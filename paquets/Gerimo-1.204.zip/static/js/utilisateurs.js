// Paramètres (Admin) : onglets Utilisateurs, Réglages, À propos, Confidentialité ;
// et « Mon mot de passe » pour tous les profils.

let comptes = null;
let compteEnCours = null;
let ongletParametres = "parUtilisateursOnglet";
const AIDE_ROLES = {
  Admin: "Admin : accès complet (paramètres, utilisateurs, suppressions avec mot de passe, résiliations, mises à jour).",
  Gestionnaire: "Gestionnaire : seulement les biens qui lui sont confiés (pas de propriétaires, d'achats/ventes ni de suppression).",
  Caisse: "Caisse : tout ce qui touche à l'argent (encaissements, reçus, relances, dépenses, achats/ventes, rapports).",
  Comptable: "Comptable : trésorerie, comptabilité (TVA, résultat, export SYSCOHADA, rapprochement bancaire), dépenses et rapports financiers ; ni encaissement, ni suppression.",
};

// ---------- Onglets ----------
function montrerOngletParametres(id) {
  ongletParametres = id;
  document.querySelectorAll("#ongletsParametres .onglet").forEach(b => {
    const actif = b.dataset.onglet === id;
    b.classList.toggle("actif", actif);
    b.setAttribute("aria-selected", actif);
    if (actif) el("parTitre").textContent = b.querySelector("span").textContent;  // grand titre, comme dans Windows
  });
  for (const zone of ["parUtilisateursOnglet", "parSauvegardes", "parJournal", "parCorbeille", "parAssistant", "parReprise", "parAPropos", "parConfidentialite"]) el(zone).style.display = zone === id ? "" : "none";
  el("formulaireParametres").style.display = id === "parReglages" ? "" : "none";
  if (id === "parUtilisateursOnglet") chargerComptes();
  else if (id === "parReglages") chargerParametres();
  else if (id === "parSauvegardes") chargerSauvegardes();
  else if (id === "parJournal") chargerJournal();
  else if (id === "parCorbeille") chargerCorbeille();
  else if (id === "parAssistant") chargerAssistantAdmin();
  else if (id === "parReprise") chargerReprise();
  else chargerAPropos();
}
el("ongletsParametres").addEventListener("click", e => {
  const b = e.target.closest(".onglet");
  if (!b) return;
  el("parametres").classList.remove("par-liste");
  montrerOngletParametres(b.dataset.onglet);
  if (TELEPHONE_PARAMETRES.matches) window.scrollTo(0, 0);
});

// Téléphone : comme les Paramètres d'Android, d'abord la liste des rubriques, puis la rubrique touchée
// en plein écran ; Retour (touche du téléphone ou « ‹ Paramètres ») revient à la liste.
const TELEPHONE_PARAMETRES = window.matchMedia("(max-width: 760px)");
let parametresDirect = false;
function ouvrirRubriqueParametres(id) { ongletParametres = id; parametresDirect = true; navTo("parametres"); }
function montrerListeParametres() {
  el("parametres").classList.add("par-liste");
  document.querySelectorAll("#ongletsParametres .onglet").forEach(b => b.classList.remove("actif"));
}
// appelé par goBack : true si le Retour a été « consommé » (rubrique ouverte → liste)
function retourParametres() {
  const p = el("parametres");
  if (!TELEPHONE_PARAMETRES.matches || !p.classList.contains("active") || p.classList.contains("par-liste")) return false;
  montrerListeParametres();
  window.scrollTo(0, 0);
  return true;
}
CHARGEURS.parametres = () => {
  const direct = parametresDirect;
  parametresDirect = false;
  if (TELEPHONE_PARAMETRES.matches && !direct) { montrerListeParametres(); chargerComptes(); return; }  // compteur des demandes
  el("parametres").classList.remove("par-liste");
  montrerOngletParametres(ongletParametres);
};

// ---------- Comptes ----------
async function chargerComptes() {
  try { comptes = await api("/api/utilisateurs"); }
  catch (e) { el("listeUtilisateurs").innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  el("nbDemandes").textContent = comptes.demandes.length || "";
  el("parDemandes").innerHTML = comptes.demandes.length ? `<div class="card"><h3>Demandes « Mot de passe oublié »</h3>${comptes.demandes.map(d => {
    const u = comptes.utilisateurs.find(x => x.id === d.utilisateur_id);
    return `<div class="row"><span class="who"><b>${esc(d.identifiant)}</b>${u ? " — " + esc(u.nom_complet) : " — identifiant inconnu"}<br><span class="petit">Demandé le ${esc(d.date)}</span></span>
      <span class="boutons">${u ? `<button class="btn-sm" onclick="redonnerMotDePasse(${u.id})">Donner un nouveau mot de passe</button>` : ""}
      <button class="btn-sm" onclick="traiterDemande(${d.id})">Ignorer</button></span></div>`;
  }).join("")}</div>` : "";
  el("listeUtilisateurs").innerHTML = `<div class="card"><h3>Comptes (${comptes.utilisateurs.length})</h3>
    <p class="petit">Gérimo ne montre jamais le mot de passe d'un employé : chacun choisit le sien à sa première connexion.</p>${comptes.utilisateurs.map(u => `
    <div class="row">
      <span class="who"><b>${esc(u.nom_complet)}</b> — identifiant <b>${esc(u.identifiant)}</b>${u.id === comptes.moi ? " (vous)" : ""}
        <br><span class="petit">${esc(u.fonction_affichee)}${u.cites.length ? " — biens : " + esc(u.cites.map(c => c.nom).join(", ")) : ""}
        — créé le ${esc(u.cree_le)}${u.derniere_connexion ? " — dernière connexion le " + esc(u.derniere_connexion) : " — jamais connecté"}</span></span>
      <span class="boutons">
        <span class="pill ${u.role === "Admin" ? "danger" : u.role === "Caisse" ? "warn" : u.role === "Comptable" ? "ok" : "info"}">${esc(u.role)}</span>
        ${u.actif ? "" : '<span class="pill">Désactivé</span>'}
        ${u.mdp_provisoire_expire_deja ? `<span class="pill danger" data-tip="Le mot de passe provisoire n'a pas servi à temps : donnez-en un nouveau">Mot de passe expiré</span>`
          : u.mdp_provisoire ? `<span class="pill warn" data-tip="${u.mdp_provisoire_expire ? "Valable jusqu'au " + esc(u.mdp_provisoire_expire) + " ; " : ""}la personne choisira le sien à sa prochaine connexion">Mot de passe provisoire</span>` : ""}
        ${ibtn("horloge", "Donner un nouveau mot de passe", `redonnerMotDePasse(${u.id})`, { classe: "doc" })}
        ${ibtn("modifier", "Modifier (profil, fonction, biens, activer / désactiver)", `modifierUtilisateur(${u.id})`)}
      </span></div>`).join("")}</div>`;
}

function remplirBiensCompte(selection = []) {
  el("utBiens").innerHTML = comptes.biens.map(b => `<label><input type="checkbox" value="${b.id}"${selection.includes(b.id) ? " checked" : ""}> ${esc(b.nom)}</label>`).join("")
    || '<span class="petit">Aucun bien enregistré.</span>';
}
function majRoleCompte() {
  const role = el("utRole").value;
  el("champUtBiens").style.display = role === "Gestionnaire" ? "" : "none";
  el("utAideRole").textContent = AIDE_ROLES[role];
  el("utFonction").placeholder = { Admin: "ex : Directeur", Gestionnaire: "Gestionnaire immobilier", Caisse: "Caissier(ère)", Comptable: "Comptable" }[role];
}
el("utRole").addEventListener("change", majRoleCompte);

function ouvrirCompte(u) {
  compteEnCours = u;
  el("utTitre").textContent = u ? `Modifier le compte de ${u.nom_complet}` : "Nouveau compte";
  el("utNom").value = u?.nom_complet || "";
  el("utIdentifiant").value = u?.identifiant || "";
  el("utRole").value = u?.role || "Gestionnaire";
  el("utFonction").value = u?.fonction || "";
  el("utAppellation").value = u?.appellation || "";
  el("utActif").checked = u ? u.actif : true;
  el("utMdp").value = "";
  el("champUtMdp").style.display = u ? "none" : "";
  el("utSupprimer").style.display = u && u.id !== comptes.moi ? "" : "none";
  remplirBiensCompte(u ? u.cites.map(c => c.id) : []);
  majRoleCompte();
  erreurFormulaire(el("formUtilisateur"), "");
  ouvrirModal("modalUtilisateur");
  el("utNom").focus();
}
function nouvelUtilisateur() { ouvrirCompte(null); }
function modifierUtilisateur(id) { ouvrirCompte(comptes.utilisateurs.find(u => u.id === id)); }

el("formUtilisateur").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (!el("utNom").value.trim()) throw new Error("Indiquez le nom et les prénoms.");
    if (!/^[A-Za-z0-9._-]{3,80}$/.test(el("utIdentifiant").value.trim()))
      throw new Error("Identifiant : 3 caractères minimum, lettres, chiffres, point, tiret (sans espace ni accent).");
    const corps = {
      nom_complet: el("utNom").value, identifiant: el("utIdentifiant").value.trim(), role: el("utRole").value,
      fonction: el("utFonction").value, appellation: el("utAppellation").value, actif: el("utActif").checked,
      cites_ids: [...el("utBiens").querySelectorAll("input:checked")].map(c => Number(c.value)),
    };
    if (compteEnCours) {
      await api(`/api/utilisateurs/${compteEnCours.id}`, { method: "PUT", body: corps });
      toast("Compte enregistré");
    } else {
      const mdp = el("utMdp").value;
      if (mdp.length < 8 || !/\d/.test(mdp) || !/\p{L}/u.test(mdp)) throw new Error("Mot de passe provisoire : 8 caractères minimum, avec lettres et chiffres.");
      await api("/api/utilisateurs", { method: "POST", body: { ...corps, mot_de_passe: mdp } });
      alert(`Compte créé.\n\nProfil : ${corps.role}\nIdentifiant : ${corps.identifiant}\nMot de passe provisoire : ${mdp}\n\n` +
            "Communiquez-les à la personne. Ce mot de passe est valable 48 heures et ne sert qu'une fois : à sa première " +
            "connexion, elle choisira le sien, que personne d'autre ne connaîtra (pas même l'Admin).");
    }
    fermerModal("modalUtilisateur");
    chargerComptes();
  });
});

el("utSupprimer").addEventListener("click", () => {
  const u = compteEnCours;
  fermerModal("modalUtilisateur");
  supprimerAvecConfirmation(`Supprimer le compte de ${u.nom_complet} ? (S'il a déjà enregistré des opérations, désactivez-le plutôt.) Mot de passe Admin.`,
    `/api/utilisateurs/${u.id}/supprimer`, chargerComptes);
});

async function traiterDemande(id) {
  try { await api(`/api/demandes-reinitialisation/${id}/traiter`, { method: "POST" }); chargerComptes(); } catch (e) { toast(e.message); }
}

// ---------- Mots de passe ----------
let mdpPour = null;   // null = mon mot de passe ; sinon id du compte (Admin)
function ouvrirMotDePasse(titre, texte, pourId) {
  mdpPour = pourId;
  el("mdpTitre").textContent = titre;
  el("mdpTexte").textContent = texte;
  el("champMdpAncien").style.display = pourId ? "none" : "";
  ["mdpAncien", "mdpNouveau", "mdpConfirme"].forEach(id => { el(id).value = ""; });
  erreurFormulaire(el("formMotDePasse"), "");
  ouvrirModal("modalMotDePasse");
  el(pourId ? "mdpNouveau" : "mdpAncien").focus();
}
function changerMonMotDePasse() {
  closeMenu();
  ouvrirMotDePasse("Mon mot de passe", `Profil ${moi.role} — identifiant ${moi.identifiant}`, null);
}
function redonnerMotDePasse(id) {
  const u = comptes.utilisateurs.find(x => x.id === id);
  ouvrirMotDePasse(`Nouveau mot de passe pour ${u.nom_complet}`, "Mot de passe provisoire, valable 48 heures : ses sessions ouvertes sont fermées, et à sa prochaine connexion il choisira le sien. C'est noté au journal et il en sera informé.", id);
}
el("formMotDePasse").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    const nouveau = el("mdpNouveau").value;
    if (nouveau !== el("mdpConfirme").value) throw new Error("Les deux mots de passe ne correspondent pas.");
    if (nouveau.length < 8 || !/\d/.test(nouveau) || !/\p{L}/u.test(nouveau)) throw new Error("8 caractères minimum, avec au moins une lettre et un chiffre.");
    if (mdpPour) await api(`/api/utilisateurs/${mdpPour}/mot-de-passe`, { method: "POST", body: { mot_de_passe: nouveau } });
    else {
      await api("/api/moi/mot-de-passe", { method: "POST", body: { ancien: el("mdpAncien").value, nouveau } });
      const pont = (window.ISUPAndroid && window.ISUPAndroid.memoriserConnexion ? window.ISUPAndroid : null) || window.GerimoPont;
      if (pont) await Promise.resolve(pont.memoriserConnexion(moi.identifiant, nouveau)).catch(() => {});
    }
    fermerModal("modalMotDePasse");
    toast("Mot de passe enregistré ✅");
    if (mdpPour && comptes) chargerComptes();
  });
});

// ---------- À propos et confidentialité ----------
async function activerLicence() {
  const cle = el("cleLicence").value.trim();
  if (!cle) { toast("Collez d'abord la clé de licence reçue de l'éditeur."); return; }
  try {
    const rep = await api("/api/licence", { method: "POST", body: { cle } });
    toast(rep.message, 8000);
  } catch (e) { toast(e.message, 10000); return; }
  chargerAPropos();
}

async function verifierAbonnement(bouton) {
  bouton.disabled = true;
  try {
    const rep = await api("/api/licence/verifier", { method: "POST" });
    toast(rep.resultat.message, 8000);
    if (rep.resultat.installee) chargerAPropos();
  } catch (e) { toast(e.message, 8000); }
  bouton.disabled = false;
}

async function chargerAPropos() {
  let a, lic;
  try { [a, lic] = await Promise.all([api("/api/a-propos"), api("/api/licence")]); }
  catch (e) { el("parAPropos").innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  const pastille = { active: '<span class="pill ok">Active</span>', essai: '<span class="pill warn">Essai</span>',
                     relais: '<span class="pill warn">PC de secours</span>', retard: '<span class="pill warn">À régler</span>',
                     reduite: '<span class="pill danger">Fonctions réduites</span>', lecture_seule: '<span class="pill danger">Lecture seule</span>' }[lic.statut] || "";
  const texteWa = encodeURIComponent(`Bonjour, voici le code PC de notre serveur Gérimo : ${lic.code_pc}. Merci de m'envoyer la clé de licence.`);
  el("parAPropos").innerHTML = `
    <div class="card a-propos-tete">
      <div class="sm-logo gerimo" role="img" aria-label="Logo Gérimo" style="width:64px;height:64px;border-radius:18px"></div>
      <div><h2>${esc(a.nom)}</h2><p class="petit">${esc(a.sous_titre)}</p>
        <p><b>Version ${esc(a.version)}</b>${a.date ? ` — du ${esc(a.date)}` : ""}</p></div>
      <button class="btn primary a-propos-maj" onclick="ouvrirMiseAJour()"><svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-3-6.7"/><polyline points="21 3 21 9 15 9"/></svg>Mise à jour</button>
    </div>
    <div class="card" id="carteLicence">
      <h3>Licence</h3>
      <div class="row"><span class="who">${pastille} ${esc(lic.message)}${lic.numero ? ` <span class="petit">(${esc(lic.numero)})</span>` : ""}
        ${lic.controle ? "" : '<br><span class="petit">PC de développement : la licence n\'y est pas contrôlée.</span>'}</span></div>
      ${(lic.metiers || []).length ? `<div class="row"><span class="who">Métiers ouverts : <b>${lic.metiers.map(m => esc(m.libelle)).join(", ")}</b>
        <br><span class="petit">Pour ajouter un métier (par exemple le commerce), demandez à l'éditeur une nouvelle clé de licence.</span></span></div>` : ""}
      <div class="row"><span class="who">Code de ce PC : <b style="font-family:Consolas,monospace;letter-spacing:.05em">${esc(lic.code_pc)}</b>
        <br><span class="petit">À envoyer à l'éditeur de Gérimo pour recevoir la clé de licence de ce PC (et celui du PC de secours, s'il y en a un).</span></span>
        <span class="boutons"><button class="btn-sm wa" onclick="window.open('https://wa.me/${esc(lic.whatsapp_editeur)}?text=${texteWa}', '_blank')">Envoyer par WhatsApp</button></span></div>
      <div class="pj-boutons"><input id="cleLicence" class="search" placeholder="Collez ici la clé reçue (GERIMO1.…)" autocomplete="off">
        <button class="btn primary" onclick="activerLicence()">Activer</button></div>
      <div class="row"><span class="who petit">Abonnement payé ? Gérimo installe tout seul la clé débloquée (vérification toutes les 30 minutes quand Internet est disponible).</span>
        <span class="boutons"><button class="btn-sm" onclick="verifierAbonnement(this)">Vérifier mon abonnement</button></span></div>
    </div>
    <div class="card"><h3>Licence accordée à</h3><p class="petit"><b>${esc(a.licencie.nom)}</b> — ${esc(a.licencie.activite)}<br>${esc(a.licencie.adresse)}<br>
      ${esc(a.licencie.contact)}<br>${esc(a.licencie.rccm)} — ${esc(a.licencie.ncc)}</p></div>
    <div class="card"><h3>Écran de ce PC</h3>
      <div class="row"><span class="who petit" id="ligneEcran">${esc(texteEcran())}</span>
        <span class="boutons"><button class="btn-sm" onclick="reglerEcran()">Ajuster l'écran</button></span></div></div>
    ${await carteSuivi()}
    <p class="petit" style="text-align:center">Gérimo — Logiciel de gestion immobilière. Tous droits réservés.</p>`;
  el("parConfidentialite").innerHTML = `<div class="card politique"><h3>Politique de confidentialité</h3>
    <p class="petit">Dernière mise à jour : ${esc(a.politique_date)}</p>
    ${a.politique.map(([genre, texte]) => genre === "titre" ? `<h4>${esc(texte)}</h4>` : genre === "liste" ? `<p class="puce">• ${esc(texte)}</p>` : `<p>${esc(texte)}</p>`).join("")}</div>`;
}
