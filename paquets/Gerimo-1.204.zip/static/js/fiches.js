// Fiches de l'immobilier (13/11/2026, demande de Boss) : l'essentiel en évidence et un clic pour tout voir.
// - En haut de chaque liste : des chiffres clés (cliquables quand ils filtrent la liste).
// - Chaque ligne porte la couleur de son état (à jour, en retard, à risque, départ, terminé) et s'ouvre d'un clic
//   dans une fenêtre claire. Les boutons des lignes gardent leur rôle habituel.
// Le serveur (fiches.py) applique les mêmes droits que les listes.

const ETATS_IMMO = {
  a_jour: { texte: "À jour", pill: "ok" }, retard: { texte: "En retard", pill: "warn" },
  a_risque: { texte: "À risque", pill: "danger" }, depart: { texte: "Départ prévu", pill: "info" },
  termine: { texte: "Terminé", pill: "" }, libre: { texte: "Libre", pill: "warn" },
};

// État d'une ligne de liste (contrat ou locataire), avec les seules données de la liste
function etatListeContrat(c) {
  if (!STATUTS_EN_COURS.includes(c.statut_contrat)) return "termine";
  if (c.a_risque) return "a_risque";
  if (c.en_retard) return "retard";
  if (c.date_depart) return "depart";
  return "a_jour";
}
function etatListeLocataire(l) {
  const ordre = ["a_risque", "retard", "depart", "a_jour"];
  const etats = l.contrats.filter(c => STATUTS_EN_COURS.includes(c.statut_contrat)).map(etatListeContrat);
  return ordre.find(e => etats.includes(e)) || "termine";
}

// ---------- Chiffres clés en haut d'une liste ----------

function resumeAvant(idListe, tuiles) {
  const liste = el(idListe);
  let zone = el(idListe + "Resume");
  if (!zone) {
    zone = document.createElement("div");
    zone.id = idListe + "Resume";
    zone.className = "resume-stock";
    liste.parentElement.insertBefore(zone, liste.previousElementSibling && liste.previousElementSibling.classList.contains("toolbar")
      ? liste.previousElementSibling : liste);
  }
  const filtre = liste.dataset.filtre || "";
  zone.innerHTML = tuiles.map(t => t.filtre !== undefined
    ? `<button class="chiffre-cle ${t.classe || "neutre"}${filtre === t.filtre && t.filtre ? " choisi" : ""}" onclick="filtrerListeImmo('${idListe}', '${t.filtre}')">
        <span class="cc-chiffre">${t.chiffre}</span><span class="cc-libelle">${t.libelle}</span><span class="cc-aide">${t.aide || ""}</span></button>`
    : `<div class="chiffre-cle ${t.classe || "neutre"} statique"><span class="cc-chiffre">${t.chiffre}</span>
        <span class="cc-libelle">${t.libelle}</span><span class="cc-aide">${t.aide || ""}</span></div>`).join("");
}
// Filtre par état : ajoute une classe sur la liste (la recherche continue de marcher par-dessus)
function filtrerListeImmo(idListe, filtre) {
  const liste = el(idListe);
  liste.dataset.filtre = liste.dataset.filtre === filtre ? "" : filtre;
  liste.className = liste.dataset.filtre ? `filtre-${liste.dataset.filtre}` : "";
  const zone = el(idListe + "Resume");
  if (zone) zone.querySelectorAll("button.chiffre-cle").forEach(b => {
    b.classList.toggle("choisi", !!liste.dataset.filtre && b.getAttribute("onclick").includes(`'${liste.dataset.filtre}'`));
  });
}

function resumeLocataires() {
  const etats = locatairesCache.map(etatListeLocataire);
  const n = e => etats.filter(x => x === e).length;
  const enCours = etats.filter(e => e !== "termine").length;
  resumeAvant("listeLocataires", [
    { filtre: "", chiffre: locatairesCache.length, libelle: "Locataires", aide: `${enCours} avec un contrat en cours` },
    { filtre: "retard", classe: n("retard") + n("a_risque") ? "alerte-orange" : "calme", chiffre: n("retard") + n("a_risque"),
      libelle: "En retard de loyer", aide: n("retard") + n("a_risque") ? "voir qui relancer" : "tout le monde est à jour" },
    { filtre: "a_risque", classe: n("a_risque") ? "alerte" : "calme", chiffre: n("a_risque"), libelle: "À risque", aide: "2 mois impayés ou plus" },
    { filtre: "depart", classe: "neutre", chiffre: n("depart"), libelle: "Départs prévus", aide: "préavis reçus" },
  ]);
}

function resumeContrats() {
  const etats = contratsCache.map(etatListeContrat);
  const n = e => etats.filter(x => x === e).length;
  const enCours = etats.filter(e => e !== "termine").length;
  const loyers = contratsCache.filter(c => STATUTS_EN_COURS.includes(c.statut_contrat)).reduce((s, c) => s + c.montant_loyer, 0);
  resumeAvant("listeContrats", [
    { filtre: "", chiffre: enCours, libelle: "Contrats en cours", aide: `${formatMontant(loyers)} de loyers par mois` },
    { filtre: "retard", classe: n("retard") + n("a_risque") ? "alerte-orange" : "calme", chiffre: n("retard") + n("a_risque"),
      libelle: "En retard de loyer", aide: "au moins un mois impayé" },
    { filtre: "a_risque", classe: n("a_risque") ? "alerte" : "calme", chiffre: n("a_risque"), libelle: "À risque", aide: "2 mois impayés ou plus" },
    { filtre: "depart", classe: "neutre", chiffre: n("depart"), libelle: "Départs prévus", aide: "préavis reçus" },
  ]);
}

function resumeBiens() {
  const logements = citesCache.flatMap(c => c.logements);
  const occupes = logements.filter(l => l.statut_logement === "Occupé").length;
  const libres = logements.filter(l => l.statut_logement === "Libre").length;
  const taux = logements.length ? Math.round(occupes * 100 / logements.length) : 0;
  resumeAvant("listeBiens", [
    { chiffre: citesCache.length, libelle: citesCache.length > 1 ? "Biens" : "Bien", aide: `${logements.length} logement${logements.length > 1 ? "s" : ""}` },
    { chiffre: `${taux} %`, classe: taux >= 80 ? "calme" : "neutre", libelle: "Occupation", aide: `${occupes} occupé${occupes > 1 ? "s" : ""}` },
    { filtre: "libre", classe: libres ? "alerte-orange" : "calme", chiffre: libres, libelle: "Logements libres", aide: libres ? "à louer" : "tout est loué" },
  ]);
}

function resumeProprios() {
  const biens = propriosCache.reduce((s, p) => s + p.cites.length, 0);
  const logements = propriosCache.reduce((s, p) => s + p.cites.reduce((t, c) => t + c.nb_logements, 0), 0);
  resumeAvant("listeProprios", [
    { chiffre: propriosCache.length, libelle: "Propriétaires", aide: "cliquez sur un nom pour sa fiche" },
    { chiffre: biens, libelle: "Biens confiés", aide: `${logements} logement${logements > 1 ? "s" : ""}` },
  ]);
}

// Après chaque chargement de liste (les fonctions d'origine restent inchangées)
function apresChargement(nom, suite) {
  const origine = window[nom];
  window[nom] = async function (...args) {
    const r = await origine.apply(this, args);
    try { suite(); } catch (e) { console.error(e); }
    return r;
  };
}
apresChargement("chargerLocataires", () => { if (locatairesCache.length) resumeLocataires(); });
apresChargement("chargerContrats", () => { if (contratsCache.length) resumeContrats(); });
apresChargement("chargerBiens", () => { if (citesCache.length) resumeBiens(); });
apresChargement("chargerProprios", () => { if (propriosCache.length) resumeProprios(); });
CHARGEURS.locataires = window.chargerLocataires;
CHARGEURS.contrats = window.chargerContrats;
CHARGEURS.biens = window.chargerBiens;
CHARGEURS.proprietaires = window.chargerProprios;

// ---------- Clic sur une ligne → sa fiche ----------

document.addEventListener("click", e => {
  const ligne = e.target.closest(".row[data-fiche]");
  if (!ligne || e.target.closest("button, a, input, select, .boutons, .pill")) return;
  const [genre, id] = ligne.dataset.fiche.split(":");
  ouvrirFiche(genre, Number(id));
});
document.addEventListener("keydown", e => {
  if (e.key !== "Enter") return;
  const ligne = e.target.closest && e.target.closest(".row[data-fiche]");
  if (ligne && e.target === ligne) { const [g, id] = ligne.dataset.fiche.split(":"); ouvrirFiche(g, Number(id)); }
});

function ouvrirFiche(genre, id) {
  ({ locataire: ficheLocataire, contrat: ficheContrat, bien: ficheBien, proprietaire: ficheProprietaire })[genre]?.(id);
}

// Petits morceaux communs des fenêtres
const statFiche = (libelle, valeur, aide = "", classe = "") =>
  `<div class="fiche-stat ${classe}"><small>${libelle}</small><b>${valeur}</b>${aide ? `<span>${aide}</span>` : ""}</div>`;
const pillEtat = (code, texte) => `<span class="pill ${ETATS_IMMO[code]?.pill ?? ""}">${esc(texte || ETATS_IMMO[code]?.texte || code)}</span>`;
function teteFiche(titre, sousTitre) {
  return `<div class="fa-tete"><div><h2>${esc(titre)}</h2><p>${sousTitre || "&nbsp;"}</p></div>
    <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>`;
}
function bandeauFiche(code, etat, grand, aide = "") {
  return `<div class="fa-stock etat-${code}"><span class="fa-etat">${esc(etat)}</span><span class="fa-quantite">${grand}</span>
    ${aide ? `<span class="fa-aide">${aide}</span>` : ""}</div>`;
}
function listePaiements(paiements) {
  if (!paiements.length) return "";
  return `<h4>Derniers paiements</h4><div class="fa-liste">${paiements.map(p => `
    <div class="fa-ligne"><span>${formatDate(p.date)} — ${esc(p.periode || p.motif)} <small>(${esc(p.mode)}${p.numero_recu ? ", reçu " + esc(p.numero_recu) : ""})</small></span>
      <span><b class="${p.statut === "Payé" ? "plus" : "moins"}">${formatMontant(p.montant)}</b>${p.statut !== "Payé" ? ` ${pillEtat("termine", p.statut)}` : ""}</span></div>`).join("")}</div>`;
}
function boutonsFiche(boutons) {
  return `<div class="actions fiche-actions">${boutons.filter(Boolean).join("")}<button class="btn" data-fermer>Fermer</button></div>`;
}
// Brancher les boutons [data-action] d'une fenêtre : la fenêtre se ferme puis l'action s'exécute
function brancherActions(fen, actions) {
  fen.querySelectorAll("[data-action]").forEach(b => b.addEventListener("click", () => {
    const action = actions[b.dataset.action];
    if (!action) return;
    if (!b.hasAttribute("data-garder")) fen.fermer();
    action(b.dataset);
  }));
}
const lienTel = tel => tel ? `<a href="tel:${esc(tel.replace(/\s/g, ""))}">${esc(tel)}</a>` : "";

// ---------- Locataire ----------

async function ficheLocataire(id) {
  let l;
  try { l = await api(`/api/fiches/locataire/${id}`); } catch (e) { toast(e.message); return; }
  const enCours = l.contrats.filter(c => c.etat !== "termine");
  const prochaine = enCours.map(c => c.prochaine_echeance).filter(Boolean)[0];
  const grand = l.etat === "termine" ? "Aucun contrat en cours" : l.total_du ? `${formatMontant(l.total_du)} à payer` : "Rien à payer";
  const aide = l.etat === "a_risque" ? "2 mois impayés ou plus : à relancer d'urgence."
    : l.etat === "retard" ? "Au moins un mois impayé : pensez à le relancer." : l.etat === "depart" ? "Il a annoncé son départ." : "";
  const fen = ouvrirFenetre(`<div class="fiche-article">
    ${teteFiche(l.nom_complet, [l.profession, lienTel(l.telephone), l.cni ? "CNI " + esc(l.cni) : "", l.email].filter(Boolean).map(x => x.startsWith("<a") ? x : esc(x)).join(" · "))}
    ${bandeauFiche(l.etat, ETATS_IMMO[l.etat].texte, grand, aide)}
    <div class="fiche-stats">
      ${statFiche("Loyer par mois", formatMontant(l.loyer_mensuel), enCours.length > 1 ? `${enCours.length} logements` : "")}
      ${statFiche("Reste à payer", formatMontant(l.total_du), l.total_du ? "mois échus" : "à jour", l.total_du ? "negatif" : "positif")}
      ${prochaine ? statFiche("Prochain loyer", formatMontant(prochaine.montant), `${esc(prochaine.mois)}, avant le ${formatDate(prochaine.date_limite)}`) : ""}
      ${l.client_depuis ? statFiche("Locataire depuis", formatDate(l.client_depuis)) : ""}
    </div>
    ${l.contrats.length ? `<h4>Contrats</h4><div class="fa-liste">${l.contrats.map(c => `
      <button class="fa-ligne cliquable" data-action="contrat" data-id="${c.id}"><span><b>${esc(c.logement)}</b> <small>· N° ${esc(c.numero_contrat)} · ${formatMontant(c.montant_loyer)}/mois</small>
        ${c.impayes ? `<br><small>Impayés : ${esc(c.impayes.mois.join(", "))}</small>` : ""}</span>${pillEtat(c.etat, c.etat_texte)}</button>`).join("")}</div>` : ""}
    ${listePaiements(l.paiements)}
    ${l.nb_pieces ? `<p class="petit">📎 ${l.nb_pieces} pièce${l.nb_pieces > 1 ? "s" : ""} jointe${l.nb_pieces > 1 ? "s" : ""} (CNI…) : bouton « Modifier ».</p>` : ""}
    ${boutonsFiche([
      l.telephone ? `<button class="btn" data-action="whatsapp">WhatsApp</button>` : "",
      `<button class="btn" data-action="modifier">Modifier</button>`,
      l.voit_paiements && enCours.length ? `<button class="btn primary" data-action="encaisser">Encaisser un loyer</button>` : "",
    ])}</div>`, { taille: "large" });
  brancherActions(fen, {
    contrat: d => ficheContrat(Number(d.id)),
    whatsapp: () => whatsAppLocataire(l.id),
    modifier: () => modifierLocataire(l.id),
    encaisser: () => encaisserPour(enCours[0].id),
  });
}

// ---------- Contrat ----------

async function ficheContrat(id) {
  let c;
  try { c = await api(`/api/fiches/contrat/${id}`); } catch (e) { toast(e.message); return; }
  const enCours = c.etat !== "termine";
  const grand = !enCours ? esc(c.statut_contrat) : c.impayes ? `${formatMontant(c.impayes.montant)} à payer` : "Loyers à jour";
  const aide = c.impayes ? `Mois impayés : ${esc(c.impayes.mois.join(", "))}${c.impayes.deja_verse ? ` (déjà versé ${formatMontant(c.impayes.deja_verse)})` : ""}`
    : c.date_depart ? `Départ prévu le ${formatDate(c.date_depart)}${c.motif_depart ? " — " + esc(c.motif_depart) : ""}`
    : c.statut_contrat === "Résilié" ? `Résilié le ${formatDate(c.date_resiliation)}${c.motif_resiliation ? " — " + esc(c.motif_resiliation) : ""}` : "";
  const fen = ouvrirFenetre(`<div class="fiche-article">
    ${teteFiche(`${c.locataire.nom_complet}`, `Contrat N° ${esc(c.numero_contrat)} · ${esc(c.type_contrat)} · Logement ${esc(c.logement.numero_logement)}, ${esc(c.logement.cite_nom)}`)}
    ${bandeauFiche(c.etat, c.etat_texte, grand, aide)}
    <div class="fiche-stats">
      ${statFiche("Loyer", formatMontant(c.montant_loyer), `payé en ${esc(c.terme_loyer.toLowerCase())}`)}
      ${c.prochaine_echeance ? statFiche("Prochain loyer", esc(c.prochaine_echeance.mois), `avant le ${formatDate(c.prochaine_echeance.date_limite)}`) : ""}
      ${statFiche("Caution", formatMontant(c.montant_caution), `${c.mois_caution} mois`)}
      ${statFiche("Avance", formatMontant(c.montant_avance), `${c.mois_avance} mois`)}
      ${statFiche("Début", formatDate(c.date_debut), c.date_fin ? `fin le ${formatDate(c.date_fin)}` : "sans date de fin")}
      ${statFiche("Mois réglés", c.nb_mois_payes, "depuis le début du suivi")}
    </div>
    <h4>Locataire</h4>
    <div class="fa-liste"><button class="fa-ligne cliquable" data-action="locataire"><span><b>${esc(c.locataire.nom_complet)}</b>
      ${c.locataire.telephone ? ` <small>· ${esc(c.locataire.telephone)}</small>` : ""}</span><span class="petit">voir sa fiche ›</span></button></div>
    ${listePaiements(c.paiements)}
    ${boutonsFiche([
      `<button class="btn" data-action="pdf">Contrat en PDF</button>`,
      enCours && c.locataire.telephone ? `<button class="btn" data-action="whatsapp">${c.impayes ? "Relancer (WhatsApp)" : "Bienvenue (WhatsApp)"}</button>` : "",
      c.statut_contrat !== "Résilié" ? `<button class="btn" data-action="modifier">Modifier</button>` : "",
      enCours && c.voit_paiements ? `<button class="btn primary" data-action="encaisser">Encaisser</button>` : "",
    ])}</div>`, { taille: "large" });
  brancherActions(fen, {
    locataire: () => ficheLocataire(c.locataire.id),
    pdf: () => ouvrirContratPdf(c.id),
    whatsapp: () => envoyerWhatsApp(c.impayes ? "retard" : "bienvenue", { contrat_id: c.id }),
    modifier: () => modifierContrat(c.id),
    encaisser: () => encaisserPour(c.id),
  });
}

// ---------- Bien ----------

async function ficheBien(id) {
  let b;
  try { b = await api(`/api/fiches/bien/${id}`); } catch (e) { toast(e.message); return; }
  const code = b.impayes ? "retard" : b.libres ? "libre" : "a_jour";
  const sous = [esc(b.adresse), b.proprietaire ? `Propriétaire : ${esc(b.proprietaire.nom_complet)}` : "",
                b.pourcentage_commission != null ? `Commission ${formatNombre(b.pourcentage_commission)} %` : "",
                b.gestionnaires && b.gestionnaires.length ? `Gestionnaire : ${esc(b.gestionnaires.join(", "))}` : ""].filter(Boolean).join(" · ");
  const fen = ouvrirFenetre(`<div class="fiche-article">
    ${teteFiche(b.nom, sous)}
    ${bandeauFiche(code, "Occupation", `${b.occupes} / ${b.nb_logements} logements occupés`,
      `${b.taux_occupation} % · ${b.libres} libre${b.libres > 1 ? "s" : ""}${b.impayes ? ` · ${formatMontant(b.impayes)} de loyers impayés` : ""}`)}
    <div class="fiche-stats">
      ${statFiche("Loyers attendus", formatMontant(b.loyers_attendus), "par mois")}
      ${statFiche("Impayés", formatMontant(b.impayes), b.impayes ? "mois échus" : "rien à relancer", b.impayes ? "negatif" : "positif")}
      ${statFiche("Logements libres", b.libres, b.libres ? "à louer" : "tout est loué")}
      ${b.parcelles.length ? statFiche("Parcelles", b.parcelles.length) : ""}
    </div>
    ${b.logements.length ? `<h4>Logements</h4><div class="fa-tableau"><table><thead><tr><th>Logement</th><th>Locataire</th><th>Loyer</th><th>État</th></tr></thead><tbody>
      ${b.logements.map(l => `<tr class="${l.locataire ? "ligne-cliquable" : ""}" ${l.locataire ? `data-action="locataire" data-id="${l.locataire.id}" data-garder` : ""}>
        <td><b>${esc(l.numero)}</b> <small>${esc(l.type)}</small></td>
        <td>${l.locataire ? esc(l.locataire.nom_complet) : '<span class="petit">—</span>'}</td>
        <td>${formatMontant(l.loyer)}</td>
        <td>${l.locataire ? pillEtat(l.etat, l.etat_texte) : `<span class="pill ${CLASSE_STATUT[l.statut] || ""}">${esc(l.statut)}</span>`}</td></tr>`).join("")}
    </tbody></table></div>` : ""}
    ${b.description ? `<h4>Description</h4><p>${esc(b.description)}</p>` : ""}
    ${boutonsFiche([
      `<button class="btn" data-action="probleme">Déclarer un problème</button>`,
      estAdmin() ? `<button class="btn primary" data-action="modifier">Modifier le bien</button>` : "",
    ])}</div>`, { taille: "large" });
  brancherActions(fen, {
    locataire: d => { fen.fermer(); ficheLocataire(Number(d.id)); },
    probleme: () => declarerProbleme(b.id),
    modifier: () => modifierCite(b.id),
  });
}

// ---------- Propriétaire ----------

async function ficheProprietaire(id) {
  let p;
  try { p = await api(`/api/fiches/proprietaire/${id}`); } catch (e) { toast(e.message); return; }
  const code = p.impayes ? "retard" : "a_jour";
  const fen = ouvrirFenetre(`<div class="fiche-article">
    ${teteFiche(p.nom_complet, [lienTel(p.telephone), p.ville ? esc(p.ville) : "", p.cni ? "CNI " + esc(p.cni) : "", p.email ? esc(p.email) : ""].filter(Boolean).join(" · "))}
    ${bandeauFiche(code, "Ses biens", `${p.biens.length} bien${p.biens.length > 1 ? "s" : ""} · ${p.occupes} / ${p.nb_logements} logements occupés`,
      p.impayes ? `${formatMontant(p.impayes)} de loyers impayés chez ses locataires` : "Aucun loyer impayé chez ses locataires")}
    <div class="fiche-stats">
      ${statFiche("Loyers attendus", formatMontant(p.loyers_attendus), "par mois")}
      ${statFiche("Impayés", formatMontant(p.impayes), "", p.impayes ? "negatif" : "positif")}
      ${statFiche("Logements", p.nb_logements, `${p.occupes} occupé${p.occupes > 1 ? "s" : ""}`)}
    </div>
    ${p.biens.length ? `<h4>Ses biens</h4><div class="fa-liste">${p.biens.map(b => `
      <button class="fa-ligne cliquable" data-action="bien" data-id="${b.id}"><span><b>${esc(b.nom)}</b>
        <small>· ${b.occupes}/${b.nb_logements} occupés${b.nb_parcelles ? ` · ${b.nb_parcelles} parcelle${b.nb_parcelles > 1 ? "s" : ""}` : ""}${
          b.pourcentage_commission != null ? ` · commission ${formatNombre(b.pourcentage_commission)} %` : ""}</small>
        <br><small>${formatMontant(b.loyers_attendus)}/mois${b.impayes ? ` · <b class="moins">${formatMontant(b.impayes)} impayés</b>` : ""}</small></span>
        <span class="petit">voir ›</span></button>`).join("")}</div>` : '<p class="petit">Aucun bien enregistré pour ce propriétaire.</p>'}
    ${p.nb_pieces ? `<p class="petit">📎 ${p.nb_pieces} pièce${p.nb_pieces > 1 ? "s" : ""} jointe${p.nb_pieces > 1 ? "s" : ""} : bouton « Modifier ».</p>` : ""}
    ${boutonsFiche([
      p.telephone ? `<button class="btn" data-action="whatsapp">WhatsApp</button>` : "",
      `<button class="btn primary" data-action="modifier">Modifier</button>`,
    ])}</div>`, { taille: "large" });
  brancherActions(fen, {
    bien: d => ficheBien(Number(d.id)),
    whatsapp: () => ouvrirWhatsAppTexte(p.telephone),
    modifier: () => modifierProprietaire(p.id),
  });
}
