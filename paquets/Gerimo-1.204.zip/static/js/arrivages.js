// Commerce, partie 2 (13/11/2026) : arrivages de marchandises et « ce que je dois aux fournisseurs ».
// Le magasinier (Gestionnaire) compte ; la Caisse ou l'Admin met les prix et paie. Le serveur revérifie tout.

let arrivagesCache = [];
TITRES_ECRANS.formArrivage = ["Arrivage de marchandises", "Ce que le fournisseur vient de livrer"];
ECRANS.formArrivage = "stock";

// État le plus important d'un arrivage, en couleur
function etatArrivage(a) {
  if (a.annule) return { classe: "annule", texte: "Annulé" };
  if (!a.prix_complets) return { classe: "a-completer", texte: "Prix à compléter" };
  if (a.reste > 0) return { classe: "a-payer", texte: `Reste à payer ${formatMontant(a.reste)}` };
  return { classe: "paye", texte: "Payé" };
}
const resumeLignes = a => a.lignes.map(l => `${nombre(l.quantite)} ${l.unite} ${l.article}`).join(", ");

async function chargerArrivages() {
  const zone = el("listeArrivages");
  try {
    [arrivagesCache] = await Promise.all([api("/api/arrivages"), optionsCommerce ? null : chargerOptionsCommerce()]);
  } catch (e) {
    zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`;
    return;
  }
  afficherArrivages();
}

function afficherArrivages() {
  const zone = el("listeArrivages");
  if (!arrivagesCache.length) {
    zone.innerHTML = '<div class="card vide">Aucun arrivage pour l\'instant. Quand un fournisseur livre, cliquez sur « + Nouvel arrivage » : le stock augmente tout de suite.</div>';
    return;
  }
  const mots = normaliser(el("rechercheArrivages").value).split(/\s+/).filter(Boolean);
  const liste = arrivagesCache.filter(a => !mots.length || mots.every(m =>
    normaliser([a.numero, a.fournisseur, a.reference_facture, resumeLignes(a)].join(" ")).includes(m)));
  // Ce qui demande une action d'abord : prix à compléter, puis reste à payer
  const voitArgent = optionsCommerce && optionsCommerce.voit_achats;
  const aFaire = voitArgent ? liste.filter(a => !a.annule && (!a.prix_complets || a.reste > 0)) : [];
  const reste = liste.filter(a => !aFaire.includes(a));
  const tuile = a => {
    const e = etatArrivage(a);
    return `<button class="tuile-arrivage etat-${e.classe}" onclick="ouvrirArrivage(${a.id})">
      <span class="tarr-haut"><b>${esc(a.fournisseur)}</b><span class="tarr-etat">${esc(e.texte)}</span></span>
      <span class="tarr-contenu">${esc(resumeLignes(a))}</span>
      <span class="tarr-bas">${formatDate(a.date_arrivage)} · ${esc(a.numero)}${a.reference_facture ? ` · facture ${esc(a.reference_facture)}` : ""}${
        voitArgent && a.prix_complets ? ` · <b>${formatMontant(a.montant_total)}</b>` : ""}</span>
    </button>`;
  };
  zone.innerHTML = (aFaire.length ? `<h3 class="titre-groupe">À traiter (${aFaire.length})</h3><div class="tuiles-arrivages">${aFaire.map(tuile).join("")}</div>` : "")
    + (reste.length ? `<h3 class="titre-groupe">${aFaire.length ? "Déjà réglés" : "Arrivages"}</h3><div class="tuiles-arrivages">${reste.map(tuile).join("")}</div>` : "")
    || '<div class="card vide">Aucun arrivage ne correspond.</div>';
}
el("rechercheArrivages").addEventListener("input", () => { if (arrivagesCache.length) afficherArrivages(); });

// ---------- Fenêtre de détail : voir, mettre les prix, payer, annuler ----------

async function ouvrirArrivage(id) {
  await chargerArrivages();
  const a = arrivagesCache.find(x => x.id === id);
  if (!a) return;
  const o = optionsCommerce;
  const e = etatArrivage(a);
  const peutPrix = o.voit_achats && !a.annule;
  const fen = ouvrirFenetre(`
    <div class="fiche-article">
      <div class="fa-tete"><div><h2>${esc(a.fournisseur)}</h2><p>Arrivage ${esc(a.numero)} du ${formatDate(a.date_arrivage)}${
        a.reference_facture ? ` · facture ${esc(a.reference_facture)}` : ""}${a.saisi_par ? ` · saisi par ${esc(a.saisi_par)}` : ""}</p></div>
        <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
      <div class="fa-stock etat-${e.classe}"><span class="fa-etat">État</span><span class="fa-quantite">${esc(e.texte)}</span>
        <span class="fa-aide">${a.annule ? esc(a.motif_annulation) : !a.prix_complets ? (o.voit_achats ? "Tapez le prix de chaque ligne (celui de la facture), puis enregistrez." : "La Caisse ou l'Admin mettra les prix de la facture.")
          : o.voit_achats ? `Total ${formatMontant(a.montant_total)} · déjà payé ${formatMontant(a.paye)}` : ""}</span></div>
      <h4>Ce qui est arrivé</h4>
      <form id="formPrixArrivage" novalidate><div class="fa-tableau"><table><thead><tr><th>Article</th><th>Quantité</th><th>Date limite</th>
        ${o.voit_achats ? "<th>Prix d'un lot (F)</th><th>Total</th>" : ""}</tr></thead><tbody>
        ${a.lignes.map(l => `<tr><td><b>${esc(l.article)}</b></td><td>${nombre(l.quantite)} ${esc(l.unite)}${l.contenance > 1 ? ` <small>(${nombre(l.quantite_base)} ${esc(l.unite_base)})</small>` : ""}</td>
          <td>${l.date_limite ? formatDate(l.date_limite) : "—"}</td>
          ${o.voit_achats ? `<td>${peutPrix ? `<input class="prix-ligne" data-ligne="${l.id}" data-quantite="${l.quantite}" inputmode="numeric" value="${l.prix_unitaire != null ? formatNombre(l.prix_unitaire) : ""}" placeholder="prix d'un ${esc(l.unite)}">` : formatMontant(l.prix_unitaire || 0)}</td>
            <td class="total-ligne">${l.prix_unitaire != null ? formatMontant(l.prix_unitaire * l.quantite) : "—"}</td>` : ""}</tr>`).join("")}
      </tbody></table></div>
      ${peutPrix ? `<div class="total-arrivage" id="totalPrixArrivage"></div>
        <div class="fgrid">
          <div class="field"><label for="ppReference">N° de facture (facultatif)</label><input id="ppReference" maxlength="60" value="${esc(a.reference_facture)}"></div>
          <div class="field"><label for="ppPaye">Payé maintenant (F CFA, facultatif)</label><input id="ppPaye" inputmode="numeric"></div>
          <div class="field"><label for="ppMode">Mode de paiement</label><select id="ppMode"></select></div>
          <div class="field"><label for="ppCompte">Payé depuis</label><select id="ppCompte"></select></div>
        </div>
        <div class="form-erreur" role="alert"></div>` : ""}
      </form>
      ${o.voit_achats && a.versements && a.versements.length ? `<h4>Paiements au fournisseur</h4><div class="fa-liste">${a.versements.map(v => `
        <div class="fa-ligne"><span>${formatDate(v.date)} — ${esc(v.mode_paiement)}${v.saisi_par ? ` <small>(${esc(v.saisi_par)})</small>` : ""}</span>
          <span><b>${formatMontant(v.montant)}</b> ${ibtn("supprimer", "Supprimer ce paiement", `supprimerVersementFournisseur(${v.id}, ${a.id})`)}</span></div>`).join("")}</div>` : ""}
      ${a.note ? `<h4>Note</h4><p>${esc(a.note)}</p>` : ""}
      <div class="actions">
        ${estAdmin() && !a.annule ? '<button class="btn ghost" data-action="annuler">Annuler l\'arrivage</button>' : ""}
        <button class="btn" data-fermer>Fermer</button>
        ${peutPrix ? `<button class="btn primary" data-action="prix">${a.prix_complets ? "Enregistrer" : "Enregistrer les prix"}</button>` : ""}
      </div>
    </div>`, { taille: "large" });

  if (peutPrix) {
    remplirSelect(fen.querySelector("#ppMode"), ["Espèce", "Mobile Money", "Virement", "Chèque", "Autre"]);
    await preparerChoixCompte("ppMode", "ppCompte");
    const majTotal = () => {
      let total = 0, complet = true;
      fen.querySelectorAll(".prix-ligne").forEach(champ => {
        const prix = lireMontant(champ.value);
        const td = champ.closest("tr").querySelector(".total-ligne");
        if (prix === null) { complet = false; td.textContent = "—"; return; }
        total += prix * Number(champ.dataset.quantite);
        td.textContent = formatMontant(prix * Number(champ.dataset.quantite));
      });
      const reste = total - (a.paye || 0);
      fen.querySelector("#totalPrixArrivage").innerHTML = complet
        ? `Total de la facture : <b>${formatMontant(total)}</b>${a.paye ? ` · déjà payé ${formatMontant(a.paye)} · reste <b>${formatMontant(reste)}</b>` : ""}`
        : "Tapez le prix de chaque ligne pour voir le total.";
    };
    fen.querySelectorAll(".prix-ligne").forEach(c => {
      c.addEventListener("input", majTotal);
      c.addEventListener("blur", () => { const n = lireMontant(c.value); if (n !== null) c.value = formatNombre(n); });
    });
    majTotal();
    fen.querySelector('[data-action="prix"]').addEventListener("click", async () => {
      const zoneErreur = fen.querySelector(".form-erreur");
      zoneErreur.style.display = "none";
      try {
        const prix = {};
        fen.querySelectorAll(".prix-ligne").forEach(champ => {
          const p = lireMontant(champ.value);
          if (p === null) throw new Error("Tapez le prix de chaque ligne (ex : 7 200).");
          prix[champ.dataset.ligne] = p;
        });
        const paye = fen.querySelector("#ppPaye").value.trim() ? lireMontant(fen.querySelector("#ppPaye").value) : null;
        if (fen.querySelector("#ppPaye").value.trim() && !paye) throw new Error("Montant payé invalide.");
        await api(`/api/arrivages/${a.id}/prix`, { method: "POST", body: {
          prix, reference_facture: fen.querySelector("#ppReference").value.trim(),
          paiement: paye ? { montant: paye, mode_paiement: fen.querySelector("#ppMode").value, compte_id: compteChoisi("ppCompte") } : null } });
        toast("Arrivage enregistré");
        fen.fermer();
        rafraichirCommerce();
      } catch (err) {
        zoneErreur.textContent = err.message;
        zoneErreur.style.display = "block";
      }
    });
  }
  fen.querySelector('[data-action="annuler"]')?.addEventListener("click", async () => {
    const motif = await new Promise(resolve => {
      const f = ouvrirFenetre(`<div class="modal-tete"><h3>Annuler l'arrivage ${esc(a.numero)}</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
        <div class="field"><label for="motifAnnulArr">Pourquoi ?</label><input id="motifAnnulArr" maxlength="300" placeholder="ex : saisi deux fois"></div>
        <div class="actions"><button class="btn" data-fermer>Retour</button><button class="btn primary" data-action="ok">Continuer</button></div>`, { taille: "" });
      let choisi = null;
      f.querySelector('[data-action="ok"]').addEventListener("click", () => {
        const v = f.querySelector("#motifAnnulArr").value.trim();
        if (v.length < 3) { toast("Indiquez le motif de l'annulation."); return; }
        choisi = v;
        f.fermer();
      });
      f.addEventListener("fermee", () => resolve(choisi));
      f.querySelector("#motifAnnulArr").focus();
    });
    if (!motif) return;
    const mdp = await demanderMotDePasseAdmin(`Annuler l'arrivage ${a.numero} ? Le stock sera diminué d'autant. Entrez votre mot de passe Admin.`,
                                              { titre: "Confirmer l'annulation", bouton: "Annuler l'arrivage" });
    if (!mdp) return;
    try {
      await api(`/api/arrivages/${a.id}/annuler`, { method: "POST", body: { mot_de_passe_admin: mdp, motif: motif.trim() } });
      toast("Arrivage annulé");
      fen.fermer();
      rafraichirCommerce();
    } catch (err) { toast(err.message, 7000); }
  });
}

function rafraichirCommerce() {
  if (el("stock").classList.contains("active")) montrerOngletStock(ongletStock);
}

function supprimerVersementFournisseur(id, arrivageId) {
  supprimerAvecConfirmation("Supprimer ce paiement au fournisseur ? La somme redeviendra due. Entrez votre mot de passe pour confirmer.",
    `/api/versements-fournisseurs/${id}/supprimer`, async () => {
      document.querySelectorAll(".modal-overlay").forEach(f => f.fermer ? f.fermer() : f.remove());
      rafraichirCommerce();
      ouvrirArrivage(arrivageId);
    });
}

// ---------- Nouvel arrivage ----------

function ligneArrivage() {
  const div = document.createElement("div");
  div.className = "ligne-arrivage";
  const voitPrix = optionsCommerce.voit_achats;
  div.innerHTML = `
    <div class="field la-article"><label>Article</label><select class="laArticle"></select></div>
    <div class="field"><label>Arrivé par</label><select class="laUnite"></select></div>
    <div class="field"><label>Quantité</label><input class="laQuantite" inputmode="decimal" placeholder="ex : 10"></div>
    <div class="field la-date" style="display:none"><label>Date limite</label><input class="laDate" type="date"></div>
    ${voitPrix ? '<div class="field"><label class="laLblPrix">Prix d\'un lot (F)</label><input class="laPrix" inputmode="numeric" placeholder="facultatif"></div>' : ""}
    <div class="field la-retirer"><button type="button" class="ibtn del" data-tip="Retirer cette ligne" aria-label="Retirer">✕</button></div>`;
  initialiserChampsDate(div);  // champ jj/mm/aaaa + calendrier, comme partout dans Gérimo
  const choixArticle = div.querySelector(".laArticle");
  remplirSelect(choixArticle, articlesCache.filter(a => a.actif), { valeur: a => a.id, texte: a => a.nom, vide: "— Choisir l'article —" });
  const majUnites = () => {
    const a = articlesCache.find(x => String(x.id) === choixArticle.value);
    remplirSelect(div.querySelector(".laUnite"), a ? [{ id: "", nom: a.unite_base }, ...a.unites.map(u => ({ id: u.id, nom: `${u.nom} (${nombre(u.contenance)} ${a.unite_base})` }))] : [],
      { valeur: u => u.id, texte: u => u.nom });
    div.querySelector(".la-date").style.display = a && a.suit_peremption ? "" : "none";
    majTotalArrivage();
  };
  choixArticle.addEventListener("change", majUnites);
  div.querySelectorAll("input, select").forEach(c => c.addEventListener("input", majTotalArrivage));
  div.querySelector(".la-retirer button").addEventListener("click", () => { div.remove(); majTotalArrivage(); });
  majUnites();
  return div;
}
function ajouterLigneArrivage() { el("arrLignes").appendChild(ligneArrivage()); }

function majTotalArrivage() {
  if (!optionsCommerce || !optionsCommerce.voit_achats) return;
  let total = 0, complet = true, lignes = 0;
  el("arrLignes").querySelectorAll(".ligne-arrivage").forEach(l => {
    const q = lireQuantite(l.querySelector(".laQuantite").value), p = lireMontant(l.querySelector(".laPrix").value);
    if (!l.querySelector(".laArticle").value) return;
    lignes++;
    if (q === null || p === null) { complet = false; return; }
    total += q * p;
  });
  el("arrTotal").innerHTML = lignes && complet ? `Total de la facture : <b>${formatMontant(total)}</b>`
    : lignes ? "Sans tous les prix, l'arrivage sera « prix à compléter » (vous pourrez les ajouter plus tard)." : "";
}

async function nouvelArrivage() {
  try {
    await chargerOptionsCommerce();
    if (!articlesCache.length) articlesCache = await api("/api/articles");
  } catch (e) { toast(e.message); return; }
  if (!articlesCache.some(a => a.actif)) { toast("Créez d'abord vos articles (onglet Articles)."); return; }
  const o = optionsCommerce;
  el("arrAide").textContent = o.voit_achats
    ? "Le stock augmente dès l'enregistrement. Les prix sont facultatifs : sans eux, l'arrivage reste « prix à compléter »."
    : "Comptez ce qui est arrivé : le stock augmente dès l'enregistrement. La Caisse ou l'Admin mettra les prix de la facture.";
  remplirSelect(el("arrFournisseur"), o.fournisseurs, { valeur: f => f.id, texte: f => f.nom, vide: "— Sans fournisseur —" });
  fixerDate("arrDate", aujourdhui());
  el("arrReference").value = "";
  el("arrNote").value = "";
  el("arrLignes").innerHTML = "";
  ajouterLigneArrivage();
  document.querySelectorAll("#formulaireArrivage .champ-achat").forEach(x => { x.style.display = o.voit_achats ? "" : "none"; });
  if (o.voit_achats) {
    remplirSelect(el("arrMode"), ["Espèce", "Mobile Money", "Virement", "Chèque", "Autre"]);
    el("arrPaye").value = "";
    await preparerChoixCompte("arrMode", "arrCompte");
  }
  majTotalArrivage();
  erreurFormulaire(el("formulaireArrivage"), "");
  afficher("formArrivage");
}

el("formulaireArrivage").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    const dateArrivage = valeurDate("arrDate", "Date d'arrivée");
    if (!dateArrivage) throw new Error("Indiquez la date d'arrivée (jj/mm/aaaa).");
    const voitPrix = optionsCommerce.voit_achats;
    const lignes = [...el("arrLignes").querySelectorAll(".ligne-arrivage")].filter(l => l.querySelector(".laArticle").value).map(l => {
      const a = articlesCache.find(x => String(x.id) === l.querySelector(".laArticle").value);
      const quantite = lireQuantite(l.querySelector(".laQuantite").value);
      if (!quantite) throw new Error(`« ${a.nom} » : indiquez la quantité arrivée.`);
      const texteDate = a.suit_peremption ? l.querySelector('.la-date input[type="text"]').value.trim() : "";
      const date_limite = texteDate ? isoDepuisTexte(texteDate) : null;
      if (a.suit_peremption && !date_limite) throw new Error(`« ${a.nom} » se périme : indiquez sa date limite (jj/mm/aaaa).`);
      const champPrix = voitPrix ? l.querySelector(".laPrix").value.trim() : "";
      const prix = champPrix ? lireMontant(champPrix) : null;
      if (champPrix && prix === null) throw new Error(`« ${a.nom} » : prix invalide.`);
      return { article_id: a.id, unite_id: l.querySelector(".laUnite").value ? Number(l.querySelector(".laUnite").value) : null,
               quantite, date_limite, prix_unitaire: prix };
    });
    if (!lignes.length) throw new Error("Ajoutez au moins un article.");
    let paiement = null;
    if (voitPrix && el("arrPaye").value.trim()) {
      const montant = lireMontant(el("arrPaye").value);
      if (!montant) throw new Error("Montant payé invalide.");
      if (lignes.some(l => l.prix_unitaire === null)) throw new Error("Pour noter un paiement, tapez d'abord tous les prix.");
      paiement = { montant, mode_paiement: el("arrMode").value, compte_id: compteChoisi("arrCompte") };
    }
    const r = await api("/api/arrivages", { method: "POST", body: {
      fournisseur_id: el("arrFournisseur").value ? Number(el("arrFournisseur").value) : null, date_arrivage: dateArrivage,
      reference_facture: el("arrReference").value.trim() || null, note: el("arrNote").value.trim() || null, lignes, paiement } });
    toast(`Arrivage ${r.numero} enregistré : le stock est à jour`, 5000);
    ongletStock = "stArrivages";
    goBack();
  });
});

// ---------- Ce que je dois aux fournisseurs ----------

async function chargerDettes() {
  const zone = el("listeDettes");
  let d;
  try { d = await api("/api/fournisseurs/a-payer"); } catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  zone.innerHTML = `
    <div class="resume-stock">
      <div class="chiffre-cle ${d.total ? "alerte" : "calme"} statique"><span class="cc-chiffre">${formatMontant(d.total)}</span>
        <span class="cc-libelle">Je dois à mes fournisseurs</span><span class="cc-aide">${d.fournisseurs.length} fournisseur${d.fournisseurs.length > 1 ? "s" : ""}</span></div>
      ${d.prix_a_completer ? `<button class="chiffre-cle alerte-orange" onclick="montrerOngletStock('stArrivages')"><span class="cc-chiffre">${d.prix_a_completer}</span>
        <span class="cc-libelle">Arrivage${d.prix_a_completer > 1 ? "s" : ""} sans prix</span><span class="cc-aide">à compléter (pas encore compté ici)</span></button>` : ""}
    </div>
    ${d.fournisseurs.length ? d.fournisseurs.map(f => `<div class="card dette-fournisseur"><div class="df-tete"><h3>${esc(f.fournisseur)}</h3><b>${formatMontant(f.total)}</b></div>
      ${f.arrivages.map(a => `<button class="fa-ligne cliquable" onclick="ouvrirPaiementFournisseur(${a.id}, ${a.reste}, '${esc(a.numero)}')">
        <span>Arrivage ${esc(a.numero)} du ${formatDate(a.date)} <small>(total ${formatMontant(a.total)})</small></span>
        <span><b>reste ${formatMontant(a.reste)}</b> <span class="btn-sm">Payer</span></span></button>`).join("")}</div>`).join("")
    : '<div class="card vide">Vous ne devez rien à vos fournisseurs. 👍</div>'}`;
}

async function ouvrirPaiementFournisseur(arrivageId, reste, numero) {
  const fen = ouvrirFenetre(`
    <div class="modal-tete"><h3>Payer le fournisseur — ${esc(numero)}</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <p>Reste à payer : <b>${formatMontant(reste)}</b></p>
    <div class="fgrid">
      <div class="field"><label for="pfMontant">Montant payé (F CFA)</label><input id="pfMontant" inputmode="numeric" value="${formatNombre(reste)}"></div>
      <div class="field"><label for="pfMode">Mode de paiement</label><select id="pfMode"></select></div>
      <div class="field"><label for="pfCompte">Payé depuis</label><select id="pfCompte"></select></div>
      <div class="field"><label for="pfDate">Date</label><input id="pfDate" type="date"></div>
    </div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="payer">Enregistrer le paiement</button></div>`);
  remplirSelect(fen.querySelector("#pfMode"), ["Espèce", "Mobile Money", "Virement", "Chèque", "Autre"]);
  initialiserChampsDate(fen);
  fixerDate("pfDate", aujourdhui());
  await preparerChoixCompte("pfMode", "pfCompte");
  fen.querySelector('[data-action="payer"]').addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const montant = lireMontant(fen.querySelector("#pfMontant").value);
      if (!montant) throw new Error("Montant invalide.");
      await api(`/api/arrivages/${arrivageId}/versements`, { method: "POST", body: {
        montant, mode_paiement: fen.querySelector("#pfMode").value, compte_id: compteChoisi("pfCompte"),
        date_versement: valeurDate("pfDate", "Date") } });
      toast("Paiement enregistré : il apparaît dans la Trésorerie");
      fen.fermer();
      chargerDettes();
    } catch (err) { erreur.textContent = err.message; erreur.style.display = "block"; }
  });
}
