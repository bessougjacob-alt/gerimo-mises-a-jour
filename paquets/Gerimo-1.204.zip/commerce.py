"""Métier Commerce / boutique, partie 1 (13/11/2026) : articles et fournisseurs.

Décisions de Boss (13/11/2026) :
- Prix détail ET prix gros ; plusieurs unités de vente par article, avec leur contenance en unité de base
  (Carton = 24 Bouteilles) : le stock se compte toujours en unité de base.
- Prix d'achat et marge : jamais montrés au Gestionnaire (magasinier), ni renvoyés par le serveur ; quand il modifie
  un article, le prix d'achat enregistré est gardé.
- Articles : créés et modifiés par l'Admin et le Gestionnaire ; la Caisse les consulte (elle vend).
  Fournisseurs : Admin, Gestionnaire et Caisse (la Caisse suit les dettes fournisseurs).
- Suppression : Admin seulement, mot de passe redemandé (corbeille : migration 019).
- Un seul dépôt pour l'instant. Le stock, les entrées et les sorties arrivent dans la partie suivante.
"""
from datetime import date
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from sqlalchemy import func
from sqlalchemy.orm import Session as SessionDB, selectinload

from commun import Formulaire, Suppression, Telephone, Texte, Paragraphe, charger, enregistrer, montant, supprimer
from models import Article, Fournisseur, UniteArticle, Utilisateur
from securite import confirmer_mot_de_passe_admin, exiger_admin, exiger_module, get_db

router = APIRouter(prefix="/api")
acces = exiger_module("stock")

UNITES_COURANTES = ("Pièce", "Bouteille", "Canette", "Paquet", "Sachet", "Boîte", "Carton", "Sac", "Kg", "Litre",
                    "Mètre", "Rouleau", "Douzaine", "Palette", "Bidon", "Tas")
ROLES_ARTICLES = ("Admin", "Gestionnaire")   # créer et modifier les articles


def voit_achats(u: Utilisateur) -> bool:
    """Prix d'achat et marges : pas pour le Gestionnaire (décision du 13/11/2026)."""
    return u.role.value != "Gestionnaire"


def quantite(valeur: Decimal | None) -> int | float:
    return montant(valeur)


# ---------- Fournisseurs ----------

class FournisseurIn(Formulaire):
    nom: Texte = Field(min_length=2, max_length=150)
    telephone: Telephone | None = Field(None, max_length=30)
    contact: Texte | None = Field(None, max_length=150)
    adresse: Texte | None = Field(None, max_length=200)
    note: Paragraphe | None = Field(None, max_length=2000)
    actif: bool = True


def fournisseur_json(f: Fournisseur, nb_articles: int = 0) -> dict:
    return {"id": f.id, "nom": f.nom, "telephone": f.telephone or "", "contact": f.contact or "",
            "adresse": f.adresse or "", "note": f.note or "", "actif": f.actif, "nb_articles": nb_articles}


@router.get("/fournisseurs")
def liste_fournisseurs(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    compte = dict(db.query(Article.fournisseur_id, func.count(Article.id)).group_by(Article.fournisseur_id).all())
    return [fournisseur_json(f, compte.get(f.id, 0))
            for f in db.query(Fournisseur).order_by(Fournisseur.actif.desc(), func.lower(Fournisseur.nom))]


def _appliquer_fournisseur(f: Fournisseur, d: FournisseurIn) -> None:
    f.nom, f.telephone, f.contact = d.nom, d.telephone or None, d.contact or None
    f.adresse, f.note, f.actif = d.adresse or None, d.note or None, d.actif


@router.post("/fournisseurs")
def creer_fournisseur(d: FournisseurIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    f = Fournisseur()
    _appliquer_fournisseur(f, d)
    db.add(f)
    enregistrer(db, f"Un fournisseur « {d.nom} » existe déjà.")
    return {"id": f.id}


@router.put("/fournisseurs/{fournisseur_id}")
def modifier_fournisseur(fournisseur_id: int, d: FournisseurIn, u: Utilisateur = Depends(acces),
                         db: SessionDB = Depends(get_db)):
    f = charger(db, Fournisseur, fournisseur_id, "Fournisseur introuvable.")
    _appliquer_fournisseur(f, d)
    enregistrer(db, f"Un fournisseur « {d.nom} » existe déjà.")
    return {"id": f.id}


@router.post("/fournisseurs/{fournisseur_id}/supprimer")
def supprimer_fournisseur(fournisseur_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin),
                          db: SessionDB = Depends(get_db)):
    acces(admin)  # métier Commerce ouvert par la licence
    confirmer_mot_de_passe_admin(admin, d.mot_de_passe_admin)
    f = charger(db, Fournisseur, fournisseur_id, "Fournisseur introuvable.")
    return supprimer(db, f, "Ce fournisseur est encore utilisé : rendez-le plutôt inactif.")


# ---------- Articles ----------

class UniteIn(Formulaire):
    nom: Texte = Field(min_length=1, max_length=30)
    contenance: Decimal = Field(gt=0, max_digits=12, decimal_places=3)
    prix_detail: Decimal = Field(Decimal(0), ge=0, max_digits=12, decimal_places=2)
    prix_gros: Decimal = Field(Decimal(0), ge=0, max_digits=12, decimal_places=2)
    code_barres: Texte | None = Field(None, max_length=40)


class ArticleIn(Formulaire):
    nom: Texte = Field(min_length=2, max_length=150)
    categorie: Texte | None = Field(None, max_length=80)
    code_barres: Texte | None = Field(None, max_length=40)
    unite_base: Texte = Field("Pièce", min_length=1, max_length=30)
    prix_detail: Decimal = Field(Decimal(0), ge=0, max_digits=12, decimal_places=2)
    prix_gros: Decimal = Field(Decimal(0), ge=0, max_digits=12, decimal_places=2)
    prix_achat: Decimal | None = Field(None, ge=0, max_digits=12, decimal_places=2)  # ignoré pour le Gestionnaire
    seuil_alerte: Decimal = Field(Decimal(0), ge=0, max_digits=12, decimal_places=3)
    suit_peremption: bool = False
    fournisseur_id: int | None = None
    actif: bool = True
    unites: list[UniteIn] = Field(default_factory=list, max_length=10)


def _marge(prix_vente: Decimal, prix_achat: Decimal) -> dict:
    """Marge par unité vendue : en francs et en % du prix de vente."""
    if not prix_achat or not prix_vente:
        return {"montant": None, "pourcentage": None}
    m = prix_vente - prix_achat
    return {"montant": montant(m), "pourcentage": round(float(m / prix_vente * 100), 1)}


def article_json(a: Article, u: Utilisateur, stock: Decimal | None = None) -> dict:
    import arrivages  # (arrivages importe ce module)
    achats = voit_achats(u)
    unites = []
    for x in a.unites:
        ligne = {"id": x.id, "nom": x.nom, "contenance": quantite(x.contenance), "prix_detail": montant(x.prix_detail),
                 "prix_gros": montant(x.prix_gros), "code_barres": x.code_barres or ""}
        if achats:
            achat = a.prix_achat * x.contenance
            ligne.update(prix_achat=montant(achat), marge_detail=_marge(x.prix_detail, achat),
                         marge_gros=_marge(x.prix_gros, achat))
        unites.append(ligne)
    r = {"id": a.id, "nom": a.nom, "categorie": a.categorie or "", "code_barres": a.code_barres or "",
         "unite_base": a.unite_base, "prix_detail": montant(a.prix_detail), "prix_gros": montant(a.prix_gros),
         "seuil_alerte": quantite(a.seuil_alerte), "suit_peremption": a.suit_peremption,
         "fournisseur_id": a.fournisseur_id, "fournisseur": a.fournisseur.nom if a.fournisseur else "",
         "actif": a.actif, "unites": unites}
    if stock is not None:
        r.update(stock=quantite(stock), stock_texte=arrivages.resume_stock(a, stock),
                 stock_bas=bool(a.actif and stock <= a.seuil_alerte and (a.seuil_alerte > 0 or stock <= 0)))
    if achats:
        r.update(prix_achat=montant(a.prix_achat), marge_detail=_marge(a.prix_detail, a.prix_achat),
                 marge_gros=_marge(a.prix_gros, a.prix_achat))
    return r


@router.get("/commerce/options")
def options(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    categories = [c for (c,) in db.query(Article.categorie).filter(Article.categorie.isnot(None))
                  .distinct().order_by(Article.categorie)]
    unites = sorted({*UNITES_COURANTES, *(n for (n,) in db.query(Article.unite_base).distinct()),
                     *(n for (n,) in db.query(UniteArticle.nom).distinct())}, key=str.lower)
    return {"categories": categories, "unites": unites, "voit_achats": voit_achats(u),
            "modifie_articles": u.role.value in ROLES_ARTICLES, "supprime": u.role.value == "Admin",
            "fournisseurs": [{"id": f.id, "nom": f.nom} for f in
                             db.query(Fournisseur).filter(Fournisseur.actif).order_by(func.lower(Fournisseur.nom))]}


@router.get("/articles")
def liste_articles(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    import arrivages
    articles = (db.query(Article).options(selectinload(Article.unites), selectinload(Article.fournisseur))
                .order_by(Article.actif.desc(), func.lower(Article.nom)))
    stock, limites = arrivages.stocks(db), arrivages.dates_limites(db)
    resultat = []
    for a in articles:
        r = article_json(a, u, stock.get(a.id, Decimal(0)))
        limite = limites.get(a.id)
        r["date_limite"] = limite.isoformat() if limite else None
        r["date_limite_proche"] = bool(limite and (limite - date.today()).days <= arrivages.JOURS_DATE_LIMITE)
        if voit_achats(u):
            r["valeur_stock"] = montant((max(stock.get(a.id, Decimal(0)), Decimal(0)) * a.prix_achat).quantize(Decimal("1")))
        resultat.append(r)
    return resultat


@router.get("/articles/code/{code}")
def article_par_code(code: str, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    """Douchette ou caméra : l'article (et l'unité) qui porte ce code-barres."""
    code = code.strip()
    a = db.query(Article).filter(Article.code_barres == code).first()
    unite = None
    if a is None:
        unite = db.query(UniteArticle).filter(UniteArticle.code_barres == code).first()
        a = unite.article if unite else None
    if a is None:
        raise HTTPException(status_code=404, detail=f"Aucun article avec le code-barres {code}.")
    import arrivages
    return {"article": article_json(a, u, arrivages.stock_de(db, a.id)), "unite_id": unite.id if unite else None}


def _verifier_codes(db: SessionDB, d: ArticleIn, article_id: int | None) -> None:
    """Un code-barres ne désigne qu'une seule chose (article ou unité), dans tout le magasin."""
    codes = [c for c in [d.code_barres, *(x.code_barres for x in d.unites)] if c]
    if len(codes) != len(set(codes)):
        raise HTTPException(status_code=400, detail="Le même code-barres est donné deux fois.")
    for c in codes:
        autre = db.query(Article).filter(Article.code_barres == c, Article.id != (article_id or 0)).first()
        unite = db.query(UniteArticle).filter(UniteArticle.code_barres == c,
                                              UniteArticle.article_id != (article_id or 0)).first()
        if autre or unite:
            nom = autre.nom if autre else unite.article.nom
            raise HTTPException(status_code=409, detail=f"Le code-barres {c} est déjà celui de « {nom} ».")


def _appliquer_article(db: SessionDB, u: Utilisateur, a: Article, d: ArticleIn) -> None:
    if u.role.value not in ROLES_ARTICLES:
        raise HTTPException(status_code=403, detail="Les articles sont créés et modifiés par l'Admin ou le Gestionnaire.")
    noms = [x.nom.lower() for x in d.unites]
    if d.unite_base.lower() in noms or len(noms) != len(set(noms)):
        raise HTTPException(status_code=400, detail="Chaque lot doit avoir un nom différent (et différent de la plus petite unité vendue).")
    if any(x.contenance == 1 for x in d.unites):
        raise HTTPException(status_code=400, detail=f"Un lot doit contenir plus d'un(e) {d.unite_base} (ex : Carton de 24).")
    if d.fournisseur_id is not None:
        charger(db, Fournisseur, d.fournisseur_id, "Fournisseur introuvable.")
    _verifier_codes(db, d, a.id)
    a.nom, a.categorie, a.code_barres = d.nom, d.categorie or None, d.code_barres or None
    a.unite_base, a.prix_detail, a.prix_gros = d.unite_base, d.prix_detail, d.prix_gros
    if voit_achats(u) and d.prix_achat is not None:   # le Gestionnaire ne voit pas le prix d'achat : on le garde
        a.prix_achat = d.prix_achat
    a.seuil_alerte, a.suit_peremption = d.seuil_alerte, d.suit_peremption
    a.fournisseur_id, a.actif = d.fournisseur_id, d.actif
    # unités : on garde les lignes existantes (même nom) pour ne pas casser les ventes qui les citeront
    existantes = {x.nom.lower(): x for x in a.unites}
    gardees = []
    for x in d.unites:
        ligne = existantes.get(x.nom.lower()) or UniteArticle()
        ligne.nom, ligne.contenance, ligne.prix_detail = x.nom, x.contenance, x.prix_detail
        ligne.prix_gros, ligne.code_barres = x.prix_gros, x.code_barres or None
        gardees.append(ligne)
    a.unites = gardees


@router.post("/articles")
def creer_article(d: ArticleIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    a = Article()
    _appliquer_article(db, u, a, d)
    db.add(a)
    enregistrer(db, f"Un article « {d.nom} » existe déjà.")
    return {"id": a.id}


@router.put("/articles/{article_id}")
def modifier_article(article_id: int, d: ArticleIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    a = charger(db, Article, article_id, "Article introuvable.")
    _appliquer_article(db, u, a, d)
    enregistrer(db, f"Un article « {d.nom} » existe déjà.")
    return {"id": a.id}


@router.post("/articles/{article_id}/supprimer")
def supprimer_article(article_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin),
                      db: SessionDB = Depends(get_db)):
    acces(admin)  # métier Commerce ouvert par la licence
    confirmer_mot_de_passe_admin(admin, d.mot_de_passe_admin)
    a = charger(db, Article, article_id, "Article introuvable.")
    return supprimer(db, a, "Cet article a déjà des mouvements de stock : rendez-le plutôt inactif.")
