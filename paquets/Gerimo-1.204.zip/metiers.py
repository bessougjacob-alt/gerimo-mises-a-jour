"""Métiers de Gérimo Pro : un seul logiciel, des modules métier ouverts par la licence (13/11/2026, demande de Boss).

- Le SOCLE sert à toutes les entreprises : accueil, dépenses, trésorerie, comptabilité, agenda, réseaux sociaux,
  paramètres, utilisateurs (et tout ce qui n'est pas un écran : WhatsApp de base, sauvegardes, mises à jour…).
- Chaque MÉTIER ajoute ses écrans. L'immobilier est le premier ; le commerce arrive.
- La liste des métiers d'un client est écrite dans sa clé de licence (champ « metiers »), signée par l'éditeur :
  le client ne peut pas l'élargir lui-même. Le serveur refuse (403) les écrans d'un métier fermé.
- Une clé sans ce champ (toutes les clés d'avant le 13/11/2026) = immobilier : les clients actuels ne voient rien changer.
- Pas de clé (essai de 30 jours) : tous les métiers, pour que le client puisse tout essayer.
- Dossier de développement (licence non contrôlée) : tous les métiers, ou ceux de la variable GERIMO_METIERS
  (ex. « commerce » ou « immobilier,commerce ») pour essayer un client d'un autre métier.
"""
import os
from datetime import datetime, timedelta

METIERS = {
    "immobilier": {
        "libelle": "Immobilier",
        "description": "Propriétaires, biens, locataires, contrats, loyers, courte durée, états des lieux",
        "modules": {"biens", "proprietaires", "locataires", "contrats", "paiements", "achats_ventes", "rapports",
                    "etats_des_lieux", "courriers", "sejours"},
    },
    "commerce": {
        "libelle": "Commerce / boutique",
        "description": "Articles et stock, ventes au comptoir, clients, fournisseurs, factures",
        "modules": {"stock"},  # articles, fournisseurs, stock (ventes : étape 4)
    },
}
PAR_DEFAUT = ("immobilier",)  # clé faite avant l'arrivée des métiers
MODULES_METIER = set().union(*(m["modules"] for m in METIERS.values()))

_cache = {"quand": datetime.min, "metiers": None}


def normaliser(liste) -> tuple[str, ...]:
    """Métiers connus seulement, dans l'ordre de METIERS, sans doublon."""
    voulus = {str(m).strip().lower() for m in (liste or [])}
    return tuple(m for m in METIERS if m in voulus)


def metiers_de_la_cle(contenu: dict | None) -> tuple[str, ...]:
    """Métiers ouverts par le contenu d'une clé (None = pas de clé → tous)."""
    if contenu is None:
        return tuple(METIERS)
    if "metiers" not in contenu:
        return PAR_DEFAUT
    return normaliser(contenu["metiers"])


def _calculer() -> tuple[str, ...]:
    import licence
    if not licence.ACTIVE:
        voulus = os.getenv("GERIMO_METIERS", "").replace(";", ",").split(",")
        return normaliser(voulus) if any(v.strip() for v in voulus) else tuple(METIERS)
    from database import SessionLocal
    try:
        with SessionLocal() as db:
            cle = licence._lire(db, licence.CLE_PARAM)
    except Exception:  # noqa: BLE001 — base pas prête : on ne bloque rien
        return tuple(METIERS)
    if not cle:
        return tuple(METIERS)
    try:
        return metiers_de_la_cle(licence.lire_cle(cle))
    except ValueError:  # clé abîmée : la licence passe en lecture seule, les écrans restent visibles
        return PAR_DEFAUT


def actifs() -> tuple[str, ...]:
    """Métiers ouverts sur ce serveur (relus chaque minute, ou tout de suite après une nouvelle clé)."""
    if _cache["metiers"] is None or datetime.now() - _cache["quand"] > timedelta(minutes=1):
        _cache["metiers"] = _calculer()
        _cache["quand"] = datetime.now()
    return _cache["metiers"]


def oublier_cache() -> None:
    _cache["metiers"] = None


def module_ouvert(module: str) -> bool:
    """Un module du socle est toujours ouvert ; un module métier, seulement si son métier l'est."""
    if module not in MODULES_METIER:
        return True
    return any(module in METIERS[m]["modules"] for m in actifs())


def resume() -> list[dict]:
    """Pour Paramètres → À propos : les métiers ouverts, avec leur nom."""
    return [{"id": m, "libelle": METIERS[m]["libelle"], "description": METIERS[m]["description"]} for m in actifs()]
