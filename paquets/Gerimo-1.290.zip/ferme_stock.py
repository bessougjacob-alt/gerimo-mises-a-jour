"""Ferme, étape 2 (22/11/2026) : aliments et produits — stock, achats, fournisseurs, ce que je dois.

Décisions de Boss (22/11/2026) — voir migrations/048_ferme_produits.sql :
- Stock des aliments, vaccins, médicaments et vitamines, matériel et litière. Stock = somme des mouvements
  (+ achat, − utilisation, − perte, ± correction).
- L'aliment noté dans le suivi du jour sort tout seul du stock (ferme.py appelle sortir_aliment_du_suivi).
- L'aliment se compte en kg et s'achète en sacs (kg_par_sac) ; les autres produits dans leur unité.
- Achats comptant ou à crédit : versements, « Ce que je dois aux fournisseurs » ; trésorerie et comptabilité.
- Rôles : Admin tout ; Gestionnaire (chef de ferme) : produits, achats SANS prix (« prix à compléter »),
  utilisations et pertes, jamais de montant ; Caisse : produits, achats avec prix, paiements ; Comptable : consultation.
  Correction du stock (comptage) et annulation d'un achat : Admin.
"""
from collections import defaultdict
from datetime import date
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from sqlalchemy import func
from sqlalchemy.orm import Session as SessionDB, selectinload

import periode
import tresorerie
from commun import Formulaire, Suppression, Telephone, Texte, charger, enregistrer, montant, numero_suivant
from models import (MODES_PAIEMENT, CompteTresorerie, FermeAchat, FermeBande, FermeFournisseur, FermeLigneAchat,
                    FermeMouvement, FermeProduit, FermeVersement, Utilisateur)
from securite import exiger_admin, exiger_module, get_db, verifier_mot_de_passe

router = APIRouter(prefix="/api/ferme")
acces = exiger_module("ferme")
ZERO = Decimal(0)
CATEGORIES = ("Aliment", "Vaccin", "Médicament", "Matériel")
ECRIT_PRODUITS = ("Admin", "Gestionnaire", "Caisse")
NOTE_ACHATS = ("Admin", "Gestionnaire", "Caisse")
ARGENT = ("Admin", "Caisse")                       # prix, paiements, ce que je dois
VOIT_ARGENT = ("Admin", "Caisse", "Comptable")
SORT_DU_STOCK = ("Admin", "Gestionnaire")          # utilisations et pertes (le chef de ferme)


def _role(u: Utilisateur) -> str:
    return u.role.value


def _exiger(u: Utilisateur, roles: tuple, message: str) -> None:
    if _role(u) not in roles:
        raise HTTPException(status_code=403, detail=message)


def _q(v) -> float | int:
    return montant(Decimal(v))


# ---------- Stock ----------

def stocks(db: SessionDB) -> dict[int, Decimal]:
    return {pid: q for pid, q in db.query(FermeMouvement.produit_id, func.sum(FermeMouvement.quantite))
            .group_by(FermeMouvement.produit_id)}


def stock_de(db: SessionDB, produit_id: int) -> Decimal:
    return db.query(func.coalesce(func.sum(FermeMouvement.quantite), 0)).filter(FermeMouvement.produit_id == produit_id).scalar()


def couts_moyens(db: SessionDB) -> dict[int, Decimal]:
    """Prix moyen d'une unité de chaque produit (achats aux prix connus, non annulés)."""
    lignes = (db.query(FermeLigneAchat.produit_id, func.sum(FermeLigneAchat.prix), func.sum(FermeLigneAchat.quantite))
              .join(FermeAchat).filter(FermeAchat.annule.is_(False), FermeLigneAchat.prix.isnot(None))
              .group_by(FermeLigneAchat.produit_id))
    return {pid: (prix / qte) for pid, prix, qte in lignes if qte}


def texte_quantite(p: FermeProduit, q: Decimal) -> str:
    """« 1 250 kg » ; pour un aliment vendu en sacs : « 1 250 kg (25 sacs) »."""
    nombre = lambda v: f"{Decimal(v).normalize():,f}".replace(",", " ").replace(".", ",")  # noqa: E731
    texte = f"{nombre(q)} {p.unite}"
    if p.kg_par_sac and p.unite == "kg" and q:
        sacs = (Decimal(q) / p.kg_par_sac).quantize(Decimal("0.1"))
        texte += f" ({nombre(sacs)} sac{'s' if abs(sacs) > 1 else ''})"
    return texte


def produit_json(p: FermeProduit, stock: Decimal, u: Utilisateur, cout: Decimal | None = None, jamais: bool = False) -> dict:
    """jamais : aucun mouvement (produit pas encore acheté) — ce n'est pas une alerte."""
    etat = "jamais" if jamais else "vide" if stock <= 0 else "bas" if p.seuil_alerte and stock <= p.seuil_alerte else "ok"
    d = {"id": p.id, "nom": p.nom, "categorie": p.categorie, "unite": p.unite,
         "kg_par_sac": _q(p.kg_par_sac) if p.kg_par_sac else None, "seuil_alerte": _q(p.seuil_alerte),
         "note": p.note or "", "actif": p.actif, "stock": _q(stock), "stock_texte": texte_quantite(p, stock),
         "etat": etat if p.actif else "retire"}
    if _role(u) in VOIT_ARGENT:
        d["cout_unitaire"] = round(float(cout)) if cout else None
        d["valeur_stock"] = round(float(cout * stock)) if cout and stock > 0 else 0
    return d


def comptes_actifs(db: SessionDB) -> list[dict]:
    return [{"id": c.id, "nom": c.nom, "type": c.type_compte}
            for c in db.query(CompteTresorerie).filter(CompteTresorerie.actif).order_by(CompteTresorerie.nom)]


@router.get("/stock")
def liste_stock(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    st, couts = stocks(db), couts_moyens(db)
    produits = db.query(FermeProduit).order_by(FermeProduit.categorie, FermeProduit.nom).all()
    argent = _role(u) in ARGENT
    return {
        "produits": [produit_json(p, st.get(p.id, ZERO), u, couts.get(p.id), p.id not in st) for p in produits],
        "fournisseurs": [{"id": f.id, "nom": f.nom, "telephone": f.telephone or "", "note": f.note or "", "actif": f.actif}
                         for f in db.query(FermeFournisseur).order_by(FermeFournisseur.nom)],
        "categories": CATEGORIES, "modes": MODES_PAIEMENT, "comptes": comptes_actifs(db) if argent else [],
        "ecrit_produits": _role(u) in ECRIT_PRODUITS, "note_achats": _role(u) in NOTE_ACHATS,
        "argent": argent, "voit_argent": _role(u) in VOIT_ARGENT, "sort_du_stock": _role(u) in SORT_DU_STOCK,
        "est_admin": _role(u) == "Admin",
    }


# ---------- Produits ----------

class ProduitIn(Formulaire):
    nom: Texte = Field(min_length=2, max_length=80)
    categorie: Literal[CATEGORIES]
    unite: Texte = Field("kg", min_length=1, max_length=20)
    kg_par_sac: Decimal | None = Field(None, gt=0, max_digits=8, decimal_places=2)
    seuil_alerte: Decimal = Field(Decimal(0), ge=0, max_digits=12, decimal_places=2)
    note: Texte | None = Field(None, max_length=300)
    actif: bool = True


def _appliquer_produit(p: FermeProduit, d: ProduitIn) -> None:
    p.nom, p.categorie, p.unite = d.nom, d.categorie, ("kg" if d.categorie == "Aliment" else d.unite)
    p.kg_par_sac = d.kg_par_sac if d.categorie == "Aliment" else None
    p.seuil_alerte, p.note, p.actif = d.seuil_alerte, d.note or None, d.actif


@router.post("/produits")
def creer_produit(d: ProduitIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u, ECRIT_PRODUITS, "Le Comptable consulte seulement.")
    p = FermeProduit()
    _appliquer_produit(p, d)
    db.add(p)
    enregistrer(db, f"Un produit « {d.nom} » existe déjà.")
    return {"id": p.id}


@router.put("/produits/{produit_id}")
def modifier_produit(produit_id: int, d: ProduitIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u, ECRIT_PRODUITS, "Le Comptable consulte seulement.")
    p = charger(db, FermeProduit, produit_id, "Produit introuvable.")
    if p.categorie != d.categorie and db.query(FermeMouvement).filter(FermeMouvement.produit_id == p.id).first():
        raise HTTPException(status_code=409, detail="Ce produit a déjà des mouvements : sa sorte ne peut plus changer.")
    _appliquer_produit(p, d)
    enregistrer(db, f"Un produit « {d.nom} » existe déjà.")
    return {"id": p.id}


@router.get("/produits/{produit_id}")
def fiche_produit(produit_id: int, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    p = charger(db, FermeProduit, produit_id, "Produit introuvable.")
    mouvements = (db.query(FermeMouvement).options(selectinload(FermeMouvement.bande), selectinload(FermeMouvement.auteur))
                  .filter(FermeMouvement.produit_id == p.id)
                  .order_by(FermeMouvement.date_mouvement.desc(), FermeMouvement.id.desc()).limit(150).all())
    numeros = {a.id: a.numero for a in db.query(FermeAchat).filter(FermeAchat.id.in_({m.achat_id for m in mouvements if m.achat_id} or {0}))}
    return {**produit_json(p, stock_de(db, p.id), u, couts_moyens(db).get(p.id), not mouvements),
            "mouvements": [{"id": m.id, "date": m.date_mouvement.isoformat(), "genre": m.genre, "quantite": _q(m.quantite),
                            "texte": texte_quantite(p, abs(m.quantite)),
                            "bande": (m.bande.nom or f"{m.bande.type_elevage} ({m.bande.numero})") if m.bande else "",
                            "achat": numeros.get(m.achat_id, ""), "motif": m.motif or "",
                            "suivi": m.suivi_id is not None, "saisi_par": m.auteur.nom_complet if m.auteur else ""}
                           for m in mouvements]}


# ---------- Sorties du stock (utilisation, perte) et correction ----------

class MouvementIn(Formulaire):
    produit_id: int
    genre: Literal["Utilisation", "Perte", "Correction"]
    quantite: Decimal = Field(ge=0, max_digits=12, decimal_places=2)   # sortie ; pour une correction : quantité comptée
    bande_id: int | None = None
    motif: Texte | None = Field(None, max_length=200)
    date_mouvement: date | None = None


@router.post("/mouvements")
def sortir(d: MouvementIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u, SORT_DU_STOCK, "Les sorties du stock sont notées par le chef de ferme (Gestionnaire) ou l'Admin.")
    p = charger(db, FermeProduit, d.produit_id, "Produit introuvable.")
    jour = d.date_mouvement or date.today()
    if jour > date.today():
        raise HTTPException(status_code=400, detail="La date ne peut pas être dans le futur.")
    stock = stock_de(db, p.id)
    if d.genre == "Correction":
        if _role(u) != "Admin":
            raise HTTPException(status_code=403, detail="Seul l'Admin corrige le stock après un comptage.")
        quantite = d.quantite - stock
        if quantite == 0:
            raise HTTPException(status_code=400, detail="Le stock compté est déjà celui de Gérimo : rien à corriger.")
        motif = d.motif or "Comptage du stock"
    else:
        if d.quantite <= 0:
            raise HTTPException(status_code=400, detail="Indiquez la quantité sortie.")
        if d.quantite > stock:
            raise HTTPException(status_code=409, detail=f"Il ne reste que {texte_quantite(p, stock)} de « {p.nom} ».")
        if d.genre == "Perte" and not d.motif:
            raise HTTPException(status_code=400, detail="Dites pourquoi (exemple : sacs mouillés, rats, périmé).")
        quantite, motif = -d.quantite, d.motif
    bande_id = None
    if d.bande_id is not None:
        bande_id = charger(db, FermeBande, d.bande_id, "Lot introuvable.").id
    db.add(FermeMouvement(produit_id=p.id, date_mouvement=jour, genre=d.genre, quantite=quantite, bande_id=bande_id,
                          motif=motif or None, saisi_par=u.id))
    enregistrer(db, "Enregistrement impossible.")
    return {"ok": True, "stock": _q(stock + quantite), "stock_texte": texte_quantite(p, stock + quantite)}


def sortir_aliment_du_suivi(db: SessionDB, suivi, u: Utilisateur) -> None:
    """Suivi du jour : les kg d'aliment donnés sortent du stock de l'aliment choisi (une seule sortie par suivi)."""
    db.flush()
    existant = db.query(FermeMouvement).filter(FermeMouvement.suivi_id == suivi.id).first()
    if not suivi.produit_id or not suivi.aliment_kg:
        if existant:
            db.delete(existant)
        return
    p = db.get(FermeProduit, suivi.produit_id)
    if p is None or p.categorie != "Aliment":
        raise HTTPException(status_code=400, detail="Choisissez un aliment dans la liste.")
    deja = -existant.quantite if existant and existant.produit_id == p.id else ZERO
    disponible = stock_de(db, p.id) + deja
    if suivi.aliment_kg > disponible:
        raise HTTPException(status_code=409, detail=f"« {p.nom} » : il ne reste que {texte_quantite(p, disponible)} en stock. "
                                                    "Notez d'abord l'achat (Ferme → Achats), ou choisissez un autre aliment.")
    if existant is None:
        existant = FermeMouvement(suivi_id=suivi.id, genre="Utilisation", saisi_par=u.id)
        db.add(existant)
    existant.produit_id, existant.quantite = p.id, -suivi.aliment_kg
    existant.date_mouvement, existant.bande_id, existant.motif = suivi.date_suivi, suivi.bande_id, "Suivi du jour"


def aliments(db: SessionDB) -> list[dict]:
    """Aliments proposés dans le suivi du jour, avec leur stock."""
    st = stocks(db)
    return [{"id": p.id, "nom": p.nom, "stock": _q(st.get(p.id, ZERO)), "stock_texte": texte_quantite(p, st.get(p.id, ZERO))}
            for p in db.query(FermeProduit).filter(FermeProduit.categorie == "Aliment", FermeProduit.actif)
            .order_by(FermeProduit.nom)]


# ---------- Fournisseurs ----------

class FournisseurIn(Formulaire):
    nom: Texte = Field(min_length=2, max_length=100)
    telephone: Telephone | None = Field(None, max_length=30)
    note: Texte | None = Field(None, max_length=300)
    actif: bool = True


@router.post("/fournisseurs")
def creer_fournisseur(d: FournisseurIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u, NOTE_ACHATS, "Le Comptable consulte seulement.")
    f = FermeFournisseur(nom=d.nom, telephone=d.telephone or None, note=d.note or None, actif=d.actif)
    db.add(f)
    enregistrer(db, f"Le fournisseur « {d.nom} » existe déjà.")
    return {"id": f.id}


@router.put("/fournisseurs/{fournisseur_id}")
def modifier_fournisseur(fournisseur_id: int, d: FournisseurIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u, NOTE_ACHATS, "Le Comptable consulte seulement.")
    f = charger(db, FermeFournisseur, fournisseur_id, "Fournisseur introuvable.")
    f.nom, f.telephone, f.note, f.actif = d.nom, d.telephone or None, d.note or None, d.actif
    enregistrer(db, f"Le fournisseur « {d.nom} » existe déjà.")
    return {"id": f.id}


# ---------- Achats ----------

def paye(a: FermeAchat) -> Decimal:
    return sum((v.montant for v in a.versements), ZERO)


def achat_json(a: FermeAchat, u: Utilisateur) -> dict:
    argent = _role(u) in VOIT_ARGENT
    reste = (a.montant_total - paye(a)) if a.prix_complets and a.montant_total is not None else None
    if a.annule:
        etat = "annule"
    elif not a.prix_complets:
        etat = "prix"
    elif reste and reste > 0:
        etat = "credit"
    else:
        etat = "paye"
    d = {"id": a.id, "numero": a.numero, "date": a.date_achat.isoformat(), "fournisseur": a.fournisseur.nom if a.fournisseur else "",
         "fournisseur_id": a.fournisseur_id, "reference": a.reference or "", "note": a.note or "", "etat": etat,
         "prix_complets": a.prix_complets, "annule": a.annule, "motif_annulation": a.motif_annulation or "",
         "saisi_par": a.auteur.nom_complet if a.auteur else "",
         "lignes": [{"id": l.id, "produit_id": l.produit_id, "produit": l.produit.nom, "categorie": l.produit.categorie,
                     "quantite": _q(l.quantite), "texte": texte_quantite(l.produit, l.quantite),
                     **({"prix": _q(l.prix) if l.prix is not None else None} if argent else {})} for l in a.lignes]}
    if argent:
        d.update({"total": _q(a.montant_total) if a.montant_total is not None else None, "paye": _q(paye(a)),
                  "reste": _q(reste) if reste is not None else None,
                  "versements": [{"id": v.id, "date": v.date_versement.isoformat(), "montant": _q(v.montant),
                                  "mode": v.mode_paiement, "saisi_par": v.auteur.nom_complet if v.auteur else ""}
                                 for v in a.versements]})
    return d


def _achats(db: SessionDB):
    return db.query(FermeAchat).options(selectinload(FermeAchat.lignes).selectinload(FermeLigneAchat.produit),
                                        selectinload(FermeAchat.versements).selectinload(FermeVersement.auteur),
                                        selectinload(FermeAchat.fournisseur), selectinload(FermeAchat.auteur))


@router.get("/achats")
def liste_achats(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    return [achat_json(a, u) for a in _achats(db).order_by(FermeAchat.date_achat.desc(), FermeAchat.id.desc()).limit(500)]


class LigneAchatIn(Formulaire):
    produit_id: int
    quantite: Decimal = Field(gt=0, max_digits=12, decimal_places=2)    # dans l'unité du produit (kg pour un aliment)
    prix: Decimal | None = Field(None, ge=0, max_digits=14, decimal_places=2)   # prix de toute la ligne


class PaiementIn(Formulaire):
    montant: Decimal = Field(gt=0, max_digits=14, decimal_places=2)
    mode_paiement: Literal[MODES_PAIEMENT] = "Espèce"
    compte_id: int | None = None
    date_versement: date | None = None
    note: Texte | None = Field(None, max_length=200)


class AchatIn(Formulaire):
    fournisseur_id: int | None = None
    date_achat: date
    reference: Texte | None = Field(None, max_length=60)
    note: Texte | None = Field(None, max_length=300)
    lignes: list[LigneAchatIn] = Field(min_length=1, max_length=100)
    paiement: PaiementIn | None = None


class PrixIn(Formulaire):
    prix: dict[int, Decimal]                 # id de ligne → prix de toute la ligne
    paiement: PaiementIn | None = None


def _ajouter_versement(db: SessionDB, u: Utilisateur, a: FermeAchat, p: PaiementIn) -> None:
    jour = p.date_versement or date.today()
    if jour > date.today():
        raise HTTPException(status_code=400, detail="La date du paiement ne peut pas être dans le futur.")
    if jour < a.date_achat:
        raise HTTPException(status_code=400, detail="Le paiement ne peut pas être avant l'achat.")
    periode.verifier_ouverte(db, jour)
    reste = a.montant_total - paye(a)
    if p.montant > reste:
        raise HTTPException(status_code=400, detail=f"Le paiement dépasse ce qui reste à payer ({montant(reste):,} F).".replace(",", " "))
    a.versements.append(FermeVersement(date_versement=jour, montant=p.montant, mode_paiement=p.mode_paiement,
                                       compte_id=tresorerie.verifier_compte_choisi(db, p.compte_id, p.mode_paiement),
                                       note=p.note or None, saisi_par=u.id))


def _fixer_prix(a: FermeAchat, prix_par_ligne: dict, u: Utilisateur) -> None:
    for l in a.lignes:
        v = prix_par_ligne.get(l.id) if l.id is not None else None
        if v is None:
            raise HTTPException(status_code=400, detail=f"Indiquez le prix de « {l.produit.nom} ».")
        l.prix = Decimal(v)
    a.montant_total = sum((l.prix for l in a.lignes), ZERO)
    a.prix_complets, a.prix_par = True, u.id


@router.post("/achats")
def creer_achat(d: AchatIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u, NOTE_ACHATS, "Le Comptable consulte seulement.")
    if d.date_achat > date.today():
        raise HTTPException(status_code=400, detail="La date de l'achat ne peut pas être dans le futur.")
    periode.verifier_ouverte(db, d.date_achat)
    if d.fournisseur_id is not None:
        charger(db, FermeFournisseur, d.fournisseur_id, "Fournisseur introuvable.")
    if len({x.produit_id for x in d.lignes}) != len(d.lignes):
        raise HTTPException(status_code=400, detail="Un produit apparaît deux fois : regroupez les quantités.")
    argent = _role(u) in ARGENT
    a = FermeAchat(numero=numero_suivant(db, FermeAchat.numero, f"AFE-{d.date_achat.year}", 4), date_achat=d.date_achat,
                   fournisseur_id=d.fournisseur_id, reference=d.reference or None, note=d.note or None, saisi_par=u.id)
    for x in d.lignes:
        p = charger(db, FermeProduit, x.produit_id, "Produit introuvable.")
        if not p.actif:
            raise HTTPException(status_code=400, detail=f"« {p.nom} » n'est plus utilisé.")
        a.lignes.append(FermeLigneAchat(produit=p, quantite=x.quantite, prix=x.prix if argent else None))
    if argent:
        if any(x.prix is None for x in d.lignes):
            raise HTTPException(status_code=400, detail="Indiquez le prix de chaque produit.")
        a.montant_total = sum((x.prix for x in d.lignes), ZERO)
        a.prix_complets, a.prix_par = True, u.id
    db.add(a)
    db.flush()
    for l in a.lignes:   # le stock augmente tout de suite (les prix peuvent venir plus tard)
        db.add(FermeMouvement(produit_id=l.produit_id, date_mouvement=a.date_achat, genre="Achat", quantite=l.quantite,
                              achat_id=a.id, saisi_par=u.id))
    if d.paiement is not None and argent:
        _ajouter_versement(db, u, a, d.paiement)
    enregistrer(db, "Enregistrement impossible.")
    db.refresh(a)
    return achat_json(a, u)


@router.post("/achats/{achat_id}/prix")
def completer_prix(achat_id: int, d: PrixIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u, ARGENT, "Les prix sont complétés par la Caisse ou l'Admin.")
    a = charger(db, FermeAchat, achat_id, "Achat introuvable.")
    if a.annule:
        raise HTTPException(status_code=409, detail="Cet achat est annulé.")
    if a.versements:
        raise HTTPException(status_code=409, detail="Cet achat a déjà des paiements : ses prix ne changent plus.")
    periode.verifier_ouverte(db, a.date_achat)
    _fixer_prix(a, {int(k): v for k, v in d.prix.items()}, u)
    if d.paiement is not None:
        _ajouter_versement(db, u, a, d.paiement)
    enregistrer(db, "Enregistrement impossible.")
    return achat_json(a, u)


@router.post("/achats/{achat_id}/versements")
def payer(achat_id: int, d: PaiementIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u, ARGENT, "Les paiements aux fournisseurs sont notés par la Caisse ou l'Admin.")
    a = charger(db, FermeAchat, achat_id, "Achat introuvable.")
    if a.annule:
        raise HTTPException(status_code=409, detail="Cet achat est annulé.")
    if not a.prix_complets:
        raise HTTPException(status_code=409, detail="Complétez d'abord les prix de cet achat.")
    _ajouter_versement(db, u, a, d)
    enregistrer(db, "Enregistrement impossible.")
    return achat_json(a, u)


@router.post("/versements/{versement_id}/supprimer")
def supprimer_versement(versement_id: int, d: Suppression, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u, ARGENT, "Suppression réservée à l'Admin et à la Caisse.")
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", u.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été supprimé.")
    v = charger(db, FermeVersement, versement_id, "Paiement introuvable.")
    periode.verifier_ouverte(db, v.date_versement)
    db.delete(v)
    enregistrer(db, "Suppression impossible.")
    return {"ok": True}


class AnnulationIn(Suppression):
    motif: Texte = Field(min_length=3, max_length=300)


@router.post("/achats/{achat_id}/annuler")
def annuler_achat(achat_id: int, d: AnnulationIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été annulé.")
    a = charger(db, FermeAchat, achat_id, "Achat introuvable.")
    if a.annule:
        raise HTTPException(status_code=409, detail="Cet achat est déjà annulé.")
    if a.versements:
        raise HTTPException(status_code=409, detail="Cet achat a des paiements : supprimez-les d'abord.")
    periode.verifier_ouverte(db, a.date_achat)
    st = stocks(db)
    for l in a.lignes:
        if st.get(l.produit_id, ZERO) < l.quantite:
            raise HTTPException(status_code=409, detail=f"« {l.produit.nom} » de cet achat a déjà été utilisé : "
                                                        "l'achat ne peut plus être annulé.")
    db.query(FermeMouvement).filter(FermeMouvement.achat_id == a.id).delete()
    a.annule, a.motif_annulation = True, d.motif
    enregistrer(db, "Annulation impossible.")
    return {"ok": True}


@router.get("/dettes")
def ce_que_je_dois(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    """« Ce que je dois aux fournisseurs » : par fournisseur, les achats pas encore payés en entier."""
    _exiger(u, VOIT_ARGENT, "Réservé à l'Admin, à la Caisse et au Comptable.")
    par = defaultdict(lambda: {"total": ZERO, "achats": []})
    a_completer = 0
    for a in _achats(db).filter(FermeAchat.annule.is_(False)).order_by(FermeAchat.date_achat):
        if not a.prix_complets:
            a_completer += 1
            continue
        reste = a.montant_total - paye(a)
        if reste > 0:
            f = par[a.fournisseur.nom if a.fournisseur else "Sans fournisseur"]
            f["total"] += reste
            f["achats"].append({"id": a.id, "numero": a.numero, "date": a.date_achat.isoformat(),
                                "total": _q(a.montant_total), "reste": _q(reste)})
    liste = [{"fournisseur": nom, "total": _q(v["total"]), "achats": v["achats"]}
             for nom, v in sorted(par.items(), key=lambda x: -x[1]["total"])]
    return {"total": _q(sum((v["total"] for v in par.values()), ZERO)), "fournisseurs": liste, "prix_a_completer": a_completer}


# ---------- Pour la trésorerie, la comptabilité et le résultat ----------

def versements(db: SessionDB, debut: date | None = None, fin: date | None = None):
    q = db.query(FermeVersement).options(selectinload(FermeVersement.achat).selectinload(FermeAchat.fournisseur))
    if debut is not None:
        q = q.filter(FermeVersement.date_versement >= debut)
    if fin is not None:
        q = q.filter(FermeVersement.date_versement <= fin)
    return q.order_by(FermeVersement.date_versement, FermeVersement.id).all()


def achats_completes(db: SessionDB, debut: date, fin: date):
    return (db.query(FermeAchat).options(selectinload(FermeAchat.fournisseur))
            .filter(FermeAchat.prix_complets.is_(True), FermeAchat.annule.is_(False),
                    FermeAchat.date_achat >= debut, FermeAchat.date_achat <= fin)
            .order_by(FermeAchat.date_achat, FermeAchat.id).all())


# ---------- Alertes (assistant) ----------

def alertes(db: SessionDB, u: Utilisateur) -> list[tuple[str, str, str, str]]:
    resultat = []
    st = stocks(db)
    for p in db.query(FermeProduit).filter(FermeProduit.actif):
        q = st.get(p.id, ZERO)
        if p.seuil_alerte and q <= p.seuil_alerte and (q > 0 or p.id in st):
            resultat.append((f"ferme-stock-{p.id}", "attention", f"{p.nom} : {'plus rien' if q <= 0 else 'presque fini'} en stock",
                             f"Il reste {texte_quantite(p, max(q, ZERO))} : pensez à en racheter (Ferme → Achats)."))
    if _role(u) in ARGENT:
        n = db.query(FermeAchat).filter(FermeAchat.prix_complets.is_(False), FermeAchat.annule.is_(False)).count()
        if n:
            resultat.append(("ferme-achats-prix", "info", f"{n} achat{'s' if n > 1 else ''} de la ferme sans prix",
                             "Le chef de ferme a noté ce qui est arrivé : complétez les prix (Ferme → Achats)."))
    return resultat
