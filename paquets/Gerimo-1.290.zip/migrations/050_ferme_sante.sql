-- ============================================================
-- Migration 050 — Ferme, étape 3 (22/11/2026) : santé, pesées, vétérinaire (ferme_sante.py)
-- Décisions de Boss (22/11/2026) :
-- - Vaccins : un PROGRAMME par type de volaille, écrit une fois par l'Admin (jour d'âge, vaccin, produit) ; pour chaque
--   bande Gérimo prévoit les dates (Agenda, alerte la veille, retard).
-- - Un vaccin ou un traitement fait est NOTÉ ; le produit ne sort du stock que si le flacon (le sachet…) est FINI
--   (case « il reste du produit »). Plus aucun flacon en stock : le vaccin ne peut pas être fait, Gérimo prévient.
-- - Pesées : poids moyen d'un échantillon, comparé au poids attendu pour l'âge (table de référence modifiable).
-- - Visites du vétérinaire : constat, conseils, prix (noté en Dépense de l'entreprise).
-- Le programme d'exemple des poulets de chair et les poids attendus sont INDICATIFS : à faire valider par le vétérinaire.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS ferme_programme (
    id              SERIAL PRIMARY KEY,
    type_elevage    VARCHAR(40) NOT NULL REFERENCES ferme_especes(nom) ON UPDATE CASCADE ON DELETE CASCADE,   -- espèce (migration 049)
    jour_age        INTEGER NOT NULL CHECK (jour_age >= 0 AND jour_age <= 1000),
    nom             VARCHAR(100) NOT NULL,                       -- « Gumboro », « Newcastle (rappel) »…
    produit_id      INTEGER REFERENCES ferme_produits(id) ON DELETE SET NULL,
    mode            VARCHAR(40),                                 -- eau de boisson, goutte dans l'œil, injection…
    note            VARCHAR(300),
    UNIQUE (type_elevage, jour_age, nom)
);
-- Exemple pour les poulets de chair (à adapter avec le vétérinaire)
INSERT INTO ferme_programme (type_elevage, jour_age, nom, mode) VALUES
    ('Poulets de chair', 7, 'Gumboro', 'Eau de boisson'),
    ('Poulets de chair', 10, 'Newcastle', 'Eau de boisson'),
    ('Poulets de chair', 14, 'Gumboro (rappel)', 'Eau de boisson'),
    ('Poulets de chair', 21, 'Newcastle (rappel)', 'Eau de boisson')
ON CONFLICT (type_elevage, jour_age, nom) DO NOTHING;

CREATE TABLE IF NOT EXISTS ferme_soins (
    id              SERIAL PRIMARY KEY,
    bande_id        INTEGER NOT NULL REFERENCES ferme_bandes(id),
    date_soin       DATE NOT NULL,
    genre           VARCHAR(12) NOT NULL CHECK (genre IN ('Vaccin', 'Traitement')),
    nom             VARCHAR(100) NOT NULL,
    programme_id    INTEGER REFERENCES ferme_programme(id) ON DELETE SET NULL,
    produit_id      INTEGER REFERENCES ferme_produits(id),
    mode            VARCHAR(40),
    reste_produit   BOOLEAN NOT NULL DEFAULT TRUE,               -- il reste du produit : rien ne sort du stock
    finis           NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (finis >= 0),   -- flacons / sachets finis (sortis du stock)
    note            VARCHAR(300),
    saisi_par       INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ferme_soins_programme ON ferme_soins (bande_id, programme_id) WHERE programme_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_ferme_soins_bande ON ferme_soins (bande_id, date_soin);

ALTER TABLE ferme_mouvements ADD COLUMN IF NOT EXISTS soin_id INTEGER REFERENCES ferme_soins(id) ON DELETE CASCADE;

CREATE TABLE IF NOT EXISTS ferme_pesees (
    id              SERIAL PRIMARY KEY,
    bande_id        INTEGER NOT NULL REFERENCES ferme_bandes(id),
    date_pesee      DATE NOT NULL,
    nombre          INTEGER NOT NULL CHECK (nombre > 0),          -- volailles pesées
    poids_moyen_g   NUMERIC(8, 1) NOT NULL CHECK (poids_moyen_g > 0),
    note            VARCHAR(300),
    saisi_par       INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT NOW(),
    UNIQUE (bande_id, date_pesee)
);

CREATE TABLE IF NOT EXISTS ferme_poids_reference (
    type_elevage    VARCHAR(40) NOT NULL REFERENCES ferme_especes(nom) ON UPDATE CASCADE ON DELETE CASCADE,
    jour_age        INTEGER NOT NULL CHECK (jour_age >= 0),
    poids_g         NUMERIC(8, 1) NOT NULL CHECK (poids_g > 0),
    PRIMARY KEY (type_elevage, jour_age)
);
-- Poids moyens indicatifs (grammes) ; l'Admin peut les changer
INSERT INTO ferme_poids_reference (type_elevage, jour_age, poids_g) VALUES
    ('Poulets de chair', 0, 42), ('Poulets de chair', 7, 180), ('Poulets de chair', 14, 470), ('Poulets de chair', 21, 930),
    ('Poulets de chair', 28, 1500), ('Poulets de chair', 35, 2100), ('Poulets de chair', 42, 2700), ('Poulets de chair', 49, 3200),
    ('Poules pondeuses', 0, 40), ('Poules pondeuses', 7, 70), ('Poules pondeuses', 14, 120), ('Poules pondeuses', 28, 280),
    ('Poules pondeuses', 42, 480), ('Poules pondeuses', 56, 700), ('Poules pondeuses', 84, 1100), ('Poules pondeuses', 112, 1450),
    ('Poules pondeuses', 140, 1700)
ON CONFLICT (type_elevage, jour_age) DO NOTHING;

CREATE TABLE IF NOT EXISTS ferme_visites (
    id              SERIAL PRIMARY KEY,
    date_visite     DATE NOT NULL,
    veterinaire     VARCHAR(100) NOT NULL,
    telephone       VARCHAR(30),
    bande_id        INTEGER REFERENCES ferme_bandes(id),          -- vide : toute la ferme
    constat         VARCHAR(1000),
    conseils        VARCHAR(1000),
    cout            NUMERIC(12, 2) CHECK (cout IS NULL OR cout >= 0),
    depense_id      INTEGER REFERENCES depenses(id) ON DELETE SET NULL,
    saisi_par       INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT NOW()
);

DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['ferme_programme', 'ferme_soins', 'ferme_pesees', 'ferme_poids_reference', 'ferme_visites']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
