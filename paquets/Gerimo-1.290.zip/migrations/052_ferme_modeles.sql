-- ============================================================
-- Migration 052 — Ferme : modèles de fiche technique par espèce (22/11/2026, demande de Boss)
-- « Gérimo doit faciliter la création de fiche technique en proposant un modèle complet pour chaque type d'élevage. »
-- ferme_especes.modele (JSONB) : races proposées, cases propres à l'espèce (robe, pelage, cornes…) et repères
-- (reproduction, gestation, portée, sevrage, poids adulte, durée d'élevage). Valeurs INDICATIVES, modifiables par l'Admin.
-- ferme_sujets.details (JSONB) : les cases propres à l'espèce remplies pour un animal.
-- Peut être exécutée plusieurs fois sans risque (un modèle déjà modifié n'est pas écrasé)
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE ferme_especes ADD COLUMN IF NOT EXISTS modele JSONB NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE ferme_sujets ADD COLUMN IF NOT EXISTS details JSONB NOT NULL DEFAULT '{}'::jsonb;

UPDATE ferme_especes SET modele = m.modele::jsonb FROM (VALUES
 ('Poulets de chair', '{"races": ["Cobb 500", "Ross 308", "Hubbard", "Arbor Acres"],
   "champs": [{"nom": "Plumage", "choix": ["Blanc", "Roux", "Mélangé"]}],
   "reperes": [["Durée d''élevage", "35 à 45 jours"], ["Poids de vente", "2 à 2,5 kg vers 42 jours"], ["Aliment", "démarrage, croissance, finition"]]}'),
 ('Poules pondeuses', '{"races": ["ISA Brown", "Lohmann Brown", "Hy-Line Brown", "Bovans"],
   "champs": [{"nom": "Plumage", "choix": ["Roux", "Blanc", "Noir"]}],
   "reperes": [["Début de ponte", "18 à 20 semaines"], ["Ponte", "environ 300 œufs par an"], ["Réforme", "vers 72 à 80 semaines"]]}'),
 ('Poulets traditionnels', '{"races": ["Bicyclette (locale)", "Kabir", "Sasso", "Goliath"],
   "champs": [{"nom": "Plumage", "choix": ["Roux", "Noir", "Blanc", "Mélangé", "Cou nu"]}],
   "reperes": [["Durée d''élevage", "3 à 5 mois"], ["Poids de vente", "1,5 à 2,5 kg"]]}'),
 ('Pintades', '{"races": ["Locale", "Galor", "Pintade grise perlée"],
   "champs": [{"nom": "Plumage", "choix": ["Gris perlé", "Blanc", "Lilas"]}],
   "reperes": [["Durée d''élevage", "4 à 5 mois"], ["Poids de vente", "1,2 à 1,8 kg"]]}'),
 ('Canards', '{"races": ["Barbarie", "Pékin", "Mulard", "Local"],
   "champs": [{"nom": "Plumage", "choix": ["Blanc", "Noir et blanc", "Noir"]}],
   "reperes": [["Durée d''élevage", "10 à 12 semaines"], ["Poids de vente", "2,5 à 4 kg"]]}'),
 ('Lapins', '{"races": ["Néo-Zélandais blanc", "Californien", "Fauve de Bourgogne", "Géant des Flandres", "Local", "Croisé"],
   "champs": [{"nom": "Pelage", "choix": ["Blanc", "Fauve", "Gris", "Noir", "Tacheté"]}, {"nom": "Yeux", "choix": ["Rouges", "Marron", "Bleus"]}],
   "reperes": [["Mise à la reproduction", "femelle 4 à 5 mois, mâle 5 à 6 mois"], ["Gestation", "31 jours"], ["Portée", "6 à 10 lapereaux"],
               ["Sevrage", "30 à 35 jours"], ["Poids adulte", "3,5 à 5 kg"], ["Âge de vente", "10 à 12 semaines (2 à 2,5 kg)"]]}'),
 ('Aulacodes', '{"races": ["Lignée d''élevage", "Sauvage domestiqué"],
   "champs": [{"nom": "Pelage", "choix": ["Brun", "Gris-brun"]}],
   "reperes": [["Mise à la reproduction", "7 à 8 mois"], ["Gestation", "environ 152 jours"], ["Portée", "4 à 5 petits"],
               ["Sevrage", "40 jours"], ["Poids adulte", "femelle 3 à 4 kg, mâle 4 à 6 kg"]]}'),
 ('Porcs', '{"races": ["Large White", "Landrace", "Duroc", "Piétrain", "Local", "Croisé"],
   "champs": [{"nom": "Robe", "choix": ["Blanche", "Rousse", "Noire", "Pie (tachetée)"]}],
   "reperes": [["Mise à la reproduction", "truie 7 à 8 mois, verrat 8 mois"], ["Gestation", "114 jours (3 mois, 3 semaines, 3 jours)"],
               ["Portée", "10 à 12 porcelets"], ["Sevrage", "21 à 28 jours"], ["Poids de vente", "90 à 110 kg vers 6 mois"]]}'),
 ('Moutons', '{"races": ["Djallonké", "Sahélien", "Bali-Bali", "Touabire", "Croisé"],
   "champs": [{"nom": "Robe", "choix": ["Blanche", "Noire", "Pie", "Rousse"]}, {"nom": "Cornes", "choix": ["Oui", "Non"]}],
   "reperes": [["Mise à la reproduction", "8 à 12 mois"], ["Gestation", "150 jours"], ["Portée", "1 à 2 agneaux"],
               ["Sevrage", "3 mois"], ["Poids adulte", "25 à 60 kg selon la race"]]}'),
 ('Chèvres', '{"races": ["Naine de Guinée (Djallonké)", "Sahélienne", "Rousse de Maradi", "Croisée"],
   "champs": [{"nom": "Robe", "choix": ["Noire", "Blanche", "Rousse", "Pie", "Grise"]}, {"nom": "Cornes", "choix": ["Oui", "Non"]}],
   "reperes": [["Mise à la reproduction", "7 à 10 mois"], ["Gestation", "150 jours"], ["Portée", "1 à 3 chevreaux"],
               ["Sevrage", "3 mois"], ["Poids adulte", "20 à 40 kg selon la race"]]}'),
 ('Bovins', '{"races": ["N''Dama", "Baoulé", "Zébu", "Métis", "Holstein"],
   "champs": [{"nom": "Robe", "choix": ["Fauve", "Noire", "Blanche", "Pie noire", "Pie rouge"]}, {"nom": "Cornes", "choix": ["Oui", "Non", "Écornée"]}],
   "reperes": [["Mise à la reproduction", "génisse 24 à 30 mois"], ["Gestation", "283 jours (environ 9 mois)"], ["Portée", "1 veau"],
               ["Sevrage", "6 mois"], ["Poids adulte", "250 à 450 kg selon la race"]]}'),
 ('Poissons', '{"races": ["Tilapia (Oreochromis niloticus)", "Silure (Clarias)", "Hétérotis", "Carpe"],
   "champs": [],
   "reperes": [["Durée d''élevage", "5 à 7 mois"], ["Poids de vente", "300 à 500 g (tilapia)"], ["Densité", "selon la taille du bassin"]]}')
) AS m(nom, modele)
WHERE ferme_especes.nom = m.nom AND ferme_especes.modele = '{}'::jsonb;

-- Caractéristiques particulières d'un animal (22/11/2026, demande de Boss : yeux bleus, oreilles tombantes…)
ALTER TABLE ferme_sujets ADD COLUMN IF NOT EXISTS caracteristiques VARCHAR(300);
UPDATE ferme_especes SET modele = modele || jsonb_build_object('caracteristiques', m.liste::jsonb) FROM (VALUES
 ('Lapins', '["Yeux bleus", "Yeux rouges", "Oreilles courtes", "Oreilles tombantes (bélier)", "Poil long", "Tache sur le nez"]'),
 ('Aulacodes', '["Tache claire", "Queue courte", "Cicatrice"]'),
 ('Porcs', '["Oreilles tombantes", "Oreilles dressées", "Tache noire", "Queue coupée", "Boiterie"]'),
 ('Moutons', '["Tache sur la tête", "Oreilles tombantes", "Barbiche", "Cornes recourbées"]'),
 ('Chèvres', '["Barbiche", "Pendeloques au cou", "Oreilles tombantes", "Tache blanche au front"]'),
 ('Bovins', '["Bosse marquée", "Tache blanche au front", "Cornes en lyre", "Fanon développé", "Boiterie"]'),
 ('Poulets de chair', '["Pattes jaunes", "Crête simple"]'),
 ('Poules pondeuses', '["Crête simple", "Crête rose", "Pattes jaunes"]'),
 ('Poulets traditionnels', '["Cou nu", "Pattes emplumées", "Huppe", "Crête double"]'),
 ('Pintades', '["Casque haut", "Barbillons rouges"]'),
 ('Canards', '["Caroncules rouges", "Huppe"]')
) AS m(nom, liste)
WHERE ferme_especes.nom = m.nom AND NOT (ferme_especes.modele ? 'caracteristiques');
