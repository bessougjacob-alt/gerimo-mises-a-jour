-- ============================================================
-- Migration 053 — Ferme, étape 5 (22/11/2026) : ventes de la ferme (ferme_ventes.py) et rentabilité
-- Demande de Boss (22/11/2026) : « un module qui traitera de revenus, rendements, rentabilité, pertes… les choses
-- essentielles du business ». Décision du 22/11 : ventes propres à la ferme, comptant ou à crédit, avec reçu.
-- - ferme_clients : acheteurs (pour le crédit) ;
-- - ferme_ventes (n° VFE-AAAA-NNNN) et ferme_lignes_vente : animaux (d'une bande ou avec fiche), œufs, lait, autre ;
--   une vente d'animaux d'une bande diminue ses animaux en vie ; un animal avec fiche passe « Vendu » ;
-- - ferme_reglements : argent reçu (comptant au moment de la vente, puis remboursements) → trésorerie, comptabilité.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS ferme_clients (
    id          SERIAL PRIMARY KEY,
    nom         VARCHAR(100) NOT NULL UNIQUE,
    telephone   VARCHAR(30),
    note        VARCHAR(300),
    actif       BOOLEAN NOT NULL DEFAULT TRUE,
    cree_le     TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ferme_ventes (
    id                  SERIAL PRIMARY KEY,
    numero              VARCHAR(20) NOT NULL UNIQUE,
    date_vente          DATE NOT NULL,
    client_id           INTEGER REFERENCES ferme_clients(id),
    client_nom          VARCHAR(100),                             -- acheteur de passage
    total               NUMERIC(14, 2) NOT NULL CHECK (total >= 0),
    annulee             BOOLEAN NOT NULL DEFAULT FALSE,
    motif_annulation    VARCHAR(300),
    note                VARCHAR(300),
    saisi_par           INTEGER REFERENCES utilisateurs(id),
    cree_le             TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_ferme_ventes_date ON ferme_ventes (date_vente);

CREATE TABLE IF NOT EXISTS ferme_lignes_vente (
    id              SERIAL PRIMARY KEY,
    vente_id        INTEGER NOT NULL REFERENCES ferme_ventes(id) ON DELETE CASCADE,
    genre           VARCHAR(10) NOT NULL CHECK (genre IN ('Animaux', 'Œufs', 'Lait', 'Autre')),
    espece          VARCHAR(40) REFERENCES ferme_especes(nom) ON UPDATE CASCADE,
    bande_id        INTEGER REFERENCES ferme_bandes(id),
    sujet_id        INTEGER REFERENCES ferme_sujets(id),
    description     VARCHAR(120),
    quantite        NUMERIC(12, 2) NOT NULL CHECK (quantite > 0),     -- animaux, œufs, litres, unités
    poids_kg        NUMERIC(12, 2) CHECK (poids_kg IS NULL OR poids_kg > 0),   -- poids vendu (animaux)
    unite_prix      VARCHAR(10) NOT NULL DEFAULT 'pièce' CHECK (unite_prix IN ('pièce', 'kg', 'plateau', 'litre', 'unité')),
    prix_unitaire   NUMERIC(14, 2) NOT NULL CHECK (prix_unitaire >= 0),
    montant         NUMERIC(14, 2) NOT NULL CHECK (montant >= 0)
);
CREATE INDEX IF NOT EXISTS idx_ferme_lignes_vente_bande ON ferme_lignes_vente (bande_id);

CREATE TABLE IF NOT EXISTS ferme_reglements (
    id              SERIAL PRIMARY KEY,
    vente_id        INTEGER NOT NULL REFERENCES ferme_ventes(id),
    date_reglement  DATE NOT NULL,
    montant         NUMERIC(14, 2) NOT NULL CHECK (montant > 0),
    mode_paiement   VARCHAR(20) NOT NULL DEFAULT 'Espèce',
    compte_id       INTEGER REFERENCES comptes_tresorerie(id),
    saisi_par       INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_ferme_reglements_date ON ferme_reglements (date_reglement);

DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['ferme_clients', 'ferme_ventes', 'ferme_lignes_vente', 'ferme_reglements']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
