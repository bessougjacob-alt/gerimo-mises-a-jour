-- ============================================================
-- Migration 047 — Métier « Ferme » (22/11/2026), étape 1 : poulaillers, bandes, suivi du jour (ferme.py)
-- Décisions de Boss (22/11/2026) : volaille seulement pour commencer (poulets de chair, poules pondeuses,
-- poulets traditionnels, pintades ; le couvoir viendra à part) ; les animaux sont comptés par BANDE ;
-- plusieurs poulaillers sur un seul site ; le chef de ferme (Gestionnaire) saisit chaque jour les morts,
-- les œufs et l'aliment donné, sans voir l'argent.
-- Tables :
-- - ferme_poulaillers (bâtiments), ferme_bandes (n° BDE-AAAA-NNN), ferme_suivis (une ligne par bande et par jour).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS ferme_poulaillers (
    id          SERIAL PRIMARY KEY,
    nom         VARCHAR(60) NOT NULL UNIQUE,
    capacite    INTEGER CHECK (capacite IS NULL OR capacite > 0),     -- nombre de sujets qu'il peut loger
    note        VARCHAR(300),
    actif       BOOLEAN NOT NULL DEFAULT TRUE,
    cree_le     TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ferme_bandes (
    id              SERIAL PRIMARY KEY,
    numero          VARCHAR(20) NOT NULL UNIQUE,
    type_elevage    VARCHAR(30) NOT NULL CHECK (type_elevage IN
                    ('Poulets de chair', 'Poules pondeuses', 'Poulets traditionnels', 'Pintades')),
    poulailler_id   INTEGER NOT NULL REFERENCES ferme_poulaillers(id),
    nom             VARCHAR(100),                                   -- facultatif : « Bande de Noël »
    souche          VARCHAR(60),                                    -- race / souche (Cobb 500, ISA Brown…)
    date_arrivee    DATE NOT NULL,
    age_arrivee     INTEGER NOT NULL DEFAULT 1 CHECK (age_arrivee >= 0),   -- âge en jours à l'arrivée
    effectif_depart INTEGER NOT NULL CHECK (effectif_depart > 0),
    fournisseur     VARCHAR(100),
    cout_achat      NUMERIC(14, 2) CHECK (cout_achat IS NULL OR cout_achat >= 0),  -- vide = prix à compléter
    statut          VARCHAR(12) NOT NULL DEFAULT 'En cours' CHECK (statut IN ('En cours', 'Terminée')),
    date_fin        DATE,
    note            VARCHAR(300),
    saisi_par       INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_ferme_bandes_statut ON ferme_bandes (statut);

CREATE TABLE IF NOT EXISTS ferme_suivis (
    id              SERIAL PRIMARY KEY,
    bande_id        INTEGER NOT NULL REFERENCES ferme_bandes(id),
    date_suivi      DATE NOT NULL,
    morts           INTEGER NOT NULL DEFAULT 0 CHECK (morts >= 0),
    cause_morts     VARCHAR(100),
    oeufs           INTEGER NOT NULL DEFAULT 0 CHECK (oeufs >= 0),          -- œufs ramassés (bons)
    oeufs_casses    INTEGER NOT NULL DEFAULT 0 CHECK (oeufs_casses >= 0),
    aliment_kg      NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (aliment_kg >= 0),
    note            VARCHAR(300),
    saisi_par       INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT NOW(),
    modifie_le      TIMESTAMP,
    UNIQUE (bande_id, date_suivi)
);

DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['ferme_poulaillers', 'ferme_bandes', 'ferme_suivis']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
