-- ============================================================
-- Migration 048 — Ferme, étape 2 (22/11/2026) : aliments et produits (ferme_stock.py)
-- Décisions de Boss (22/11/2026) : stock des aliments, vaccins, médicaments et vitamines, matériel et litière ;
-- l'aliment noté dans le suivi du jour sort TOUT SEUL du stock (le chef choisit l'aliment sur la ligne de la bande) ;
-- achats comptant ou à crédit (« Ce que je dois aux fournisseurs », versements) ; l'aliment se compte en kg,
-- s'achète en sacs (kg par sac propre à chaque aliment).
-- Le chef de ferme (Gestionnaire) peut noter un achat sans les prix : « prix à compléter » par la Caisse ou l'Admin.
-- Tables :
-- - ferme_produits, ferme_fournisseurs, ferme_achats (n° AFE-AAAA-NNNN), ferme_lignes_achat, ferme_versements,
-- - ferme_mouvements (stock = somme des quantités ; + entrée, − sortie), ferme_suivis.produit_id (aliment donné).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS ferme_produits (
    id              SERIAL PRIMARY KEY,
    nom             VARCHAR(80) NOT NULL UNIQUE,
    categorie       VARCHAR(20) NOT NULL CHECK (categorie IN ('Aliment', 'Vaccin', 'Médicament', 'Matériel')),
    unite           VARCHAR(20) NOT NULL DEFAULT 'kg',             -- kg, flacon, dose, sachet, litre, pièce, sac…
    kg_par_sac      NUMERIC(8, 2) CHECK (kg_par_sac IS NULL OR kg_par_sac > 0),   -- aliments achetés en sacs
    seuil_alerte    NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (seuil_alerte >= 0),
    note            VARCHAR(300),
    actif           BOOLEAN NOT NULL DEFAULT TRUE,
    cree_le         TIMESTAMP DEFAULT NOW()
);
-- Les aliments les plus courants, prêts à servir (l'Admin peut les renommer ou les retirer)
INSERT INTO ferme_produits (nom, categorie, unite, kg_par_sac, seuil_alerte) VALUES
    ('Aliment démarrage', 'Aliment', 'kg', 50, 100), ('Aliment croissance', 'Aliment', 'kg', 50, 100),
    ('Aliment finition', 'Aliment', 'kg', 50, 100), ('Aliment ponte', 'Aliment', 'kg', 50, 100)
ON CONFLICT (nom) DO NOTHING;

CREATE TABLE IF NOT EXISTS ferme_fournisseurs (
    id          SERIAL PRIMARY KEY,
    nom         VARCHAR(100) NOT NULL UNIQUE,
    telephone   VARCHAR(30),
    note        VARCHAR(300),
    actif       BOOLEAN NOT NULL DEFAULT TRUE,
    cree_le     TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ferme_achats (
    id                  SERIAL PRIMARY KEY,
    numero              VARCHAR(20) NOT NULL UNIQUE,
    date_achat          DATE NOT NULL,
    fournisseur_id      INTEGER REFERENCES ferme_fournisseurs(id),
    reference           VARCHAR(60),                               -- n° de facture du fournisseur
    montant_total       NUMERIC(14, 2) CHECK (montant_total IS NULL OR montant_total >= 0),   -- vide = prix à compléter
    prix_complets       BOOLEAN NOT NULL DEFAULT FALSE,
    annule              BOOLEAN NOT NULL DEFAULT FALSE,
    motif_annulation    VARCHAR(300),
    note                VARCHAR(300),
    saisi_par           INTEGER REFERENCES utilisateurs(id),
    prix_par            INTEGER REFERENCES utilisateurs(id),
    cree_le             TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_ferme_achats_date ON ferme_achats (date_achat);

CREATE TABLE IF NOT EXISTS ferme_lignes_achat (
    id          SERIAL PRIMARY KEY,
    achat_id    INTEGER NOT NULL REFERENCES ferme_achats(id) ON DELETE CASCADE,
    produit_id  INTEGER NOT NULL REFERENCES ferme_produits(id),
    quantite    NUMERIC(12, 2) NOT NULL CHECK (quantite > 0),     -- dans l'unité du produit (kg pour un aliment)
    prix        NUMERIC(14, 2) CHECK (prix IS NULL OR prix >= 0)  -- prix de toute la ligne ; vide = à compléter
);

CREATE TABLE IF NOT EXISTS ferme_versements (
    id              SERIAL PRIMARY KEY,
    achat_id        INTEGER NOT NULL REFERENCES ferme_achats(id),
    date_versement  DATE NOT NULL,
    montant         NUMERIC(14, 2) NOT NULL CHECK (montant > 0),
    mode_paiement   VARCHAR(20) NOT NULL DEFAULT 'Espèce',
    compte_id       INTEGER REFERENCES comptes_tresorerie(id),
    note            VARCHAR(200),
    saisi_par       INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_ferme_versements_date ON ferme_versements (date_versement);

CREATE TABLE IF NOT EXISTS ferme_mouvements (
    id              SERIAL PRIMARY KEY,
    produit_id      INTEGER NOT NULL REFERENCES ferme_produits(id),
    date_mouvement  DATE NOT NULL,
    genre           VARCHAR(12) NOT NULL CHECK (genre IN ('Achat', 'Utilisation', 'Perte', 'Correction')),
    quantite        NUMERIC(12, 2) NOT NULL CHECK (quantite <> 0),   -- + entrée, − sortie
    bande_id        INTEGER REFERENCES ferme_bandes(id),
    suivi_id        INTEGER REFERENCES ferme_suivis(id) ON DELETE CASCADE,   -- aliment du suivi du jour
    achat_id        INTEGER REFERENCES ferme_achats(id) ON DELETE CASCADE,
    motif           VARCHAR(200),
    saisi_par       INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_ferme_mouvements_produit ON ferme_mouvements (produit_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ferme_mouvements_suivi ON ferme_mouvements (suivi_id) WHERE suivi_id IS NOT NULL;

ALTER TABLE ferme_suivis ADD COLUMN IF NOT EXISTS produit_id INTEGER REFERENCES ferme_produits(id);

DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['ferme_produits', 'ferme_fournisseurs', 'ferme_achats', 'ferme_lignes_achat',
                             'ferme_versements', 'ferme_mouvements']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
