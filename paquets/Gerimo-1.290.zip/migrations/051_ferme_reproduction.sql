-- ============================================================
-- Migration 051 — Ferme, étape 4 (22/11/2026) : reproduction et animaux (ferme_repro.py)
-- Décisions de Boss (22/11/2026) :
-- - Gérimo donne l'âge des animaux : âge à l'arrivée + temps passé à la ferme (ou date de naissance si connue).
-- - Fiches individuelles AU CHOIX (animaux étiquetés : n° de boucle ou d'étiquette) : espèce, race, sexe, parents,
--   génération, état de santé, pesées, sortie (vendu, mort, réformé).
-- - Accouplements (en attente, réussi, non réussi) ; durée de gestation par espèce (modifiable) : date de contrôle et
--   date de mise bas prévues (Agenda, alertes).
-- - Naissances (portées) : nés vivants, morts-nés, mâles, femelles, race, santé ; les petits ont chacun leur fiche OU
--   sont comptés dans une bande (au choix à chaque naissance).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE ferme_especes ADD COLUMN IF NOT EXISTS gestation_jours INTEGER CHECK (gestation_jours IS NULL OR gestation_jours > 0);
ALTER TABLE ferme_especes ADD COLUMN IF NOT EXISTS controle_jours INTEGER CHECK (controle_jours IS NULL OR controle_jours > 0);
ALTER TABLE ferme_especes ADD COLUMN IF NOT EXISTS sevrage_jours INTEGER CHECK (sevrage_jours IS NULL OR sevrage_jours > 0);
-- Durées indicatives (jours), modifiables par l'Admin
UPDATE ferme_especes SET gestation_jours = 31, controle_jours = 12, sevrage_jours = 35 WHERE nom = 'Lapins' AND gestation_jours IS NULL;
UPDATE ferme_especes SET gestation_jours = 152, controle_jours = 30, sevrage_jours = 40 WHERE nom = 'Aulacodes' AND gestation_jours IS NULL;
UPDATE ferme_especes SET gestation_jours = 114, controle_jours = 21, sevrage_jours = 28 WHERE nom = 'Porcs' AND gestation_jours IS NULL;
UPDATE ferme_especes SET gestation_jours = 150, controle_jours = 35, sevrage_jours = 90 WHERE nom = 'Moutons' AND gestation_jours IS NULL;
UPDATE ferme_especes SET gestation_jours = 150, controle_jours = 35, sevrage_jours = 90 WHERE nom = 'Chèvres' AND gestation_jours IS NULL;
UPDATE ferme_especes SET gestation_jours = 283, controle_jours = 45, sevrage_jours = 180 WHERE nom = 'Bovins' AND gestation_jours IS NULL;

-- Bandes : mâles et femelles à l'arrivée (facultatif)
ALTER TABLE ferme_bandes ADD COLUMN IF NOT EXISTS males INTEGER CHECK (males IS NULL OR males >= 0);
ALTER TABLE ferme_bandes ADD COLUMN IF NOT EXISTS femelles INTEGER CHECK (femelles IS NULL OR femelles >= 0);

CREATE TABLE IF NOT EXISTS ferme_naissances (
    id                  SERIAL PRIMARY KEY,
    numero              VARCHAR(20) NOT NULL UNIQUE,              -- NAI-AAAA-NNNN
    espece              VARCHAR(40) NOT NULL REFERENCES ferme_especes(nom) ON UPDATE CASCADE,
    date_naissance      DATE NOT NULL,
    mere_id             INTEGER,                                  -- ferme_sujets (clé ajoutée plus bas)
    pere_id             INTEGER,
    mere_texte          VARCHAR(80),                              -- mère sans fiche (« une lapine de la bande B3 »)
    pere_texte          VARCHAR(80),
    nes_vivants         INTEGER NOT NULL DEFAULT 0 CHECK (nes_vivants >= 0),
    morts_nes           INTEGER NOT NULL DEFAULT 0 CHECK (morts_nes >= 0),
    males               INTEGER NOT NULL DEFAULT 0 CHECK (males >= 0),
    femelles            INTEGER NOT NULL DEFAULT 0 CHECK (femelles >= 0),
    race                VARCHAR(60),
    etat_sante          VARCHAR(40),
    poids_moyen_g       NUMERIC(10, 1) CHECK (poids_moyen_g IS NULL OR poids_moyen_g > 0),
    destination         VARCHAR(10) NOT NULL DEFAULT 'Bande' CHECK (destination IN ('Fiches', 'Bande')),
    bande_id            INTEGER REFERENCES ferme_bandes(id),      -- les petits comptés dans cette bande
    note                VARCHAR(300),
    saisi_par           INTEGER REFERENCES utilisateurs(id),
    cree_le             TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ferme_sujets (
    id                  SERIAL PRIMARY KEY,
    numero              VARCHAR(30),                              -- n° de boucle ou d'étiquette
    nom                 VARCHAR(60),
    espece              VARCHAR(40) NOT NULL REFERENCES ferme_especes(nom) ON UPDATE CASCADE,
    race                VARCHAR(60),
    sexe                VARCHAR(8) NOT NULL DEFAULT 'Inconnu' CHECK (sexe IN ('Mâle', 'Femelle', 'Inconnu')),
    date_naissance      DATE,                                     -- connue : l'âge en découle
    date_arrivee        DATE NOT NULL,
    age_arrivee         INTEGER NOT NULL DEFAULT 0 CHECK (age_arrivee >= 0),   -- jours, si la naissance n'est pas connue
    origine             VARCHAR(20) NOT NULL DEFAULT 'Acheté' CHECK (origine IN ('Né à la ferme', 'Acheté', 'Autre')),
    mere_id             INTEGER REFERENCES ferme_sujets(id),
    pere_id             INTEGER REFERENCES ferme_sujets(id),
    naissance_id        INTEGER REFERENCES ferme_naissances(id) ON DELETE SET NULL,
    generation          INTEGER NOT NULL DEFAULT 1 CHECK (generation >= 1),
    bande_id            INTEGER REFERENCES ferme_bandes(id),
    poulailler_id       INTEGER REFERENCES ferme_poulaillers(id),
    reproducteur        BOOLEAN NOT NULL DEFAULT FALSE,
    etat_sante          VARCHAR(20) NOT NULL DEFAULT 'Bonne santé' CHECK (etat_sante IN ('Bonne santé', 'Malade', 'En traitement', 'Blessé')),
    statut              VARCHAR(10) NOT NULL DEFAULT 'Présent' CHECK (statut IN ('Présent', 'Vendu', 'Mort', 'Réformé')),
    date_sortie         DATE,
    cause_sortie        VARCHAR(100),
    note                VARCHAR(300),
    saisi_par           INTEGER REFERENCES utilisateurs(id),
    cree_le             TIMESTAMP DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ferme_sujets_numero ON ferme_sujets (espece, numero) WHERE numero IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_ferme_sujets_espece ON ferme_sujets (espece, statut);

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ferme_naissances_mere_fk') THEN
        ALTER TABLE ferme_naissances ADD CONSTRAINT ferme_naissances_mere_fk FOREIGN KEY (mere_id) REFERENCES ferme_sujets(id);
        ALTER TABLE ferme_naissances ADD CONSTRAINT ferme_naissances_pere_fk FOREIGN KEY (pere_id) REFERENCES ferme_sujets(id);
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS ferme_pesees_sujets (
    id          SERIAL PRIMARY KEY,
    sujet_id    INTEGER NOT NULL REFERENCES ferme_sujets(id) ON DELETE CASCADE,
    date_pesee  DATE NOT NULL,
    poids_kg    NUMERIC(10, 3) NOT NULL CHECK (poids_kg > 0),
    saisi_par   INTEGER REFERENCES utilisateurs(id),
    cree_le     TIMESTAMP DEFAULT NOW(),
    UNIQUE (sujet_id, date_pesee)
);

CREATE TABLE IF NOT EXISTS ferme_accouplements (
    id                  SERIAL PRIMARY KEY,
    espece              VARCHAR(40) NOT NULL REFERENCES ferme_especes(nom) ON UPDATE CASCADE,
    femelle_id          INTEGER REFERENCES ferme_sujets(id),
    male_id             INTEGER REFERENCES ferme_sujets(id),
    femelle_texte       VARCHAR(80),                              -- femelle sans fiche
    male_texte          VARCHAR(80),                              -- mâle sans fiche (« verrat du voisin »)
    date_accouplement   DATE NOT NULL,
    methode             VARCHAR(15) NOT NULL DEFAULT 'Naturelle' CHECK (methode IN ('Naturelle', 'Insémination')),
    resultat            VARCHAR(12) NOT NULL DEFAULT 'En attente' CHECK (resultat IN ('En attente', 'Réussi', 'Non réussi')),
    date_resultat       DATE,
    mise_bas_prevue     DATE,
    naissance_id        INTEGER REFERENCES ferme_naissances(id) ON DELETE SET NULL,
    note                VARCHAR(300),
    saisi_par           INTEGER REFERENCES utilisateurs(id),
    cree_le             TIMESTAMP DEFAULT NOW(),
    CHECK (femelle_id IS NOT NULL OR femelle_texte IS NOT NULL)
);
ALTER TABLE ferme_naissances ADD COLUMN IF NOT EXISTS accouplement_id INTEGER REFERENCES ferme_accouplements(id) ON DELETE SET NULL;

DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['ferme_naissances', 'ferme_sujets', 'ferme_pesees_sujets', 'ferme_accouplements']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
