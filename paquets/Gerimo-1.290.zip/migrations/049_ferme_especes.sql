-- ============================================================
-- Migration 049 — Ferme : toutes les espèces (22/11/2026, demande de Boss)
-- « Le logiciel doit donner la liberté d'élever d'autres espèces : lapins, aulacodes, bétail… » : la liste des
-- espèces n'est plus figée. Chaque espèce : son groupe, son dessin, ce qu'elle donne chaque jour (œufs, lait ou rien),
-- si elle a des naissances (lapins, porcs…), et le nom de son bâtiment (poulailler, clapier, porcherie…).
-- L'Admin en ajoute ou en retire (Ferme → Bâtiments et animaux). ferme_bandes.type_elevage renvoie au nom de l'espèce
-- (ON UPDATE CASCADE : renommer une espèce renomme ses bandes).
-- Suivi du jour : + naissances, + lait (litres).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS ferme_especes (
    id              SERIAL PRIMARY KEY,
    nom             VARCHAR(40) NOT NULL UNIQUE,
    groupe          VARCHAR(20) NOT NULL DEFAULT 'Autre' CHECK (groupe IN ('Volaille', 'Petits animaux', 'Bétail', 'Poissons', 'Autre')),
    dessin          VARCHAR(30) NOT NULL DEFAULT 'animal',       -- image de static/img/ferme
    production      VARCHAR(10) CHECK (production IN ('Œufs', 'Lait')),   -- ce qu'elle donne chaque jour (vide = rien)
    naissances      BOOLEAN NOT NULL DEFAULT FALSE,
    batiment        VARCHAR(30) NOT NULL DEFAULT 'bâtiment',     -- poulailler, clapier, porcherie, étable, bassin…
    actif           BOOLEAN NOT NULL DEFAULT TRUE,
    ordre           INTEGER NOT NULL DEFAULT 0
);
INSERT INTO ferme_especes (nom, groupe, dessin, production, naissances, batiment, ordre) VALUES
    ('Poulets de chair', 'Volaille', 'poulet-chair', NULL, FALSE, 'poulailler', 1),
    ('Poules pondeuses', 'Volaille', 'pondeuse', 'Œufs', FALSE, 'poulailler', 2),
    ('Poulets traditionnels', 'Volaille', 'coq', NULL, FALSE, 'poulailler', 3),
    ('Pintades', 'Volaille', 'pintade', NULL, FALSE, 'poulailler', 4),
    ('Canards', 'Volaille', 'canard', NULL, FALSE, 'poulailler', 5),
    ('Lapins', 'Petits animaux', 'lapin', NULL, TRUE, 'clapier', 10),
    ('Aulacodes', 'Petits animaux', 'aulacode', NULL, TRUE, 'enclos', 11),
    ('Porcs', 'Bétail', 'porc', NULL, TRUE, 'porcherie', 20),
    ('Moutons', 'Bétail', 'mouton', NULL, TRUE, 'bergerie', 21),
    ('Chèvres', 'Bétail', 'chevre', 'Lait', TRUE, 'chèvrerie', 22),
    ('Bovins', 'Bétail', 'boeuf', 'Lait', TRUE, 'étable', 23),
    ('Poissons', 'Poissons', 'poisson', NULL, FALSE, 'bassin', 30)
ON CONFLICT (nom) DO NOTHING;

-- Les bandes renvoient à une espèce de la liste (au lieu de 4 types figés)
ALTER TABLE ferme_bandes ALTER COLUMN type_elevage TYPE VARCHAR(40);
ALTER TABLE ferme_bandes DROP CONSTRAINT IF EXISTS ferme_bandes_type_elevage_check;
ALTER TABLE ferme_bandes DROP CONSTRAINT IF EXISTS ferme_bandes_espece_fk;
ALTER TABLE ferme_bandes ADD CONSTRAINT ferme_bandes_espece_fk FOREIGN KEY (type_elevage)
    REFERENCES ferme_especes(nom) ON UPDATE CASCADE;

-- Suivi du jour : naissances (lapins, porcs…) et lait (chèvres, vaches)
ALTER TABLE ferme_suivis ADD COLUMN IF NOT EXISTS naissances INTEGER NOT NULL DEFAULT 0 CHECK (naissances >= 0);
ALTER TABLE ferme_suivis ADD COLUMN IF NOT EXISTS lait_litres NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (lait_litres >= 0);

DROP TRIGGER IF EXISTS journal_actions ON ferme_especes;
CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON ferme_especes
    FOR EACH ROW EXECUTE FUNCTION journal_ecrire();
