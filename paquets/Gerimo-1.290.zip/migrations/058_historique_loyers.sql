-- ============================================================
-- Migration 058 — Historique des loyers repris des anciens classeurs (demande de Boss, 23/11/2026)
-- Une ligne = ce qu'un locataire a versé pour un mois dans l'ancien fichier de l'agence (somme, part du propriétaire,
-- part de l'agence, dépenses), tel que noté. Sert seulement aux rapports (rapport par bien, annuel, par locataire,
-- statistiques, relevés) : aucun contrat, impayé ni encaissement n'est créé. Rattachée au contrat du locataire
-- actuel quand le nom (ou le téléphone) correspond, sinon gardée comme « ancien locataire » (nom tel qu'écrit).
-- transaction_id : pour retirer les lignes d'un import annulé (Paramètres → Reprise de données).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS historique_loyers (
    id                SERIAL PRIMARY KEY,
    cite_id           INTEGER NOT NULL REFERENCES cites(id) ON DELETE CASCADE,
    logement_id       INTEGER REFERENCES logements(id) ON DELETE SET NULL,
    contrat_id        INTEGER REFERENCES contrats(id) ON DELETE SET NULL,
    numero_logement   VARCHAR(30) NOT NULL,
    locataire         VARCHAR(150) NOT NULL,
    telephone         VARCHAR(30),
    mois              DATE NOT NULL,
    montant           NUMERIC(12, 2) NOT NULL DEFAULT 0,
    part_proprietaire NUMERIC(12, 2) NOT NULL DEFAULT 0,
    part_agence       NUMERIC(12, 2) NOT NULL DEFAULT 0,
    depenses          NUMERIC(12, 2) NOT NULL DEFAULT 0,
    source            VARCHAR(200),
    transaction_id    BIGINT NOT NULL DEFAULT txid_current(),
    cree_le           TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_historique_loyers_cite_mois ON historique_loyers (cite_id, mois);
CREATE INDEX IF NOT EXISTS ix_historique_loyers_contrat ON historique_loyers (contrat_id);
CREATE INDEX IF NOT EXISTS ix_historique_loyers_transaction ON historique_loyers (transaction_id);
