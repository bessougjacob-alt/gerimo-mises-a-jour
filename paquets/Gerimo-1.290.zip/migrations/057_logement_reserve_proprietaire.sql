-- ============================================================
-- Migration 057 — Logement « Réservé par le propriétaire » (demande de Boss, 23/11/2026)
-- Certains logements sont occupés par leur propriétaire : pas de loyer, et ils ne doivent compter ni comme
-- occupés ni comme libres. Le logement passe au statut « Réservé » avec reserve_proprietaire = vrai ; le taux
-- d'occupation ne compte plus que les logements occupés et libres (les réservés sont affichés à part).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE logements ADD COLUMN IF NOT EXISTS reserve_proprietaire BOOLEAN NOT NULL DEFAULT FALSE;
