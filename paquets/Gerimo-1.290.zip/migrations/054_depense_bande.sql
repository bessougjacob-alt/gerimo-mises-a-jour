-- ============================================================
-- Migration 054 — Ferme : une dépense peut être rattachée à une bande (22/11/2026)
-- Décision de Boss (22/11/2026) : les ouvriers de la ferme sont payés en Dépenses, « rattachables à une bande » pour
-- compter dans son bénéfice (Ferme → Rentabilité). Salaires, électricité d'un bâtiment, transport des animaux…
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE depenses ADD COLUMN IF NOT EXISTS ferme_bande_id INTEGER REFERENCES ferme_bandes(id);
CREATE INDEX IF NOT EXISTS idx_depenses_ferme_bande ON depenses (ferme_bande_id) WHERE ferme_bande_id IS NOT NULL;
