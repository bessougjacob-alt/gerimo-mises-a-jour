-- ============================================================
-- Migration 055 — Ferme : œufs et couvoir (22/11/2026, ferme_oeufs.py)
-- Décisions de Boss (22/11/2026) :
-- - Stock d'œufs en plateaux de 30 : les œufs ramassés (suivi du jour) entrent ; les ventes, les œufs mis à couver,
--   cassés, mangés à la maison en sortent ; l'Admin corrige après un comptage.
-- - Couvaison en couveuse (machine) ou avec des poules couveuses, au choix ; œufs du stock ou achetés.
--   Mirage (œufs clairs retirés), éclosion prévue selon l'espèce (poule 21 jours, pintade 27, canard 28…).
-- - À l'éclosion, les poussins vont au choix : dans un nouveau lot, dans un lot existant, ou à la vente.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE ferme_especes ADD COLUMN IF NOT EXISTS incubation_jours INTEGER CHECK (incubation_jours IS NULL OR incubation_jours > 0);
ALTER TABLE ferme_especes ADD COLUMN IF NOT EXISTS mirage_jours INTEGER CHECK (mirage_jours IS NULL OR mirage_jours > 0);
UPDATE ferme_especes SET incubation_jours = 21, mirage_jours = 7
 WHERE nom IN ('Poulets de chair', 'Poules pondeuses', 'Poulets traditionnels') AND incubation_jours IS NULL;
UPDATE ferme_especes SET incubation_jours = 27, mirage_jours = 8 WHERE nom = 'Pintades' AND incubation_jours IS NULL;
UPDATE ferme_especes SET incubation_jours = 28, mirage_jours = 8 WHERE nom = 'Canards' AND incubation_jours IS NULL;

-- Sorties et corrections du stock d'œufs (les entrées viennent du suivi du jour, les ventes des ventes)
CREATE TABLE IF NOT EXISTS ferme_oeufs_mouvements (
    id              SERIAL PRIMARY KEY,
    date_mouvement  DATE NOT NULL,
    genre           VARCHAR(12) NOT NULL CHECK (genre IN ('Maison', 'Perte', 'Correction', 'Achat')),
    quantite        INTEGER NOT NULL CHECK (quantite <> 0),           -- + entrée, − sortie (œufs)
    motif           VARCHAR(200),
    saisi_par       INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ferme_couvaisons (
    id                  SERIAL PRIMARY KEY,
    numero              VARCHAR(20) NOT NULL UNIQUE,                  -- COU-AAAA-NNN
    espece              VARCHAR(40) NOT NULL REFERENCES ferme_especes(nom) ON UPDATE CASCADE,
    date_mise           DATE NOT NULL,
    nombre_oeufs        INTEGER NOT NULL CHECK (nombre_oeufs > 0),
    origine             VARCHAR(10) NOT NULL DEFAULT 'Stock' CHECK (origine IN ('Stock', 'Achetés')),
    cout_oeufs          NUMERIC(14, 2) CHECK (cout_oeufs IS NULL OR cout_oeufs >= 0),   -- œufs achetés
    methode             VARCHAR(10) NOT NULL DEFAULT 'Couveuse' CHECK (methode IN ('Couveuse', 'Poules')),
    couveuse            VARCHAR(80),                                  -- nom de la machine, ou « 3 poules du lot B2 »
    date_mirage         DATE,
    oeufs_clairs        INTEGER NOT NULL DEFAULT 0 CHECK (oeufs_clairs >= 0),          -- retirés au mirage (pas fécondés)
    eclosion_prevue     DATE,
    date_eclosion       DATE,
    eclos               INTEGER CHECK (eclos IS NULL OR eclos >= 0),
    destination         VARCHAR(12) CHECK (destination IN ('Nouveau lot', 'Lot existant', 'Vente')),
    lot_id              INTEGER REFERENCES ferme_bandes(id),
    statut              VARCHAR(10) NOT NULL DEFAULT 'En cours' CHECK (statut IN ('En cours', 'Éclose', 'Échouée')),
    note                VARCHAR(300),
    saisi_par           INTEGER REFERENCES utilisateurs(id),
    cree_le             TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_ferme_couvaisons_statut ON ferme_couvaisons (statut);

-- les poussins mis dans un lot existant y sont comptés (comme une portée)
ALTER TABLE ferme_naissances ADD COLUMN IF NOT EXISTS couvaison_id INTEGER REFERENCES ferme_couvaisons(id) ON DELETE CASCADE;

DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['ferme_oeufs_mouvements', 'ferme_couvaisons']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
