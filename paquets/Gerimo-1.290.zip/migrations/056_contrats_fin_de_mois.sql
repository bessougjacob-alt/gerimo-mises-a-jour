-- ============================================================
-- Migration 056 — Contrats : loyer « Fin de mois » par défaut et date d'établissement (demande de Boss, 23/11/2026)
-- - « Fin de mois » devient le terme par défaut (le « Début de mois » ne concerne que quelques contrats) ;
-- - une seule fois : les contrats repris d'un ancien fichier (suivi_depuis renseigné), tous saisis en
--   « Début de mois » par l'import, passent en « Fin de mois » ; leurs mois non soldés reçoivent la date limite
--   du 05 du mois suivant (les impayés sont recalculés par Gérimo à la lecture suivante). Les quelques contrats
--   vraiment payés en début de mois se corrigent ensuite un par un (Contrats → Modifier) ;
-- - date_etablissement : « Date du jour » où le contrat est établi (la date de prise d'effet reste date_debut).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE contrats ALTER COLUMN terme_loyer SET DEFAULT 'Fin de mois';
ALTER TABLE contrats ADD COLUMN IF NOT EXISTS date_etablissement DATE;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM parametres WHERE cle = 'migration_056_faite') THEN
        CREATE TEMP TABLE contrats_056 ON COMMIT DROP AS
            SELECT id FROM contrats WHERE suivi_depuis IS NOT NULL AND terme_loyer = 'Début de mois';

        DELETE FROM impayes
        WHERE echeance_id IN (SELECT e.id FROM echeances e
                              WHERE e.contrat_id IN (SELECT id FROM contrats_056) AND e.paiement_id IS NULL);

        UPDATE echeances
        SET date_limite = (mois_echeance + INTERVAL '1 month' + INTERVAL '4 days')::date
        WHERE contrat_id IN (SELECT id FROM contrats_056) AND paiement_id IS NULL;

        UPDATE contrats SET terme_loyer = 'Fin de mois' WHERE id IN (SELECT id FROM contrats_056);

        INSERT INTO parametres (cle, valeur, modifie_le) VALUES ('migration_056_faite', 'oui', NOW());
    END IF;
END $$;
