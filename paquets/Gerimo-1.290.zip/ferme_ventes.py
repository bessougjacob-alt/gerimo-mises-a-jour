"""Ferme, étape 5 (22/11/2026) : ventes de la ferme — animaux (d'une bande ou avec fiche), œufs, lait, autres produits ;
comptant ou à crédit ; clients ; ce que les clients doivent ; trésorerie et comptabilité.

Décisions de Boss (22/11/2026) : ventes propres à la ferme (pièce ou kilo, œufs en plateaux de 30, lait…), comptant ou
à crédit, reçu. Une vente d'animaux d'une bande diminue ses animaux en vie ; un animal avec fiche passe « Vendu ».
Rôles : Admin et Caisse vendent et encaissent ; le chef de ferme (Gestionnaire) note une vente sans encaisser ;
annulation : Admin (mot de passe et motif) ; Comptable : consultation.
"""
from collections import defaultdict
from datetime import date
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from sqlalchemy.orm import Session as SessionDB, selectinload

import periode
import tresorerie
from commun import Formulaire, Suppression, Telephone, Texte, charger, enregistrer, montant, numero_suivant
from models import (MODES_PAIEMENT, FermeBande, FermeClient, FermeEspece, FermeLigneVente, FermeReglement, FermeSujet,
                    FermeVente, Utilisateur)
from securite import exiger_admin, exiger_module, get_db, verifier_mot_de_passe

router = APIRouter(prefix="/api/ferme")
acces = exiger_module("ferme")
ZERO = Decimal(0)
VEND = ("Admin", "Caisse", "Gestionnaire")
ENCAISSE = ("Admin", "Caisse")
VOIT_ARGENT = ("Admin", "Caisse", "Comptable")
GENRES = ("Animaux", "Œufs", "Lait", "Autre")
UNITES = ("pièce", "kg", "plateau", "litre", "unité")
OEUFS_PAR_PLATEAU = 30


def _role(u: Utilisateur) -> str:
    return u.role.value


def paye(v: FermeVente) -> Decimal:
    return sum((r.montant for r in v.reglements), ZERO)


def nom_client(v: FermeVente) -> str:
    return v.client.nom if v.client else (v.client_nom or "Client de passage")


def vente_json(v: FermeVente) -> dict:
    reste = ZERO if v.annulee else v.total - paye(v)
    return {"id": v.id, "numero": v.numero, "date": v.date_vente.isoformat(), "client_id": v.client_id, "client": nom_client(v),
            "telephone": v.client.telephone if v.client and v.client.telephone else "",
            "total": montant(v.total), "paye": montant(paye(v)), "reste": montant(reste), "annulee": v.annulee,
            "motif_annulation": v.motif_annulation or "", "note": v.note or "",
            "etat": "annulee" if v.annulee else "credit" if reste > 0 else "payee",
            "saisi_par": v.auteur.nom_complet if v.auteur else "",
            "lignes": [{"id": l.id, "genre": l.genre, "espece": l.espece or "", "bande_id": l.bande_id, "sujet_id": l.sujet_id,
                        "bande": (l.bande.nom or l.bande.type_elevage) if l.bande else "",
                        "description": l.description or "", "quantite": montant(l.quantite),
                        "poids_kg": montant(l.poids_kg) if l.poids_kg else None, "unite_prix": l.unite_prix,
                        "prix_unitaire": montant(l.prix_unitaire), "montant": montant(l.montant)} for l in v.lignes],
            "reglements": [{"id": r.id, "date": r.date_reglement.isoformat(), "montant": montant(r.montant), "mode": r.mode_paiement}
                           for r in v.reglements]}


def _ventes(db: SessionDB):
    return db.query(FermeVente).options(selectinload(FermeVente.lignes).selectinload(FermeLigneVente.bande),
                                        selectinload(FermeVente.reglements), selectinload(FermeVente.client),
                                        selectinload(FermeVente.auteur))


def vendus_par_bande(db: SessionDB) -> dict[int, Decimal]:
    """Animaux vendus de chaque lot (ventes non annulées) : ils ne sont plus en vie dans le lot."""
    par = defaultdict(lambda: ZERO)
    for l in (db.query(FermeLigneVente).join(FermeVente)
              .filter(FermeVente.annulee.is_(False), FermeLigneVente.genre == "Animaux", FermeLigneVente.bande_id.isnot(None))):
        par[l.bande_id] += l.quantite
    return par


@router.get("/ventes")
def tableau_ventes(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    if _role(u) not in VOIT_ARGENT + ("Gestionnaire",):
        raise HTTPException(status_code=403, detail="Accès refusé.")
    ventes = _ventes(db).order_by(FermeVente.date_vente.desc(), FermeVente.id.desc()).limit(500).all()
    import ferme
    bandes = [b for b in ferme._bandes(db, "En cours")]
    sujets = (db.query(FermeSujet).filter(FermeSujet.statut == "Présent").order_by(FermeSujet.espece, FermeSujet.numero).all())
    from ferme_stock import comptes_actifs
    argent = _role(u) in VOIT_ARGENT
    return {"ventes": [vente_json(v) for v in ventes] if argent else [
                {**vente_json(v), "total": None, "paye": None, "reste": None} for v in ventes if v.saisi_par == u.id],
            "clients": [{"id": c.id, "nom": c.nom, "telephone": c.telephone or "", "actif": c.actif}
                        for c in db.query(FermeClient).order_by(FermeClient.nom)],
            "bandes": [{"id": b.id, "nom": b.nom or b.type_elevage, "espece": b.type_elevage, "dessin": b.espece.dessin,
                        "batiment": b.poulailler.nom, "vivants": ferme.chiffres(b)["vivants"], "pondeuses": b.espece.production == "Œufs",
                        "lait": b.espece.production == "Lait"} for b in bandes],
            "animaux": [{"id": s.id, "libelle": " ".join(x for x in (s.numero and f"n° {s.numero}", s.nom) if x) or f"{s.espece} #{s.id}",
                         "espece": s.espece, "sexe": s.sexe, "race": s.race or ""} for s in sujets],
            "especes": [{"nom": e.nom, "dessin": e.dessin} for e in db.query(FermeEspece).filter(FermeEspece.actif).order_by(FermeEspece.ordre)],
            "modes": MODES_PAIEMENT, "comptes": comptes_actifs(db) if _role(u) in ENCAISSE else [], "unites": UNITES,
            "vend": _role(u) in VEND, "encaisse": _role(u) in ENCAISSE, "argent": argent, "est_admin": _role(u) == "Admin"}


class LigneVenteIn(Formulaire):
    genre: Literal[GENRES]
    espece: Texte | None = Field(None, max_length=40)
    bande_id: int | None = None
    sujet_id: int | None = None
    description: Texte | None = Field(None, max_length=120)
    quantite: Decimal = Field(gt=0, max_digits=12, decimal_places=2)   # animaux, œufs, litres, unités
    poids_kg: Decimal | None = Field(None, gt=0, max_digits=12, decimal_places=2)
    unite_prix: Literal[UNITES] = "pièce"
    prix_unitaire: Decimal = Field(ge=0, max_digits=14, decimal_places=2)


class ReglementIn(Formulaire):
    montant: Decimal = Field(gt=0, max_digits=14, decimal_places=2)
    mode_paiement: Literal[MODES_PAIEMENT] = "Espèce"
    compte_id: int | None = None
    date_reglement: date | None = None


class VenteIn(Formulaire):
    date_vente: date | None = None
    client_id: int | None = None
    client_nom: Texte | None = Field(None, max_length=100)
    lignes: list[LigneVenteIn] = Field(min_length=1, max_length=60)
    paiement: ReglementIn | None = None
    note: Texte | None = Field(None, max_length=300)


def montant_ligne(x: LigneVenteIn) -> Decimal:
    """Prix × quantité, selon l'unité du prix : au kg (poids), au plateau de 30 œufs, sinon à la pièce."""
    if x.unite_prix == "kg":
        if not x.poids_kg:
            raise HTTPException(status_code=400, detail="Vente au kilo : indiquez le poids total vendu.")
        base = x.poids_kg
    elif x.unite_prix == "plateau":
        base = x.quantite / OEUFS_PAR_PLATEAU
    else:
        base = x.quantite
    return (base * x.prix_unitaire).quantize(Decimal("1"))


def _ajouter_reglement(db: SessionDB, u: Utilisateur, v: FermeVente, r: ReglementIn) -> None:
    jour = r.date_reglement or date.today()
    if jour > date.today() or jour < v.date_vente:
        raise HTTPException(status_code=400, detail="Date de paiement incorrecte.")
    periode.verifier_ouverte(db, jour)
    reste = v.total - paye(v)
    if r.montant > reste:
        raise HTTPException(status_code=400, detail=f"Le montant dépasse ce qui reste à payer ({montant(reste):,} F).".replace(",", " "))
    v.reglements.append(FermeReglement(date_reglement=jour, montant=r.montant, mode_paiement=r.mode_paiement,
                                       compte_id=tresorerie.verifier_compte_choisi(db, r.compte_id, r.mode_paiement), saisi_par=u.id))


@router.post("/ventes")
def vendre(d: VenteIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    if _role(u) not in VEND:
        raise HTTPException(status_code=403, detail="Le Comptable consulte seulement.")
    jour = d.date_vente or date.today()
    if jour > date.today():
        raise HTTPException(status_code=400, detail="La date ne peut pas être dans le futur.")
    periode.verifier_ouverte(db, jour)
    client = charger(db, FermeClient, d.client_id, "Client introuvable.") if d.client_id else None
    import ferme
    vendus = vendus_par_bande(db)
    v = FermeVente(numero=numero_suivant(db, FermeVente.numero, f"VFE-{jour.year}", 4), date_vente=jour,
                   client_id=client.id if client else None, client_nom=None if client else (d.client_nom or None),
                   note=d.note or None, saisi_par=u.id, total=ZERO)
    total, deja = ZERO, defaultdict(lambda: ZERO)
    for x in d.lignes:
        espece = x.espece
        if x.genre == "Animaux":
            if x.sujet_id:
                s = charger(db, FermeSujet, x.sujet_id, "Animal introuvable.")
                if s.statut != "Présent":
                    raise HTTPException(status_code=409, detail="Cet animal n'est plus à la ferme.")
                if x.quantite != 1:
                    raise HTTPException(status_code=400, detail="Un animal avec fiche se vend à l'unité.")
                s.statut, s.date_sortie, s.cause_sortie = "Vendu", jour, f"Vente {v.numero}"
                espece = s.espece
            elif x.bande_id:
                b = charger(db, FermeBande, x.bande_id, "Lot introuvable.")
                en_vie = ferme.chiffres(b)["vivants"] - deja[b.id]
                if x.quantite != x.quantite.to_integral_value():
                    raise HTTPException(status_code=400, detail="Le nombre d'animaux vendus doit être entier.")
                if x.quantite > en_vie:
                    raise HTTPException(status_code=409, detail=f"Lot {b.numero} : il n'y a que {en_vie} animaux en vie.")
                deja[b.id] += x.quantite
                espece = b.type_elevage
            else:
                raise HTTPException(status_code=400, detail="Choisissez le lot ou l'animal vendu.")
        elif x.bande_id:
            espece = charger(db, FermeBande, x.bande_id, "Lot introuvable.").type_elevage
        m = montant_ligne(x)
        total += m
        v.lignes.append(FermeLigneVente(genre=x.genre, espece=espece, bande_id=x.bande_id, sujet_id=x.sujet_id,
                                        description=x.description or None, quantite=x.quantite, poids_kg=x.poids_kg,
                                        unite_prix=x.unite_prix, prix_unitaire=x.prix_unitaire, montant=m))
    oeufs = int(sum((x.quantite for x in d.lignes if x.genre == "Œufs"), ZERO))
    if oeufs:   # les œufs vendus sortent du stock d'œufs (ramassés au suivi du jour)
        import ferme_oeufs
        ferme_oeufs.verifier_stock(db, oeufs, "cette vente")
    v.total = total
    db.add(v)
    db.flush()
    if d.paiement is not None:
        if _role(u) not in ENCAISSE:
            raise HTTPException(status_code=403, detail="L'argent est encaissé par la Caisse ou l'Admin.")
        d.paiement.date_reglement = d.paiement.date_reglement or jour
        _ajouter_reglement(db, u, v, d.paiement)
    if v.total - sum((r.montant for r in v.reglements), ZERO) > 0 and client is None and _role(u) in ENCAISSE:
        raise HTTPException(status_code=400, detail="Vente à crédit : choisissez le client (fiche obligatoire pour le suivre).")
    enregistrer(db, "Enregistrement impossible.")
    db.refresh(v)
    return vente_json(v)


@router.post("/ventes/{vente_id}/reglements")
def encaisser(vente_id: int, d: ReglementIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    if _role(u) not in ENCAISSE:
        raise HTTPException(status_code=403, detail="L'argent est encaissé par la Caisse ou l'Admin.")
    v = charger(db, FermeVente, vente_id, "Vente introuvable.")
    if v.annulee:
        raise HTTPException(status_code=409, detail="Cette vente est annulée.")
    _ajouter_reglement(db, u, v, d)
    enregistrer(db, "Enregistrement impossible.")
    return vente_json(v)


class AnnulationIn(Suppression):
    motif: Texte = Field(min_length=3, max_length=300)


@router.post("/ventes/{vente_id}/annuler")
def annuler(vente_id: int, d: AnnulationIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été annulé.")
    v = charger(db, FermeVente, vente_id, "Vente introuvable.")
    if v.annulee:
        raise HTTPException(status_code=409, detail="Cette vente est déjà annulée.")
    if v.reglements:
        raise HTTPException(status_code=409, detail="Cette vente a été payée : supprimez d'abord ses paiements (remboursement).")
    periode.verifier_ouverte(db, v.date_vente)
    for l in v.lignes:   # l'animal avec fiche redevient présent ; les animaux d'une bande y reviennent tout seuls
        if l.sujet_id:
            s = db.get(FermeSujet, l.sujet_id)
            if s and s.statut == "Vendu":
                s.statut, s.date_sortie, s.cause_sortie = "Présent", None, None
    v.annulee, v.motif_annulation = True, d.motif
    enregistrer(db, "Annulation impossible.")
    return {"ok": True}


@router.post("/reglements/{reglement_id}/supprimer")
def supprimer_reglement(reglement_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été supprimé.")
    r = charger(db, FermeReglement, reglement_id, "Paiement introuvable.")
    periode.verifier_ouverte(db, r.date_reglement)
    db.delete(r)
    enregistrer(db, "Suppression impossible.")
    return {"ok": True}


@router.get("/ventes/{vente_id}/recu")
def recu_vente(vente_id: int, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    """Reçu PDF de la vente (même mise en page que la facture de la Boutique ; identité de « Mon entreprise »)."""
    if _role(u) not in VOIT_ARGENT:
        raise HTTPException(status_code=403, detail="Le reçu est imprimé par la Caisse ou l'Admin.")
    import recus_commerce
    from ventes import _pdf
    v = charger(db, FermeVente, vente_id, "Vente introuvable.")
    unites = {"pièce": "animal(aux)", "kg": "kg", "plateau": "plateau(x)", "litre": "L", "unité": ""}
    lignes = []
    for l in v.lignes:
        if l.genre == "Animaux":
            article = f"{l.espece or 'Animaux'} : {montant(l.quantite)} animal(aux)" + (f", {montant(l.poids_kg)} kg" if l.poids_kg else "")
        elif l.genre == "Œufs":
            article = f"Œufs : {montant(l.quantite)} œufs"
        elif l.genre == "Lait":
            article = "Lait"
        else:
            article = l.description or "Autre produit de la ferme"
        base = l.poids_kg if l.unite_prix == "kg" else (l.quantite / OEUFS_PAR_PLATEAU if l.unite_prix == "plateau" else l.quantite)
        lignes.append({"article": article, "quantite": base, "unite": unites.get(l.unite_prix, ""), "prix": l.prix_unitaire, "total": l.montant})
    modes = sorted({r.mode_paiement for r in v.reglements})
    donnees = {"titre": "REÇU", "sous_titre": "Vente de la ferme", "arrete": "Arrêté le présent reçu",
               "numero": v.numero, "date": v.date_vente.strftime("%d/%m/%Y"), "client": nom_client(v),
               "client_coordonnees": v.client.telephone if v.client and v.client.telephone else "",
               "annulee": v.annulee, "lignes": lignes, "remise": 0, "sous_total": v.total, "total": v.total,
               "mode": ", ".join(modes) or "à crédit", "recu": paye(v), "reste": ZERO if v.annulee else v.total - paye(v)}
    return _pdf(recus_commerce.facture_pdf(donnees), f"Reçu {v.numero}.pdf")


class ClientIn(Formulaire):
    nom: Texte = Field(min_length=2, max_length=100)
    telephone: Telephone | None = Field(None, max_length=30)
    note: Texte | None = Field(None, max_length=300)
    actif: bool = True


@router.post("/clients")
def creer_client(d: ClientIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    if _role(u) not in VEND:
        raise HTTPException(status_code=403, detail="Le Comptable consulte seulement.")
    c = FermeClient(nom=d.nom, telephone=d.telephone or None, note=d.note or None, actif=d.actif)
    db.add(c)
    enregistrer(db, f"Le client « {d.nom} » existe déjà.")
    return {"id": c.id, "nom": c.nom}


@router.put("/clients/{client_id}")
def modifier_client(client_id: int, d: ClientIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    if _role(u) not in VEND:
        raise HTTPException(status_code=403, detail="Le Comptable consulte seulement.")
    c = charger(db, FermeClient, client_id, "Client introuvable.")
    c.nom, c.telephone, c.note, c.actif = d.nom, d.telephone or None, d.note or None, d.actif
    enregistrer(db, f"Le client « {d.nom} » existe déjà.")
    return {"id": c.id, "nom": c.nom}


# ---------- Pour la trésorerie, la comptabilité et le résultat ----------

def reglements(db: SessionDB, debut: date | None = None, fin: date | None = None):
    q = db.query(FermeReglement).options(selectinload(FermeReglement.vente).selectinload(FermeVente.client))
    if debut is not None:
        q = q.filter(FermeReglement.date_reglement >= debut)
    if fin is not None:
        q = q.filter(FermeReglement.date_reglement <= fin)
    return q.order_by(FermeReglement.date_reglement, FermeReglement.id).all()


def ventes_validees(db: SessionDB, debut: date, fin: date):
    return (db.query(FermeVente).options(selectinload(FermeVente.client), selectinload(FermeVente.lignes))
            .filter(FermeVente.annulee.is_(False), FermeVente.date_vente >= debut, FermeVente.date_vente <= fin)
            .order_by(FermeVente.date_vente, FermeVente.id).all())


def alertes(db: SessionDB, u: Utilisateur) -> list[tuple[str, str, str, str]]:
    if _role(u) not in ENCAISSE:
        return []
    credits = [v for v in _ventes(db).filter(FermeVente.annulee.is_(False)) if v.total - paye(v) > 0]
    if not credits:
        return []
    total = sum((v.total - paye(v) for v in credits), ZERO)
    return [("ferme-credits", "info", f"Les clients de la ferme doivent {montant(total):,} F".replace(",", " "),
             f"{len(credits)} vente{'s' if len(credits) > 1 else ''} à crédit : Ferme → Ventes.")]
