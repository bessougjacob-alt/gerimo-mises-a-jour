"""Ferme : module « Rentabilité » (22/11/2026, demande de Boss) — revenus, charges, pertes, rendements, bénéfice.

« Un module qui traitera de revenus, rendements, rentabilité, pertes… les choses essentielles du business même. »
- Par bande (toute sa vie) : revenus (ventes), charges (achat des animaux, aliment consommé et produits utilisés au
  prix d'achat moyen, vétérinaire), pertes (animaux morts estimés à leur coût, morts-nés, œufs cassés), rendements
  (aliment pour 1 kg vendu, œufs pour 100 poules, lait, poids vendu), prix de revient, bénéfice ou perte.
- Pour la ferme sur une période : revenus des ventes, charges (achats de la ferme, achat des animaux, dépenses de
  l'entreprise), pertes, résultat, mois par mois, par espèce, bandes qui rapportent le plus et le moins.
Consultation : Admin, Caisse, Comptable (les chiffres d'argent) ; le chef de ferme n'y a pas accès.
"""
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session as SessionDB, selectinload

from commun import montant
from models import (Depense, FermeBande, FermeEspece, FermeLigneVente, FermeMouvement, FermeNaissance, FermeProduit,
                    FermeVente, FermeVisite, Utilisateur)
from securite import exiger_module, get_db

router = APIRouter(prefix="/api/ferme")
acces = exiger_module("ferme")
ZERO = Decimal(0)
VOIT = ("Admin", "Caisse", "Comptable")


def _m(v) -> int:
    return int(Decimal(v or 0).quantize(Decimal("1")))


def _couts(db: SessionDB) -> tuple[dict[int, Decimal], Decimal]:
    """Prix moyen d'achat de chaque produit, et prix moyen d'un kg d'aliment (pour l'aliment « pas pris du stock »)."""
    from ferme_stock import couts_moyens
    couts = couts_moyens(db)
    aliments = [couts[p.id] for p in db.query(FermeProduit).filter(FermeProduit.categorie == "Aliment") if p.id in couts]
    return couts, (sum(aliments, ZERO) / len(aliments)) if aliments else ZERO


def bilan_bande(b: FermeBande, couts: dict, kg_moyen: Decimal, lignes: list, mouvements: list, visites: list,
                depenses: list | None = None) -> dict:
    import ferme
    c = ferme.chiffres(b)
    achat = b.cout_achat or ZERO
    aliment = ZERO
    for s in b.suivis:
        if s.aliment_kg:
            aliment += s.aliment_kg * (couts.get(s.produit_id, kg_moyen) if s.produit_id else kg_moyen)
    produits = sum((-m.quantite * couts.get(m.produit_id, ZERO) for m in mouvements if m.suivi_id is None), ZERO)
    # vétérinaire : visites sans dépense rattachée (une visite payée crée sa dépense, comptée une seule fois)
    ids_dep = {d.id for d in (depenses or [])}
    veto = sum((v.cout or ZERO for v in visites if not (v.depense_id and v.depense_id in ids_dep)), ZERO)
    autres = sum((d.montant for d in (depenses or [])), ZERO)    # dépenses rattachées à la bande (salaires, électricité…)
    charges = achat + aliment + produits + veto + autres
    revenus = sum((l.montant for l in lignes), ZERO)
    vendus = sum((l.quantite for l in lignes if l.genre == "Animaux"), ZERO)
    poids_vendu = sum((l.poids_kg or ZERO for l in lignes if l.genre == "Animaux"), ZERO)
    oeufs_vendus = sum((l.quantite for l in lignes if l.genre == "Œufs"), ZERO)
    entres = b.effectif_depart + c["naissances"]
    cout_tete = (achat + aliment + produits) / entres if entres else ZERO
    pertes_morts = cout_tete * c["morts"]
    oeufs_casses = sum(s.oeufs_casses for s in b.suivis)
    jours_ponte = [s for s in b.suivis if s.oeufs]
    ponte_moy = None
    if jours_ponte and b.effectif_depart:
        ponte_moy = round(sum(s.oeufs for s in jours_ponte) / len(jours_ponte) / max(c["vivants"] or b.effectif_depart, 1) * 100, 1)
    benefice = revenus - charges
    return {"id": b.id, "numero": b.numero, "nom": b.nom or b.type_elevage, "espece": b.type_elevage, "dessin": b.espece.dessin,
            "batiment": b.poulailler.nom, "statut": b.statut, "date_arrivee": b.date_arrivee.isoformat(),
            "date_fin": b.date_fin.isoformat() if b.date_fin else None, "age_jours": c["age_jours"],
            "effectif": b.effectif_depart, "naissances": c["naissances"], "morts": c["morts"], "vivants": c["vivants"],
            "mortalite": c["mortalite"], "vendus": _m(vendus), "poids_vendu": float(poids_vendu),
            "revenus": _m(revenus), "charges": _m(charges), "benefice": _m(benefice),
            "detail_charges": {"achat": _m(achat), "aliment": _m(aliment), "produits": _m(produits), "veterinaire": _m(veto),
                               "depenses": _m(autres)},
            "pertes": {"morts": c["morts"], "valeur_morts": _m(pertes_morts), "oeufs_casses": oeufs_casses},
            "rendements": {"aliment_kg": c["aliment_kg"],
                           "indice_conso": round(c["aliment_kg"] / float(poids_vendu), 2) if poids_vendu else None,
                           "oeufs": c["oeufs_total"], "oeufs_vendus": _m(oeufs_vendus), "ponte_moyenne": ponte_moy,
                           "lait_litres": c["lait_total"],
                           "poids_moyen_vendu": round(float(poids_vendu / vendus), 2) if vendus and poids_vendu else None},
            "prix_revient": {"animal": _m(charges / vendus) if vendus else None,
                             "kg": _m(charges / poids_vendu) if poids_vendu else None,
                             "oeuf": round(float(charges / c["oeufs_total"]), 1) if c["oeufs_total"] else None,
                             "litre": _m(charges / Decimal(str(c["lait_total"]))) if c["lait_total"] else None},
            "marge_pct": round(float(benefice / revenus * 100), 1) if revenus else None}


def _mois(debut: date, fin: date) -> list[tuple[date, date]]:
    mois, courant = [], debut.replace(day=1)
    while courant <= fin:
        suivant = (courant.replace(day=28) + timedelta(days=4)).replace(day=1)
        mois.append((max(courant, debut), min(suivant - timedelta(days=1), fin)))
        courant = suivant
    return mois


@router.get("/rentabilite")
def rentabilite(debut: date | None = Query(None), fin: date | None = Query(None), u: Utilisateur = Depends(acces),
                db: SessionDB = Depends(get_db)):
    if u.role.value not in VOIT:
        raise HTTPException(status_code=403, detail="La rentabilité (chiffres d'argent) est réservée à l'Admin, à la Caisse et au Comptable.")
    fin = fin or date.today()
    debut = debut or fin.replace(month=1, day=1)
    if debut > fin:
        raise HTTPException(status_code=400, detail="La date de début est après la date de fin.")
    couts, kg_moyen = _couts(db)

    # ---------- par bande (toute la vie de la bande) : celles qui ont vécu pendant la période ----------
    bandes = (db.query(FermeBande).options(selectinload(FermeBande.suivis), selectinload(FermeBande.poulailler),
                                           selectinload(FermeBande.portees))
              .filter(FermeBande.date_arrivee <= fin).all())
    bandes = [b for b in bandes if b.statut == "En cours" or not b.date_fin or b.date_fin >= debut]
    ids = [b.id for b in bandes] or [0]
    lignes = defaultdict(list)
    for l in db.query(FermeLigneVente).join(FermeVente).filter(FermeVente.annulee.is_(False), FermeLigneVente.bande_id.in_(ids)):
        lignes[l.bande_id].append(l)
    mouvements = defaultdict(list)
    for m in db.query(FermeMouvement).filter(FermeMouvement.bande_id.in_(ids), FermeMouvement.genre == "Utilisation"):
        mouvements[m.bande_id].append(m)
    visites = defaultdict(list)
    for v in db.query(FermeVisite).filter(FermeVisite.bande_id.in_(ids)):
        visites[v.bande_id].append(v)
    depenses_bande = defaultdict(list)
    for d in db.query(Depense).filter(Depense.ferme_bande_id.in_(ids)):
        depenses_bande[d.ferme_bande_id].append(d)
    par_bande = [bilan_bande(b, couts, kg_moyen, lignes[b.id], mouvements[b.id], visites[b.id], depenses_bande[b.id]) for b in bandes]
    par_bande.sort(key=lambda x: -x["benefice"])

    # ---------- la ferme sur la période ----------
    from ferme_stock import achats_completes
    ventes = (db.query(FermeVente).options(selectinload(FermeVente.lignes))
              .filter(FermeVente.annulee.is_(False), FermeVente.date_vente >= debut, FermeVente.date_vente <= fin).all())
    revenus = sum((v.total for v in ventes), ZERO)
    revenus_genre = defaultdict(lambda: ZERO)
    revenus_espece = defaultdict(lambda: ZERO)
    for v in ventes:
        for l in v.lignes:
            revenus_genre[l.genre] += l.montant
            revenus_espece[l.espece or "Autre"] += l.montant
    achats = achats_completes(db, debut, fin)
    achats_ferme = sum((a.montant_total for a in achats), ZERO)
    animaux_achetes = sum((b.cout_achat or ZERO for b in bandes if debut <= b.date_arrivee <= fin), ZERO)
    depenses = db.query(Depense).filter(Depense.a_la_charge_de != "Propriétaire", Depense.date_depense >= debut, Depense.date_depense <= fin).all()
    total_depenses = sum((d.montant for d in depenses), ZERO)
    depenses_categorie = defaultdict(lambda: ZERO)
    for d in depenses:
        depenses_categorie[d.categorie] += d.montant
    charges = achats_ferme + animaux_achetes + total_depenses

    # pertes de la période : animaux morts (au coût d'une tête de leur bande), produits perdus, œufs cassés, morts-nés
    cout_tete = {x["id"]: (Decimal(x["detail_charges"]["achat"] + x["detail_charges"]["aliment"] + x["detail_charges"]["produits"])
                           / (x["effectif"] + x["naissances"])) if x["effectif"] + x["naissances"] else ZERO for x in par_bande}
    morts_periode, valeur_morts, oeufs_casses = 0, ZERO, 0
    morts_espece = defaultdict(int)
    for b in bandes:
        for s in b.suivis:
            if debut <= s.date_suivi <= fin:
                morts_periode += s.morts
                morts_espece[b.type_elevage] += s.morts
                valeur_morts += cout_tete.get(b.id, ZERO) * s.morts
                oeufs_casses += s.oeufs_casses
    pertes_produits = sum((-m.quantite * couts.get(m.produit_id, ZERO) for m in db.query(FermeMouvement).filter(
        FermeMouvement.genre == "Perte", FermeMouvement.date_mouvement >= debut, FermeMouvement.date_mouvement <= fin)), ZERO)
    morts_nes = sum(n.morts_nes for n in db.query(FermeNaissance).filter(FermeNaissance.date_naissance >= debut, FermeNaissance.date_naissance <= fin))

    # mois par mois
    par_mois = []
    for d1, d2 in _mois(debut, fin):
        r = sum((v.total for v in ventes if d1 <= v.date_vente <= d2), ZERO)
        ch = (sum((a.montant_total for a in achats if d1 <= a.date_achat <= d2), ZERO)
              + sum((b.cout_achat or ZERO for b in bandes if d1 <= b.date_arrivee <= d2), ZERO)
              + sum((d.montant for d in depenses if d1 <= d.date_depense <= d2), ZERO))
        par_mois.append({"mois": d1.strftime("%m/%Y"), "revenus": _m(r), "charges": _m(ch), "resultat": _m(r - ch)})

    # par espèce : revenus de la période, et coût de ce que ses bandes ont consommé pendant la période
    par_espece = defaultdict(lambda: {"revenus": ZERO, "charges": ZERO, "morts": 0, "animaux": 0})
    for k, v in revenus_espece.items():
        par_espece[k]["revenus"] += v
    for b in bandes:
        e = par_espece[b.type_elevage]
        if debut <= b.date_arrivee <= fin:
            e["charges"] += b.cout_achat or ZERO
        for s in b.suivis:
            if debut <= s.date_suivi <= fin and s.aliment_kg:
                e["charges"] += s.aliment_kg * (couts.get(s.produit_id, kg_moyen) if s.produit_id else kg_moyen)
        e["charges"] += sum((-m.quantite * couts.get(m.produit_id, ZERO) for m in mouvements[b.id]
                             if m.suivi_id is None and debut <= m.date_mouvement <= fin), ZERO)
        e["charges"] += sum((v.cout or ZERO for v in visites[b.id] if debut <= v.date_visite <= fin), ZERO)
        e["charges"] += sum((d.montant for d in depenses_bande[b.id] if debut <= d.date_depense <= fin
                             and not any(v.depense_id == d.id for v in visites[b.id])), ZERO)
        e["morts"] += morts_espece.get(b.type_elevage, 0) if e["animaux"] == 0 else 0
        e["animaux"] += 1
    dessins = {e.nom: e.dessin for e in db.query(FermeEspece)}
    especes = sorted(({"espece": k, "dessin": dessins.get(k, "animal"), "revenus": _m(v["revenus"]), "charges": _m(v["charges"]),
                       "resultat": _m(v["revenus"] - v["charges"]), "morts": morts_espece.get(k, 0)} for k, v in par_espece.items()),
                     key=lambda x: -x["resultat"])

    resultat = revenus - charges
    return {"debut": debut.isoformat(), "fin": fin.isoformat(),
            "total": {"revenus": _m(revenus), "charges": _m(charges), "resultat": _m(resultat),
                      "marge_pct": round(float(resultat / revenus * 100), 1) if revenus else None,
                      "ventes": len(ventes)},
            "revenus_par_genre": {k: _m(v) for k, v in revenus_genre.items()},
            "charges_detail": {"Aliments et produits achetés": _m(achats_ferme), "Achat des animaux": _m(animaux_achetes),
                               **{f"Dépenses : {k}": _m(v) for k, v in sorted(depenses_categorie.items(), key=lambda x: -x[1])}},
            "pertes": {"morts": morts_periode, "valeur_morts": _m(valeur_morts), "produits_perdus": _m(pertes_produits),
                       "oeufs_casses": oeufs_casses, "morts_nes": morts_nes, "total": _m(valeur_morts + pertes_produits)},
            "par_mois": par_mois, "par_espece": especes, "par_bande": par_bande,
            "note": "Les dépenses de l'entreprise comptent pour toute la ferme. Le bénéfice d'un lot compte son achat, son "
                    "aliment, ses produits, ses visites du vétérinaire et les dépenses rattachées à elle (salaires, électricité…)."}


@router.get("/rentabilite/pdf")
def rentabilite_pdf(debut: date | None = Query(None), fin: date | None = Query(None), u: Utilisateur = Depends(acces),
                    db: SessionDB = Depends(get_db)):
    """Bilan imprimable de la période (mêmes droits et mêmes chiffres que l'écran Rentabilité)."""
    import recus
    from fastapi.responses import Response
    r = rentabilite(debut, fin, u, db)
    nom = f"Bilan-ferme-{r['debut']}-au-{r['fin']}.pdf"
    return Response(recus.bilan_ferme_pdf(r), media_type="application/pdf", headers={"Content-Disposition": f'inline; filename="{nom}"'})
