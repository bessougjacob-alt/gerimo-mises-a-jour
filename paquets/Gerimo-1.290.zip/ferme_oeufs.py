"""Ferme (22/11/2026) : œufs et couvoir — stock d'œufs en plateaux, couvaisons (couveuse ou poules), mirage, éclosion.

Décisions de Boss (22/11/2026) — voir migrations/055_ferme_oeufs.sql :
- Stock d'œufs = œufs ramassés (suivi du jour) + achats et corrections − ventes d'œufs − œufs mis à couver (du stock)
  − œufs mangés à la maison ou perdus. Affiché en œufs et en plateaux de 30.
- Couvaison : couveuse (machine) ou poules couveuses ; œufs du stock ou achetés. Mirage (œufs clairs retirés) ;
  éclosion prévue selon l'espèce. À l'éclosion, les poussins vont dans un nouveau lot, dans un lot existant, ou à la vente.
- Rôles : Admin et chef de ferme (Gestionnaire) ; prix des œufs achetés : Admin et Caisse ; correction du stock et
  suppression : Admin (mot de passe) ; Caisse et Comptable : consultation.
"""
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from sqlalchemy import func
from sqlalchemy.orm import Session as SessionDB, selectinload

from commun import Formulaire, Suppression, Texte, charger, enregistrer, montant, numero_suivant
from models import (FermeBande, FermeCouvaison, FermeEspece, FermeLigneVente, FermeNaissance, FermeOeufMouvement,
                    FermePoulailler, FermeSuivi, FermeVente, Utilisateur)
from securite import exiger_admin, exiger_module, get_db, verifier_mot_de_passe

router = APIRouter(prefix="/api/ferme")
acces = exiger_module("ferme")
SOIGNE = ("Admin", "Gestionnaire")
ARGENT = ("Admin", "Caisse", "Comptable")
PLATEAU = 30


def _role(u: Utilisateur) -> str:
    return u.role.value


def _exiger(u: Utilisateur) -> None:
    if _role(u) not in SOIGNE:
        raise HTTPException(status_code=403, detail="Les œufs et le couvoir sont tenus par le chef de ferme (Gestionnaire) ou l'Admin.")


def plateaux(n: int) -> str:
    p, reste = divmod(max(int(n), 0), PLATEAU)
    if not p:
        return f"{reste} œuf{'s' if reste > 1 else ''}"
    return f"{p} plateau{'x' if p > 1 else ''}" + (f" et {reste} œuf{'s' if reste > 1 else ''}" if reste else "")


# ---------- Stock d'œufs ----------

def stock_oeufs(db: SessionDB) -> dict:
    ramasses = db.query(func.coalesce(func.sum(FermeSuivi.oeufs), 0)).scalar() or 0
    manuels = db.query(func.coalesce(func.sum(FermeOeufMouvement.quantite), 0)).scalar() or 0
    vendus = (db.query(func.coalesce(func.sum(FermeLigneVente.quantite), 0)).join(FermeVente)
              .filter(FermeVente.annulee.is_(False), FermeLigneVente.genre == "Œufs").scalar() or 0)
    couves = (db.query(func.coalesce(func.sum(FermeCouvaison.nombre_oeufs), 0))
              .filter(FermeCouvaison.origine == "Stock").scalar() or 0)
    stock = int(ramasses) + int(manuels) - int(Decimal(vendus)) - int(couves)
    return {"ramasses": int(ramasses), "manuels": int(manuels), "vendus": int(Decimal(vendus)), "couves": int(couves),
            "stock": stock, "plateaux": plateaux(stock)}


def verifier_stock(db: SessionDB, besoin: int, quoi: str) -> None:
    st = stock_oeufs(db)["stock"]
    if besoin > st:
        raise HTTPException(status_code=409, detail=f"Il n'y a que {plateaux(st)} en stock ({st} œufs) pour {quoi}.")


@router.get("/oeufs")
def tableau_oeufs(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    st = stock_oeufs(db)
    debut = date.today() - timedelta(days=29)
    par_jour = defaultdict(int)
    for s in db.query(FermeSuivi).filter(FermeSuivi.date_suivi >= debut, FermeSuivi.oeufs > 0):
        par_jour[s.date_suivi.isoformat()] += s.oeufs
    casses = db.query(func.coalesce(func.sum(FermeSuivi.oeufs_casses), 0)).filter(FermeSuivi.date_suivi >= debut).scalar() or 0
    mouvements = (db.query(FermeOeufMouvement).options(selectinload(FermeOeufMouvement.auteur))
                  .order_by(FermeOeufMouvement.date_mouvement.desc(), FermeOeufMouvement.id.desc()).limit(100).all())
    return {**st, "par_jour": [{"date": j, "oeufs": n} for j, n in sorted(par_jour.items())],
            "ramasses_30j": sum(par_jour.values()), "casses_30j": int(casses),
            "mouvements": [{"id": m.id, "date": m.date_mouvement.isoformat(), "genre": m.genre, "quantite": m.quantite,
                            "motif": m.motif or "", "saisi_par": m.auteur.nom_complet if m.auteur else ""} for m in mouvements],
            "soigne": _role(u) in SOIGNE, "est_admin": _role(u) == "Admin"}


class OeufsIn(Formulaire):
    genre: Literal["Maison", "Perte", "Correction", "Achat"]
    quantite: int = Field(ge=0, le=1_000_000)     # sortie ou entrée ; correction : œufs comptés
    motif: Texte | None = Field(None, max_length=200)
    date_mouvement: date | None = None


@router.post("/oeufs/mouvements")
def mouvement_oeufs(d: OeufsIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u)
    jour = d.date_mouvement or date.today()
    if jour > date.today():
        raise HTTPException(status_code=400, detail="La date ne peut pas être dans le futur.")
    st = stock_oeufs(db)["stock"]
    if d.genre == "Correction":
        if _role(u) != "Admin":
            raise HTTPException(status_code=403, detail="Seul l'Admin corrige le stock d'œufs après un comptage.")
        quantite = d.quantite - st
        if quantite == 0:
            raise HTTPException(status_code=400, detail="Le stock compté est déjà celui de Gérimo.")
    elif d.genre == "Achat":
        if d.quantite <= 0:
            raise HTTPException(status_code=400, detail="Indiquez le nombre d'œufs.")
        quantite = d.quantite
    else:
        if d.quantite <= 0:
            raise HTTPException(status_code=400, detail="Indiquez le nombre d'œufs.")
        verifier_stock(db, d.quantite, "cette sortie")
        if d.genre == "Perte" and not d.motif:
            raise HTTPException(status_code=400, detail="Dites pourquoi (exemple : cassés au transport, pourris).")
        quantite = -d.quantite
    db.add(FermeOeufMouvement(date_mouvement=jour, genre=d.genre, quantite=quantite, motif=d.motif or None, saisi_par=u.id))
    enregistrer(db, "Enregistrement impossible.")
    return stock_oeufs(db)


# ---------- Couvoir ----------

def couvaison_json(c: FermeCouvaison, u: Utilisateur) -> dict:
    e = c.espece_obj
    aujourdhui = date.today()
    mirage = (c.date_mise + timedelta(days=e.mirage_jours)) if e.mirage_jours else None
    jours = (min(c.date_eclosion or aujourdhui, aujourdhui) - c.date_mise).days
    fecondes = c.nombre_oeufs - c.oeufs_clairs
    d = {"id": c.id, "numero": c.numero, "espece": c.espece, "dessin": e.dessin, "date_mise": c.date_mise.isoformat(),
         "nombre_oeufs": c.nombre_oeufs, "origine": c.origine, "methode": c.methode, "couveuse": c.couveuse or "",
         "mirage_prevu": mirage.isoformat() if mirage else None, "date_mirage": c.date_mirage.isoformat() if c.date_mirage else None,
         "oeufs_clairs": c.oeufs_clairs, "fecondes": fecondes,
         "eclosion_prevue": c.eclosion_prevue.isoformat() if c.eclosion_prevue else None,
         "date_eclosion": c.date_eclosion.isoformat() if c.date_eclosion else None, "eclos": c.eclos,
         "non_eclos": (fecondes - c.eclos) if c.eclos is not None else None,
         "taux_fecondite": round(fecondes * 100 / c.nombre_oeufs, 1) if c.date_mirage and c.nombre_oeufs else None,
         "taux_eclosion": round(c.eclos * 100 / c.nombre_oeufs, 1) if c.eclos is not None and c.nombre_oeufs else None,
         "eclosion_sur_fecondes": round(c.eclos * 100 / fecondes, 1) if c.eclos is not None and fecondes else None,
         "jours": jours, "duree": e.incubation_jours, "destination": c.destination or "", "lot_id": c.lot_id,
         "lot": (c.lot.nom or f"{c.lot.type_elevage} ({c.lot.numero})") if c.lot else "", "statut": c.statut, "note": c.note or ""}
    if _role(u) in ARGENT:
        d["cout_oeufs"] = montant(c.cout_oeufs) if c.cout_oeufs is not None else None
    return d


@router.get("/couvoir")
def tableau_couvoir(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    couv = (db.query(FermeCouvaison).options(selectinload(FermeCouvaison.lot))
            .order_by(FermeCouvaison.statut != "En cours", FermeCouvaison.date_mise.desc()).limit(300).all())
    finies = [c for c in couv if c.statut == "Éclose"]
    mis = sum(c.nombre_oeufs for c in finies)
    eclos = sum(c.eclos or 0 for c in finies)
    fecondes = sum(c.nombre_oeufs - c.oeufs_clairs for c in finies if c.date_mirage)
    mis_mirage = sum(c.nombre_oeufs for c in finies if c.date_mirage)
    especes = db.query(FermeEspece).filter(FermeEspece.actif, FermeEspece.incubation_jours.isnot(None)).order_by(FermeEspece.ordre).all()
    lots = db.query(FermeBande).filter(FermeBande.statut == "En cours").order_by(FermeBande.date_arrivee.desc()).all()
    return {"couvaisons": [couvaison_json(c, u) for c in couv], "stock": stock_oeufs(db),
            "bilan": {"couvaisons": len(finies), "oeufs": mis, "eclos": eclos,
                      "taux_eclosion": round(eclos * 100 / mis, 1) if mis else None,
                      "taux_fecondite": round(fecondes * 100 / mis_mirage, 1) if mis_mirage else None},
            "especes": [{"nom": e.nom, "dessin": e.dessin, "incubation_jours": e.incubation_jours, "mirage_jours": e.mirage_jours} for e in especes],
            "lots": [{"id": b.id, "nom": b.nom or b.type_elevage, "espece": b.type_elevage, "batiment": b.poulailler.nom} for b in lots],
            "batiments": [{"id": p.id, "nom": p.nom} for p in db.query(FermePoulailler).filter(FermePoulailler.actif).order_by(FermePoulailler.nom)],
            "soigne": _role(u) in SOIGNE, "argent": _role(u) in ("Admin", "Caisse"), "est_admin": _role(u) == "Admin"}


class CouvaisonIn(Formulaire):
    espece: Texte = Field(min_length=2, max_length=40)
    date_mise: date | None = None
    nombre_oeufs: int = Field(gt=0, le=100000)
    origine: Literal["Stock", "Achetés"] = "Stock"
    cout_oeufs: Decimal | None = Field(None, ge=0, max_digits=14, decimal_places=2)
    methode: Literal["Couveuse", "Poules"] = "Couveuse"
    couveuse: Texte | None = Field(None, max_length=80)
    note: Texte | None = Field(None, max_length=300)


@router.post("/couvoir")
def mettre_a_couver(d: CouvaisonIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u)
    e = db.query(FermeEspece).filter(FermeEspece.nom == d.espece).first()
    if e is None or not e.incubation_jours:
        raise HTTPException(status_code=400, detail="Choisissez une espèce qui pond (durée de couvaison connue).")
    jour = d.date_mise or date.today()
    if jour > date.today():
        raise HTTPException(status_code=400, detail="La date ne peut pas être dans le futur.")
    if d.origine == "Stock":
        verifier_stock(db, d.nombre_oeufs, "cette couvaison")
    c = FermeCouvaison(numero=numero_suivant(db, FermeCouvaison.numero, f"COU-{jour.year}", 3), espece=e.nom, date_mise=jour,
                       nombre_oeufs=d.nombre_oeufs, origine=d.origine, methode=d.methode, couveuse=d.couveuse or None,
                       cout_oeufs=d.cout_oeufs if d.origine == "Achetés" and _role(u) in ("Admin", "Caisse") else None,
                       eclosion_prevue=jour + timedelta(days=e.incubation_jours), note=d.note or None, saisi_par=u.id)
    db.add(c)
    enregistrer(db, "Enregistrement impossible.")
    db.refresh(c)
    return couvaison_json(c, u)


class MirageIn(Formulaire):
    date_mirage: date | None = None
    oeufs_clairs: int = Field(ge=0, le=100000)


@router.post("/couvoir/{couv_id}/mirage")
def mirage(couv_id: int, d: MirageIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u)
    c = charger(db, FermeCouvaison, couv_id, "Couvaison introuvable.")
    if c.statut != "En cours":
        raise HTTPException(status_code=409, detail="Cette couvaison est finie.")
    if d.oeufs_clairs > c.nombre_oeufs:
        raise HTTPException(status_code=400, detail="Plus d'œufs clairs que d'œufs mis à couver.")
    jour = d.date_mirage or date.today()
    if jour > date.today() or jour < c.date_mise:
        raise HTTPException(status_code=400, detail="Date du mirage incorrecte.")
    c.date_mirage, c.oeufs_clairs = jour, d.oeufs_clairs
    if d.oeufs_clairs == c.nombre_oeufs:
        c.statut = "Échouée"   # aucun œuf fécondé
    enregistrer(db, "Enregistrement impossible.")
    return couvaison_json(c, u)


class EclosionIn(Formulaire):
    date_eclosion: date | None = None
    eclos: int = Field(ge=0, le=100000)
    destination: Literal["Nouveau lot", "Lot existant", "Vente"] = "Nouveau lot"
    lot_id: int | None = None                # lot existant
    poulailler_id: int | None = None         # nouveau lot
    nom_lot: Texte | None = Field(None, max_length=100)


@router.post("/couvoir/{couv_id}/eclosion")
def eclosion(couv_id: int, d: EclosionIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u)
    c = charger(db, FermeCouvaison, couv_id, "Couvaison introuvable.")
    if c.statut != "En cours":
        raise HTTPException(status_code=409, detail="Cette couvaison est déjà finie.")
    if d.eclos > c.nombre_oeufs - c.oeufs_clairs:
        raise HTTPException(status_code=400, detail=f"Au plus {c.nombre_oeufs - c.oeufs_clairs} poussins (œufs fécondés).")
    jour = d.date_eclosion or date.today()
    if jour > date.today() or jour < c.date_mise:
        raise HTTPException(status_code=400, detail="Date d'éclosion incorrecte.")
    # toutes les vérifications avant de changer quoi que ce soit
    p = lot = None
    if d.eclos and d.destination == "Nouveau lot":
        if d.poulailler_id is None:
            raise HTTPException(status_code=400, detail="Choisissez le bâtiment du nouveau lot.")
        p = charger(db, FermePoulailler, d.poulailler_id, "Bâtiment introuvable.")
    if d.eclos and d.destination == "Lot existant":
        lot = charger(db, FermeBande, d.lot_id, "Lot introuvable.") if d.lot_id else None
        if lot is None or lot.statut != "En cours" or lot.type_elevage != c.espece:
            raise HTTPException(status_code=400, detail="Choisissez un lot en cours de la même espèce.")
    c.date_eclosion, c.eclos, c.statut = jour, d.eclos, "Éclose" if d.eclos else "Échouée"
    if d.eclos:
        c.destination = d.destination
        if d.destination == "Nouveau lot":   # un nouveau lot avec les poussins éclos (âge 0 jour)
            lot = FermeBande(numero=numero_suivant(db, FermeBande.numero, f"LOT-{date.today().year}", 3), type_elevage=c.espece,
                             poulailler_id=p.id, nom=d.nom_lot or f"Éclosion {c.numero}", date_arrivee=jour, age_arrivee=0,
                             effectif_depart=d.eclos, fournisseur="Couvoir de la ferme", cout_achat=c.cout_oeufs,
                             note=f"Poussins de la couvaison {c.numero}", saisi_par=u.id)
            db.add(lot)
            db.flush()
            c.lot_id = lot.id
        elif d.destination == "Lot existant":   # comptés dans le lot comme une portée
            c.lot_id = lot.id
            db.add(FermeNaissance(numero=numero_suivant(db, FermeNaissance.numero, f"NAI-{jour.year}", 4), espece=c.espece,
                                  date_naissance=jour, mere_texte=f"Couvaison {c.numero}", nes_vivants=d.eclos,
                                  destination="Bande", bande_id=lot.id, couvaison_id=c.id, saisi_par=u.id))
    enregistrer(db, "Enregistrement impossible.")
    db.refresh(c)
    return couvaison_json(c, u)


@router.post("/couvoir/{couv_id}/supprimer")
def supprimer_couvaison(couv_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été supprimé.")
    c = charger(db, FermeCouvaison, couv_id, "Couvaison introuvable.")
    if c.statut == "Éclose" and c.destination == "Nouveau lot":
        raise HTTPException(status_code=409, detail="Les poussins forment déjà un lot : supprimez ou terminez d'abord ce lot.")
    db.delete(c)   # les œufs pris du stock y reviennent ; les poussins comptés dans un lot en ressortent
    enregistrer(db, "Suppression impossible.")
    return {"ok": True}


# ---------- Agenda et assistant ----------

def evenements_prevus(db: SessionDB, debut: date, fin: date) -> dict[str, list[str]]:
    par = defaultdict(list)
    for c in db.query(FermeCouvaison).filter(FermeCouvaison.statut == "En cours"):
        e = c.espece_obj
        if e.mirage_jours and not c.date_mirage:
            j = c.date_mise + timedelta(days=e.mirage_jours)
            if debut <= j <= fin:
                par[j.isoformat()].append(f"Mirage — couvaison {c.numero} ({c.nombre_oeufs} œufs, {c.espece.lower()})")
        if c.eclosion_prevue and debut <= c.eclosion_prevue <= fin:
            par[c.eclosion_prevue.isoformat()].append(f"Éclosion prévue — couvaison {c.numero} ({c.espece.lower()})")
    return dict(par)


def alertes(db: SessionDB, u: Utilisateur) -> list[tuple[str, str, str, str]]:
    resultat = []
    aujourdhui = date.today()
    for c in db.query(FermeCouvaison).filter(FermeCouvaison.statut == "En cours"):
        e = c.espece_obj
        if e.mirage_jours and not c.date_mirage and c.date_mise + timedelta(days=e.mirage_jours) <= aujourdhui:
            resultat.append((f"ferme-mirage-{c.id}", "info", f"Couvaison {c.numero} : mirage à faire",
                             "Retirez les œufs clairs (pas fécondés) et notez-les (Ferme → Couvoir)."))
        if c.eclosion_prevue and c.eclosion_prevue <= aujourdhui + timedelta(days=1):
            retard = c.eclosion_prevue < aujourdhui
            resultat.append((f"ferme-eclosion-{c.id}", "attention" if retard else "info",
                             f"Couvaison {c.numero} : éclosion {'prévue le ' + c.eclosion_prevue.strftime('%d/%m/%Y') + ' pas encore notée' if retard else 'aujourd’hui ou demain'}",
                             "Comptez les poussins éclos et choisissez leur lot (Ferme → Couvoir)."))
    return resultat
