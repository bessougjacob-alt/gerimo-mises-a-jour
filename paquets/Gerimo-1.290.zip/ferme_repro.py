"""Ferme, étape 4 (22/11/2026) : reproduction et animaux — fiches individuelles, accouplements, naissances,
modèles de fiche technique par espèce, statistiques.

Décisions de Boss (22/11/2026) — voir migrations/051_ferme_reproduction.sql et 052_ferme_modeles.sql :
- L'âge d'un animal = date de naissance si connue, sinon âge à l'arrivée + temps passé à la ferme.
- Fiches individuelles AU CHOIX (animaux étiquetés) : race, sexe, parents, génération (parents + 1), santé, pesées.
- Accouplements : en attente / réussi / non réussi ; gestation par espèce → contrôle et mise bas prévus.
- Naissances : les petits ont chacun leur fiche OU sont comptés dans une bande (au choix à chaque naissance).
- Modèle de fiche par espèce : races proposées, cases propres (robe, pelage, cornes…), repères.
- Statistiques par espèce : mâles et femelles, âges, poids, races les plus résistantes, mortalité, natalité, survie.
- Rôles : fiches, accouplements, naissances : Admin et chef de ferme (Gestionnaire) ; modèles et durées : Admin ;
  suppression : Admin (mot de passe) ; Caisse et Comptable : consultation.
"""
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import Field
from sqlalchemy.orm import Session as SessionDB, selectinload

from commun import Formulaire, Suppression, Texte, charger, enregistrer, montant, numero_suivant
from models import (FermeAccouplement, FermeBande, FermeEspece, FermeNaissance, FermePeseeSujet, FermePoulailler,
                    FermeSujet, Utilisateur)
from securite import exiger_admin, exiger_module, get_db, verifier_mot_de_passe

router = APIRouter(prefix="/api/ferme")
acces = exiger_module("ferme")
ECRIT = ("Admin", "Gestionnaire")
SEXES = ("Mâle", "Femelle", "Inconnu")
SANTES = ("Bonne santé", "Malade", "En traitement", "Blessé")
SORTIES = ("Vendu", "Mort", "Réformé")
CLASSES_AGE = [(30, "Moins d'1 mois"), (91, "1 à 3 mois"), (182, "3 à 6 mois"), (365, "6 à 12 mois"), (730, "1 à 2 ans"), (None, "Plus de 2 ans")]


def _role(u: Utilisateur) -> str:
    return u.role.value


def _ecrire(u: Utilisateur) -> None:
    if _role(u) not in ECRIT:
        raise HTTPException(status_code=403, detail="Les fiches des animaux sont tenues par le chef de ferme (Gestionnaire) ou l'Admin.")


def _espece(db: SessionDB, nom: str) -> FermeEspece:
    e = db.query(FermeEspece).filter(FermeEspece.nom == nom).first()
    if e is None:
        raise HTTPException(status_code=400, detail="Choisissez l'espèce dans la liste.")
    return e


# ---------- Âges ----------

def age_jours(s: FermeSujet, jour: date | None = None) -> int:
    jour = s.date_sortie if s.statut != "Présent" and s.date_sortie else (jour or date.today())
    if s.date_naissance:
        return max((jour - s.date_naissance).days, 0)
    return max((jour - s.date_arrivee).days + s.age_arrivee, 0)


def age_texte(jours: int) -> str:
    """« 12 jours », « 5 mois », « 2 ans 3 mois »."""
    if jours < 60:
        return f"{jours} jour{'s' if jours > 1 else ''}"
    mois = round(jours / 30.44)
    if mois < 12:
        return f"{mois} mois"
    ans, reste = divmod(mois, 12)
    return f"{ans} an{'s' if ans > 1 else ''}" + (f" {reste} mois" if reste else "")


def classe_age(jours: int) -> str:
    for limite, libelle in CLASSES_AGE:
        if limite is None or jours < limite:
            return libelle
    return CLASSES_AGE[-1][1]


# ---------- Fiches des animaux ----------

def nom_sujet(s: FermeSujet | None) -> str:
    if s is None:
        return ""
    return " ".join(x for x in (s.numero and f"n° {s.numero}", s.nom) if x) or f"{s.espece} #{s.id}"


def sujet_json(s: FermeSujet, complet: bool = False) -> dict:
    a = age_jours(s)
    derniere = s.pesees[-1] if s.pesees else None
    d = {"id": s.id, "numero": s.numero or "", "nom": s.nom or "", "libelle": nom_sujet(s), "espece": s.espece,
         "dessin": s.espece_obj.dessin, "race": s.race or "", "sexe": s.sexe, "generation": s.generation, "origine": s.origine,
         "date_naissance": s.date_naissance.isoformat() if s.date_naissance else None, "date_arrivee": s.date_arrivee.isoformat(),
         "age_arrivee": s.age_arrivee, "age_jours": a, "age_texte": age_texte(a),
         "a_la_ferme_jours": max(((s.date_sortie if s.statut != "Présent" and s.date_sortie else date.today()) - s.date_arrivee).days, 0),
         "mere_id": s.mere_id, "pere_id": s.pere_id, "mere": nom_sujet(s.mere), "pere": nom_sujet(s.pere),
         "bande_id": s.bande_id, "bande": (s.bande.nom or s.bande.type_elevage) if s.bande else "",
         "poulailler_id": s.poulailler_id, "batiment": s.batiment.nom if s.batiment else "",
         "reproducteur": s.reproducteur, "etat_sante": s.etat_sante, "statut": s.statut,
         "date_sortie": s.date_sortie.isoformat() if s.date_sortie else None, "cause_sortie": s.cause_sortie or "",
         "poids_kg": float(derniere.poids_kg) if derniere else None, "poids_le": derniere.date_pesee.isoformat() if derniere else None,
         "details": s.details or {}, "caracteristiques": s.caracteristiques or "", "note": s.note or ""}
    d["a_la_ferme_texte"] = age_texte(d["a_la_ferme_jours"])
    if complet:
        d["pesees"] = [{"id": p.id, "date": p.date_pesee.isoformat(), "poids_kg": float(p.poids_kg)} for p in s.pesees]
    return d


def _requete_sujets(db: SessionDB):
    return db.query(FermeSujet).options(selectinload(FermeSujet.mere), selectinload(FermeSujet.pere), selectinload(FermeSujet.bande),
                                        selectinload(FermeSujet.batiment), selectinload(FermeSujet.pesees))


def especes_json(db: SessionDB) -> list[dict]:
    return [{"nom": e.nom, "dessin": e.dessin, "groupe": e.groupe, "naissances": e.naissances, "gestation_jours": e.gestation_jours,
             "controle_jours": e.controle_jours, "sevrage_jours": e.sevrage_jours, "modele": e.modele or {}, "actif": e.actif}
            for e in db.query(FermeEspece).order_by(FermeEspece.ordre, FermeEspece.nom)]


@router.get("/animaux")
def liste_animaux(espece: str | None = None, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    q = _requete_sujets(db)
    if espece:
        q = q.filter(FermeSujet.espece == espece)
    sujets = q.order_by(FermeSujet.statut != "Présent", FermeSujet.espece, FermeSujet.numero, FermeSujet.id).all()
    bandes = db.query(FermeBande).filter(FermeBande.statut == "En cours").order_by(FermeBande.date_arrivee.desc()).all()
    return {"animaux": [sujet_json(s) for s in sujets], "especes": especes_json(db),
            "bandes": [{"id": b.id, "nom": b.nom or b.type_elevage, "espece": b.type_elevage, "batiment": b.poulailler.nom,
                        "poulailler_id": b.poulailler_id} for b in bandes],
            "batiments": [{"id": p.id, "nom": p.nom} for p in db.query(FermePoulailler).filter(FermePoulailler.actif).order_by(FermePoulailler.nom)],
            "sexes": SEXES, "santes": SANTES, "sorties": SORTIES, "ecrit": _role(u) in ECRIT, "est_admin": _role(u) == "Admin"}


@router.get("/animaux/{sujet_id}")
def fiche_animal(sujet_id: int, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    s = charger(db, FermeSujet, sujet_id, "Animal introuvable.")
    enfants = _requete_sujets(db).filter((FermeSujet.mere_id == s.id) | (FermeSujet.pere_id == s.id)).order_by(FermeSujet.date_naissance).all()
    portees = (db.query(FermeNaissance).filter((FermeNaissance.mere_id == s.id) | (FermeNaissance.pere_id == s.id))
               .order_by(FermeNaissance.date_naissance.desc()).all())
    accs = (db.query(FermeAccouplement).filter((FermeAccouplement.femelle_id == s.id) | (FermeAccouplement.male_id == s.id))
            .order_by(FermeAccouplement.date_accouplement.desc()).all())
    return {**sujet_json(s, complet=True), "modele": s.espece_obj.modele or {},
            "enfants": [sujet_json(x) for x in enfants], "portees": [naissance_json(n) for n in portees],
            "accouplements": [accouplement_json(a) for a in accs]}


class AnimalIn(Formulaire):
    numero: Texte | None = Field(None, max_length=30)
    nom: Texte | None = Field(None, max_length=60)
    espece: Texte = Field(min_length=2, max_length=40)
    race: Texte | None = Field(None, max_length=60)
    sexe: Literal[SEXES] = "Inconnu"
    date_naissance: date | None = None
    date_arrivee: date | None = None
    age_arrivee: int = Field(0, ge=0, le=20000)
    origine: Literal["Né à la ferme", "Acheté", "Autre"] = "Acheté"
    mere_id: int | None = None
    pere_id: int | None = None
    bande_id: int | None = None
    poulailler_id: int | None = None
    reproducteur: bool = False
    etat_sante: Literal[SANTES] = "Bonne santé"
    details: dict[str, str] = Field(default_factory=dict)
    caracteristiques: Texte | None = Field(None, max_length=300)   # yeux bleus, oreilles tombantes…
    note: Texte | None = Field(None, max_length=300)


def _parent(db: SessionDB, sid: int | None, espece: str, sexe: str, soi: int | None) -> FermeSujet | None:
    if sid is None:
        return None
    p = charger(db, FermeSujet, sid, "Parent introuvable.")
    if p.id == soi:
        raise HTTPException(status_code=400, detail="Un animal ne peut pas être son propre parent.")
    if p.espece != espece:
        raise HTTPException(status_code=400, detail=f"{nom_sujet(p)} n'est pas de la même espèce.")
    if p.sexe != sexe:
        raise HTTPException(status_code=400, detail=f"{nom_sujet(p)} n'est pas {'une femelle' if sexe == 'Femelle' else 'un mâle'}.")
    return p


def _appliquer_animal(db: SessionDB, s: FermeSujet, d: AnimalIn) -> None:
    e = _espece(db, d.espece)
    arrivee = d.date_arrivee or d.date_naissance or date.today()
    if arrivee > date.today() or (d.date_naissance and d.date_naissance > date.today()):
        raise HTTPException(status_code=400, detail="Une date ne peut pas être dans le futur.")
    if d.date_naissance and d.date_naissance > arrivee:
        raise HTTPException(status_code=400, detail="La naissance ne peut pas être après l'arrivée.")
    mere = _parent(db, d.mere_id, e.nom, "Femelle", s.id)
    pere = _parent(db, d.pere_id, e.nom, "Mâle", s.id)
    if d.bande_id is not None:
        b = charger(db, FermeBande, d.bande_id, "Lot introuvable.")
        if b.type_elevage != e.nom:
            raise HTTPException(status_code=400, detail="Ce lot n'est pas de la même espèce.")
    if d.poulailler_id is not None:
        charger(db, FermePoulailler, d.poulailler_id, "Bâtiment introuvable.")
    s.numero, s.nom, s.espece, s.race, s.sexe = d.numero or None, d.nom or None, e.nom, d.race or None, d.sexe
    s.date_naissance, s.date_arrivee, s.age_arrivee, s.origine = d.date_naissance, arrivee, (0 if d.date_naissance else d.age_arrivee), d.origine
    s.mere_id, s.pere_id = (mere.id if mere else None), (pere.id if pere else None)
    s.generation = max((p.generation for p in (mere, pere) if p), default=0) + 1
    s.bande_id, s.poulailler_id, s.reproducteur, s.etat_sante = d.bande_id, d.poulailler_id, d.reproducteur, d.etat_sante
    champs = {c.get("nom") for c in (e.modele or {}).get("champs", [])}
    s.details = {k: v for k, v in d.details.items() if k in champs and v}
    s.caracteristiques = d.caracteristiques or None
    s.note = d.note or None


@router.post("/animaux")
def creer_animal(d: AnimalIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _ecrire(u)
    s = FermeSujet(saisi_par=u.id)
    _appliquer_animal(db, s, d)
    db.add(s)
    enregistrer(db, f"Le n° « {d.numero} » est déjà utilisé pour cette espèce.")
    db.refresh(s)
    return sujet_json(s)


@router.put("/animaux/{sujet_id}")
def modifier_animal(sujet_id: int, d: AnimalIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _ecrire(u)
    s = charger(db, FermeSujet, sujet_id, "Animal introuvable.")
    _appliquer_animal(db, s, d)
    enregistrer(db, f"Le n° « {d.numero} » est déjà utilisé pour cette espèce.")
    return sujet_json(s)


class SortieIn(Formulaire):
    statut: Literal[SORTIES]
    date_sortie: date | None = None
    cause: Texte | None = Field(None, max_length=100)


@router.post("/animaux/{sujet_id}/sortie")
def sortie_animal(sujet_id: int, d: SortieIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _ecrire(u)
    s = charger(db, FermeSujet, sujet_id, "Animal introuvable.")
    if s.statut != "Présent":
        raise HTTPException(status_code=409, detail="Cet animal n'est déjà plus à la ferme.")
    jour = d.date_sortie or date.today()
    if jour > date.today() or jour < s.date_arrivee:
        raise HTTPException(status_code=400, detail="Date de sortie incorrecte.")
    if d.statut == "Mort" and not d.cause:
        raise HTTPException(status_code=400, detail="Dites de quoi il est mort (exemple : maladie, accident, inconnue).")
    s.statut, s.date_sortie, s.cause_sortie = d.statut, jour, d.cause or None
    enregistrer(db, "Enregistrement impossible.")
    return sujet_json(s)


@router.post("/animaux/{sujet_id}/retour")
def retour_animal(sujet_id: int, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    s = charger(db, FermeSujet, sujet_id, "Animal introuvable.")
    s.statut, s.date_sortie, s.cause_sortie = "Présent", None, None
    enregistrer(db, "Enregistrement impossible.")
    return sujet_json(s)


class PeseeAnimalIn(Formulaire):
    date_pesee: date | None = None
    poids_kg: Decimal = Field(gt=0, max_digits=10, decimal_places=3)


@router.post("/animaux/{sujet_id}/pesees")
def peser_animal(sujet_id: int, d: PeseeAnimalIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _ecrire(u)
    s = charger(db, FermeSujet, sujet_id, "Animal introuvable.")
    jour = d.date_pesee or date.today()
    if jour > date.today() or jour < (s.date_naissance or s.date_arrivee):
        raise HTTPException(status_code=400, detail="Date de pesée incorrecte.")
    p = next((x for x in s.pesees if x.date_pesee == jour), None)
    if p is None:
        p = FermePeseeSujet(date_pesee=jour)
        s.pesees.append(p)
    p.poids_kg, p.saisi_par = d.poids_kg, u.id
    enregistrer(db, "Enregistrement impossible.")
    return sujet_json(s, complet=True)


@router.post("/animaux/{sujet_id}/supprimer")
def supprimer_animal(sujet_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été supprimé.")
    s = charger(db, FermeSujet, sujet_id, "Animal introuvable.")
    if (db.query(FermeSujet).filter((FermeSujet.mere_id == s.id) | (FermeSujet.pere_id == s.id)).first()
            or db.query(FermeAccouplement).filter((FermeAccouplement.femelle_id == s.id) | (FermeAccouplement.male_id == s.id)).first()
            or db.query(FermeNaissance).filter((FermeNaissance.mere_id == s.id) | (FermeNaissance.pere_id == s.id)).first()):
        raise HTTPException(status_code=409, detail="Cet animal a des petits ou des accouplements notés : notez plutôt sa sortie (vendu, mort, réformé).")
    db.delete(s)
    enregistrer(db, "Suppression impossible.")
    return {"ok": True}


# ---------- Accouplements ----------

def accouplement_json(a: FermeAccouplement) -> dict:
    e_controle = None
    if a.resultat == "En attente":
        esp = a.femelle.espece_obj if a.femelle else None
        jours = (esp.controle_jours if esp else None)
        e_controle = (a.date_accouplement + timedelta(days=jours)).isoformat() if jours else None
    return {"id": a.id, "espece": a.espece, "femelle_id": a.femelle_id, "male_id": a.male_id,
            "femelle": nom_sujet(a.femelle) or (a.femelle_texte or ""), "male": nom_sujet(a.male) or (a.male_texte or ""),
            "date": a.date_accouplement.isoformat(), "methode": a.methode, "resultat": a.resultat,
            "date_resultat": a.date_resultat.isoformat() if a.date_resultat else None,
            "controle_prevu": e_controle, "mise_bas_prevue": a.mise_bas_prevue.isoformat() if a.mise_bas_prevue else None,
            "naissance_id": a.naissance_id, "note": a.note or ""}


class AccouplementIn(Formulaire):
    espece: Texte = Field(min_length=2, max_length=40)
    femelle_id: int | None = None
    male_id: int | None = None
    femelle_texte: Texte | None = Field(None, max_length=80)
    male_texte: Texte | None = Field(None, max_length=80)
    date_accouplement: date | None = None
    methode: Literal["Naturelle", "Insémination"] = "Naturelle"
    note: Texte | None = Field(None, max_length=300)


@router.post("/accouplements")
def noter_accouplement(d: AccouplementIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _ecrire(u)
    e = _espece(db, d.espece)
    jour = d.date_accouplement or date.today()
    if jour > date.today():
        raise HTTPException(status_code=400, detail="La date ne peut pas être dans le futur.")
    femelle = _parent(db, d.femelle_id, e.nom, "Femelle", None)
    male = _parent(db, d.male_id, e.nom, "Mâle", None)
    if femelle is None and not d.femelle_texte:
        raise HTTPException(status_code=400, detail="Choisissez la femelle (ou décrivez-la si elle n'a pas de fiche).")
    if femelle and femelle.statut != "Présent":
        raise HTTPException(status_code=409, detail=f"{nom_sujet(femelle)} n'est plus à la ferme.")
    if femelle and db.query(FermeAccouplement).filter(FermeAccouplement.femelle_id == femelle.id, FermeAccouplement.naissance_id.is_(None),
                                                       FermeAccouplement.resultat != "Non réussi").first():
        raise HTTPException(status_code=409, detail=f"{nom_sujet(femelle)} a déjà un accouplement en cours (en attente ou réussi).")
    a = FermeAccouplement(espece=e.nom, femelle_id=femelle.id if femelle else None, male_id=male.id if male else None,
                          femelle_texte=None if femelle else d.femelle_texte, male_texte=None if male else (d.male_texte or None),
                          date_accouplement=jour, methode=d.methode, note=d.note or None, saisi_par=u.id,
                          mise_bas_prevue=jour + timedelta(days=e.gestation_jours) if e.gestation_jours else None)
    db.add(a)
    enregistrer(db, "Enregistrement impossible.")
    db.refresh(a)
    return accouplement_json(a)


class ResultatIn(Formulaire):
    resultat: Literal["En attente", "Réussi", "Non réussi"]
    date_resultat: date | None = None


@router.post("/accouplements/{acc_id}/resultat")
def resultat_accouplement(acc_id: int, d: ResultatIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _ecrire(u)
    a = charger(db, FermeAccouplement, acc_id, "Accouplement introuvable.")
    if a.naissance_id:
        raise HTTPException(status_code=409, detail="La naissance est déjà notée : cet accouplement a réussi.")
    a.resultat = d.resultat
    a.date_resultat = None if d.resultat == "En attente" else (d.date_resultat or date.today())
    enregistrer(db, "Enregistrement impossible.")
    return accouplement_json(a)


@router.post("/accouplements/{acc_id}/supprimer")
def supprimer_accouplement(acc_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été supprimé.")
    db.delete(charger(db, FermeAccouplement, acc_id, "Accouplement introuvable."))
    enregistrer(db, "Suppression impossible.")
    return {"ok": True}


# ---------- Naissances (portées) ----------

def naissance_json(n: FermeNaissance) -> dict:
    return {"id": n.id, "numero": n.numero, "espece": n.espece, "date": n.date_naissance.isoformat(),
            "mere": nom_sujet(n.mere) or (n.mere_texte or ""), "pere": nom_sujet(n.pere) or (n.pere_texte or ""),
            "mere_id": n.mere_id, "pere_id": n.pere_id, "nes_vivants": n.nes_vivants, "morts_nes": n.morts_nes,
            "males": n.males, "femelles": n.femelles, "race": n.race or "", "etat_sante": n.etat_sante or "",
            "poids_moyen_g": montant(n.poids_moyen_g) if n.poids_moyen_g else None, "destination": n.destination,
            "bande": (n.bande.nom or n.bande.type_elevage) if n.bande else "", "bande_id": n.bande_id, "note": n.note or ""}


class PetitIn(Formulaire):
    sexe: Literal[SEXES] = "Inconnu"
    numero: Texte | None = Field(None, max_length=30)
    poids_g: Decimal | None = Field(None, gt=0, max_digits=10, decimal_places=1)


class NaissanceIn(Formulaire):
    espece: Texte = Field(min_length=2, max_length=40)
    date_naissance: date | None = None
    accouplement_id: int | None = None
    mere_id: int | None = None
    pere_id: int | None = None
    mere_texte: Texte | None = Field(None, max_length=80)
    pere_texte: Texte | None = Field(None, max_length=80)
    morts_nes: int = Field(0, ge=0, le=1000)
    race: Texte | None = Field(None, max_length=60)
    etat_sante: Texte | None = Field(None, max_length=40)
    poids_moyen_g: Decimal | None = Field(None, gt=0, max_digits=10, decimal_places=1)
    destination: Literal["Fiches", "Bande"] = "Bande"
    bande_id: int | None = None                       # destination « Bande »
    males: int = Field(0, ge=0, le=100000)            # destination « Bande »
    femelles: int = Field(0, ge=0, le=100000)
    nes_vivants: int = Field(0, ge=0, le=100000)
    petits: list[PetitIn] = Field(default_factory=list, max_length=60)   # destination « Fiches »
    note: Texte | None = Field(None, max_length=300)


@router.post("/naissances")
def noter_naissance(d: NaissanceIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _ecrire(u)
    e = _espece(db, d.espece)
    jour = d.date_naissance or date.today()
    if jour > date.today():
        raise HTTPException(status_code=400, detail="La date ne peut pas être dans le futur.")
    acc = charger(db, FermeAccouplement, d.accouplement_id, "Accouplement introuvable.") if d.accouplement_id else None
    if acc and acc.naissance_id:
        raise HTTPException(status_code=409, detail="La naissance de cet accouplement est déjà notée.")
    mere = _parent(db, d.mere_id or (acc.femelle_id if acc else None), e.nom, "Femelle", None)
    pere = _parent(db, d.pere_id or (acc.male_id if acc else None), e.nom, "Mâle", None)
    if d.destination == "Fiches":
        vivants, males = len(d.petits), sum(1 for p in d.petits if p.sexe == "Mâle")
        femelles = sum(1 for p in d.petits if p.sexe == "Femelle")
        bande = None
    else:
        vivants, males, femelles = d.nes_vivants or (d.males + d.femelles), d.males, d.femelles
        if males + femelles > vivants:
            raise HTTPException(status_code=400, detail="Plus de mâles et de femelles que de petits nés vivants.")
        bande = charger(db, FermeBande, d.bande_id, "Lot introuvable.") if d.bande_id else None
        if vivants and bande is None:
            raise HTTPException(status_code=400, detail="Choisissez le lot où les petits seront comptés.")
        if bande and (bande.type_elevage != e.nom or bande.statut != "En cours"):
            raise HTTPException(status_code=400, detail="Choisissez une lot en cours de la même espèce.")
    if not vivants and not d.morts_nes:
        raise HTTPException(status_code=400, detail="Indiquez le nombre de petits.")
    n = FermeNaissance(numero=numero_suivant(db, FermeNaissance.numero, f"NAI-{jour.year}", 4), espece=e.nom, date_naissance=jour,
                       accouplement_id=acc.id if acc else None, mere_id=mere.id if mere else None, pere_id=pere.id if pere else None,
                       mere_texte=None if mere else (d.mere_texte or (acc.femelle_texte if acc else None)),
                       pere_texte=None if pere else (d.pere_texte or (acc.male_texte if acc else None)),
                       nes_vivants=vivants, morts_nes=d.morts_nes, males=males, femelles=femelles,
                       race=d.race or (mere.race if mere else None), etat_sante=d.etat_sante or None, poids_moyen_g=d.poids_moyen_g,
                       destination=d.destination, bande_id=bande.id if bande else None, note=d.note or None, saisi_par=u.id)
    db.add(n)
    db.flush()
    if d.destination == "Fiches":   # une fiche par petit : parents, génération, race, bâtiment de la mère
        generation = max((p.generation for p in (mere, pere) if p), default=0) + 1
        for p in d.petits:
            petit = FermeSujet(numero=p.numero or None, espece=e.nom, race=n.race, sexe=p.sexe, date_naissance=jour, date_arrivee=jour,
                               origine="Né à la ferme", mere_id=n.mere_id, pere_id=n.pere_id, naissance_id=n.id, generation=generation,
                               poulailler_id=mere.poulailler_id if mere else None, saisi_par=u.id)
            if p.poids_g:
                petit.pesees.append(FermePeseeSujet(date_pesee=jour, poids_kg=p.poids_g / 1000, saisi_par=u.id))
            db.add(petit)
    if acc:
        acc.naissance_id, acc.resultat, acc.date_resultat = n.id, "Réussi", acc.date_resultat or jour
    enregistrer(db, "Un numéro de petit est déjà utilisé pour cette espèce.")
    db.refresh(n)
    return naissance_json(n)


@router.post("/naissances/{naissance_id}/supprimer")
def supprimer_naissance(naissance_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été supprimé.")
    n = charger(db, FermeNaissance, naissance_id, "Naissance introuvable.")
    petits = db.query(FermeSujet).filter(FermeSujet.naissance_id == n.id).all()
    if any(db.query(FermeSujet).filter((FermeSujet.mere_id == p.id) | (FermeSujet.pere_id == p.id)).first() for p in petits):
        raise HTTPException(status_code=409, detail="Des petits de cette portée ont déjà eu des petits : la naissance ne peut plus être supprimée.")
    for p in petits:
        db.delete(p)
    for a in db.query(FermeAccouplement).filter(FermeAccouplement.naissance_id == n.id):
        a.naissance_id = None
    db.delete(n)
    enregistrer(db, "Suppression impossible.")
    return {"ok": True}


# ---------- Tableau de la reproduction ----------

@router.get("/reproduction")
def tableau_reproduction(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    accs = (db.query(FermeAccouplement).options(selectinload(FermeAccouplement.femelle), selectinload(FermeAccouplement.male))
            .order_by(FermeAccouplement.date_accouplement.desc()).limit(300).all())
    naissances = (db.query(FermeNaissance).options(selectinload(FermeNaissance.mere), selectinload(FermeNaissance.pere), selectinload(FermeNaissance.bande))
                  .order_by(FermeNaissance.date_naissance.desc()).limit(300).all())
    reproducteurs = _requete_sujets(db).filter(FermeSujet.statut == "Présent", FermeSujet.sexe.in_(("Mâle", "Femelle"))).order_by(FermeSujet.espece, FermeSujet.numero).all()
    bandes = db.query(FermeBande).filter(FermeBande.statut == "En cours").all()
    return {"accouplements": [accouplement_json(a) for a in accs], "naissances": [naissance_json(n) for n in naissances],
            "animaux": [{"id": s.id, "libelle": nom_sujet(s), "espece": s.espece, "sexe": s.sexe, "race": s.race or "",
                         "reproducteur": s.reproducteur, "age_texte": age_texte(age_jours(s))} for s in reproducteurs],
            "bandes": [{"id": b.id, "nom": b.nom or b.type_elevage, "espece": b.type_elevage, "batiment": b.poulailler.nom} for b in bandes],
            "especes": [e for e in especes_json(db) if e["actif"] and e["naissances"]], "sexes": SEXES,
            "ecrit": _role(u) in ECRIT, "est_admin": _role(u) == "Admin"}


# ---------- Modèles de fiche et durées (Admin) ----------

class ModeleIn(Formulaire):
    gestation_jours: int | None = Field(None, gt=0, le=1000)
    controle_jours: int | None = Field(None, gt=0, le=1000)
    sevrage_jours: int | None = Field(None, gt=0, le=2000)
    races: list[Texte] = Field(default_factory=list, max_length=40)
    champs: list[dict] = Field(default_factory=list, max_length=12)       # [{"nom": "Robe", "choix": ["Noire", …]}]
    reperes: list[list[str]] = Field(default_factory=list, max_length=20)  # [["Gestation", "31 jours"], …]
    caracteristiques: list[Texte] = Field(default_factory=list, max_length=30)   # exemples proposés (yeux bleus…)


@router.put("/especes/{espece_id}/modele")
def changer_modele(espece_id: int, d: ModeleIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    e = charger(db, FermeEspece, espece_id, "Espèce introuvable.")
    champs = []
    for c in d.champs:
        nom = str(c.get("nom", "")).strip()[:40]
        if nom:
            champs.append({"nom": nom, "choix": [str(x).strip()[:40] for x in c.get("choix", []) if str(x).strip()][:20]})
    e.gestation_jours, e.controle_jours, e.sevrage_jours = d.gestation_jours, d.controle_jours, d.sevrage_jours
    e.modele = {"races": [r for r in d.races if r], "champs": champs,
                "reperes": [[str(r[0])[:60], str(r[1])[:120]] for r in d.reperes if len(r) == 2 and r[0]],
                "caracteristiques": [c[:60] for c in d.caracteristiques if c]}
    enregistrer(db, "Enregistrement impossible.")
    return {"ok": True}


# ---------- Statistiques par espèce ----------

def _taux(n, sur) -> float | None:
    return round(n * 100 / sur, 1) if sur else None


@router.get("/reproduction/statistiques")
def statistiques(espece: str = Query(...), u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    e = _espece(db, espece)
    aujourdhui = date.today()
    il_y_a_un_an = aujourdhui - timedelta(days=365)
    sujets = _requete_sujets(db).filter(FermeSujet.espece == e.nom).all()
    presents = [s for s in sujets if s.statut == "Présent"]
    bandes = db.query(FermeBande).options(selectinload(FermeBande.suivis)).filter(FermeBande.type_elevage == e.nom).all()
    bandes_ec = [b for b in bandes if b.statut == "En cours"]
    import ferme
    vivants_bandes = sum(ferme.chiffres(b)["vivants"] for b in bandes_ec)

    # mâles et femelles : fiches présentes + bandes (déclarés à l'arrivée)
    sexes = {x: sum(1 for s in presents if s.sexe == x) for x in SEXES}
    sexes_bandes = {"Mâle": sum(b.males or 0 for b in bandes_ec), "Femelle": sum(b.femelles or 0 for b in bandes_ec)}

    # par âge (fiches présentes), par sexe ; poids moyen de chaque classe
    par_age = []
    for _, libelle in CLASSES_AGE:
        dans = [s for s in presents if classe_age(age_jours(s)) == libelle]
        if not dans:
            continue
        poids = lambda sexe: [float(s.pesees[-1].poids_kg) for s in dans if s.pesees and (sexe is None or s.sexe == sexe)]  # noqa: E731
        moy = lambda l: round(sum(l) / len(l), 2) if l else None  # noqa: E731
        par_age.append({"classe": libelle, "total": len(dans), "males": sum(1 for s in dans if s.sexe == "Mâle"),
                        "femelles": sum(1 for s in dans if s.sexe == "Femelle"),
                        "poids_moyen": moy(poids(None)), "poids_males": moy(poids("Mâle")), "poids_femelles": moy(poids("Femelle"))})

    # mortalité (12 derniers mois) : fiches + bandes
    morts_fiches = sum(1 for s in sujets if s.statut == "Mort" and s.date_sortie and s.date_sortie >= il_y_a_un_an)
    base_fiches = sum(1 for s in sujets if s.statut == "Présent" or (s.date_sortie and s.date_sortie >= il_y_a_un_an))
    morts_bandes = sum(x.morts for b in bandes for x in b.suivis if x.date_suivi >= il_y_a_un_an)
    base_bandes = sum(b.effectif_depart + sum(x.naissances for x in b.suivis) for b in bandes
                      if b.statut == "En cours" or (b.date_fin and b.date_fin >= il_y_a_un_an))

    # natalité et accouplements (12 derniers mois)
    naissances = db.query(FermeNaissance).filter(FermeNaissance.espece == e.nom, FermeNaissance.date_naissance >= il_y_a_un_an).all()
    nes_vivants = sum(n.nes_vivants for n in naissances)
    morts_nes = sum(n.morts_nes for n in naissances)
    femelles_repro = sum(1 for s in presents if s.sexe == "Femelle" and (s.reproducteur or any(n.mere_id == s.id for n in naissances)))
    accs = db.query(FermeAccouplement).filter(FermeAccouplement.espece == e.nom, FermeAccouplement.date_accouplement >= il_y_a_un_an).all()
    reussis = sum(1 for a in accs if a.resultat == "Réussi")
    rates = sum(1 for a in accs if a.resultat == "Non réussi")

    # survie jusqu'au sevrage (petits avec fiche, nés depuis assez longtemps)
    petits = [s for s in sujets if s.naissance_id and s.date_naissance and e.sevrage_jours
              and s.date_naissance + timedelta(days=e.sevrage_jours) <= aujourdhui]
    survivants = [s for s in petits if not (s.statut == "Mort" and s.date_sortie and s.date_sortie < s.date_naissance + timedelta(days=e.sevrage_jours))]

    # races : les plus résistantes (mortalité la plus basse), fiches + bandes (race de la bande)
    races = defaultdict(lambda: {"animaux": 0, "morts": 0, "malades": 0})
    for s in sujets:
        r = races[s.race or "Race non précisée"]
        r["animaux"] += 1
        r["morts"] += 1 if s.statut == "Mort" else 0
        r["malades"] += 1 if s.statut == "Présent" and s.etat_sante in ("Malade", "En traitement") else 0
    for b in bandes:
        r = races[b.souche or "Race non précisée"]
        r["animaux"] += b.effectif_depart + sum(x.naissances for x in b.suivis)
        r["morts"] += sum(x.morts for x in b.suivis)
    races_liste = sorted(({"race": k, **v, "mortalite": _taux(v["morts"], v["animaux"]), "peu": v["animaux"] < 5} for k, v in races.items() if v["animaux"]),
                         key=lambda r: (r["peu"], r["mortalite"] if r["mortalite"] is not None else 999))

    # meilleures mères : petits nés vivants et sevrés
    meres = defaultdict(lambda: {"portees": 0, "nes": 0, "sevres": 0, "petits_fiches": 0})
    for n in db.query(FermeNaissance).filter(FermeNaissance.espece == e.nom, FermeNaissance.mere_id.isnot(None)):
        meres[n.mere_id]["portees"] += 1
        meres[n.mere_id]["nes"] += n.nes_vivants
    for s in petits:
        if s.mere_id:
            meres[s.mere_id]["petits_fiches"] += 1
            meres[s.mere_id]["sevres"] += 1 if s in survivants else 0
    noms = {s.id: nom_sujet(s) for s in sujets}
    meres_liste = sorted(({"mere": noms.get(k, ""), **v, "survie": _taux(v["sevres"], v["petits_fiches"]),
                           "par_portee": round(v["nes"] / v["portees"], 1) if v["portees"] else None} for k, v in meres.items()),
                         key=lambda m: (-(m["par_portee"] or 0), -(m["survie"] or 0)))[:10]

    return {"espece": e.nom, "dessin": e.dessin, "naissances_possibles": e.naissances,
            "effectif": {"fiches": len(presents), "bandes": vivants_bandes, "total": len(presents) + vivants_bandes},
            "sexes": sexes, "sexes_bandes": sexes_bandes, "par_age": par_age,
            "mortalite": {"morts": morts_fiches + morts_bandes, "taux": _taux(morts_fiches + morts_bandes, base_fiches + base_bandes)},
            "natalite": {"portees": len(naissances), "nes_vivants": nes_vivants, "morts_nes": morts_nes,
                         "par_portee": round((nes_vivants + morts_nes) / len(naissances), 1) if naissances else None,
                         "taux_morts_nes": _taux(morts_nes, nes_vivants + morts_nes), "femelles": femelles_repro,
                         "par_femelle": round(nes_vivants / femelles_repro, 1) if femelles_repro else None},
            "accouplements": {"total": len(accs), "reussis": reussis, "rates": rates, "en_attente": len(accs) - reussis - rates,
                              "taux_reussite": _taux(reussis, reussis + rates)},
            "survie": {"petits": len(petits), "sevres": len(survivants), "taux": _taux(len(survivants), len(petits)), "sevrage_jours": e.sevrage_jours},
            "races": races_liste, "meres": meres_liste}


# ---------- Agenda et assistant ----------

def evenements_prevus(db: SessionDB, debut: date, fin: date) -> dict[str, list[str]]:
    """Agenda : contrôles de gestation et mises bas prévus."""
    par = defaultdict(list)
    for a in db.query(FermeAccouplement).options(selectinload(FermeAccouplement.femelle)).filter(FermeAccouplement.naissance_id.is_(None),
                                                                                                FermeAccouplement.resultat != "Non réussi"):
        j = accouplement_json(a)
        qui = j["femelle"] or a.espece
        if j["controle_prevu"] and debut.isoformat() <= j["controle_prevu"] <= fin.isoformat():
            par[j["controle_prevu"]].append(f"Contrôle de gestation — {qui} ({a.espece})")
        if j["mise_bas_prevue"] and debut.isoformat() <= j["mise_bas_prevue"] <= fin.isoformat():
            par[j["mise_bas_prevue"]].append(f"Mise bas prévue — {qui} ({a.espece})")
    return dict(par)


def alertes(db: SessionDB, u: Utilisateur) -> list[tuple[str, str, str, str]]:
    resultat = []
    aujourdhui = date.today()
    for a in db.query(FermeAccouplement).options(selectinload(FermeAccouplement.femelle)).filter(FermeAccouplement.naissance_id.is_(None),
                                                                                                FermeAccouplement.resultat != "Non réussi"):
        j = accouplement_json(a)
        qui = f"{j['femelle'] or 'Une femelle'} ({a.espece})"
        if j["controle_prevu"] and date.fromisoformat(j["controle_prevu"]) <= aujourdhui:
            resultat.append((f"ferme-controle-{a.id}", "info", f"{qui} : contrôle de gestation à faire",
                             "Est-elle pleine ? Notez le résultat (Ferme → Reproduction)."))
        if j["mise_bas_prevue"]:
            mb = date.fromisoformat(j["mise_bas_prevue"])
            if mb < aujourdhui:
                resultat.append((f"ferme-misebas-{a.id}", "attention", f"{qui} : mise bas prévue le {mb:%d/%m/%Y} pas encore notée",
                                 "Notez la naissance, ou l'échec de l'accouplement (Ferme → Reproduction)."))
            elif mb <= aujourdhui + timedelta(days=3):
                resultat.append((f"ferme-misebas-{a.id}", "info", f"{qui} : mise bas prévue le {mb:%d/%m/%Y}",
                                 "Préparez le nid ou la case de mise bas."))
    malades = db.query(FermeSujet).filter(FermeSujet.statut == "Présent", FermeSujet.etat_sante.in_(("Malade", "Blessé"))).count()
    if malades:
        resultat.append(("ferme-malades", "attention", f"{malades} animal{'aux' if malades > 1 else ''} malade{'s' if malades > 1 else ''} ou blessé{'s' if malades > 1 else ''}",
                         "Voir Ferme → Animaux (fiches)."))
    return resultat
