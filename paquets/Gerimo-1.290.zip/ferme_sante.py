"""Ferme, étape 3 (22/11/2026) : santé (programme de vaccins, soins faits), pesées, visites du vétérinaire.

Décisions de Boss (22/11/2026) — voir migrations/050_ferme_sante.sql :
- Un programme de vaccins par espèce (jour d'âge → vaccin) ; pour chaque bande Gérimo calcule les dates prévues
  (Agenda, alerte la veille, retard). Un vaccin prévu avant l'arrivée du lot (couvoir) n'est pas demandé.
- Un vaccin ou un traitement fait est NOTÉ. Le produit ne sort du stock que si le flacon (sachet…) est FINI : la case
  « il reste du produit » est cochée par défaut. Plus aucun flacon en stock : le soin ne peut pas être noté, et Gérimo
  prévient (produit épuisé) pour que le chef de ferme prévoie un achat.
- Pesées : poids moyen d'un échantillon, comparé au poids attendu pour l'âge (référence modifiable par l'Admin).
- Visites du vétérinaire : constat, conseils ; le prix (Admin, Caisse) devient une Dépense de l'entreprise.
- Rôles : soins et pesées : Admin et chef de ferme (Gestionnaire) ; visites : Admin, Gestionnaire, Caisse (prix :
  Admin et Caisse) ; programme et poids attendus : Admin ; suppression : Admin avec son mot de passe ; Comptable : lecture.
"""
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from sqlalchemy.orm import Session as SessionDB, selectinload

import periode
import tresorerie
from commun import Formulaire, Suppression, Telephone, Texte, charger, enregistrer, montant
from ferme_stock import comptes_actifs, stock_de, texte_quantite
from models import (MODES_PAIEMENT, Depense, FermeBande, FermeEspece, FermeMouvement, FermePesee, FermePoidsReference,
                    FermeProduit, FermeProgramme, FermeSoin, FermeVisite, Utilisateur)
from securite import exiger_admin, exiger_module, get_db, verifier_mot_de_passe

router = APIRouter(prefix="/api/ferme")
acces = exiger_module("ferme")
ZERO = Decimal(0)
SOIGNE = ("Admin", "Gestionnaire")                 # soins et pesées : le chef de ferme
NOTE_VISITES = ("Admin", "Gestionnaire", "Caisse")
ARGENT = ("Admin", "Caisse")
MODES_SOIN = ("Eau de boisson", "Goutte dans l'œil", "Injection", "Pulvérisation", "Dans l'aliment", "Autre")
JOURS_A_VENIR = 14
CROISSANCE_LENTE = Decimal("0.85")                 # moins de 85 % du poids attendu


def _role(u: Utilisateur) -> str:
    return u.role.value


def _exiger(u: Utilisateur, roles: tuple, message: str) -> None:
    if _role(u) not in roles:
        raise HTTPException(status_code=403, detail=message)


def _jour_ok(jour: date, b: FermeBande | None = None) -> None:
    if jour > date.today():
        raise HTTPException(status_code=400, detail="La date ne peut pas être dans le futur.")
    if b is not None and jour < b.date_arrivee:
        raise HTTPException(status_code=400, detail=f"Ce lot est arrivé le {b.date_arrivee:%d/%m/%Y}.")


# ---------- Programme de vaccins et dates prévues ----------

def programmes(db: SessionDB) -> dict[str, list[FermeProgramme]]:
    par = defaultdict(list)
    for p in db.query(FermeProgramme).options(selectinload(FermeProgramme.produit)).order_by(FermeProgramme.jour_age, FermeProgramme.nom):
        par[p.type_elevage].append(p)
    return par


def plan_bande(b: FermeBande, progs: dict, soins_bande: list[FermeSoin], stocks: dict | None = None) -> list[dict]:
    """Vaccins du programme pour ce lot : date prévue, fait ou non, en retard, produit en stock."""
    aujourdhui = date.today()
    faits = {s.programme_id: s for s in soins_bande if s.programme_id}
    lignes = []
    for p in progs.get(b.type_elevage, []):
        if p.jour_age < b.age_arrivee:
            continue   # fait avant l'arrivée (au couvoir, chez le vendeur)
        prevu = b.date_arrivee + timedelta(days=p.jour_age - b.age_arrivee)
        s = faits.get(p.id)
        if s:
            etat = "fait"
        elif prevu < aujourdhui:
            etat = "retard"
        elif prevu == aujourdhui:
            etat = "aujourdhui"
        elif prevu == aujourdhui + timedelta(days=1):
            etat = "demain"
        else:
            etat = "prevu"
        stock = (stocks or {}).get(p.produit_id) if p.produit_id else None
        lignes.append({"programme_id": p.id, "nom": p.nom, "jour_age": p.jour_age, "date": prevu.isoformat(), "etat": etat,
                       "mode": p.mode or "", "produit_id": p.produit_id, "produit": p.produit.nom if p.produit else "",
                       "epuise": bool(p.produit_id and not s and stock is not None and stock <= 0),
                       "fait_le": s.date_soin.isoformat() if s else None, "soin_id": s.id if s else None,
                       "bande_id": b.id})
    return lignes


def programme_json(p: FermeProgramme) -> dict:
    return {"id": p.id, "espece": p.type_elevage, "jour_age": p.jour_age, "nom": p.nom, "produit_id": p.produit_id,
            "produit": p.produit.nom if p.produit else "", "mode": p.mode or "", "note": p.note or ""}


def soin_json(s: FermeSoin) -> dict:
    return {"id": s.id, "bande_id": s.bande_id, "bande": (s.bande.nom or s.bande.type_elevage) if s.bande else "",
            "batiment": s.bande.poulailler.nom if s.bande else "", "espece": s.bande.type_elevage if s.bande else "",
            "date": s.date_soin.isoformat(), "genre": s.genre, "nom": s.nom, "programme_id": s.programme_id,
            "produit": s.produit.nom if s.produit else "", "mode": s.mode or "", "reste_produit": s.reste_produit,
            "finis": montant(s.finis), "finis_texte": texte_quantite(s.produit, s.finis) if s.produit and s.finis else "",
            "note": s.note or "", "saisi_par": s.auteur.nom_complet if s.auteur else ""}


def _bandes_en_cours(db: SessionDB):
    return (db.query(FermeBande).options(selectinload(FermeBande.poulailler))
            .filter(FermeBande.statut == "En cours").order_by(FermeBande.date_arrivee).all())


def _soins_par_bande(db: SessionDB, ids) -> dict[int, list[FermeSoin]]:
    par = defaultdict(list)
    for s in db.query(FermeSoin).filter(FermeSoin.bande_id.in_(list(ids) or [0])):
        par[s.bande_id].append(s)
    return par


def _stocks(db: SessionDB) -> dict[int, Decimal]:
    from ferme_stock import stocks
    return stocks(db)


@router.get("/sante")
def tableau_sante(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    bandes = _bandes_en_cours(db)
    progs, st = programmes(db), _stocks(db)
    soins = _soins_par_bande(db, [b.id for b in bandes])
    limite = date.today() + timedelta(days=JOURS_A_VENIR)
    a_faire = []
    for b in bandes:
        for l in plan_bande(b, progs, soins[b.id], st):
            if l["etat"] != "fait" and date.fromisoformat(l["date"]) <= limite:
                a_faire.append({**l, "bande": b.nom or b.type_elevage, "espece": b.type_elevage, "batiment": b.poulailler.nom,
                                "dessin": b.espece.dessin})
    a_faire.sort(key=lambda l: l["date"])
    derniers = (db.query(FermeSoin).options(selectinload(FermeSoin.bande).selectinload(FermeBande.poulailler),
                                            selectinload(FermeSoin.produit), selectinload(FermeSoin.auteur))
                .order_by(FermeSoin.date_soin.desc(), FermeSoin.id.desc()).limit(60).all())
    produits = [{"id": p.id, "nom": p.nom, "categorie": p.categorie, "unite": p.unite, "stock": montant(st.get(p.id, ZERO)),
                 "stock_texte": texte_quantite(p, st.get(p.id, ZERO))}
                for p in db.query(FermeProduit).filter(FermeProduit.actif, FermeProduit.categorie.in_(("Vaccin", "Médicament")))
                .order_by(FermeProduit.categorie.desc(), FermeProduit.nom)]
    return {"a_faire": a_faire, "derniers": [soin_json(s) for s in derniers],
            "programme": [programme_json(p) for liste in progs.values() for p in liste],
            "bandes": [{"id": b.id, "nom": b.nom or b.type_elevage, "espece": b.type_elevage, "batiment": b.poulailler.nom,
                        "dessin": b.espece.dessin} for b in bandes],
            "produits": produits, "modes": MODES_SOIN, "especes": [e.nom for e in db.query(FermeEspece).filter(FermeEspece.actif).order_by(FermeEspece.ordre)],
            "soigne": _role(u) in SOIGNE, "est_admin": _role(u) == "Admin"}


# ---------- Soins faits (vaccins, traitements) ----------

class SoinIn(Formulaire):
    bande_id: int
    genre: Literal["Vaccin", "Traitement"] = "Vaccin"
    nom: Texte | None = Field(None, max_length=100)
    programme_id: int | None = None
    produit_id: int | None = None
    reste_produit: bool = True        # il reste du produit dans le flacon : rien ne sort du stock
    finis: Decimal = Field(Decimal(1), ge=0, max_digits=10, decimal_places=2)   # flacons finis si reste_produit est faux
    mode: Texte | None = Field(None, max_length=40)
    date_soin: date | None = None
    note: Texte | None = Field(None, max_length=300)


@router.post("/soins")
def noter_soin(d: SoinIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u, SOIGNE, "Les soins sont notés par le chef de ferme (Gestionnaire) ou l'Admin.")
    b = charger(db, FermeBande, d.bande_id, "Lot introuvable.")
    if b.statut != "En cours":
        raise HTTPException(status_code=409, detail="Ce lot est terminé.")
    jour = d.date_soin or date.today()
    _jour_ok(jour, b)
    nom, produit_id, mode, genre = d.nom, d.produit_id, d.mode, d.genre
    if d.programme_id is not None:
        p = charger(db, FermeProgramme, d.programme_id, "Vaccin du programme introuvable.")
        if p.type_elevage != b.type_elevage:
            raise HTTPException(status_code=400, detail="Ce vaccin n'est pas au programme de cette espèce.")
        if db.query(FermeSoin).filter(FermeSoin.bande_id == b.id, FermeSoin.programme_id == p.id).first():
            raise HTTPException(status_code=409, detail=f"« {p.nom} » est déjà noté pour ce lot.")
        nom, genre = nom or p.nom, "Vaccin"
        produit_id = produit_id or p.produit_id
        mode = mode or p.mode
    if not nom:
        raise HTTPException(status_code=400, detail="Indiquez le nom du vaccin ou du traitement.")
    produit = None
    if produit_id is not None:
        produit = charger(db, FermeProduit, produit_id, "Produit introuvable.")
        if produit.categorie not in ("Vaccin", "Médicament"):
            raise HTTPException(status_code=400, detail="Choisissez un vaccin ou un médicament.")
        stock = stock_de(db, produit.id)
        if stock <= 0:
            raise HTTPException(status_code=409, detail=f"Plus aucun « {produit.nom} » en stock : le soin ne peut pas être fait. "
                                                        "Prévoyez un achat (Ferme → Achats).")
        if not d.reste_produit:
            if d.finis <= 0:
                raise HTTPException(status_code=400, detail=f"Combien de {produit.unite}(s) sont finis ?")
            if d.finis > stock:
                raise HTTPException(status_code=409, detail=f"Il ne reste que {texte_quantite(produit, stock)} de « {produit.nom} ».")
    s = FermeSoin(bande_id=b.id, date_soin=jour, genre=genre, nom=nom, programme_id=d.programme_id, produit_id=produit.id if produit else None,
                  mode=mode or None, reste_produit=d.reste_produit or produit is None,
                  finis=d.finis if produit is not None and not d.reste_produit else ZERO, note=d.note or None, saisi_par=u.id)
    db.add(s)
    db.flush()
    if s.finis:   # flacon (sachet…) fini : il sort du stock
        db.add(FermeMouvement(produit_id=produit.id, date_mouvement=jour, genre="Utilisation", quantite=-s.finis,
                              bande_id=b.id, soin_id=s.id, motif=f"{genre} : {nom}", saisi_par=u.id))
    enregistrer(db, f"« {nom} » est déjà noté pour ce lot.")
    db.refresh(s)
    reste = stock_de(db, produit.id) if produit else None
    return {**soin_json(s), "stock_restant": texte_quantite(produit, reste) if produit else None,
            "epuise": bool(produit and reste <= 0)}


@router.post("/soins/{soin_id}/supprimer")
def supprimer_soin(soin_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été supprimé.")
    s = charger(db, FermeSoin, soin_id, "Soin introuvable.")
    db.query(FermeMouvement).filter(FermeMouvement.soin_id == s.id).delete()   # le flacon fini revient dans le stock
    db.delete(s)
    enregistrer(db, "Suppression impossible.")
    return {"ok": True}


# ---------- Programme (Admin) ----------

class ProgrammeIn(Formulaire):
    espece: Texte = Field(min_length=2, max_length=40)
    jour_age: int = Field(ge=0, le=1000)
    nom: Texte = Field(min_length=2, max_length=100)
    produit_id: int | None = None
    mode: Texte | None = Field(None, max_length=40)
    note: Texte | None = Field(None, max_length=300)


def _appliquer_programme(db: SessionDB, p: FermeProgramme, d: ProgrammeIn) -> None:
    if not db.query(FermeEspece).filter(FermeEspece.nom == d.espece).first():
        raise HTTPException(status_code=400, detail="Choisissez l'espèce dans la liste.")
    if d.produit_id is not None:
        pr = charger(db, FermeProduit, d.produit_id, "Produit introuvable.")
        if pr.categorie not in ("Vaccin", "Médicament"):
            raise HTTPException(status_code=400, detail="Choisissez un vaccin ou un médicament.")
    p.type_elevage, p.jour_age, p.nom, p.produit_id, p.mode, p.note = d.espece, d.jour_age, d.nom, d.produit_id, d.mode or None, d.note or None


@router.post("/programme")
def ajouter_programme(d: ProgrammeIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    p = FermeProgramme()
    _appliquer_programme(db, p, d)
    db.add(p)
    enregistrer(db, "Ce vaccin est déjà au programme ce jour-là.")
    return {"id": p.id}


@router.put("/programme/{programme_id}")
def modifier_programme(programme_id: int, d: ProgrammeIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    p = charger(db, FermeProgramme, programme_id, "Vaccin du programme introuvable.")
    _appliquer_programme(db, p, d)
    enregistrer(db, "Ce vaccin est déjà au programme ce jour-là.")
    return {"id": p.id}


@router.post("/programme/{programme_id}/supprimer")
def retirer_programme(programme_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été supprimé.")
    db.delete(charger(db, FermeProgramme, programme_id, "Vaccin du programme introuvable."))
    enregistrer(db, "Suppression impossible.")
    return {"ok": True}


# ---------- Pesées ----------

def references(db: SessionDB) -> dict[str, list[tuple[int, Decimal]]]:
    par = defaultdict(list)
    for r in db.query(FermePoidsReference).order_by(FermePoidsReference.type_elevage, FermePoidsReference.jour_age):
        par[r.type_elevage].append((r.jour_age, r.poids_g))
    return par


def poids_attendu(refs: list[tuple[int, Decimal]], age: int) -> Decimal | None:
    """Poids attendu à cet âge (entre deux repères : en ligne droite) ; rien après le dernier repère."""
    if not refs or age < refs[0][0] or age > refs[-1][0]:
        return None
    for (j1, p1), (j2, p2) in zip(refs, refs[1:]):
        if j1 <= age <= j2:
            return (p1 + (p2 - p1) * Decimal(age - j1) / Decimal(j2 - j1)).quantize(Decimal("1"))
    return refs[-1][1] if age == refs[-1][0] else None


def pesee_json(p: FermePesee, refs: dict) -> dict:
    b = p.bande
    age = (p.date_pesee - b.date_arrivee).days + b.age_arrivee
    attendu = poids_attendu(refs.get(b.type_elevage, []), age)
    ecart = round(float(p.poids_moyen_g / attendu * 100)) if attendu else None
    return {"id": p.id, "bande_id": b.id, "date": p.date_pesee.isoformat(), "age": age, "nombre": p.nombre,
            "poids_g": montant(p.poids_moyen_g), "attendu_g": montant(attendu) if attendu else None, "pour_cent": ecart,
            "lent": bool(attendu and p.poids_moyen_g < attendu * CROISSANCE_LENTE), "note": p.note or "",
            "saisi_par": p.auteur.nom_complet if p.auteur else ""}


@router.get("/pesees")
def tableau_pesees(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    refs = references(db)
    bandes = _bandes_en_cours(db)
    pesees = defaultdict(list)
    for p in (db.query(FermePesee).options(selectinload(FermePesee.bande), selectinload(FermePesee.auteur))
              .filter(FermePesee.bande_id.in_([b.id for b in bandes] or [0])).order_by(FermePesee.date_pesee)):
        pesees[p.bande_id].append(pesee_json(p, refs))
    lignes = []
    for b in bandes:
        age = (date.today() - b.date_arrivee).days + b.age_arrivee
        attendu = poids_attendu(refs.get(b.type_elevage, []), age)
        lignes.append({"id": b.id, "nom": b.nom or b.type_elevage, "espece": b.type_elevage, "batiment": b.poulailler.nom,
                       "dessin": b.espece.dessin, "age": age, "attendu_aujourdhui": montant(attendu) if attendu else None,
                       "pesees": pesees[b.id], "derniere": pesees[b.id][-1] if pesees[b.id] else None})
    return {"bandes": lignes, "references": {k: [[j, montant(p)] for j, p in v] for k, v in refs.items()},
            "especes": [e.nom for e in db.query(FermeEspece).filter(FermeEspece.actif).order_by(FermeEspece.ordre)],
            "soigne": _role(u) in SOIGNE, "est_admin": _role(u) == "Admin"}


class PeseeIn(Formulaire):
    bande_id: int
    date_pesee: date | None = None
    nombre: int = Field(gt=0, le=10000)
    poids_moyen_g: Decimal = Field(gt=0, max_digits=8, decimal_places=1)
    note: Texte | None = Field(None, max_length=300)


@router.post("/pesees")
def noter_pesee(d: PeseeIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u, SOIGNE, "Les pesées sont notées par le chef de ferme (Gestionnaire) ou l'Admin.")
    b = charger(db, FermeBande, d.bande_id, "Lot introuvable.")
    jour = d.date_pesee or date.today()
    _jour_ok(jour, b)
    p = db.query(FermePesee).filter(FermePesee.bande_id == b.id, FermePesee.date_pesee == jour).first()
    if p is None:
        p = FermePesee(bande_id=b.id, date_pesee=jour)
        db.add(p)
    p.nombre, p.poids_moyen_g, p.note, p.saisi_par = d.nombre, d.poids_moyen_g, d.note or None, u.id
    enregistrer(db, "Enregistrement impossible.")
    db.refresh(p)
    return pesee_json(p, references(db))


@router.post("/pesees/{pesee_id}/supprimer")
def supprimer_pesee(pesee_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été supprimé.")
    db.delete(charger(db, FermePesee, pesee_id, "Pesée introuvable."))
    enregistrer(db, "Suppression impossible.")
    return {"ok": True}


class ReferenceIn(Formulaire):
    points: list[tuple[int, Decimal]] = Field(max_length=60)    # [jour d'âge, poids en grammes]


@router.put("/poids-reference/{espece}")
def changer_references(espece: str, d: ReferenceIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    if not db.query(FermeEspece).filter(FermeEspece.nom == espece).first():
        raise HTTPException(status_code=404, detail="Espèce introuvable.")
    jours = [j for j, _ in d.points]
    if len(set(jours)) != len(jours) or any(j < 0 for j in jours) or any(p <= 0 for _, p in d.points):
        raise HTTPException(status_code=400, detail="Chaque âge une seule fois, avec un poids plus grand que 0.")
    db.query(FermePoidsReference).filter(FermePoidsReference.type_elevage == espece).delete()
    for j, p in d.points:
        db.add(FermePoidsReference(type_elevage=espece, jour_age=j, poids_g=p))
    enregistrer(db, "Enregistrement impossible.")
    return {"ok": True}


# ---------- Visites du vétérinaire ----------

def visite_json(v: FermeVisite, u: Utilisateur) -> dict:
    d = {"id": v.id, "date": v.date_visite.isoformat(), "veterinaire": v.veterinaire, "telephone": v.telephone or "",
         "bande_id": v.bande_id, "bande": (v.bande.nom or v.bande.type_elevage) if v.bande else "",
         "constat": v.constat or "", "conseils": v.conseils or "", "saisi_par": v.auteur.nom_complet if v.auteur else ""}
    if _role(u) in ("Admin", "Caisse", "Comptable"):
        d["cout"] = montant(v.cout) if v.cout is not None else None
    return d


@router.get("/visites")
def liste_visites(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    visites = (db.query(FermeVisite).options(selectinload(FermeVisite.bande), selectinload(FermeVisite.auteur))
               .order_by(FermeVisite.date_visite.desc(), FermeVisite.id.desc()).limit(200).all())
    return {"visites": [visite_json(v, u) for v in visites],
            "bandes": [{"id": b.id, "nom": b.nom or b.type_elevage, "batiment": b.poulailler.nom} for b in _bandes_en_cours(db)],
            "modes": MODES_PAIEMENT, "comptes": comptes_actifs(db) if _role(u) in ARGENT else [],
            "note_visites": _role(u) in NOTE_VISITES, "argent": _role(u) in ARGENT, "est_admin": _role(u) == "Admin"}


class VisiteIn(Formulaire):
    date_visite: date | None = None
    veterinaire: Texte = Field(min_length=2, max_length=100)
    telephone: Telephone | None = Field(None, max_length=30)
    bande_id: int | None = None
    constat: Texte | None = Field(None, max_length=1000)
    conseils: Texte | None = Field(None, max_length=1000)
    cout: Decimal | None = Field(None, ge=0, max_digits=12, decimal_places=2)
    mode_paiement: Literal[MODES_PAIEMENT] = "Espèce"
    compte_id: int | None = None


@router.post("/visites")
def noter_visite(d: VisiteIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _exiger(u, NOTE_VISITES, "Le Comptable consulte seulement.")
    jour = d.date_visite or date.today()
    _jour_ok(jour)
    b = charger(db, FermeBande, d.bande_id, "Lot introuvable.") if d.bande_id is not None else None
    v = FermeVisite(date_visite=jour, veterinaire=d.veterinaire, telephone=d.telephone or None, bande_id=b.id if b else None,
                    constat=d.constat or None, conseils=d.conseils or None, saisi_par=u.id)
    if d.cout and _role(u) in ARGENT:   # le prix de la visite devient une dépense de l'entreprise
        periode.verifier_ouverte(db, jour)
        dep = Depense(cite_id=None, montant=d.cout, categorie="Autre", a_la_charge_de="Entreprise", mode_paiement=d.mode_paiement,
                      motif=f"Visite du vétérinaire — {d.veterinaire}" + (f" ({b.nom or b.type_elevage})" if b else ""),
                      date_depense=jour, compte_id=tresorerie.verifier_compte_choisi(db, d.compte_id, d.mode_paiement), saisi_par=u.id,
                      ferme_bande_id=b.id if b else None)
        db.add(dep)
        db.flush()
        v.cout, v.depense_id = d.cout, dep.id
    db.add(v)
    enregistrer(db, "Enregistrement impossible.")
    db.refresh(v)
    return visite_json(v, u)


@router.post("/visites/{visite_id}/supprimer")
def supprimer_visite(visite_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été supprimé.")
    v = charger(db, FermeVisite, visite_id, "Visite introuvable.")
    if v.depense_id:
        dep = db.get(Depense, v.depense_id)
        if dep is not None:
            periode.verifier_ouverte(db, dep.date_depense)
            db.delete(dep)
    db.delete(v)
    enregistrer(db, "Suppression impossible.")
    return {"ok": True}


# ---------- Pour la fiche d'un lot, l'agenda et l'assistant ----------

def sante_bande(db: SessionDB, b: FermeBande, u: Utilisateur) -> dict:
    refs = references(db)
    soins = (db.query(FermeSoin).options(selectinload(FermeSoin.produit), selectinload(FermeSoin.auteur), selectinload(FermeSoin.bande))
             .filter(FermeSoin.bande_id == b.id).order_by(FermeSoin.date_soin.desc()).all())
    pesees = (db.query(FermePesee).options(selectinload(FermePesee.bande), selectinload(FermePesee.auteur))
              .filter(FermePesee.bande_id == b.id).order_by(FermePesee.date_pesee).all())
    visites = db.query(FermeVisite).filter(FermeVisite.bande_id == b.id).order_by(FermeVisite.date_visite.desc()).all()
    age = ((b.date_fin if b.statut == "Terminée" and b.date_fin else date.today()) - b.date_arrivee).days + b.age_arrivee
    return {"plan": plan_bande(b, programmes(db), soins, _stocks(db)), "soins": [soin_json(s) for s in soins],
            "pesees": [pesee_json(p, refs) for p in pesees], "reference": [[j, montant(p)] for j, p in refs.get(b.type_elevage, [])],
            "attendu_aujourdhui": montant(poids_attendu(refs.get(b.type_elevage, []), age)) if poids_attendu(refs.get(b.type_elevage, []), age) else None,
            "visites": [visite_json(v, u) for v in visites]}


def vaccins_prevus(db: SessionDB, debut: date, fin: date) -> dict[str, list[str]]:
    """Agenda : vaccins prévus (pas encore faits) entre deux dates, par jour."""
    bandes = _bandes_en_cours(db)
    progs, soins = programmes(db), _soins_par_bande(db, [b.id for b in bandes])
    par = defaultdict(list)
    for b in bandes:
        for l in plan_bande(b, progs, soins[b.id]):
            j = date.fromisoformat(l["date"])
            if l["etat"] != "fait" and debut <= j <= fin:
                par[l["date"]].append(f"Vaccin {l['nom']} — {b.nom or b.type_elevage} ({b.poulailler.nom})")
    return dict(par)


def alertes(db: SessionDB, u: Utilisateur) -> list[tuple[str, str, str, str]]:
    resultat = []
    bandes = _bandes_en_cours(db)
    progs, st, soins = programmes(db), _stocks(db), _soins_par_bande(db, [b.id for b in bandes])
    for b in bandes:
        nom = f"{b.nom or b.type_elevage} ({b.poulailler.nom})"
        for l in plan_bande(b, progs, soins[b.id], st):
            cle = f"ferme-vaccin-{b.id}-{l['programme_id']}"
            if l["etat"] == "retard":
                resultat.append((cle, "attention", f"{nom} : vaccin {l['nom']} en retard",
                                 f"Prévu le {date.fromisoformat(l['date']):%d/%m/%Y}. Faites-le vite, puis notez-le (Ferme → Santé)."))
            elif l["etat"] in ("aujourdhui", "demain"):
                resultat.append((cle, "info", f"{nom} : vaccin {l['nom']} {'aujourd’hui' if l['etat'] == 'aujourdhui' else 'demain'}",
                                 (l["mode"] + " · " if l["mode"] else "") + "à noter dans Ferme → Santé une fois fait."))
            if l["epuise"] and date.fromisoformat(l["date"]) <= date.today() + timedelta(days=7):
                resultat.append((f"ferme-epuise-{l['produit_id']}", "attention", f"Plus de « {l['produit']} » en stock",
                                 f"Il faut ce produit pour le vaccin {l['nom']} du {date.fromisoformat(l['date']):%d/%m/%Y} : prévoyez un achat."))
    refs = references(db)
    dernieres = {}
    for p in (db.query(FermePesee).options(selectinload(FermePesee.bande)).filter(FermePesee.bande_id.in_([b.id for b in bandes] or [0]))
              .order_by(FermePesee.date_pesee)):
        dernieres[p.bande_id] = p
    for p in dernieres.values():
        j = pesee_json(p, refs)
        if j["lent"]:
            resultat.append((f"ferme-poids-{p.bande_id}", "attention", f"{p.bande.nom or p.bande.type_elevage} : croissance lente",
                             f"{j['poids_g']} g à {j['age']} jours pour {j['attendu_g']} g attendus ({j['pour_cent']} %) : vérifiez l'aliment et la santé."))
    return resultat
