// Ferme (22/11/2026) : œufs (stock en plateaux de 30) et couvoir (couveuse ou poules, mirage, éclosion).
// Même style que la Ferme (ferme.js). Le serveur (ferme_oeufs.py) revérifie tout.

let oeufsFerme = null, couvoirFerme = null;
const ETAT_COUV = { "En cours": ["jaune", "En couvaison"], "Éclose": ["vert", "Éclose"], "Échouée": ["gris", "Échouée"] };
const plateauxTexte = n => { const p = Math.floor(Math.max(n, 0) / 30), r = Math.max(n, 0) % 30; return p ? `${p} plateau${p > 1 ? "x" : ""}${r ? ` et ${r} œuf${r > 1 ? "s" : ""}` : ""}` : `${r} œuf${r > 1 ? "s" : ""}`; };

Object.assign(ONGLETS_FERME, { frOeufs: () => chargerOeufsFerme(), frCouvoir: () => chargerCouvoirFerme() });

// ---------- Œufs ----------

async function chargerOeufsFerme() {
  const zone = el("zoneOeufsFerme");
  try { oeufsFerme = await api("/api/ferme/oeufs"); } catch (e) { erreurFerme(zone, e); return; }
  const o = oeufsFerme;
  const max = Math.max(1, ...o.par_jour.map(j => j.oeufs));
  const GENRE = { Maison: "Mangés à la maison", Perte: "Perdus", Correction: "Correction (comptage)", Achat: "Achetés" };
  zone.innerHTML = `
    <div class="fe-chiffres">
      <div class="fe-chiffre jaune">${imgFerme("plat:oeuf")}<span><span class="fe-chiffre-libelle">Œufs en stock</span><b>${nbFerme(o.stock)}</b><small>soit ${plateauxTexte(o.stock)}</small></span></div>
      <div class="fe-chiffre vert">${imgFerme("plat:oiseau")}<span><span class="fe-chiffre-libelle">Ramassés en 30 jours</span><b>${nbFerme(o.ramasses_30j)}</b><small>${plateauxTexte(o.ramasses_30j)}</small></span></div>
      <div class="fe-chiffre ${o.casses_30j ? "rouge" : "vert"}">${imgFerme("plat:alerte")}<span><span class="fe-chiffre-libelle">Cassés en 30 jours</span><b>${nbFerme(o.casses_30j)}</b><small>${o.ramasses_30j ? `${String(Math.round(o.casses_30j * 1000 / (o.ramasses_30j + o.casses_30j)) / 10).replace(".", ",")} % des œufs` : "—"}</small></span></div>
      <div class="fe-chiffre creme">${imgFerme("plat:panier")}<span><span class="fe-chiffre-libelle">Vendus</span><b>${nbFerme(o.vendus)}</b><small>${nbFerme(o.couves)} mis à couver</small></span></div>
    </div>
    ${o.soigne ? `<div class="fe-barre"><div class="fe-boutons">
      ${o.est_admin ? '<button class="btn ghost" onclick="formulaireOeufs(\'Correction\')">Corriger après comptage</button>' : ""}
      <button class="btn" onclick="formulaireOeufs('Achat')">Œufs achetés</button>
      <button class="btn primary" onclick="formulaireOeufs('Maison')">Sortir des œufs</button></div></div>` : ""}
    ${o.par_jour.length ? `<div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">Œufs ramassés chaque jour (30 derniers jours)</h3><div class="fe-barres">
      ${o.par_jour.map(j => `<div class="fe-barre-mois" data-tip="${formatDate(j.date)} : ${nbFerme(j.oeufs)} œufs"><div class="fe-colonnes"><span class="oe" style="height:${Math.round(j.oeufs / max * 100)}%"></span></div>
        <small>${j.date.slice(8, 10)}</small></div>`).join("")}</div>
      <p class="fe-aide">Les œufs entrent en stock avec le suivi du jour (colonne « Œufs ramassés »).</p></div>` : `<div class="fe-carte fe-vide">${imgFerme("oeuf", "fe-vide-img")}<p>Aucun œuf ramassé ces 30 derniers jours. Les œufs se notent dans le suivi du jour des pondeuses.</p></div>`}
    ${o.mouvements.length ? `<div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">Autres entrées et sorties</h3><div class="fe-tableau"><table><thead><tr><th>Date</th><th>Quoi</th><th class="nb">Œufs</th><th>Pourquoi</th><th>Par</th></tr></thead><tbody>
      ${o.mouvements.map(m => `<tr><td data-titre="Date">${formatDate(m.date)}</td><td data-titre="Quoi">${GENRE[m.genre] || esc(m.genre)}</td>
        <td data-titre="Œufs" class="nb"><b class="${m.quantite > 0 ? "fe-vert" : "fe-rouge"}">${m.quantite > 0 ? "+" : "−"} ${nbFerme(Math.abs(m.quantite))}</b></td>
        <td data-titre="Pourquoi">${esc(m.motif) || "—"}</td><td data-titre="Par"><small>${esc(m.saisi_par)}</small></td></tr>`).join("")}</tbody></table></div></div>` : ""}`;
}

function formulaireOeufs(genreDepart) {
  let genre = genreDepart;
  const GENRES = genreDepart === "Correction" ? [["Correction", "Corriger le stock", "après avoir compté les œufs"]]
    : genreDepart === "Achat" ? [["Achat", "Œufs achetés", "ils entrent dans le stock"]]
    : [["Maison", "Mangés à la maison", "pour la famille, les ouvriers…"], ["Perte", "Perdus", "cassés au transport, pourris…"]];
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("oeuf", "fe-fiche-img")}<div><h2>${GENRES[0][1]}</h2><p>En stock : ${plateauxTexte(oeufsFerme.stock)} (${nbFerme(oeufsFerme.stock)} œufs)</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    ${GENRES.length > 1 ? `<div class="fe-choix-types fe-choix-genres">${GENRES.map(([g, t, a]) => `<button type="button" class="fe-choix-type${g === genre ? " choisi" : ""}" data-genre="${g}"><b>${t}</b><small>${a}</small></button>`).join("")}</div>` : ""}
    <div class="fgrid" style="margin-top:1rem">
      <div class="field"><label for="oeNombre">${genre === "Correction" ? "Œufs comptés" : "Nombre d'œufs"}</label><div class="fe-quantite"><input id="oeNombre" inputmode="numeric" placeholder="0"><select id="oeUnite"><option value="1">œufs</option><option value="30">plateaux</option></select></div></div>
      <div class="field"><label for="oeDate">Date</label><input id="oeDate" type="date"></div>
    </div>
    <div class="field"><label for="oeMotif">Pourquoi ? (facultatif)</label><input id="oeMotif" maxlength="200"></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#oeDate").value = formatDate(aujourdhui());
  const g = fen.querySelector(".fe-choix-genres");
  if (g) g.addEventListener("click", e => { const x = e.target.closest("[data-genre]"); if (!x) return; genre = x.dataset.genre; g.querySelectorAll(".fe-choix-type").forEach(y => y.classList.toggle("choisi", y === x)); });
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const n = lireEntierFerme(fen.querySelector("#oeNombre").value);
      if (n === null || (!n && genre !== "Correction")) throw new Error("Indiquez le nombre.");
      ok.disabled = true;
      const r = await api("/api/ferme/oeufs/mouvements", { method: "POST", body: { genre, quantite: n * Number(fen.querySelector("#oeUnite").value),
        motif: fen.querySelector("#oeMotif").value.trim() || null, date_mouvement: isoDepuisTexte(fen.querySelector("#oeDate").value) } });
      fen.fermer(); toast(`C'est noté. En stock : ${r.plateaux}`); chargerOeufsFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

// ---------- Couvoir ----------

async function chargerCouvoirFerme() {
  const zone = el("zoneCouvoirFerme");
  try { couvoirFerme = await api("/api/ferme/couvoir"); } catch (e) { erreurFerme(zone, e); return; }
  const c = couvoirFerme, b = c.bilan;
  const enCours = c.couvaisons.filter(x => x.statut === "En cours"), finies = c.couvaisons.filter(x => x.statut !== "En cours");
  const pc = v => v === null || v === undefined ? "—" : `${String(v).replace(".", ",")} %`;
  zone.innerHTML = `
    <div class="fe-chiffres">
      <div class="fe-chiffre jaune">${imgFerme("plat:oeuf")}<span><span class="fe-chiffre-libelle">En couvaison</span><b>${nbFerme(enCours.reduce((t, x) => t + x.nombre_oeufs - x.oeufs_clairs, 0))}</b><small>œufs dans ${plurielFerme(enCours.length, "couvaison")}</small></span></div>
      <div class="fe-chiffre vert">${imgFerme("plat:naissance")}<span><span class="fe-chiffre-libelle">Taux d'éclosion</span><b>${pc(b.taux_eclosion)}</b><small>${nbFerme(b.eclos)} poussins pour ${nbFerme(b.oeufs)} œufs</small></span></div>
      <div class="fe-chiffre creme">${imgFerme("plat:coeur")}<span><span class="fe-chiffre-libelle">Œufs fécondés</span><b>${pc(b.taux_fecondite)}</b><small>vu au mirage</small></span></div>
      <div class="fe-chiffre bleu">${imgFerme("plat:oeuf")}<span><span class="fe-chiffre-libelle">Œufs en stock</span><b>${nbFerme(c.stock.stock)}</b><small>${esc(c.stock.plateaux)}</small></span></div>
    </div>
    ${c.soigne ? '<div class="fe-barre"><button class="btn primary" onclick="formulaireCouvaison()">+ Mettre des œufs à couver</button></div>' : ""}
    <div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">En couvaison</h3>
      ${enCours.length ? `<div class="fe-couvaisons">${enCours.map(x => {
        const pct = x.duree ? Math.min(100, Math.round(x.jours / x.duree * 100)) : 0;
        const mirageAFaire = x.mirage_prevu && !x.date_mirage && x.mirage_prevu <= aujourdhui();
        return `<div class="fe-couvaison">
          <div class="fe-bande">${imgFerme(x.dessin)}<span><b>${esc(x.espece)} · ${nbFerme(x.nombre_oeufs)} œufs</b><small>n° ${esc(x.numero)} · ${x.methode === "Couveuse" ? "couveuse" : "poules couveuses"}${x.couveuse ? " (" + esc(x.couveuse) + ")" : ""} · mis le ${formatDate(x.date_mise)}</small></span></div>
          <div class="fe-progres"><span style="width:${pct}%"></span></div>
          <div class="fe-progres-texte"><span>Jour ${x.jours} sur ${x.duree || "?"}</span><b>éclosion vers le ${formatDate(x.eclosion_prevue)}</b></div>
          <div class="fe-reperes" style="margin:.6rem 0 0">
            <span><small>Mirage</small>${x.date_mirage ? `fait le ${formatDate(x.date_mirage)} · ${x.oeufs_clairs} clairs retirés` : x.mirage_prevu ? `prévu le ${formatDate(x.mirage_prevu)}` : "—"}</span>
            <span><small>Œufs fécondés</small>${x.date_mirage ? nbFerme(x.fecondes) : "pas encore vu"}</span></div>
          ${c.soigne ? `<div class="actions" style="margin-top:.6rem">${!x.date_mirage ? `<button class="btn${mirageAFaire ? " primary" : ""}" onclick="formulaireMirage(${x.id})">Mirage</button>` : ""}
            <button class="btn${x.eclosion_prevue <= aujourdhui() ? " primary" : ""}" onclick="formulaireEclosion(${x.id})">Éclosion</button></div>` : ""}
        </div>`; }).join("")}</div>` : `<div class="fe-vide">${imgFerme("oeuf", "fe-vide-img")}<p>Aucun œuf en couvaison.</p></div>`}</div>
    ${finies.length ? `<div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">Couvaisons terminées</h3><div class="fe-tableau"><table><thead><tr><th>Couvaison</th><th class="nb">Œufs</th><th class="nb">Clairs</th><th class="nb">Éclos</th><th class="nb">Éclosion</th><th>Poussins</th><th>État</th></tr></thead><tbody>
      ${finies.map(x => `<tr${c.est_admin ? ` class="fe-ligne" onclick="supprimerCouvaison(${x.id})" data-tip="Cliquez pour supprimer"` : ""}>
        <td data-titre="Couvaison"><span class="fe-bande">${imgFerme(x.dessin)}<span><b>${esc(x.espece)}</b><small>n° ${esc(x.numero)} · ${x.date_eclosion ? "éclose le " + formatDate(x.date_eclosion) : "mise le " + formatDate(x.date_mise)}</small></span></span></td>
        <td data-titre="Œufs" class="nb">${nbFerme(x.nombre_oeufs)}</td><td data-titre="Clairs" class="nb">${nbFerme(x.oeufs_clairs)}</td>
        <td data-titre="Éclos" class="nb"><b class="fe-vert">${x.eclos ?? 0}</b></td><td data-titre="Éclosion" class="nb">${pc(x.taux_eclosion)}</td>
        <td data-titre="Poussins">${x.destination === "Vente" ? "à vendre" : x.lot ? esc(x.lot) : "—"}</td><td data-titre="État">${pastilleFerme(ETAT_COUV[x.statut])}</td></tr>`).join("")}
    </tbody></table></div></div>` : ""}`;
}

function formulaireCouvaison() {
  const c = couvoirFerme;
  if (!c.especes.length) { toast("Aucune espèce qui pond n'est élevée (Bâtiments et animaux)."); return; }
  let espece = c.especes[0].nom, origine = "Stock", methode = "Couveuse";
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("oeuf", "fe-fiche-img")}<div><h2>Mettre des œufs à couver</h2><p>En stock : ${esc(c.stock.plateaux)} (${nbFerme(c.stock.stock)} œufs)</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <h4 class="fe-titre">Quelle espèce ?</h4>
    <div class="fe-choix-types fe-choix-especes">${c.especes.map(e => `<button type="button" class="fe-choix-type${e.nom === espece ? " choisi" : ""}" data-espece="${esc(e.nom)}">${imgFerme(e.dessin, "fe-choix-img")}<b>${esc(e.nom)}</b><small>${e.incubation_jours} jours</small></button>`).join("")}</div>
    <h4 class="fe-titre">Comment ?</h4>
    <div class="fe-choix-types fe-choix-genres fe-ch-methode"><button type="button" class="fe-choix-type choisi" data-m="Couveuse"><b>Couveuse</b><small>une machine</small></button>
      <button type="button" class="fe-choix-type" data-m="Poules"><b>Poules couveuses</b><small>couvaison naturelle</small></button></div>
    <div class="fe-choix-types fe-choix-genres fe-ch-origine" style="margin-top:.8rem"><button type="button" class="fe-choix-type choisi" data-o="Stock"><b>Œufs de la ferme</b><small>pris dans le stock</small></button>
      <button type="button" class="fe-choix-type" data-o="Achetés"><b>Œufs achetés</b><small>ailleurs</small></button></div>
    <div class="fgrid" style="margin-top:1rem">
      <div class="field"><label for="cvNombre">Nombre d'œufs</label><input id="cvNombre" inputmode="numeric" placeholder="ex : 60"></div>
      <div class="field"><label for="cvCouveuse">Quelle couveuse ou quelles poules ? (facultatif)</label><input id="cvCouveuse" maxlength="80" placeholder="ex : couveuse 120 œufs"></div>
      <div class="field"><label for="cvDate">Mis à couver le</label><input id="cvDate" type="date"></div>
      ${c.argent ? '<div class="field" id="cvChampCout" style="display:none"><label for="cvCout">Prix des œufs achetés (F)</label><input id="cvCout" inputmode="numeric"></div>' : ""}
    </div>
    <div class="fe-fiche-grand vert"><b id="cvPrevu">—</b><span id="cvAide"></span></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Mettre à couver</button></div></div>`, { taille: "large fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#cvDate").value = formatDate(aujourdhui());
  const maj = () => {
    const e = c.especes.find(z => z.nom === espece), d = isoDepuisTexte(fen.querySelector("#cvDate").value);
    if (!d) { fen.querySelector("#cvPrevu").textContent = "—"; return; }
    const ec = new Date(d + "T00:00"); ec.setDate(ec.getDate() + e.incubation_jours);
    const mi = new Date(d + "T00:00"); mi.setDate(mi.getDate() + (e.mirage_jours || 7));
    fen.querySelector("#cvPrevu").textContent = `Éclosion vers le ${ec.toLocaleDateString("fr-FR")}`;
    fen.querySelector("#cvAide").textContent = `mirage vers le ${mi.toLocaleDateString("fr-FR")} · ${e.incubation_jours} jours de couvaison`;
  };
  const choix = (sel, attr, fn) => { const z = fen.querySelector(sel); z.addEventListener("click", ev => { const x = ev.target.closest(`[${attr}]`); if (!x) return; z.querySelectorAll(".fe-choix-type").forEach(y => y.classList.toggle("choisi", y === x)); fn(x.getAttribute(attr)); maj(); }); };
  choix(".fe-choix-especes", "data-espece", v => { espece = v; });
  choix(".fe-ch-methode", "data-m", v => { methode = v; });
  choix(".fe-ch-origine", "data-o", v => { origine = v; const z = fen.querySelector("#cvChampCout"); if (z) z.style.display = v === "Achetés" ? "" : "none"; });
  fen.querySelector("#cvDate").addEventListener("change", maj);
  maj();
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const n = lireEntierFerme(fen.querySelector("#cvNombre").value);
      if (!n) throw new Error("Indiquez le nombre d'œufs.");
      const date = isoDepuisTexte(fen.querySelector("#cvDate").value);
      if (!date) throw new Error("Date incorrecte : écrivez-la comme 02/12/2026.");
      const cout = fen.querySelector("#cvCout") && fen.querySelector("#cvCout").value.trim() ? lireMontant(fen.querySelector("#cvCout").value) : null;
      ok.disabled = true;
      const r = await api("/api/ferme/couvoir", { method: "POST", body: { espece, nombre_oeufs: n, origine, methode, cout_oeufs: cout,
        couveuse: fen.querySelector("#cvCouveuse").value.trim() || null, date_mise: date } });
      fen.fermer(); toast(`${nbFerme(n)} œufs mis à couver : éclosion vers le ${formatDate(r.eclosion_prevue)}`, 5000); chargerCouvoirFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

function formulaireMirage(id) {
  const x = couvoirFerme.couvaisons.find(z => z.id === id);
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("oeuf", "fe-fiche-img")}<div><h2>Mirage</h2><p>${esc(x.espece)} · ${nbFerme(x.nombre_oeufs)} œufs mis le ${formatDate(x.date_mise)}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <p class="fe-aide">Regardez chaque œuf à la lumière : un œuf « clair » (sans veines ni tache sombre) n'est pas fécondé. Retirez-les et comptez-les.</p>
    <div class="fgrid"><div class="field"><label for="miClairs">Œufs clairs retirés</label><input id="miClairs" inputmode="numeric" placeholder="0"></div>
      <div class="field"><label for="miDate">Date</label><input id="miDate" type="date"></div></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#miDate").value = formatDate(aujourdhui());
  fen.querySelector('[data-action="ok"]').addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const n = fen.querySelector("#miClairs").value.trim() ? lireEntierFerme(fen.querySelector("#miClairs").value) : 0;
      if (n === null) throw new Error("Nombre incorrect.");
      const r = await api(`/api/ferme/couvoir/${id}/mirage`, { method: "POST", body: { oeufs_clairs: n, date_mirage: isoDepuisTexte(fen.querySelector("#miDate").value) } });
      fen.fermer(); toast(`Mirage noté : ${nbFerme(r.fecondes)} œufs fécondés (${String(r.taux_fecondite).replace(".", ",")} %)`, 5000); chargerCouvoirFerme();
    } catch (e) { erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

function formulaireEclosion(id) {
  const c = couvoirFerme, x = c.couvaisons.find(z => z.id === id);
  let destination = "Nouveau lot";
  const lots = c.lots.filter(l => l.espece === x.espece);
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme(x.dessin, "fe-fiche-img")}<div><h2>Éclosion</h2><p>${esc(x.espece)} · ${nbFerme(x.fecondes)} œufs fécondés sur ${nbFerme(x.nombre_oeufs)}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid"><div class="field"><label for="ecEclos">Poussins éclos</label><input id="ecEclos" inputmode="numeric" placeholder="0"></div>
      <div class="field"><label for="ecDate">Date</label><input id="ecDate" type="date"></div></div>
    <h4 class="fe-titre">Les poussins vont…</h4>
    <div class="fe-choix-types fe-choix-genres"><button type="button" class="fe-choix-type choisi" data-d="Nouveau lot"><b>Dans un nouveau lot</b><small>créé tout seul</small></button>
      <button type="button" class="fe-choix-type" data-d="Lot existant"><b>Dans un lot existant</b><small>${lots.length ? "même espèce" : "aucun lot de cette espèce"}</small></button>
      <button type="button" class="fe-choix-type" data-d="Vente"><b>À la vente</b><small>poussins d'un jour</small></button></div>
    <div id="ecSuite" style="margin-top:1rem"></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer l'éclosion</button></div></div>`, { taille: "large fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#ecDate").value = formatDate(aujourdhui());
  const suite = () => {
    fen.querySelector("#ecSuite").innerHTML = destination === "Nouveau lot" ? `<div class="fgrid">
        <div class="field"><label for="ecBatiment">Dans quel bâtiment ?</label><select id="ecBatiment">${c.batiments.map(b => `<option value="${b.id}">${esc(b.nom)}</option>`).join("")}</select></div>
        <div class="field"><label for="ecNom">Petit nom du lot (facultatif)</label><input id="ecNom" maxlength="100" placeholder="Éclosion ${esc(x.numero)}"></div></div>`
      : destination === "Lot existant" ? (lots.length ? `<div class="field"><label for="ecLot">Quel lot ?</label><select id="ecLot">${lots.map(l => `<option value="${l.id}">${esc(l.nom)} (${esc(l.batiment)})</option>`).join("")}</select></div>`
        : '<p class="fe-aide">Aucun lot de cette espèce en cours.</p>')
      : '<p class="fe-aide">Les poussins sont notés « à vendre ». Leur vente se note ensuite dans Rentabilité → Ventes.</p>';
  };
  suite();
  fen.querySelector(".fe-choix-genres").addEventListener("click", e => { const b = e.target.closest("[data-d]"); if (!b) return; destination = b.dataset.d; fen.querySelectorAll(".fe-choix-genres .fe-choix-type").forEach(y => y.classList.toggle("choisi", y === b)); suite(); });
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const n = lireEntierFerme(fen.querySelector("#ecEclos").value);
      if (n === null || fen.querySelector("#ecEclos").value.trim() === "") throw new Error("Indiquez le nombre de poussins éclos (0 si aucun).");
      const q = s => fen.querySelector(s);
      ok.disabled = true;
      const r = await api(`/api/ferme/couvoir/${id}/eclosion`, { method: "POST", body: { eclos: n, destination, date_eclosion: isoDepuisTexte(q("#ecDate").value),
        poulailler_id: q("#ecBatiment") ? Number(q("#ecBatiment").value) : null, nom_lot: q("#ecNom") ? q("#ecNom").value.trim() || null : null,
        lot_id: q("#ecLot") ? Number(q("#ecLot").value) : null } });
      fen.fermer();
      toast(n ? `${nbFerme(n)} poussins éclos (${String(r.taux_eclosion).replace(".", ",")} %)${r.lot ? " : lot « " + r.lot + " »" : ""} 🐣` : "Couvaison notée comme échouée", 6000);
      tableauFerme = null; chargerCouvoirFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

async function supprimerCouvaison(id) {
  const x = couvoirFerme.couvaisons.find(z => z.id === id);
  const mdp = await demanderMotDePasseAdmin(`Supprimer la couvaison ${x ? x.numero : ""} ? Les œufs pris dans le stock y reviennent. Entrez votre mot de passe.`);
  if (!mdp) return;
  try { await api(`/api/ferme/couvoir/${id}/supprimer`, { method: "POST", body: { mot_de_passe_admin: mdp } }); toast("Couvaison supprimée"); chargerCouvoirFerme(); } catch (e) { toast(e.message, 7000); }
}
