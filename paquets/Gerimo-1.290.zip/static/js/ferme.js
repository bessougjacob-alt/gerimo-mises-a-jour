// Métier « Ferme » (22/11/2026) : bandes d'animaux (toutes les espèces), suivi du jour, bâtiments.
// Style propre à la ferme (demande de Boss du 22/11/2026) : couleurs paille / poussin / prairie / grange, un dessin
// par type de volaille (static/img/ferme), des tableaux simples à lire et des mots de tous les jours.
// Le suivi du jour : on coche les volailles concernées, une ligne par bande, UN bouton ; une fois enregistré, il
// s'affiche en lecture seule (bouton « Modifier » pour le corriger).
// Le serveur (ferme.py) revérifie tout : droits, dates, nombre de volailles en vie.

let tableauFerme = null;
let ongletFerme = "frBandes";
let suiviEnModification = false;     // « Modifier » demandé sur un suivi déjà enregistré
let jourSuiviFerme = null;
const IMG_FERME = "/static/img/ferme/";
// Espèces : liste libre venant du serveur (tableauFerme.especes : nom, groupe, dessin, production, naissances, bâtiment)
const especeFerme = nom => ((tableauFerme && tableauFerme.especes) || []).find(e => e.nom === nom);
// « volailles » si la ferme n'élève que des volailles, sinon « animaux »
const MOTS_VOLAILLE = { un: "volaille", des: "volailles", Des: "Volailles" };
const MOTS_ANIMAUX = { un: "animal", des: "animaux", Des: "Animaux" };
function motsFerme(bandes) {
  const t = tableauFerme;
  const groupes = bandes && bandes.length ? bandes.map(b => b.groupe) : t && t.bandes.length ? t.bandes.map(b => b.groupe) : ["Autre"];
  return groupes.every(g => g === "Volaille") ? MOTS_VOLAILLE : MOTS_ANIMAUX;
}
const CAUSES_MORTS = ["Chaleur", "Maladie", "Étouffement", "Rat ou serpent", "Accident", "Je ne sais pas"];
// Icônes plates (demande de Boss du 22/11/2026) : dans les cartes de chiffres, un symbole simple au lieu d'un dessin
const PLATS = {
  patte: '<circle cx="12" cy="15.5" r="3.6"/><circle cx="6.3" cy="10.5" r="1.9"/><circle cx="9.6" cy="6.6" r="1.9"/><circle cx="14.4" cy="6.6" r="1.9"/><circle cx="17.7" cy="10.5" r="1.9"/>',
  oiseau: '<path d="M16 7a3 3 0 1 0-5.6 1.5L8 11c-2.5 0-4 1.8-4 4 0 2.8 2.7 4.5 6 4.5h3.5c3.6 0 6-2.6 6-6 0-1.7-.7-3.2-1.8-4.2"/><path d="M16 7h3l-1.5 1.5"/><path d="M10 15.5c1.5 0 3-.8 3.6-2.2"/>',
  poisson: '<path d="M3 12c2.5-4 6-6 10-6 3 0 5.5 2 7 6-1.5 4-4 6-7 6-4 0-7.5-2-10-6z"/><path d="M3 12 1 8.5M3 12l-2 3.5"/><circle cx="15.5" cy="10.5" r=".9"/>',
  grange: '<path d="M3 21V10l9-6 9 6v11"/><path d="M8 21v-6h8v6"/><path d="M8 15l8 6M16 15l-8 6"/>',
  oeuf: '<path d="M12 3c-3.5 0-6.5 5.5-6.5 10a6.5 6.5 0 0 0 13 0C18.5 8.5 15.5 3 12 3z"/>',
  sac: '<path d="M7 7h10l2 12.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 5 19.5z"/><path d="M8.5 7 7 3.5h10L15.5 7"/><path d="M9.5 13.5h5"/>',
  seringue: '<path d="m18 2 4 4"/><path d="m17 7 3-3"/><path d="M19 9 8.7 19.3a2.4 2.4 0 0 1-3.4 0l-.6-.6a2.4 2.4 0 0 1 0-3.4L15 5"/><path d="m9 11 4 4"/><path d="m5 19-3 3"/>',
  croix: '<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M12 8v8M8 12h8"/>',
  liste: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 3v2h6V3"/><path d="m9 13 2 2 4-4"/>',
  tombe: '<path d="M6 21V10a6 6 0 0 1 12 0v11z"/><path d="M12 9v6M9.5 11.5h5"/><path d="M4 21h16"/>',
  male: '<circle cx="10" cy="14" r="5.5"/><path d="M14 10l6-6M15 4h5v5"/>',
  femelle: '<circle cx="12" cy="9" r="5.5"/><path d="M12 14.5V21M9 18h6"/>',
  coeur: '<path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7z"/>',
  naissance: '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
  argent: '<ellipse cx="9" cy="7" rx="6" ry="3"/><path d="M3 7v5c0 1.7 2.7 3 6 3s6-1.3 6-3V7"/><path d="M9 15v3c0 1.7 2.7 3 6 3s6-1.3 6-3v-5c0-1.7-2.7-3-6-3"/>',
  charges: '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  hausse: '<path d="M3 17l6-6 4 4 8-8"/><path d="M14 7h7v7"/>',
  baisse: '<path d="M3 7l6 6 4-4 8 8"/><path d="M14 17h7v-7"/>',
  alerte: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
  panier: '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2.5 3h2.6l2.4 11.2a2 2 0 0 0 2 1.6h7.9a2 2 0 0 0 2-1.5L21 7H6.2"/>',
};
// symboles des espèces et des objets (même style que les autres icônes plates)
Object.assign(PLATS, {
  coq: PLATS.oiseau + '<path d="M13.6 4.6c.3-1.6 1.9-1.8 2.2-.3.7-1.1 2.2-.6 1.9.8"/>',
  pondeuse: PLATS.oiseau + '<ellipse cx="20.3" cy="19.6" rx="1.7" ry="2.1"/>',
  pintade: PLATS.oiseau + '<path d="M9 16h.01M12 15h.01M10.5 18.2h.01M7.5 18h.01"/>',
  canard: '<path d="M8 8a3 3 0 1 1 5.5 1.7c3 .5 7.5 1.3 7.5 5.3 0 3-2.5 5-7 5H9c-3.5 0-6-2-6-5 0-2 1.2-3.5 3-4"/><path d="M5 8H2.5"/><circle cx="10.6" cy="7.2" r=".7"/>',
  lapin: '<path d="M9.5 9.2C8 6 8 3 9.3 3s2.4 3 2 6.2"/><path d="M12.8 9.2c.5-3.2 1.6-6.2 2.9-6.2s1 3-1 6.2"/><circle cx="12" cy="14.5" r="5.5"/><path d="M10.2 13.6h.01M13.8 13.6h.01M11 16.8h2"/>',
  rongeur: '<path d="M4 15c0-4.5 4-7.5 8.5-7.5S21 10 21 14c0 3-2.5 5-6 5H8c-2.5 0-4-1.7-4-4z"/><circle cx="7.5" cy="12.5" r=".8"/><path d="M4.2 15.5H2.5"/><path d="M8 19v2M16 19v2"/>',
  porc: '<path d="M4 13c0-4 3.6-7 8-7s8 3 8 7-3.6 6.5-8 6.5S4 17 4 13z"/><path d="M5.5 8 4.5 4l3.5 2.5M18.5 8l1-4-3.5 2.5"/><ellipse cx="12" cy="14.3" rx="3" ry="2.2"/><path d="M11 14.3h.01M13 14.3h.01"/>',
  mouton: '<path d="M7 10a3 3 0 0 1 5-2 3 3 0 0 1 5 2 3 3 0 0 1 0 6 3 3 0 0 1-5 1.5A3 3 0 0 1 7 16a3 3 0 0 1 0-6z"/><path d="M9 18v3M15 18v3"/>',
  chevre: '<path d="M8.3 6.2C7.5 4 5.6 3 4.4 3.5M15.7 6.2C16.5 4 18.4 3 19.6 3.5"/><path d="M7 9c0-2.5 2.2-4 5-4s5 1.5 5 4l-1 6c-.5 2.5-2 4-4 4s-3.5-1.5-4-4z"/><path d="M12 19v2.5"/><path d="M10 11h.01M14 11h.01"/>',
  boeuf: '<path d="M4 5.5c0 2 1.5 3.3 3 3.3M20 5.5c0 2-1.5 3.3-3 3.3"/><path d="M7 9c0-2 2.2-3 5-3s5 1 5 3v5c0 3-2 5-5 5s-5-2-5-5z"/><ellipse cx="12" cy="15.6" rx="3" ry="2"/><path d="M10 11h.01M14 11h.01"/>',
  seau: '<path d="M5 8h14l-1.5 12a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1z"/><path d="M8 8a4 4 0 0 1 8 0"/>',
  maison: '<path d="M3 11 12 4l9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-5h4v5"/>',
  lots: '<path d="m12 2.5 9 5-9 5-9-5z"/><path d="m3 12 9 5 9-5"/><path d="m3 16.5 9 5 9-5"/>',
});
const DESSIN_PLAT = { poussin: "oiseau", "poulet-chair": "oiseau", pondeuse: "pondeuse", coq: "coq", pintade: "pintade", canard: "canard",
  lapin: "lapin", aulacode: "rongeur", porc: "porc", mouton: "mouton", chevre: "chevre", boeuf: "boeuf", animal: "patte", poisson: "poisson",
  ferme: "patte", oeuf: "oeuf", sac: "sac", vaccin: "seringue", medicament: "croix", materiel: "seau", poulailler: "maison", "poulet-mort": "tombe" };
// teinte douce du carré selon la famille du symbole
const TEINTE_PLAT = { oiseau: "volaille", coq: "volaille", pondeuse: "volaille", pintade: "volaille", canard: "volaille",
  lapin: "petits", rongeur: "petits", porc: "betail", mouton: "betail", chevre: "betail", boeuf: "betail", poisson: "eau",
  tombe: "mort", seringue: "soin", croix: "soin" };
const icoPlat = (nom, classe = "") => `<span class="fe-plat ${classe} t-${TEINTE_PLAT[nom] || "objet"}"><svg viewBox="0 0 24 24" aria-hidden="true">${PLATS[nom] || PLATS.patte}</svg></span>`;
// Tout est en icônes plates dans la Ferme (demande de Boss du 22/11/2026) : « plat:nom » ou un nom de dessin (espèce, objet)
const imgFerme = (nom, classe = "fe-ico") => {
  if (nom.startsWith("plat:")) return icoPlat(nom.slice(5), classe === "fe-ico" ? "" : classe);
  const plat = DESSIN_PLAT[nom] || (PLATS[nom] ? nom : "patte");
  return classe === "fe-chiffre-img" ? icoPlat(plat) : icoPlat(plat, classe);
};
const imgType = (type, classe) => imgFerme((especeFerme(type) || {}).dessin || "animal", classe);
// Dessin de l'espèce qui compte le plus d'animaux en vie (une seule espèce : la sienne) ; plusieurs ou aucune : la ferme
function dessinFerme(bandes) {
  const liste = bandes || (tableauFerme ? tableauFerme.bandes : []);
  const parEspece = {};
  liste.forEach(b => { parEspece[b.dessin] = (parEspece[b.dessin] || 0) + (b.vivants || 0); });
  const cles = Object.keys(parEspece);
  return cles.length === 1 ? cles[0] : cles.length ? cles.sort((x, y) => parEspece[y] - parEspece[x])[0] : "ferme";
}
// Symbole de l'espèce avec une petite marque : ✕ mort (grisé), cœur, naissance, ♂, ♀
const MARQUES = { mort: "✕", coeur: "♥", naissance: "+", male: "♂", femelle: "♀" };
function imgMarque(dessin, marque, classe = "fe-ico") {
  if (classe === "fe-chiffre-img") return icoPlat(marque === "mort" ? "tombe" : marque);
  return `<span class="fe-marque ${marque}">${imgFerme(dessin || "animal", classe)}<i>${MARQUES[marque] || ""}</i></span>`;
}
const nbFerme = n => Number(n || 0).toLocaleString("fr-FR", { maximumFractionDigits: 2 }).replace(/[  ]/g, " ");
const plurielFerme = (n, mot, motPluriel = mot + "s") => `${nbFerme(n)} ${Math.abs(n) > 1 ? motPluriel : mot}`;
const lireNombreFerme = texte => {   // « 12,5 » → 12.5 ; vide → 0 ; invalide → null
  const propre = String(texte || "").replace(/\s/g, "").replace(",", ".");
  if (!propre) return 0;
  return /^\d+(\.\d{1,2})?$/.test(propre) ? Number(propre) : null;
};
const lireEntierFerme = texte => { const n = lireNombreFerme(texte); return n === null || !Number.isInteger(n) ? null : n; };
// État d'une bande en mots simples : [classe de couleur, texte]
const ETAT_BANDE = {
  ok: ["vert", "Suivi du jour fait"], a_saisir: ["jaune", "Suivi du jour à faire"],
  alerte: ["rouge", "Beaucoup de morts cette semaine"], termine: ["gris", "Terminé"],
};
const pastilleEtat = etat => { const [c, t] = ETAT_BANDE[etat] || ETAT_BANDE.ok; return `<span class="fe-pastille ${c}">${t}</span>`; };

const ONGLETS_FERME = { frBandes: () => chargerBandesFerme(), frSuivi: () => chargerSuiviFerme(),
                        frTerminees: () => chargerBandesTerminees(), frPoulaillers: () => chargerPoulaillers() };
function montrerOngletFerme(id) {
  ongletFerme = id;
  document.querySelectorAll("#ongletsFerme .onglet").forEach(b => b.classList.toggle("actif", b.dataset.onglet === id));
  Object.keys(ONGLETS_FERME).forEach(z => { el(z).style.display = z === id ? "" : "none"; });
  ONGLETS_FERME[id]();
}
el("ongletsFerme").addEventListener("click", e => { const b = e.target.closest(".onglet"); if (b) montrerOngletFerme(b.dataset.onglet); });
CHARGEURS.ferme = () => { suiviEnModification = false; montrerOngletFerme(ongletFerme); };

async function chargerTableauFerme() {
  tableauFerme = await api("/api/ferme/tableau");
  document.querySelectorAll("#ongletsFerme .onglet-saisie").forEach(b => { b.style.display = tableauFerme.peut_saisir ? "" : "none"; });
  document.querySelectorAll("#ongletsFerme .onglet-argent").forEach(b => { b.style.display = tableauFerme.voit_argent ? "" : "none"; });
  return tableauFerme;
}
const erreurFerme = (zone, e) => { zone.innerHTML = `<div class="fe-carte fe-vide">${esc(e.message)}</div>`; };

// ---------- Tableau des bandes (en cours ou terminées) ----------

function tableauBandes(liste, { terminees = false } = {}) {
  const pondeuses = liste.some(b => b.pondeuses);
  return `<div class="fe-tableau"><table>
    <thead><tr><th>Lot</th><th>Bâtiment</th><th class="nb">Âge</th><th class="nb">En vie</th><th class="nb">Morts</th>
      ${pondeuses && !terminees ? '<th class="nb">Œufs du jour</th>' : ""}<th>${terminees ? "Fin" : "Aujourd'hui"}</th></tr></thead>
    <tbody>${liste.map(b => `<tr class="fe-ligne" onclick="ouvrirFicheBande(${b.id})" tabindex="0" onkeydown="if(event.key==='Enter')ouvrirFicheBande(${b.id})">
      <td data-titre="Lot"><span class="fe-bande">${imgType(b.type)}<span><b>${esc(b.nom || b.type)}</b>
        <small>arrivé le ${formatDate(b.date_arrivee)}</small></span></span></td>
      <td data-titre="Bâtiment">${esc(b.poulailler)}</td>
      <td data-titre="Âge" class="nb">${ageTexteFerme(b.age_jours)}</td>
      <td data-titre="En vie" class="nb"><b class="fe-gros">${nbFerme(b.vivants)}</b></td>
      <td data-titre="Morts" class="nb">${b.morts ? `<span class="fe-rouge">${nbFerme(b.morts)}</span>` : "0"}</td>
      ${pondeuses && !terminees ? `<td data-titre="Œufs du jour" class="nb">${b.pondeuses ? nbFerme(b.oeufs_jour) : "—"}</td>` : ""}
      <td data-titre="${terminees ? "Fin" : "Aujourd'hui"}">${terminees ? formatDate(b.date_fin) : pastilleEtat(b.etat)}</td>
    </tr>`).join("")}</tbody></table></div>`;
}

async function chargerBandesFerme() {
  const zone = el("listeBandes");
  try { await chargerTableauFerme(); } catch (e) { erreurFerme(zone, e); return; }
  const t = tableauFerme;
  el("btnNouvelleBande").style.display = t.cree_bandes ? "" : "none";
  el("resumeFerme").innerHTML = htmlChiffresFerme(t);
  afficherBandesFerme();
}

// Bannière et grands chiffres de la ferme (écran Bandes et accueil)
function htmlChiffresFerme(t, { action = true } = {}) {
  const pondeuses = t.bandes.some(b => b.pondeuses);
  const chiffre = (img, valeur, libelle, aide, couleur, action = "") =>
    `<${action ? "button type=\"button\"" : "div"} class="fe-chiffre ${couleur}"${action ? ` onclick="${action}"` : ""}>${img.startsWith("<") ? img : imgFerme(img, "fe-chiffre-img")}
      <span><b>${valeur}</b><span class="fe-chiffre-libelle">${libelle}</span><small>${aide}</small></span></${action ? "button" : "div"}>`;
  return `
    <div class="fe-banniere">${imgFerme(dessinFerme(t.bandes), "fe-banniere-img")}<div><h3>Votre ferme aujourd'hui</h3>
      <p>${formatDate(t.aujourdhui)} · ${plurielFerme(t.bandes.length, "lot en cours", "lots en cours")} · ${plurielFerme(t.poulaillers.filter(p => p.actif).length, "bâtiment")}</p></div></div>
    <div class="fe-chiffres">
      ${chiffre(dessinFerme(t.bandes), nbFerme(t.total.vivants), `${motsFerme().Des} en vie`, t.total.naissances_7j ? `dont ${nbFerme(t.total.naissances_7j)} nés cette semaine` : "dans tous les lots", "jaune")}
      ${pondeuses ? chiffre("oeuf", nbFerme(t.total.oeufs_jour), "Œufs ramassés aujourd'hui", `soit ${plurielFerme(Math.floor(t.total.oeufs_jour / 30), "plateau")} de 30`, "creme") : ""}
      ${chiffre(imgMarque(dessinFerme(t.bandes), "mort", "fe-chiffre-img"), nbFerme(t.total.morts_7j), "Morts cette semaine", t.total.morts_7j ? "les 7 derniers jours" : "aucune perte 👍", t.total.morts_7j ? "rouge" : "vert")}
      ${t.peut_saisir ? chiffre("poulailler", t.total.a_saisir ? t.total.a_saisir : `${t.bandes.length} sur ${t.bandes.length}`, t.total.a_saisir ? "Suivis à faire" : "Suivis faits", t.total.a_saisir ? "cliquez pour les faire" : "tout est noté aujourd'hui",
                                t.total.a_saisir ? "jaune" : "vert", action ? "ouvrirSuiviFerme()" : "") : ""}
    </div>`;
}

// Accueil (licence avec la Ferme) : la ferme d'un coup d'œil ; un clic ouvre la Ferme
async function chargerAccueilFerme() {
  const zone = el("accueilFerme");
  if (!zone || typeof peut !== "function" || !peut("ferme")) return;
  try { await chargerTableauFerme(); } catch { zone.innerHTML = ""; return; }
  zone.innerHTML = htmlChiffresFerme(tableauFerme);
  const banniere = zone.querySelector(".fe-banniere");
  if (banniere) { banniere.classList.add("cliquable"); banniere.onclick = () => { ongletFerme = "frBandes"; ouvrirEspace("ferme"); }; }
}
window.addEventListener("load", () => {
  const avant = CHARGEURS.accueil;
  CHARGEURS.accueil = () => { if (avant) avant(); chargerAccueilFerme(); };
  if (el("accueil") && el("accueil").classList.contains("active")) chargerAccueilFerme();   // accueil déjà affiché
});

function afficherBandesFerme() {
  const zone = el("listeBandes");
  const t = tableauFerme;
  if (!t.poulaillers.length) {
    zone.innerHTML = `<div class="fe-carte fe-vide">${imgFerme("poulailler", "fe-vide-img")}<p>${t.est_admin ? "Commencez par créer vos bâtiments (poulailler, clapier, porcherie… : rubrique « Bâtiments et animaux »), puis ajoutez votre premier lot."
      : "Aucun bâtiment pour l'instant : l'Admin doit les créer (Ferme → Bâtiments et animaux)."}</p></div>`;
    return;
  }
  if (!t.bandes.length) {
    zone.innerHTML = `<div class="fe-carte fe-vide">${imgFerme("ferme", "fe-vide-img")}<p>Aucune lot en cours.${t.cree_bandes ? "<br>Quand les animaux arrivent, cliquez sur « + Nouveau lot »." : ""}</p></div>`;
    return;
  }
  const mots = normaliser(el("rechercheFerme").value).split(/\s+/).filter(Boolean);
  const liste = t.bandes.filter(b => !mots.length || mots.every(m => normaliser([b.libelle, b.numero, b.poulailler, b.souche, b.type, b.fournisseur].join(" ")).includes(m)));
  const rang = b => ({ alerte: 0, a_saisir: 1, ok: 2 })[b.etat] ?? 3;   // les plus urgentes d'abord
  liste.sort((x, y) => rang(x) - rang(y) || y.date_arrivee.localeCompare(x.date_arrivee));
  zone.innerHTML = liste.length ? `<div class="fe-carte">${tableauBandes(liste)}</div>` : '<div class="fe-carte fe-vide"><p>Aucun lot ne correspond.</p></div>';
}
el("rechercheFerme").addEventListener("input", () => { if (tableauFerme) afficherBandesFerme(); });

async function chargerBandesTerminees() {
  const zone = el("listeBandesTerminees");
  let liste;
  try {
    if (!tableauFerme) await chargerTableauFerme();
    liste = await api("/api/ferme/bandes?statut=" + encodeURIComponent("Terminée"));
  } catch (e) { erreurFerme(zone, e); return; }
  zone.innerHTML = liste.length ? `<div class="fe-carte">${tableauBandes(liste, { terminees: true })}</div>`
    : `<div class="fe-carte fe-vide">${imgFerme("poulailler", "fe-vide-img")}<p>Aucune lot terminé pour l'instant.</p></div>`;
}

// ---------- Fiche d'une bande ----------

async function ouvrirFicheBande(id) {
  let b;
  try { b = await api(`/api/ferme/bandes/${id}`); if (!tableauFerme) await chargerTableauFerme(); } catch (e) { toast(e.message); return; }
  const t = tableauFerme;
  const pct = n => String(n).replace(".", ",") + " %";
  const ligne = (libelle, valeur, aide = "") => valeur === null || valeur === undefined || valeur === "" ? "" :
    `<tr><th>${libelle}</th><td>${valeur}${aide ? ` <small>${aide}</small>` : ""}</td></tr>`;
  const prix = b.cout_achat === undefined ? null : b.cout_achat === null ? '<span class="fe-pastille jaune">à compléter</span>'
    : `${formatMontant(b.cout_achat)}`;
  const fen = ouvrirFenetre(`
    <div class="fe-fiche">
      <div class="fe-fiche-tete">${imgType(b.type, "fe-fiche-img")}
        <div><h2>${esc(b.nom || b.type)}</h2><p>${esc(b.type)} · ${esc(b.poulailler)} · n° ${esc(b.numero)}</p></div>
        <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
      <div class="fe-fiche-grand ${(ETAT_BANDE[b.etat] || ETAT_BANDE.ok)[0]}">
        <b>${plurielFerme(b.vivants, `${motsFerme([b]).un} en vie`, `${motsFerme([b]).des} en vie`)}</b>
        <span>${pastilleEtat(b.etat)} · sur ${nbFerme(b.effectif_depart)} à l'arrivée</span></div>
      <div class="fe-fiche-colonnes">
        <div class="fe-tableau fe-tableau-cles"><table><tbody>
          ${ligne("Arrivée le", formatDate(b.date_arrivee))}
          ${ligne("Âge à l'arrivée", ageTexteFerme(b.age_arrivee))}
          ${ligne("À la ferme depuis", ageTexteFerme(b.a_la_ferme_jours))}
          ${ligne("Âge aujourd'hui", `<b>${ageTexteFerme(b.age_jours)}</b>`, b.age_jours >= 60 ? `(${plurielFerme(b.age_jours, "jour")})` : "")}
          ${b.males != null || b.femelles != null ? ligne("À l'arrivée", `${b.males ?? "?"} ♂ · ${b.femelles ?? "?"} ♀`) : ""}
          ${ligne("Morts depuis l'arrivée", nbFerme(b.morts), `(${pct(b.mortalite)})`)}
          ${ligne("Morts cette semaine", nbFerme(b.morts_7j), b.morts_7j ? `(${pct(b.mortalite_7j)})` : "")}
          ${b.avec_naissances ? ligne("Naissances depuis l'arrivée", nbFerme(b.naissances)) : ""}
          ${b.lait ? ligne("Lait aujourd'hui", `${nbFerme(b.lait_jour)} L`, `(${nbFerme(b.lait_total)} L depuis l'arrivée)`) : ""}
          ${b.pondeuses ? ligne("Œufs aujourd'hui", nbFerme(b.oeufs_jour), b.ponte_jour ? `(${nbFerme(b.ponte_jour)} œufs pour 100 poules)` : "") : ""}
          ${b.pondeuses ? ligne("Œufs depuis l'arrivée", nbFerme(b.oeufs_total), `(${plurielFerme(Math.floor(b.oeufs_total / 30), "plateau")})`) : ""}
          ${b.date_fin ? ligne("Terminé le", formatDate(b.date_fin)) : ""}
        </tbody></table></div>
        <div class="fe-tableau fe-tableau-cles"><table><tbody>
          ${ligne("Aliment donné", `${nbFerme(b.aliment_kg)} kg`, `(${plurielFerme(Math.round(b.aliment_kg / 50 * 10) / 10, "sac")} de 50 kg)`)}
          ${ligne(`Aliment par ${motsFerme([b]).un}`, `${nbFerme(b.aliment_par_sujet_kg)} kg`)}
          ${t.voit_argent ? ligne("Prix des poussins", prix, b.cout_par_sujet ? `(${formatMontant(b.cout_par_sujet)} l'un)` : "") : ""}
          ${ligne("Achetés chez", b.fournisseur ? esc(b.fournisseur) : "")}
          ${ligne("Race", b.souche ? esc(b.souche) : "")}
          ${ligne("Note", b.note ? esc(b.note) : "")}
        </tbody></table></div>
      </div>
      <h4 class="fe-titre">Jour par jour</h4>
      ${b.suivis.length ? `<div class="fe-tableau fe-defile"><table><thead><tr><th>Date</th><th class="nb">Morts</th><th>Pourquoi</th>${b.pondeuses ? '<th class="nb">Œufs</th><th class="nb">Cassés</th>' : ""}<th class="nb">Aliment</th><th>Noté par</th></tr></thead><tbody>
        ${b.suivis.slice(0, 90).map(s => `<tr><td>${formatDate(s.date)}</td><td class="nb">${s.morts ? `<b class="fe-rouge">${s.morts}</b>` : "0"}</td><td>${esc(s.cause_morts) || ""}</td>
          ${b.pondeuses ? `<td class="nb">${nbFerme(s.oeufs)}</td><td class="nb">${s.oeufs_casses || "0"}</td>` : ""}<td class="nb">${s.aliment_kg ? nbFerme(s.aliment_kg) + " kg" : "—"}</td><td><small>${esc(s.saisi_par)}</small></td></tr>`).join("")}
      </tbody></table></div>` : '<p class="fe-aide">Aucun suivi noté pour l\'instant.</p>'}
      ${typeof htmlSanteBande === "function" ? htmlSanteBande(b) : ""}
      <div class="actions">
        ${t.est_admin && !b.suivis.length ? '<button class="btn ghost" data-action="supprimer">Supprimer</button>' : ""}
        ${t.est_admin && b.statut === "En cours" ? '<button class="btn ghost" data-action="terminer">Terminer le lot</button>' : ""}
        ${t.est_admin && b.statut === "Terminée" ? '<button class="btn ghost" data-action="reprendre">Remettre en cours</button>' : ""}
        ${t.cree_bandes && (b.statut === "En cours" || t.est_admin) ? '<button class="btn" data-action="modifier">Modifier</button>' : ""}
        ${t.peut_saisir && b.statut === "En cours" ? '<button class="btn" data-action="soin">Noter un soin</button><button class="btn" data-action="peser">Peser</button>' : ""}
        ${t.peut_saisir && b.statut === "En cours" ? '<button class="btn primary" data-action="suivi">Faire le suivi du jour</button>' : ""}
      </div>
    </div>`, { taille: "large fe-fenetre" });
  const action = (nom, fn) => { const x = fen.querySelector(`[data-action="${nom}"]`); if (x) x.addEventListener("click", fn); };
  action("supprimer", () => supprimerBande(b, fen));
  action("terminer", () => terminerBande(b, fen));
  action("reprendre", () => reprendreBande(b, fen));
  action("modifier", () => { fen.fermer(); formulaireBande(b); });
  action("suivi", () => { fen.fermer(); ouvrirSuiviFerme(); });
  action("soin", () => { fen.fermer(); formulaireSoinFerme(null, b.id); });
  action("peser", () => { fen.fermer(); formulairePeseeFerme(b.id); });
}
window.addEventListener("load", () => { if (typeof FICHES !== "undefined") FICHES.bande = id => ouvrirFicheBande(id); });

function ouvrirSuiviFerme() {
  suiviEnModification = false;
  if (el("ferme").classList.contains("active")) montrerOngletFerme("frSuivi"); else { ongletFerme = "frSuivi"; ouvrirEspace("ferme"); }
}
function rechargerFerme() { montrerOngletFerme(ongletFerme); }

async function terminerBande(b, fen) {
  if (!confirm(`Terminer le lot « ${b.nom || b.type} » (${b.poulailler}) ?\n\nElle passera dans « Lots terminés » ; tout son historique reste consultable.`)) return;
  try {
    await api(`/api/ferme/bandes/${b.id}/terminer`, { method: "POST", body: {} });
    fen.fermer();
    toast("Lot terminé");
    rechargerFerme();
  } catch (e) { toast(e.message, 7000); }
}
async function reprendreBande(b, fen) {
  try {
    await api(`/api/ferme/bandes/${b.id}/reprendre`, { method: "POST", body: {} });
    fen.fermer();
    toast("Le lot est de nouveau en cours");
    rechargerFerme();
  } catch (e) { toast(e.message, 7000); }
}
async function supprimerBande(b, fen) {
  const mdp = await demanderMotDePasseAdmin(`Supprimer le lot « ${b.nom || b.type} » (${b.poulailler}) ? Entrez votre mot de passe.`);
  if (!mdp) return;
  try {
    await api(`/api/ferme/bandes/${b.id}/supprimer`, { method: "POST", body: { mot_de_passe_admin: mdp } });
    fen.fermer();
    toast("Lot supprimé");
    rechargerFerme();
  } catch (e) { toast(e.message, 7000); }
}

// ---------- Nouvelle bande / modifier ----------

async function formulaireBande(b) {
  try { if (!tableauFerme) await chargerTableauFerme(); } catch (e) { toast(e.message); return; }
  const t = tableauFerme;
  const poulaillers = t.poulaillers.filter(p => p.actif || (b && p.id === b.poulailler_id));
  if (!poulaillers.length) { toast(t.est_admin ? "Créez d'abord un bâtiment (Ferme → Bâtiments et animaux)." : "Aucun bâtiment : demandez à l'Admin d'en créer un.", 6000); return; }
  let type = b ? b.type : null;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme(b ? (especeFerme(b.type) || {}).dessin || "ferme" : "ferme", "fe-fiche-img")}<div><h2>${b ? "Modifier le lot" : "Nouveau lot"}</h2>
      <p>Un lot = des animaux de la même espèce arrivés ensemble dans le même bâtiment.</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <h4 class="fe-titre">1. Quels animaux ?</h4>
    <div class="fe-choix-types" role="radiogroup" aria-label="Espèce">${t.especes.filter(e => e.actif || (b && e.nom === b.type)).map(e => e.nom).map(x => `
      <button type="button" class="fe-choix-type${x === type ? " choisi" : ""}" data-type="${esc(x)}" role="radio" aria-checked="${x === type}">
        ${imgType(x, "fe-choix-img")}<b>${esc(x)}</b><small>${esc((especeFerme(x) || {}).groupe || "")}</small></button>`).join("")}</div>
    <h4 class="fe-titre">2. Combien, où et quand ?</h4>
    <div class="fgrid">
      <div class="field"><label for="bdEffectif">Nombre d'animaux à l'arrivée</label><input id="bdEffectif" inputmode="numeric" value="${b ? b.effectif_depart : ""}" placeholder="ex : 500"></div>
      <div class="field"><label for="bdPoulailler">Dans quel bâtiment ?</label><select id="bdPoulailler">${poulaillers.map(p =>
        `<option value="${p.id}"${b && b.poulailler_id === p.id ? " selected" : ""}>${esc(p.nom)}${p.capacite ? ` (${nbFerme(p.occupes)} sur ${nbFerme(p.capacite)} places)` : ""}</option>`).join("")}</select></div>
      <div class="field"><label for="bdDate">Arrivées le</label><input id="bdDate" type="date"></div>
      <div class="field"><label for="bdMales">Dont mâles (facultatif)</label><input id="bdMales" inputmode="numeric" value="${b && b.males != null ? b.males : ""}"></div>
      <div class="field"><label for="bdFemelles">Dont femelles (facultatif)</label><input id="bdFemelles" inputmode="numeric" value="${b && b.femelles != null ? b.femelles : ""}"></div>
      <div class="field"><label for="bdAge">Âge à l'arrivée (en jours)</label><input id="bdAge" inputmode="numeric" value="${b ? b.age_arrivee : 1}"><small class="fe-aide">1 pour des poussins d'un jour</small></div>
    </div>
    <h4 class="fe-titre">3. Pour s'en souvenir (facultatif)</h4>
    <div class="fgrid">
      ${t.voit_argent ? `<div class="field"><label for="bdCout">Prix payé pour tous les animaux (F)</label><input id="bdCout" inputmode="numeric" value="${b && b.cout_achat != null ? formatNombre(b.cout_achat) : ""}" placeholder="peut être complété plus tard"></div>` : ""}
      <div class="field"><label for="bdFournisseur">Achetées chez</label><input id="bdFournisseur" maxlength="100" value="${esc(b ? b.fournisseur : "")}"></div>
      <div class="field"><label for="bdSouche">Race</label><input id="bdSouche" maxlength="60" list="bdRaces" value="${esc(b ? b.souche : "")}" placeholder="choisissez ou écrivez"><datalist id="bdRaces"></datalist></div>
      <div class="field"><label for="bdNom">Petit nom du lot</label><input id="bdNom" maxlength="100" value="${esc(b ? b.nom : "")}" placeholder="ex : Lot de Noël"></div>
    </div>
    <div class="field"><label for="bdNote">Note</label><input id="bdNote" maxlength="300" value="${esc(b ? b.note : "")}"></div>
    ${t.voit_argent ? "" : '<p class="fe-aide">Le prix sera noté par la Caisse ou l\'Admin.</p>'}
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer le lot</button></div>
  </div>`, { taille: "large fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#bdDate").value = formatDate(b ? b.date_arrivee : aujourdhui());
  fen.querySelector(".fe-choix-types").addEventListener("click", e => {
    const x = e.target.closest("[data-type]");
    if (!x) return;
    type = x.dataset.type;
    fen.querySelectorAll(".fe-choix-type").forEach(y => { y.classList.toggle("choisi", y === x); y.setAttribute("aria-checked", y === x); });
    majRacesBande();
  });
  // races proposées par le modèle de l'espèce
  const majRacesBande = () => { fen.querySelector("#bdRaces").innerHTML = (((especeFerme(type) || {}).modele || {}).races || []).map(r => `<option value="${esc(r)}">`).join(""); };
  majRacesBande();
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    erreur.style.display = "none";
    try {
      if (!type) throw new Error("Choisissez d'abord les animaux (étape 1).");
      const effectif = lireEntierFerme(fen.querySelector("#bdEffectif").value);
      if (!effectif) throw new Error("Indiquez le nombre d'animaux à l'arrivée.");
      const age = lireEntierFerme(fen.querySelector("#bdAge").value);
      if (age === null) throw new Error("L'âge à l'arrivée doit être un nombre de jours.");
      const date = isoDepuisTexte(fen.querySelector("#bdDate").value);
      if (!date) throw new Error("Date d'arrivée incorrecte : écrivez-la comme 02/12/2026.");
      let cout = null;
      if (t.voit_argent && fen.querySelector("#bdCout").value.trim()) {
        cout = lireMontant(fen.querySelector("#bdCout").value);
        if (cout === null) throw new Error("Le prix est incorrect.");
      }
      const v = id => fen.querySelector(id).value.trim() || null;
      const corps = { type_elevage: type, poulailler_id: Number(fen.querySelector("#bdPoulailler").value), effectif_depart: effectif,
                      date_arrivee: date, age_arrivee: age, souche: v("#bdSouche"), fournisseur: v("#bdFournisseur"),
                      nom: v("#bdNom"), note: v("#bdNote"), cout_achat: cout,
                      males: fen.querySelector("#bdMales").value.trim() ? lireEntierFerme(fen.querySelector("#bdMales").value) : null,
                      femelles: fen.querySelector("#bdFemelles").value.trim() ? lireEntierFerme(fen.querySelector("#bdFemelles").value) : null };
      ok.disabled = true;
      await api(b ? `/api/ferme/bandes/${b.id}` : "/api/ferme/bandes", { method: b ? "PUT" : "POST", body: corps });
      fen.fermer();
      toast(b ? "Lot modifié" : `Lot enregistré : ${plurielFerme(effectif, "animal", "animaux")}`);
      ongletFerme = ongletFerme === "frSuivi" ? "frSuivi" : "frBandes";
      rechargerFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

// ---------- Suivi du jour ----------
// Cases à cocher : les types de volaille à suivre (retenus sur ce poste). Une fois enregistré, le suivi du jour
// s'affiche en lecture seule ; « Modifier ce suivi » le rouvre.

const CLE_TYPES_SUIVI = "gerimo_ferme_types_suivi";
function typesSuivis(t) {
  const presents = ((tableauFerme && tableauFerme.especes) || []).map(e => e.nom).filter(x => t.bandes.some(b => b.type === x));
  let choisis;
  try { choisis = JSON.parse(localStorage.getItem(CLE_TYPES_SUIVI) || "null"); } catch { choisis = null; }
  const gardes = Array.isArray(choisis) ? presents.filter(x => choisis.includes(x)) : presents;
  return gardes.length ? gardes : presents;
}

async function chargerSuiviFerme(jour) {
  const zone = el("zoneSuiviFerme");
  jour = jour || jourSuiviFerme || aujourdhui();
  if (jour !== jourSuiviFerme) suiviEnModification = false;
  jourSuiviFerme = jour;
  let deja;
  try { await chargerTableauFerme(); deja = await api("/api/ferme/suivis?jour=" + jour); } catch (e) { erreurFerme(zone, e); return; }
  const t = tableauFerme;
  if (!t.peut_saisir) { zone.innerHTML = '<div class="fe-carte fe-vide"><p>Le suivi du jour est fait par le chef de ferme ou l\'Admin.</p></div>'; return; }
  const duJour = t.bandes.filter(b => b.date_arrivee <= jour);
  const presents = ((tableauFerme && tableauFerme.especes) || []).map(e => e.nom).filter(x => duJour.some(b => b.type === x));
  const choisis = typesSuivis({ bandes: duJour });
  const bandes = duJour.filter(b => choisis.includes(b.type));
  const note = id => deja.find(s => s.bande_id === id);
  const toutNote = bandes.length > 0 && bandes.every(b => note(b.id));
  const lecture = toutNote && !suiviEnModification;
  const estAujourdhui = jour === aujourdhui();

  const entete = `<div class="fe-carte fe-suivi-tete">
    <div class="fe-suivi-jour"><label for="sfDate">Suivi du</label><input id="sfDate" type="date"></div>
    ${presents.length ? `<div class="fe-types-suivi" role="group" aria-label="Animaux à suivre"><span class="fe-types-titre">À suivre :</span>
      ${presents.map(x => `<label class="fe-case-type${choisis.includes(x) ? " coche" : ""}"><input type="checkbox" value="${esc(x)}"${choisis.includes(x) ? " checked" : ""}>
        ${imgType(x, "fe-case-img")}<span>${esc(x)}</span></label>`).join("")}</div>` : ""}
  </div>`;

  let corps;
  if (!duJour.length) {
    corps = `<div class="fe-carte fe-vide">${imgFerme("ferme", "fe-vide-img")}<p>Aucune lot en cours ${estAujourdhui ? "aujourd'hui" : "ce jour-là"}.</p></div>`;
  } else if (!bandes.length) {
    corps = '<div class="fe-carte fe-vide"><p>Cochez au moins une espèce ci-dessus.</p></div>';
  } else if (lecture) {
    const pondeuses = bandes.some(b => b.pondeuses), lait = bandes.some(b => b.lait), nes = bandes.some(b => b.avec_naissances);
    const tot = k => bandes.reduce((s, b) => s + (note(b.id)[k] || 0), 0);
    corps = `<div class="fe-carte fe-suivi-fait">
      <div class="fe-suivi-bravo">${imgFerme(dessinFerme(bandes), "fe-bravo-img")}<div><h3>✓ Suivi ${estAujourdhui ? "d'aujourd'hui" : `du ${formatDate(jour)}`} enregistré</h3>
        <p>${plurielFerme(tot("morts"), "mort")}${nes ? ` · ${plurielFerme(tot("naissances"), "naissance")}` : ""}${pondeuses ? ` · ${plurielFerme(tot("oeufs"), "œuf")} ramassés` : ""}${lait ? ` · ${nbFerme(tot("lait_litres"))} L de lait` : ""} · ${nbFerme(tot("aliment_kg"))} kg d'aliment donnés</p></div></div>
      <div class="fe-tableau"><table><thead><tr><th>Lot</th><th class="nb">Morts</th><th>Pourquoi</th>${nes ? '<th class="nb">Naissances</th>' : ""}${pondeuses ? '<th class="nb">Œufs</th><th class="nb">Cassés</th>' : ""}${lait ? '<th class="nb">Lait</th>' : ""}<th class="nb">Aliment</th><th>Noté par</th></tr></thead><tbody>
        ${bandes.map(b => { const s = note(b.id); return `<tr>
          <td data-titre="Lot"><span class="fe-bande">${imgType(b.type)}<span><b>${esc(b.nom || b.type)}</b><small>${esc(b.poulailler)}</small></span></span></td>
          <td data-titre="Morts" class="nb">${s.morts ? `<b class="fe-rouge">${s.morts}</b>` : "0"}</td><td data-titre="Pourquoi">${esc(s.cause_morts) || ""}</td>
          ${nes ? `<td data-titre="Naissances" class="nb">${b.avec_naissances ? `<b class="fe-vert">${nbFerme(s.naissances)}</b>` : "—"}</td>` : ""}
          ${pondeuses ? `<td data-titre="Œufs" class="nb">${b.pondeuses ? nbFerme(s.oeufs) : "—"}</td><td data-titre="Cassés" class="nb">${b.pondeuses ? s.oeufs_casses || 0 : "—"}</td>` : ""}
          ${lait ? `<td data-titre="Lait" class="nb">${b.lait ? nbFerme(s.lait_litres) + " L" : "—"}</td>` : ""}
          <td data-titre="Aliment" class="nb">${nbFerme(s.aliment_kg)} kg${s.aliment ? `<br><small>${esc(s.aliment)}</small>` : ""}</td><td data-titre="Noté par"><small>${esc(s.saisi_par)}</small></td></tr>`; }).join("")}
      </tbody></table></div>
      <div class="actions"><button class="btn" onclick="suiviEnModification = true; chargerSuiviFerme()">Modifier ce suivi</button>
        <button class="btn primary" onclick="montrerOngletFerme('frBandes')">Voir mes lots</button></div>
    </div>`;
  } else {
    const pondeuses = bandes.some(b => b.pondeuses), lait = bandes.some(b => b.lait), nes = bandes.some(b => b.avec_naissances);
    const val = n => n ? nbFerme(n) : "";
    const sans = '<td class="fe-sans">—</td>';
    corps = `<div class="fe-carte">
      <p class="fe-aide">Pour chaque lot, écrivez ce qui s'est passé ${estAujourdhui ? "aujourd'hui" : "ce jour-là"}. Une case laissée vide compte pour 0.</p>
      <div class="fe-tableau fe-saisie"><table><thead><tr><th>Lot</th><th>Morts</th><th>Pourquoi ?</th>${nes ? "<th>Naissances</th>" : ""}${pondeuses ? "<th>Œufs ramassés</th><th>Œufs cassés</th>" : ""}${lait ? "<th>Lait (litres)</th>" : ""}${t.aliments.length ? "<th>Aliment donné</th>" : ""}<th>Kg donnés</th></tr></thead><tbody>
        ${bandes.map(b => { const s = note(b.id) || {}; return `<tr data-bande="${b.id}">
          <td data-titre="Lot"><span class="fe-bande">${imgType(b.type)}<span><b>${esc(b.nom || b.type)}</b><small>${esc(b.poulailler)} · ${nbFerme(b.vivants)} en vie${s.id ? " · déjà noté" : ""}</small></span></span></td>
          <td data-titre="Morts"><input class="sfMorts" inputmode="numeric" value="${val(s.morts)}" placeholder="0" aria-label="Morts"></td>
          <td data-titre="Pourquoi ?"><select class="sfCause" aria-label="Pourquoi sont-ils morts ?"><option value="">—</option>
            ${[...CAUSES_MORTS, ...(s.cause_morts && !CAUSES_MORTS.includes(s.cause_morts) ? [s.cause_morts] : [])].map(c => `<option${c === s.cause_morts ? " selected" : ""}>${esc(c)}</option>`).join("")}</select></td>
          ${nes ? (b.avec_naissances ? `<td data-titre="Naissances"><input class="sfNes" inputmode="numeric" value="${val(s.naissances)}" placeholder="0" aria-label="Naissances"></td>` : sans) : ""}
          ${pondeuses ? (b.pondeuses ? `<td data-titre="Œufs ramassés"><input class="sfOeufs" inputmode="numeric" value="${val(s.oeufs)}" placeholder="0" aria-label="Œufs ramassés"></td>
            <td data-titre="Œufs cassés"><input class="sfCasses" inputmode="numeric" value="${val(s.oeufs_casses)}" placeholder="0" aria-label="Œufs cassés"></td>` : sans + sans) : ""}
          ${lait ? (b.lait ? `<td data-titre="Lait (litres)"><input class="sfLait" inputmode="decimal" value="${val(s.lait_litres)}" placeholder="0" aria-label="Lait en litres"></td>` : sans) : ""}
          ${t.aliments.length ? `<td data-titre="Aliment donné"><select class="sfProduit" aria-label="Aliment donné">
            <option value=""${s.id && !s.produit_id ? " selected" : ""}>— pas pris du stock —</option>${t.aliments.map(x =>
            `<option value="${x.id}"${!(s.id && !s.produit_id) && x.id === (s.produit_id || b.dernier_aliment_id || t.aliments[0].id) ? " selected" : ""}>${esc(x.nom)} (${esc(x.stock_texte)})</option>`).join("")}</select></td>` : ""}
          <td data-titre="Kg donnés"><input class="sfAliment" inputmode="decimal" value="${val(s.aliment_kg)}" placeholder="0" aria-label="Aliment donné en kg"></td></tr>`; }).join("")}
      </tbody></table></div>
      <div class="form-erreur" role="alert" id="sfErreur"></div>
      <div class="actions">${suiviEnModification ? '<button class="btn" onclick="suiviEnModification = false; chargerSuiviFerme()">Annuler</button>' : ""}
        <button type="button" class="btn-encaisser fe-bouton" id="sfValider" onclick="validerSuiviFerme()">Enregistrer le suivi</button></div>
    </div>`;
  }
  zone.innerHTML = entete + corps;
  initialiserChampsDate(zone);
  fixerDate("sfDate", jour);
  el("sfDate").addEventListener("change", () => { const j = isoDepuisTexte(el("sfDate").value); if (j && j <= aujourdhui()) chargerSuiviFerme(j); });
  zone.querySelectorAll(".fe-types-suivi input").forEach(c => c.addEventListener("change", () => {
    const coches = [...zone.querySelectorAll(".fe-types-suivi input:checked")].map(x => x.value);
    localStorage.setItem(CLE_TYPES_SUIVI, JSON.stringify(coches.length ? coches : presents));
    if (!coches.length) toast("Gardez au moins une espèce cochée.");
    chargerSuiviFerme();
  }));
  const premier = zone.querySelector(".sfMorts");
  if (premier && !matchMedia("(pointer: coarse)").matches) premier.focus();
}

async function validerSuiviFerme() {
  const erreur = el("sfErreur"), bouton = el("sfValider");
  if (bouton.disabled) return;
  erreur.style.display = "none";
  try {
    const jour = valeurDate("sfDate", "Suivi du") || aujourdhui();
    const lignes = [...el("zoneSuiviFerme").querySelectorAll("tr[data-bande]")].map(tr => {
      const nom = tr.querySelector("b").textContent;
      const entier = (cls, quoi) => { const c = tr.querySelector(cls); if (!c) return 0; const n = lireEntierFerme(c.value); if (n === null) throw new Error(`${nom} : le nombre de ${quoi} est incorrect.`); return n; };
      const aliment = lireNombreFerme(tr.querySelector(".sfAliment").value);
      const lait = ligne => { const c = ligne.querySelector(".sfLait"); if (!c) return 0; const n = lireNombreFerme(c.value); if (n === null) throw new Error(`${nom} : la quantité de lait est incorrecte (exemple : 12,5).`); return n; };
      if (aliment === null) throw new Error(`${nom} : la quantité d'aliment est incorrecte (exemple : 12,5).`);
      const morts = entier(".sfMorts", "morts");
      return { bande_id: Number(tr.dataset.bande), morts, cause_morts: morts ? tr.querySelector(".sfCause").value || null : null,
               oeufs: entier(".sfOeufs", "œufs"), oeufs_casses: entier(".sfCasses", "œufs cassés"), aliment_kg: aliment,
               naissances: entier(".sfNes", "naissances"), lait_litres: lait(tr),
               produit_id: tr.querySelector(".sfProduit") && tr.querySelector(".sfProduit").value ? Number(tr.querySelector(".sfProduit").value) : null };
    });
    bouton.disabled = true;
    bouton.textContent = "Enregistrement…";
    const r = await api("/api/ferme/suivis", { method: "POST", body: { date_suivi: jour, lignes } });
    suiviEnModification = false;
    toast(`Suivi enregistré pour ${plurielFerme(r.nombre, "bande")} 👍`, 4000);
    chargerSuiviFerme(jour);
  } catch (e) {
    erreur.textContent = e.message; erreur.style.display = "block";
    bouton.disabled = false; bouton.textContent = "Enregistrer le suivi";
  }
}

// ---------- Bâtiments et animaux (bâtiments, espèces élevées) ----------

async function chargerPoulaillers() {
  const zone = el("zonePoulaillers");
  try { await chargerTableauFerme(); } catch (e) { erreurFerme(zone, e); return; }
  const t = tableauFerme;
  const etat = p => !p.actif ? '<span class="fe-pastille gris">Plus utilisé</span>' : p.capacite && p.occupes > p.capacite ? '<span class="fe-pastille rouge">Trop plein</span>'
    : p.occupes ? '<span class="fe-pastille vert">Occupé</span>' : '<span class="fe-pastille jaune">Vide</span>';
  const PROD = { "Œufs": "des œufs", "Lait": "du lait" };
  zone.innerHTML = `<div class="fe-carte">
    <div class="fe-dette-tete"><h3>Bâtiments</h3>${t.est_admin ? '<button class="btn primary" onclick="formulairePoulailler(null)">+ Nouveau bâtiment</button>' : ""}</div>
    ${t.poulaillers.length ? `<div class="fe-tableau"><table><thead><tr><th>Bâtiment</th><th class="nb">Animaux dedans</th><th class="nb">Places</th><th>État</th></tr></thead><tbody>
      ${t.poulaillers.map(p => `<tr${t.est_admin ? ` class="fe-ligne" onclick="formulairePoulailler(${p.id})" tabindex="0" onkeydown="if(event.key==='Enter')formulairePoulailler(${p.id})"` : ""}>
        <td data-titre="Bâtiment"><span class="fe-bande">${imgFerme("poulailler")}<span><b>${esc(p.nom)}</b>${p.note ? `<small>${esc(p.note)}</small>` : ""}</span></span></td>
        <td data-titre="Animaux dedans" class="nb"><b class="fe-gros">${nbFerme(p.occupes)}</b></td>
        <td data-titre="Places" class="nb">${p.capacite ? nbFerme(p.capacite) : "—"}</td><td data-titre="État">${etat(p)}</td></tr>`).join("")}
    </tbody></table></div>` : `<div class="fe-vide">${imgFerme("poulailler", "fe-vide-img")}<p>Aucun bâtiment.${t.est_admin ? " Créez-en un pour chaque poulailler, clapier, porcherie, étable ou bassin." : ""}</p></div>`}
  </div>
  <div class="fe-carte">
    <div class="fe-dette-tete"><h3>Animaux élevés</h3>${t.est_admin ? '<button class="btn primary" onclick="formulaireEspece(null)">+ Autre espèce</button>' : ""}</div>
    <p class="fe-aide">Gérimo propose déjà les espèces les plus courantes. Retirez celles que vous n'élevez pas, ou ajoutez les vôtres.</p>
    <div class="fe-tableau"><table><thead><tr><th>Espèce</th><th>Groupe</th><th>Donne chaque jour</th><th>Naissances</th><th>Bâtiment</th><th>État</th></tr></thead><tbody>
      ${t.especes.map(e => `<tr${t.est_admin ? ` class="fe-ligne" onclick="formulaireEspece(${e.id})" tabindex="0" onkeydown="if(event.key==='Enter')formulaireEspece(${e.id})"` : ""}>
        <td data-titre="Espèce"><span class="fe-bande">${imgFerme(e.dessin)}<b>${esc(e.nom)}</b></span></td><td data-titre="Groupe">${esc(e.groupe)}</td>
        <td data-titre="Donne chaque jour">${e.production ? PROD[e.production] : "—"}</td><td data-titre="Naissances">${e.naissances ? "oui" : "—"}</td>
        <td data-titre="Bâtiment">${esc(e.batiment)}</td><td data-titre="État">${e.actif ? '<span class="fe-pastille vert">Élevée</span>' : '<span class="fe-pastille gris">Retirée</span>'}</td></tr>`).join("")}
    </tbody></table></div>
  </div>`;
}

function formulaireEspece(id) {
  const t = tableauFerme;
  const e = id ? t.especes.find(x => x.id === id) : null;
  let dessin = e ? e.dessin : "animal";
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme(dessin, "fe-fiche-img")}<div><h2>${e ? "Modifier l'espèce" : "Autre espèce"}</h2><p>Un animal que vous élevez : lapins, aulacodes, escargots, cailles…</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field"><label for="esNom">Nom (au pluriel)</label><input id="esNom" maxlength="40" value="${esc(e ? e.nom : "")}" placeholder="ex : Cailles"></div>
      <div class="field"><label for="esGroupe">Groupe</label><select id="esGroupe">${t.groupes.map(g => `<option${(e ? e.groupe : "Autre") === g ? " selected" : ""}>${esc(g)}</option>`).join("")}</select></div>
      <div class="field"><label for="esBatiment">Son bâtiment s'appelle</label><input id="esBatiment" maxlength="30" value="${esc(e ? e.batiment : "")}" placeholder="ex : clapier, enclos, bassin"></div>
      <div class="field"><label for="esProduction">Donne chaque jour</label><select id="esProduction"><option value="">Rien</option>
        <option value="Œufs"${e && e.production === "Œufs" ? " selected" : ""}>Des œufs</option><option value="Lait"${e && e.production === "Lait" ? " selected" : ""}>Du lait</option></select></div>
    </div>
    <label class="case"><input type="checkbox" id="esNaissances"${e && e.naissances ? " checked" : ""}> Elle fait des petits à la ferme (naissances à noter)</label>
    <h4 class="fe-titre">Son dessin</h4>
    <div class="fe-choix-dessins">${t.dessins.map(d => `<button type="button" class="fe-choix-dessin${d === dessin ? " choisi" : ""}" data-dessin="${d}" aria-label="${d}">${imgFerme(d, "fe-choix-img")}</button>`).join("")}</div>
    ${e ? `<button type="button" class="btn" id="esModele" style="margin-top:.8rem">Modèle de fiche technique (races, cases, repères, gestation)</button>` : ""}
    ${e ? `<label class="case" style="margin-top:.8rem"><input type="checkbox" id="esActif"${e.actif ? " checked" : ""}> Espèce élevée (décochez pour la retirer de la liste)</label>` : ""}
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div>
  </div>`, { taille: "large fe-fenetre" });
  if (fen.querySelector("#esModele")) fen.querySelector("#esModele").addEventListener("click", () => { fen.fermer(); formulaireModeleFerme(e); });
  fen.querySelector(".fe-choix-dessins").addEventListener("click", ev => {
    const x = ev.target.closest("[data-dessin]"); if (!x) return;
    dessin = x.dataset.dessin;
    fen.querySelectorAll(".fe-choix-dessin").forEach(y => y.classList.toggle("choisi", y === x));
    fen.querySelector(".fe-fiche-tete .fe-plat").outerHTML = imgFerme(dessin, "fe-fiche-img");
  });
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const nom = fen.querySelector("#esNom").value.trim();
      if (nom.length < 2) throw new Error("Indiquez le nom de l'espèce.");
      ok.disabled = true;
      await api(e ? `/api/ferme/especes/${e.id}` : "/api/ferme/especes", { method: e ? "PUT" : "POST", body: {
        nom, groupe: fen.querySelector("#esGroupe").value, dessin, production: fen.querySelector("#esProduction").value || null,
        naissances: fen.querySelector("#esNaissances").checked, batiment: fen.querySelector("#esBatiment").value.trim() || "bâtiment",
        actif: e ? fen.querySelector("#esActif").checked : true } });
      fen.fermer();
      toast("Espèce enregistrée");
      chargerPoulaillers();
    } catch (err) { ok.disabled = false; erreur.textContent = err.message; erreur.style.display = "block"; }
  });
}

function formulairePoulailler(id) {
  const p = id ? tableauFerme.poulaillers.find(x => x.id === id) : null;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("poulailler", "fe-fiche-img")}<div><h2>${p ? "Modifier le bâtiment" : "Nouveau bâtiment"}</h2><p>Poulailler, clapier, porcherie, étable, bassin…</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field"><label for="plNom">Nom</label><input id="plNom" maxlength="60" value="${esc(p ? p.nom : "")}" placeholder="ex : Poulailler 1, Clapier A"></div>
      <div class="field"><label for="plCapacite">Nombre de places (facultatif)</label><input id="plCapacite" inputmode="numeric" value="${p && p.capacite ? p.capacite : ""}"></div>
    </div>
    <div class="field"><label for="plNote">Note (facultatif)</label><input id="plNote" maxlength="300" value="${esc(p ? p.note : "")}"></div>
    ${p ? `<label class="case"><input type="checkbox" id="plActif"${p.actif ? " checked" : ""}> Bâtiment utilisé</label>` : ""}
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div>
  </div>`, { taille: "fe-fenetre" });
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const nom = fen.querySelector("#plNom").value.trim();
      if (!nom) throw new Error("Indiquez le nom du bâtiment.");
      const texteCap = fen.querySelector("#plCapacite").value.trim();
      const cap = texteCap ? lireEntierFerme(texteCap) : null;
      if (texteCap && !cap) throw new Error("Le nombre de places est incorrect.");
      ok.disabled = true;
      await api(p ? `/api/ferme/poulaillers/${p.id}` : "/api/ferme/poulaillers", { method: p ? "PUT" : "POST",
        body: { nom, capacite: cap, note: fen.querySelector("#plNote").value.trim() || null, actif: p ? fen.querySelector("#plActif").checked : true } });
      fen.fermer();
      toast("Bâtiment enregistré");
      chargerPoulaillers();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}
