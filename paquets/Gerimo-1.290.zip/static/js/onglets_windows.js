// Navigation par tuiles « comme Paramètres / Paramètres Windows » sur tous les écrans à onglets (14/11/2026,
// demande de Boss) : colonne de rubriques avec icône à gauche, grand titre de la rubrique à droite.
// Les écrans gardent leur propre code (ils montrent/cachent leurs zones par id) : on ne change que la présentation.

const ICONES_ONGLETS = {
  // Trésorerie
  trSoldes: '<rect x="2.5" y="6" width="19" height="13" rx="2"/><path d="M2.5 10h19"/><path d="M16 14.5h2"/>',
  trJournal: '<path d="M8 6h12"/><path d="M8 12h12"/><path d="M8 18h12"/><path d="M4 6h.01"/><path d="M4 12h.01"/><path d="M4 18h.01"/>',
  trTransferts: '<path d="M4 8h14"/><path d="m15 4 4 4-4 4"/><path d="M20 16H6"/><path d="m9 12-4 4 4 4"/>',
  trArretes: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8"/><path d="M8 11h.01M12 11h.01M16 11h.01M8 15h.01M12 15h.01M16 15h.01"/>',
  trReversements: '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M4 21h16"/>',
  trCarnet: '<path d="M5 4.5A1.5 1.5 0 0 1 6.5 3H19v16H6.5A1.5 1.5 0 0 0 5 20.5z"/><path d="M5 20.5A1.5 1.5 0 0 0 6.5 22H19"/><path d="M9 8h6"/>',
  trRapprochement: '<path d="M3 10 12 4l9 6"/><path d="M5 10v8M9.5 10v8M14.5 10v8M19 10v8"/><path d="M3 21h18"/>',
  trComptes: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8 2 2 0 1 1-2.8 2.8 1.6 1.6 0 0 0-2.8 1.2 2 2 0 1 1-4 0 1.6 1.6 0 0 0-2.7-1.2 2 2 0 1 1-2.8-2.8A1.6 1.6 0 0 0 3.4 14a2 2 0 1 1 0-4 1.6 1.6 0 0 0 1.2-2.7 2 2 0 1 1 2.8-2.8A1.6 1.6 0 0 0 10 3.4a2 2 0 1 1 4 0 1.6 1.6 0 0 0 2.7 1.2 2 2 0 1 1 2.8 2.8 1.6 1.6 0 0 0 1.2 2.6 2 2 0 1 1 0 4z"/>',
  // Stock (Commerce)
  stArticles: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5"/><path d="M12 13v8"/>',
  stArrivages: '<path d="M3 6h11v10H3z"/><path d="M14 9h4l3 3v4h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
  stSorties: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="M8.5 12.5h7"/>',
  stDettes: '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  stFournisseurs: '<path d="M3 21V9l9-6 9 6v12"/><path d="M9 21v-6h6v6"/><path d="M3 21h18"/>',
  // Ventes (Commerce)
  veCaisse: '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2.5 3h2.6l2.4 11.2a2 2 0 0 0 2 1.6h7.9a2 2 0 0 0 2-1.5L21 7H6.2"/>',
  veHistorique: '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  veClients: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.6 3.3-5.5 6.5-5.5s5.9 1.9 6.5 5.5"/><path d="M16 4.8a3.3 3.3 0 0 1 0 6.4"/><path d="M18.5 14.8c1.7.7 2.8 2.4 3 5.2"/>',
  // Mobile Money
  mmGuichet: '<rect x="6" y="2" width="12" height="20" rx="2.5"/><path d="M10 18h4"/><path d="M9.5 8.5 12 6l2.5 2.5"/><path d="M12 6v7"/>',
  mmOperations: '<path d="M8 6h12"/><path d="M8 12h12"/><path d="M8 18h12"/><path d="M4 6h.01"/><path d="M4 12h.01"/><path d="M4 18h.01"/>',
  mmCloture: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8"/><path d="m9 14 2 2 4-4"/>',
  mmCommissions: '<path d="M4 20V11"/><path d="M10 20V5"/><path d="M16 20v-7"/><path d="M22 20H2"/>',
  // Ferme
  frBandes: '<path d="m12 2.5 9 5-9 5-9-5z"/><path d="m3 12 9 5 9-5"/><path d="m3 16.5 9 5 9-5"/>',
  frSuivi: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 3v2h6V3"/><path d="m9 13 2 2 4-4"/>',
  frOeufs: '<path d="M12 3c-3.5 0-6.5 5.5-6.5 10a6.5 6.5 0 0 0 13 0C18.5 8.5 15.5 3 12 3z"/>',
  frCouvoir: '<path d="M7 14c0-4 2.2-8 5-8s5 4 5 8a5 5 0 0 1-10 0z"/><path d="M4 21h16"/><path d="M6 17.5 4 21M18 17.5 20 21"/>',
  frAnimaux: '<rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="9" cy="10" r="2.5"/><path d="M5.5 16.5a3.5 3.5 0 0 1 7 0"/><path d="M15 9h3M15 13h3"/>',
  frRepro: '<circle cx="8" cy="9" r="4"/><circle cx="16" cy="9" r="4"/><path d="M12 15v6"/><path d="M9 18h6"/>',
  frStats: '<path d="M4 20V11"/><path d="M10 20V5"/><path d="M16 20v-7"/><path d="M22 20H2"/>',
  frSante: '<path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7z"/><path d="M9 11h2l1-2 2 4 1-2h2"/>',
  frPesees: '<path d="M12 3v3"/><path d="M5 21h14"/><path d="M6.5 6h11l2.5 9a3 3 0 0 1-3 3.5H7A3 3 0 0 1 4 15z"/><path d="M12 10.5 14 13"/>',
  frVeto: '<path d="M6 3v6a4 4 0 0 0 8 0V3"/><path d="M10 13v3a5 5 0 0 0 10 0v-2"/><circle cx="20" cy="12" r="2"/>',
  rfResultat: '<path d="M3 17l6-6 4 4 8-8"/><path d="M14 7h7v7"/>',
  rfVentes: '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2.5 3h2.6l2.4 11.2a2 2 0 0 0 2 1.6h7.9a2 2 0 0 0 2-1.5L21 7H6.2"/>',
  rfBandes: '<path d="M4 20V11"/><path d="M10 20V5"/><path d="M16 20v-7"/><path d="M22 20H2"/>',
  rfEspeces: '<circle cx="12" cy="15.5" r="3.6"/><circle cx="6.3" cy="10.5" r="1.9"/><circle cx="9.6" cy="6.6" r="1.9"/><circle cx="14.4" cy="6.6" r="1.9"/><circle cx="17.7" cy="10.5" r="1.9"/>',
  rfPertes: '<path d="M3 7l6 6 4-4 8 8"/><path d="M14 17h7v-7"/>',
  frStock: '<path d="M6 7h12l1.5 13a1 1 0 0 1-1 1.1H5.5a1 1 0 0 1-1-1.1z"/><path d="M8.5 7V5.5a3.5 3.5 0 0 1 7 0V7"/><path d="M9 13h6"/>',
  frAchats: '<path d="M3 6h11v10H3z"/><path d="M14 9h4l3 3v4h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
  frDettes: '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  frFournisseurs: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.6 3.3-5.5 6.5-5.5s5.9 1.9 6.5 5.5"/><path d="M16 4.8a3.3 3.3 0 0 1 0 6.4"/><path d="M18.5 14.8c1.7.7 2.8 2.4 3 5.2"/>',
  frTerminees: '<path d="M4 20h16"/><path d="M6 16V9l6-4 6 4v7"/><path d="m9.5 12 2 2 3.5-3.5"/>',
  frPoulaillers: '<path d="M3 21V10l9-6 9 6v11"/><path d="M8 21v-6h8v6"/><path d="M3 21h18"/>',
  mmReglages: '<path d="M4 6h9"/><path d="M17 6h3"/><circle cx="15" cy="6" r="2"/><path d="M4 12h3"/><path d="M11 12h9"/><circle cx="9" cy="12" r="2"/><path d="M4 18h11"/><path d="M19 18h1"/><circle cx="17" cy="18" r="2"/>',
  // Rapports
  rapGraphiques: '<path d="M4 20V11"/><path d="M10 20V5"/><path d="M16 20v-7"/><path d="M22 20H2"/>',
  rapDetail: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h4"/>',
  rapBien: '<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M10 6h4M10 10h4M10 14h4M10 18h4"/>',
  rapResultat: '<path d="M12 3v18"/><path d="M5 7h14"/><path d="m5 7-3 7a3 3 0 0 0 6 0z"/><path d="m19 7-3 7a3 3 0 0 0 6 0z"/>',
  // Agenda
  ongletAgenda: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  ongletClients: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.6 3.3-5.5 6.5-5.5s5.9 1.9 6.5 5.5"/><path d="M19 8v6M16 11h6"/>',
};
const SANS_ICONE = '<circle cx="12" cy="12" r="8"/>';

function texteOnglet(b) {
  const span = b.querySelector(".ow-texte");
  return (span ? span.textContent : b.textContent).trim();
}

function preparerEcranWindows(section) {
  const onglets = section.querySelector(":scope > .onglets");
  if (!onglets || section.classList.contains("ecran-windows")) return;
  section.classList.add("ecran-windows");
  onglets.classList.add("onglets-windows");
  onglets.setAttribute("role", "tablist");
  // Chaque onglet : icône + texte (les pastilles de nombre restent à droite)
  onglets.querySelectorAll(".onglet").forEach(b => {
    const pastilles = [...b.querySelectorAll(".pill")];
    pastilles.forEach(p => p.remove());
    const texte = b.textContent.trim();
    b.innerHTML = `<svg class="par-ico" viewBox="0 0 24 24" aria-hidden="true">${ICONES_ONGLETS[b.dataset.onglet] || SANS_ICONE}</svg>`
      + `<span class="ow-texte">${esc(texte)}</span>`;
    pastilles.forEach(p => b.appendChild(p));
  });
  // Le reste de l'écran passe dans la colonne de droite, sous un grand titre
  const contenu = document.createElement("div");
  contenu.className = "par-contenu";
  const titre = document.createElement("h2");
  titre.className = "par-titre";
  contenu.appendChild(titre);
  [...section.children].filter(x => x !== onglets).forEach(x => contenu.appendChild(x));
  section.appendChild(contenu);
  const majTitre = () => {
    if (section.dataset.espacePret) return;   // écran rangé dans un espace : espaces.js donne le titre
    const actif = onglets.querySelector(".onglet.actif");
    titre.textContent = actif ? texteOnglet(actif) : "";
    onglets.querySelectorAll(".onglet").forEach(b => b.setAttribute("aria-selected", b.classList.contains("actif")));
  };
  // Les écrans changent la classe « actif » eux-mêmes : on suit ce changement
  new MutationObserver(majTitre).observe(onglets, { subtree: true, attributes: true, attributeFilter: ["class"] });
  majTitre();
}

["tresorerie", "stock", "ventes", "mobile_money", "ferme", "rentabilite_ferme", "rapports", "agenda"].forEach(id => { const s = el(id); if (s) preparerEcranWindows(s); });

// Flèches du clavier (18/11/2026, demandes de Boss) dans un écran à colonne de tuiles (espaces, Paramètres, écrans
// à onglets) :
// - Haut / Bas : rubrique précédente / suivante (sauf pendant une saisie dans une case) ;
// - Droite : on sort de la colonne, vers le premier champ à renseigner de la rubrique (sinon son premier bouton) ;
// - Gauche : retour sur la tuile de la rubrique ouverte. Dans une case de texte, seulement quand le curseur est déjà
//   tout au début (la flèche gauche sert d'abord à déplacer le curseur) ; dans une case de nombre ou de date, si elle
//   est vide ; jamais dans des boutons ronds à choix (les flèches y choisissent).
// Jamais quand une fenêtre (fiche…) ou le menu est ouvert.
const TEXTE_SAISIE = ["text", "search", "tel", "url", "password", ""];
const CHAMPS = 'input:not([type="hidden"]):not([disabled]):not([readonly]), select:not([disabled]), textarea:not([disabled]):not([readonly])';
const ACTIVABLES = 'button:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])';

function navTuiles(section) {
  return section.querySelector(":scope > .espace-nav")
    || [...section.querySelectorAll(".onglets-windows:not(.onglets-internes)")].find(n => n.offsetParent !== null);
}
const visible = x => x.offsetParent !== null && !x.closest(".onglets-internes, [hidden]");

function tuileActive(nav) {
  return nav.querySelector(".onglet.actif") || nav.querySelector(".onglet");
}

function versRubrique(section, nav) {
  const hors = x => !nav.contains(x) && visible(x);
  const cible = [...section.querySelectorAll(CHAMPS)].find(hors) || [...section.querySelectorAll(ACTIVABLES)].find(hors);
  if (cible) { cible.focus(); return true; }
  return false;
}

// La flèche gauche doit-elle quitter ce champ pour revenir sur la tuile ?
function gaucheSort(t) {
  if (t.isContentEditable) return false;
  if (t.tagName === "SELECT") return true;
  if (t.tagName === "TEXTAREA" || (t.tagName === "INPUT" && TEXTE_SAISIE.includes(t.type))) {
    try { return t.selectionStart === 0 && t.selectionEnd === 0; } catch { return t.value === ""; }
  }
  if (t.tagName === "INPUT") {
    if (t.type === "radio" || t.type === "range") return false;
    if (["checkbox", "button", "submit", "reset", "file", "color"].includes(t.type)) return true;
    return t.value === "";   // nombre, date, e-mail… : seulement vide
  }
  return true;   // bouton, lien, ligne de liste…
}

document.addEventListener("keydown", e => {
  if (!["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key) || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
  if (document.querySelector(".modal-overlay.show") || document.querySelector("#sideMenu.show")) return;
  const section = document.querySelector(".screen.active");
  const nav = section && navTuiles(section);
  if (!nav) return;
  const t = e.target;
  const enSaisie = ["INPUT", "SELECT", "TEXTAREA"].includes(t.tagName) || t.isContentEditable;
  const dansRubrique = section.contains(t) && !nav.contains(t);

  if (e.key === "ArrowRight") {
    if (enSaisie || (dansRubrique && t !== section)) return;   // déjà dans la rubrique : la touche garde son rôle
    if (versRubrique(section, nav)) e.preventDefault();
    return;
  }
  if (e.key === "ArrowLeft") {
    if (nav.contains(t) || !dansRubrique || !gaucheSort(t)) return;
    e.preventDefault();
    const tuile = tuileActive(nav);
    if (tuile) tuile.focus();
    return;
  }
  // Haut / Bas
  if (enSaisie) return;
  const tuiles = [...nav.querySelectorAll(".onglet")].filter(b => b.offsetParent !== null && !b.disabled);
  if (tuiles.length < 2) return;
  const i = tuiles.findIndex(b => b.classList.contains("actif"));
  const suivante = tuiles[i < 0 ? 0 : (i + (e.key === "ArrowDown" ? 1 : -1) + tuiles.length) % tuiles.length];
  const garderFocus = nav.contains(t);
  e.preventDefault();
  suivante.click();
  suivante.scrollIntoView({ block: "nearest", inline: "nearest" });
  // la colonne d'un espace est refaite à chaque rubrique : on remet le focus sur la nouvelle tuile active
  // (et la rubrique suivante peut être sur un autre écran, qui met un instant à s'ouvrir)
  if (garderFocus) [120, 500, 1000].forEach(ms => setTimeout(() => {
    const ecran = document.querySelector(".screen.active");
    const n = ecran && navTuiles(ecran);
    const a = n && tuileActive(n);
    if (a && document.activeElement !== a && (document.activeElement === document.body || n.contains(document.activeElement) || !document.activeElement.offsetParent)) a.focus({ preventScroll: true });
  }, ms));
});
