// Ferme : ventes (animaux, œufs, lait, autres ; comptant ou à crédit) et module « Rentabilité » (22/11/2026).
// Demande de Boss : « revenus, rendements, rentabilité, pertes… les choses essentielles du business ».
// Même style que la Ferme (ferme.js). Le serveur (ferme_ventes.py, ferme_rentabilite.py) revérifie tout.

let ventesFerme = null, rentaFerme = null, periodeRenta = "annee";
const ETAT_VENTE = { payee: ["vert", "Payée"], credit: ["jaune", "À crédit"], annulee: ["gris", "Annulée"] };
const UNITES_GENRE = { "Animaux": ["pièce", "kg"], "Œufs": ["plateau", "pièce"], "Lait": ["litre"], "Autre": ["unité", "kg"] };
const LIB_UNITE = { "pièce": "par animal (pièce)", "kg": "au kilo", "plateau": "par plateau de 30", "litre": "par litre", "unité": "par unité" };

// Module principal « Rentabilité » (demande de Boss du 22/11/2026) : ses rubriques, comme un écran à tuiles
let ongletRenta = "rfResultat";
const ONGLETS_RENTA = { rfResultat: () => chargerRentaFerme("rfResultat"), rfVentes: () => chargerVentesFerme(),
                        rfBandes: () => chargerRentaFerme("rfBandes"), rfEspeces: () => chargerRentaFerme("rfEspeces"),
                        rfPertes: () => chargerRentaFerme("rfPertes") };
function montrerOngletRenta(id) {
  if (moi && moi.role === "Gestionnaire") id = "rfVentes";   // le chef de ferme ne voit pas les chiffres d'argent
  ongletRenta = id;
  document.querySelectorAll("#ongletsRenta .onglet").forEach(b => b.classList.toggle("actif", b.dataset.onglet === id));
  Object.keys(ONGLETS_RENTA).forEach(z => { el(z).style.display = z === id ? "" : "none"; });
  ONGLETS_RENTA[id]();
}
el("ongletsRenta").addEventListener("click", e => { const b = e.target.closest(".onglet"); if (b) montrerOngletRenta(b.dataset.onglet); });
CHARGEURS.rentabilite_ferme = () => {
  document.querySelectorAll("#ongletsRenta .onglet-argent").forEach(b => { b.style.display = moi && moi.role === "Gestionnaire" ? "none" : ""; });
  montrerOngletRenta(ongletRenta);
};

// ---------- Ventes ----------

async function chargerVentesFerme() {
  const zone = el("zoneVentesFerme");
  try { ventesFerme = await api("/api/ferme/ventes"); } catch (e) { erreurFerme(zone, e); return; }
  const v = ventesFerme;
  const mois = aujourdhui().slice(0, 7);
  const duMois = v.ventes.filter(x => !x.annulee && x.date.startsWith(mois));
  const credits = v.ventes.filter(x => x.etat === "credit");
  zone.innerHTML = `
    ${v.argent ? `<div class="fe-chiffres">
      <div class="fe-chiffre vert">${imgFerme("plat:panier")}<span><b>${formatMontant(duMois.reduce((t, x) => t + x.total, 0))}</b><span class="fe-chiffre-libelle">Vendu ce mois-ci</span><small>${plurielFerme(duMois.length, "vente")}</small></span></div>
      <div class="fe-chiffre creme">${imgFerme("plat:argent")}<span><b>${formatMontant(duMois.reduce((t, x) => t + x.paye, 0))}</b><span class="fe-chiffre-libelle">Encaissé ce mois-ci</span><small>argent reçu</small></span></div>
      <div class="fe-chiffre ${credits.length ? "rouge" : "vert"}">${imgFerme("plat:charges")}<span><b>${formatMontant(credits.reduce((t, x) => t + x.reste, 0))}</b><span class="fe-chiffre-libelle">Les clients doivent</span><small>${credits.length ? plurielFerme(credits.length, "vente") + " à crédit" : "rien à réclamer 👍"}</small></span></div>
    </div>` : ""}
    <div class="fe-barre"><div class="fe-boutons">
      ${v.vend ? '<button class="btn" onclick="formulaireClientFerme(null)">+ Client</button><button class="btn primary" onclick="formulaireVenteFerme()">+ Nouvelle vente</button>' : ""}</div></div>
    <div class="fe-carte">${v.ventes.length ? `<div class="fe-tableau"><table><thead><tr><th>Vente</th><th>Client</th><th>Ce qui est vendu</th>${v.argent ? '<th class="nb">Total</th><th class="nb">Reste à payer</th>' : ""}<th>État</th></tr></thead><tbody>
      ${v.ventes.map(x => `<tr class="fe-ligne" onclick="ouvrirVenteFerme(${x.id})" tabindex="0" onkeydown="if(event.key==='Enter')ouvrirVenteFerme(${x.id})">
        <td data-titre="Vente"><b>${formatDate(x.date)}</b><br><small class="fe-aide">n° ${esc(x.numero)}</small></td><td data-titre="Client">${esc(x.client)}</td>
        <td data-titre="Ce qui est vendu">${x.lignes.map(l => `${esc(texteLigneVente(l))}`).join("<br>")}</td>
        ${v.argent ? `<td data-titre="Total" class="nb"><b>${formatMontant(x.total)}</b></td><td data-titre="Reste" class="nb">${x.reste ? `<b class="fe-rouge">${formatMontant(x.reste)}</b>` : "—"}</td>` : ""}
        <td data-titre="État">${pastilleFerme(ETAT_VENTE[x.etat])}</td></tr>`).join("")}
    </tbody></table></div>` : `<div class="fe-vide">${imgFerme("ferme", "fe-vide-img")}<p>Aucune vente pour l'instant.${v.vend ? " Cliquez sur « + Nouvelle vente »." : ""}</p></div>`}</div>`;
}

function texteLigneVente(l) {
  const q = nbFerme(l.quantite);
  if (l.genre === "Animaux") return `${q} ${l.espece ? l.espece.toLowerCase() : "animaux"}${l.bande ? ` (${l.bande})` : ""}${l.poids_kg ? ` · ${nbFerme(l.poids_kg)} kg` : ""}`;
  if (l.genre === "Œufs") return `${q} œufs (${nbFerme(Math.round(l.quantite / 30 * 10) / 10)} plateaux)`;
  if (l.genre === "Lait") return `${q} L de lait`;
  return `${q} × ${l.description || "autre"}`;
}

function ouvrirVenteFerme(id) {
  const v = ventesFerme, x = v.ventes.find(z => z.id === id);
  if (!x) return;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("ferme", "fe-fiche-img")}<div><h2>Vente du ${formatDate(x.date)}</h2><p>n° ${esc(x.numero)} · ${esc(x.client)}${x.telephone ? " · " + esc(x.telephone) : ""}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    ${v.argent ? `<div class="fe-fiche-grand ${ETAT_VENTE[x.etat][0]}"><b>${formatMontant(x.total)}</b><span>${pastilleFerme(ETAT_VENTE[x.etat])}${x.reste ? ` · reste à payer ${formatMontant(x.reste)}` : ""}${x.annulee ? " · " + esc(x.motif_annulation) : ""}</span></div>` : ""}
    <div class="fe-tableau fe-fond-blanc"><table><thead><tr><th>Ce qui est vendu</th>${v.argent ? '<th class="nb">Prix</th><th class="nb">Montant</th>' : ""}</tr></thead><tbody>
      ${x.lignes.map(l => `<tr><td><b>${esc(texteLigneVente(l))}</b>${l.description && l.genre !== "Autre" ? `<br><small class="fe-aide">${esc(l.description)}</small>` : ""}</td>
        ${v.argent ? `<td class="nb">${formatMontant(l.prix_unitaire)} <small class="fe-aide">${esc(LIB_UNITE[l.unite_prix] || l.unite_prix)}</small></td><td class="nb"><b>${formatMontant(l.montant)}</b></td>` : ""}</tr>`).join("")}</tbody></table></div>
    ${v.argent && x.reglements.length ? `<h4 class="fe-titre">Argent reçu</h4><div class="fe-tableau fe-fond-blanc"><table><thead><tr><th>Date</th><th class="nb">Montant</th><th>Payé par</th><th></th></tr></thead><tbody>
      ${x.reglements.map(r => `<tr><td>${formatDate(r.date)}</td><td class="nb"><b>${formatMontant(r.montant)}</b></td><td>${esc(r.mode)}</td>
        <td>${v.est_admin ? `<button class="ibtn del" data-supr="${r.id}" aria-label="Supprimer ce paiement" data-tip="Supprimer ce paiement">✕</button>` : ""}</td></tr>`).join("")}</tbody></table></div>` : ""}
    <p class="fe-aide">Noté par ${esc(x.saisi_par)}${x.note ? " · " + esc(x.note) : ""}</p>
    <div class="actions">
      ${v.est_admin && !x.annulee ? '<button class="btn ghost" data-action="annuler">Annuler la vente</button>' : ""}
      ${x.telephone && x.reste ? '<button class="btn" data-action="whatsapp">Rappel WhatsApp</button>' : ""}
      ${v.argent ? '<button class="btn" data-action="recu">Reçu (PDF)</button>' : ""}
      ${v.encaisse && x.etat === "credit" ? '<button class="btn primary" data-action="encaisser">Encaisser</button>' : ""}
    </div></div>`, { taille: "large fe-fenetre" });
  const action = (nom, fn) => { const b = fen.querySelector(`[data-action="${nom}"]`); if (b) b.addEventListener("click", () => { fen.fermer(); fn(); }); };
  action("encaisser", () => formulaireEncaisserFerme(x));
  action("recu", () => window.open(`/api/ferme/ventes/${x.id}/recu`, "_blank"));
  action("whatsapp", () => ouvrirWhatsAppTexte(x.telephone, `Bonjour ${x.client}, petit rappel : il reste ${formatMontant(x.reste)} à régler pour votre achat du ${formatDate(x.date)} (n° ${x.numero}). Merci !`));
  action("annuler", async () => {
    const mdp = await demanderMotDePasseAdmin(`Annuler la vente du ${formatDate(x.date)} ? Les animaux reviennent dans leur lot. Entrez votre mot de passe.`, { titre: "Annuler la vente", bouton: "Annuler la vente" });
    if (!mdp) return;
    try { await api(`/api/ferme/ventes/${x.id}/annuler`, { method: "POST", body: { mot_de_passe_admin: mdp, motif: "Annulée par l'Admin" } }); toast("Vente annulée"); chargerVentesFerme(); } catch (e) { toast(e.message, 7000); }
  });
  fen.querySelectorAll("[data-supr]").forEach(b => b.addEventListener("click", async () => {
    const mdp = await demanderMotDePasseAdmin("Supprimer ce paiement (argent rendu au client) ? Entrez votre mot de passe.");
    if (!mdp) return;
    try { await api(`/api/ferme/reglements/${b.dataset.supr}/supprimer`, { method: "POST", body: { mot_de_passe_admin: mdp } }); fen.fermer(); toast("Paiement supprimé"); chargerVentesFerme(); } catch (e) { toast(e.message, 7000); }
  }));
}

function htmlPaiementVente(v) {
  return `<div class="fe-choix-types fe-choix-paiement">
      <button type="button" class="fe-choix-type choisi" data-pay="tout"><b>Payé en entier</b><small>aujourd'hui</small></button>
      <button type="button" class="fe-choix-type" data-pay="partie"><b>Payé en partie</b><small>le reste à crédit</small></button>
      <button type="button" class="fe-choix-type" data-pay="rien"><b>Rien payé</b><small>tout à crédit</small></button></div>
    <div class="fgrid fe-pay-champs" style="margin-top:.8rem">
      <div class="field fe-pay-montant" style="display:none"><label>Montant reçu (F)</label><input class="payMontant" inputmode="numeric"></div>
      <div class="field"><label>Payé par</label><select class="payMode">${v.modes.map(m => `<option>${esc(m)}</option>`).join("")}</select></div>
      ${v.comptes.length ? `<div class="field"><label>Mis dans (facultatif)</label><select class="payCompte"><option value="">— compte habituel —</option>${v.comptes.map(c => `<option value="${c.id}">${esc(c.nom)}</option>`).join("")}</select></div>` : ""}
    </div>`;
}

async function formulaireVenteFerme() {
  try { if (!ventesFerme) ventesFerme = await api("/api/ferme/ventes"); } catch (e) { toast(e.message); return; }
  const v = ventesFerme;
  const optionsSource = genre => {
    const bandes = v.bandes.filter(b => genre === "Animaux" || (genre === "Œufs" ? b.pondeuses : genre === "Lait" ? b.lait : true));
    return `<option value="">${genre === "Animaux" ? "— choisir —" : "— aucun lot —"}</option>
      ${bandes.map(b => `<option value="b${b.id}">Lot : ${esc(b.nom)} (${esc(b.batiment)})${genre === "Animaux" ? ` · ${nbFerme(b.vivants)} en vie` : ""}</option>`).join("")}
      ${genre === "Animaux" ? v.animaux.map(s => `<option value="s${s.id}">Animal : ${esc(s.libelle)} · ${esc(s.espece)}${s.race ? " · " + esc(s.race) : ""}</option>`).join("") : ""}`;
  };
  const ligne = () => `<tr class="vtLigne">
    <td data-titre="Quoi"><select class="vtGenre">${["Animaux", "Œufs", "Lait", "Autre"].map(g => `<option>${g}</option>`).join("")}</select></td>
    <td data-titre="De quel lot"><select class="vtSource">${optionsSource("Animaux")}</select><input class="vtDesc" maxlength="120" placeholder="ex : fumier, sacs vides" style="display:none"></td>
    <td data-titre="Quantité"><input class="vtQte" inputmode="decimal" placeholder="0"><small class="fe-aide vtAideQte"></small></td>
    <td data-titre="Poids (kg)"><input class="vtPoids" inputmode="decimal" placeholder="facultatif"></td>
    <td data-titre="Prix"><div class="fe-quantite"><input class="vtPrix" inputmode="numeric" placeholder="0"><select class="vtUnite"></select></div></td>
    <td data-titre="Montant" class="nb"><b class="vtMontant">0 F</b></td>
    <td><button type="button" class="ibtn del" aria-label="Retirer" onclick="this.closest('tr').remove(); totalVenteFerme()">✕</button></td></tr>`;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("ferme", "fe-fiche-img")}<div><h2>Nouvelle vente</h2><p>Animaux, œufs, lait ou autres produits de la ferme.</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field"><label for="vtClient">Client</label><div class="fe-quantite"><select id="vtClient"><option value="">— client de passage —</option>
        ${v.clients.filter(c => c.actif).map(c => `<option value="${c.id}">${esc(c.nom)}${c.telephone ? " · " + esc(c.telephone) : ""}</option>`).join("")}</select>
        <button type="button" class="btn ghost" id="vtNouveauC" title="Nouveau client">+</button></div></div>
      <div class="field" id="vtChampPassage"><label for="vtPassage">Nom (facultatif)</label><input id="vtPassage" maxlength="100" placeholder="client de passage"></div>
      <div class="field"><label for="vtDate">Date</label><input id="vtDate" type="date"></div>
    </div>
    <h4 class="fe-titre">Ce qui est vendu</h4>
    <div class="fe-tableau fe-saisie fe-fond-blanc"><table><thead><tr><th>Quoi</th><th>De quel lot</th><th>Quantité</th><th>Poids (kg)</th><th>Prix</th><th class="nb">Montant</th><th></th></tr></thead>
      <tbody id="vtLignes">${ligne()}</tbody></table></div>
    <button type="button" class="btn ghost" id="vtAjout" style="margin-top:.6rem">+ Autre chose</button>
    <div class="fe-total">Total : <b id="vtTotal">0 F</b></div>
    ${v.encaisse ? `<h4 class="fe-titre">Paiement</h4>${htmlPaiementVente(v)}` : '<p class="fe-aide">L\'argent sera encaissé par la Caisse ou l\'Admin.</p>'}
    <div class="field"><label for="vtNote">Note (facultatif)</label><input id="vtNote" maxlength="300"></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer la vente</button></div></div>`, { taille: "tres-large fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#vtDate").value = formatDate(aujourdhui());
  const majLigne = (tr, genreChange) => {
    const g = tr.querySelector(".vtGenre").value;
    if (genreChange) {
      tr.querySelector(".vtSource").innerHTML = optionsSource(g);
      tr.querySelector(".vtUnite").innerHTML = UNITES_GENRE[g].map(u => `<option value="${u}">${LIB_UNITE[u]}</option>`).join("");
    }
    tr.querySelector(".vtSource").style.display = g === "Autre" ? "none" : "";
    tr.querySelector(".vtDesc").style.display = g === "Autre" ? "" : "none";
    tr.querySelector(".vtPoids").style.visibility = g === "Animaux" || tr.querySelector(".vtUnite").value === "kg" ? "" : "hidden";
    tr.querySelector(".vtQte").placeholder = g === "Œufs" ? "nombre d'œufs" : g === "Lait" ? "litres" : g === "Animaux" ? "nombre" : "quantité";
    const q = lireNombreFerme(tr.querySelector(".vtQte").value) || 0;
    tr.querySelector(".vtAideQte").textContent = g === "Œufs" && q ? `= ${nbFerme(Math.round(q / 30 * 10) / 10)} plateaux` : "";
    const src = tr.querySelector(".vtSource").value;
    if (src.startsWith("s") && g === "Animaux") tr.querySelector(".vtQte").value = "1";
    const prix = lireMontant(tr.querySelector(".vtPrix").value) || 0, u = tr.querySelector(".vtUnite").value;
    const poids = lireNombreFerme(tr.querySelector(".vtPoids").value) || 0;
    const m = Math.round((u === "kg" ? poids : u === "plateau" ? q / 30 : q) * prix);
    tr.querySelector(".vtMontant").textContent = formatMontant(m);
    tr.dataset.montant = m;
    totalVenteFerme(fen);
  };
  const brancher = tr => {
    tr.querySelector(".vtGenre").addEventListener("change", () => majLigne(tr, true));
    ["vtSource", "vtUnite"].forEach(c => tr.querySelector("." + c).addEventListener("change", () => majLigne(tr)));
    ["vtQte", "vtPrix", "vtPoids"].forEach(c => tr.querySelector("." + c).addEventListener("input", () => majLigne(tr)));
    majLigne(tr, true);
  };
  fen.querySelectorAll(".vtLigne").forEach(brancher);
  fen.querySelector("#vtAjout").addEventListener("click", () => { fen.querySelector("#vtLignes").insertAdjacentHTML("beforeend", ligne()); brancher(fen.querySelector("#vtLignes").lastElementChild); });
  fen.querySelector("#vtClient").addEventListener("change", () => { fen.querySelector("#vtChampPassage").style.display = fen.querySelector("#vtClient").value ? "none" : ""; });
  fen.querySelector("#vtNouveauC").addEventListener("click", () => formulaireClientFerme(null, c => {
    fen.querySelector("#vtClient").insertAdjacentHTML("beforeend", `<option value="${c.id}" selected>${esc(c.nom)}</option>`);
    fen.querySelector("#vtChampPassage").style.display = "none";
  }));
  const pay = fen.querySelector(".fe-choix-paiement");
  if (pay) pay.addEventListener("click", e => {
    const x = e.target.closest("[data-pay]"); if (!x) return;
    pay.querySelectorAll(".fe-choix-type").forEach(y => y.classList.toggle("choisi", y === x));
    fen.querySelector(".fe-pay-montant").style.display = x.dataset.pay === "partie" ? "" : "none";
    fen.querySelector(".fe-pay-champs").style.display = x.dataset.pay === "rien" ? "none" : "";
  });
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const date = isoDepuisTexte(fen.querySelector("#vtDate").value);
      if (!date) throw new Error("Date incorrecte : écrivez-la comme 02/12/2026.");
      const lignes = [...fen.querySelectorAll(".vtLigne")].map(tr => {
        const g = tr.querySelector(".vtGenre").value, src = tr.querySelector(".vtSource").value;
        const q = lireNombreFerme(tr.querySelector(".vtQte").value), prix = lireMontant(tr.querySelector(".vtPrix").value);
        const poids = tr.querySelector(".vtPoids").value.trim() ? lireNombreFerme(tr.querySelector(".vtPoids").value) : null;
        if (!q) throw new Error("Indiquez la quantité vendue.");
        if (prix === null) throw new Error("Indiquez le prix.");
        if (g === "Animaux" && !src) throw new Error("Choisissez le lot ou l'animal vendu.");
        return { genre: g, bande_id: src.startsWith("b") ? Number(src.slice(1)) : null, sujet_id: src.startsWith("s") ? Number(src.slice(1)) : null,
                 description: g === "Autre" ? tr.querySelector(".vtDesc").value.trim() || null : null, quantite: q, poids_kg: poids,
                 unite_prix: tr.querySelector(".vtUnite").value, prix_unitaire: prix };
      });
      const total = [...fen.querySelectorAll(".vtLigne")].reduce((t, tr) => t + Number(tr.dataset.montant || 0), 0);
      let paiement = null;
      if (v.encaisse) {
        const quoi = fen.querySelector(".fe-choix-paiement .choisi").dataset.pay;
        if (quoi !== "rien" && total) {
          const m = quoi === "tout" ? total : lireMontant(fen.querySelector(".payMontant").value);
          if (!m) throw new Error("Indiquez le montant reçu.");
          const compte = fen.querySelector(".payCompte");
          paiement = { montant: m, mode_paiement: fen.querySelector(".payMode").value, compte_id: compte && compte.value ? Number(compte.value) : null, date_reglement: date };
        }
      }
      ok.disabled = true;
      const r = await api("/api/ferme/ventes", { method: "POST", body: { date_vente: date, client_id: fen.querySelector("#vtClient").value ? Number(fen.querySelector("#vtClient").value) : null,
        client_nom: fen.querySelector("#vtPassage").value.trim() || null, lignes, paiement, note: fen.querySelector("#vtNote").value.trim() || null } });
      fen.fermer();
      toast(`Vente ${r.numero} enregistrée : ${formatMontant(r.total)}${r.reste ? `, reste ${formatMontant(r.reste)} à crédit` : ""}`, 5000);
      ventesFerme = null; tableauFerme = null;
      montrerOngletRenta("rfVentes");
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}
function totalVenteFerme(depuis) {
  const fen = depuis && depuis.querySelector ? depuis : document.querySelector(".modal-box.fe-fenetre") || document;
  const t = [...fen.querySelectorAll(".vtLigne")].reduce((s, tr) => s + Number(tr.dataset.montant || 0), 0);
  const z = fen.querySelector("#vtTotal");
  if (z) z.textContent = formatMontant(t);
}

function formulaireEncaisserFerme(x) {
  const v = ventesFerme;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("sac", "fe-fiche-img")}<div><h2>Encaisser ${esc(x.client)}</h2><p>Vente du ${formatDate(x.date)} · reste ${formatMontant(x.reste)}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field"><label for="enMontant">Montant reçu (F)</label><input id="enMontant" inputmode="numeric" value="${formatNombre(x.reste)}"></div>
      <div class="field"><label for="enMode">Payé par</label><select id="enMode">${v.modes.map(m => `<option>${esc(m)}</option>`).join("")}</select></div>
      ${v.comptes.length ? `<div class="field"><label for="enCompte">Mis dans (facultatif)</label><select id="enCompte"><option value="">— compte habituel —</option>${v.comptes.map(c => `<option value="${c.id}">${esc(c.nom)}</option>`).join("")}</select></div>` : ""}
      <div class="field"><label for="enDate">Date</label><input id="enDate" type="date"></div>
    </div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Encaisser</button></div></div>`, { taille: "fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#enDate").value = formatDate(aujourdhui());
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const m = lireMontant(fen.querySelector("#enMontant").value);
      if (!m) throw new Error("Indiquez le montant reçu.");
      const compte = fen.querySelector("#enCompte");
      ok.disabled = true;
      await api(`/api/ferme/ventes/${x.id}/reglements`, { method: "POST", body: { montant: m, mode_paiement: fen.querySelector("#enMode").value,
        compte_id: compte && compte.value ? Number(compte.value) : null, date_reglement: isoDepuisTexte(fen.querySelector("#enDate").value) } });
      fen.fermer(); toast("Argent encaissé 👍"); chargerVentesFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

function formulaireClientFerme(id, apres = null) {
  const c = id ? ventesFerme.clients.find(x => x.id === id) : null;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("ferme", "fe-fiche-img")}<div><h2>${c ? "Modifier le client" : "Nouveau client"}</h2><p>Un acheteur régulier (obligatoire pour vendre à crédit).</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid"><div class="field"><label for="clNom">Nom</label><input id="clNom" maxlength="100" value="${esc(c ? c.nom : "")}"></div>
      <div class="field"><label for="clTel">Téléphone (facultatif)</label><input id="clTel" inputmode="tel" maxlength="30" value="${esc(c ? c.telephone : "")}"></div></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "fe-fenetre" });
  fen.querySelector('[data-action="ok"]').addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const nom = fen.querySelector("#clNom").value.trim();
      if (nom.length < 2) throw new Error("Indiquez le nom du client.");
      const r = await api(c ? `/api/ferme/clients/${c.id}` : "/api/ferme/clients", { method: c ? "PUT" : "POST", body: { nom, telephone: fen.querySelector("#clTel").value.trim() || null } });
      fen.fermer(); toast("Client enregistré");
      ventesFerme.clients.push({ id: r.id, nom: r.nom, telephone: fen.querySelector("#clTel").value.trim(), actif: true });
      if (apres) apres(r); else chargerVentesFerme();
    } catch (e) { erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

// ---------- Rentabilité ----------

function periodeRentaDates() {
  const a = new Date(), an = a.getFullYear(), iso = d => d.toISOString().slice(0, 10);
  if (periodeRenta === "mois") return [aujourdhui().slice(0, 8) + "01", aujourdhui()];
  if (periodeRenta === "an_dernier") return [`${an - 1}-01-01`, `${an - 1}-12-31`];
  if (periodeRenta === "tout") return ["2000-01-01", aujourdhui()];
  return [`${an}-01-01`, iso(a)];
}

const ZONES_RENTA = { rfResultat: "zoneRentaFerme", rfBandes: "zoneRentaBandes", rfEspeces: "zoneRentaEspeces", rfPertes: "zoneRentaPertes" };
const PERIODES_RENTA = [["mois", "Ce mois-ci"], ["annee", "Cette année"], ["an_dernier", "L'an dernier"], ["tout", "Depuis le début"]];
const carteRenta = (couleur, plat, titre, valeur, aide) => `<div class="fe-chiffre ${couleur}">${imgFerme("plat:" + plat)}<span><span class="fe-chiffre-libelle">${titre}</span><b>${valeur}</b><small>${aide}</small></span></div>`;

async function chargerRentaFerme(onglet = "rfResultat") {
  const zone = el(ZONES_RENTA[onglet]);
  const [d, f] = periodeRentaDates();
  try { rentaFerme = await api(`/api/ferme/rentabilite?debut=${d}&fin=${f}`); } catch (e) { erreurFerme(zone, e); return; }
  const r = rentaFerme;
  const entete = `<div class="fe-barre fe-barre-stock"><div class="fe-types-suivi">${PERIODES_RENTA.map(([k, l]) => `<label class="fe-case-type${periodeRenta === k ? " coche" : ""}" onclick="periodeRenta = '${k}'; chargerRentaFerme('${onglet}')"><span>${l}</span></label>`).join("")}</div>
      <div class="fe-boutons"><span class="fe-aide" style="margin:0">du ${formatDate(r.debut)} au ${formatDate(r.fin)}</span><button class="btn" onclick="window.open('/api/ferme/rentabilite/pdf?debut=${d}&fin=${f}', '_blank')">Bilan à imprimer (PDF)</button></div></div>`;
  const corps = { rfResultat: htmlResultatRenta, rfBandes: htmlBandesRenta, rfEspeces: htmlEspecesRenta, rfPertes: htmlPertesRenta }[onglet](r);
  zone.innerHTML = entete + corps;
}

function htmlResultatRenta(r) {
  const t = r.total, gagne = t.resultat >= 0;
  const max = Math.max(1, ...r.par_mois.flatMap(m => [m.revenus, m.charges]));
  return `
    <div class="fe-chiffres">
      ${carteRenta("vert", "argent", "Revenus", formatMontant(t.revenus), `ce que la ferme a vendu · ${plurielFerme(t.ventes, "vente")}`)}
      ${carteRenta("rouge", "charges", "Charges", formatMontant(t.charges), "achats, animaux, dépenses")}
      ${carteRenta(gagne ? "vert" : "rouge", gagne ? "hausse" : "baisse", gagne ? "Bénéfice" : "Perte", formatMontant(Math.abs(t.resultat)),
                   t.marge_pct !== null ? `${String(Math.abs(t.marge_pct)).replace(".", ",")} F ${gagne ? "gagnés" : "perdus"} sur 100 F vendus` : "revenus − charges")}
      ${carteRenta("jaune", "tombe", "Pertes", formatMontant(r.pertes.total), `${plurielFerme(r.pertes.morts, "mort")} · produits perdus`)}
    </div>
    ${r.par_mois.length > 1 ? `<div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">Mois par mois</h3><div class="fe-barres">
      ${r.par_mois.map(m => `<div class="fe-barre-mois" data-tip="${m.mois} : revenus ${formatMontant(m.revenus)}, charges ${formatMontant(m.charges)}">
        <div class="fe-colonnes"><span class="rev" style="height:${Math.round(m.revenus / max * 100)}%"></span><span class="ch" style="height:${Math.round(m.charges / max * 100)}%"></span></div>
        <small>${m.mois.slice(0, 2)}</small><b class="${m.resultat >= 0 ? "fe-vert" : "fe-rouge"}">${m.resultat >= 0 ? "+" : "−"}${nbFerme(Math.abs(Math.round(m.resultat / 1000)))}k</b></div>`).join("")}
    </div><p class="fe-aide"><b style="color:#3f6f12">■</b> revenus · <b style="color:#9e3519">■</b> charges · en dessous : bénéfice ou perte du mois (en milliers de F)</p></div>` : ""}
    <div class="fe-fiche-colonnes">
      <div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">D'où vient l'argent</h3><div class="fe-tableau"><table><tbody>
        ${Object.entries(r.revenus_par_genre).map(([k, v]) => `<tr><td>${esc(k)}</td><td class="nb"><b>${formatMontant(v)}</b></td></tr>`).join("") || '<tr><td class="fe-aide">Aucune vente sur la période.</td></tr>'}
      </tbody></table></div></div>
      <div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">Où va l'argent</h3><div class="fe-tableau"><table><tbody>
        ${Object.entries(r.charges_detail).filter(([, v]) => v).map(([k, v]) => `<tr><td>${esc(k)}</td><td class="nb"><b>${formatMontant(v)}</b></td></tr>`).join("") || '<tr><td class="fe-aide">Aucune charge sur la période.</td></tr>'}
      </tbody></table></div></div>
    </div>
    <p class="fe-aide">${esc(r.note)}</p>`;
}

function htmlBandesRenta(r) {
  const gagnantes = r.par_bande.filter(b => b.benefice > 0).length;
  return `<div class="fe-chiffres">
      ${carteRenta("vert", "hausse", "Lots gagnants", gagnantes, "bénéfice positif")}
      ${carteRenta("rouge", "baisse", "Lots perdants", r.par_bande.length - gagnantes, "à surveiller")}
    </div>
    <div class="fe-carte">${r.par_bande.length ? `<div class="fe-tableau"><table><thead><tr><th>Lot</th><th class="nb">Revenus</th><th class="nb">Charges</th><th class="nb">Bénéfice</th><th class="nb">Prix de revient</th><th>Rendement</th></tr></thead><tbody>
      ${r.par_bande.map((b, i) => `<tr class="fe-ligne" onclick="ouvrirBilanBande(${i})" tabindex="0">
        <td data-titre="Lot"><span class="fe-bande">${imgFerme(b.dessin)}<span><b>${esc(b.nom)}</b><small>${esc(b.batiment)} · ${b.statut === "Terminée" ? "terminé" : "en cours"}</small></span></span></td>
        <td data-titre="Revenus" class="nb">${formatMontant(b.revenus)}</td><td data-titre="Charges" class="nb">${formatMontant(b.charges)}</td>
        <td data-titre="Bénéfice" class="nb"><b class="${b.benefice >= 0 ? "fe-vert" : "fe-rouge"}">${formatMontant(b.benefice)}</b></td>
        <td data-titre="Prix de revient" class="nb">${b.prix_revient.animal ? formatMontant(b.prix_revient.animal) + " / animal" : b.prix_revient.oeuf ? `${String(b.prix_revient.oeuf).replace(".", ",")} F / œuf` : b.prix_revient.litre ? formatMontant(b.prix_revient.litre) + " / L" : "—"}</td>
        <td data-titre="Rendement">${texteRendement(b)}</td></tr>`).join("")}
    </tbody></table></div>` : `<div class="fe-vide">${imgFerme("ferme", "fe-vide-img")}<p>Aucun lot sur la période.</p></div>`}</div>
    <p class="fe-aide">Cliquez sur un lot : le détail de ses charges, de ses pertes, de ses rendements et de son prix de revient.</p>`;
}

function htmlEspecesRenta(r) {
  return `<div class="fe-carte">${r.par_espece.length ? `<div class="fe-tableau"><table><thead><tr><th>Espèce</th><th class="nb">Revenus</th><th class="nb">Charges</th><th class="nb">Résultat</th><th class="nb">Morts</th></tr></thead><tbody>
      ${r.par_espece.map((e, i) => `<tr><td data-titre="Espèce"><span class="fe-bande">${imgFerme(e.dessin)}<b>${esc(e.espece)}</b>${i === 0 && e.resultat > 0 ? ' <span class="fe-pastille vert">rapporte le plus</span>' : ""}</span></td><td data-titre="Revenus" class="nb">${formatMontant(e.revenus)}</td>
        <td data-titre="Charges" class="nb">${formatMontant(e.charges)}</td><td data-titre="Résultat" class="nb"><b class="${e.resultat >= 0 ? "fe-vert" : "fe-rouge"}">${formatMontant(e.resultat)}</b></td><td data-titre="Morts" class="nb">${e.morts}</td></tr>`).join("")}
    </tbody></table></div>` : '<p class="fe-aide">Aucune vente ni charge sur la période.</p>'}</div>
    <p class="fe-aide">Charges d'une espèce : achat de ses animaux et ce que ses lots ont consommé sur la période (aliment, produits, vétérinaire, dépenses rattachées).</p>`;
}

function htmlPertesRenta(r) {
  const p = r.pertes;
  return `<div class="fe-chiffres">
      ${carteRenta("rouge", "tombe", "Animaux morts", nbFerme(p.morts), `estimés à ${formatMontant(p.valeur_morts)}`)}
      ${carteRenta("jaune", "sac", "Produits perdus", formatMontant(p.produits_perdus), "sacs mouillés, périmés…")}
      ${carteRenta("creme", "oeuf", "Œufs cassés", nbFerme(p.oeufs_casses), "sur la période")}
      ${carteRenta("rose", "naissance", "Morts-nés", nbFerme(p.morts_nes), "dans les portées")}
    </div>
    <div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">Total des pertes : ${formatMontant(p.total)}</h3>
      <p class="fe-aide" style="margin:0">Un animal mort compte pour ce qu'il a coûté (sa part de l'achat, de l'aliment et des produits de son lot). Les produits perdus comptent à leur prix d'achat moyen.</p></div>`;
}

function texteRendement(b) {
  const x = b.rendements;
  if (x.indice_conso) return `${String(x.indice_conso).replace(".", ",")} kg d'aliment pour 1 kg vendu`;
  if (x.ponte_moyenne) return `${String(x.ponte_moyenne).replace(".", ",")} œufs pour 100 poules par jour`;
  if (x.lait_litres) return `${nbFerme(x.lait_litres)} L de lait`;
  if (x.poids_moyen_vendu) return `${nbFerme(x.poids_moyen_vendu)} kg en moyenne à la vente`;
  return b.mortalite ? `mortalité ${String(b.mortalite).replace(".", ",")} %` : "—";
}

function ouvrirBilanBande(i) {
  const b = rentaFerme.par_bande[i];
  const ligne = (l, v) => v === null || v === undefined || v === "" ? "" : `<tr><th>${l}</th><td>${v}</td></tr>`;
  const x = b.rendements, pr = b.prix_revient;
  ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme(b.dessin, "fe-fiche-img")}<div><h2>${esc(b.nom)}</h2><p>${esc(b.espece)} · ${esc(b.batiment)} · arrivé le ${formatDate(b.date_arrivee)}${b.date_fin ? ` · terminé le ${formatDate(b.date_fin)}` : " · en cours"}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fe-fiche-grand ${b.benefice >= 0 ? "vert" : "rouge"}"><b>${b.benefice >= 0 ? "Bénéfice" : "Perte"} : ${formatMontant(Math.abs(b.benefice))}</b>
      <span>${formatMontant(b.revenus)} de revenus − ${formatMontant(b.charges)} de charges${b.marge_pct !== null ? ` · ${String(b.marge_pct).replace(".", ",")} %` : ""}${b.statut !== "Terminée" ? " · lot encore en cours" : ""}</span></div>
    <div class="fe-fiche-colonnes">
      <div class="fe-tableau fe-tableau-cles"><table><tbody>
        ${ligne("Achat des animaux", formatMontant(b.detail_charges.achat))}${ligne("Aliment consommé", formatMontant(b.detail_charges.aliment))}
        ${ligne("Vaccins, médicaments, matériel", formatMontant(b.detail_charges.produits))}${ligne("Vétérinaire", formatMontant(b.detail_charges.veterinaire))}
        ${b.detail_charges.depenses ? ligne("Dépenses rattachées (salaires, électricité…)", formatMontant(b.detail_charges.depenses)) : ""}
        ${ligne("<b>Total des charges</b>", `<b>${formatMontant(b.charges)}</b>`)}
      </tbody></table></div>
      <div class="fe-tableau fe-tableau-cles"><table><tbody>
        ${ligne("Animaux à l'arrivée", nbFerme(b.effectif))}${b.naissances ? ligne("Naissances", nbFerme(b.naissances)) : ""}
        ${ligne("Vendus", nbFerme(b.vendus))}${ligne("Morts", `${nbFerme(b.morts)} (${String(b.mortalite).replace(".", ",")} %)`)}${ligne("Encore en vie", nbFerme(b.vivants))}
        ${ligne("Valeur des animaux morts", formatMontant(b.pertes.valeur_morts))}
      </tbody></table></div>
    </div>
    <h4 class="fe-titre">Rendements et prix de revient</h4>
    <div class="fe-reperes" style="margin:0">
      <span><small>Aliment donné</small>${nbFerme(x.aliment_kg)} kg</span>
      ${x.indice_conso ? `<span><small>Aliment pour 1 kg vendu</small>${String(x.indice_conso).replace(".", ",")} kg</span>` : ""}
      ${b.poids_vendu ? `<span><small>Poids vendu</small>${nbFerme(b.poids_vendu)} kg${x.poids_moyen_vendu ? ` (${nbFerme(x.poids_moyen_vendu)} kg/animal)` : ""}</span>` : ""}
      ${x.oeufs ? `<span><small>Œufs ramassés</small>${nbFerme(x.oeufs)}${x.ponte_moyenne ? ` · ${String(x.ponte_moyenne).replace(".", ",")} pour 100 poules/jour` : ""}</span>` : ""}
      ${b.pertes.oeufs_casses ? `<span><small>Œufs cassés</small>${nbFerme(b.pertes.oeufs_casses)}</span>` : ""}
      ${x.lait_litres ? `<span><small>Lait</small>${nbFerme(x.lait_litres)} L</span>` : ""}
      ${pr.animal ? `<span><small>Prix de revient d'un animal vendu</small>${formatMontant(pr.animal)}</span>` : ""}
      ${pr.kg ? `<span><small>Prix de revient d'un kg</small>${formatMontant(pr.kg)}</span>` : ""}
      ${pr.oeuf ? `<span><small>Prix de revient d'un œuf</small>${String(pr.oeuf).replace(".", ",")} F</span>` : ""}
      ${pr.litre ? `<span><small>Prix de revient d'un litre</small>${formatMontant(pr.litre)}</span>` : ""}
    </div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button></div></div>`, { taille: "large fe-fenetre" });
}
