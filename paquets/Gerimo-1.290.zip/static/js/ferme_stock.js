// Ferme, étape 2 (22/11/2026) : stock des aliments et produits, achats, ce que je dois, fournisseurs.
// Même style que la Ferme (ferme.js : imgFerme, nbFerme, plurielFerme, tableaux .fe-tableau, fenêtres fe-fenetre).
// Le serveur (ferme_stock.py) revérifie tout : droits, stock suffisant, prix, paiements.

let stockFerme = null;
let filtreCatFerme = "tous";
let achatsFerme = [];
const IMG_CAT = { Aliment: "sac", Vaccin: "vaccin", "Médicament": "medicament", "Matériel": "materiel" };
const LIB_CAT = { Aliment: "Aliments", Vaccin: "Vaccins", "Médicament": "Médicaments et vitamines", "Matériel": "Matériel et litière" };
const UNITES_FERME = ["flacon", "dose", "sachet", "boîte", "litre", "pièce", "sac", "kg"];
const ETAT_PRODUIT = { jamais: ["gris", "Pas encore acheté"], ok: ["vert", "Assez"], bas: ["jaune", "Presque fini"], vide: ["rouge", "Plus rien"], retire: ["gris", "Plus utilisé"] };
const ETAT_ACHAT = { paye: ["vert", "Payé"], credit: ["jaune", "À crédit"], prix: ["jaune", "Prix à compléter"], annule: ["gris", "Annulé"] };
const imgCat = (cat, classe) => imgFerme(IMG_CAT[cat] || "sac", classe);
const pastilleFerme = ([c, t]) => `<span class="fe-pastille ${c}">${t}</span>`;

Object.assign(ONGLETS_FERME, { frStock: () => chargerStockFerme(), frAchats: () => chargerAchatsFerme(),
                               frDettes: () => chargerDettesFerme(), frFournisseurs: () => chargerFournisseursFerme() });

async function chargerDonneesStock() {
  stockFerme = await api("/api/ferme/stock");
  return stockFerme;
}
const produitFerme = id => stockFerme.produits.find(p => p.id === id);

// ---------- Stock ----------

async function chargerStockFerme() {
  const zone = el("zoneStockFerme");
  try { await chargerDonneesStock(); if (!tableauFerme) await chargerTableauFerme(); } catch (e) { erreurFerme(zone, e); return; }
  const s = stockFerme;
  const actifs = s.produits.filter(p => p.actif);
  const bas = actifs.filter(p => p.etat === "bas" || p.etat === "vide").length;
  const valeur = actifs.reduce((t, p) => t + (p.valeur_stock || 0), 0);
  const cats = Object.keys(LIB_CAT).filter(c => s.produits.some(p => p.categorie === c));
  const liste = s.produits.filter(p => filtreCatFerme === "tous" || p.categorie === filtreCatFerme)
    .sort((a, b) => (a.actif === b.actif ? 0 : a.actif ? -1 : 1) || ({ vide: 0, bas: 1 }[a.etat] ?? 2) - ({ vide: 0, bas: 1 }[b.etat] ?? 2));
  zone.innerHTML = `
    <div class="fe-chiffres">
      <div class="fe-chiffre creme">${imgFerme("sac", "fe-chiffre-img")}<span><b>${actifs.length}</b><span class="fe-chiffre-libelle">Produits suivis</span><small>aliments, vaccins, médicaments…</small></span></div>
      <button type="button" class="fe-chiffre ${bas ? "rouge" : "vert"}" onclick="filtreCatFerme = 'tous'; chargerStockFerme()">${imgFerme(bas ? "medicament" : "sac", "fe-chiffre-img")}
        <span><b>${bas}</b><span class="fe-chiffre-libelle">${bas > 1 ? "Presque finis" : "Presque fini"}</span><small>${bas ? "à racheter bientôt" : "tout va bien 👍"}</small></span></button>
      ${s.voit_argent ? `<div class="fe-chiffre jaune">${imgFerme("sac", "fe-chiffre-img")}<span><b>${formatMontant(valeur)}</b><span class="fe-chiffre-libelle">Valeur du stock</span><small>au prix d'achat moyen</small></span></div>` : ""}
    </div>
    <div class="fe-barre fe-barre-stock">
      <div class="fe-types-suivi">${["tous", ...cats].map(c => `<label class="fe-case-type${filtreCatFerme === c ? " coche" : ""}" onclick="filtreCatFerme = '${c}'; chargerStockFerme()">
        ${c === "tous" ? "" : imgCat(c, "fe-case-img")}<span>${c === "tous" ? "Tout" : LIB_CAT[c]}</span></label>`).join("")}</div>
      <div class="fe-boutons">
        ${s.sort_du_stock ? '<button class="btn" onclick="formulaireSortieFerme()">Sortir du stock</button>' : ""}
        ${s.ecrit_produits ? '<button class="btn" onclick="formulaireProduitFerme(null)">+ Nouveau produit</button>' : ""}
        ${s.note_achats ? '<button class="btn primary" onclick="formulaireAchatFerme()">+ Nouvel achat</button>' : ""}
      </div>
    </div>
    <div class="fe-carte">${liste.length ? `<div class="fe-tableau"><table>
      <thead><tr><th>Produit</th><th class="nb">En stock</th><th class="nb">Prévenir à</th>${s.voit_argent ? '<th class="nb">Prix moyen</th>' : ""}<th>État</th></tr></thead>
      <tbody>${liste.map(p => `<tr class="fe-ligne" onclick="ouvrirFicheProduitFerme(${p.id})" tabindex="0" onkeydown="if(event.key==='Enter')ouvrirFicheProduitFerme(${p.id})">
        <td data-titre="Produit"><span class="fe-bande">${imgCat(p.categorie)}<span><b>${esc(p.nom)}</b><small>${esc(LIB_CAT[p.categorie])}</small></span></span></td>
        <td data-titre="En stock" class="nb"><b class="fe-gros">${esc(p.stock_texte)}</b></td>
        <td data-titre="Prévenir à" class="nb">${p.seuil_alerte ? `${nbFerme(p.seuil_alerte)} ${esc(p.unite)}` : "—"}</td>
        ${s.voit_argent ? `<td data-titre="Prix moyen" class="nb">${p.cout_unitaire ? `${formatMontant(p.cout_unitaire)} / ${esc(p.unite)}` : "—"}</td>` : ""}
        <td data-titre="État">${pastilleFerme(ETAT_PRODUIT[p.etat])}</td></tr>`).join("")}</tbody></table></div>`
      : `<div class="fe-vide">${imgFerme("sac", "fe-vide-img")}<p>Aucun produit ici.${s.ecrit_produits ? " Cliquez sur « + Nouveau produit »." : ""}</p></div>`}</div>`;
}

async function ouvrirFicheProduitFerme(id) {
  let p;
  try { p = await api(`/api/ferme/produits/${id}`); if (!stockFerme) await chargerDonneesStock(); } catch (e) { toast(e.message); return; }
  const s = stockFerme;
  const ligne = (l, v) => v === null || v === undefined || v === "" ? "" : `<tr><th>${l}</th><td>${v}</td></tr>`;
  const GENRE = { Achat: "Acheté", Utilisation: "Utilisé", Perte: "Perdu", Correction: "Corrigé (comptage)" };
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgCat(p.categorie, "fe-fiche-img")}<div><h2>${esc(p.nom)}</h2><p>${esc(LIB_CAT[p.categorie])}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fe-fiche-grand ${(ETAT_PRODUIT[p.etat] || ETAT_PRODUIT.ok)[0]}"><b>${esc(p.stock_texte)}</b><span>${pastilleFerme(ETAT_PRODUIT[p.etat])} en stock aujourd'hui</span></div>
    <div class="fe-tableau fe-tableau-cles fe-fond-blanc"><table><tbody>
      ${ligne("Compté en", esc(p.unite))}${p.kg_par_sac ? ligne("Un sac fait", `${nbFerme(p.kg_par_sac)} kg`) : ""}
      ${ligne("Gérimo prévient à", p.seuil_alerte ? `${nbFerme(p.seuil_alerte)} ${esc(p.unite)}` : "jamais")}
      ${s.voit_argent ? ligne("Prix moyen", p.cout_unitaire ? `${formatMontant(p.cout_unitaire)} le ${esc(p.unite)}` : "pas encore de prix") : ""}
      ${s.voit_argent && p.valeur_stock ? ligne("Valeur du stock", formatMontant(p.valeur_stock)) : ""}${ligne("Note", esc(p.note))}
    </tbody></table></div>
    <h4 class="fe-titre">Entrées et sorties</h4>
    ${p.mouvements.length ? `<div class="fe-tableau fe-defile fe-fond-blanc"><table><thead><tr><th>Date</th><th>Quoi</th><th class="nb">Quantité</th><th>Pour / pourquoi</th><th>Par</th></tr></thead><tbody>
      ${p.mouvements.map(m => `<tr><td>${formatDate(m.date)}</td><td>${GENRE[m.genre] || esc(m.genre)}</td>
        <td class="nb"><b class="${m.quantite > 0 ? "fe-vert" : "fe-rouge"}">${m.quantite > 0 ? "+" : "−"} ${esc(m.texte)}</b></td>
        <td>${[m.bande, m.achat ? "achat " + m.achat : "", m.suivi ? "suivi du jour" : m.motif].filter(Boolean).map(esc).join(" · ")}</td><td><small>${esc(m.saisi_par)}</small></td></tr>`).join("")}
    </tbody></table></div>` : '<p class="fe-aide">Rien n\'est encore entré ni sorti.</p>'}
    <div class="actions">
      ${s.ecrit_produits ? '<button class="btn ghost" data-action="modifier">Modifier</button>' : ""}
      ${s.est_admin ? '<button class="btn ghost" data-action="corriger">Corriger après comptage</button>' : ""}
      ${s.sort_du_stock && p.stock > 0 ? '<button class="btn" data-action="sortir">Sortir du stock</button>' : ""}
      ${s.note_achats ? '<button class="btn primary" data-action="acheter">Acheter</button>' : ""}
    </div></div>`, { taille: "large fe-fenetre" });
  const action = (nom, fn) => { const x = fen.querySelector(`[data-action="${nom}"]`); if (x) x.addEventListener("click", () => { fen.fermer(); fn(); }); };
  action("modifier", () => formulaireProduitFerme(p));
  action("corriger", () => formulaireSortieFerme(p.id, "Correction"));
  action("sortir", () => formulaireSortieFerme(p.id));
  action("acheter", () => formulaireAchatFerme(p.id));
}
window.addEventListener("load", () => { if (typeof FICHES !== "undefined") { FICHES.produitferme = id => ouvrirFicheProduitFerme(id); FICHES.achatferme = id => ouvrirFicheAchatFerme(id); } });

function rafraichirStockFerme() { if (["frStock", "frAchats", "frDettes", "frFournisseurs"].includes(ongletFerme)) montrerOngletFerme(ongletFerme); }

// ---------- Nouveau produit / modifier ----------

async function formulaireProduitFerme(p) {
  try { if (!stockFerme) await chargerDonneesStock(); } catch (e) { toast(e.message); return; }
  let cat = p ? p.categorie : null;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("sac", "fe-fiche-img")}<div><h2>${p ? "Modifier le produit" : "Nouveau produit"}</h2><p>Un aliment, un vaccin, un médicament ou du matériel.</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <h4 class="fe-titre">1. Quelle sorte ?</h4>
    <div class="fe-choix-types">${Object.keys(LIB_CAT).map(c => `<button type="button" class="fe-choix-type${c === cat ? " choisi" : ""}" data-cat="${esc(c)}">${imgCat(c, "fe-choix-img")}<b>${esc(LIB_CAT[c])}</b></button>`).join("")}</div>
    <h4 class="fe-titre">2. Son nom et comment on le compte</h4>
    <div class="fgrid">
      <div class="field"><label for="prNom">Nom</label><input id="prNom" maxlength="80" value="${esc(p ? p.nom : "")}" placeholder="ex : Aliment démarrage, Vaccin Gumboro"></div>
      <div class="field" id="prChampUnite"><label for="prUnite">Compté en</label><select id="prUnite">${UNITES_FERME.map(x => `<option${p && p.unite === x ? " selected" : ""}>${x}</option>`).join("")}</select></div>
      <div class="field" id="prChampSac"><label for="prSac">Un sac fait (kg)</label><input id="prSac" inputmode="decimal" value="${p && p.kg_par_sac ? nbFerme(p.kg_par_sac) : "50"}"></div>
      <div class="field"><label for="prSeuil">Me prévenir quand il reste (<span id="prUniteTexte">kg</span>)</label><input id="prSeuil" inputmode="decimal" value="${p && p.seuil_alerte ? nbFerme(p.seuil_alerte) : ""}" placeholder="ex : 100"></div>
    </div>
    <div class="field"><label for="prNote">Note (facultatif)</label><input id="prNote" maxlength="300" value="${esc(p ? p.note : "")}"></div>
    ${p ? `<label class="case"><input type="checkbox" id="prActif"${p.actif ? " checked" : ""}> Produit utilisé</label>` : ""}
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "large fe-fenetre" });
  const maj = () => {
    const aliment = cat === "Aliment";
    fen.querySelector("#prChampUnite").style.display = aliment ? "none" : "";
    fen.querySelector("#prChampSac").style.display = aliment ? "" : "none";
    fen.querySelector("#prUniteTexte").textContent = aliment ? "kg" : fen.querySelector("#prUnite").value;
  };
  maj();
  fen.querySelector("#prUnite").addEventListener("change", maj);
  fen.querySelector(".fe-choix-types").addEventListener("click", e => {
    const x = e.target.closest("[data-cat]"); if (!x) return;
    cat = x.dataset.cat;
    fen.querySelectorAll(".fe-choix-type").forEach(y => y.classList.toggle("choisi", y === x));
    if (cat !== "Aliment" && fen.querySelector("#prUnite").value === "kg") fen.querySelector("#prUnite").value = cat === "Vaccin" ? "flacon" : cat === "Médicament" ? "sachet" : "pièce";
    maj();
  });
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      if (!cat) throw new Error("Choisissez d'abord la sorte de produit (étape 1).");
      const nom = fen.querySelector("#prNom").value.trim();
      if (nom.length < 2) throw new Error("Indiquez le nom du produit.");
      const seuil = lireNombreFerme(fen.querySelector("#prSeuil").value);
      if (seuil === null) throw new Error("La quantité « me prévenir » est incorrecte.");
      const sac = cat === "Aliment" ? lireNombreFerme(fen.querySelector("#prSac").value) : null;
      if (cat === "Aliment" && !sac) throw new Error("Indiquez le poids d'un sac (en kg).");
      ok.disabled = true;
      await api(p ? `/api/ferme/produits/${p.id}` : "/api/ferme/produits", { method: p ? "PUT" : "POST", body: {
        nom, categorie: cat, unite: cat === "Aliment" ? "kg" : fen.querySelector("#prUnite").value, kg_par_sac: sac, seuil_alerte: seuil,
        note: fen.querySelector("#prNote").value.trim() || null, actif: p ? fen.querySelector("#prActif").checked : true } });
      fen.fermer();
      toast("Produit enregistré");
      stockFerme = null;
      rafraichirStockFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

// ---------- Sortir du stock (utilisé, perdu) ou corriger après comptage ----------

async function formulaireSortieFerme(produitId = null, genreDepart = "Utilisation") {
  try { await chargerDonneesStock(); if (!tableauFerme) await chargerTableauFerme(); } catch (e) { toast(e.message); return; }
  const produits = stockFerme.produits.filter(p => p.actif && (p.stock > 0 || genreDepart === "Correction"));
  if (!produits.length) { toast("Aucun produit en stock : notez d'abord un achat."); return; }
  let genre = genreDepart;
  const GENRES = [["Utilisation", "Utilisé", "donné aux volailles, utilisé à la ferme"], ["Perte", "Perdu ou abîmé", "mouillé, rats, périmé, cassé…"],
                  ...(stockFerme.est_admin ? [["Correction", "Corriger le stock", "après avoir compté ce qui reste"]] : [])];
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("sac", "fe-fiche-img")}<div><h2>Sortir du stock</h2><p>L'aliment donné chaque jour sort tout seul avec le suivi du jour.</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fe-choix-types fe-choix-genres">${GENRES.map(([g, t, a]) => `<button type="button" class="fe-choix-type${g === genre ? " choisi" : ""}" data-genre="${g}"><b>${t}</b><small>${a}</small></button>`).join("")}</div>
    <div class="fgrid" style="margin-top:1rem">
      <div class="field"><label for="soProduit">Produit</label><select id="soProduit">${produits.map(p => `<option value="${p.id}"${p.id === produitId ? " selected" : ""}>${esc(p.nom)} — ${esc(p.stock_texte)}</option>`).join("")}</select></div>
      <div class="field"><label for="soQuantite" id="soLibelle">Quantité</label><input id="soQuantite" inputmode="decimal" placeholder="0"><small class="fe-aide" id="soAide"></small></div>
      <div class="field" id="soChampBande"><label for="soBande">Pour quel lot ? (facultatif)</label><select id="soBande"><option value="">—</option>
        ${tableauFerme.bandes.map(b => `<option value="${b.id}">${esc(b.nom || b.type)} (${esc(b.poulailler)})</option>`).join("")}</select></div>
      <div class="field"><label for="soDate">Date</label><input id="soDate" type="date"></div>
    </div>
    <div class="field"><label for="soMotif" id="soLibMotif">Pourquoi ? (facultatif)</label><input id="soMotif" maxlength="200"></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "large fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#soDate").value = formatDate(aujourdhui());
  const maj = () => {
    const p = produitFerme(Number(fen.querySelector("#soProduit").value));
    fen.querySelector("#soLibelle").textContent = genre === "Correction" ? `Quantité comptée (${p.unite})` : `Quantité sortie (${p.unite})`;
    fen.querySelector("#soAide").textContent = `En stock : ${p.stock_texte}${p.kg_par_sac ? ` · 1 sac = ${nbFerme(p.kg_par_sac)} kg` : ""}`;
    fen.querySelector("#soChampBande").style.display = genre === "Utilisation" ? "" : "none";
    fen.querySelector("#soLibMotif").textContent = genre === "Perte" ? "Pourquoi ?" : "Pourquoi ? (facultatif)";
  };
  maj();
  fen.querySelector("#soProduit").addEventListener("change", maj);
  fen.querySelector(".fe-choix-genres").addEventListener("click", e => {
    const x = e.target.closest("[data-genre]"); if (!x) return;
    genre = x.dataset.genre;
    fen.querySelectorAll(".fe-choix-genres .fe-choix-type").forEach(y => y.classList.toggle("choisi", y === x));
    maj();
  });
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const quantite = lireNombreFerme(fen.querySelector("#soQuantite").value);
      if (quantite === null || (!quantite && genre !== "Correction")) throw new Error("Indiquez la quantité.");
      const date = isoDepuisTexte(fen.querySelector("#soDate").value);
      if (!date) throw new Error("Date incorrecte : écrivez-la comme 02/12/2026.");
      ok.disabled = true;
      const r = await api("/api/ferme/mouvements", { method: "POST", body: { produit_id: Number(fen.querySelector("#soProduit").value), genre, quantite,
        bande_id: genre === "Utilisation" && fen.querySelector("#soBande").value ? Number(fen.querySelector("#soBande").value) : null,
        motif: fen.querySelector("#soMotif").value.trim() || null, date_mouvement: date } });
      fen.fermer();
      toast(`C'est noté. Il reste ${r.stock_texte}.`, 5000);
      rafraichirStockFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

// ---------- Paiement (bloc commun : nouvel achat, prix complétés, payer) ----------

function htmlPaiementFerme(total, { choix = true } = {}) {
  const s = stockFerme;
  return `<div class="fe-paiement">
    ${choix ? `<div class="fe-choix-types fe-choix-paiement">
      <button type="button" class="fe-choix-type choisi" data-pay="tout"><b>Payé en entier</b><small>aujourd'hui</small></button>
      <button type="button" class="fe-choix-type" data-pay="partie"><b>Payé en partie</b><small>le reste à crédit</small></button>
      <button type="button" class="fe-choix-type" data-pay="rien"><b>Rien payé</b><small>tout à crédit</small></button></div>` : ""}
    <div class="fgrid fe-pay-champs" style="margin-top:.8rem">
      <div class="field fe-pay-montant"${choix ? ' style="display:none"' : ""}><label>Montant payé (F)</label><input class="payMontant" inputmode="numeric" value="${total ? formatNombre(total) : ""}"></div>
      <div class="field"><label>Payé par</label><select class="payMode">${s.modes.map(m => `<option>${esc(m)}</option>`).join("")}</select></div>
      ${s.comptes.length ? `<div class="field"><label>Sorti de (facultatif)</label><select class="payCompte"><option value="">— compte habituel —</option>${s.comptes.map(c => `<option value="${c.id}">${esc(c.nom)}</option>`).join("")}</select></div>` : ""}
    </div></div>`;
}
function brancherPaiementFerme(fen) {
  const bloc = fen.querySelector(".fe-choix-paiement");
  if (!bloc) return;
  bloc.addEventListener("click", e => {
    const x = e.target.closest("[data-pay]"); if (!x) return;
    bloc.querySelectorAll(".fe-choix-type").forEach(y => y.classList.toggle("choisi", y === x));
    fen.querySelector(".fe-pay-montant").style.display = x.dataset.pay === "partie" ? "" : "none";
    fen.querySelector(".fe-pay-champs").style.display = x.dataset.pay === "rien" ? "none" : "";
  });
}
function lirePaiementFerme(fen, total) {
  const choisi = fen.querySelector(".fe-choix-paiement .choisi");
  const quoi = choisi ? choisi.dataset.pay : "partie";
  if (quoi === "rien" || !total) return null;
  const montantPaye = quoi === "tout" ? total : lireMontant(fen.querySelector(".payMontant").value);
  if (!montantPaye) throw new Error("Indiquez le montant payé.");
  if (montantPaye > total) throw new Error("Le montant payé dépasse le total.");
  const compte = fen.querySelector(".payCompte");
  return { montant: montantPaye, mode_paiement: fen.querySelector(".payMode").value, compte_id: compte && compte.value ? Number(compte.value) : null };
}

// ---------- Nouvel achat ----------

async function formulaireAchatFerme(produitId = null) {
  try { await chargerDonneesStock(); } catch (e) { toast(e.message); return; }
  const s = stockFerme;
  const produits = s.produits.filter(p => p.actif);
  if (!produits.length) { toast("Créez d'abord un produit."); return; }
  const optionsProduits = id => produits.map(p => `<option value="${p.id}"${p.id === id ? " selected" : ""}>${esc(p.nom)}</option>`).join("");
  const ligne = id => `<tr class="acLigne">
    <td data-titre="Produit"><select class="acProduit">${optionsProduits(id)}</select></td>
    <td data-titre="Quantité"><div class="fe-quantite"><input class="acQte" inputmode="decimal" placeholder="0"><span class="acUnite"></span></div><small class="acKg fe-aide"></small></td>
    ${s.argent ? '<td data-titre="Prix de la ligne (F)"><input class="acPrix" inputmode="numeric" placeholder="0"></td>' : ""}
    <td><button type="button" class="ibtn del" aria-label="Retirer" onclick="this.closest('tr').remove(); totalAchatFerme(this)">✕</button></td></tr>`;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("sac", "fe-fiche-img")}<div><h2>Nouvel achat</h2><p>Ce qui est arrivé à la ferme : le stock augmente tout de suite.</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field"><label for="acFournisseur">Acheté chez</label><div class="fe-quantite"><select id="acFournisseur"><option value="">— fournisseur non précisé —</option>
        ${s.fournisseurs.filter(f => f.actif).map(f => `<option value="${f.id}">${esc(f.nom)}</option>`).join("")}</select>
        <button type="button" class="btn ghost" id="acNouveauF" title="Nouveau fournisseur">+</button></div></div>
      <div class="field"><label for="acDate">Date</label><input id="acDate" type="date"></div>
      <div class="field"><label for="acRef">N° de facture (facultatif)</label><input id="acRef" maxlength="60"></div>
    </div>
    <h4 class="fe-titre">Ce qui est arrivé</h4>
    <div class="fe-tableau fe-saisie fe-fond-blanc"><table><thead><tr><th>Produit</th><th>Quantité</th>${s.argent ? "<th>Prix de la ligne (F)</th>" : ""}<th></th></tr></thead>
      <tbody id="acLignes">${ligne(produitId)}</tbody></table></div>
    <button type="button" class="btn ghost" id="acAjout" style="margin-top:.6rem">+ Un autre produit</button>
    ${s.argent ? `<div class="fe-total">Total : <b id="acTotal">0 F</b></div><h4 class="fe-titre">Paiement</h4>${htmlPaiementFerme(0)}`
      : '<p class="fe-aide">Les prix seront complétés par la Caisse ou l\'Admin.</p>'}
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer l'achat</button></div></div>`, { taille: "large fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#acDate").value = formatDate(aujourdhui());
  brancherPaiementFerme(fen);
  const majLigne = tr => {
    const p = produitFerme(Number(tr.querySelector(".acProduit").value));
    tr.querySelector(".acUnite").textContent = p.kg_par_sac ? "sacs" : p.unite;
    const q = lireNombreFerme(tr.querySelector(".acQte").value);
    tr.querySelector(".acKg").textContent = p.kg_par_sac ? (q ? `= ${nbFerme(q * p.kg_par_sac)} kg` : `1 sac = ${nbFerme(p.kg_par_sac)} kg`) : "";
  };
  const brancher = tr => {
    tr.querySelector(".acProduit").addEventListener("change", () => majLigne(tr));
    tr.querySelector(".acQte").addEventListener("input", () => majLigne(tr));
    const prix = tr.querySelector(".acPrix");
    if (prix) prix.addEventListener("input", () => totalAchatFerme(fen));
    majLigne(tr);
  };
  fen.querySelectorAll(".acLigne").forEach(brancher);
  fen.querySelector("#acAjout").addEventListener("click", () => {
    fen.querySelector("#acLignes").insertAdjacentHTML("beforeend", ligne(null));
    brancher(fen.querySelector("#acLignes").lastElementChild);
  });
  fen.querySelector("#acNouveauF").addEventListener("click", () => formulaireFournisseurFerme(null, f => {
    fen.querySelector("#acFournisseur").insertAdjacentHTML("beforeend", `<option value="${f.id}" selected>${esc(f.nom)}</option>`);
  }));
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const date = isoDepuisTexte(fen.querySelector("#acDate").value);
      if (!date) throw new Error("Date incorrecte : écrivez-la comme 02/12/2026.");
      const lignes = [...fen.querySelectorAll(".acLigne")].map(tr => {
        const p = produitFerme(Number(tr.querySelector(".acProduit").value));
        const q = lireNombreFerme(tr.querySelector(".acQte").value);
        if (!q) throw new Error(`« ${p.nom} » : indiquez la quantité.`);
        const l = { produit_id: p.id, quantite: Math.round(q * (p.kg_par_sac || 1) * 100) / 100 };
        if (s.argent) {
          const prix = lireMontant(tr.querySelector(".acPrix").value);
          if (prix === null) throw new Error(`« ${p.nom} » : indiquez le prix de la ligne.`);
          l.prix = prix;
        }
        return l;
      });
      if (!lignes.length) throw new Error("Ajoutez au moins un produit.");
      const total = lignes.reduce((t, l) => t + (l.prix || 0), 0);
      const corps = { fournisseur_id: fen.querySelector("#acFournisseur").value ? Number(fen.querySelector("#acFournisseur").value) : null,
                      date_achat: date, reference: fen.querySelector("#acRef").value.trim() || null, lignes,
                      paiement: s.argent ? lirePaiementFerme(fen, total) : null };
      if (corps.paiement) corps.paiement.date_versement = date;
      ok.disabled = true;
      const r = await api("/api/ferme/achats", { method: "POST", body: corps });
      fen.fermer();
      toast(`Achat ${r.numero} enregistré : le stock est à jour`, 5000);
      stockFerme = null;
      rafraichirStockFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}
function totalAchatFerme(depuis) {
  const fen = depuis.closest ? depuis.closest(".modal-box") || depuis : depuis;
  const t = [...fen.querySelectorAll(".acPrix")].reduce((s, c) => s + (lireMontant(c.value) || 0), 0);
  const z = fen.querySelector("#acTotal");
  if (z) z.textContent = formatMontant(t);
  const m = fen.querySelector(".payMontant");
  if (m && !m.dataset.touche) m.value = t ? formatNombre(t) : "";
}

// ---------- Achats ----------

async function chargerAchatsFerme() {
  const zone = el("zoneAchatsFerme");
  try { await chargerDonneesStock(); achatsFerme = await api("/api/ferme/achats"); } catch (e) { erreurFerme(zone, e); return; }
  const s = stockFerme;
  zone.innerHTML = `<div class="fe-carte"><div class="fe-dette-tete"><h3>Achats d'aliments et de produits</h3>${s.note_achats ? '<button class="btn primary" onclick="formulaireAchatFerme()">+ Nouvel achat</button>' : ""}</div>
    ${achatsFerme.length ? `<div class="fe-tableau"><table>
      <thead><tr><th>Achat</th><th>Chez</th><th>Produits</th>${s.voit_argent ? '<th class="nb">Total</th><th class="nb">Reste à payer</th>' : ""}<th>État</th></tr></thead>
      <tbody>${achatsFerme.map(a => `<tr class="fe-ligne" onclick="ouvrirFicheAchatFerme(${a.id})" tabindex="0" onkeydown="if(event.key==='Enter')ouvrirFicheAchatFerme(${a.id})">
        <td data-titre="Achat"><span class="fe-bande">${imgCat(a.lignes[0] ? a.lignes[0].categorie : "Aliment")}<span><b>${formatDate(a.date)}</b><small>n° ${esc(a.numero)}</small></span></span></td>
        <td data-titre="Chez">${esc(a.fournisseur) || "—"}</td>
        <td data-titre="Produits">${a.lignes.map(l => `${esc(l.produit)} <small>(${esc(l.texte)})</small>`).join("<br>")}</td>
        ${s.voit_argent ? `<td data-titre="Total" class="nb">${a.total !== null ? formatMontant(a.total) : "—"}</td>
          <td data-titre="Reste à payer" class="nb">${a.reste ? `<b class="fe-rouge">${formatMontant(a.reste)}</b>` : "—"}</td>` : ""}
        <td data-titre="État">${pastilleFerme(ETAT_ACHAT[a.etat])}</td></tr>`).join("")}</tbody></table></div>`
      : `<div class="fe-vide">${imgFerme("sac", "fe-vide-img")}<p>Aucun achat pour l'instant.</p></div>`}</div>`;
}

async function ouvrirFicheAchatFerme(id) {
  let a = achatsFerme.find(x => x.id === id);
  try { if (!stockFerme) await chargerDonneesStock(); if (!a) { achatsFerme = await api("/api/ferme/achats"); a = achatsFerme.find(x => x.id === id); } } catch (e) { toast(e.message); return; }
  if (!a) return;
  const s = stockFerme;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgCat(a.lignes[0] ? a.lignes[0].categorie : "Aliment", "fe-fiche-img")}<div><h2>Achat du ${formatDate(a.date)}</h2>
      <p>n° ${esc(a.numero)}${a.fournisseur ? " · chez " + esc(a.fournisseur) : ""}${a.reference ? " · facture " + esc(a.reference) : ""}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    ${s.voit_argent ? `<div class="fe-fiche-grand ${(ETAT_ACHAT[a.etat])[0]}"><b>${a.total !== null ? formatMontant(a.total) : "Prix à compléter"}</b>
      <span>${pastilleFerme(ETAT_ACHAT[a.etat])}${a.reste ? ` · reste à payer ${formatMontant(a.reste)}` : ""}${a.annule ? " · " + esc(a.motif_annulation) : ""}</span></div>` : ""}
    <div class="fe-tableau fe-fond-blanc"><table><thead><tr><th>Produit</th><th class="nb">Quantité</th>${s.voit_argent ? '<th class="nb">Prix</th>' : ""}</tr></thead><tbody>
      ${a.lignes.map(l => `<tr><td><span class="fe-bande">${imgCat(l.categorie)}<b>${esc(l.produit)}</b></span></td><td class="nb">${esc(l.texte)}</td>
        ${s.voit_argent ? `<td class="nb">${l.prix !== null && l.prix !== undefined ? formatMontant(l.prix) : "—"}</td>` : ""}</tr>`).join("")}</tbody></table></div>
    ${s.voit_argent && a.versements && a.versements.length ? `<h4 class="fe-titre">Paiements</h4><div class="fe-tableau fe-fond-blanc"><table><thead><tr><th>Date</th><th class="nb">Montant</th><th>Payé par</th><th>Noté par</th><th></th></tr></thead><tbody>
      ${a.versements.map(v => `<tr><td>${formatDate(v.date)}</td><td class="nb"><b>${formatMontant(v.montant)}</b></td><td>${esc(v.mode)}</td><td><small>${esc(v.saisi_par)}</small></td>
        <td>${s.argent ? `<button class="ibtn del" data-supv="${v.id}" aria-label="Supprimer ce paiement" data-tip="Supprimer ce paiement">✕</button>` : ""}</td></tr>`).join("")}</tbody></table></div>` : ""}
    <p class="fe-aide">Noté par ${esc(a.saisi_par)}${a.note ? " · " + esc(a.note) : ""}</p>
    <div class="actions">
      ${s.est_admin && !a.annule ? '<button class="btn ghost" data-action="annuler">Annuler l\'achat</button>' : ""}
      ${s.argent && a.etat === "prix" ? '<button class="btn primary" data-action="prix">Compléter les prix</button>' : ""}
      ${s.argent && a.etat === "credit" ? '<button class="btn primary" data-action="payer">Payer</button>' : ""}
    </div></div>`, { taille: "large fe-fenetre" });
  const action = (nom, fn) => { const x = fen.querySelector(`[data-action="${nom}"]`); if (x) x.addEventListener("click", () => { fen.fermer(); fn(); }); };
  action("prix", () => formulairePrixAchatFerme(a));
  action("payer", () => formulairePayerFerme(a));
  action("annuler", () => annulerAchatFerme(a));
  fen.querySelectorAll("[data-supv]").forEach(b => b.addEventListener("click", async () => {
    const mdp = await demanderMotDePasseAdmin("Supprimer ce paiement ? Entrez votre mot de passe.");
    if (!mdp) return;
    try { await api(`/api/ferme/versements/${b.dataset.supv}/supprimer`, { method: "POST", body: { mot_de_passe_admin: mdp } }); fen.fermer(); toast("Paiement supprimé"); rafraichirStockFerme(); }
    catch (e) { toast(e.message, 7000); }
  }));
}

function formulairePrixAchatFerme(a) {
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("sac", "fe-fiche-img")}<div><h2>Compléter les prix</h2><p>Achat du ${formatDate(a.date)} (n° ${esc(a.numero)})</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fe-tableau fe-saisie fe-fond-blanc"><table><thead><tr><th>Produit</th><th class="nb">Quantité</th><th>Prix de la ligne (F)</th></tr></thead><tbody>
      ${a.lignes.map(l => `<tr><td><b>${esc(l.produit)}</b></td><td class="nb">${esc(l.texte)}</td><td><input class="acPrix" data-ligne="${l.id}" inputmode="numeric" placeholder="0"></td></tr>`).join("")}</tbody></table></div>
    <div class="fe-total">Total : <b id="acTotal">0 F</b></div>
    <h4 class="fe-titre">Paiement</h4>${htmlPaiementFerme(0)}
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "large fe-fenetre" });
  brancherPaiementFerme(fen);
  fen.querySelectorAll(".acPrix").forEach(c => c.addEventListener("input", () => totalAchatFerme(fen)));
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const prix = {};
      fen.querySelectorAll(".acPrix").forEach(c => { const v = lireMontant(c.value); if (v === null) throw new Error("Indiquez le prix de chaque produit."); prix[c.dataset.ligne] = v; });
      const total = Object.values(prix).reduce((t, v) => t + v, 0);
      ok.disabled = true;
      await api(`/api/ferme/achats/${a.id}/prix`, { method: "POST", body: { prix, paiement: lirePaiementFerme(fen, total) } });
      fen.fermer();
      toast("Prix enregistrés");
      rafraichirStockFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

function formulairePayerFerme(a) {
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("sac", "fe-fiche-img")}<div><h2>Payer ${a.fournisseur ? esc(a.fournisseur) : "le fournisseur"}</h2>
      <p>Achat du ${formatDate(a.date)} · reste à payer ${formatMontant(a.reste)}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    ${htmlPaiementFerme(a.reste, { choix: false })}
    <div class="field"><label for="pfDate">Date</label><input id="pfDate" type="date"></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer le paiement</button></div></div>`, { taille: "fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#pfDate").value = formatDate(aujourdhui());
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const p = lirePaiementFerme(fen, a.reste);
      p.date_versement = isoDepuisTexte(fen.querySelector("#pfDate").value);
      if (!p.date_versement) throw new Error("Date incorrecte : écrivez-la comme 02/12/2026.");
      ok.disabled = true;
      await api(`/api/ferme/achats/${a.id}/versements`, { method: "POST", body: p });
      fen.fermer();
      toast("Paiement enregistré");
      rafraichirStockFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

async function annulerAchatFerme(a) {
  const mdp = await demanderMotDePasseAdmin(`Annuler l'achat du ${formatDate(a.date)} ? Ses produits sortiront du stock. Entrez votre mot de passe.`,
                                            { titre: "Annuler l'achat", bouton: "Annuler l'achat" });
  if (!mdp) return;
  try {
    await api(`/api/ferme/achats/${a.id}/annuler`, { method: "POST", body: { mot_de_passe_admin: mdp, motif: "Annulé par l'Admin" } });
    toast("Achat annulé");
    rafraichirStockFerme();
  } catch (e) { toast(e.message, 7000); }
}

// ---------- Ce que je dois aux fournisseurs ----------

async function chargerDettesFerme() {
  const zone = el("zoneDettesFerme");
  let d;
  try { await chargerDonneesStock(); d = await api("/api/ferme/dettes"); achatsFerme = await api("/api/ferme/achats"); } catch (e) { erreurFerme(zone, e); return; }
  zone.innerHTML = `<div class="fe-chiffres">
      <div class="fe-chiffre ${d.total ? "rouge" : "vert"}">${imgFerme("sac", "fe-chiffre-img")}<span><b>${formatMontant(d.total)}</b><span class="fe-chiffre-libelle">Je dois aux fournisseurs</span><small>${d.total ? `${plurielFerme(d.fournisseurs.length, "fournisseur")} à payer` : "rien à payer 👍"}</small></span></div>
      ${d.prix_a_completer ? `<button type="button" class="fe-chiffre jaune" onclick="montrerOngletFerme('frAchats')">${imgFerme("sac", "fe-chiffre-img")}<span><b>${d.prix_a_completer}</b><span class="fe-chiffre-libelle">Achats sans prix</span><small>cliquez pour les compléter</small></span></button>` : ""}
    </div>
    ${d.fournisseurs.map(f => `<div class="fe-carte"><div class="fe-dette-tete"><h3>${esc(f.fournisseur)}</h3><b class="fe-rouge">${formatMontant(f.total)}</b></div>
      <div class="fe-tableau"><table><thead><tr><th>Achat</th><th class="nb">Total</th><th class="nb">Reste à payer</th><th></th></tr></thead><tbody>
      ${f.achats.map(a => `<tr><td data-titre="Achat"><b>${formatDate(a.date)}</b> <small>n° ${esc(a.numero)}</small></td><td data-titre="Total" class="nb">${formatMontant(a.total)}</td>
        <td data-titre="Reste" class="nb"><b class="fe-rouge">${formatMontant(a.reste)}</b></td>
        <td>${stockFerme.argent ? `<button class="btn primary" onclick="formulairePayerFerme(achatsFerme.find(x => x.id === ${a.id}))">Payer</button>` : ""}</td></tr>`).join("")}
      </tbody></table></div></div>`).join("")}`;
}

// ---------- Fournisseurs ----------

async function chargerFournisseursFerme() {
  const zone = el("zoneFournisseursFerme");
  try { await chargerDonneesStock(); } catch (e) { erreurFerme(zone, e); return; }
  const s = stockFerme;
  zone.innerHTML = `${s.note_achats ? '<div class="fe-barre"><button class="btn primary" onclick="formulaireFournisseurFerme(null)">+ Nouveau fournisseur</button></div>' : ""}
    <div class="fe-carte">${s.fournisseurs.length ? `<div class="fe-tableau"><table><thead><tr><th>Fournisseur</th><th>Téléphone</th><th>Note</th><th>État</th></tr></thead><tbody>
      ${s.fournisseurs.map(f => `<tr${s.note_achats ? ` class="fe-ligne" onclick="formulaireFournisseurFerme(${f.id})" tabindex="0"` : ""}>
        <td data-titre="Fournisseur"><b>${esc(f.nom)}</b></td><td data-titre="Téléphone">${esc(f.telephone) || "—"}</td><td data-titre="Note">${esc(f.note) || ""}</td>
        <td data-titre="État">${f.actif ? '<span class="fe-pastille vert">Actif</span>' : '<span class="fe-pastille gris">Plus utilisé</span>'}</td></tr>`).join("")}</tbody></table></div>`
      : `<div class="fe-vide">${imgFerme("poulailler", "fe-vide-img")}<p>Aucun fournisseur. Ajoutez ceux qui vous vendent aliments, poussins, vaccins…</p></div>`}</div>`;
}

function formulaireFournisseurFerme(id, apres = null) {
  const f = id ? stockFerme.fournisseurs.find(x => x.id === id) : null;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("poulailler", "fe-fiche-img")}<div><h2>${f ? "Modifier le fournisseur" : "Nouveau fournisseur"}</h2><p>Celui qui vous vend aliments, vaccins, matériel…</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field"><label for="foNom">Nom</label><input id="foNom" maxlength="100" value="${esc(f ? f.nom : "")}"></div>
      <div class="field"><label for="foTel">Téléphone (facultatif)</label><input id="foTel" inputmode="tel" maxlength="30" value="${esc(f ? f.telephone : "")}"></div>
    </div>
    <div class="field"><label for="foNote">Note (facultatif)</label><input id="foNote" maxlength="300" value="${esc(f ? f.note : "")}"></div>
    ${f ? `<label class="case"><input type="checkbox" id="foActif"${f.actif ? " checked" : ""}> Fournisseur utilisé</label>` : ""}
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "fe-fenetre" });
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const nom = fen.querySelector("#foNom").value.trim();
      if (nom.length < 2) throw new Error("Indiquez le nom du fournisseur.");
      ok.disabled = true;
      const r = await api(f ? `/api/ferme/fournisseurs/${f.id}` : "/api/ferme/fournisseurs", { method: f ? "PUT" : "POST", body: {
        nom, telephone: fen.querySelector("#foTel").value.trim() || null, note: fen.querySelector("#foNote").value.trim() || null,
        actif: f ? fen.querySelector("#foActif").checked : true } });
      fen.fermer();
      toast("Fournisseur enregistré");
      await chargerDonneesStock();
      if (apres) apres({ id: r.id, nom }); else rafraichirStockFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}
