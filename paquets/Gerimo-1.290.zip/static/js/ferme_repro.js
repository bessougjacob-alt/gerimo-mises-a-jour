// Ferme, étape 4 (22/11/2026) : reproduction et animaux — fiches techniques (modèle par espèce), âges, parents,
// générations, accouplements (dates prévues), naissances (fiches ou bande), statistiques par espèce.
// Même style que la Ferme (ferme.js). Le serveur (ferme_repro.py) revérifie tout.

let animauxFerme = null, reproFerme = null;
let filtreEspeceAnimaux = "tous", voirSortis = false, especeStats = null;
const SEXE_PASTILLE = { "Mâle": ["bleu", "♂ Mâle"], "Femelle": ["rose", "♀ Femelle"], "Inconnu": ["gris", "?"] };
const SANTE_PASTILLE = { "Bonne santé": "vert", "Malade": "rouge", "En traitement": "jaune", "Blessé": "rouge" };
const RESULTAT_ACC = { "En attente": ["jaune", "En attente"], "Réussi": ["vert", "Réussi"], "Non réussi": ["gris", "Non réussi"] };
const pastilleSexe = s => { const [c, t] = SEXE_PASTILLE[s] || SEXE_PASTILLE.Inconnu; return `<span class="fe-pastille ${c}">${t}</span>`; };
const pastilleSante = s => `<span class="fe-pastille ${SANTE_PASTILLE[s] || "gris"}">${esc(s)}</span>`;
// « 12 jours », « 5 mois », « 2 ans 3 mois » (même règle que le serveur)
function ageTexteFerme(jours) {
  if (jours < 60) return `${jours} jour${jours > 1 ? "s" : ""}`;
  const mois = Math.round(jours / 30.44);
  if (mois < 12) return `${mois} mois`;
  const ans = Math.floor(mois / 12), reste = mois % 12;
  return `${ans} an${ans > 1 ? "s" : ""}${reste ? ` ${reste} mois` : ""}`;
}

Object.assign(ONGLETS_FERME, { frAnimaux: () => chargerAnimauxFerme(), frRepro: () => chargerReproFerme(), frStats: () => chargerStatsFerme() });

// ---------- Animaux (fiches) ----------

// Fiches techniques en TABLEAU (demande de Boss du 22/11/2026) : une ligne par animal, des cases à remplir directement,
// comme une feuille de calcul ; les colonnes propres à l'espèce viennent de son modèle (robe, pelage…). Un seul bouton
// enregistre toutes les lignes changées ; l'âge se calcule tout seul ; la fiche complète s'ouvre avec ⓘ.
let especeFiches = null;

async function chargerAnimauxFerme() {
  const zone = el("zoneAnimauxFerme");
  try { animauxFerme = await api("/api/ferme/animaux"); if (!tableauFerme) await chargerTableauFerme(); } catch (e) { erreurFerme(zone, e); return; }
  const a = animauxFerme;
  const choix = a.especes.filter(e => e.actif || a.animaux.some(x => x.espece === e.nom));
  if (!especeFiches || !choix.some(e => e.nom === especeFiches)) {
    const avec = choix.find(e => a.animaux.some(x => x.espece === e.nom));
    especeFiches = (avec || choix[0] || {}).nom;
  }
  const e = a.especes.find(z => z.nom === especeFiches) || { modele: {} };
  const m = e.modele || {};
  const champs = m.champs || [];
  const lignes = a.animaux.filter(x => x.espece === especeFiches && (voirSortis ? x.statut !== "Présent" : x.statut === "Présent"));
  const presents = a.animaux.filter(x => x.espece === especeFiches && x.statut === "Présent");
  const malades = presents.filter(x => x.etat_sante !== "Bonne santé").length;
  const ecrit = a.ecrit && !voirSortis;
  zone.innerHTML = `
    <div class="fe-barre fe-barre-stock"><div class="fe-types-suivi">${choix.map(x => `<label class="fe-case-type${x.nom === especeFiches ? " coche" : ""}" onclick="especeFiches = '${esc(x.nom).replace(/'/g, "\\'")}'; chargerAnimauxFerme()">
        ${imgFerme(x.dessin, "fe-case-img")}<span>${esc(x.nom)}</span></label>`).join("")}
      <label class="fe-case-type${voirSortis ? " coche" : ""}" onclick="voirSortis = !voirSortis; chargerAnimauxFerme()"><span>${voirSortis ? "Voir les présents" : "Vendus, morts, réformés"}</span></label></div></div>
    <div class="fe-chiffres">
      <div class="fe-chiffre creme">${imgFerme(e.dessin || "animal", "fe-chiffre-img")}<span><span class="fe-chiffre-libelle">${esc(especeFiches || "Animaux")} avec fiche</span><b>${presents.length}</b><small>présents à la ferme</small></span></div>
      <div class="fe-chiffre bleu">${imgMarque(e.dessin, "male", "fe-chiffre-img")}<span><span class="fe-chiffre-libelle">Mâles</span><b>${presents.filter(x => x.sexe === "Mâle").length}</b><small>avec fiche</small></span></div>
      <div class="fe-chiffre rose">${imgMarque(e.dessin, "femelle", "fe-chiffre-img")}<span><span class="fe-chiffre-libelle">Femelles</span><b>${presents.filter(x => x.sexe === "Femelle").length}</b><small>avec fiche</small></span></div>
      <div class="fe-chiffre ${malades ? "rouge" : "vert"}">${imgFerme("plat:croix")}<span><span class="fe-chiffre-libelle">Malades ou blessés</span><b>${malades}</b><small>${malades ? "à surveiller" : "tout le monde va bien 👍"}</small></span></div>
    </div>
    ${(m.reperes || []).length ? `<div class="fe-reperes"><b>Repères pour les ${esc((especeFiches || "").toLowerCase())}</b>${m.reperes.map(r => `<span><small>${esc(r[0])}</small>${esc(r[1])}</span>`).join("")}</div>` : ""}
    <div class="fe-carte">
      <div class="fe-dette-tete"><h3>Fiches techniques : ${esc(especeFiches || "")}</h3>
        ${ecrit ? '<div class="fe-boutons"><button class="btn" onclick="ajouterLignesFiches(1)">+ Une ligne</button><button class="btn" onclick="ajouterLignesFiches(5)">+ 5 lignes</button></div>' : ""}</div>
      <p class="fe-aide">${ecrit ? "Remplissez les cases directement : une ligne par animal. Les lignes changées passent en jaune ; cliquez sur « Enregistrer » en bas." : "Consultation seulement."}</p>
      <div class="fe-tableau fe-saisie fe-grille"><table><thead><tr>
        <th>N° d'étiquette</th><th>Nom</th><th>Sexe</th><th>Race</th><th>Né le</th><th>Âge à l'arrivée</th><th>Arrivé le</th><th class="nb">Âge</th>
        <th>Mère</th><th>Père</th>${champs.map(c => `<th>${esc(c.nom)}</th>`).join("")}<th>Caractéristiques</th><th>Santé</th><th>Poids (kg)</th><th>Reproducteur</th><th></th>
      </tr></thead><tbody id="grilleFiches">${lignes.map(x => ligneFiche(x, e, ecrit)).join("")}${ecrit && !lignes.length ? ligneFiche(null, e, true) : ""}</tbody></table></div>
      <datalist id="grRaces">${(m.races || []).map(r => `<option value="${esc(r)}">`).join("")}</datalist>
      ${champs.map((c, i) => `<datalist id="grChoix${i}">${(c.choix || []).map(o => `<option value="${esc(o)}">`).join("")}</datalist>`).join("")}
      <datalist id="grCarac">${(m.caracteristiques || []).map(o => `<option value="${esc(o)}">`).join("")}</datalist>
      ${ecrit ? `<div class="form-erreur" role="alert" id="grErreur"></div>
        <div class="actions"><span class="fe-aide" id="grCompte" style="margin:0 auto 0 0">Aucun changement.</span><button class="btn-encaisser fe-bouton" id="grEnregistrer" onclick="enregistrerFiches()">Enregistrer</button></div>` : ""}
    </div>`;
  brancherGrilleFiches();
}

function ligneFiche(x, e, ecrit) {
  const m = e.modele || {}, champs = m.champs || [];
  const a = animauxFerme;
  const dis = ecrit ? "" : " disabled";
  const meres = a.animaux.filter(z => z.espece === e.nom && z.sexe === "Femelle" && (!x || z.id !== x.id));
  const peres = a.animaux.filter(z => z.espece === e.nom && z.sexe === "Mâle" && (!x || z.id !== x.id));
  const ageArr = x && !x.date_naissance && x.age_arrivee ? Math.round(x.age_arrivee / 30.44 * 10) / 10 : "";
  return `<tr class="grLigne" data-id="${x ? x.id : ""}">
    <td><input class="grNumero" maxlength="30" value="${esc(x ? x.numero : "")}"${dis}></td>
    <td><input class="grNom" maxlength="60" value="${esc(x ? x.nom : "")}"${dis}></td>
    <td><select class="grSexe"${dis}>${["Inconnu", "Mâle", "Femelle"].map(s => `<option value="${s}"${(x ? x.sexe : "Inconnu") === s ? " selected" : ""}>${s === "Inconnu" ? "?" : s === "Mâle" ? "♂ Mâle" : "♀ Femelle"}</option>`).join("")}</select></td>
    <td><input class="grRace" list="grRaces" maxlength="60" value="${esc(x ? x.race : "")}"${dis}></td>
    <td><input class="grNe" placeholder="jj/mm/aaaa" maxlength="10" inputmode="numeric" value="${x && x.date_naissance ? formatDate(x.date_naissance) : ""}"${dis}></td>
    <td><div class="fe-quantite"><input class="grAgeArr" inputmode="decimal" placeholder="mois" value="${ageArr}"${dis}><span class="fe-aide" style="margin:0">mois</span></div></td>
    <td><input class="grArrive" placeholder="jj/mm/aaaa" maxlength="10" inputmode="numeric" value="${formatDate(x ? x.date_arrivee : aujourdhui())}"${dis}></td>
    <td class="nb grAge"><b>${x ? esc(x.age_texte) : "—"}</b></td>
    <td><select class="grMere"${dis}><option value="">—</option>${meres.map(z => `<option value="${z.id}"${x && x.mere_id === z.id ? " selected" : ""}>${esc(z.libelle)}</option>`).join("")}</select></td>
    <td><select class="grPere"${dis}><option value="">—</option>${peres.map(z => `<option value="${z.id}"${x && x.pere_id === z.id ? " selected" : ""}>${esc(z.libelle)}</option>`).join("")}</select></td>
    ${champs.map((c, i) => `<td><input class="grChamp" data-nom="${esc(c.nom)}" list="grChoix${i}" maxlength="40" value="${esc(x ? (x.details || {})[c.nom] || "" : "")}"${dis}></td>`).join("")}
    <td><input class="grCarac" list="grCarac" maxlength="300" value="${esc(x ? x.caracteristiques : "")}"${dis}></td>
    <td><select class="grSante"${dis}>${["Bonne santé", "Malade", "En traitement", "Blessé"].map(s => `<option${(x ? x.etat_sante : "Bonne santé") === s ? " selected" : ""}>${s}</option>`).join("")}</select></td>
    <td><input class="grPoids" inputmode="decimal" value="${x && x.poids_kg ? String(x.poids_kg).replace(".", ",") : ""}" data-avant="${x && x.poids_kg ? x.poids_kg : ""}"${dis}></td>
    <td class="nb"><input type="checkbox" class="grRepro"${x && x.reproducteur ? " checked" : ""}${dis}></td>
    <td>${x ? `<button type="button" class="ibtn" onclick="ouvrirFicheAnimalFerme(${x.id})" data-tip="Fiche complète" aria-label="Fiche complète">ⓘ</button>` : ""}</td>
  </tr>`;
}

function ajouterLignesFiches(n) {
  const e = animauxFerme.especes.find(z => z.nom === especeFiches);
  const corps = el("grilleFiches");
  for (let i = 0; i < n; i++) corps.insertAdjacentHTML("beforeend", ligneFiche(null, e, true));
  brancherGrilleFiches();
  corps.lastElementChild.querySelector(".grNumero").focus();
}

function brancherGrilleFiches() {
  const corps = el("grilleFiches");
  if (!corps) return;
  corps.querySelectorAll(".grLigne").forEach(tr => {
    if (tr.dataset.branche) return;
    tr.dataset.branche = "1";
    const maj = () => {
      tr.classList.add("modifie");
      // âge calculé tout de suite : date de naissance, sinon âge à l'arrivée + temps passé à la ferme
      const ne = isoDepuisTexte(tr.querySelector(".grNe").value), arr = isoDepuisTexte(tr.querySelector(".grArrive").value);
      const mois = lireNombreFerme(tr.querySelector(".grAgeArr").value) || 0;
      let jours = null;
      if (ne) jours = Math.round((new Date(aujourdhui()) - new Date(ne)) / 86400000);
      else if (arr) jours = Math.round(mois * 30.44) + Math.round((new Date(aujourdhui()) - new Date(arr)) / 86400000);
      tr.querySelector(".grAge").innerHTML = jours !== null && jours >= 0 ? `<b>${ageTexteFerme(jours)}</b>` : "—";
      const n = el("grilleFiches").querySelectorAll(".grLigne.modifie").length;
      if (el("grCompte")) el("grCompte").textContent = n ? `${plurielFerme(n, "ligne changée", "lignes changées")} à enregistrer` : "Aucun changement.";
    };
    tr.querySelectorAll("input, select").forEach(c => c.addEventListener(c.type === "checkbox" || c.tagName === "SELECT" ? "change" : "input", maj));
    tr.querySelectorAll(".grNe, .grArrive").forEach(c => c.addEventListener("input", ev => {   // les « / » s'ajoutent en tapant
      if (ev.inputType && ev.inputType.startsWith("delete")) return;
      const ch = c.value.replace(/\D/g, "").slice(0, 8);
      c.value = [ch.slice(0, 2), ch.slice(2, 4), ch.slice(4)].filter(Boolean).join("/");
    }));
  });
}

async function enregistrerFiches() {
  const erreur = el("grErreur"), bouton = el("grEnregistrer");
  erreur.style.display = "none";
  const lignes = [...el("grilleFiches").querySelectorAll(".grLigne.modifie")];
  if (!lignes.length) { toast("Aucun changement à enregistrer."); return; }
  bouton.disabled = true;
  let faits = 0;
  try {
    for (const tr of lignes) {
      const q = c => tr.querySelector(c);
      const id = tr.dataset.id ? Number(tr.dataset.id) : null;
      const ancien = id ? animauxFerme.animaux.find(z => z.id === id) : null;
      const numero = q(".grNumero").value.trim(), nom = q(".grNom").value.trim();
      if (!id && !numero && !nom && !q(".grRace").value.trim()) { tr.classList.remove("modifie"); continue; }   // ligne vide
      const qui = numero ? `n° ${numero}` : nom || "une nouvelle ligne";
      const ne = q(".grNe").value.trim() ? isoDepuisTexte(q(".grNe").value) : null;
      if (q(".grNe").value.trim() && !ne) throw new Error(`${qui} : date de naissance incorrecte (jj/mm/aaaa).`);
      const arrive = isoDepuisTexte(q(".grArrive").value);
      if (!arrive) throw new Error(`${qui} : date d'arrivée incorrecte (jj/mm/aaaa).`);
      const mois = lireNombreFerme(q(".grAgeArr").value);
      if (mois === null) throw new Error(`${qui} : âge à l'arrivée incorrect (en mois, ex : 4 ou 2,5).`);
      const poids = q(".grPoids").value.trim() ? lireNombreFerme(q(".grPoids").value) : null;
      if (q(".grPoids").value.trim() && !poids) throw new Error(`${qui} : poids incorrect (ex : 3,8).`);
      const details = {};
      tr.querySelectorAll(".grChamp").forEach(c => { if (c.value.trim()) details[c.dataset.nom] = c.value.trim(); });
      const mere = q(".grMere").value ? Number(q(".grMere").value) : null, pere = q(".grPere").value ? Number(q(".grPere").value) : null;
      const corps = { espece: especeFiches, numero: numero || null, nom: nom || null, sexe: q(".grSexe").value, race: q(".grRace").value.trim() || null,
                      date_naissance: ne, date_arrivee: arrive, age_arrivee: Math.round(mois * 30.44), mere_id: mere, pere_id: pere, details,
                      caracteristiques: q(".grCarac").value.trim() || null, etat_sante: q(".grSante").value, reproducteur: q(".grRepro").checked,
                      origine: ancien ? ancien.origine : (mere || pere ? "Né à la ferme" : "Acheté"),
                      bande_id: ancien ? ancien.bande_id : null, poulailler_id: ancien ? ancien.poulailler_id : null, note: ancien ? ancien.note || null : null };
      const r = await api(id ? `/api/ferme/animaux/${id}` : "/api/ferme/animaux", { method: id ? "PUT" : "POST", body: corps }).catch(err => { throw new Error(`${qui} : ${err.message}`); });
      if (poids && String(poids) !== String(q(".grPoids").dataset.avant)) {
        await api(`/api/ferme/animaux/${r.id}/pesees`, { method: "POST", body: { poids_kg: poids } }).catch(err => { throw new Error(`${qui} : ${err.message}`); });
      }
      tr.dataset.id = r.id;
      tr.classList.remove("modifie");
      faits++;
    }
    toast(faits ? `${plurielFerme(faits, "fiche enregistrée", "fiches enregistrées")} 👍` : "Rien à enregistrer.");
    chargerAnimauxFerme();
  } catch (e) {
    erreur.textContent = e.message + (faits ? ` (${plurielFerme(faits, "fiche déjà enregistrée", "fiches déjà enregistrées")})` : "");
    erreur.style.display = "block";
    bouton.disabled = false;
  }
}

async function ouvrirFicheAnimalFerme(id) {
  let x;
  try { x = await api(`/api/ferme/animaux/${id}`); if (!animauxFerme) animauxFerme = await api("/api/ferme/animaux"); } catch (e) { toast(e.message); return; }
  const a = animauxFerme;
  const ligne = (l, v) => v === null || v === undefined || v === "" ? "" : `<tr><th>${l}</th><td>${v}</td></tr>`;
  const lienAnimal = (sid, txt) => sid ? `<a href="#" class="fe-lien" data-animal="${sid}">${esc(txt)}</a>` : esc(txt || "—");
  const reperes = (x.modele.reperes || []);
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme(x.dessin, "fe-fiche-img")}<div><h2>${esc(x.libelle)}</h2><p>${esc(x.espece)}${x.race ? " · " + esc(x.race) : ""} · génération ${x.generation}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fe-fiche-grand ${x.statut === "Présent" ? (x.etat_sante === "Bonne santé" ? "vert" : "rouge") : "gris"}"><b>${esc(x.age_texte)}</b>
      <span>${pastilleSexe(x.sexe)} ${pastilleSante(x.etat_sante)} · ${x.statut === "Présent" ? `à la ferme depuis ${esc(x.a_la_ferme_texte)}` : `${esc(x.statut)} le ${formatDate(x.date_sortie)}${x.cause_sortie ? " (" + esc(x.cause_sortie) + ")" : ""}`}</span></div>
    <div class="fe-fiche-colonnes">
      <div class="fe-tableau fe-tableau-cles"><table><tbody>
        ${ligne("N° d'étiquette", esc(x.numero))}${ligne("Nom", esc(x.nom))}
        ${x.date_naissance ? ligne("Né le", formatDate(x.date_naissance)) : ligne("Âge à l'arrivée", ageTexteFerme(x.age_arrivee))}
        ${ligne("Arrivé le", formatDate(x.date_arrivee))}${ligne("Origine", esc(x.origine))}
        ${ligne("Mère", lienAnimal(x.mere_id, x.mere))}${ligne("Père", lienAnimal(x.pere_id, x.pere))}
      </tbody></table></div>
      <div class="fe-tableau fe-tableau-cles"><table><tbody>
        ${Object.entries(x.details || {}).map(([k, v]) => ligne(esc(k), esc(v))).join("")}
        ${ligne("Caractéristiques", esc(x.caracteristiques))}
        ${ligne("Bâtiment", esc(x.batiment))}${ligne("Lot", esc(x.bande))}
        ${ligne("Reproducteur", x.reproducteur ? "oui" : "")}${ligne("Dernier poids", x.poids_kg ? `${nbFerme(x.poids_kg)} kg <small>le ${formatDate(x.poids_le)}</small>` : "")}
        ${ligne("Note", esc(x.note))}
      </tbody></table></div>
    </div>
    ${reperes.length ? `<div class="fe-reperes"><b>Repères pour les ${esc(x.espece.toLowerCase())}</b>${reperes.map(r => `<span><small>${esc(r[0])}</small>${esc(r[1])}</span>`).join("")}</div>` : ""}
    ${x.pesees.length ? `<h4 class="fe-titre">Pesées</h4><div class="fe-tableau fe-fond-blanc"><table><thead><tr><th>Date</th><th class="nb">Poids</th></tr></thead><tbody>
      ${x.pesees.slice().reverse().map(p => `<tr><td>${formatDate(p.date)}</td><td class="nb"><b>${nbFerme(p.poids_kg)} kg</b></td></tr>`).join("")}</tbody></table></div>` : ""}
    ${x.enfants.length ? `<h4 class="fe-titre">Ses petits (${x.enfants.length})</h4><div class="fe-tableau fe-fond-blanc"><table><thead><tr><th>Petit</th><th>Sexe</th><th class="nb">Âge</th><th>État</th></tr></thead><tbody>
      ${x.enfants.map(c => `<tr class="fe-ligne" data-animal="${c.id}"><td><b>${esc(c.libelle)}</b></td><td>${pastilleSexe(c.sexe)}</td><td class="nb">${esc(c.age_texte)}</td><td>${esc(c.statut)}</td></tr>`).join("")}</tbody></table></div>` : ""}
    ${x.portees.length ? `<h4 class="fe-titre">Portées</h4><div class="fe-tableau fe-fond-blanc"><table><thead><tr><th>Date</th><th class="nb">Nés vivants</th><th class="nb">Morts-nés</th><th>♂ / ♀</th></tr></thead><tbody>
      ${x.portees.map(n => `<tr><td>${formatDate(n.date)}</td><td class="nb"><b>${n.nes_vivants}</b></td><td class="nb">${n.morts_nes}</td><td>${n.males} ♂ · ${n.femelles} ♀</td></tr>`).join("")}</tbody></table></div>` : ""}
    ${x.accouplements.length ? `<h4 class="fe-titre">Accouplements</h4><div class="fe-tableau fe-fond-blanc"><table><thead><tr><th>Date</th><th>Avec</th><th>Résultat</th><th>Mise bas prévue</th></tr></thead><tbody>
      ${x.accouplements.map(c => `<tr><td>${formatDate(c.date)}</td><td>${esc(x.sexe === "Femelle" ? c.male : c.femelle) || "—"}</td><td>${pastilleFerme(RESULTAT_ACC[c.resultat])}</td><td>${c.mise_bas_prevue ? formatDate(c.mise_bas_prevue) : "—"}</td></tr>`).join("")}</tbody></table></div>` : ""}
    <div class="actions">
      ${a.est_admin ? (x.statut === "Présent" ? '<button class="btn ghost" data-action="supprimer">Supprimer</button>' : '<button class="btn ghost" data-action="retour">Remettre présent</button>') : ""}
      ${a.ecrit && x.statut === "Présent" ? '<button class="btn ghost" data-action="sortie">Vendu, mort, réformé…</button><button class="btn" data-action="peser">Peser</button>' : ""}
      ${a.ecrit && x.statut === "Présent" && x.sexe !== "Inconnu" ? '<button class="btn" data-action="accouplement">Accouplement</button>' : ""}
      ${a.ecrit && x.statut === "Présent" && x.sexe === "Femelle" ? '<button class="btn" data-action="naissance">Naissance</button>' : ""}
      ${a.ecrit ? '<button class="btn primary" data-action="modifier">Modifier la fiche</button>' : ""}
    </div></div>`, { taille: "large fe-fenetre" });
  fen.querySelectorAll("[data-animal]").forEach(l => l.addEventListener("click", ev => { ev.preventDefault(); fen.fermer(); ouvrirFicheAnimalFerme(Number(l.dataset.animal)); }));
  const action = (nom, fn) => { const b = fen.querySelector(`[data-action="${nom}"]`); if (b) b.addEventListener("click", () => { fen.fermer(); fn(); }); };
  action("modifier", () => formulaireAnimalFerme(x));
  action("peser", () => formulairePeseeAnimal(x));
  action("sortie", () => formulaireSortieAnimal(x));
  action("accouplement", () => formulaireAccouplementFerme(x.espece, x.sexe === "Femelle" ? x.id : null, x.sexe === "Mâle" ? x.id : null));
  action("naissance", () => formulaireNaissanceFerme({ espece: x.espece, mere_id: x.id }));
  action("supprimer", async () => {
    const mdp = await demanderMotDePasseAdmin(`Supprimer la fiche de ${x.libelle} ? Entrez votre mot de passe.`);
    if (!mdp) return;
    try { await api(`/api/ferme/animaux/${x.id}/supprimer`, { method: "POST", body: { mot_de_passe_admin: mdp } }); toast("Fiche supprimée"); chargerAnimauxFerme(); } catch (e) { toast(e.message, 7000); }
  });
  action("retour", async () => { try { await api(`/api/ferme/animaux/${x.id}/retour`, { method: "POST", body: {} }); toast("De nouveau présent"); chargerAnimauxFerme(); } catch (e) { toast(e.message, 7000); } });
}
window.addEventListener("load", () => { if (typeof FICHES !== "undefined") FICHES.animalferme = id => ouvrirFicheAnimalFerme(id); });

// Fiche technique d'un animal : le modèle de l'espèce propose races, cases propres et repères
async function formulaireAnimalFerme(x, prerempli = {}) {
  try { if (!animauxFerme) animauxFerme = await api("/api/ferme/animaux"); } catch (e) { toast(e.message); return; }
  const a = animauxFerme;
  let espece = x ? x.espece : prerempli.espece || null, sexe = x ? x.sexe : prerempli.sexe || "Inconnu";
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme(x ? x.dessin : "animal", "fe-fiche-img")}<div><h2>${x ? "Modifier la fiche" : "Nouvel animal"}</h2><p>Fiche technique : Gérimo propose le modèle de chaque espèce.</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <h4 class="fe-titre">1. Quelle espèce ?</h4>
    <div class="fe-choix-types fe-choix-especes">${a.especes.filter(e => e.actif || (x && e.nom === x.espece)).map(e => `<button type="button" class="fe-choix-type${e.nom === espece ? " choisi" : ""}" data-espece="${esc(e.nom)}">${imgFerme(e.dessin, "fe-choix-img")}<b>${esc(e.nom)}</b></button>`).join("")}</div>
    <div id="anSuite"></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer la fiche</button></div></div>`, { taille: "large fe-fenetre" });
  const suite = () => {
    const e = a.especes.find(z => z.nom === espece);
    if (!e) { fen.querySelector("#anSuite").innerHTML = '<p class="fe-aide">Choisissez d\'abord l\'espèce.</p>'; return; }
    const m = e.modele || {};
    const val = (k, defaut = "") => x ? (x[k] ?? defaut) : (prerempli[k] ?? defaut);
    const femelles = a.animaux.filter(z => z.espece === espece && z.sexe === "Femelle" && (!x || z.id !== x.id));
    const males = a.animaux.filter(z => z.espece === espece && z.sexe === "Mâle" && (!x || z.id !== x.id));
    const ageArr = val("age_arrivee", 0);
    fen.querySelector("#anSuite").innerHTML = `
      ${(m.reperes || []).length ? `<div class="fe-reperes"><b>Repères pour les ${esc(e.nom.toLowerCase())}</b>${m.reperes.map(r => `<span><small>${esc(r[0])}</small>${esc(r[1])}</span>`).join("")}</div>` : ""}
      <h4 class="fe-titre">2. Qui est-ce ?</h4>
      <div class="fgrid">
        <div class="field"><label for="anNumero">N° d'étiquette ou de boucle</label><input id="anNumero" maxlength="30" value="${esc(val("numero"))}" placeholder="ex : L-012"></div>
        <div class="field"><label for="anNom">Nom (facultatif)</label><input id="anNom" maxlength="60" value="${esc(val("nom"))}"></div>
        <div class="field"><label for="anRace">Race</label><input id="anRace" maxlength="60" list="anRaces" value="${esc(val("race"))}" placeholder="choisissez ou écrivez"><datalist id="anRaces">${(m.races || []).map(r => `<option value="${esc(r)}">`).join("")}</datalist></div>
        <div class="field"><label>Sexe</label><div class="fe-sexes">${["Mâle", "Femelle", "Inconnu"].map(s => `<button type="button" class="fe-sexe${s === sexe ? " choisi" : ""}" data-sexe="${s}">${s === "Mâle" ? "♂ Mâle" : s === "Femelle" ? "♀ Femelle" : "Je ne sais pas"}</button>`).join("")}</div></div>
        ${(m.champs || []).map((c, i) => `<div class="field"><label for="anChamp${i}">${esc(c.nom)}</label><input id="anChamp${i}" class="anChamp" data-nom="${esc(c.nom)}" list="anChoix${i}" maxlength="40" value="${esc((val("details", {}) || {})[c.nom] || "")}">
          <datalist id="anChoix${i}">${(c.choix || []).map(o => `<option value="${esc(o)}">`).join("")}</datalist></div>`).join("")}
      </div>
      <div class="field"><label for="anCarac">Caractéristiques particulières</label><input id="anCarac" maxlength="300" value="${esc(val("caracteristiques"))}" placeholder="ex : yeux bleus, oreilles tombantes">
        ${(m.caracteristiques || []).length ? `<div class="fe-exemples">${m.caracteristiques.map(c => `<button type="button" class="fe-exemple" data-carac="${esc(c)}">+ ${esc(c)}</button>`).join("")}</div>` : ""}</div>
      <h4 class="fe-titre">3. Son âge</h4>
      <div class="fgrid">
        <div class="field"><label for="anOrigine">Origine</label><select id="anOrigine">${["Acheté", "Né à la ferme", "Autre"].map(o => `<option${val("origine", "Acheté") === o ? " selected" : ""}>${o}</option>`).join("")}</select></div>
        <div class="field"><label for="anArrivee">Arrivé à la ferme le</label><input id="anArrivee" type="date"></div>
        <div class="field"><label for="anNaissance">Né le (si on le sait)</label><input id="anNaissance" type="date"></div>
        <div class="field"><label for="anAge">Sinon, âge à l'arrivée</label><div class="fe-quantite"><input id="anAge" inputmode="numeric" value="${ageArr >= 365 && ageArr % 365 === 0 ? ageArr / 365 : ageArr >= 30 && ageArr % 30 === 0 ? ageArr / 30 : ageArr || ""}" placeholder="0">
          <select id="anAgeUnite"><option value="1">jours</option><option value="30"${ageArr >= 30 && ageArr % 30 === 0 && !(ageArr >= 365 && ageArr % 365 === 0) ? " selected" : ""}>mois</option><option value="365"${ageArr >= 365 && ageArr % 365 === 0 ? " selected" : ""}>ans</option></select></div></div>
      </div>
      <h4 class="fe-titre">4. Ses parents et sa place</h4>
      <div class="fgrid">
        <div class="field"><label for="anMere">Mère</label><select id="anMere"><option value="">— inconnue ou sans fiche —</option>${femelles.map(f => `<option value="${f.id}"${val("mere_id") === f.id ? " selected" : ""}>${esc(f.libelle)}${f.race ? " · " + esc(f.race) : ""}</option>`).join("")}</select></div>
        <div class="field"><label for="anPere">Père</label><select id="anPere"><option value="">— inconnu ou sans fiche —</option>${males.map(f => `<option value="${f.id}"${val("pere_id") === f.id ? " selected" : ""}>${esc(f.libelle)}${f.race ? " · " + esc(f.race) : ""}</option>`).join("")}</select></div>
        <div class="field"><label for="anBatiment">Bâtiment</label><select id="anBatiment"><option value="">—</option>${a.batiments.map(b => `<option value="${b.id}"${val("poulailler_id") === b.id ? " selected" : ""}>${esc(b.nom)}</option>`).join("")}</select></div>
        <div class="field"><label for="anBande">Dans le lot (facultatif)</label><select id="anBande"><option value="">—</option>${a.bandes.filter(b => b.espece === espece).map(b => `<option value="${b.id}"${val("bande_id") === b.id ? " selected" : ""}>${esc(b.nom)} (${esc(b.batiment)})</option>`).join("")}</select></div>
        <div class="field"><label for="anSante">État de santé</label><select id="anSante">${a.santes.map(s => `<option${val("etat_sante", "Bonne santé") === s ? " selected" : ""}>${s}</option>`).join("")}</select></div>
      </div>
      <label class="case"><input type="checkbox" id="anRepro"${val("reproducteur", false) ? " checked" : ""}> Reproducteur (gardé pour les accouplements)</label>
      <div class="field"><label for="anNote">Note (facultatif)</label><input id="anNote" maxlength="300" value="${esc(val("note"))}"></div>`;
    initialiserChampsDate(fen.querySelector("#anSuite"));
    fen.querySelector("#anArrivee").value = formatDate(val("date_arrivee") || aujourdhui());
    if (val("date_naissance")) fen.querySelector("#anNaissance").value = formatDate(val("date_naissance"));
    fen.querySelectorAll(".fe-exemple").forEach(b => b.addEventListener("click", () => {
      const c = fen.querySelector("#anCarac"), mots = c.value.split(",").map(x => x.trim()).filter(Boolean);
      if (!mots.includes(b.dataset.carac)) mots.push(b.dataset.carac);
      c.value = mots.join(", ").slice(0, 300);
    }));
    fen.querySelector(".fe-sexes").addEventListener("click", ev => {
      const b = ev.target.closest("[data-sexe]"); if (!b) return;
      sexe = b.dataset.sexe;
      fen.querySelectorAll(".fe-sexe").forEach(y => y.classList.toggle("choisi", y === b));
    });
  };
  suite();
  fen.querySelector(".fe-choix-especes").addEventListener("click", ev => {
    const b = ev.target.closest("[data-espece]"); if (!b) return;
    espece = b.dataset.espece;
    fen.querySelectorAll(".fe-choix-especes .fe-choix-type").forEach(y => y.classList.toggle("choisi", y === b));
    suite();
  });
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      if (!espece) throw new Error("Choisissez d'abord l'espèce (étape 1).");
      const q = id => fen.querySelector(id);
      const arrivee = isoDepuisTexte(q("#anArrivee").value);
      if (!arrivee) throw new Error("Date d'arrivée incorrecte : écrivez-la comme 02/12/2026.");
      const naissance = q("#anNaissance").value.trim() ? isoDepuisTexte(q("#anNaissance").value) : null;
      if (q("#anNaissance").value.trim() && !naissance) throw new Error("Date de naissance incorrecte.");
      const age = q("#anAge").value.trim() ? lireEntierFerme(q("#anAge").value) : 0;
      if (age === null) throw new Error("L'âge à l'arrivée doit être un nombre.");
      const details = {};
      fen.querySelectorAll(".anChamp").forEach(c => { if (c.value.trim()) details[c.dataset.nom] = c.value.trim(); });
      const num = sel => q(sel).value ? Number(q(sel).value) : null;
      ok.disabled = true;
      const r = await api(x ? `/api/ferme/animaux/${x.id}` : "/api/ferme/animaux", { method: x ? "PUT" : "POST", body: {
        espece, numero: q("#anNumero").value.trim() || null, nom: q("#anNom").value.trim() || null, race: q("#anRace").value.trim() || null,
        sexe, date_arrivee: arrivee, date_naissance: naissance, age_arrivee: age * Number(q("#anAgeUnite").value), origine: q("#anOrigine").value,
        mere_id: num("#anMere"), pere_id: num("#anPere"), poulailler_id: num("#anBatiment"), bande_id: num("#anBande"),
        etat_sante: q("#anSante").value, reproducteur: q("#anRepro").checked, details, caracteristiques: q("#anCarac").value.trim() || null,
        note: q("#anNote").value.trim() || null } });
      fen.fermer();
      toast(`Fiche enregistrée : ${r.libelle}, ${r.age_texte}`);
      animauxFerme = null;
      montrerOngletFerme(ongletFerme);
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

function formulairePeseeAnimal(x) {
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme(x.dessin, "fe-fiche-img")}<div><h2>Peser ${esc(x.libelle)}</h2><p>${esc(x.age_texte)}${x.poids_kg ? ` · dernier poids ${nbFerme(x.poids_kg)} kg` : ""}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid"><div class="field"><label for="paPoids">Poids (kg)</label><input id="paPoids" inputmode="decimal" placeholder="ex : 3,8"></div>
      <div class="field"><label for="paDate">Date</label><input id="paDate" type="date"></div></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#paDate").value = formatDate(aujourdhui());
  fen.querySelector('[data-action="ok"]').addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const p = lireNombreFerme(fen.querySelector("#paPoids").value);
      if (!p) throw new Error("Indiquez le poids en kg.");
      await api(`/api/ferme/animaux/${x.id}/pesees`, { method: "POST", body: { poids_kg: p, date_pesee: isoDepuisTexte(fen.querySelector("#paDate").value) } });
      fen.fermer(); toast("Pesée notée"); ouvrirFicheAnimalFerme(x.id);
    } catch (e) { erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

function formulaireSortieAnimal(x) {
  let statut = "Vendu";
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme(x.dessin, "fe-fiche-img")}<div><h2>${esc(x.libelle)} quitte la ferme</h2><p>Sa fiche reste consultable.</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fe-choix-types fe-choix-genres">${["Vendu", "Mort", "Réformé"].map(s => `<button type="button" class="fe-choix-type${s === statut ? " choisi" : ""}" data-statut="${s}">${s === "Mort" ? imgMarque(x.dessin, "mort", "fe-choix-img") : ""}<b>${s}</b></button>`).join("")}</div>
    <div class="fgrid" style="margin-top:1rem"><div class="field"><label for="srCause" id="srLib">Précision (facultatif)</label><input id="srCause" maxlength="100" placeholder="ex : vendu au marché, maladie…"></div>
      <div class="field"><label for="srDate">Date</label><input id="srDate" type="date"></div></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#srDate").value = formatDate(aujourdhui());
  fen.querySelector(".fe-choix-genres").addEventListener("click", ev => {
    const b = ev.target.closest("[data-statut]"); if (!b) return;
    statut = b.dataset.statut;
    fen.querySelectorAll(".fe-choix-genres .fe-choix-type").forEach(y => y.classList.toggle("choisi", y === b));
    fen.querySelector("#srLib").textContent = statut === "Mort" ? "De quoi est-il mort ?" : "Précision (facultatif)";
  });
  fen.querySelector('[data-action="ok"]').addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      await api(`/api/ferme/animaux/${x.id}/sortie`, { method: "POST", body: { statut, cause: fen.querySelector("#srCause").value.trim() || null,
        date_sortie: isoDepuisTexte(fen.querySelector("#srDate").value) } });
      fen.fermer(); toast("C'est noté"); chargerAnimauxFerme();
    } catch (e) { erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

// ---------- Reproduction : accouplements et naissances ----------

async function chargerReproFerme() {
  const zone = el("zoneReproFerme");
  try { reproFerme = await api("/api/ferme/reproduction"); } catch (e) { erreurFerme(zone, e); return; }
  const r = reproFerme;
  const enAttente = r.accouplements.filter(a => a.resultat === "En attente" && !a.naissance_id);
  const dans30 = new Date(); dans30.setDate(dans30.getDate() + 30);
  const prochaines = r.accouplements.filter(a => !a.naissance_id && a.resultat !== "Non réussi" && a.mise_bas_prevue && a.mise_bas_prevue <= dans30.toISOString().slice(0, 10));
  const unAn = new Date(); unAn.setFullYear(unAn.getFullYear() - 1);
  const recentes = r.naissances.filter(n => n.date >= unAn.toISOString().slice(0, 10));
  // dessin de l'espèce la plus suivie en reproduction
  const compte = {};
  [...r.accouplements, ...r.naissances].forEach(x => { compte[x.espece] = (compte[x.espece] || 0) + 1; });
  const principale = Object.keys(compte).sort((x, y) => compte[y] - compte[x])[0];
  const dessin = ((r.especes.find(e => e.nom === principale) || r.especes[0]) || {}).dessin || "animal";
  zone.innerHTML = `
    <div class="fe-chiffres">
      <div class="fe-chiffre jaune">${imgMarque(dessin, "coeur", "fe-chiffre-img")}<span><b>${enAttente.length}</b><span class="fe-chiffre-libelle">Accouplements en attente</span><small>résultat à noter</small></span></div>
      <div class="fe-chiffre creme">${imgMarque(dessin, "naissance", "fe-chiffre-img")}<span><b>${prochaines.length}</b><span class="fe-chiffre-libelle">Mises bas prévues</span><small>dans les 30 jours (ou en retard)</small></span></div>
      <div class="fe-chiffre vert">${imgFerme(dessin, "fe-chiffre-img")}<span><b>${recentes.reduce((t, n) => t + n.nes_vivants, 0)}</b><span class="fe-chiffre-libelle">Petits nés vivants</span><small>en ${plurielFerme(recentes.length, "portée")}, sur 12 mois</small></span></div>
    </div>
    ${r.ecrit ? `<div class="fe-barre"><div class="fe-boutons"><button class="btn" onclick="formulaireAccouplementFerme()">+ Accouplement</button><button class="btn primary" onclick="formulaireNaissanceFerme({})">+ Naissance</button></div></div>` : ""}
    <div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">Accouplements</h3>
      ${r.accouplements.length ? `<div class="fe-tableau"><table><thead><tr><th>Femelle</th><th>Mâle</th><th>Date</th><th>Résultat</th><th>Contrôle</th><th>Mise bas prévue</th><th></th></tr></thead><tbody>
        ${r.accouplements.map(a => `<tr>
          <td data-titre="Femelle"><span class="fe-bande">${imgType(a.espece)}<span><b>${esc(a.femelle) || "—"}</b><small>${esc(a.espece)} · ${esc(a.methode)}</small></span></span></td>
          <td data-titre="Mâle">${esc(a.male) || "—"}</td><td data-titre="Date">${formatDate(a.date)}</td>
          <td data-titre="Résultat">${a.naissance_id ? '<span class="fe-pastille vert">Naissance notée</span>' : pastilleFerme(RESULTAT_ACC[a.resultat])}</td>
          <td data-titre="Contrôle">${a.controle_prevu ? formatDate(a.controle_prevu) : "—"}</td>
          <td data-titre="Mise bas prévue">${a.mise_bas_prevue ? `<b>${formatDate(a.mise_bas_prevue)}</b>` : "—"}</td>
          <td>${r.ecrit && !a.naissance_id ? `<div class="fe-boutons">${a.resultat === "En attente" ? `<button class="btn" onclick="resultatAccouplementFerme(${a.id}, 'Réussi')">Réussi</button><button class="btn ghost" onclick="resultatAccouplementFerme(${a.id}, 'Non réussi')">Non réussi</button>` : ""}
            ${a.resultat !== "Non réussi" ? `<button class="btn primary" onclick="formulaireNaissanceFerme({accouplement: reproFerme.accouplements.find(x => x.id === ${a.id})})">Naissance</button>` : ""}</div>` : ""}</td></tr>`).join("")}
      </tbody></table></div>` : '<p class="fe-aide">Aucun accouplement noté.</p>'}
    </div>
    <div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">Naissances</h3>
      ${r.naissances.length ? `<div class="fe-tableau"><table><thead><tr><th>Date</th><th>Mère</th><th>Père</th><th class="nb">Nés vivants</th><th class="nb">Morts-nés</th><th>♂ / ♀</th><th>Petits</th><th>Santé</th></tr></thead><tbody>
        ${r.naissances.map(n => `<tr${r.est_admin ? ` class="fe-ligne" onclick="supprimerNaissanceFerme(${n.id})" data-tip="Cliquez pour supprimer cette naissance"` : ""}>
          <td data-titre="Date"><span class="fe-bande">${imgType(n.espece)}<span><b>${formatDate(n.date)}</b><small>${esc(n.espece)} · ${esc(n.numero)}</small></span></span></td>
          <td data-titre="Mère">${esc(n.mere) || "—"}</td><td data-titre="Père">${esc(n.pere) || "—"}</td>
          <td data-titre="Nés vivants" class="nb"><b class="fe-vert">${n.nes_vivants}</b></td><td data-titre="Morts-nés" class="nb">${n.morts_nes ? `<span class="fe-rouge">${n.morts_nes}</span>` : 0}</td>
          <td data-titre="♂ / ♀">${n.males} ♂ · ${n.femelles} ♀</td><td data-titre="Petits">${n.destination === "Fiches" ? "une fiche chacun" : "bande " + esc(n.bande)}</td>
          <td data-titre="Santé">${esc(n.etat_sante) || "—"}</td></tr>`).join("")}
      </tbody></table></div>` : '<p class="fe-aide">Aucune naissance notée.</p>'}
    </div>`;
}

async function resultatAccouplementFerme(id, resultat) {
  try { await api(`/api/ferme/accouplements/${id}/resultat`, { method: "POST", body: { resultat } }); toast(resultat === "Réussi" ? "Elle est pleine : Gérimo vous rappellera la mise bas" : "C'est noté"); chargerReproFerme(); }
  catch (e) { toast(e.message, 7000); }
}

async function supprimerNaissanceFerme(id) {
  const n = reproFerme.naissances.find(x => x.id === id);
  const mdp = await demanderMotDePasseAdmin(`Supprimer la naissance du ${n ? formatDate(n.date) : ""} ? Les fiches des petits seront aussi supprimées. Entrez votre mot de passe.`);
  if (!mdp) return;
  try { await api(`/api/ferme/naissances/${id}/supprimer`, { method: "POST", body: { mot_de_passe_admin: mdp } }); toast("Naissance supprimée"); chargerReproFerme(); } catch (e) { toast(e.message, 7000); }
}

async function formulaireAccouplementFerme(especeDepart = null, femelleId = null, maleId = null) {
  try { if (!reproFerme) reproFerme = await api("/api/ferme/reproduction"); } catch (e) { toast(e.message); return; }
  const r = reproFerme;
  if (!r.especes.length) { toast("Aucune espèce avec naissances : cochez « naissances » dans Bâtiments et animaux."); return; }
  let espece = especeDepart || r.especes[0].nom;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgMarque((r.especes.find(z => z.nom === espece) || {}).dessin, "coeur", "fe-fiche-img")}<div><h2>Noter un accouplement</h2><p>Gérimo prévoit la date de contrôle et la date de mise bas.</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fe-choix-types fe-choix-especes">${r.especes.map(e => `<button type="button" class="fe-choix-type${e.nom === espece ? " choisi" : ""}" data-espece="${esc(e.nom)}">${imgFerme(e.dessin, "fe-choix-img")}<b>${esc(e.nom)}</b></button>`).join("")}</div>
    <div id="acSuite"></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "large fe-fenetre" });
  const suite = () => {
    const e = r.especes.find(z => z.nom === espece);
    const f = r.animaux.filter(z => z.espece === espece && z.sexe === "Femelle"), m = r.animaux.filter(z => z.espece === espece && z.sexe === "Mâle");
    fen.querySelector("#acSuite").innerHTML = `<div class="fgrid" style="margin-top:1rem">
      <div class="field"><label for="acFemelle">Femelle</label><select id="acFemelle"><option value="">— pas de fiche (décrire) —</option>${f.map(z => `<option value="${z.id}"${z.id === femelleId ? " selected" : ""}>${esc(z.libelle)}${z.race ? " · " + esc(z.race) : ""} · ${esc(z.age_texte)}</option>`).join("")}</select>
        <input id="acFemelleTexte" maxlength="80" placeholder="ex : lapine grise du clapier B" style="margin-top:.4rem"></div>
      <div class="field"><label for="acMale">Mâle</label><select id="acMale"><option value="">— pas de fiche (décrire) —</option>${m.map(z => `<option value="${z.id}"${z.id === maleId ? " selected" : ""}>${esc(z.libelle)}${z.race ? " · " + esc(z.race) : ""} · ${esc(z.age_texte)}</option>`).join("")}</select>
        <input id="acMaleTexte" maxlength="80" placeholder="ex : verrat du voisin" style="margin-top:.4rem"></div>
      <div class="field"><label for="acDateA">Date</label><input id="acDateA" type="date"></div>
      <div class="field"><label for="acMethode">Comment</label><select id="acMethode"><option>Naturelle</option><option>Insémination</option></select></div>
    </div>
    <div class="fe-fiche-grand vert"><b id="acPrevu">—</b><span>${e.gestation_jours ? `gestation des ${esc(espece.toLowerCase())} : ${e.gestation_jours} jours${e.controle_jours ? ` · contrôle ${e.controle_jours} jours après` : ""}` : "durée de gestation non indiquée pour cette espèce"}</span></div>
    <div class="field"><label for="acNote">Note (facultatif)</label><input id="acNote" maxlength="300"></div>`;
    initialiserChampsDate(fen.querySelector("#acSuite"));
    fen.querySelector("#acDateA").value = formatDate(aujourdhui());
    const maj = () => {
      const d = isoDepuisTexte(fen.querySelector("#acDateA").value);
      fen.querySelector("#acFemelleTexte").style.display = fen.querySelector("#acFemelle").value ? "none" : "";
      fen.querySelector("#acMaleTexte").style.display = fen.querySelector("#acMale").value ? "none" : "";
      if (!d || !e.gestation_jours) { fen.querySelector("#acPrevu").textContent = "—"; return; }
      const mb = new Date(d + "T00:00"); mb.setDate(mb.getDate() + e.gestation_jours);
      fen.querySelector("#acPrevu").textContent = `Mise bas prévue vers le ${mb.toLocaleDateString("fr-FR")}`;
    };
    ["#acDateA", "#acFemelle", "#acMale"].forEach(s => { fen.querySelector(s).addEventListener("change", maj); fen.querySelector(s).addEventListener("input", maj); });
    maj();
  };
  suite();
  fen.querySelector(".fe-choix-especes").addEventListener("click", ev => {
    const b = ev.target.closest("[data-espece]"); if (!b) return;
    espece = b.dataset.espece; femelleId = maleId = null;
    fen.querySelectorAll(".fe-choix-especes .fe-choix-type").forEach(y => y.classList.toggle("choisi", y === b));
    suite();
  });
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const q = s => fen.querySelector(s);
      const date = isoDepuisTexte(q("#acDateA").value);
      if (!date) throw new Error("Date incorrecte : écrivez-la comme 02/12/2026.");
      ok.disabled = true;
      const a = await api("/api/ferme/accouplements", { method: "POST", body: { espece, date_accouplement: date, methode: q("#acMethode").value,
        femelle_id: q("#acFemelle").value ? Number(q("#acFemelle").value) : null, femelle_texte: q("#acFemelleTexte").value.trim() || null,
        male_id: q("#acMale").value ? Number(q("#acMale").value) : null, male_texte: q("#acMaleTexte").value.trim() || null, note: q("#acNote").value.trim() || null } });
      fen.fermer();
      toast(a.mise_bas_prevue ? `Accouplement noté : mise bas prévue le ${formatDate(a.mise_bas_prevue)}` : "Accouplement noté", 5000);
      reproFerme = null;
      montrerOngletFerme(ongletFerme);
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

async function formulaireNaissanceFerme({ accouplement = null, espece = null, mere_id = null } = {}) {
  try { reproFerme = await api("/api/ferme/reproduction"); } catch (e) { toast(e.message); return; }
  const r = reproFerme;
  espece = accouplement ? accouplement.espece : espece || (r.especes[0] || {}).nom;
  if (!espece) { toast("Aucune espèce avec naissances."); return; }
  let destination = "Fiches";
  const e = r.especes.find(z => z.nom === espece) || {};
  const races = ((e.modele || {}).races || []);
  const f = r.animaux.filter(z => z.espece === espece && z.sexe === "Femelle"), m = r.animaux.filter(z => z.espece === espece && z.sexe === "Mâle");
  const mere = accouplement ? accouplement.femelle_id : mere_id, pere = accouplement ? accouplement.male_id : null;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgType(espece, "fe-fiche-img")}<div><h2>Noter une naissance</h2><p>${esc(espece)}${accouplement ? ` · accouplement du ${formatDate(accouplement.date)}` : ""}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field"><label for="naMere">Mère</label><select id="naMere"${accouplement ? " disabled" : ""}><option value="">— sans fiche —</option>${f.map(z => `<option value="${z.id}"${z.id === mere ? " selected" : ""}>${esc(z.libelle)}</option>`).join("")}</select></div>
      <div class="field"><label for="naPere">Père</label><select id="naPere"${accouplement ? " disabled" : ""}><option value="">— inconnu ou sans fiche —</option>${m.map(z => `<option value="${z.id}"${z.id === pere ? " selected" : ""}>${esc(z.libelle)}</option>`).join("")}</select></div>
      <div class="field"><label for="naDate">Née le</label><input id="naDate" type="date"></div>
      <div class="field"><label for="naMortsNes">Morts-nés</label><input id="naMortsNes" inputmode="numeric" placeholder="0"></div>
      <div class="field"><label for="naRace">Race des petits</label><input id="naRace" list="naRaces" maxlength="60" placeholder="celle de la mère si vide"><datalist id="naRaces">${races.map(x => `<option value="${esc(x)}">`).join("")}</datalist></div>
      <div class="field"><label for="naSante">État de santé des petits</label><select id="naSante"><option>Bon</option><option>Faible</option><option>Malade</option></select></div>
    </div>
    <h4 class="fe-titre">Les petits</h4>
    <div class="fe-choix-types fe-choix-genres"><button type="button" class="fe-choix-type choisi" data-dest="Fiches"><b>Une fiche pour chaque petit</b><small>sexe, n°, poids, parents notés tout seuls</small></button>
      <button type="button" class="fe-choix-type" data-dest="Bande"><b>Les compter dans un lot</b><small>seulement les nombres</small></button></div>
    <div id="naPetits" style="margin-top:1rem"></div>
    <div class="field"><label for="naNote">Note (facultatif)</label><input id="naNote" maxlength="300"></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer la naissance</button></div></div>`, { taille: "large fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#naDate").value = formatDate(aujourdhui());
  const lignePetit = i => `<tr><td>${i + 1}</td><td><select class="ptSexe"><option>Inconnu</option><option>Mâle</option><option>Femelle</option></select></td>
    <td><input class="ptNumero" maxlength="30" placeholder="facultatif"></td><td><input class="ptPoids" inputmode="decimal" placeholder="g"></td></tr>`;
  const petits = () => {
    const z = fen.querySelector("#naPetits");
    if (destination === "Fiches") {
      z.innerHTML = `<div class="field" style="max-width:260px"><label for="naNombre">Nombre de petits nés vivants</label><input id="naNombre" inputmode="numeric" value="1"></div>
        <div class="fe-tableau fe-saisie fe-fond-blanc"><table><thead><tr><th>#</th><th>Sexe</th><th>N° d'étiquette</th><th>Poids (g)</th></tr></thead><tbody id="naLignes">${lignePetit(0)}</tbody></table></div>`;
      z.querySelector("#naNombre").addEventListener("input", () => {
        const n = Math.min(lireEntierFerme(z.querySelector("#naNombre").value) || 0, 60), corps = z.querySelector("#naLignes");
        while (corps.children.length < n) corps.insertAdjacentHTML("beforeend", lignePetit(corps.children.length));
        while (corps.children.length > n) corps.lastElementChild.remove();
      });
    } else {
      const bandes = r.bandes.filter(b => b.espece === espece);
      z.innerHTML = bandes.length ? `<div class="fgrid">
        <div class="field"><label for="naBande">Lot</label><select id="naBande">${bandes.map(b => `<option value="${b.id}">${esc(b.nom)} (${esc(b.batiment)})</option>`).join("")}</select></div>
        <div class="field"><label for="naVivants">Nés vivants</label><input id="naVivants" inputmode="numeric"></div>
        <div class="field"><label for="naMales">Dont mâles</label><input id="naMales" inputmode="numeric" placeholder="0"></div>
        <div class="field"><label for="naFemelles">Dont femelles</label><input id="naFemelles" inputmode="numeric" placeholder="0"></div></div>`
        : `<p class="fe-aide">Aucun lot de ${esc(espece.toLowerCase())} en cours : créez-en une, ou choisissez « une fiche pour chaque petit ».</p>`;
    }
  };
  petits();
  fen.querySelector(".fe-choix-genres").addEventListener("click", ev => {
    const b = ev.target.closest("[data-dest]"); if (!b) return;
    destination = b.dataset.dest;
    fen.querySelectorAll(".fe-choix-genres .fe-choix-type").forEach(y => y.classList.toggle("choisi", y === b));
    petits();
  });
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const q = s => fen.querySelector(s);
      const date = isoDepuisTexte(q("#naDate").value);
      if (!date) throw new Error("Date incorrecte : écrivez-la comme 02/12/2026.");
      const ent = (s, quoi) => { const c = q(s); if (!c || !c.value.trim()) return 0; const n = lireEntierFerme(c.value); if (n === null) throw new Error(`Le nombre de ${quoi} est incorrect.`); return n; };
      const corps = { espece, date_naissance: date, accouplement_id: accouplement ? accouplement.id : null,
                      mere_id: q("#naMere").value ? Number(q("#naMere").value) : null, pere_id: q("#naPere").value ? Number(q("#naPere").value) : null,
                      morts_nes: ent("#naMortsNes", "morts-nés"), race: q("#naRace").value.trim() || null, etat_sante: q("#naSante").value, destination,
                      note: q("#naNote").value.trim() || null };
      if (destination === "Fiches") {
        corps.petits = [...fen.querySelectorAll("#naLignes tr")].map(tr => {
          const p = tr.querySelector(".ptPoids").value.trim() ? lireNombreFerme(tr.querySelector(".ptPoids").value) : null;
          if (tr.querySelector(".ptPoids").value.trim() && !p) throw new Error("Un poids est incorrect.");
          return { sexe: tr.querySelector(".ptSexe").value, numero: tr.querySelector(".ptNumero").value.trim() || null, poids_g: p };
        });
      } else {
        if (!q("#naBande")) throw new Error("Aucun lot pour compter les petits.");
        Object.assign(corps, { bande_id: Number(q("#naBande").value), nes_vivants: ent("#naVivants", "petits"), males: ent("#naMales", "mâles"), femelles: ent("#naFemelles", "femelles") });
      }
      ok.disabled = true;
      const n = await api("/api/ferme/naissances", { method: "POST", body: corps });
      fen.fermer();
      toast(`Naissance notée : ${plurielFerme(n.nes_vivants, "petit")} vivant${n.nes_vivants > 1 ? "s" : ""} 🎉`, 5000);
      reproFerme = null; animauxFerme = null;
      montrerOngletFerme(ongletFerme);
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

// ---------- Statistiques par espèce ----------

async function chargerStatsFerme() {
  const zone = el("zoneStatsFerme");
  if (!tableauFerme) { try { await chargerTableauFerme(); } catch (e) { erreurFerme(zone, e); return; } }
  const especes = tableauFerme.especes.filter(e => e.actif);
  const presentes = especes.filter(e => tableauFerme.bandes.some(b => b.type === e.nom));
  if (!especeStats) especeStats = (presentes[0] || especes[0] || {}).nom;
  let s;
  try { s = await api(`/api/ferme/reproduction/statistiques?espece=${encodeURIComponent(especeStats)}`); } catch (e) { erreurFerme(zone, e); return; }
  const pc = v => v === null || v === undefined ? "—" : `${String(v).replace(".", ",")} %`;
  const tot = s.effectif.total;
  zone.innerHTML = `
    <div class="fe-barre fe-barre-stock"><div class="fe-types-suivi">${especes.map(e => `<label class="fe-case-type${e.nom === especeStats ? " coche" : ""}" onclick="especeStats = '${esc(e.nom).replace(/'/g, "\\'")}'; chargerStatsFerme()">${imgFerme(e.dessin, "fe-case-img")}<span>${esc(e.nom)}</span></label>`).join("")}</div></div>
    <div class="fe-banniere">${imgFerme(s.dessin, "fe-banniere-img")}<div><h3>${esc(s.espece)} : ${plurielFerme(tot, "animal", "animaux")}</h3>
      <p>${plurielFerme(s.effectif.fiches, "avec fiche", "avec fiche")} · ${nbFerme(s.effectif.bandes)} dans les lots · chiffres des 12 derniers mois</p></div></div>
    <div class="fe-chiffres">
      <div class="fe-chiffre bleu">${imgMarque(s.dessin, "male", "fe-chiffre-img")}<span><b>${s.sexes["Mâle"] + s.sexes_bandes["Mâle"]}</b><span class="fe-chiffre-libelle">Mâles</span><small>${s.sexes["Mâle"]} avec fiche + ${s.sexes_bandes["Mâle"]} en lot</small></span></div>
      <div class="fe-chiffre rose">${imgMarque(s.dessin, "femelle", "fe-chiffre-img")}<span><b>${s.sexes["Femelle"] + s.sexes_bandes["Femelle"]}</b><span class="fe-chiffre-libelle">Femelles</span><small>${s.sexes["Femelle"]} avec fiche + ${s.sexes_bandes["Femelle"]} en lot</small></span></div>
      <div class="fe-chiffre ${s.mortalite.taux > 5 ? "rouge" : "vert"}">${imgMarque(s.dessin, "mort", "fe-chiffre-img")}<span><b>${pc(s.mortalite.taux)}</b><span class="fe-chiffre-libelle">Mortalité</span><small>${plurielFerme(s.mortalite.morts, "mort")}</small></span></div>
      ${s.naissances_possibles ? `
      <div class="fe-chiffre vert">${imgMarque(s.dessin, "naissance", "fe-chiffre-img")}<span><b>${s.natalite.par_portee ?? "—"}</b><span class="fe-chiffre-libelle">Petits par portée</span><small>${plurielFerme(s.natalite.portees, "portée")} · ${pc(s.natalite.taux_morts_nes)} morts-nés</small></span></div>
      <div class="fe-chiffre creme">${imgMarque(s.dessin, "coeur", "fe-chiffre-img")}<span><b>${pc(s.accouplements.taux_reussite)}</b><span class="fe-chiffre-libelle">Accouplements réussis</span><small>${s.accouplements.reussis} réussis · ${s.accouplements.rates} non réussis</small></span></div>
      <div class="fe-chiffre jaune">${imgFerme(s.dessin, "fe-chiffre-img")}<span><b>${pc(s.survie.taux)}</b><span class="fe-chiffre-libelle">Survie jusqu'au sevrage</span><small>${s.survie.sevrage_jours ? `${s.survie.sevres} sur ${s.survie.petits} petits avec fiche` : "durée de sevrage non indiquée"}</small></span></div>` : ""}
    </div>
    <div class="fe-fiche-colonnes">
      <div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">Par âge et par sexe (animaux avec fiche)</h3>
        ${s.par_age.length ? `<div class="fe-tableau"><table><thead><tr><th>Âge</th><th class="nb">Total</th><th class="nb">♂</th><th class="nb">♀</th><th class="nb">Poids moyen</th></tr></thead><tbody>
          ${s.par_age.map(x => `<tr><td data-titre="Âge"><b>${esc(x.classe)}</b></td><td data-titre="Total" class="nb">${x.total}</td><td data-titre="♂" class="nb">${x.males}</td><td data-titre="♀" class="nb">${x.femelles}</td>
            <td data-titre="Poids moyen" class="nb">${x.poids_moyen ? `${nbFerme(x.poids_moyen)} kg${x.poids_males || x.poids_femelles ? `<br><small class="fe-aide">♂ ${x.poids_males ? nbFerme(x.poids_males) + " kg" : "—"} · ♀ ${x.poids_femelles ? nbFerme(x.poids_femelles) + " kg" : "—"}</small>` : ""}` : "—"}</td></tr>`).join("")}
        </tbody></table></div>` : '<p class="fe-aide">Pas encore de fiches pour cette espèce.</p>'}</div>
      <div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">Races : les plus résistantes d'abord</h3>
        ${s.races.length ? `<div class="fe-tableau"><table><thead><tr><th>Race</th><th class="nb">Animaux</th><th class="nb">Morts</th><th class="nb">Mortalité</th></tr></thead><tbody>
          ${s.races.map((x, i) => `<tr><td data-titre="Race"><b>${esc(x.race)}</b>${i === 0 && !x.peu ? ' <span class="fe-pastille vert">la plus résistante</span>' : ""}${x.peu ? ' <small class="fe-aide">(peu d\'animaux)</small>' : ""}</td>
            <td data-titre="Animaux" class="nb">${nbFerme(x.animaux)}</td><td data-titre="Morts" class="nb">${x.morts}</td><td data-titre="Mortalité" class="nb">${pc(x.mortalite)}</td></tr>`).join("")}
        </tbody></table></div>` : '<p class="fe-aide">Indiquez la race des lots et des fiches pour comparer.</p>'}</div>
    </div>
    ${s.naissances_possibles && s.meres.length ? `<div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">Meilleures mères</h3><div class="fe-tableau"><table><thead><tr><th>Mère</th><th class="nb">Portées</th><th class="nb">Nés vivants</th><th class="nb">Par portée</th><th class="nb">Survie</th></tr></thead><tbody>
      ${s.meres.map(x => `<tr><td data-titre="Mère"><b>${esc(x.mere)}</b></td><td data-titre="Portées" class="nb">${x.portees}</td><td data-titre="Nés vivants" class="nb">${x.nes}</td><td data-titre="Par portée" class="nb">${x.par_portee ?? "—"}</td><td data-titre="Survie" class="nb">${pc(x.survie)}</td></tr>`).join("")}
    </tbody></table></div></div>` : ""}`;
}

// ---------- Modèle de fiche d'une espèce (Admin) ----------

function formulaireModeleFerme(espece) {
  const e = tableauFerme.especes.find(x => x.id === espece.id) || espece;
  const m = e.modele || {};
  const ligneChamp = (c = {}) => `<tr class="mdChamp"><td><input class="mdNom" maxlength="40" value="${esc(c.nom || "")}" placeholder="ex : Robe"></td>
    <td><input class="mdChoix" value="${esc((c.choix || []).join(", "))}" placeholder="Noire, Blanche, Rousse"></td><td><button type="button" class="ibtn del" aria-label="Retirer" onclick="this.closest('tr').remove()">✕</button></td></tr>`;
  const ligneRepere = (r = ["", ""]) => `<tr class="mdRepere"><td><input class="mdLib" maxlength="60" value="${esc(r[0])}" placeholder="ex : Gestation"></td>
    <td><input class="mdVal" maxlength="120" value="${esc(r[1])}" placeholder="ex : 31 jours"></td><td><button type="button" class="ibtn del" aria-label="Retirer" onclick="this.closest('tr').remove()">✕</button></td></tr>`;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme(e.dessin, "fe-fiche-img")}<div><h2>Modèle de fiche : ${esc(e.nom)}</h2><p>Ce que Gérimo propose quand on crée une fiche de cette espèce. Valeurs indicatives, à adapter.</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field"><label for="mdGestation">Gestation (jours)</label><input id="mdGestation" inputmode="numeric" value="${e.gestation_jours || ""}"></div>
      <div class="field"><label for="mdControle">Contrôle de gestation (jours après)</label><input id="mdControle" inputmode="numeric" value="${e.controle_jours || ""}"></div>
      <div class="field"><label for="mdSevrage">Sevrage (jours)</label><input id="mdSevrage" inputmode="numeric" value="${e.sevrage_jours || ""}"></div>
    </div>
    <div class="field"><label for="mdRaces">Races proposées (une par ligne)</label><textarea id="mdRaces" rows="4">${esc((m.races || []).join("\n"))}</textarea></div>
    <div class="field"><label for="mdCarac">Exemples de caractéristiques particulières (séparés par des virgules)</label><input id="mdCarac" value="${esc((m.caracteristiques || []).join(", "))}" placeholder="Yeux bleus, Oreilles tombantes"></div>
    <h4 class="fe-titre">Cases propres à l'espèce</h4>
    <div class="fe-tableau fe-saisie fe-fond-blanc"><table><thead><tr><th>Case</th><th>Choix proposés (séparés par des virgules)</th><th></th></tr></thead><tbody id="mdChamps">${(m.champs || []).map(ligneChamp).join("")}</tbody></table></div>
    <button type="button" class="btn ghost" id="mdAjoutChamp" style="margin-top:.5rem">+ Une case</button>
    <h4 class="fe-titre">Repères</h4>
    <div class="fe-tableau fe-saisie fe-fond-blanc"><table><thead><tr><th>Repère</th><th>Valeur</th><th></th></tr></thead><tbody id="mdReperes">${(m.reperes || []).map(ligneRepere).join("")}</tbody></table></div>
    <button type="button" class="btn ghost" id="mdAjoutRepere" style="margin-top:.5rem">+ Un repère</button>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer le modèle</button></div></div>`, { taille: "large fe-fenetre" });
  fen.querySelector("#mdAjoutChamp").addEventListener("click", () => fen.querySelector("#mdChamps").insertAdjacentHTML("beforeend", ligneChamp()));
  fen.querySelector("#mdAjoutRepere").addEventListener("click", () => fen.querySelector("#mdReperes").insertAdjacentHTML("beforeend", ligneRepere()));
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const jours = s => { const v = fen.querySelector(s).value.trim(); if (!v) return null; const n = lireEntierFerme(v); if (!n) throw new Error("Les durées sont des nombres de jours."); return n; };
      ok.disabled = true;
      await api(`/api/ferme/especes/${e.id}/modele`, { method: "PUT", body: {
        gestation_jours: jours("#mdGestation"), controle_jours: jours("#mdControle"), sevrage_jours: jours("#mdSevrage"),
        races: fen.querySelector("#mdRaces").value.split("\n").map(x => x.trim()).filter(Boolean),
        champs: [...fen.querySelectorAll(".mdChamp")].map(tr => ({ nom: tr.querySelector(".mdNom").value.trim(), choix: tr.querySelector(".mdChoix").value.split(",").map(x => x.trim()).filter(Boolean) })).filter(c => c.nom),
        caracteristiques: fen.querySelector("#mdCarac").value.split(",").map(x => x.trim()).filter(Boolean),
        reperes: [...fen.querySelectorAll(".mdRepere")].map(tr => [tr.querySelector(".mdLib").value.trim(), tr.querySelector(".mdVal").value.trim()]).filter(r => r[0]) } });
      fen.fermer();
      toast(`Modèle des ${e.nom.toLowerCase()} enregistré`);
      tableauFerme = null; animauxFerme = null;
      montrerOngletFerme(ongletFerme);
    } catch (err) { ok.disabled = false; erreur.textContent = err.message; erreur.style.display = "block"; }
  });
}
