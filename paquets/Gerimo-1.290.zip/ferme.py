"""Métier « Ferme » (22/11/2026), étape 1 : bâtiments, bandes d'animaux, suivi du jour.

Toutes les espèces (22/11/2026, demande de Boss) : volailles, lapins, aulacodes, porcs, moutons, chèvres, bovins,
poissons… et celles que l'Admin ajoute (ferme_especes, migration 049). Chaque espèce dit ce qu'elle donne (œufs, lait)
et si elle a des naissances : le suivi du jour montre les bonnes cases.

Décisions de Boss (22/11/2026) — voir migrations/047_ferme.sql :
- Volaille seulement pour commencer ; les animaux sont comptés par BANDE (un lot arrivé le même jour dans un
  poulailler). Plusieurs poulaillers, un seul site.
- Chaque jour, le chef de ferme note pour chaque bande : les morts (et la cause), les œufs ramassés (pondeuses),
  l'aliment donné. Gérimo en tire les sujets vivants, la mortalité, le taux de ponte, l'aliment consommé.
- Rôles (comme la Boutique) : Admin tout ; Gestionnaire = chef de ferme (bandes, suivi du jour) SANS l'argent ;
  Caisse : bandes et prix d'achat (pas de suivi du jour) ; Comptable : consultation.
  Poulaillers, fin de bande et suppression (mot de passe redemandé) : Admin.
"""
from collections import defaultdict
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from sqlalchemy.orm import Session as SessionDB, selectinload

from commun import Formulaire, Suppression, Texte, charger, enregistrer, montant, numero_suivant
from models import FermeBande, FermeEspece, FermePoulailler, FermeSuivi, Utilisateur
from securite import exiger_admin, exiger_module, get_db, verifier_mot_de_passe
import ferme_stock

router = APIRouter(prefix="/api/ferme")
acces = exiger_module("ferme")
GROUPES = ("Volaille", "Petits animaux", "Bétail", "Poissons", "Autre")
PRODUCTIONS = ("Œufs", "Lait")
DESSINS = ("poulet-chair", "pondeuse", "coq", "pintade", "canard", "lapin", "aulacode", "porc", "mouton", "chevre",
           "boeuf", "poisson", "animal")
SAISIT_SUIVI = ("Admin", "Gestionnaire")             # le chef de ferme
CREE_BANDES = ("Admin", "Gestionnaire", "Caisse")
VOIT_ARGENT = ("Admin", "Caisse", "Comptable")
# Alerte « mortalité élevée » : plus de 3 % des sujets morts en 7 jours
ALERTE_MORTALITE_7J = Decimal(3)


def _role(u: Utilisateur) -> str:
    return u.role.value


# ---------- Chiffres d'une bande ----------

def chiffres(b: FermeBande, jour: date | None = None) -> dict:
    """Sujets vivants, âge, mortalité, œufs, aliment… calculés à partir des suivis du jour."""
    jour = jour or date.today()
    fin = b.date_fin if b.statut == "Terminée" and b.date_fin else jour
    suivis = b.suivis
    morts = sum(s.morts for s in suivis)
    naissances = sum(s.naissances for s in suivis) + sum(p.nes_vivants for p in b.portees)   # suivi + portées notées
    vendus = int(sum((l.quantite for l in b.lignes_vente if l.genre == "Animaux" and not l.vente.annulee), 0))   # étape 5
    vivants = max(b.effectif_depart + naissances - morts - vendus, 0)
    il_y_a_7j = jour - timedelta(days=6)
    morts_7j = sum(s.morts for s in suivis if s.date_suivi >= il_y_a_7j)
    du_jour = next((s for s in suivis if s.date_suivi == jour), None)
    oeufs_total = sum(s.oeufs for s in suivis)
    lait_total = sum((s.lait_litres for s in suivis), Decimal(0))
    aliment = sum((s.aliment_kg for s in suivis), Decimal(0))
    pct = lambda n, sur: round(float(Decimal(n) * 100 / sur), 1) if sur else 0.0  # noqa: E731
    mortalite_7j = pct(morts_7j, b.effectif_depart)
    dernier = max((s.date_suivi for s in suivis), default=None)
    if b.statut == "Terminée":
        etat = "termine"
    elif mortalite_7j >= ALERTE_MORTALITE_7J:
        etat = "alerte"
    elif du_jour is None:
        etat = "a_saisir"
    else:
        etat = "ok"
    return {
        "age_jours": (fin - b.date_arrivee).days + b.age_arrivee,
        "vivants": vivants, "morts": morts, "mortalite": pct(morts, b.effectif_depart), "naissances": naissances, "vendus": vendus,
        "naissances_jour": du_jour.naissances if du_jour else 0,
        "lait_total": float(lait_total), "lait_jour": float(du_jour.lait_litres) if du_jour else 0.0,
        "morts_7j": morts_7j, "mortalite_7j": mortalite_7j,
        "oeufs_total": oeufs_total, "oeufs_jour": du_jour.oeufs if du_jour else 0,
        "ponte_jour": pct(du_jour.oeufs, vivants) if du_jour and vivants else 0.0,
        "aliment_kg": float(aliment), "aliment_par_sujet_kg": round(float(aliment) / b.effectif_depart, 2),
        "suivi_du_jour": du_jour is not None, "dernier_suivi": dernier.isoformat() if dernier else None, "etat": etat,
    }


def bande_json(b: FermeBande, u: Utilisateur, jour: date | None = None) -> dict:
    e = b.espece
    d = {"id": b.id, "numero": b.numero, "type": b.type_elevage, "pondeuses": e.production == "Œufs",
         "lait": e.production == "Lait", "avec_naissances": e.naissances, "dessin": e.dessin, "groupe": e.groupe,
         "nom": b.nom or "", "libelle": libelle(b), "poulailler_id": b.poulailler_id, "poulailler": b.poulailler.nom,
         "souche": b.souche or "", "date_arrivee": b.date_arrivee.isoformat(), "age_arrivee": b.age_arrivee,
         "effectif_depart": b.effectif_depart, "males": b.males, "femelles": b.femelles,
         "a_la_ferme_jours": ((b.date_fin if b.statut == "Terminée" and b.date_fin else date.today()) - b.date_arrivee).days,
         "fournisseur": b.fournisseur or "", "statut": b.statut,
         "date_fin": b.date_fin.isoformat() if b.date_fin else None, "note": b.note or "",
         "dernier_aliment_id": next((s.produit_id for s in sorted(b.suivis, key=lambda x: x.date_suivi, reverse=True) if s.produit_id), None),
         **chiffres(b, jour)}
    if _role(u) in VOIT_ARGENT:
        d["cout_achat"] = montant(b.cout_achat) if b.cout_achat is not None else None
        d["cout_par_sujet"] = round(float(b.cout_achat) / b.effectif_depart) if b.cout_achat is not None else None
    return d


def libelle(b: FermeBande) -> str:
    """« Poulets de chair — P1, arrivés le 01/12/2026 » (ou le nom choisi)."""
    return b.nom or f"{b.type_elevage} — {b.poulailler.nom}, arrivé le {b.date_arrivee:%d/%m/%Y}"


def _bandes(db: SessionDB, statut: str | None = None):
    q = db.query(FermeBande).options(selectinload(FermeBande.suivis), selectinload(FermeBande.poulailler), selectinload(FermeBande.portees),
                                     selectinload(FermeBande.lignes_vente))
    if statut:
        q = q.filter(FermeBande.statut == statut)
    return q.order_by(FermeBande.date_arrivee.desc(), FermeBande.id.desc()).all()


# ---------- Tableau de la ferme ----------

@router.get("/tableau")
def tableau(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    bandes_ec = _bandes(db, "En cours")
    en_cours = [bande_json(b, u) for b in bandes_ec]
    poulaillers = db.query(FermePoulailler).order_by(FermePoulailler.nom).all()
    occupes = defaultdict(int)
    for b in en_cours:
        occupes[b["poulailler_id"]] += b["vivants"]
    return {
        "bandes": en_cours,
        "poulaillers": [{"id": p.id, "nom": p.nom, "capacite": p.capacite, "actif": p.actif, "note": p.note or "",
                         "occupes": occupes[p.id]} for p in poulaillers],
        "total": {"vivants": sum(b["vivants"] for b in en_cours), "oeufs_jour": sum(b["oeufs_jour"] for b in en_cours),
                  "lait_jour": sum(b["lait_jour"] for b in en_cours), "naissances_7j": sum(
                      sum(s.naissances for s in x.suivis if s.date_suivi >= date.today() - timedelta(days=6)) for x in bandes_ec),
                  "morts_7j": sum(b["morts_7j"] for b in en_cours),
                  "a_saisir": sum(1 for b in en_cours if not b["suivi_du_jour"])},
        "especes": [espece_json(e) for e in especes(db, tous=True)], "types": [e.nom for e in especes(db)],
        "groupes": GROUPES, "dessins": DESSINS, "aujourdhui": date.today().isoformat(), "aliments": ferme_stock.aliments(db),
        "peut_saisir": _role(u) in SAISIT_SUIVI, "cree_bandes": _role(u) in CREE_BANDES,
        "voit_argent": _role(u) in VOIT_ARGENT, "est_admin": _role(u) == "Admin",
    }


# ---------- Bandes ----------

@router.get("/bandes")
def liste_bandes(statut: Literal["En cours", "Terminée"] | None = None, u: Utilisateur = Depends(acces),
                 db: SessionDB = Depends(get_db)):
    return [bande_json(b, u) for b in _bandes(db, statut)]


@router.get("/bandes/{bande_id}")
def fiche_bande(bande_id: int, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    b = charger(db, FermeBande, bande_id, "Lot introuvable.")
    import ferme_sante   # vaccins prévus et faits, pesées, visites du vétérinaire (étape 3)
    return {**bande_json(b, u), "suivis": [suivi_json(s) for s in reversed(b.suivis)], "sante": ferme_sante.sante_bande(db, b, u)}


# ---------- Espèces (liste libre, migration 049) ----------

def especes(db: SessionDB, tous: bool = False) -> list[FermeEspece]:
    q = db.query(FermeEspece)
    if not tous:
        q = q.filter(FermeEspece.actif)
    return q.order_by(FermeEspece.ordre, FermeEspece.nom).all()


def espece_json(e: FermeEspece) -> dict:
    return {"id": e.id, "nom": e.nom, "groupe": e.groupe, "dessin": e.dessin, "production": e.production,
            "naissances": e.naissances, "batiment": e.batiment, "actif": e.actif, "gestation_jours": e.gestation_jours,
            "controle_jours": e.controle_jours, "sevrage_jours": e.sevrage_jours, "modele": e.modele or {}}


class EspeceIn(Formulaire):
    nom: Texte = Field(min_length=2, max_length=40)
    groupe: Literal[GROUPES] = "Autre"
    dessin: Literal[DESSINS] = "animal"
    production: Literal[PRODUCTIONS] | None = None
    naissances: bool = False
    batiment: Texte = Field("bâtiment", min_length=2, max_length=30)
    actif: bool = True


def _appliquer_espece(e: FermeEspece, d: EspeceIn) -> None:
    e.nom, e.groupe, e.dessin, e.production = d.nom, d.groupe, d.dessin, d.production
    e.naissances, e.batiment, e.actif = d.naissances, d.batiment.lower(), d.actif


@router.post("/especes")
def creer_espece(d: EspeceIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    from sqlalchemy import func
    e = FermeEspece(ordre=(db.query(func.max(FermeEspece.ordre)).scalar() or 0) + 1)
    _appliquer_espece(e, d)
    db.add(e)
    enregistrer(db, f"L'espèce « {d.nom} » existe déjà.")
    return espece_json(e)


@router.put("/especes/{espece_id}")
def modifier_espece(espece_id: int, d: EspeceIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    e = charger(db, FermeEspece, espece_id, "Espèce introuvable.")
    _appliquer_espece(e, d)
    enregistrer(db, f"L'espèce « {d.nom} » existe déjà.")
    return espece_json(e)


class BandeIn(Formulaire):
    type_elevage: Texte = Field(min_length=2, max_length=40)     # nom d'une espèce de la liste
    poulailler_id: int
    nom: Texte | None = Field(None, max_length=100)
    souche: Texte | None = Field(None, max_length=60)
    date_arrivee: date
    age_arrivee: int = Field(1, ge=0, le=2000)
    effectif_depart: int = Field(gt=0, le=1_000_000)
    males: int | None = Field(None, ge=0, le=1_000_000)       # à l'arrivée (facultatif)
    femelles: int | None = Field(None, ge=0, le=1_000_000)
    fournisseur: Texte | None = Field(None, max_length=100)
    cout_achat: Decimal | None = Field(None, ge=0, max_digits=14, decimal_places=2)
    note: Texte | None = Field(None, max_length=300)


def _appliquer_bande(db: SessionDB, b: FermeBande, d: BandeIn, u: Utilisateur) -> None:
    p = charger(db, FermePoulailler, d.poulailler_id, "Bâtiment introuvable.")
    if not p.actif and p.id != b.poulailler_id:
        raise HTTPException(status_code=400, detail=f"Le bâtiment « {p.nom} » n'est plus utilisé.")
    e = db.query(FermeEspece).filter(FermeEspece.nom == d.type_elevage).first()
    if e is None or (not e.actif and e.nom != b.type_elevage):
        raise HTTPException(status_code=400, detail="Choisissez l'espèce dans la liste.")
    if d.date_arrivee > date.today():
        raise HTTPException(status_code=400, detail="La date d'arrivée ne peut pas être dans le futur.")
    premier = min((s.date_suivi for s in b.suivis), default=None) if b.id else None
    if premier and d.date_arrivee > premier:
        raise HTTPException(status_code=400, detail=f"Un suivi existe déjà le {premier:%d/%m/%Y} : "
                                                    "la date d'arrivée ne peut pas être après.")
    morts = sum(s.morts - s.naissances for s in b.suivis) if b.id else 0
    if d.effectif_depart < morts:
        raise HTTPException(status_code=400, detail=f"{morts} animaux sont déjà notés morts : "
                                                    "le nombre au départ ne peut pas être plus petit.")
    b.type_elevage, b.poulailler_id, b.nom, b.souche = d.type_elevage, p.id, d.nom or None, d.souche or None
    b.date_arrivee, b.age_arrivee, b.effectif_depart = d.date_arrivee, d.age_arrivee, d.effectif_depart
    if (d.males or 0) + (d.femelles or 0) > d.effectif_depart:
        raise HTTPException(status_code=400, detail="Plus de mâles et de femelles que d'animaux à l'arrivée.")
    b.males, b.femelles = d.males, d.femelles
    b.fournisseur, b.note = d.fournisseur or None, d.note or None
    if _role(u) in VOIT_ARGENT:   # le chef de ferme ne voit pas l'argent : il laisse le prix « à compléter »
        b.cout_achat = d.cout_achat


def _peut_creer(u: Utilisateur) -> None:
    if _role(u) not in CREE_BANDES:
        raise HTTPException(status_code=403, detail="Le Comptable consulte seulement.")


@router.post("/bandes")
def creer_bande(d: BandeIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _peut_creer(u)
    b = FermeBande(numero=numero_suivant(db, FermeBande.numero, f"LOT-{date.today().year}", 3), saisi_par=u.id)
    _appliquer_bande(db, b, d, u)
    db.add(b)
    enregistrer(db, "Enregistrement impossible.")
    db.refresh(b)
    return bande_json(b, u)


@router.put("/bandes/{bande_id}")
def modifier_bande(bande_id: int, d: BandeIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _peut_creer(u)
    b = charger(db, FermeBande, bande_id, "Lot introuvable.")
    if b.statut == "Terminée" and _role(u) != "Admin":
        raise HTTPException(status_code=409, detail="Ce lot est terminé : seul l'Admin peut encore la modifier.")
    _appliquer_bande(db, b, d, u)
    enregistrer(db, "Enregistrement impossible.")
    return bande_json(b, u)


class FinIn(Formulaire):
    date_fin: date | None = None


@router.post("/bandes/{bande_id}/terminer")
def terminer_bande(bande_id: int, d: FinIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    b = charger(db, FermeBande, bande_id, "Lot introuvable.")
    if b.statut == "Terminée":
        raise HTTPException(status_code=409, detail="Ce lot est déjà terminé.")
    fin = d.date_fin or date.today()
    dernier = max((s.date_suivi for s in b.suivis), default=b.date_arrivee)
    if fin > date.today() or fin < dernier:
        raise HTTPException(status_code=400, detail=f"Date de fin incorrecte (entre le {dernier:%d/%m/%Y} et aujourd'hui).")
    b.statut, b.date_fin = "Terminée", fin
    enregistrer(db, "Enregistrement impossible.")
    return bande_json(b, admin)


@router.post("/bandes/{bande_id}/reprendre")
def reprendre_bande(bande_id: int, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    b = charger(db, FermeBande, bande_id, "Lot introuvable.")
    b.statut, b.date_fin = "En cours", None
    enregistrer(db, "Enregistrement impossible.")
    return bande_json(b, admin)


@router.post("/bandes/{bande_id}/supprimer")
def supprimer_bande(bande_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin),
                    db: SessionDB = Depends(get_db)):
    acces(admin)
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été supprimé.")
    b = charger(db, FermeBande, bande_id, "Lot introuvable.")
    if b.suivis:
        raise HTTPException(status_code=409, detail="Ce lot a déjà des suivis du jour : terminez-la plutôt "
                                                    "(son historique reste consultable).")
    db.delete(b)
    enregistrer(db, "Suppression impossible.")
    return {"ok": True}


# ---------- Suivi du jour ----------

def suivi_json(s: FermeSuivi) -> dict:
    return {"id": s.id, "bande_id": s.bande_id, "date": s.date_suivi.isoformat(), "morts": s.morts,
            "cause_morts": s.cause_morts or "", "oeufs": s.oeufs, "oeufs_casses": s.oeufs_casses,
            "naissances": s.naissances, "lait_litres": float(s.lait_litres),
            "aliment_kg": float(s.aliment_kg), "produit_id": s.produit_id, "aliment": s.produit.nom if s.produit else "",
            "note": s.note or "", "saisi_par": s.auteur.nom_complet if s.auteur else ""}


class LigneSuiviIn(Formulaire):
    bande_id: int
    morts: int = Field(0, ge=0, le=1_000_000)
    cause_morts: Texte | None = Field(None, max_length=100)
    oeufs: int = Field(0, ge=0, le=10_000_000)
    oeufs_casses: int = Field(0, ge=0, le=10_000_000)
    naissances: int = Field(0, ge=0, le=1_000_000)
    lait_litres: Decimal = Field(Decimal(0), ge=0, max_digits=10, decimal_places=2)
    aliment_kg: Decimal = Field(Decimal(0), ge=0, max_digits=10, decimal_places=2)
    produit_id: int | None = None    # aliment donné : ses kg sortent du stock (étape 2)
    note: Texte | None = Field(None, max_length=300)


class SuiviIn(Formulaire):
    date_suivi: date | None = None   # aujourd'hui par défaut ; un oubli d'un jour passé se rattrape
    lignes: list[LigneSuiviIn] = Field(min_length=1, max_length=200)


@router.post("/suivis")
def enregistrer_suivis(d: SuiviIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    """Le suivi du jour de plusieurs lots en une fois. Un lot déjà suivie ce jour-là : sa ligne est remplacée."""
    if _role(u) not in SAISIT_SUIVI:
        raise HTTPException(status_code=403, detail="Le suivi du jour est saisi par le chef de ferme (Gestionnaire) ou l'Admin.")
    jour = d.date_suivi or date.today()
    if jour > date.today():
        raise HTTPException(status_code=400, detail="On ne peut pas saisir le suivi d'un jour à venir.")
    if len({x.bande_id for x in d.lignes}) != len(d.lignes):
        raise HTTPException(status_code=400, detail="Un lot apparaît deux fois.")
    for x in d.lignes:
        b = charger(db, FermeBande, x.bande_id, "Lot introuvable.")
        if b.statut == "Terminée" and _role(u) != "Admin":
            raise HTTPException(status_code=409, detail=f"Le lot {b.numero} est terminé.")
        if jour < b.date_arrivee:
            raise HTTPException(status_code=400, detail=f"Le lot {b.numero} est arrivé le {b.date_arrivee:%d/%m/%Y}.")
        s = next((y for y in b.suivis if y.date_suivi == jour), None)
        e = b.espece
        autres = sum(y.morts - y.naissances for y in b.suivis if y is not s)
        disponibles = (b.effectif_depart - autres + x.naissances + sum(p.nes_vivants for p in b.portees)
                       - int(sum((l.quantite for l in b.lignes_vente if l.genre == "Animaux" and not l.vente.annulee), 0)))
        if x.morts > disponibles:
            raise HTTPException(status_code=400, detail=f"Lot {b.numero} : il n'y a que {max(disponibles, 0)} animaux en vie.")
        if (x.oeufs or x.oeufs_casses) and e.production != "Œufs":
            raise HTTPException(status_code=400, detail=f"Le lot {b.numero} ({e.nom}) ne donne pas d'œufs.")
        if x.lait_litres and e.production != "Lait":
            raise HTTPException(status_code=400, detail=f"Le lot {b.numero} ({e.nom}) ne donne pas de lait.")
        if x.naissances and not e.naissances:
            raise HTTPException(status_code=400, detail=f"Pas de naissances pour le lot {b.numero} ({e.nom}).")
        if s is None:
            s = FermeSuivi(bande_id=b.id, date_suivi=jour, saisi_par=u.id)
            db.add(s)
            b.suivis.append(s)
        else:
            s.modifie_le, s.saisi_par = datetime.now(), u.id
        s.morts, s.cause_morts = x.morts, (x.cause_morts or None) if x.morts else None
        s.oeufs, s.oeufs_casses, s.aliment_kg, s.note = x.oeufs, x.oeufs_casses, x.aliment_kg, x.note or None
        s.naissances, s.lait_litres = x.naissances, x.lait_litres
        s.produit_id = x.produit_id if x.aliment_kg else None
        ferme_stock.sortir_aliment_du_suivi(db, s, u)   # les kg d'aliment sortent du stock
    enregistrer(db, "Enregistrement impossible.")
    return {"ok": True, "date": jour.isoformat(), "nombre": len(d.lignes)}


@router.get("/suivis")
def suivis_du_jour(jour: date | None = None, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    """Ce qui a déjà été noté ce jour-là (pour pré-remplir l'écran « Suivi du jour »)."""
    jour = jour or date.today()
    lignes = db.query(FermeSuivi).filter(FermeSuivi.date_suivi == jour).all()
    return [suivi_json(s) for s in lignes]


# ---------- Bâtiments (poulaillers, clapiers, porcheries…) — Admin ----------

class PoulaillerIn(Formulaire):
    nom: Texte = Field(min_length=1, max_length=60)
    capacite: int | None = Field(None, gt=0, le=1_000_000)
    note: Texte | None = Field(None, max_length=300)
    actif: bool = True


@router.post("/poulaillers")
def creer_poulailler(d: PoulaillerIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    p = FermePoulailler(nom=d.nom, capacite=d.capacite, note=d.note or None, actif=d.actif)
    db.add(p)
    enregistrer(db, f"Un bâtiment « {d.nom} » existe déjà.")
    return {"id": p.id}


@router.put("/poulaillers/{poulailler_id}")
def modifier_poulailler(poulailler_id: int, d: PoulaillerIn, admin: Utilisateur = Depends(exiger_admin),
                        db: SessionDB = Depends(get_db)):
    acces(admin)
    p = charger(db, FermePoulailler, poulailler_id, "Bâtiment introuvable.")
    p.nom, p.capacite, p.note, p.actif = d.nom, d.capacite, d.note or None, d.actif
    enregistrer(db, f"Un bâtiment « {d.nom} » existe déjà.")
    return {"id": p.id}


# ---------- Alertes (assistant) ----------

def alertes(db: SessionDB, u: Utilisateur) -> list[tuple[str, str, str, str]]:
    resultat = []
    hier = date.today() - timedelta(days=1)
    for b in _bandes(db, "En cours"):
        c = chiffres(b)
        if c["mortalite_7j"] >= ALERTE_MORTALITE_7J:
            resultat.append((f"ferme-morts-{b.id}", "attention", f"{libelle(b)} : {c['morts_7j']} morts en 7 jours",
                             f"{c['mortalite_7j']} % du lot : appelez le vétérinaire si cela continue."))
        if b.date_arrivee <= hier and not any(s.date_suivi == hier for s in b.suivis):
            resultat.append((f"ferme-suivi-{b.id}", "info", f"{libelle(b)} : le suivi d'hier n'a pas été noté",
                             "Morts, œufs et aliment : Ferme → Suivi du jour (on peut choisir la date d'hier)."))
    return resultat
