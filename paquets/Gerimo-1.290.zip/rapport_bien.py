"""Rapport mensuel par bien (cité, immeuble, maison, cour…) : à imprimer ou à exporter vers Excel.

Pour chaque logement du bien : type et numéro, locataire et son contact, loyer mensuel, loyers encaissés,
commission de gestion, part du propriétaire, loyer impayé et dépenses ; puis les dépenses communes du bien,
le détail des dépenses et le net à reverser au propriétaire.
Mêmes calculs que le rapport détaillé (rapports.py) : un encaissement compte dans le mois du loyer qu'il paie ;
la caution n'entre ni dans la commission ni dans la part du propriétaire ; un loyer est impayé quand son mois
est dans la période, qu'il n'est pas réglé et que sa date limite (le 05) est passée.
Droits : Admin, Caisse, Comptable = tout ; Gestionnaire = ses biens, sans propriétaire ni commission.
"""
import io
import re
import unicodedata
from collections import Counter, defaultdict
from datetime import date, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy.orm import Session as SessionDB, selectinload

import recus
from commun import montant, voit_finances
from models import Cite, Contrat, Echeance, HistoriqueLoyer, Logement, Utilisateur
from paiements import ajouter_mois, libelle_mois, premier_du_mois, recalculer_tout
from rapports import (_dans_perimetre, _depenses, _encaissements, _periode, _repartition, acces_rapports,
                      logement_historique)
from securite import get_db

router = APIRouter(prefix="/api")
ZERO = Decimal(0)


def libelle_de_periode(debut: date, fin: date) -> str:
    """« Octobre 2026 » pour un mois entier (ou le mois en cours jusqu'à aujourd'hui), sinon « du … au … »."""
    lendemain = fin + timedelta(days=1)
    if (debut.day, debut.month) == (1, 1) and debut.year == fin.year             and ((fin.day, fin.month) == (31, 12) or fin == date.today()):
        return f"Année {debut.year}"
    if debut.day == 1 and (debut.year, debut.month) == (fin.year, fin.month) \
            and (lendemain.day == 1 or fin == date.today()):
        return libelle_mois(debut).capitalize()
    return f"du {debut.strftime('%d/%m/%Y')} au {fin.strftime('%d/%m/%Y')}"


def _fin_contrat(c: Contrat) -> date | None:
    fin = c.date_resiliation if c.statut_contrat == "Résilié" else c.date_fin
    if c.date_depart and c.statut_contrat != "Résilié" and (fin is None or c.date_depart < fin):
        fin = c.date_depart
    return fin


def _type_bien(cite: Cite) -> str:
    types = sorted({l.type_batiment for l in cite.logements if l.type_batiment})
    return ", ".join(types) or "—"


def _cle_numero(numero: str):
    """Tri naturel des numéros de logement : A2 avant A10."""
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r"(\d+)", numero or "")]


def choisir_cites(db: SessionDB, utilisateur: Utilisateur, cite_ids: list[int] | None, *options) -> list[Cite]:
    """Les biens du rapport : ceux choisis (un ou plusieurs, ex. les cités d'un même propriétaire, imprimées sur le
    même document), sinon tous les biens avec des logements du périmètre. Un bien hors périmètre : 404."""
    perimetre = _dans_perimetre(utilisateur)
    requete = db.query(Cite).options(selectinload(Cite.logements), *options)
    if cite_ids:
        cites = requete.filter(Cite.id.in_(set(cite_ids))).order_by(Cite.nom).all()
        if len(cites) != len(set(cite_ids)) or not all(perimetre(c.id) for c in cites):
            raise HTTPException(status_code=404, detail="Bien introuvable (ou hors de vos biens).")
        return cites
    return [c for c in requete.order_by(Cite.nom) if perimetre(c.id) and c.logements]


def construire(db: SessionDB, utilisateur: Utilisateur, debut: date, fin: date,
               cite_ids: list[int] | None) -> dict:
    finances = voit_finances(utilisateur)
    aujourdhui = date.today()
    cites = choisir_cites(db, utilisateur, cite_ids, selectinload(Cite.proprietaire), selectinload(Cite.mandats))
    ids = {c.id for c in cites}

    # contrats des logements de ces biens, avec leurs échéances (mises à jour avant lecture)
    contrats = db.query(Contrat).join(Logement).options(
        selectinload(Contrat.echeances).selectinload(Echeance.paiement), selectinload(Contrat.locataire),
        selectinload(Contrat.logement)).filter(Logement.cite_id.in_(ids)).all() if ids else []
    recalculer_tout(db, contrats)

    paiements = [p for p in _encaissements(db, debut, fin, utilisateur) if p.contrat.logement.cite_id in ids]
    depenses = [d for d in _depenses(db, debut, fin, utilisateur) if d.cite_id in ids]
    mois_debut = premier_du_mois(debut)
    # Rapport sur plusieurs mois (rapport annuel) : tableau mois par mois de chaque bien
    les_mois = []
    m = mois_debut
    while m <= fin:
        les_mois.append(m)
        m = ajouter_mois(m, 1)
    par_mois = {(cid, m): {"encaisse": ZERO, "commission": ZERO, "depenses": ZERO, "depenses_proprietaire": ZERO,
                           "impaye": ZERO} for cid in ids for m in les_mois}
    for p in paiements:
        loyers, _, commission = _repartition(p)
        case = par_mois.get((p.contrat.logement.cite_id, p.mois))
        if case:
            case["encaisse"] += loyers
            case["commission"] += commission
    for d in depenses:
        case = par_mois.get((d.cite_id, premier_du_mois(d.date_depense)))
        if case:
            case["depenses"] += d.montant
            if d.a_la_charge_de == "Propriétaire":
                case["depenses_proprietaire"] += d.montant

    # Lignes : un contrat qui couvre la période (ou qui a payé pendant la période) = une ligne
    lignes: dict = {}

    def ligne(logement: Logement, contrat: Contrat | None, sejours: bool = False) -> dict:
        cle = ("contrat", contrat.id) if contrat else ("sejours" if sejours else "libre", logement.id)
        if cle not in lignes:
            lignes[cle] = {
                "logement_id": logement.id, "cite_id": logement.cite_id, "numero": logement.numero_logement,
                "type_logement": logement.type_logement,
                "locataire": contrat.locataire.nom_complet if contrat else
                ("Séjours courte durée" if sejours else "— (Réservé par le propriétaire)" if logement.reserve_proprietaire
                 else f"— ({logement.statut_logement})"),
                "telephone": (contrat.locataire.telephone or "") if contrat else "",
                "numero_contrat": contrat.numero_contrat if contrat else "",
                "loyer_mensuel": contrat.montant_loyer if contrat else logement.loyer,
                "encaisse": ZERO, "cautions": ZERO, "commission": ZERO, "impaye": ZERO, "mois_impayes": [],
                "depenses": ZERO, "_debut": contrat.date_debut if contrat else date.min,
            }
        return lignes[cle]

    def ligne_ancien(h) -> dict:
        """Ancien locataire d'après les anciens classeurs (nom et numéro tels qu'écrits)."""
        lg = logement_historique(h)
        cle = ("ancien", h.cite_id, lg.numero_logement.lower(), " ".join(h.locataire.lower().split()))
        if cle not in lignes:
            lignes[cle] = {
                "logement_id": lg.id, "cite_id": h.cite_id,
                "numero": lg.numero_logement + ("" if h.logement else " (ancien n°)"),
                "type_logement": lg.type_logement, "locataire": f"{h.locataire} (ancien locataire)",
                "telephone": h.telephone or "", "numero_contrat": "", "loyer_mensuel": ZERO,
                "encaisse": ZERO, "cautions": ZERO, "commission": ZERO, "impaye": ZERO, "mois_impayes": [],
                "depenses": ZERO, "_debut": date.min,
            }
        return lignes[cle]

    for c in contrats:
        fin_c = _fin_contrat(c)
        if c.date_debut <= fin and (fin_c is None or fin_c >= debut):
            ligne(c.logement, c)
        for e in c.echeances:  # loyers du mois (ou des mois) de la période, échus et non réglés
            if mois_debut <= e.mois_echeance <= fin and e.paiement is None and e.date_limite < aujourdhui:
                l = ligne(c.logement, c)
                l["impaye"] += e.reste
                par_mois[(c.logement.cite_id, e.mois_echeance)]["impaye"] += e.reste
                l["mois_impayes"].append(libelle_mois(e.mois_echeance))
    for p in paiements:
        loyers, caution, commission = _repartition(p)
        contrat = p.contrat if isinstance(p.contrat, Contrat) else None
        if contrat is None and hasattr(p, "historique"):
            l = ligne_ancien(p.historique)
        else:
            l = ligne(p.contrat.logement, contrat, sejours=contrat is None)
        l["encaisse"] += loyers
        l["cautions"] += caution
        l["commission"] += commission
    for d in depenses:
        if d.logement_id:
            occupees = [l for l in lignes.values() if l["logement_id"] == d.logement_id]
            (max(occupees, key=lambda l: l["_debut"]) if occupees else ligne(d.logement, None))["depenses"] += d.montant
    # logements sans locataire ni mouvement : une ligne quand même (le rapport montre tout le bien)
    for c in cites:
        for lg in c.logements:
            if not any(l["logement_id"] == lg.id for l in lignes.values()):
                ligne(lg, None)

    biens = []
    for c in cites:
        rangs = sorted((l for l in lignes.values() if l["cite_id"] == c.id),
                       key=lambda l: (_cle_numero(l["numero"]), l["_debut"]))
        deps = sorted((d for d in depenses if d.cite_id == c.id), key=lambda d: (d.date_depense, d.id))
        communes = sum((d.montant for d in deps if not d.logement_id), ZERO)
        dep_proprio = sum((d.montant for d in deps if d.a_la_charge_de == "Propriétaire"), ZERO)
        t = {k: sum((l[k] for l in rangs), ZERO) for k in ("encaisse", "cautions", "commission", "impaye", "depenses")}
        t["depenses"] += communes
        bien = {
            "cite_id": c.id, "bien": c.nom, "type_bien": _type_bien(c), "adresse": c.adresse or "",
            "nb_logements": len(c.logements),
            "occupes": sum(1 for l in c.logements if l.statut_logement == "Occupé"),
            "lignes": [{
                "numero": l["numero"], "type_logement": l["type_logement"], "locataire": l["locataire"],
                "telephone": l["telephone"], "numero_contrat": l["numero_contrat"],
                "loyer_mensuel": montant(l["loyer_mensuel"]), "encaisse": montant(l["encaisse"]),
                "impaye": montant(l["impaye"]), "mois_impayes": l["mois_impayes"], "depenses": montant(l["depenses"]),
                **({"commission": montant(l["commission"]),
                    "part_proprietaire": montant(l["encaisse"] - l["commission"])} if finances else {}),
            } for l in rangs],
            "depenses_communes": montant(communes),
            "detail_depenses": [{
                "date": d.date_depense.isoformat(), "logement": d.logement.numero_logement if d.logement else "Commune",
                "motif": d.motif, "categorie": d.categorie, "a_la_charge_de": d.a_la_charge_de,
                "montant": montant(d.montant)} for d in deps],
            "totaux": {"loyer_mensuel": montant(sum((l["loyer_mensuel"] for l in rangs), ZERO)),
                       "encaisse": montant(t["encaisse"]), "cautions": montant(t["cautions"]),
                       "impaye": montant(t["impaye"]), "depenses": montant(t["depenses"])},
        }
        if len(les_mois) > 1:
            bien["par_mois"] = []
            for m in les_mois:
                v = par_mois[(c.id, m)]
                bien["par_mois"].append({
                    "mois": libelle_mois(m).capitalize(), "encaisse": montant(v["encaisse"]),
                    "impaye": montant(v["impaye"]), "depenses": montant(v["depenses"]),
                    **({"commission": montant(v["commission"]),
                        "part_proprietaire": montant(v["encaisse"] - v["commission"]),
                        "net_a_reverser": montant(v["encaisse"] - v["commission"] - v["depenses_proprietaire"])}
                       if finances else {})})
        if finances:
            mandat = c.mandat_actuel
            bien["proprietaire"] = c.proprietaire.nom_complet if c.proprietaire else "Non renseigné"
            bien["proprietaire_telephone"] = (c.proprietaire.telephone or "") if c.proprietaire else ""
            bien["pourcentage_commission"] = montant(mandat.pourcentage_commission) if mandat else None
            bien["totaux"].update(
                commission=montant(t["commission"]), part_proprietaire=montant(t["encaisse"] - t["commission"]),
                depenses_proprietaire=montant(dep_proprio),
                net_a_reverser=montant(t["encaisse"] - t["commission"] - dep_proprio))
        biens.append(bien)
    return {"debut": debut.isoformat(), "fin": fin.isoformat(), "periode": libelle_de_periode(debut, fin),
            "finances": finances, "biens": biens,
            # des mois viennent des anciens classeurs : sommes telles que notées, impayés de ces mois non calculés
            "historique": any(hasattr(p, "historique") for p in paiements)}


# ---------- Rapport par locataire : qui est bon payeur ? (demande de Boss du 23/11/2026) ----------

def _note_payeur(dus: int, a_temps: int, en_retard: int, impayes: int) -> tuple[str, str]:
    """(code couleur, appréciation) d'après les mois échus de la période."""
    if not dus:
        return "termine", "Pas encore de loyer échu"
    if impayes >= 2:
        return "a_risque", "Mauvais payeur"
    if impayes or en_retard > max(1, dus // 4):
        return "retard", "Payeur irrégulier"
    return "a_jour", "Bon payeur"


def mois_historiques(lignes: list, plafond: Decimal | None) -> list[dict]:
    """Classe les mois repris des anciens classeurs d'un locataire : à temps, en retard ou impayé.

    Les classeurs ne donnent ni le loyer dû ni la date du paiement : on compare le cumul versé au cumul dû, avec pour
    loyer de chaque année le versement le plus fréquent de l'année (plafonné au loyer actuel : un locataire qui paie
    deux mois d'un coup ne double pas son loyer). Un mois est « à temps » si, à la fin du mois, le cumul versé couvre
    le cumul dû ; « en retard » s'il est couvert plus tard (retard compté en mois) ; sinon « impayé »."""
    par_mois: dict[date, Decimal] = defaultdict(Decimal)
    for h in lignes:
        par_mois[h.mois] += h.montant or ZERO
    les_mois = sorted(par_mois)
    references = {}
    for annee in {m.year for m in les_mois}:
        positifs = [par_mois[m] for m in les_mois if m.year == annee and par_mois[m] > 0]
        if positifs:
            frequent = max(Counter(positifs).items(), key=lambda x: (x[1], -x[0]))[0]
            references[annee] = min(frequent, plafond) if plafond else frequent
    if not references:
        references = {m.year: plafond or ZERO for m in les_mois}

    def reference(m: date) -> Decimal:
        if m.year in references:
            return references[m.year]
        proche = min(references, key=lambda a: abs(a - m.year))
        return references[proche]

    cumul_du, cumul_verse, du, verse = [], [], ZERO, ZERO
    for m in les_mois:
        du += reference(m)
        verse += par_mois[m]
        cumul_du.append(du)
        cumul_verse.append(verse)
    resultat = []
    for i, m in enumerate(les_mois):
        if cumul_verse[i] >= cumul_du[i] - 1:
            etat, retard_mois = "À temps", 0
        else:
            k = next((j for j in range(i + 1, len(les_mois)) if cumul_verse[j] >= cumul_du[i] - 1), None)
            etat, retard_mois = ("Impayé", None) if k is None else ("En retard", k - i)
        resultat.append({"mois": m, "loyer": reference(m), "verse": par_mois[m], "etat": etat,
                         "retard_mois": retard_mois})
    return resultat


def construire_locataires(db: SessionDB, utilisateur: Utilisateur, debut: date, fin: date,
                          cite_ids: list[int] | None) -> dict:
    """Pour chaque locataire (contrat) du ou des biens : ses loyers échus de la période, payés à temps (avant la date
    limite, le 05), en retard ou encore impayés, le retard moyen et une appréciation (bon payeur…).
    Un mois compte quand sa date limite est passée ; il est « à temps » quand le paiement qui l'a soldé est daté au
    plus tard de sa date limite. Les mois d'avant le suivi dans Gérimo viennent des anciens classeurs repris
    (historique_loyers, voir mois_historiques) ; les anciens locataires, partis depuis, sont listés à part."""
    from import_donnees import mots_nom
    aujourdhui = date.today()
    cites = {c.id: c for c in choisir_cites(db, utilisateur, cite_ids)}
    contrats = db.query(Contrat).join(Logement).options(
        selectinload(Contrat.echeances).selectinload(Echeance.paiement), selectinload(Contrat.locataire),
        selectinload(Contrat.logement).selectinload(Logement.cite)
    ).filter(Logement.cite_id.in_(list(cites))).all() if cites else []
    recalculer_tout(db, contrats)
    mois_debut = premier_du_mois(debut)
    historique = db.query(HistoriqueLoyer).options(selectinload(HistoriqueLoyer.logement)).filter(
        HistoriqueLoyer.cite_id.in_(list(cites)), HistoriqueLoyer.mois <= fin).all() if cites else []
    par_contrat, anciens = defaultdict(list), defaultdict(list)
    for h in historique:
        if h.contrat_id:
            par_contrat[h.contrat_id].append(h)
        else:
            anciens[(h.cite_id, frozenset(mots_nom(h.locataire)) or h.locataire)].append(h)

    def ajouter_historique(compte: dict, lignes_h: list, plafond) -> None:
        for x in mois_historiques(lignes_h, plafond):
            if not (mois_debut <= x["mois"] <= fin):
                continue
            compte["dus"] += 1
            compte["verse"] += x["verse"]
            if x["etat"] == "À temps":
                compte["a_temps"] += 1
            elif x["etat"] == "En retard":
                compte["en_retard"] += 1
                compte["jours"].append(x["retard_mois"] * 30)
            else:
                compte["impayes"] += 1
            compte["detail"].append({
                "mois": libelle_mois(x["mois"]).capitalize(), "loyer": montant(x["loyer"]), "verse": montant(x["verse"]),
                "reste": 0, "date_limite": None, "paye_le": None, "source": "ancien classeur",
                "jours_retard": (x["retard_mois"] or 0) * 30, "retard_mois": x["retard_mois"], "etat": x["etat"]})

    def resultat(compte: dict) -> dict:
        dus = compte["dus"]
        code, note = _note_payeur(dus, compte["a_temps"], compte["en_retard"], compte["impayes"])
        return {"mois_dus": dus, "a_temps": compte["a_temps"], "en_retard": compte["en_retard"],
                "impayes": compte["impayes"], "taux_a_temps": round(compte["a_temps"] / dus * 100) if dus else None,
                "retard_moyen": round(sum(compte["jours"]) / len(compte["jours"])) if compte["jours"] else 0,
                "verse": montant(compte["verse"]), "reste": montant(compte["reste"]), "code": code, "note": note,
                "detail": compte["detail"]}

    nouveau_compte = lambda: {"dus": 0, "a_temps": 0, "en_retard": 0, "impayes": 0, "jours": [],  # noqa: E731
                              "verse": ZERO, "reste": ZERO, "detail": []}
    locataires = []
    for c in contrats:
        fin_c = _fin_contrat(c)
        dans_periode = c.date_debut <= fin and (fin_c is None or fin_c >= debut)
        a_historique = any(mois_debut <= h.mois <= fin for h in par_contrat.get(c.id, []))
        if not dans_periode and not a_historique:
            continue
        compte = nouveau_compte()
        ajouter_historique(compte, par_contrat.get(c.id, []), c.montant_loyer)
        for e in sorted(c.echeances, key=lambda e: e.mois_echeance):
            if not (mois_debut <= e.mois_echeance <= fin) or e.date_limite >= aujourdhui:
                continue
            compte["dus"] += 1
            compte["verse"] += e.montant_verse or ZERO
            paye_le = e.paiement.date_paiement if e.paiement is not None else None
            if paye_le is None:
                compte["impayes"] += 1
                compte["reste"] += e.reste
                retard = (aujourdhui - e.date_limite).days
                etat = "Payé en partie" if e.montant_verse else "Impayé"
            elif paye_le <= e.date_limite:
                compte["a_temps"] += 1
                retard, etat = 0, "À temps"
            else:
                compte["en_retard"] += 1
                retard, etat = (paye_le - e.date_limite).days, "En retard"
                compte["jours"].append(retard)
            compte["detail"].append({
                "mois": libelle_mois(e.mois_echeance).capitalize(), "loyer": montant(e.montant_loyer),
                "verse": montant(e.montant_verse or ZERO), "reste": montant(e.reste),
                "date_limite": e.date_limite.isoformat(), "paye_le": paye_le.isoformat() if paye_le else None,
                "jours_retard": retard, "etat": etat})
        locataires.append({
            "contrat_id": c.id, "locataire_id": c.locataire_id, "locataire": c.locataire.nom_complet,
            "telephone": c.locataire.telephone or "", "numero_contrat": c.numero_contrat,
            "bien": c.logement.cite.nom, "logement": c.logement.numero_logement,
            "loyer_mensuel": montant(c.montant_loyer), "statut_contrat": c.statut_contrat, "ancien": False,
            **resultat(compte)})
    # Anciens locataires (partis avant Gérimo) : d'après les anciens classeurs seulement
    for (cite_id, _), lignes_h in anciens.items():
        if not any(mois_debut <= h.mois <= fin for h in lignes_h):
            continue
        dernier = max(lignes_h, key=lambda h: h.mois)
        plafond = dernier.logement.loyer if dernier.logement is not None else None
        compte = nouveau_compte()
        ajouter_historique(compte, lignes_h, plafond)
        loyer = mois_historiques(lignes_h, plafond)[-1]["loyer"]
        locataires.append({
            "contrat_id": None, "locataire_id": None, "locataire": dernier.locataire,
            "telephone": dernier.telephone or "", "numero_contrat": "", "bien": cites[cite_id].nom,
            "logement": dernier.logement.numero_logement if dernier.logement is not None else dernier.numero_logement,
            "loyer_mensuel": montant(loyer), "statut_contrat": "Parti", "ancien": True, **resultat(compte)})
    rang = {"a_jour": 0, "retard": 1, "a_risque": 2, "termine": 3}
    locataires.sort(key=lambda l: (l["ancien"], rang[l["code"]], -(l["taux_a_temps"] or 0), l["retard_moyen"],
                                   l["bien"], _cle_numero(l["logement"])))
    actuels = [l for l in locataires if not l["ancien"]]
    compte = {k: sum(1 for l in actuels if l["code"] == k) for k in rang}
    return {"debut": debut.isoformat(), "fin": fin.isoformat(), "periode": libelle_de_periode(debut, fin),
            "bien": _titre_biens([c.nom for c in cites.values()], cite_ids),
            "bons": compte["a_jour"], "irreguliers": compte["retard"], "mauvais": compte["a_risque"],
            "anciens": sum(1 for l in locataires if l["ancien"]),
            "historique": bool(historique), "locataires": locataires}


@router.get("/rapports/par-locataire")
def rapport_par_locataire(cite_id: list[int] | None = Query(None), debut: date | None = Query(None),
                          fin: date | None = Query(None), utilisateur: Utilisateur = Depends(acces_rapports),
                          db: SessionDB = Depends(get_db)):
    return construire_locataires(db, utilisateur, *_periode(debut, fin), cite_id)


def _nom_fichier_locataires(rapport: dict, extension: str) -> str:
    ascii_ = unicodedata.normalize("NFKD", rapport["bien"]).encode("ascii", "ignore").decode()
    sujet = "".join(ch if ch.isalnum() else "_" for ch in ascii_).strip("_")[:40] or "biens"
    return f"locataires_{sujet}_{rapport['debut'][:7]}.{extension}"


@router.get("/rapports/par-locataire/pdf")
def rapport_par_locataire_pdf(cite_id: list[int] | None = Query(None), debut: date | None = Query(None),
                              fin: date | None = Query(None), utilisateur: Utilisateur = Depends(acces_rapports),
                              db: SessionDB = Depends(get_db)):
    rapport = construire_locataires(db, utilisateur, *_periode(debut, fin), cite_id)
    return Response(recus.rapport_locataires_pdf(rapport), media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="{_nom_fichier_locataires(rapport, "pdf")}"'})


@router.get("/rapports/par-locataire/excel")
def rapport_par_locataire_excel(cite_id: list[int] | None = Query(None), debut: date | None = Query(None),
                                fin: date | None = Query(None), utilisateur: Utilisateur = Depends(acces_rapports),
                                db: SessionDB = Depends(get_db)):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    rapport = construire_locataires(db, utilisateur, *_periode(debut, fin), cite_id)
    classeur = Workbook()
    f = classeur.active
    f.title = "Locataires"
    f["A1"] = f"Rapport par locataire — {rapport['bien']} — {rapport['periode']}"
    f["A1"].font = Font(bold=True, size=14, color="C1552D")
    f["A2"] = (f"{rapport['bons']} bon(s) payeur(s), {rapport['irreguliers']} irrégulier(s), "
               f"{rapport['mauvais']} mauvais payeur(s)")
    titres = [("Appréciation", 22), ("Locataire", 28), ("Contact", 16), ("Bien", 22), ("Logement", 10),
              ("Loyer mensuel", 14), ("Mois échus", 11), ("À temps", 9), ("En retard", 10), ("Impayés", 9),
              ("% à temps", 10), ("Retard moyen (jours)", 12), ("Versé", 14), ("Reste à payer", 14)]
    for j, (t, largeur) in enumerate(titres, start=1):
        c = f.cell(4, j, t)
        c.font, c.fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="1D3B53")
        f.column_dimensions[c.column_letter].width = largeur
    for i, l in enumerate(rapport["locataires"], start=5):
        valeurs = [("Ancien locataire — " if l["ancien"] else "") + l["note"], l["locataire"], l["telephone"], l["bien"], l["logement"], float(l["loyer_mensuel"]),
                   l["mois_dus"], l["a_temps"], l["en_retard"], l["impayes"],
                   (l["taux_a_temps"] / 100) if l["taux_a_temps"] is not None else None, l["retard_moyen"],
                   float(l["verse"]), float(l["reste"])]
        for j, v in enumerate(valeurs, start=1):
            c = f.cell(i, j, v)
            if j in (6, 13, 14):
                c.number_format = '#,##0" F"'
            elif j == 11:
                c.number_format = "0 %"
    f.freeze_panes = "A5"
    tampon = io.BytesIO()
    classeur.save(tampon)
    return Response(tampon.getvalue(), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition":
                             f'attachment; filename="{_nom_fichier_locataires(rapport, "xlsx")}"'})


def _titre_biens(noms: list[str], cite_ids: list[int] | None) -> str:
    """« Cité A », « Cité A, Cité B et Cité C », « 5 biens » ou « Tous les biens »."""
    if not cite_ids:
        return "Tous les biens"
    noms = sorted(noms)
    if len(noms) == 1:
        return noms[0]
    if len(noms) <= 3:
        return ", ".join(noms[:-1]) + " et " + noms[-1]
    return f"{len(noms)} biens"


def _nom_fichier(rapport: dict, extension: str) -> str:
    sujet = rapport["biens"][0]["bien"] if len(rapport["biens"]) == 1 else \
        rapport.get("titre_biens", "tous_les_biens")
    ascii_ = unicodedata.normalize("NFKD", sujet).encode("ascii", "ignore").decode()
    sujet = "".join(ch if ch.isalnum() else "_" for ch in ascii_).strip("_")[:40] or "bien"
    return f"rapport_{sujet}_{rapport['debut'][:7]}.{extension}"


def _charger(db, utilisateur, debut, fin, cite_id) -> dict:
    rapport = construire(db, utilisateur, *_periode(debut, fin), cite_id)
    rapport["titre_biens"] = _titre_biens([b["bien"] for b in rapport["biens"]], cite_id)
    if not rapport["biens"]:
        raise HTTPException(status_code=404, detail="Aucun bien avec des logements à présenter.")
    return rapport


@router.get("/rapports/par-bien/biens")
def liste_biens(utilisateur: Utilisateur = Depends(acces_rapports), db: SessionDB = Depends(get_db)):
    """Biens proposés dans la liste (la Caisse et le Comptable n'ont pas accès au module Biens)."""
    perimetre = _dans_perimetre(utilisateur)
    finances = voit_finances(utilisateur)
    return [{"id": c.id, "nom": c.nom,
             "proprietaire": (c.proprietaire.nom_complet if c.proprietaire else "") if finances else ""}
            for c in db.query(Cite).options(selectinload(Cite.logements), selectinload(Cite.proprietaire))
            .order_by(Cite.nom) if perimetre(c.id) and c.logements]


@router.get("/rapports/par-bien")
def rapport_par_bien(cite_id: list[int] | None = Query(None), debut: date | None = Query(None),
                     fin: date | None = Query(None), utilisateur: Utilisateur = Depends(acces_rapports),
                     db: SessionDB = Depends(get_db)):
    return construire(db, utilisateur, *_periode(debut, fin), cite_id)


@router.get("/rapports/par-bien/pdf")
def rapport_par_bien_pdf(cite_id: list[int] | None = Query(None), debut: date | None = Query(None),
                         fin: date | None = Query(None), utilisateur: Utilisateur = Depends(acces_rapports),
                         db: SessionDB = Depends(get_db)):
    rapport = _charger(db, utilisateur, debut, fin, cite_id)
    contenu = recus.rapport_par_bien_pdf(rapport)
    return Response(contenu, media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="{_nom_fichier(rapport, "pdf")}"'})


# ---------- Excel (.xlsx mis en forme) ----------

def classeur_excel(rapport: dict) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

    finances = rapport["finances"]
    marine, vert_clair = "1D3B53", "EEF5E8"
    titre_police = Font(bold=True, size=14, color="C1552D")
    gras = Font(bold=True)
    entete_police = Font(bold=True, color="FFFFFF")
    entete_fond = PatternFill("solid", fgColor=marine)
    total_fond = PatternFill("solid", fgColor=vert_clair)
    trait = Side(style="thin", color="D5DBD3")
    cadre = Border(left=trait, right=trait, top=trait, bottom=trait)
    format_f = '#,##0" F"'

    colonnes = [("N°", 8), ("Type de logement", 18), ("Locataire", 28), ("Contact", 16), ("Loyer mensuel", 15),
                ("Loyer encaissé", 15)]
    if finances:
        colonnes += [("Commission agence", 16), ("Part propriétaire", 17)]
    colonnes += [("Loyer impayé", 14), ("Mois impayés", 22), ("Dépenses", 13)]
    cles = ["numero", "type_logement", "locataire", "telephone", "loyer_mensuel", "encaisse"] + \
           (["commission", "part_proprietaire"] if finances else []) + ["impaye", "mois_impayes", "depenses"]
    nombres = {"loyer_mensuel", "encaisse", "commission", "part_proprietaire", "impaye", "depenses"}

    classeur = Workbook()
    classeur.remove(classeur.active)
    noms_pris = set()
    for b in rapport["biens"]:
        nom = re.sub(r"[\\/*?:\[\]]", " ", b["bien"])[:28].strip() or "Bien"
        base, n = nom, 2
        while nom.lower() in noms_pris:
            nom = f"{base[:25]} ({n})"
            n += 1
        noms_pris.add(nom.lower())
        f = classeur.create_sheet(nom)
        f.sheet_view.showGridLines = False
        f.page_setup.orientation = "landscape"
        f.page_setup.fitToWidth = 1
        f.page_setup.fitToHeight = 0
        f.sheet_properties.pageSetUpPr.fitToPage = True

        genre = ("Rapport annuel" if rapport["periode"].startswith("Année") else
                 "Rapport" if b.get("par_mois") else "Rapport mensuel")
        f["A1"] = f"{genre} — {b['bien']}"
        f["A1"].font = titre_police
        infos = [("Entreprise", recus.ENTETE["nom"]), ("Période", rapport["periode"]),
                 ("Type de bien", b["type_bien"]), ("Adresse", b["adresse"]),
                 ("Logements", f"{b['nb_logements']} dont {b['occupes']} occupé(s)")]
        if finances:
            infos[2:2] = [("Propriétaire", b["proprietaire"]), ("Contact du propriétaire", b["proprietaire_telephone"])]
            if b["pourcentage_commission"] is not None:
                infos.append(("Commission de gestion", f"{str(b['pourcentage_commission']).replace('.', ',')} %"))
        for i, (libelle, valeur) in enumerate(infos, start=3):
            f.cell(i, 1, libelle).font = Font(color="5C655E")
            f.cell(i, 3, valeur).font = gras
        ligne = 4 + len(infos)
        for j, (titre, largeur) in enumerate(colonnes, start=1):
            c = f.cell(ligne, j, titre)
            c.font, c.fill, c.border = entete_police, entete_fond, cadre
            c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            f.column_dimensions[c.column_letter].width = largeur
        f.row_dimensions[ligne].height = 30
        premiere = ligne + 1
        for r in b["lignes"]:
            ligne += 1
            for j, cle in enumerate(cles, start=1):
                v = r[cle]
                v = ", ".join(v) if isinstance(v, list) else v
                c = f.cell(ligne, j, float(v) if cle in nombres else v)
                c.border = cadre
                if cle in nombres:
                    c.number_format = format_f
        if b["depenses_communes"]:
            ligne += 1
            f.cell(ligne, 3, "Dépenses communes du bien").font = Font(italic=True)
            c = f.cell(ligne, cles.index("depenses") + 1, float(b["depenses_communes"]))
            c.number_format = format_f
            for j in range(1, len(cles) + 1):
                f.cell(ligne, j).border = cadre
        ligne += 1
        f.cell(ligne, 1, "TOTAL")
        for j, cle in enumerate(cles, start=1):
            c = f.cell(ligne, j)
            c.font, c.fill, c.border = gras, total_fond, cadre
            if cle in nombres:
                lettre = c.column_letter
                c.value = f"=SUM({lettre}{premiere}:{lettre}{ligne - 1})"
                c.number_format = format_f
        f.freeze_panes = f.cell(premiere, 1)

        # récapitulatif
        t = b["totaux"]
        recap = [("Loyers encaissés", t["encaisse"]), ("Cautions perçues (non reversées)", t["cautions"])]
        if finances:
            recap += [("Commission de l'agence", t["commission"]), ("Part du propriétaire", t["part_proprietaire"]),
                      ("Dépenses à la charge du propriétaire", t["depenses_proprietaire"]),
                      ("Net à reverser au propriétaire", t["net_a_reverser"])]
        recap += [("Loyers impayés", t["impaye"]), ("Total des dépenses", t["depenses"])]
        ligne += 2
        f.cell(ligne, 1, "Récapitulatif").font = Font(bold=True, color=marine, size=12)
        for libelle, valeur in recap:
            ligne += 1
            f.cell(ligne, 1, libelle)
            c = f.cell(ligne, 5, float(valeur))
            c.number_format = format_f
            if libelle.startswith("Net"):
                f.cell(ligne, 1).font = c.font = gras

        # rapport sur plusieurs mois (annuel) : mois par mois
        if b.get("par_mois"):
            ligne += 2
            f.cell(ligne, 1, "Mois par mois").font = Font(bold=True, color=marine, size=12)
            ligne += 1
            entetes = [("Mois", "mois"), ("Loyers encaissés", "encaisse")]
            if finances:
                entetes += [("Commission agence", "commission"), ("Part propriétaire", "part_proprietaire")]
            entetes += [("Dépenses", "depenses")]
            if finances:
                entetes += [("Net à reverser", "net_a_reverser")]
            entetes += [("Loyers impayés", "impaye")]
            for j, (titre, _) in enumerate(entetes, start=1):
                c = f.cell(ligne, j, titre)
                c.font, c.fill, c.border = entete_police, entete_fond, cadre
            for m in b["par_mois"]:
                ligne += 1
                for j, (_, cle) in enumerate(entetes, start=1):
                    c = f.cell(ligne, j, m[cle] if cle == "mois" else float(m[cle]))
                    c.border = cadre
                    if cle != "mois":
                        c.number_format = format_f

        # détail des dépenses
        ligne += 2
        f.cell(ligne, 1, "Détail des dépenses").font = Font(bold=True, color=marine, size=12)
        ligne += 1
        for j, titre in enumerate(("Date", "Logement", "Motif", "Catégorie", "À la charge de", "Montant"), start=1):
            c = f.cell(ligne, j, titre)
            c.font, c.fill, c.border = entete_police, entete_fond, cadre
        for d in b["detail_depenses"]:
            ligne += 1
            valeurs = ("/".join(reversed(d["date"].split("-"))), d["logement"], d["motif"], d["categorie"],
                       d["a_la_charge_de"], float(d["montant"]))
            for j, v in enumerate(valeurs, start=1):
                c = f.cell(ligne, j, v)
                c.border = cadre
            c.number_format = format_f
        if not b["detail_depenses"]:
            f.cell(ligne + 1, 1, "Aucune dépense sur la période.").font = Font(italic=True, color="5C655E")
    tampon = io.BytesIO()
    classeur.save(tampon)
    return tampon.getvalue()


@router.get("/rapports/par-bien/excel")
def rapport_par_bien_excel(cite_id: list[int] | None = Query(None), debut: date | None = Query(None),
                           fin: date | None = Query(None), utilisateur: Utilisateur = Depends(acces_rapports),
                           db: SessionDB = Depends(get_db)):
    rapport = _charger(db, utilisateur, debut, fin, cite_id)
    return Response(classeur_excel(rapport),
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{_nom_fichier(rapport, "xlsx")}"'})

