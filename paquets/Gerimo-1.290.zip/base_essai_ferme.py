"""Base d'essai réservée à la Ferme (22/11/2026, demande de Boss : « une base distincte des autres métiers »).

Lancement, dans le terminal (venv activé) :
    python base_essai_ferme.py            → crée (si besoin) la base vide « gerimo_essai_ferme » et y branche le dossier d'essai
    python base_essai_ferme.py --revenir  → rebranche le dossier d'essai sur l'ancienne base « gerimo_essai »

Comme chez un nouveau client : base neuve (schema.sql + migrations), aucun loyer ni bien ni locataire. Seuls les comptes
(identifiants et mots de passe déjà hachés) sont recopiés depuis « gerimo_essai », pour se connecter comme d'habitude.
Le dossier d'essai démarre sur le métier Ferme (ligne GERIMO_METIERS=ferme du .env) ; l'Admin peut en cocher d'autres
dans Paramètres (ses cases passent avant cette ligne). La vraie base « isup_erp » n'est jamais touchée.
Seule la ligne DB_NAME du .env change (le mot de passe n'est ni affiché ni modifié). Ensuite : relancer demarrer.bat.
"""
import os
import re
import sys
from pathlib import Path

import psycopg2
from dotenv import dotenv_values
from psycopg2 import sql

RACINE = Path(__file__).parent
BASE_FERME = "gerimo_essai_ferme"
BASE_ESSAI = "gerimo_essai"
VRAIE_BASE = "isup_erp"


def brancher(chemin_env: Path, base: str) -> None:
    """DB_NAME = la base choisie ; base Ferme : GERIMO_METIERS=ferme (seul le métier Ferme s'affiche dans le dossier
    d'essai ; les tests, eux, ouvrent toujours tous les métiers). Aucune autre ligne n'est touchée."""
    texte = chemin_env.read_text(encoding="utf-8")
    nouveau = re.sub(r"(?m)^DB_NAME=.*$", f"DB_NAME={base}", texte)
    nouveau = re.sub(r"(?m)^GERIMO_METIERS=.*\n?", "", nouveau)
    if base == BASE_FERME:
        nouveau = nouveau.rstrip("\n") + "\nGERIMO_METIERS=ferme\n"
    if nouveau != texte:
        provisoire = chemin_env.with_name(".env.tmp")
        provisoire.write_text(nouveau, encoding="utf-8")
        provisoire.replace(chemin_env)


def main() -> None:
    chemin_env = RACINE / ".env"
    env = dotenv_values(chemin_env)
    if env.get("DB_NAME") == VRAIE_BASE:
        sys.exit("❌ Le dossier de développement est branché sur la vraie base : lancez d'abord creer_base_essai.py.")
    if "--revenir" in sys.argv:
        brancher(chemin_env, BASE_ESSAI)
        import subprocess   # l'ancienne base reçoit les nouvelles tables faites entre-temps (migrations)
        subprocess.run([sys.executable, "migrer.py"], cwd=RACINE, env={**os.environ, "DB_NAME": BASE_ESSAI}, check=False)
        print(f"✅ Le dossier d'essai travaille de nouveau sur « {BASE_ESSAI} ». Relancez demarrer.bat.")
        return

    hote, port = env.get("DB_HOST") or "localhost", str(env.get("DB_PORT") or 5432)
    utilisateur, mot_de_passe = env.get("DB_USER"), env.get("DB_PASSWORD") or ""
    connecter = lambda base: psycopg2.connect(host=hote, port=port, dbname=base, user=utilisateur, password=mot_de_passe)  # noqa: E731

    admin = connecter("postgres")
    admin.autocommit = True
    with admin.cursor() as c:
        c.execute("SELECT 1 FROM pg_database WHERE datname = %s", (BASE_FERME,))
        nouvelle = c.fetchone() is None
        if nouvelle:
            c.execute(sql.SQL("CREATE DATABASE {} ENCODING 'UTF8' TEMPLATE template0").format(sql.Identifier(BASE_FERME)))
    admin.close()

    # structure : comme à l'installation chez un client (schema.sql la première fois, puis toutes les migrations)
    base = connecter(BASE_FERME)
    base.autocommit = True
    with base.cursor() as c:
        c.execute("SELECT to_regclass('public.utilisateurs')")
        if c.fetchone()[0] is None:
            c.execute((RACINE / "schema.sql").read_text(encoding="utf-8"))
        for fichier in sorted((RACINE / "migrations").glob("*.sql")):
            c.execute(fichier.read_text(encoding="utf-8"))
        print("✅ Structure à jour (schema.sql + migrations)")

        # comptes recopiés depuis la base d'essai (mêmes identifiants, mots de passe déjà hachés)
        source = connecter(BASE_ESSAI)
        with source.cursor() as s:
            s.execute("SELECT nom_complet, identifiant, mot_de_passe, role::text, actif, fonction FROM utilisateurs "
                      "WHERE identifiant <> 'claude_essai'")   # compte temporaire de vérification : jamais recopié
            comptes = s.fetchall()
        source.close()
        ajoutes = 0
        for nom, ident, mdp, role, actif, fonction in comptes:
            c.execute("SELECT 1 FROM utilisateurs WHERE identifiant = %s", (ident,))
            if c.fetchone() is None:
                c.execute("INSERT INTO utilisateurs (nom_complet, identifiant, mot_de_passe, role, actif, fonction) "
                          "VALUES (%s, %s, %s, %s, %s, %s)", (nom, ident, mdp, role, actif, fonction))
                ajoutes += 1
        print(f"✅ Comptes recopiés : {ajoutes} (déjà là : {len(comptes) - ajoutes})")

        # essai : on démarre sur le métier Ferme (ligne GERIMO_METIERS du .env, voir brancher) ; cases remises à zéro
        c.execute("DELETE FROM parametres WHERE cle = 'essai_metiers'")

        # comme migrer.py : la base est confiée au compte de Gérimo Serveur (sinon « permission denied »)
        sys.path.insert(0, str(RACINE))
        from compte_base import ROLE, confier_la_base
        c.execute("SELECT rolsuper FROM pg_roles WHERE rolname = current_user")
        super_admin = c.fetchone()[0]
        c.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (ROLE,))
        if super_admin and c.fetchone():
            confier_la_base(c, ROLE, BASE_FERME)
    base.close()

    brancher(chemin_env, BASE_FERME)
    print(f"✅ Base d'essai Ferme prête{' (nouvelle)' if nouvelle else ''}. Le dossier d'essai travaille maintenant sur "
          f"« {BASE_FERME} ». Relancez demarrer.bat. Pour revenir : python base_essai_ferme.py --revenir")


if __name__ == "__main__":
    main()
