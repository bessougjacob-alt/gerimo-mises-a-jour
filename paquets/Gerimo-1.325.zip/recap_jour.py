"""Récapitulatif du matin (demande de Boss du 26/11/2026).

À la première ouverture de Gérimo de la journée, une fenêtre résume ce qui attend l'utilisateur, selon ses droits :
loyers attendus dans les 5 jours (dont aujourd'hui), loyers en retard, contrats qui se terminent dans les 30 jours,
états des lieux à faire. Chaque ligne mène à l'écran concerné ; « Relancer les retards » ouvre l'envoi en série.
"""
from datetime import date, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as SessionDB

from commun import montant
from models import STATUTS_EN_COURS, Utilisateur
from securite import get_db, peut_acceder, utilisateur_connecte

router = APIRouter(prefix="/api")


@router.get("/recap-du-jour")
def recap_du_jour(utilisateur: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    role = utilisateur.role.value
    aujourdhui = date.today()
    recap: dict = {"date": aujourdhui.strftime("%d/%m/%Y"), "lignes": []}

    if peut_acceder(role, "paiements"):
        import paiements
        contrats = paiements.contrats_du_perimetre(db, utilisateur)
        paiements.recalculer_tout(db, contrats)
        en_cours = [c for c in contrats if c.statut_contrat in STATUTS_EN_COURS]
        limite = aujourdhui + timedelta(days=5)
        attendues = [e for c in en_cours for e in c.echeances
                     if e.paiement is None and aujourdhui <= e.date_limite <= limite]
        du_jour = [e for e in attendues if e.date_limite == aujourdhui]
        if attendues:
            recap["lignes"].append({
                "genre": "attendus", "ecran": "paiements", "nombre": len(attendues),
                "montant": montant(sum((e.reste for e in attendues), Decimal(0))),
                "texte": f"{len(attendues)} loyer(s) attendu(s) d'ici le {limite.strftime('%d/%m')}"
                         + (f", dont {len(du_jour)} aujourd'hui" if du_jour else "")})
        retards = [r for r in (paiements.resume_impayes(c, aujourdhui) for c in contrats) if r]
        if retards:
            recap["lignes"].append({
                "genre": "retards", "ecran": "paiements", "nombre": len(retards),
                "montant": montant(sum((Decimal(str(r["montant"])) for r in retards), Decimal(0))),
                "a_risque": sum(1 for r in retards if r["a_risque"]),
                "texte": f"{len(retards)} locataire(s) en retard de paiement"})

    if peut_acceder(role, "contrats"):
        import paiements
        fin = aujourdhui + timedelta(days=30)
        bientot = [c for c in paiements.contrats_du_perimetre(db, utilisateur)
                   if c.statut_contrat in STATUTS_EN_COURS and c.date_fin and aujourdhui <= c.date_fin <= fin]
        if bientot:
            recap["lignes"].append({
                "genre": "fins", "ecran": "contrats", "nombre": len(bientot),
                "texte": f"{len(bientot)} contrat(s) se termine(nt) d'ici le {fin.strftime('%d/%m/%Y')}",
                "noms": [f"{c.locataire.nom_complet} ({c.date_fin.strftime('%d/%m')})" for c in bientot[:4]]})

    if peut_acceder(role, "etats_des_lieux"):
        import etats_des_lieux
        a_faire = etats_des_lieux.liste(utilisateur, db)["a_faire"]
        if a_faire:
            recap["lignes"].append({
                "genre": "edl", "ecran": "etats_des_lieux", "nombre": len(a_faire),
                "texte": f"{len(a_faire)} état(s) des lieux à faire"})
    return recap
