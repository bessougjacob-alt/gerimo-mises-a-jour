// Ferme, étape 3 (22/11/2026) : santé (vaccins prévus et faits, traitements), pesées, visites du vétérinaire.
// Même style que la Ferme (ferme.js). Le serveur (ferme_sante.py) revérifie tout.
// Règle de Boss : un soin est NOTÉ ; le produit ne sort du stock que si le flacon est fini (case « il reste du produit »).

let santeFerme = null, peseesFerme = null, visitesFerme = null;
const ETAT_VACCIN = { retard: ["rouge", "En retard"], aujourdhui: ["jaune", "Aujourd'hui"], demain: ["jaune", "Demain"],
                      prevu: ["vert", "Prévu"], fait: ["gris", "Fait"] };

// Santé = vaccins, traitements ET visites du vétérinaire (demande de Boss du 22/11/2026)
Object.assign(ONGLETS_FERME, { frSante: () => { chargerSanteFerme(); chargerVisitesFerme(); }, frPesees: () => chargerPeseesFerme() });

const bandeLigne = (dessin, nom, sous) => `<span class="fe-bande">${imgFerme(dessin || "animal")}<span><b>${esc(nom)}</b>${sous ? `<small>${esc(sous)}</small>` : ""}</span></span>`;

// ---------- Santé ----------

async function chargerSanteFerme() {
  const zone = el("zoneSanteFerme");
  try { santeFerme = await api("/api/ferme/sante"); if (!tableauFerme) await chargerTableauFerme(); } catch (e) { erreurFerme(zone, e); return; }
  const s = santeFerme;
  const retard = s.a_faire.filter(l => l.etat === "retard").length;
  const bientot = s.a_faire.filter(l => l.etat === "aujourdhui" || l.etat === "demain").length;
  const epuises = new Set(s.a_faire.filter(l => l.epuise).map(l => l.produit)).size;
  zone.innerHTML = `
    <div class="fe-chiffres">
      <div class="fe-chiffre ${retard ? "rouge" : "vert"}">${imgFerme("vaccin", "fe-chiffre-img")}<span><b>${retard}</b><span class="fe-chiffre-libelle">Vaccin${retard > 1 ? "s" : ""} en retard</span><small>${retard ? "à faire au plus vite" : "rien en retard 👍"}</small></span></div>
      <div class="fe-chiffre ${bientot ? "jaune" : "vert"}">${imgFerme("vaccin", "fe-chiffre-img")}<span><b>${bientot}</b><span class="fe-chiffre-libelle">Aujourd'hui ou demain</span><small>vaccins prévus</small></span></div>
      ${epuises ? `<button type="button" class="fe-chiffre rouge" onclick="ongletFerme='frAchats'; montrerOngletFerme('frAchats')">${imgFerme("medicament", "fe-chiffre-img")}<span><b>${epuises}</b><span class="fe-chiffre-libelle">Produit${epuises > 1 ? "s" : ""} épuisé${epuises > 1 ? "s" : ""}</span><small>prévoyez un achat</small></span></button>` : ""}
    </div>
    <div class="fe-barre"><div class="fe-boutons">
      ${s.est_admin ? '<button class="btn" onclick="fenetreProgrammeFerme()">Programme des vaccins</button>' : ""}
      ${s.soigne ? '<button class="btn primary" onclick="formulaireSoinFerme(null)">+ Noter un traitement</button>' : ""}
    </div></div>
    <div class="fe-carte"><div class="fe-dette-tete"><h3>Vaccins à faire</h3><span class="fe-aide" style="margin:0">en retard et dans les ${14} jours</span></div>
      ${s.a_faire.length ? `<div class="fe-tableau"><table><thead><tr><th>Lot</th><th>Vaccin</th><th>Prévu le</th><th>État</th><th>Produit</th><th></th></tr></thead><tbody>
        ${s.a_faire.map((l, i) => `<tr>
          <td data-titre="Lot">${bandeLigne(l.dessin, l.bande, `${l.batiment} · ${l.jour_age} jours`)}</td>
          <td data-titre="Vaccin"><b>${esc(l.nom)}</b>${l.mode ? `<br><small class="fe-aide">${esc(l.mode)}</small>` : ""}</td>
          <td data-titre="Prévu le">${formatDate(l.date)}</td><td data-titre="État">${pastilleFerme(ETAT_VACCIN[l.etat])}</td>
          <td data-titre="Produit">${l.produit ? (l.epuise ? `<span class="fe-pastille rouge">${esc(l.produit)} : épuisé</span>` : esc(l.produit)) : "—"}</td>
          <td>${s.soigne ? `<button class="btn primary" onclick="formulaireSoinFerme(santeFerme.a_faire[${i}])">C'est fait</button>` : ""}</td></tr>`).join("")}
      </tbody></table></div>` : `<div class="fe-vide">${imgFerme("vaccin", "fe-vide-img")}<p>Aucun vaccin à faire pour l'instant.${s.est_admin && !s.programme.length ? "<br>Écrivez d'abord le programme des vaccins de chaque espèce." : ""}</p></div>`}
    </div>
    <div class="fe-carte"><h3 class="fe-titre" style="margin-top:0">Derniers soins notés</h3>
      ${s.derniers.length ? `<div class="fe-tableau"><table><thead><tr><th>Date</th><th>Lot</th><th>Soin</th><th>Produit</th><th>Flacon</th><th>Noté par</th></tr></thead><tbody>
        ${s.derniers.map(x => `<tr${s.est_admin ? ` class="fe-ligne" onclick="supprimerSoinFerme(${x.id})" data-tip="Cliquez pour supprimer ce soin"` : ""}>
          <td data-titre="Date">${formatDate(x.date)}</td><td data-titre="Lot">${esc(x.bande)} <small class="fe-aide">${esc(x.batiment)}</small></td>
          <td data-titre="Soin"><b>${esc(x.nom)}</b> <small class="fe-aide">${esc(x.genre)}</small></td><td data-titre="Produit">${esc(x.produit) || "—"}</td>
          <td data-titre="Flacon">${x.produit ? (x.finis ? `fini (${esc(x.finis_texte)})` : "reste du produit") : "—"}</td><td data-titre="Noté par"><small>${esc(x.saisi_par)}</small></td></tr>`).join("")}
      </tbody></table></div>` : '<p class="fe-aide">Aucun soin noté pour l\'instant.</p>'}
    </div>`;
}

async function formulaireSoinFerme(prevu, bandeId = null) {
  try { if (!santeFerme) santeFerme = await api("/api/ferme/sante"); } catch (e) { toast(e.message); return; }
  const s = santeFerme;
  if (!s.bandes.length) { toast("Aucune lot en cours."); return; }
  let genre = prevu ? "Vaccin" : "Traitement";
  const choixBande = prevu ? prevu.bande_id : bandeId;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme(prevu ? "vaccin" : "medicament", "fe-fiche-img")}<div><h2>${prevu ? `Vaccin ${esc(prevu.nom)} fait` : "Noter un soin"}</h2>
      <p>${prevu ? `${esc(prevu.bande)} · prévu le ${formatDate(prevu.date)}` : "Un vaccin ou un traitement donné à un lot."}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    ${prevu ? "" : `<div class="fe-choix-types fe-choix-genres"><button type="button" class="fe-choix-type" data-genre="Vaccin">${imgFerme("vaccin", "fe-choix-img")}<b>Vaccin</b></button>
      <button type="button" class="fe-choix-type choisi" data-genre="Traitement">${imgFerme("medicament", "fe-choix-img")}<b>Traitement</b><small>médicament, vitamines…</small></button></div>`}
    <div class="fgrid" style="margin-top:1rem">
      <div class="field"><label for="soBandeS">Lot</label><select id="soBandeS"${prevu ? " disabled" : ""}>${s.bandes.map(b => `<option value="${b.id}"${b.id === choixBande ? " selected" : ""}>${esc(b.nom)} (${esc(b.batiment)})</option>`).join("")}</select></div>
      ${prevu ? "" : '<div class="field"><label for="soNom">Nom du soin</label><input id="soNom" maxlength="100" placeholder="ex : Vitamines anti-stress"></div>'}
      <div class="field"><label for="soProduitS">Produit utilisé</label><select id="soProduitS"><option value="">— aucun produit du stock —</option>
        ${s.produits.map(p => `<option value="${p.id}"${prevu && prevu.produit_id === p.id ? " selected" : ""}${p.stock <= 0 ? " disabled" : ""}>${esc(p.nom)} — ${p.stock <= 0 ? "épuisé" : esc(p.stock_texte)}</option>`).join("")}</select></div>
      <div class="field"><label for="soMode">Comment</label><select id="soMode"><option value="">—</option>${s.modes.map(m => `<option${prevu && prevu.mode === m ? " selected" : ""}>${esc(m)}</option>`).join("")}</select></div>
      <div class="field"><label for="soDateS">Fait le</label><input id="soDateS" type="date"></div>
    </div>
    <div id="soFlacon">
      <label class="case fe-case-flacon"><input type="checkbox" id="soReste" checked> Il reste du produit dans le flacon (ou le sachet) : rien ne sort du stock</label>
      <div class="field" id="soChampFinis" style="display:none;max-width:260px"><label for="soFinis" id="soLibFinis">Flacons finis</label><input id="soFinis" inputmode="decimal" value="1"></div>
    </div>
    <div class="field"><label for="soNote">Note (facultatif)</label><input id="soNote" maxlength="300"></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "large fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#soDateS").value = formatDate(prevu && prevu.date < aujourdhui() && prevu.etat !== "retard" ? prevu.date : aujourdhui());
  const majFlacon = () => {
    const p = s.produits.find(x => x.id === Number(fen.querySelector("#soProduitS").value));
    fen.querySelector("#soFlacon").style.display = p ? "" : "none";
    fen.querySelector("#soChampFinis").style.display = p && !fen.querySelector("#soReste").checked ? "" : "none";
    if (p) fen.querySelector("#soLibFinis").textContent = `Combien de ${p.unite}(s) sont finis ?`;
  };
  majFlacon();
  fen.querySelector("#soProduitS").addEventListener("change", majFlacon);
  fen.querySelector("#soReste").addEventListener("change", majFlacon);
  const genres = fen.querySelector(".fe-choix-genres");
  if (genres) genres.addEventListener("click", e => {
    const x = e.target.closest("[data-genre]"); if (!x) return;
    genre = x.dataset.genre;
    genres.querySelectorAll(".fe-choix-type").forEach(y => y.classList.toggle("choisi", y === x));
  });
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const date = isoDepuisTexte(fen.querySelector("#soDateS").value);
      if (!date) throw new Error("Date incorrecte : écrivez-la comme 02/12/2026.");
      const produit = fen.querySelector("#soProduitS").value ? Number(fen.querySelector("#soProduitS").value) : null;
      const reste = fen.querySelector("#soReste").checked;
      const finis = lireNombreFerme(fen.querySelector("#soFinis").value);
      if (produit && !reste && !finis) throw new Error("Indiquez combien de flacons (sachets…) sont finis.");
      const corps = { bande_id: Number(fen.querySelector("#soBandeS").value), genre, programme_id: prevu ? prevu.programme_id : null,
                      nom: prevu ? null : fen.querySelector("#soNom").value.trim() || null, produit_id: produit, reste_produit: reste,
                      finis: finis || 1, mode: fen.querySelector("#soMode").value || null, date_soin: date, note: fen.querySelector("#soNote").value.trim() || null };
      if (!prevu && !corps.nom) throw new Error("Indiquez le nom du soin.");
      ok.disabled = true;
      const r = await api("/api/ferme/soins", { method: "POST", body: corps });
      fen.fermer();
      toast(r.epuise ? `C'est noté. Attention : plus aucun « ${r.produit} » en stock, prévoyez un achat.` : "C'est noté 👍", r.epuise ? 8000 : 3000);
      santeFerme = null;
      montrerOngletFerme(ongletFerme);
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

async function supprimerSoinFerme(id) {
  const x = santeFerme.derniers.find(s => s.id === id);
  const mdp = await demanderMotDePasseAdmin(`Supprimer le soin « ${x ? x.nom : ""} » ? Un flacon noté fini reviendra dans le stock. Entrez votre mot de passe.`);
  if (!mdp) return;
  try { await api(`/api/ferme/soins/${id}/supprimer`, { method: "POST", body: { mot_de_passe_admin: mdp } }); toast("Soin supprimé"); chargerSanteFerme(); }
  catch (e) { toast(e.message, 7000); }
}

// ---------- Programme des vaccins (Admin) ----------

function fenetreProgrammeFerme() {
  const s = santeFerme;
  const especes = s.especes.filter(e => true);
  const parEspece = especes.map(e => [e, s.programme.filter(p => p.espece === e)]);
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("vaccin", "fe-fiche-img")}<div><h2>Programme des vaccins</h2><p>Écrit une fois pour chaque espèce : Gérimo prévoit les dates de chaque lot. À faire valider par votre vétérinaire.</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    ${parEspece.map(([e, liste]) => `<div class="fe-dette-tete" style="margin-top:1rem"><h3>${imgType(e, "fe-case-img")} ${esc(e)}</h3><button class="btn" data-ajout="${esc(e)}">+ Vaccin</button></div>
      ${liste.length ? `<div class="fe-tableau fe-fond-blanc"><table><thead><tr><th class="nb">À l'âge de</th><th>Vaccin</th><th>Produit</th><th>Comment</th></tr></thead><tbody>
        ${liste.map(p => `<tr class="fe-ligne" data-prog="${p.id}"><td class="nb"><b>${plurielFerme(p.jour_age, "jour")}</b></td><td>${esc(p.nom)}</td><td>${esc(p.produit) || "—"}</td><td>${esc(p.mode) || "—"}</td></tr>`).join("")}
      </tbody></table></div>` : '<p class="fe-aide">Aucun vaccin au programme.</p>'}`).join("")}
    <div class="actions"><button class="btn" data-fermer>Fermer</button></div></div>`, { taille: "large fe-fenetre" });
  fen.querySelectorAll("[data-ajout]").forEach(b => b.addEventListener("click", () => { fen.fermer(); formulaireProgrammeFerme(null, b.dataset.ajout); }));
  fen.querySelectorAll("[data-prog]").forEach(tr => tr.addEventListener("click", () => { fen.fermer(); formulaireProgrammeFerme(s.programme.find(p => p.id === Number(tr.dataset.prog))); }));
}

function formulaireProgrammeFerme(p, espece = null) {
  const s = santeFerme;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgType(p ? p.espece : espece, "fe-fiche-img")}<div><h2>${p ? "Modifier le vaccin" : "Ajouter un vaccin"}</h2><p>${esc(p ? p.espece : espece)}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field"><label for="pgJour">À l'âge de (jours)</label><input id="pgJour" inputmode="numeric" value="${p ? p.jour_age : ""}" placeholder="ex : 7"></div>
      <div class="field"><label for="pgNom">Vaccin</label><input id="pgNom" maxlength="100" value="${esc(p ? p.nom : "")}" placeholder="ex : Gumboro"></div>
      <div class="field"><label for="pgProduit">Produit du stock (facultatif)</label><select id="pgProduit"><option value="">—</option>
        ${s.produits.map(x => `<option value="${x.id}"${p && p.produit_id === x.id ? " selected" : ""}>${esc(x.nom)}</option>`).join("")}</select></div>
      <div class="field"><label for="pgMode">Comment</label><select id="pgMode"><option value="">—</option>${s.modes.map(m => `<option${p && p.mode === m ? " selected" : ""}>${esc(m)}</option>`).join("")}</select></div>
    </div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions">${p ? '<button class="btn ghost" data-action="sup">Retirer du programme</button>' : ""}<button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "fe-fenetre" });
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const jour = lireEntierFerme(fen.querySelector("#pgJour").value);
      if (jour === null || fen.querySelector("#pgJour").value.trim() === "") throw new Error("Indiquez l'âge en jours.");
      const nom = fen.querySelector("#pgNom").value.trim();
      if (nom.length < 2) throw new Error("Indiquez le nom du vaccin.");
      ok.disabled = true;
      await api(p ? `/api/ferme/programme/${p.id}` : "/api/ferme/programme", { method: p ? "PUT" : "POST", body: {
        espece: p ? p.espece : espece, jour_age: jour, nom, produit_id: fen.querySelector("#pgProduit").value ? Number(fen.querySelector("#pgProduit").value) : null,
        mode: fen.querySelector("#pgMode").value || null } });
      fen.fermer();
      santeFerme = await api("/api/ferme/sante");
      fenetreProgrammeFerme();
      chargerSanteFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
  const sup = fen.querySelector('[data-action="sup"]');
  if (sup) sup.addEventListener("click", async () => {
    const mdp = await demanderMotDePasseAdmin(`Retirer « ${p.nom} » du programme ? Entrez votre mot de passe.`);
    if (!mdp) return;
    try { await api(`/api/ferme/programme/${p.id}/supprimer`, { method: "POST", body: { mot_de_passe_admin: mdp } }); fen.fermer(); santeFerme = await api("/api/ferme/sante"); fenetreProgrammeFerme(); chargerSanteFerme(); }
    catch (e) { toast(e.message, 7000); }
  });
}

// ---------- Pesées ----------

const pastillePoids = pc => pc === null || pc === undefined ? "—" : `<span class="fe-pastille ${pc >= 95 ? "vert" : pc >= 85 ? "jaune" : "rouge"}">${pc} %</span>`;

async function chargerPeseesFerme() {
  const zone = el("zonePeseesFerme");
  try { peseesFerme = await api("/api/ferme/pesees"); if (!tableauFerme) await chargerTableauFerme(); } catch (e) { erreurFerme(zone, e); return; }
  const p = peseesFerme;
  zone.innerHTML = `<div class="fe-barre"><div class="fe-boutons">
      ${p.est_admin ? '<button class="btn" onclick="fenetreReferencesFerme()">Poids attendus</button>' : ""}
      ${p.soigne ? '<button class="btn primary" onclick="formulairePeseeFerme(null)">+ Noter une pesée</button>' : ""}</div></div>
    <div class="fe-carte">${p.bandes.length ? `<div class="fe-tableau"><table><thead><tr><th>Lot</th><th class="nb">Âge</th><th class="nb">Dernière pesée</th><th class="nb">Attendu</th><th>Croissance</th><th></th></tr></thead><tbody>
      ${p.bandes.map(b => `<tr class="fe-ligne" onclick="ouvrirCourbeFerme(${b.id})" tabindex="0">
        <td data-titre="Lot">${bandeLigne(b.dessin, b.nom, b.batiment)}</td><td data-titre="Âge" class="nb">${plurielFerme(b.age, "jour")}</td>
        <td data-titre="Dernière pesée" class="nb">${b.derniere ? `<b class="fe-gros">${nbFerme(b.derniere.poids_g)} g</b><br><small class="fe-aide">le ${formatDate(b.derniere.date)}</small>` : "—"}</td>
        <td data-titre="Attendu" class="nb">${b.derniere && b.derniere.attendu_g ? `${nbFerme(b.derniere.attendu_g)} g` : b.attendu_aujourdhui ? `${nbFerme(b.attendu_aujourdhui)} g aujourd'hui` : "—"}</td>
        <td data-titre="Croissance">${b.derniere ? pastillePoids(b.derniere.pour_cent) : '<span class="fe-pastille gris">Pas encore pesée</span>'}</td>
        <td>${p.soigne ? `<button class="btn" onclick="event.stopPropagation(); formulairePeseeFerme(${b.id})">Peser</button>` : ""}</td></tr>`).join("")}
    </tbody></table></div>` : `<div class="fe-vide">${imgFerme("ferme", "fe-vide-img")}<p>Aucun lot en cours.</p></div>`}</div>
    <p class="fe-aide">Pesez 10 à 20 animaux pris au hasard : Gérimo calcule le poids moyen et le compare au poids attendu pour l'âge.</p>`;
}

async function formulairePeseeFerme(bandeId) {
  try { if (!peseesFerme) peseesFerme = await api("/api/ferme/pesees"); } catch (e) { toast(e.message); return; }
  const bandes = peseesFerme.bandes;
  if (!bandes.length) { toast("Aucune lot en cours."); return; }
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme(bandeId ? (bandes.find(x => x.id === bandeId) || {}).dessin || "ferme" : "ferme", "fe-fiche-img")}<div><h2>Noter une pesée</h2><p>Pesez quelques animaux ensemble ou un par un, puis écrivez le total.</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field"><label for="peBande">Lot</label><select id="peBande">${bandes.map(b => `<option value="${b.id}"${b.id === bandeId ? " selected" : ""}>${esc(b.nom)} (${esc(b.batiment)})</option>`).join("")}</select></div>
      <div class="field"><label for="peDate">Date</label><input id="peDate" type="date"></div>
      <div class="field"><label for="peNombre">Nombre d'animaux pesés</label><input id="peNombre" inputmode="numeric" placeholder="ex : 20"></div>
      <div class="field"><label for="peTotal">Poids total (kg)</label><input id="peTotal" inputmode="decimal" placeholder="ex : 18,4"></div>
    </div>
    <div class="fe-fiche-grand vert"><b id="peMoyenne">—</b><span id="peAide">poids moyen d'un animal</span></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#peDate").value = formatDate(aujourdhui());
  const moyenne = () => {
    const n = lireEntierFerme(fen.querySelector("#peNombre").value), t = lireNombreFerme(fen.querySelector("#peTotal").value);
    return n && t ? Math.round(t * 1000 / n * 10) / 10 : null;
  };
  const maj = () => {
    const m = moyenne(), b = bandes.find(x => x.id === Number(fen.querySelector("#peBande").value));
    fen.querySelector("#peMoyenne").textContent = m ? `${nbFerme(m)} g` : "—";
    fen.querySelector("#peAide").textContent = m && b && b.attendu_aujourdhui ? `poids moyen · ${nbFerme(b.attendu_aujourdhui)} g attendus à ${b.age} jours` : "poids moyen d'un animal";
  };
  ["#peNombre", "#peTotal", "#peBande"].forEach(c => fen.querySelector(c).addEventListener("input", maj));
  fen.querySelector("#peBande").addEventListener("change", maj);
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const m = moyenne();
      if (!m) throw new Error("Indiquez le nombre d'animaux pesés et leur poids total.");
      const date = isoDepuisTexte(fen.querySelector("#peDate").value);
      if (!date) throw new Error("Date incorrecte : écrivez-la comme 02/12/2026.");
      ok.disabled = true;
      const r = await api("/api/ferme/pesees", { method: "POST", body: { bande_id: Number(fen.querySelector("#peBande").value), date_pesee: date,
        nombre: lireEntierFerme(fen.querySelector("#peNombre").value), poids_moyen_g: m } });
      fen.fermer();
      toast(r.lent ? `Pesée notée : ${nbFerme(r.poids_g)} g, c'est ${r.pour_cent} % du poids attendu. Vérifiez l'aliment et la santé.` : `Pesée notée : ${nbFerme(r.poids_g)} g 👍`, r.lent ? 8000 : 3000);
      peseesFerme = null;
      montrerOngletFerme(ongletFerme);
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

// Courbe de croissance : pesées (trait plein) et poids attendu (pointillés)
function courbePoidsFerme(pesees, reference) {
  const points = pesees.map(p => [p.age, p.poids_g]);
  const ref = reference || [];
  const tous = [...points, ...ref.filter(r => !points.length || r[0] <= Math.max(...points.map(p => p[0])) + 14)];
  if (!tous.length) return '<p class="fe-aide">Pas encore de pesée ni de poids attendu.</p>';
  const L = 560, H = 220, m = 36;
  const xmax = Math.max(...tous.map(p => p[0]), 1), ymax = Math.max(...tous.map(p => p[1]), 1) * 1.1;
  const X = a => m + a / xmax * (L - m - 10), Y = v => H - m + 6 - v / ymax * (H - m - 10);
  const ligne = pts => pts.map((p, i) => `${i ? "L" : "M"}${X(p[0]).toFixed(1)} ${Y(p[1]).toFixed(1)}`).join(" ");
  const refVue = ref.filter(r => r[0] <= xmax);
  return `<svg class="fe-courbe" viewBox="0 0 ${L} ${H}" role="img" aria-label="Courbe de croissance">
    <line x1="${m}" y1="${H - m + 6}" x2="${L - 10}" y2="${H - m + 6}" stroke="#ddc998"/><line x1="${m}" y1="10" x2="${m}" y2="${H - m + 6}" stroke="#ddc998"/>
    <text x="${m + 6}" y="20" text-anchor="start" font-size="11" fill="#5e4522">${nbFerme(Math.round(ymax))} g</text>
    <text x="${L - 10}" y="${H - 8}" text-anchor="end" font-size="11" fill="#5e4522">${xmax} jours</text>
    ${refVue.length > 1 ? `<path d="${ligne(refVue)}" fill="none" stroke="#bf9453" stroke-width="2" stroke-dasharray="6 5"/>` : ""}
    ${points.length > 1 ? `<path d="${ligne(points)}" fill="none" stroke="#3f760b" stroke-width="3"/>` : ""}
    ${points.map(p => `<circle cx="${X(p[0]).toFixed(1)}" cy="${Y(p[1]).toFixed(1)}" r="4.5" fill="#3f760b"><title>${p[0]} jours : ${nbFerme(p[1])} g</title></circle>`).join("")}
  </svg><p class="fe-aide"><b style="color:#3f760b">━</b> pesées · <b style="color:#bf9453">┅</b> poids attendu</p>`;
}

function ouvrirCourbeFerme(id) {
  const b = peseesFerme.bandes.find(x => x.id === id);
  if (!b) return;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme(b.dessin, "fe-fiche-img")}<div><h2>${esc(b.nom)}</h2><p>${esc(b.batiment)} · ${plurielFerme(b.age, "jour")}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fe-fond-blanc">${courbePoidsFerme(b.pesees, peseesFerme.references[b.espece])}</div>
    ${b.pesees.length ? `<div class="fe-tableau fe-fond-blanc" style="margin-top:1rem"><table><thead><tr><th>Date</th><th class="nb">Âge</th><th class="nb">Pesés</th><th class="nb">Poids moyen</th><th class="nb">Attendu</th><th>Croissance</th></tr></thead><tbody>
      ${b.pesees.slice().reverse().map(x => `<tr><td>${formatDate(x.date)}</td><td class="nb">${x.age} j</td><td class="nb">${x.nombre}</td><td class="nb"><b>${nbFerme(x.poids_g)} g</b></td>
        <td class="nb">${x.attendu_g ? nbFerme(x.attendu_g) + " g" : "—"}</td><td>${pastillePoids(x.pour_cent)}</td></tr>`).join("")}</tbody></table></div>` : ""}
    <div class="actions">${peseesFerme.soigne ? '<button class="btn primary" data-action="peser">Noter une pesée</button>' : ""}</div></div>`, { taille: "large fe-fenetre" });
  const peser = fen.querySelector('[data-action="peser"]');
  if (peser) peser.addEventListener("click", () => { fen.fermer(); formulairePeseeFerme(b.id); });
}

function fenetreReferencesFerme() {
  const p = peseesFerme;
  let espece = p.especes[0];
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("ferme", "fe-fiche-img")}<div><h2>Poids attendus</h2><p>Le poids moyen normal à chaque âge. Valeurs indicatives : à adapter avec votre vétérinaire ou votre fournisseur.</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="field" style="max-width:320px"><label for="rfEspece">Espèce</label><select id="rfEspece">${p.especes.map(e => `<option>${esc(e)}</option>`).join("")}</select></div>
    <div class="fe-tableau fe-saisie fe-fond-blanc"><table><thead><tr><th>À l'âge de (jours)</th><th>Poids moyen (g)</th><th></th></tr></thead><tbody id="rfLignes"></tbody></table></div>
    <button type="button" class="btn ghost" id="rfAjout" style="margin-top:.6rem">+ Un âge</button>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "fe-fenetre" });
  const ligne = (j = "", g = "") => `<tr><td><input class="rfJour" inputmode="numeric" value="${j}"></td><td><input class="rfPoids" inputmode="decimal" value="${g}"></td>
    <td><button type="button" class="ibtn del" aria-label="Retirer" onclick="this.closest('tr').remove()">✕</button></td></tr>`;
  const remplir = () => { fen.querySelector("#rfLignes").innerHTML = (p.references[espece] || []).map(r => ligne(r[0], r[1])).join("") || ligne(); };
  remplir();
  fen.querySelector("#rfEspece").addEventListener("change", e => { espece = e.target.value; remplir(); });
  fen.querySelector("#rfAjout").addEventListener("click", () => fen.querySelector("#rfLignes").insertAdjacentHTML("beforeend", ligne()));
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const points = [...fen.querySelectorAll("#rfLignes tr")].map(tr => [tr.querySelector(".rfJour").value.trim(), tr.querySelector(".rfPoids").value.trim()])
        .filter(([j, g]) => j || g).map(([j, g]) => { const jj = lireEntierFerme(j), gg = lireNombreFerme(g); if (jj === null || !gg) throw new Error("Chaque ligne : un âge en jours et un poids en grammes."); return [jj, gg]; })
        .sort((a, b) => a[0] - b[0]);
      ok.disabled = true;
      await api(`/api/ferme/poids-reference/${encodeURIComponent(espece)}`, { method: "PUT", body: { points } });
      peseesFerme.references[espece] = points;
      toast(`Poids attendus des ${espece.toLowerCase()} enregistrés`);
      ok.disabled = false;
      chargerPeseesFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

// ---------- Vétérinaire ----------

async function chargerVisitesFerme() {
  const zone = el("zoneVetoFerme");
  try { visitesFerme = await api("/api/ferme/visites"); } catch (e) { erreurFerme(zone, e); return; }
  const v = visitesFerme;
  const argent = v.visites.some(x => "cout" in x);
  zone.innerHTML = `<div class="fe-carte"><div class="fe-dette-tete"><h3>Visites du vétérinaire</h3>${v.note_visites ? '<button class="btn primary" onclick="formulaireVisiteFerme()">+ Nouvelle visite</button>' : ""}</div>
    ${v.visites.length ? `<div class="fe-tableau"><table><thead><tr><th>Date</th><th>Vétérinaire</th><th>Lot</th><th>Ce qu'il a vu</th><th>Ses conseils</th>${argent ? '<th class="nb">Prix</th>' : ""}</tr></thead><tbody>
      ${v.visites.map(x => `<tr${v.est_admin ? ` class="fe-ligne" onclick="supprimerVisiteFerme(${x.id})" data-tip="Cliquez pour supprimer cette visite"` : ""}>
        <td data-titre="Date">${formatDate(x.date)}</td><td data-titre="Vétérinaire"><b>${esc(x.veterinaire)}</b>${x.telephone ? `<br><small class="fe-aide">${esc(x.telephone)}</small>` : ""}</td>
        <td data-titre="Lot">${esc(x.bande) || "toute la ferme"}</td><td data-titre="Ce qu'il a vu">${esc(x.constat) || "—"}</td><td data-titre="Ses conseils">${esc(x.conseils) || "—"}</td>
        ${argent ? `<td data-titre="Prix" class="nb">${x.cout ? formatMontant(x.cout) : "—"}</td>` : ""}</tr>`).join("")}
    </tbody></table></div>` : '<p class="fe-aide">Aucune visite notée.</p>'}</div>`;
}

function formulaireVisiteFerme() {
  const v = visitesFerme;
  const fen = ouvrirFenetre(`<div class="fe-fiche">
    <div class="fe-fiche-tete">${imgFerme("medicament", "fe-fiche-img")}<div><h2>Visite du vétérinaire</h2><p>Ce qu'il a vu et ce qu'il conseille.</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field"><label for="viNom">Vétérinaire</label><input id="viNom" maxlength="100" placeholder="ex : Dr Kouassi"></div>
      <div class="field"><label for="viTel">Téléphone (facultatif)</label><input id="viTel" inputmode="tel" maxlength="30"></div>
      <div class="field"><label for="viBande">Pour quel lot ?</label><select id="viBande"><option value="">Toute la ferme</option>${v.bandes.map(b => `<option value="${b.id}">${esc(b.nom)} (${esc(b.batiment)})</option>`).join("")}</select></div>
      <div class="field"><label for="viDate">Date</label><input id="viDate" type="date"></div>
    </div>
    <div class="field"><label for="viConstat">Ce qu'il a vu</label><textarea id="viConstat" rows="3" maxlength="1000"></textarea></div>
    <div class="field"><label for="viConseils">Ses conseils</label><textarea id="viConseils" rows="3" maxlength="1000"></textarea></div>
    ${v.argent ? `<div class="fgrid"><div class="field"><label for="viCout">Prix de la visite (F, facultatif)</label><input id="viCout" inputmode="numeric"></div>
      <div class="field"><label for="viMode">Payé par</label><select id="viMode">${v.modes.map(m => `<option>${esc(m)}</option>`).join("")}</select></div>
      ${v.comptes.length ? `<div class="field"><label for="viCompte">Sorti de (facultatif)</label><select id="viCompte"><option value="">— compte habituel —</option>${v.comptes.map(c => `<option value="${c.id}">${esc(c.nom)}</option>`).join("")}</select></div>` : ""}</div>
      <p class="fe-aide">Le prix est noté automatiquement dans les Dépenses.</p>` : ""}
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div></div>`, { taille: "large fe-fenetre" });
  initialiserChampsDate(fen);
  fen.querySelector("#viDate").value = formatDate(aujourdhui());
  const ok = fen.querySelector('[data-action="ok"]');
  ok.addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const nom = fen.querySelector("#viNom").value.trim();
      if (nom.length < 2) throw new Error("Indiquez le nom du vétérinaire.");
      const date = isoDepuisTexte(fen.querySelector("#viDate").value);
      if (!date) throw new Error("Date incorrecte : écrivez-la comme 02/12/2026.");
      let cout = null;
      if (v.argent && fen.querySelector("#viCout").value.trim()) { cout = lireMontant(fen.querySelector("#viCout").value); if (cout === null) throw new Error("Le prix est incorrect."); }
      const compte = fen.querySelector("#viCompte");
      ok.disabled = true;
      await api("/api/ferme/visites", { method: "POST", body: { veterinaire: nom, telephone: fen.querySelector("#viTel").value.trim() || null,
        bande_id: fen.querySelector("#viBande").value ? Number(fen.querySelector("#viBande").value) : null, date_visite: date,
        constat: fen.querySelector("#viConstat").value.trim() || null, conseils: fen.querySelector("#viConseils").value.trim() || null,
        cout, mode_paiement: v.argent ? fen.querySelector("#viMode").value : "Espèce", compte_id: compte && compte.value ? Number(compte.value) : null } });
      fen.fermer();
      toast(cout ? "Visite notée, et son prix ajouté aux Dépenses" : "Visite notée");
      chargerVisitesFerme();
    } catch (e) { ok.disabled = false; erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

async function supprimerVisiteFerme(id) {
  const x = visitesFerme.visites.find(v => v.id === id);
  const mdp = await demanderMotDePasseAdmin(`Supprimer la visite du ${x ? formatDate(x.date) : ""} ? Sa dépense sera aussi supprimée. Entrez votre mot de passe.`);
  if (!mdp) return;
  try { await api(`/api/ferme/visites/${id}/supprimer`, { method: "POST", body: { mot_de_passe_admin: mdp } }); toast("Visite supprimée"); chargerVisitesFerme(); }
  catch (e) { toast(e.message, 7000); }
}

// ---------- Fiche d'une bande : vaccins, pesées, visites ----------

function htmlSanteBande(b) {
  const s = b.sante;
  if (!s) return "";
  return `
    <h4 class="fe-titre">Vaccins</h4>
    ${s.plan.length ? `<div class="fe-tableau fe-fond-blanc"><table><thead><tr><th>Vaccin</th><th class="nb">Âge</th><th>Prévu le</th><th>État</th></tr></thead><tbody>
      ${s.plan.map(l => `<tr><td><b>${esc(l.nom)}</b></td><td class="nb">${l.jour_age} j</td><td>${formatDate(l.date)}</td>
        <td>${pastilleFerme(ETAT_VACCIN[l.etat])}${l.fait_le ? ` <small class="fe-aide">le ${formatDate(l.fait_le)}</small>` : ""}${l.epuise ? ' <span class="fe-pastille rouge">produit épuisé</span>' : ""}</td></tr>`).join("")}
    </tbody></table></div>` : '<p class="fe-aide">Aucun vaccin au programme pour cette espèce.</p>'}
    ${s.soins.filter(x => !x.programme_id).length ? `<h4 class="fe-titre">Traitements</h4><div class="fe-tableau fe-fond-blanc"><table><thead><tr><th>Date</th><th>Soin</th><th>Produit</th></tr></thead><tbody>
      ${s.soins.filter(x => !x.programme_id).map(x => `<tr><td>${formatDate(x.date)}</td><td><b>${esc(x.nom)}</b></td><td>${esc(x.produit) || "—"}</td></tr>`).join("")}</tbody></table></div>` : ""}
    <h4 class="fe-titre">Croissance</h4>
    <div class="fe-fond-blanc">${courbePoidsFerme(s.pesees, s.reference)}</div>
    ${s.visites.length ? `<h4 class="fe-titre">Visites du vétérinaire</h4><div class="fe-tableau fe-fond-blanc"><table><thead><tr><th>Date</th><th>Vétérinaire</th><th>Conseils</th></tr></thead><tbody>
      ${s.visites.map(v => `<tr><td>${formatDate(v.date)}</td><td><b>${esc(v.veterinaire)}</b></td><td>${esc(v.conseils) || esc(v.constat) || "—"}</td></tr>`).join("")}</tbody></table></div>` : ""}`;
}
