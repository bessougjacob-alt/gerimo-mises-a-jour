// Page de connexion : identifiant et mot de passe. Le profil (Admin, Gestionnaire, Caisse, Comptable) est celui du
// compte : on ne le choisit plus (Boss, 26/11/2026). La vérification réelle est faite par le serveur (/api/connexion).

// Mention sous le nom, selon le ou les métiers ouverts par la licence (Boss, 26/11/2026)
const METIER_SEUL = { immobilier: "Gestion immobilière", commerce: "Gestion de boutique",
  mobile_money: "Gestion d'agence Mobile Money", ferme: "Gestion de ferme" };
const METIER_COURT = { immobilier: "Immobilier", commerce: "Boutique", mobile_money: "Mobile Money", ferme: "Ferme" };

// Nom de l'entreprise cliente (Paramètres → Mon entreprise) : « ISUP » + « Sarl » en Medium
fetch("/api/entreprise").then(r => r.ok ? r.json() : null).then(e => {
  if (!e) return;
  const metiers = (e.metiers && e.metiers.length ? e.metiers : ["immobilier"]).filter(m => METIER_COURT[m]);
  const mention = metiers.length === 1 ? METIER_SEUL[metiers[0]] : "Logiciel de gestion";
  document.getElementById("sloganEntreprise").textContent = e.slogan ? `${e.slogan} — ${mention}` : mention;
  // plusieurs métiers : la liste en petit dessous (« Immobilier · Boutique · Mobile Money »)
  document.getElementById("metiersEntreprise").textContent = metiers.length > 1 ? metiers.map(m => METIER_COURT[m]).join(" · ") : "";
  if (!e.nom) return;  // nouvelle installation : « Gérimo » en attendant « Mon entreprise »
  const h = document.getElementById("nomEntreprise");
  const echap = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  h.innerHTML = echap(e.nom) + (e.forme ? ` <span class="sarl">${echap(e.forme)}</span>` : "");
  document.title = `Connexion — ${e.nom_complet}`;
}).catch(() => {});

const carteConnexion = document.getElementById("carteConnexion");
const carteOubli = document.getElementById("forgotCard");
const zoneErreur = document.getElementById("erreurConnexion");
const btnConnexion = document.getElementById("btnConnexion");

// Œil : afficher / cacher le mot de passe (pratique sur téléphone)
document.getElementById("voirMdp").addEventListener("click", () => {
  const champ = document.getElementById("motDePasse");
  const visible = champ.type === "text";
  champ.type = visible ? "password" : "text";
  document.getElementById("voirMdp").classList.toggle("actif", !visible);
  champ.focus();
});

// Téléphone déjà protégé par son propre verrouillage (code, schéma, empreinte) : pas de veille automatique
// dans Gérimo (veille.py). L'application Android le sait ; un iPhone ou un iPad en a presque toujours un.
function typeAppareil() {
  const android = window.ISUPAndroid;
  if (android && android.ecranSecurise) {
    try { return android.ecranSecurise() ? "telephone_verrouille" : "telephone"; } catch { return "telephone"; }
  }
  const ua = navigator.userAgent;
  if (/iPhone|iPad/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1)) return "telephone_verrouille";
  return /Android/.test(ua) ? "telephone" : "pc";
}

function afficherErreur(message) {
  zoneErreur.textContent = message;
  zoneErreur.style.display = "block";
}

carteConnexion.addEventListener("submit", async e => {
  e.preventDefault();
  zoneErreur.style.display = "none";
  btnConnexion.disabled = true;
  btnConnexion.textContent = "Connexion…";
  try {
    const rep = await fetch("/api/connexion", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        identifiant: document.getElementById("identifiant").value,
        mot_de_passe: document.getElementById("motDePasse").value,
        appareil: typeAppareil(),
      }),
    });
    if (rep.ok) {
      const infos = await rep.json().catch(() => ({}));
      // affichée une fois dans Gérimo (veille.js) : chacun voit si quelqu'un s'est servi de son compte
      try { sessionStorage.setItem("gerimo_derniere_connexion", JSON.stringify(infos.derniere_connexion || null)); } catch { /* rien */ }
      // message d'accueil dans Gérimo : la personne voit avec quel profil elle est entrée
      try { sessionStorage.setItem("gerimo_bienvenue", JSON.stringify({ nom: infos.nom_complet || "", role: infos.role || "" })); } catch { /* rien */ }
      // Android ou navigateur (pont_web.js) : de quoi reconnaître ce mot de passe hors réseau (jamais gardé tel quel)
      const pont = (window.ISUPAndroid && window.ISUPAndroid.memoriserConnexion ? window.ISUPAndroid : null) || window.GerimoPont;
      if (pont) await Promise.resolve(pont.memoriserConnexion(document.getElementById("identifiant").value,
                                                              document.getElementById("motDePasse").value)).catch(() => {});
      // Le navigateur a-t-il gardé le cookie de connexion ? Sinon /app renverrait ici sans rien dire
      // (vu le 24/11/2026 sur un Firefox de poste Linux : la page semblait seulement se recharger)
      const verif = await fetch("/api/moi", { cache: "no-store" }).catch(() => null);
      if (verif && verif.status === 401) {
        afficherErreur("Mot de passe accepté, mais ce navigateur refuse les cookies de Gérimo : la connexion ne peut pas "
          + "être gardée. Firefox : Paramètres → Vie privée et sécurité → Protection renforcée contre le pistage : "
          + "choisissez « Standard », et sous « Cookies et données de sites », vérifiez que ce site n'est pas bloqué.");
        return;
      }
      window.location.replace("/app");
      return;
    }
    const donnees = await rep.json().catch(() => ({}));
    afficherErreur(typeof donnees.detail === "string" ? donnees.detail : "Connexion impossible.");
    document.getElementById("motDePasse").value = "";
    document.getElementById("motDePasse").focus();
  } catch {
    afficherErreur("Le serveur ne répond pas. Vérifiez qu'il est bien démarré.");
  } finally {
    btnConnexion.disabled = false;
    btnConnexion.textContent = "Se connecter";
  }
});

function toggleForgot(show) {
  carteConnexion.style.display = show ? "none" : "block";
  carteOubli.style.display = show ? "block" : "none";
  document.getElementById("resetMsg").style.display = "none";
  if (show) document.getElementById("identifiantOubli").focus();
}
document.getElementById("lienOubli").addEventListener("click", e => { e.preventDefault(); toggleForgot(true); });
document.getElementById("lienRetour").addEventListener("click", e => { e.preventDefault(); toggleForgot(false); });

carteOubli.addEventListener("submit", async e => {
  e.preventDefault();
  const bouton = carteOubli.querySelector('button[type="submit"]');
  bouton.disabled = true;
  try {
    const rep = await fetch("/api/mot-de-passe-oublie", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ identifiant: document.getElementById("identifiantOubli").value }),
    });
    const donnees = await rep.json().catch(() => ({}));
    // Pas d'envoi automatique possible sans service payant : l'employé envoie lui-même
    // le message WhatsApp pré-rempli à l'Admin (lien wa.me).
    const lien = document.getElementById("lienWaAdmin");
    lien.style.display = donnees.lien ? "" : "none";
    if (donnees.lien) lien.href = donnees.lien;
    document.getElementById("resetMsg").style.display = "block";
    if (donnees.lien) lien.focus();
  } catch {
    alert("Le serveur ne répond pas. Vérifiez qu'il est bien démarré.");
  } finally {
    bouton.disabled = false;
  }
});

// Identifiant : lettres, chiffres, point, tiret, tiret bas (pas d'espace ni de symbole)
["identifiant", "identifiantOubli"].forEach(id => {
  const champ = document.getElementById(id);
  champ.spellcheck = false;
  champ.addEventListener("input", () => {
    const propre = champ.value.replace(/[^A-Za-z0-9._-]/g, "");
    if (propre !== champ.value) champ.value = propre;
  });
});

document.getElementById("identifiant").focus();

// Application Android : lien pour changer l'adresse du serveur
if (window.ISUPAndroid) {
  document.getElementById("lienOubli").parentElement.insertAdjacentHTML("afterend",
    '<div style="text-align:center;margin-top:.6rem"><a href="#" class="forgot" id="lienServeur">Changer de serveur</a></div>');
  document.getElementById("lienServeur").addEventListener("click", e => { e.preventDefault(); window.ISUPAndroid.changerServeur(); });
}

// Tout est en place : le formulaire peut être envoyé par ce programme (voir connexion.html)
window.connexionPrete = true;
