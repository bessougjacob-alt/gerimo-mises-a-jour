"""Point de départ des loyers (Paramètres → Reprise de données, Admin) — demandé par Boss le 24/11/2026 pour SBC.

Le client garde ses anciennes données avec ses anciennes méthodes : Gérimo ne compte les loyers qu'à partir d'un mois
choisi (ex. novembre 2026). L'outil :
- met chaque contrat commencé avant ce mois en « suivi dans Gérimo à partir de » ce mois (caution et avance
  considérées comme versées à l'époque : entree_reprise) ;
- supprime les encaissements de LOYER qui portent sur un mois d'avant (reçus, répartition, quittances compris) ;
  un encaissement qui couvre aussi des mois suivants est supprimé en entier (ces mois redeviennent à payer) ;
- supprime les mois de loyer d'avant et leurs impayés (plus aucun arriéré d'avant dans Gérimo) ;
- vide l'historique repris des anciens classeurs pour les mois d'avant ;
- supprime les dépenses datées jusqu'au jour choisi ;
- en option, les reversements de loyers aux propriétaires datés d'avant le point de départ.
Les cautions et avances encaissées, les autres métiers, les biens, locataires et contrats ne sont pas touchés.
Une sauvegarde complète est faite juste avant ; l'Admin retape son mot de passe.
"""
from datetime import date, datetime
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.orm import Session as SessionDB

import periode

from models import (Contrat, Depense, Document, Echeance, Encaissement, HistoriqueLoyer, Impaye, Paiement,
                    Reversement, Utilisateur)
from paiements import ajouter_mois, premier_du_mois, recalculer_contrat
from securite import confirmer_mot_de_passe_admin, exiger_admin, get_db

router = APIRouter(prefix="/api/point-depart", tags=["point de départ"])

MOTIFS_LOYER = ("Loyer mensuel", "Règlement total")


def _dates(mois: date, depenses_jusqu_au: date | None) -> tuple[date, date | None]:
    depart = premier_du_mois(mois)
    if depart > ajouter_mois(premier_du_mois(date.today()), 1):
        raise HTTPException(status_code=400, detail="Le point de départ ne peut pas être après le mois prochain.")
    if depenses_jusqu_au and depenses_jusqu_au > date.today():
        raise HTTPException(status_code=400, detail="Les dépenses ne peuvent être effacées que jusqu'à aujourd'hui.")
    return depart, depenses_jusqu_au


def _mois_du_paiement(p: Paiement) -> set[date]:
    mois = {e.mois_echeance for e in p.echeances} | {v.echeance.mois_echeance for v in p.versements}
    if p.periode_debut:
        mois.add(premier_du_mois(p.periode_debut))
    return mois


def _selection(db: SessionDB, depart: date, depenses_jusqu_au: date | None, reversements: bool) -> dict:
    contrats = db.query(Contrat).filter(Contrat.date_debut < depart).all()
    paiements = [p for p in db.query(Paiement).filter(Paiement.motif_paiement.in_(MOTIFS_LOYER)).all()
                 if any(m < depart for m in _mois_du_paiement(p))]
    echeances = db.query(Echeance).filter(Echeance.mois_echeance < depart).all()
    historique = db.query(HistoriqueLoyer).filter(HistoriqueLoyer.mois < depart).count()
    depenses = (db.query(Depense).filter(Depense.date_depense <= depenses_jusqu_au).all()
                if depenses_jusqu_au else [])
    revs = (db.query(Reversement).filter(Reversement.type_reversement == "Loyers",
                                         Reversement.date_reversement < depart).all())
    return {"contrats": contrats, "paiements": paiements, "echeances": echeances, "historique": historique,
            "depenses": depenses, "reversements": revs if reversements else [], "reversements_tous": revs}


def _periode(p: Paiement) -> str:
    """« 09/2026 → 10/2026 » (ou un seul mois)."""
    mois = sorted(_mois_du_paiement(p))
    if not mois:
        return ""
    return mois[0].strftime("%m/%Y") + (f" → {mois[-1]:%m/%Y}" if len(mois) > 1 else "")


def _somme(valeurs) -> float:
    return float(sum((Decimal(v or 0) for v in valeurs), Decimal(0)))


@router.get("/apercu")
def apercu(mois: date, depenses_jusqu_au: date | None = None, admin: Utilisateur = Depends(exiger_admin),
           db: SessionDB = Depends(get_db)):
    depart, jusqu_au = _dates(mois, depenses_jusqu_au)
    s = _selection(db, depart, jusqu_au, True)
    payes = [p for p in s["paiements"] if p.statut_paiement == "Payé"]
    return {
        "depart": depart.isoformat(),
        "contrats": len(s["contrats"]),
        "paiements": len(s["paiements"]),
        "paiements_montant": _somme(p.montant for p in payes),
        "liste_paiements": [{
            "recu": p.numero_recu, "date": p.date_paiement.strftime("%d/%m/%Y"), "montant": float(p.montant),
            "locataire": p.contrat.locataire.nom_complet if p.contrat and p.contrat.locataire else "",
            "periode": _periode(p),
            "aussi_apres": any(m >= depart for m in _mois_du_paiement(p)), "statut": p.statut_paiement,
        } for p in sorted(s["paiements"], key=lambda p: (p.date_paiement, p.id))],
        "mois_supprimes": len(s["echeances"]),
        "mois_impayes": sum(1 for e in s["echeances"] if e.paiement_id is None),
        "arrieres_montant": _somme(e.montant_loyer - (e.montant_verse or 0) for e in s["echeances"] if e.paiement_id is None),
        "historique": s["historique"],
        "depenses": len(s["depenses"]),
        "depenses_montant": _somme(d.montant for d in s["depenses"]),
        "reversements": len(s["reversements_tous"]),
        "reversements_montant": _somme(r.montant for r in s["reversements_tous"]),
        "cloture_jusqu_au": (lambda c: c.strftime("%d/%m/%Y") if c else None)(periode.cloture_jusqu_au(db)),
    }


class Application(BaseModel):
    mois: date
    depenses_jusqu_au: date | None = None
    reversements: bool = False
    mot_de_passe_admin: str


@router.post("/appliquer")
def appliquer(donnees: Application, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    depart, jusqu_au = _dates(donnees.mois, donnees.depenses_jusqu_au)
    s = _selection(db, depart, jusqu_au, donnees.reversements)
    # période clôturée par l'Admin : les chiffres remis au comptable ne bougent pas
    periode.verifier_ouverte(db, *(p.date_paiement for p in s["paiements"]), *(d.date_depense for d in s["depenses"]),
                             *(r.date_reversement for r in s["reversements"]))

    import sauvegarde
    try:
        archive = sauvegarde.creer_sauvegarde("avant-point-de-depart")
    except Exception as e:  # noqa: BLE001 — sans sauvegarde, on ne touche à rien
        raise HTTPException(status_code=500, detail=f"Sauvegarde impossible, rien n'a été modifié : {e}")

    ids_paiements = [p.id for p in s["paiements"]]
    touches = {c.id for c in s["contrats"]} | {p.contrat_id for p in s["paiements"]}
    if ids_paiements:
        # les mois d'après réglés par ces encaissements redeviennent à payer
        db.execute(text("UPDATE echeances SET paiement_id = NULL WHERE paiement_id = ANY(:ids)"), {"ids": ids_paiements})
        db.execute(text("DELETE FROM versements_echeances WHERE paiement_id = ANY(:ids)"), {"ids": ids_paiements})
        db.execute(text("UPDATE messages_whatsapp SET paiement_id = NULL WHERE paiement_id = ANY(:ids)"),
                   {"ids": ids_paiements})
        db.query(Document).filter(Document.paiement_id.in_(ids_paiements)).delete(synchronize_session=False)
        db.query(Encaissement).filter(Encaissement.paiement_id.in_(ids_paiements)).delete(synchronize_session=False)
        db.query(Paiement).filter(Paiement.id.in_(ids_paiements)).delete(synchronize_session=False)
    ids_echeances = [e.id for e in s["echeances"]]
    if ids_echeances:
        db.query(Impaye).filter(Impaye.echeance_id.in_(ids_echeances)).delete(synchronize_session=False)
        db.query(Echeance).filter(Echeance.id.in_(ids_echeances)).delete(synchronize_session=False)
    db.query(Impaye).filter(Impaye.mois < depart).delete(synchronize_session=False)
    # ce qui a été versé sur les mois restants (sans les encaissements supprimés)
    db.execute(text("UPDATE echeances e SET montant_verse = COALESCE((SELECT SUM(v.montant) FROM versements_echeances v "
                    "WHERE v.echeance_id = e.id), 0) WHERE e.contrat_id = ANY(:c)"), {"c": list(touches)})
    db.query(HistoriqueLoyer).filter(HistoriqueLoyer.mois < depart).delete(synchronize_session=False)
    if s["depenses"]:
        db.query(Depense).filter(Depense.id.in_([d.id for d in s["depenses"]])).delete(synchronize_session=False)
    if s["reversements"]:
        db.query(Reversement).filter(Reversement.id.in_([r.id for r in s["reversements"]])).delete(synchronize_session=False)
    db.flush()
    db.expire_all()

    for c in db.query(Contrat).filter(Contrat.id.in_(touches)).all():
        if premier_du_mois(c.date_debut) < depart:
            c.suivi_depuis = depart
        recalculer_contrat(db, c, date.today())
    db.commit()
    return {"ok": True, "sauvegarde": archive.name, "contrats": len(touches), "paiements": len(ids_paiements),
            "mois": len(ids_echeances), "historique": s["historique"], "depenses": len(s["depenses"]),
            "reversements": len(s["reversements"]), "le": datetime.now().strftime("%d/%m/%Y %H:%M")}
