"""Pare-feu de Windows : Gérimo Serveur n'accepte que les appareils du réseau local (audit du 12/10/2026, point 1).

Au premier lancement, Windows demande « Autoriser l'accès ? » et crée des règles qui ouvrent Gérimo Serveur à
TOUTES les adresses, souvent sur le profil « Public » (réseau d'un téléphone en partage de connexion, Wi-Fi d'un
hôtel…). Gérimo les remplace par une seule règle, « Gérimo Serveur (réseau local) » :
- seulement ses ports (8000 en clair, 8443 en https) ;
- seulement les appareils du même réseau local (« sous-réseau local ») : jamais Internet ni un autre réseau ;
- sur tous les profils (Privé, Domaine, Public), pour que les téléphones en partage de connexion continuent de
  fonctionner (Windows classe chaque nouveau partage de connexion en « Public »).
Les anciennes règles du programme sont désactivées (pas supprimées). Windows demande l'accord de l'Admin une fois
(UAC) ; c'est noté dans journaux/pare_feu.txt. L'assistant conseille aussi de passer le réseau du bureau en « Privé ».

Appelé au démarrage par protection_windows.verifier (mis à jour en ligne avec le reste du logiciel).
"""
import base64
import json
import os
import subprocess
import time
from datetime import datetime
from pathlib import Path

NOM_REGLE = "Gérimo Serveur (réseau local)"
FICHIER = "pare_feu.txt"      # dans journaux/ : réglage déjà fait (programme et ports)
VERSION = "1"
SANS_FENETRE = 0x08000000


def _powershell(script: str, delai: int = 30) -> subprocess.CompletedProcess:
    return subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], capture_output=True,
                          text=True, timeout=delai, creationflags=SANS_FENETRE, stdin=subprocess.DEVNULL)


def ports() -> list[int]:
    return sorted({int(os.getenv("ISUP_PORT", "8000")), int(os.getenv("ISUP_PORT_HTTPS", "8443"))})


def marque(executable: str) -> str:
    return f"{VERSION}|{Path(executable)}|{','.join(map(str, ports()))}"


def deja_fait(dossier: Path, executable: str) -> bool:
    try:
        return (dossier / "journaux" / FICHIER).read_text(encoding="utf-8").strip().endswith(marque(executable))
    except OSError:
        return False


def _texte_ps(texte: str) -> str:
    return "'" + texte.replace("'", "''") + "'"


def script_regles(executable: str) -> str:
    """Exécuté avec les droits Admin : anciennes règles du programme désactivées, règle « réseau local » créée."""
    exe = Path(executable)
    anciens = [str(exe), str(exe.with_name("ISUP ERP Serveur.exe"))]  # (nom du programme avant Gérimo)
    return "; ".join([
        "$ErrorActionPreference = 'Stop'",
        "try {",
        "foreach ($p in @(" + ",".join(_texte_ps(a) for a in anciens) + ")) {"
        " Get-NetFirewallApplicationFilter -Program $p -ErrorAction SilentlyContinue | Get-NetFirewallRule |"
        f" Where-Object {{ $_.Direction -eq 'Inbound' -and $_.DisplayName -ne {_texte_ps(NOM_REGLE)} }} |"
        " Disable-NetFirewallRule }",
        f"Get-NetFirewallRule -DisplayName {_texte_ps(NOM_REGLE)} -ErrorAction SilentlyContinue | Remove-NetFirewallRule",
        f"New-NetFirewallRule -DisplayName {_texte_ps(NOM_REGLE)} -Direction Inbound -Action Allow"
        f" -Program {_texte_ps(str(exe))} -Protocol TCP -LocalPort {','.join(map(str, ports()))}"
        " -RemoteAddress LocalSubnet -Profile Any | Out-Null",
        "exit 0 } catch { exit 1 }",
    ])


def demander(script: str) -> bool:
    """Fenêtre de Windows « Voulez-vous autoriser… » (UAC), puis le script. True si c'est fait."""
    code = base64.b64encode(script.encode("utf-16-le")).decode()
    externe = ("try { $p = Start-Process powershell -Verb RunAs -Wait -PassThru -WindowStyle Hidden "
               f"-ArgumentList '-NoProfile','-NonInteractive','-EncodedCommand','{code}'; exit $p.ExitCode }} "
               "catch { exit 2 }")
    try:
        return _powershell(externe, delai=600).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def verifier(dossier: Path, executable: str) -> str | None:
    """Au démarrage de Gérimo Serveur (programme installé seulement). Message pour sa fenêtre, ou None."""
    import sys
    if os.name != "nt" or not getattr(sys, "frozen", False) or deja_fait(dossier, executable):
        return None  # (en développement, python.exe n'est jamais ouvert au réseau)
    if demander(script_regles(executable)):
        try:
            (dossier / "journaux" / FICHIER).write_text(f"# {datetime.now():%d/%m/%Y %H:%M} règle « {NOM_REGLE} »\n"
                                                        + marque(executable) + "\n", encoding="utf-8")
        except OSError:
            pass
        return "✅ Pare-feu de Windows : Gérimo Serveur n'accepte plus que les appareils du réseau local."
    return ("⚠ Pare-feu : Gérimo Serveur reste ouvert à toutes les adresses. Relancez Gérimo Serveur et répondez "
            "« Oui » à Windows pour le limiter au réseau du bureau.")


# ---------- Réseau « Public » (conseil de l'assistant) ----------

_cache = {"quand": 0.0, "publics": []}


def reseaux_publics() -> list[str]:
    """Noms des réseaux de ce PC classés « Public » par Windows (lu toutes les 10 minutes au plus)."""
    if os.name != "nt":
        return []
    if time.time() - _cache["quand"] < 600:
        return _cache["publics"]
    try:
        r = _powershell("Get-NetConnectionProfile | Select-Object Name, NetworkCategory | ConvertTo-Json -Compress", 15)
        donnees = json.loads(r.stdout or "[]")
        donnees = donnees if isinstance(donnees, list) else [donnees]
        # NetworkCategory : 0 = Public, 1 = Privé, 2 = Domaine (ou le texte selon la version de Windows)
        publics = [d.get("Name", "") for d in donnees if str(d.get("NetworkCategory")) in ("0", "Public")]
    except (OSError, subprocess.SubprocessError, ValueError):
        publics = []
    _cache.update(quand=time.time(), publics=publics)
    return publics
