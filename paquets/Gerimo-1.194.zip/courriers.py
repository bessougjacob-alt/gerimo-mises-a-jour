"""Actions / courriers : révision de loyer et avenant au bail, envoyés par e-mail ou WhatsApp.

Révision de loyer :
- le nouveau loyer s'applique à partir du 1er du mois choisi (« date d'effet ») ;
- les mois déjà réglés ne changent jamais ; les mois non réglés à partir de la date d'effet
  sont recalculés avec le nouveau loyer ; les mois d'avant gardent l'ancien loyer ;
- refus si des mois après la date d'effet sont déjà payés d'avance (il faudrait d'abord régulariser).
Avenant : modifie une ou plusieurs clauses du bail ; une prolongation met à jour la date de fin.
(Le loyer se modifie par une révision, pas par un avenant.)
Droits : Admin et Gestionnaire (ses biens). Suppression : Admin, mot de passe redemandé.
"""
from datetime import date, datetime
from decimal import Decimal
from typing import Literal
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import Field
from sqlalchemy.orm import Session as SessionDB

import documents_pdf
import fichiers
import parametres
import recus
from entreprise import est_entreprise
from biens import synchroniser_statut_logement
from commun import Email, Formulaire, Paragraphe, Suppression, charger, montant, numero_suivant
from contrats import charger_contrat
from models import Contrat, Courrier, Impaye, Logement, Utilisateur, STATUTS_EN_COURS
from paiements import premier_du_mois, recalculer_contrat
from securite import cites_autorisees, confirmer_mot_de_passe_admin, exiger_admin, exiger_module, get_db
from whatsapp import numero_whatsapp

router = APIRouter(prefix="/api")
acces_courriers = exiger_module("courriers")

OBJETS_AVENANT = ("Prolongation de la durée du bail", "Ajout ou retrait d'un occupant", "Changement d'usage du local",
                  "Modalités de paiement", "Travaux ou aménagements autorisés", "Autre modification")


class RevisionIn(Formulaire):
    contrat_id: int
    nouveau_loyer: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    date_effet: date
    motif: Paragraphe = Field("", max_length=1500)


class AvenantIn(Formulaire):
    contrat_id: int
    objet: Literal[OBJETS_AVENANT]
    clauses: Paragraphe = Field(min_length=10, max_length=5000)
    date_effet: date | None = None
    nouvelle_date_fin: date | None = None


class EnvoiEmail(Formulaire):
    destinataire: Email = Field(min_length=3, max_length=150)


def signataire(u: Utilisateur) -> str:
    return f"{u.nom_complet}, {parametres.fonction_de(u)}"


def date_fr(d: date | None) -> str:
    return d.strftime("%d/%m/%Y") if d else ""


# ---------- Liste ----------

def courrier_json(k: Courrier) -> dict:
    c = k.contrat
    return {
        "id": k.id, "numero": k.numero, "type_courrier": k.type_courrier, "objet": k.objet,
        "date_courrier": k.date_courrier.isoformat(), "date_effet": k.date_effet.isoformat() if k.date_effet else None,
        "ancien_loyer": montant(k.ancien_loyer) if k.ancien_loyer is not None else None,
        "nouveau_loyer": montant(k.nouveau_loyer) if k.nouveau_loyer is not None else None,
        "contrat_id": c.id, "numero_contrat": c.numero_contrat, "locataire": c.locataire.nom_complet,
        "telephone": c.locataire.telephone, "email": c.locataire.email,
        "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}",
        "envois": k.envois or [],
    }


@router.get("/courriers")
def liste(utilisateur: Utilisateur = Depends(acces_courriers), db: SessionDB = Depends(get_db)):
    requete = db.query(Courrier).join(Contrat).join(Logement)
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None:
        requete = requete.filter(Logement.cite_id.in_(autorisees))
    return [courrier_json(k) for k in requete.order_by(Courrier.cree_le.desc()).limit(300)]


@router.get("/courriers/options")
def options(utilisateur: Utilisateur = Depends(acces_courriers), db: SessionDB = Depends(get_db)):
    requete = db.query(Contrat).join(Logement).filter(Contrat.statut_contrat.in_(STATUTS_EN_COURS))
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None:
        requete = requete.filter(Logement.cite_id.in_(autorisees))
    return {
        "objets_avenant": OBJETS_AVENANT,
        "contrats": [{"id": c.id, "numero_contrat": c.numero_contrat, "locataire": c.locataire.nom_complet,
                      "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}",
                      "montant_loyer": montant(c.montant_loyer), "date_debut": c.date_debut.isoformat(),
                      "date_fin": c.date_fin.isoformat() if c.date_fin else None,
                      "derniere_revision": max((r.date_effet.isoformat() for r in c.courriers
                                                if r.type_courrier == "Révision de loyer" and r.date_effet), default=None)}
                     for c in requete.order_by(Contrat.numero_contrat)],
    }


# ---------- Révision de loyer ----------

def donnees_revision(k: Courrier, auteur: Utilisateur) -> dict:
    c = k.contrat
    hausse = k.nouveau_loyer > k.ancien_loyer
    ecart = abs(k.nouveau_loyer - k.ancien_loyer)
    pourcentage = (ecart / k.ancien_loyer * 100).quantize(Decimal("0.1")) if k.ancien_loyer else Decimal(0)
    motif = (k.contenu or "").strip()
    corps_debut = (f"Madame, Monsieur,\n\nNous vous informons qu'à compter du {date_fr(k.date_effet)}, le loyer mensuel "
                   f"du logement {c.logement.numero_logement} ({c.logement.cite.nom}) que vous occupez au titre du "
                   f"contrat de bail N° {c.numero_contrat} est {'porté' if hausse else 'ramené'} de "
                   f"{recus.francs(k.ancien_loyer)} à {recus.francs(k.nouveau_loyer)}, soit une "
                   f"{'hausse' if hausse else 'baisse'} de {recus.francs(ecart)} ({str(pourcentage).replace('.', ',')} %).")
    if motif:
        corps_debut += f"\n\nCette révision est motivée par : {motif}"
    corps_fin = ("Les loyers des mois antérieurs restent dus au montant actuel. Les autres clauses de votre contrat de "
                 "bail demeurent inchangées.\n\nNous vous remercions de bien vouloir nous retourner un exemplaire de ce "
                 "courrier signé avec la mention « Bon pour accord ». Notre service reste à votre disposition pour tout "
                 f"renseignement au {recus.ENTETE['telephones']}.\n\nVeuillez agréer, Madame, Monsieur, l'expression de nos salutations "
                 "distinguées.")
    return {"numero": k.numero, "date": date_fr(k.date_courrier), "mention": f"Contrat N° {c.numero_contrat}",
            "destinataire": c.locataire.nom_complet,
            "destinataire_adresse": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}"
                                    + (f" — {c.logement.cite.adresse}" if c.logement.cite.adresse else ""),
            "destinataire_tel": f"Tél. {c.locataire.telephone}" if c.locataire.telephone else "",
            "objet": "Révision du montant de votre loyer", "references": f"Contrat de bail N° {c.numero_contrat}",
            "corps_debut": corps_debut, "corps_fin": corps_fin,
            "ancien_loyer": recus.francs(k.ancien_loyer), "nouveau_loyer": recus.francs(k.nouveau_loyer),
            "date_effet": date_fr(k.date_effet), "signataire": signataire(auteur)}


@router.post("/courriers/revision")
def creer_revision(d: RevisionIn, utilisateur: Utilisateur = Depends(acces_courriers), db: SessionDB = Depends(get_db)):
    c = charger_contrat(db, utilisateur, d.contrat_id)
    if c.statut_contrat not in STATUTS_EN_COURS:
        raise HTTPException(status_code=409, detail="On ne révise le loyer que d'un contrat en cours.")
    effet = premier_du_mois(d.date_effet)
    if effet < premier_du_mois(date.today()):
        raise HTTPException(status_code=400, detail="La date d'effet ne peut pas être dans un mois passé.")
    if effet < premier_du_mois(c.date_debut):
        raise HTTPException(status_code=400, detail="La date d'effet est avant le début du bail.")
    if d.nouveau_loyer == c.montant_loyer:
        raise HTTPException(status_code=400, detail="Le nouveau loyer est identique au loyer actuel.")
    payes = [e for e in c.echeances if e.mois_echeance >= effet and e.paiement is not None]
    if payes:
        raise HTTPException(status_code=409, detail="Des mois à partir de cette date sont déjà payés d'avance : "
                                                    "choisissez une date d'effet après le dernier mois réglé.")
    k = Courrier(numero=numero_suivant(db, Courrier.numero, f"REV-{date.today().year}", 4),
                 type_courrier="Révision de loyer", contrat=c, date_courrier=date.today(), date_effet=effet,
                 ancien_loyer=c.montant_loyer, nouveau_loyer=d.nouveau_loyer,
                 objet=f"Loyer {recus.francs(c.montant_loyer)} → {recus.francs(d.nouveau_loyer)}",
                 contenu=d.motif or None, cree_par=utilisateur.id, envois=[])
    db.add(k)
    # Application : nouveau loyer, mois non réglés à partir de la date d'effet recalculés
    c.montant_loyer = d.nouveau_loyer
    for e in [e for e in c.echeances if e.paiement is None and not e.montant_verse and e.mois_echeance >= effet]:
        db.query(Impaye).filter_by(echeance_id=e.id).delete()
        c.echeances.remove(e)
        db.delete(e)
    db.flush()
    recalculer_contrat(db, c, date.today())
    enregistrer_pdf(k, documents_pdf.revision_loyer_pdf(donnees_revision(k, utilisateur)))
    db.commit()
    return {"id": k.id, "numero": k.numero}


# ---------- Avenant ----------

def donnees_avenant(k: Courrier, auteur: Utilisateur) -> dict:
    c = k.contrat
    proprietaire = c.logement.cite.proprietaire
    bailleur = (f"{recus.ENTETE['nom']}, {recus.ENTETE['rccm']}, {recus.ENTETE['adresse']}, représentée par "
                f"{signataire(auteur)}" + (f", agissant pour le compte de {proprietaire.nom_complet}, propriétaire"
                                          if proprietaire and not est_entreprise(proprietaire.nom_complet) else "")
                + ", ci-après « le Bailleur » ;")
    locataire = (f"{c.locataire.nom_complet}" + (f", titulaire de la CNI N° {c.locataire.cni}" if c.locataire.cni else "")
                 + (f", téléphone {c.locataire.telephone}" if c.locataire.telephone else "") + ", ci-après « le Locataire ».")
    objet = (f"Le présent avenant modifie le contrat de bail N° {c.numero_contrat} du {date_fr(c.date_debut)} portant "
             f"sur le logement {c.logement.numero_logement} ({c.logement.type_logement}), {c.logement.cite.nom}"
             + (f", {c.logement.cite.adresse}" if c.logement.cite.adresse else "") + f".\n\nObjet : {k.objet}.")
    clauses = k.contenu or ""
    if k.nouvelle_date_fin:
        clauses += (f"\n\nLa date de fin du bail, initialement fixée au {date_fr(k.ancienne_date_fin) or 'non précisée'}, "
                    f"est portée au {date_fr(k.nouvelle_date_fin)}.")
    if k.date_effet:
        clauses += f"\n\nLe présent avenant prend effet le {date_fr(k.date_effet)}."
    return {"numero": k.numero, "date": date_fr(k.date_courrier), "numero_contrat": c.numero_contrat,
            "parties": f"- {bailleur}\n- {locataire}", "objet": objet, "clauses": clauses,
            "signataire": signataire(auteur), "locataire": c.locataire.nom_complet}


@router.post("/courriers/avenant")
def creer_avenant(d: AvenantIn, utilisateur: Utilisateur = Depends(acces_courriers), db: SessionDB = Depends(get_db)):
    c = charger_contrat(db, utilisateur, d.contrat_id)
    if c.statut_contrat not in STATUTS_EN_COURS:
        raise HTTPException(status_code=409, detail="Un avenant ne concerne qu'un contrat en cours.")
    if d.nouvelle_date_fin and d.nouvelle_date_fin <= c.date_debut:
        raise HTTPException(status_code=400, detail="La nouvelle date de fin doit être après le début du bail.")
    k = Courrier(numero=numero_suivant(db, Courrier.numero, f"AVE-{date.today().year}", 4),
                 type_courrier="Avenant au bail", contrat=c, date_courrier=date.today(), date_effet=d.date_effet,
                 objet=d.objet, contenu=d.clauses, ancienne_date_fin=c.date_fin,
                 nouvelle_date_fin=d.nouvelle_date_fin, cree_par=utilisateur.id, envois=[])
    db.add(k)
    if d.nouvelle_date_fin:  # prolongation : le bail court jusqu'à la nouvelle date
        c.date_fin = d.nouvelle_date_fin
        if c.statut_contrat == "Expiré":
            c.statut_contrat = "Renouvelé"
        synchroniser_statut_logement(c.logement)
    db.flush()
    enregistrer_pdf(k, documents_pdf.avenant_pdf(donnees_avenant(k, utilisateur)))
    db.commit()
    return {"id": k.id, "numero": k.numero}


# ---------- PDF et envois ----------

def enregistrer_pdf(k: Courrier, contenu: bytes) -> None:
    dossier = "revisions" if k.type_courrier == "Révision de loyer" else "avenants"
    relatif = f"courriers/{dossier}/{k.date_courrier.year}/{k.numero}.pdf"
    chemin = fichiers.DOSSIER_DOCUMENTS / relatif
    chemin.parent.mkdir(parents=True, exist_ok=True)
    chemin.write_bytes(contenu)
    k.chemin_pdf = relatif


def charger_courrier(db: SessionDB, utilisateur: Utilisateur, courrier_id: int) -> Courrier:
    k = charger(db, Courrier, courrier_id, "Courrier introuvable.")
    try:
        charger_contrat(db, utilisateur, k.contrat_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Courrier introuvable.")
    return k


def contenu_pdf(db: SessionDB, k: Courrier) -> bytes:
    chemin = fichiers.chemin_absolu(k.chemin_pdf) if k.chemin_pdf else None
    if chemin is None or not chemin.exists():
        auteur = db.get(Utilisateur, k.cree_par) if k.cree_par else None
        if auteur is None:
            raise HTTPException(status_code=404, detail="PDF introuvable.")
        contenu = (documents_pdf.revision_loyer_pdf(donnees_revision(k, auteur)) if k.type_courrier == "Révision de loyer"
                   else documents_pdf.avenant_pdf(donnees_avenant(k, auteur)))
        enregistrer_pdf(k, contenu)
        db.commit()
        return contenu
    return chemin.read_bytes()


@router.get("/courriers/{courrier_id}/pdf")
def pdf(courrier_id: int, utilisateur: Utilisateur = Depends(acces_courriers), db: SessionDB = Depends(get_db)):
    k = charger_courrier(db, utilisateur, courrier_id)
    return Response(contenu_pdf(db, k), media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="{k.numero}.pdf"'})


def message(k: Courrier) -> str:
    c = k.contrat
    if k.type_courrier == "Révision de loyer":
        detail = (f"votre loyer passe de {recus.francs(k.ancien_loyer)} à {recus.francs(k.nouveau_loyer)} "
                  f"à compter du {date_fr(k.date_effet)}")
    else:
        detail = f"un avenant à votre contrat de bail N° {c.numero_contrat} ({k.objet.lower()})"
    return (f"Bonjour {c.locataire.nom_complet},\n\nNous vous informons que {detail}. "
            f"Vous trouverez le courrier N° {k.numero} en pièce jointe.\n\n"
            f"Merci de nous retourner un exemplaire signé.\n\nCordialement,\n{recus.ENTETE['nom']} — {recus.ENTETE['telephones']}")


def noter_envoi(k: Courrier, canal: str, destinataire: str) -> None:
    k.envois = list(k.envois or []) + [{"canal": canal, "destinataire": destinataire,
                                        "date": datetime.now().strftime("%d/%m/%Y %H:%M")}]


@router.post("/courriers/{courrier_id}/envoyer-email")
def envoyer_email(courrier_id: int, d: EnvoiEmail, utilisateur: Utilisateur = Depends(acces_courriers),
                  db: SessionDB = Depends(get_db)):
    k = charger_courrier(db, utilisateur, courrier_id)
    parametres.envoyer_email(db, d.destinataire, f"{k.type_courrier} — courrier N° {k.numero} — {recus.ENTETE['nom']}", message(k),
                             [(f"{k.numero}.pdf", contenu_pdf(db, k), "application/pdf")])
    if not k.contrat.locataire.email:
        k.contrat.locataire.email = d.destinataire
    noter_envoi(k, "E-mail", d.destinataire)
    db.commit()
    return {"ok": True}


@router.post("/courriers/{courrier_id}/whatsapp")
def whatsapp(courrier_id: int, utilisateur: Utilisateur = Depends(acces_courriers), db: SessionDB = Depends(get_db)):
    k = charger_courrier(db, utilisateur, courrier_id)
    numero = numero_whatsapp(k.contrat.locataire.telephone)
    noter_envoi(k, "WhatsApp", k.contrat.locataire.telephone or "")
    db.commit()
    texte = quote(message(k))
    return {"lien": f"https://wa.me/{numero}?text={texte}" if numero else f"https://wa.me/?text={texte}",
            "nom_fichier": f"{k.numero}.pdf", "a_numero": bool(numero)}


@router.post("/courriers/{courrier_id}/supprimer")
def supprimer(courrier_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin),
              db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, d.mot_de_passe_admin)
    k = charger(db, Courrier, courrier_id, "Courrier introuvable.")
    if k.type_courrier == "Révision de loyer":
        raise HTTPException(status_code=409, detail="Une révision de loyer appliquée ne se supprime pas : "
                                                    "faites une nouvelle révision pour revenir à l'ancien montant.")
    chemin = k.chemin_pdf
    db.delete(k)
    db.commit()
    fichiers.effacer(chemin)
    return {"ok": True}
