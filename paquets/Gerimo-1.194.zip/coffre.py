"""Coffre de l'entreprise : la clé qui chiffre les sauvegardes et les secrets enregistrés dans la base.

Pourquoi (audit de sécurité du 12/10/2026, points 2 et 12) : une sauvegarde contient tout (CNI, contrats, montants) ;
copiée sur une clé USB perdue ou volée, elle ne doit rien révéler. Les secrets des Paramètres (mot de passe des
e-mails, clé de l'IA, jeton des mises à jour) ne doivent pas non plus se lire en clair dans la base ou une sauvegarde.

- La clé est propre à chaque entreprise : 20 octets tirés au hasard la première fois, gardés sur le PC serveur dans
  certificats/cles_donnees.json (jamais dans la base, jamais dans une sauvegarde).
- Le « code de secours » est cette même clé écrite en 8 groupes de 4 caractères (ex. K7QF-2MZA-…). L'Admin le note
  sur papier : sur un PC neuf (panne, vol), il suffit de le saisir pour relire les sauvegardes.
- Trousseau : la clé active chiffre ; les anciennes (une sauvegarde venue d'un autre PC, restaurée avec son code)
  restent pour relire. Chaque clé a un identifiant (8 octets) écrit en tête de ce qu'elle chiffre.
- Sauvegardes : AES-256-GCM par morceaux de 1 Mo (fichiers de plusieurs Go sans tout charger en mémoire) ; chaque
  morceau est numéroté et le dernier est marqué : un fichier modifié, coupé ou fabriqué est refusé.
- Le PC de secours reçoit le trousseau au jumelage (connexion vérifiée) : il peut relire les copies et prendre le relais.
"""
import base64
import hashlib
import json
import os
import secrets
from datetime import datetime
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

ICI = Path(__file__).parent
DOSSIER_DEFAUT = ICI / "certificats"
NOM_TROUSSEAU = "cles_donnees.json"

MAGIE_FICHIER = b"GERIMO-COFFRE\x01"   # en tête d'une sauvegarde chiffrée
MORCEAU = 1024 * 1024
PREFIXE_SECRET = "coffre:v1:"           # devant un secret chiffré dans la base
ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"


class CleInconnue(Exception):
    """Chiffré avec une clé absente du trousseau : il faut le code de secours de l'entreprise d'origine."""


class Abime(Exception):
    """Fichier modifié, coupé ou fabriqué : refusé."""


# ---------- Trousseau ----------

def _chemin(dossier: Path | None) -> Path:
    return Path(dossier or DOSSIER_DEFAUT) / NOM_TROUSSEAU


def _lire(dossier: Path | None = None) -> dict:
    try:
        return json.loads(_chemin(dossier).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"cles": []}


def _enregistrer(trousseau: dict, dossier: Path | None = None) -> None:
    chemin = _chemin(dossier)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    provisoire = chemin.with_suffix(".en-cours")
    provisoire.write_text(json.dumps(trousseau, ensure_ascii=False, indent=1), encoding="utf-8")
    provisoire.replace(chemin)


def identifiant(secret: bytes) -> bytes:
    return hashlib.sha256(b"gerimo/identifiant/" + secret).digest()[:8]


def _derivee(secret: bytes, usage: str) -> bytes:
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=f"gerimo/{usage}/v1".encode()).derive(secret)


def code_de(secret: bytes) -> str:
    texte = base64.b32encode(secret).decode().rstrip("=")
    return "-".join(texte[i:i + 4] for i in range(0, len(texte), 4))


def secret_du_code(code: str) -> bytes:
    """« k7qf 2mza-… » → les 20 octets ; tolère espaces, tirets, minuscules et 0/1/8 tapés pour O/I/B."""
    propre = "".join(c for c in code.upper() if c.isalnum()).translate(str.maketrans("018", "OIB"))
    if len(propre) != 32 or any(c not in ALPHABET for c in propre):
        raise ValueError("Le code de secours compte 32 caractères (8 groupes de 4, lettres et chiffres 2 à 7).")
    return base64.b32decode(propre)


def cles(dossier: Path | None = None, creer: bool = True) -> list[bytes]:
    """Les clés du trousseau, l'active en premier ; la crée la première fois."""
    t = _lire(dossier)
    liste = [secret_du_code(c["code"]) for c in t.get("cles", [])]
    if not liste and creer:
        secret = secrets.token_bytes(20)
        _enregistrer({"cles": [{"code": code_de(secret), "cree_le": datetime.now().isoformat(timespec="seconds"),
                                "note": False}]}, dossier)
        liste = [secret]
    return liste


def cle_active(dossier: Path | None = None) -> bytes:
    return cles(dossier)[0]


def code_secours(dossier: Path | None = None) -> str:
    return code_de(cle_active(dossier))


def code_note(dossier: Path | None = None) -> bool:
    """L'Admin a-t-il confirmé avoir noté le code de secours de la clé active ?"""
    cles(dossier)
    return bool(_lire(dossier)["cles"][0].get("note"))


def noter_code(dossier: Path | None = None) -> None:
    cles(dossier)
    t = _lire(dossier)
    t["cles"][0]["note"] = True
    t["cles"][0]["note_le"] = datetime.now().isoformat(timespec="seconds")
    _enregistrer(t, dossier)


def ajouter(secret: bytes, active: bool = False, dossier: Path | None = None) -> None:
    """Ajoute une clé au trousseau (sans doublon) ; active=True : elle devient la clé qui chiffre."""
    t = _lire(dossier)
    existantes = [c for c in t.get("cles", []) if secret_du_code(c["code"]) != secret]
    deja = next((c for c in t.get("cles", []) if secret_du_code(c["code"]) == secret), None)
    if deja and not active:
        return
    entree = deja or {"code": code_de(secret), "cree_le": datetime.now().isoformat(timespec="seconds"),
                      "note": active}  # saisie à la main par l'Admin = déjà notée
    t["cles"] = [entree] + existantes if active or not existantes else existantes + [entree]
    _enregistrer(t, dossier)


def exporter(dossier: Path | None = None) -> list[str]:
    """Codes du trousseau (l'actif en premier) : transmis au PC de secours au jumelage."""
    return [code_de(s) for s in cles(dossier)]


def adopter(codes: list[str], dossier: Path | None = None) -> None:
    """PC de secours : prend le trousseau du PC principal, sa clé active devient la sienne."""
    for code in reversed(codes):
        ajouter(secret_du_code(code), active=True, dossier=dossier)


def _par_identifiant(ident: bytes, dossier: Path | None) -> bytes:
    for secret in cles(dossier, creer=False):
        if identifiant(secret) == ident:
            return secret
    raise CleInconnue("Ce fichier a été chiffré avec la clé d'une autre installation de Gérimo : "
                      "saisissez son code de secours.")


# ---------- Fichiers (sauvegardes) ----------

def est_chiffre(chemin: Path) -> bool:
    try:
        with open(chemin, "rb") as f:
            return f.read(len(MAGIE_FICHIER)) == MAGIE_FICHIER
    except OSError:
        return False


def identifiant_fichier(chemin: Path) -> bytes | None:
    with open(chemin, "rb") as f:
        if f.read(len(MAGIE_FICHIER)) != MAGIE_FICHIER:
            return None
        return f.read(8)


def _nonce(prefixe: bytes, numero: int) -> bytes:
    return prefixe + numero.to_bytes(4, "big")


def chiffrer_fichier(source: Path, cible: Path, dossier: Path | None = None) -> None:
    secret = cle_active(dossier)
    aes = AESGCM(_derivee(secret, "sauvegardes"))
    prefixe = secrets.token_bytes(8)
    entete = MAGIE_FICHIER + identifiant(secret) + prefixe
    with open(source, "rb") as f, open(cible, "wb") as sortie:
        sortie.write(entete)
        numero = 0
        morceau = f.read(MORCEAU)
        while True:
            suivant = f.read(MORCEAU)
            dernier = not suivant
            sortie.write(aes.encrypt(_nonce(prefixe, numero), morceau, entete + (b"\x01" if dernier else b"\x00")))
            if dernier:
                break
            morceau, numero = suivant, numero + 1


class _Neant:
    def write(self, _):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False


def dechiffrer_fichier(source: Path, cible: Path | None, dossier: Path | None = None) -> None:
    """Lève CleInconnue (autre installation) ou Abime (modifié, coupé, fabriqué).
    Sans cible : vérifie seulement que tout le fichier est authentique et complet."""
    with open(source, "rb") as f, (open(cible, "wb") if cible else _Neant()) as sortie:
        entete = f.read(len(MAGIE_FICHIER) + 16)
        if len(entete) != len(MAGIE_FICHIER) + 16 or not entete.startswith(MAGIE_FICHIER):
            raise Abime("ce n'est pas une sauvegarde chiffrée de Gérimo")
        secret = _par_identifiant(entete[len(MAGIE_FICHIER):len(MAGIE_FICHIER) + 8], dossier)
        aes = AESGCM(_derivee(secret, "sauvegardes"))
        prefixe = entete[-8:]
        numero = 0
        bloc = f.read(MORCEAU + 16)
        while True:
            suivant = f.read(MORCEAU + 16)
            dernier = not suivant
            try:
                sortie.write(aes.decrypt(_nonce(prefixe, numero), bloc, entete + (b"\x01" if dernier else b"\x00")))
            except InvalidTag:
                raise Abime("fichier modifié ou incomplet") from None
            if dernier:
                break
            bloc, numero = suivant, numero + 1


# ---------- Secrets dans la base (Paramètres) ----------

def chiffrer_secret(valeur: str, dossier: Path | None = None) -> str:
    if not valeur or valeur.startswith(PREFIXE_SECRET):
        return valeur
    secret = cle_active(dossier)
    nonce = secrets.token_bytes(12)
    ident = identifiant(secret)
    chiffre = AESGCM(_derivee(secret, "secrets")).encrypt(nonce, valeur.encode("utf-8"), ident)
    return PREFIXE_SECRET + base64.urlsafe_b64encode(ident + nonce + chiffre).decode()


def dechiffrer_secret(valeur: str, dossier: Path | None = None) -> str:
    """Un secret en clair (d'avant le coffre) est rendu tel quel. Lève CleInconnue ou Abime."""
    if not valeur or not valeur.startswith(PREFIXE_SECRET):
        return valeur
    try:
        brut = base64.urlsafe_b64decode(valeur[len(PREFIXE_SECRET):])
    except ValueError:
        raise Abime("secret illisible") from None
    ident, nonce, chiffre = brut[:8], brut[8:20], brut[20:]
    try:
        return AESGCM(_derivee(_par_identifiant(ident, dossier), "secrets")).decrypt(nonce, chiffre, ident).decode("utf-8")
    except InvalidTag:
        raise Abime("secret modifié") from None


def disponible() -> bool:
    """Le trousseau peut-il être lu/créé ? (dossier en écriture)"""
    try:
        cles()
        return True
    except (OSError, ValueError):
        return False


if os.getenv("GERIMO_COFFRE_DOSSIER"):  # essais : un trousseau à part
    DOSSIER_DEFAUT = Path(os.environ["GERIMO_COFFRE_DOSSIER"])
