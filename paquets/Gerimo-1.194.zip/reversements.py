"""Précomptabilité, partie 2 : reversements aux propriétaires et aux vendeurs, carnet de RIB, ordre de virement.

- Dû à un propriétaire = loyers encaissés − commission − dépenses à sa charge (jamais les cautions, qui restent
  un dépôt de garantie) ; reste à verser = dû − reversements déjà faits.
- Vente faite en intermédiaire : le vendeur reçoit le prix, moins la commission si c'est lui qui la paie ;
  le versement est saisi le jour où il est réellement fait (choix de Boss du 06/10/2026).
- Chaque reversement sort de la trésorerie (caisse, banque, Mobile Money) et donne un bordereau signé ;
  un virement donne en plus un ordre de virement à remettre à la banque (Gérimo ne touche jamais au compte).
- Les paiements repris d'un ancien fichier (REP-) ne comptent pas : ils ont été reversés avant Gérimo.
- Caution : rendue au locataire qui part ; la retenue éventuelle (réparations, état des lieux de sortie)
  revient au propriétaire et s'ajoute à ce qui lui est dû.
- Période clôturée par l'Admin : plus d'ajout ni de suppression (periode.py).

Droits : Admin, Caisse et Comptable (module Trésorerie) ; suppression par l'Admin avec son mot de passe.
"""
from collections import defaultdict
from datetime import date
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import Field
from sqlalchemy.orm import Session as SessionDB, selectinload

import banque
from entreprise import est_entreprise
import parametres
import periode
import recus
import sejours
import tresorerie
from commun import (Formulaire, NomPersonne, Paragraphe, Suppression, Telephone, Texte, charger, enregistrer,
                    montant, numero_suivant, supprimer)
from models import (CATEGORIES_BENEFICIAIRE, MODES_PAIEMENT, AchatVente, Beneficiaire, CompteTresorerie,
                    Contrat, Depense, EtatDesLieux, Logement, Paiement, Proprietaire, Reversement, Utilisateur)
from securite import confirmer_mot_de_passe_admin, exiger_admin, exiger_module, get_db

router = APIRouter(prefix="/api")
acces = exiger_module("tresorerie")
ZERO = Decimal(0)


def net_vendeur(o: AchatVente) -> Decimal:
    commission = o.commission_montant or ZERO
    return o.montant - (commission if o.commission_payee_par == "Vendeur" else ZERO)


# ---------- Ce qui est dû ----------

def situation(db: SessionDB) -> dict:
    """Reste à verser à chaque propriétaire et à chaque vendeur, et cautions détenues."""
    proprietaires = {p.id: p for p in db.query(Proprietaire)}
    lignes = defaultdict(lambda: {"loyers_nets": ZERO, "depenses": ZERO, "verse": ZERO,
                                  "biens": defaultdict(lambda: {"loyers_nets": ZERO, "depenses": ZERO})})
    cautions_contrat = defaultdict(lambda: ZERO)
    paiements = db.query(Paiement).options(
        selectinload(Paiement.encaissement),
        selectinload(Paiement.contrat).selectinload(Contrat.logement).selectinload(Logement.cite),
    ).filter(Paiement.statut_paiement == "Payé")
    for p in paiements:
        if (p.numero_recu or "").startswith(tresorerie.PREFIXE_REPRISE) or p.encaissement is None:
            continue
        cautions_contrat[p.contrat_id] += p.encaissement.montant_caution or ZERO
        cite = p.contrat.logement.cite
        if cite.proprietaire_id is None:
            continue
        net = p.encaissement.montant_reverse or ZERO
        lignes[cite.proprietaire_id]["loyers_nets"] += net
        lignes[cite.proprietaire_id]["biens"][cite.nom]["loyers_nets"] += net
    for v in sejours.versements(db):  # séjours en courte durée : même partage que les loyers
        cite = v.reservation.logement.cite
        if cite.proprietaire_id is not None:
            lignes[cite.proprietaire_id]["loyers_nets"] += v.montant_reverse
            lignes[cite.proprietaire_id]["biens"][cite.nom]["loyers_nets"] += v.montant_reverse
    for d in db.query(Depense).options(selectinload(Depense.cite)).filter(Depense.a_la_charge_de == "Propriétaire"):
        if d.cite.proprietaire_id is not None:
            lignes[d.cite.proprietaire_id]["depenses"] += d.montant
            lignes[d.cite.proprietaire_id]["biens"][d.cite.nom]["depenses"] += d.montant
    verse_vente = defaultdict(lambda: ZERO)
    rendu_contrat = defaultdict(lambda: {"rendu": ZERO, "retenue": ZERO})
    for r in db.query(Reversement).options(selectinload(Reversement.contrat).selectinload(Contrat.logement)
                                           .selectinload(Logement.cite)):
        if r.type_reversement == "Loyers":
            lignes[r.proprietaire_id]["verse"] += r.montant
        elif r.type_reversement == "Vente":
            verse_vente[r.achat_vente_id] += r.montant
        else:
            rendu_contrat[r.contrat_id]["rendu"] += r.montant
            rendu_contrat[r.contrat_id]["retenue"] += r.retenue or ZERO
            cite = r.contrat.logement.cite
            if r.retenue and cite.proprietaire_id is not None:  # la retenue revient au propriétaire
                lignes[cite.proprietaire_id]["loyers_nets"] += r.retenue
                lignes[cite.proprietaire_id]["biens"][cite.nom]["loyers_nets"] += r.retenue

    resultat_proprietaires = []
    for pid, l in lignes.items():
        p = proprietaires.get(pid)
        du = l["loyers_nets"] - l["depenses"]
        resultat_proprietaires.append({
            "id": pid, "nom": p.nom_complet if p else "?", "telephone": (p.telephone or "") if p else "",
            "entreprise": est_entreprise(p.nom_complet if p else ""),
            "loyers_nets": l["loyers_nets"], "depenses": l["depenses"], "du": du, "verse": l["verse"],
            "reste": du - l["verse"],
            "biens": [{"bien": nom, "loyers_nets": b["loyers_nets"], "depenses": b["depenses"]}
                      for nom, b in sorted(l["biens"].items())]})
    resultat_proprietaires.sort(key=lambda x: (x["entreprise"], -x["reste"], x["nom"]))

    ventes = []
    for o in db.query(AchatVente).filter(AchatVente.type_operation == "Vente indirecte") \
            .order_by(AchatVente.date_operation.desc()):
        net = net_vendeur(o)
        ventes.append({"id": o.id, "numero": o.numero, "date": o.date_operation, "vendeur": o.proprietaire_nom or "",
                       "acheteur": o.partie_nom, "designation": o.designation or "", "net": net,
                       "verse": verse_vente[o.id], "reste": net - verse_vente[o.id]})
    du_proprietaires = sum((x["reste"] for x in resultat_proprietaires if not x["entreprise"] and x["reste"] > 0), ZERO)
    du_vendeurs = sum((v["reste"] for v in ventes if v["reste"] > 0), ZERO)

    # Cautions détenues, contrat par contrat (la retenue proposée vient de l'état des lieux de sortie)
    retenues_edl = {}
    for e in db.query(EtatDesLieux).filter(EtatDesLieux.type_edl == "Sortie").order_by(EtatDesLieux.date_edl):
        retenues_edl[e.contrat_id] = e.retenues or ZERO
    cautions = []
    ids = [cid for cid, v in cautions_contrat.items() if v]
    contrats = {c.id: c for c in db.query(Contrat).options(selectinload(Contrat.locataire),
                                                           selectinload(Contrat.logement).selectinload(Logement.cite))
                .filter(Contrat.id.in_(ids))} if ids else {}
    for cid in ids:
        c, deja = contrats[cid], rendu_contrat[cid]
        reste = cautions_contrat[cid] - deja["rendu"] - deja["retenue"]
        if reste <= 0:
            continue
        cautions.append({"contrat_id": cid, "numero_contrat": c.numero_contrat, "locataire": c.locataire.nom_complet,
                         "telephone": c.locataire.telephone or "", "statut": c.statut_contrat,
                         "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}",
                         "encaisse": cautions_contrat[cid], "reste": reste,
                         "a_rendre": c.statut_contrat in ("Résilié", "Expiré")
                                     or bool(c.date_depart and c.date_depart <= date.today()),
                         "retenue_edl": min(retenues_edl.get(cid, ZERO), reste)})
    cautions.sort(key=lambda x: (not x["a_rendre"], x["locataire"]))
    return {"proprietaires": resultat_proprietaires, "ventes": ventes, "cautions_detail": cautions,
            "cautions": sum((x["reste"] for x in cautions), ZERO),
            "du_proprietaires": du_proprietaires, "du_vendeurs": du_vendeurs}


def _j(valeur):
    """Montants Decimal → nombres, dates → texte (récursif)."""
    if isinstance(valeur, Decimal):
        return montant(valeur)
    if isinstance(valeur, date):
        return valeur.isoformat()
    if isinstance(valeur, dict):
        return {k: _j(v) for k, v in valeur.items()}
    if isinstance(valeur, list):
        return [_j(v) for v in valeur]
    return valeur


@router.get("/reversements/a-verser")
def a_verser(utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    s = situation(db)
    s["vendeurs_a_payer"] = [v for v in s["ventes"] if v["reste"] > 0]
    from biens import libelles_proprietaires
    proprietaires = db.query(Proprietaire).order_by(Proprietaire.nom_complet).all()
    libelles = libelles_proprietaires(proprietaires)  # homonymes : nom suivi du téléphone
    s["proprietaires_liste"] = [{"id": p.id, "nom": libelles[p.id]} for p in proprietaires]
    return _j(s)


# ---------- Carnet de RIB ----------

class BeneficiaireIn(Formulaire):
    nom: NomPersonne = Field(min_length=2, max_length=150)
    categorie: Literal[CATEGORIES_BENEFICIAIRE] = "Propriétaire"
    proprietaire_id: int | None = None
    banque_nom: Texte | None = Field(None, max_length=120)
    titulaire: Texte | None = Field(None, max_length=150)
    banque_code: str | None = Field(None, max_length=10)
    banque_guichet: str | None = Field(None, max_length=10)
    banque_compte: str | None = Field(None, max_length=20)
    banque_cle_rib: str | None = Field(None, max_length=4)
    iban: str | None = Field(None, max_length=45)
    bic: str | None = Field(None, max_length=15)
    mobile_money: Telephone | None = Field(None, max_length=30)
    observation: Paragraphe | None = Field(None, max_length=500)
    actif: bool = True


def beneficiaire_json(b: Beneficiaire) -> dict:
    return {"id": b.id, "nom": b.nom, "categorie": b.categorie, "proprietaire_id": b.proprietaire_id,
            "proprietaire": b.proprietaire.nom_complet if b.proprietaire else None,
            "banque_nom": b.banque_nom or "", "titulaire": b.titulaire or "", "banque_code": b.banque_code or "",
            "banque_guichet": b.banque_guichet or "", "banque_compte": b.banque_compte or "",
            "banque_cle_rib": b.banque_cle_rib or "", "iban": b.iban or "", "bic": b.bic or "",
            "rib": banque.rib_lisible(b.banque_code, b.banque_guichet, b.banque_compte, b.banque_cle_rib),
            "iban_lisible": banque.iban_lisible(b.iban), "mobile_money": b.mobile_money or "",
            "observation": b.observation or "", "actif": b.actif,
            "virement_possible": bool(b.iban or (b.banque_code and b.banque_guichet and b.banque_compte and b.banque_cle_rib))}


@router.get("/beneficiaires")
def liste_beneficiaires(utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    liste = db.query(Beneficiaire).options(selectinload(Beneficiaire.proprietaire)) \
        .order_by(Beneficiaire.actif.desc(), Beneficiaire.nom).all()
    return [beneficiaire_json(b) for b in liste]


def appliquer_beneficiaire(db: SessionDB, b: Beneficiaire, d: BeneficiaireIn) -> None:
    v = banque.verifier(d.banque_code or "", d.banque_guichet or "", d.banque_compte or "", d.banque_cle_rib or "",
                        d.iban or "", d.bic or "")
    rib = [v["code"], v["guichet"], v["compte"], v["cle"]]
    if any(rib) and not all(rib):
        raise HTTPException(status_code=400, detail="RIB incomplet : renseignez les 4 parties (code banque, guichet, "
                                                    "numéro de compte et clé), ou seulement l'IBAN.")
    if not (any(rib) or v["iban"] or d.mobile_money):
        raise HTTPException(status_code=400, detail="Indiquez au moins un RIB, un IBAN ou un numéro Mobile Money.")
    if d.proprietaire_id is not None:
        charger(db, Proprietaire, d.proprietaire_id, "Propriétaire introuvable.")
    b.nom, b.categorie = d.nom, d.categorie
    b.proprietaire_id = d.proprietaire_id if d.categorie == "Propriétaire" else None
    b.banque_nom, b.titulaire = d.banque_nom or None, d.titulaire or None
    b.banque_code, b.banque_guichet, b.banque_compte, b.banque_cle_rib = (x or None for x in rib)
    b.iban, b.bic = v["iban"] or None, v["bic"] or None
    b.mobile_money, b.observation, b.actif = d.mobile_money or None, d.observation or None, d.actif


@router.post("/beneficiaires")
def creer_beneficiaire(d: BeneficiaireIn, utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    b = Beneficiaire()
    appliquer_beneficiaire(db, b, d)
    db.add(b)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": b.id}


@router.put("/beneficiaires/{beneficiaire_id}")
def modifier_beneficiaire(beneficiaire_id: int, d: BeneficiaireIn, utilisateur: Utilisateur = Depends(acces),
                          db: SessionDB = Depends(get_db)):
    b = charger(db, Beneficiaire, beneficiaire_id, "Bénéficiaire introuvable.")
    appliquer_beneficiaire(db, b, d)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": b.id}


@router.post("/beneficiaires/{beneficiaire_id}/supprimer")
def supprimer_beneficiaire(beneficiaire_id: int, donnees: Suppression, admin: Utilisateur = Depends(exiger_admin),
                           db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    return supprimer(db, charger(db, Beneficiaire, beneficiaire_id, "Bénéficiaire introuvable."),
                     "Suppression impossible.")


# ---------- Reversements ----------

class ReversementIn(Formulaire):
    type_reversement: Literal["Loyers", "Vente", "Caution"]
    proprietaire_id: int | None = None
    achat_vente_id: int | None = None
    contrat_id: int | None = None                      # restitution de caution
    montant: Decimal = Field(ge=0, max_digits=14, decimal_places=2)
    retenue: Decimal = Field(Decimal(0), ge=0, max_digits=14, decimal_places=2)
    motif_retenue: Texte | None = Field(None, max_length=500)
    date_reversement: date
    compte_id: int
    mode_paiement: Literal[MODES_PAIEMENT]
    beneficiaire_id: int | None = None
    reference: Texte | None = Field(None, max_length=80)
    observation: Texte | None = Field(None, max_length=500)


def reversement_json(r: Reversement) -> dict:
    return {"id": r.id, "numero": r.numero, "type": r.type_reversement, "beneficiaire": r.beneficiaire_nom,
            "retenue": montant(r.retenue), "contrat": r.contrat.numero_contrat if r.contrat else None,
            "date": r.date_reversement.isoformat(), "montant": montant(r.montant), "reste_apres": montant(r.reste_apres),
            "compte": r.compte.nom, "mode_paiement": r.mode_paiement, "reference": r.reference or "",
            "observation": r.observation or "", "vente": r.operation.numero if r.operation else None,
            "rib": bool(r.beneficiaire and beneficiaire_json(r.beneficiaire)["virement_possible"]),
            "saisi_par": r.auteur.nom_complet if r.auteur else ""}


@router.get("/reversements")
def liste_reversements(utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    liste = db.query(Reversement).options(selectinload(Reversement.compte), selectinload(Reversement.operation),
                                          selectinload(Reversement.contrat),
                                          selectinload(Reversement.beneficiaire), selectinload(Reversement.auteur)) \
        .order_by(Reversement.date_reversement.desc(), Reversement.id.desc()).limit(500).all()
    return [reversement_json(r) for r in liste]


@router.post("/reversements")
def creer_reversement(d: ReversementIn, utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    if d.date_reversement > date.today():
        raise HTTPException(status_code=400, detail="La date du versement ne peut pas être dans le futur.")
    periode.verifier_ouverte(db, d.date_reversement)
    if d.type_reversement != "Caution":
        d.retenue, d.motif_retenue = ZERO, None
    if d.montant + d.retenue <= 0:
        raise HTTPException(status_code=400, detail="Indiquez un montant.")
    compte = charger(db, CompteTresorerie, d.compte_id, "Compte introuvable.")
    if not compte.actif:
        raise HTTPException(status_code=400, detail="Ce compte est fermé.")
    if d.date_reversement < compte.date_ouverture:
        raise HTTPException(status_code=400, detail=f"Le suivi du compte « {compte.nom} » commence le "
                                                    f"{compte.date_ouverture:%d/%m/%Y} : date trop ancienne.")
    beneficiaire = None
    if d.beneficiaire_id is not None:
        beneficiaire = charger(db, Beneficiaire, d.beneficiaire_id, "RIB introuvable dans le carnet.")
        if not beneficiaire.actif:
            raise HTTPException(status_code=400, detail="Ce RIB n'est plus actif dans le carnet.")
    # le numéro est réservé d'abord : son verrou empêche deux postes de verser en même temps le même reste
    numero = numero_suivant(db, Reversement.numero, f"REV-{date.today().year}", 4)
    s = situation(db)
    if d.type_reversement == "Loyers":
        if d.proprietaire_id is None:
            raise HTTPException(status_code=400, detail="Choisissez le propriétaire.")
        ligne = next((p for p in s["proprietaires"] if p["id"] == d.proprietaire_id), None)
        proprietaire = charger(db, Proprietaire, d.proprietaire_id, "Propriétaire introuvable.")
        if ligne is None or ligne["entreprise"]:
            raise HTTPException(status_code=409, detail="Rien à reverser à ce propriétaire.")
        nom, reste, achat_vente_id = proprietaire.nom_complet, ligne["reste"], None
    elif d.type_reversement == "Vente":
        if d.achat_vente_id is None:
            raise HTTPException(status_code=400, detail="Choisissez la vente concernée.")
        ligne = next((v for v in s["ventes"] if v["id"] == d.achat_vente_id), None)
        if ligne is None:
            raise HTTPException(status_code=404, detail="Vente faite en intermédiaire introuvable.")
        nom, reste, achat_vente_id = ligne["vendeur"] or "Vendeur", ligne["reste"], ligne["id"]
    else:
        if d.contrat_id is None:
            raise HTTPException(status_code=400, detail="Choisissez le contrat.")
        ligne = next((x for x in s["cautions_detail"] if x["contrat_id"] == d.contrat_id), None)
        if ligne is None:
            raise HTTPException(status_code=409, detail="Aucune caution à rendre sur ce contrat.")
        if d.retenue and not d.motif_retenue:
            raise HTTPException(status_code=400, detail="Indiquez le motif de la retenue (ex : réparations constatées "
                                                        "à l'état des lieux de sortie).")
        if d.montant + d.retenue > ligne["reste"]:
            raise HTTPException(status_code=409, detail=f"Rendu + retenue dépassent la caution détenue "
                                                        f"({recus.francs(ligne['reste'])}).")
        nom, reste, achat_vente_id = ligne["locataire"], ligne["reste"] - d.retenue, None
    if d.montant > reste:
        raise HTTPException(status_code=409, detail=f"Le montant dépasse le reste à verser "
                                                    f"({recus.francs(max(reste, ZERO))}).")
    if compte.type_compte == "Caisse":
        disponible = tresorerie.soldes(db, d.date_reversement)[compte.id]
        if d.montant > disponible:
            raise HTTPException(status_code=409, detail=f"La caisse « {compte.nom} » ne contient que "
                                                        f"{recus.francs(disponible)} à cette date.")
    r = Reversement(numero=numero, type_reversement=d.type_reversement,
                    proprietaire_id=d.proprietaire_id if d.type_reversement == "Loyers" else None,
                    achat_vente_id=achat_vente_id, beneficiaire_nom=nom,
                    beneficiaire_id=beneficiaire.id if beneficiaire else None, date_reversement=d.date_reversement,
                    montant=d.montant, reste_apres=reste - d.montant, compte_id=compte.id,
                    mode_paiement=d.mode_paiement, reference=d.reference or None, observation=d.observation or None,
                    contrat_id=d.contrat_id if d.type_reversement == "Caution" else None, retenue=d.retenue,
                    motif_retenue=d.motif_retenue or None, saisi_par=utilisateur.id)
    db.add(r)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": r.id, "numero": r.numero, "reste_apres": montant(r.reste_apres)}


@router.post("/reversements/{reversement_id}/supprimer")
def supprimer_reversement(reversement_id: int, donnees: Suppression, admin: Utilisateur = Depends(exiger_admin),
                          db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    r = charger(db, Reversement, reversement_id, "Reversement introuvable.")
    periode.verifier_ouverte(db, r.date_reversement)
    return supprimer(db, r, "Suppression impossible.")


# ---------- Documents : bordereau (signé par le bénéficiaire) et ordre de virement (pour la banque) ----------

def _coordonnees(b: Beneficiaire | None) -> dict:
    if b is None:
        return {}
    return {"banque": b.banque_nom or "", "titulaire": b.titulaire or b.nom,
            "rib": banque.rib_lisible(b.banque_code, b.banque_guichet, b.banque_compte, b.banque_cle_rib),
            "iban": banque.iban_lisible(b.iban), "bic": b.bic or "", "mobile_money": b.mobile_money or ""}


def donnees_document(db: SessionDB, r: Reversement) -> dict:
    p = parametres.tous(db)
    caution = {}
    if r.type_reversement == "Loyers":
        motif = "Reversement des loyers nets (loyers encaissés, moins la commission de gestion et les dépenses à sa charge)"
    elif r.type_reversement == "Caution":
        c = r.contrat
        motif = (f"Restitution de la caution (dépôt de garantie) — contrat N° {c.numero_contrat}, "
                 f"logement {c.logement.numero_logement}, {c.logement.cite.nom}")
        caution = {"retenue": recus.francs(r.retenue), "motif_retenue": r.motif_retenue or "",
                   "caution_avant": recus.francs(r.montant + r.retenue + r.reste_apres)}
    else:
        o = r.operation
        motif = f"Produit net de la vente N° {o.numero} à {o.partie_nom} : {o.designation or ''}".strip(" :")
    return {
        "numero": r.numero, "date": r.date_reversement.strftime("%d/%m/%Y"), "beneficiaire": r.beneficiaire_nom,
        "montant": r.montant, "montant_lettres": recus.en_lettres(r.montant), "motif": motif,
        "mode": r.mode_paiement, "compte": r.compte.nom, "reference": r.reference or "",
        "reste_apres": recus.francs(r.reste_apres), "type": r.type_reversement,
        "saisi_par": r.auteur.nom_complet if r.auteur else "", "coordonnees": _coordonnees(r.beneficiaire),
        "caution": caution,
        "entreprise": {"banque": p["banque_nom"], "titulaire": p["banque_titulaire"] or recus.ENTETE["nom"],
                       "rib": banque.rib_lisible(p["banque_code"], p["banque_guichet"], p["banque_compte"],
                                                 p["banque_cle_rib"]),
                       "iban": banque.iban_lisible(p["banque_iban"]), "bic": p["banque_bic"]},
    }


def _charger_reversement(db: SessionDB, reversement_id: int) -> Reversement:
    return charger(db, Reversement, reversement_id, "Reversement introuvable.")


def _pdf(contenu: bytes, nom: str) -> Response:
    return Response(contenu, media_type="application/pdf", headers={"Content-Disposition": f'inline; filename="{nom}"'})


@router.get("/reversements/{reversement_id}/bordereau")
def bordereau(reversement_id: int, utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    r = _charger_reversement(db, reversement_id)
    return _pdf(recus.bordereau_reversement_pdf(donnees_document(db, r)), f"Bordereau {r.numero}.pdf")


@router.get("/reversements/{reversement_id}/ordre-virement")
def ordre_virement(reversement_id: int, utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    r = _charger_reversement(db, reversement_id)
    d = donnees_document(db, r)
    if r.mode_paiement != "Virement":
        raise HTTPException(status_code=409, detail="L'ordre de virement ne concerne que les versements par virement.")
    if not (d["coordonnees"].get("rib") or d["coordonnees"].get("iban")):
        raise HTTPException(status_code=409, detail="Aucun RIB du bénéficiaire n'a été choisi pour ce versement.")
    if not (d["entreprise"]["rib"] or d["entreprise"]["iban"]):
        raise HTTPException(status_code=409, detail="Le RIB de l'entreprise n'est pas renseigné : l'Admin doit "
                                                    "le saisir dans Paramètres → Réglages → Informations bancaires.")
    return _pdf(recus.ordre_virement_pdf(d), f"Ordre de virement {r.numero}.pdf")
