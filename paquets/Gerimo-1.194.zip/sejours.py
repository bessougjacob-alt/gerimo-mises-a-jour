"""Location courte durée / meublée : réservations à la nuit (séjours).

Règles (vérifiées ici, côté serveur) :
- Un logement est proposé en courte durée quand un prix par nuit lui est donné (Admin ou Gestionnaire de ses
  biens). Un logement loué au mois (statut « Occupé ») ne peut pas l'être.
- Réservation : client, arrivée, départ (nuits = départ − arrivée), prix par nuit, remise éventuelle.
  Deux séjours actifs ne peuvent pas se chevaucher dans le même logement.
- Versements : acompte puis solde, jamais plus que le reste dû ; un reçu SEJ-AAAA-NNNNN par versement.
  La commission de gestion du bien s'applique comme sur les loyers (montant reversé = versé − commission).
- Annuler une réservation : Admin ou Gestionnaire tant que rien n'est versé ; avec des versements, Admin
  seulement (l'acompte reste acquis, sauf si l'Admin annule aussi le versement).
- Annuler un versement : Admin, mot de passe redemandé ; rien n'est effacé. Périodes clôturées respectées.
- Droits : Admin, Gestionnaire (ses biens) et Caisse (tous les biens, pour encaisser).
"""
from datetime import date, datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path
from typing import Literal
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session as SessionDB, selectinload

import periode
import recus
import tresorerie
from commun import Formulaire, NomPersonne, Telephone, Texte, charger, montant, numero_suivant
from models import (MODES_PAIEMENT, Cite, Logement, PaiementSejour, Reservation, Utilisateur)
from securite import (cites_autorisees, confirmer_mot_de_passe_admin, exiger_admin, exiger_module, get_db,
                      verifier_cite_autorisee)
from whatsapp import lire_modeles, numero_whatsapp

router = APIRouter(prefix="/api")
acces = exiger_module("sejours")
ZERO = Decimal(0)
ACTIFS = ("Confirmée", "Arrivé")          # séjours qui bloquent le logement
NUITS_MAX = 365
DOSSIER = Path(__file__).parent / "documents" / "sejours"


# ---------- Outils ----------

def fr(d: date) -> str:
    return d.strftime("%d/%m/%Y")


def verse(r: Reservation) -> Decimal:
    return sum((p.montant for p in r.paiements if p.statut == "Payé"), ZERO)


def reservation_json(r: Reservation) -> dict:
    deja = verse(r)
    l = r.logement
    return {
        "id": r.id, "numero": r.numero, "statut": r.statut, "logement_id": r.logement_id,
        "logement": f"Logement {l.numero_logement}, {l.cite.nom}", "cite_id": l.cite_id,
        "client_nom": r.client_nom, "client_telephone": r.client_telephone or "",
        "client_piece": r.client_piece or "", "nb_personnes": r.nb_personnes,
        "date_arrivee": r.date_arrivee.isoformat(), "date_depart": r.date_depart.isoformat(),
        "nb_nuits": r.nb_nuits, "prix_nuit": montant(r.prix_nuit), "remise": montant(r.remise),
        "montant_total": montant(r.montant_total), "verse": montant(deja), "reste": montant(r.montant_total - deja),
        "notes": r.notes or "", "motif_annulation": r.motif_annulation or "",
        "paiements": [{"id": p.id, "numero_recu": p.numero_recu, "date_paiement": p.date_paiement.isoformat(),
                       "montant": montant(p.montant), "mode_paiement": p.mode_paiement, "statut": p.statut,
                       "motif_annulation": p.motif_annulation or ""} for p in r.paiements],
    }


def charger_reservation(db: SessionDB, utilisateur: Utilisateur, rid: int) -> Reservation:
    r = charger(db, Reservation, rid, "Réservation introuvable.")
    try:
        verifier_cite_autorisee(utilisateur, r.logement.cite_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Réservation introuvable.")
    return r


def logements_du_perimetre(db: SessionDB, utilisateur: Utilisateur):
    requete = db.query(Logement).join(Cite).options(selectinload(Logement.cite)).order_by(Cite.nom, Logement.numero_logement)
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None:
        requete = requete.filter(Logement.cite_id.in_(autorisees))
    return requete.all()


def chevauchement(db: SessionDB, logement_id: int, arrivee: date, depart: date, sauf: int | None = None):
    requete = db.query(Reservation).filter(Reservation.logement_id == logement_id, Reservation.statut.in_(ACTIFS),
                                           Reservation.date_arrivee < depart, Reservation.date_depart > arrivee)
    if sauf is not None:
        requete = requete.filter(Reservation.id != sauf)
    return requete.first()


def versements(db: SessionDB, debut: date | None = None, fin: date | None = None) -> list[PaiementSejour]:
    """Versements « Payé » (pour la trésorerie, la comptabilité, les rapports et les reversements)."""
    requete = db.query(PaiementSejour).options(
        selectinload(PaiementSejour.reservation).selectinload(Reservation.logement).selectinload(Logement.cite)
        .selectinload(Cite.proprietaire)).filter(PaiementSejour.statut == "Payé")
    if debut is not None:
        requete = requete.filter(PaiementSejour.date_paiement >= debut)
    if fin is not None:
        requete = requete.filter(PaiementSejour.date_paiement <= fin)
    return requete.order_by(PaiementSejour.date_paiement, PaiementSejour.id).all()


# ---------- Logements proposés en courte durée ----------

@router.get("/sejours/options")
def options(utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    logements = logements_du_perimetre(db, utilisateur)
    return {
        "modes_paiement": MODES_PAIEMENT,
        "peut_regler_logements": utilisateur.role.value in ("Admin", "Gestionnaire"),
        "logements": [{"id": l.id, "libelle": f"Logement {l.numero_logement}, {l.cite.nom}", "cite_id": l.cite_id,
                       "type_logement": l.type_logement, "statut_logement": l.statut_logement,
                       "prix_nuit": montant(l.prix_nuit) if l.prix_nuit is not None else None}
                      for l in logements],
    }


class PrixNuitIn(BaseModel):
    prix_nuit: Decimal | None = Field(None, gt=0, max_digits=12, decimal_places=2)  # vide = retirer


@router.put("/sejours/logements/{logement_id}")
def regler_logement(logement_id: int, d: PrixNuitIn, utilisateur: Utilisateur = Depends(acces),
                    db: SessionDB = Depends(get_db)):
    if utilisateur.role.value not in ("Admin", "Gestionnaire"):
        raise HTTPException(status_code=403, detail="Les logements en courte durée sont choisis par l'Admin "
                                                    "ou le Gestionnaire.")
    l = charger(db, Logement, logement_id, "Logement introuvable.")
    try:
        verifier_cite_autorisee(utilisateur, l.cite_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Logement introuvable.")
    if d.prix_nuit is not None and l.statut_logement == "Occupé":
        raise HTTPException(status_code=409, detail="Ce logement est loué au mois (contrat en cours) : "
                                                    "il ne peut pas être proposé à la nuit.")
    if d.prix_nuit is None and db.query(Reservation).filter(Reservation.logement_id == l.id,
                                                            Reservation.statut.in_(ACTIFS)).first():
        raise HTTPException(status_code=409, detail="Ce logement a des séjours à venir ou en cours : "
                                                    "terminez-les ou annulez-les d'abord.")
    l.prix_nuit = d.prix_nuit
    db.commit()
    return {"ok": True}


# ---------- Réservations ----------

class ReservationIn(Formulaire):
    logement_id: int
    client_nom: NomPersonne = Field(min_length=2, max_length=150)
    client_telephone: Telephone | None = Field(None, max_length=30)
    client_piece: Texte | None = Field(None, max_length=80)
    nb_personnes: int = Field(1, ge=1, le=50)
    date_arrivee: date
    date_depart: date
    prix_nuit: Decimal | None = Field(None, gt=0, max_digits=12, decimal_places=2)  # vide = prix du logement
    remise: Decimal = Field(Decimal(0), ge=0, max_digits=12, decimal_places=2)
    notes: Texte | None = Field(None, max_length=500)


def appliquer(db: SessionDB, utilisateur: Utilisateur, r: Reservation, d: ReservationIn) -> None:
    l = charger(db, Logement, d.logement_id, "Logement introuvable.")
    try:
        verifier_cite_autorisee(utilisateur, l.cite_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Logement introuvable.")
    if l.prix_nuit is None:
        raise HTTPException(status_code=409, detail="Ce logement n'est pas proposé en courte durée "
                                                    "(donnez-lui d'abord un prix par nuit).")
    if l.statut_logement == "Occupé":
        raise HTTPException(status_code=409, detail="Ce logement est loué au mois : pas de séjour possible.")
    nuits = (d.date_depart - d.date_arrivee).days
    if nuits < 1:
        raise HTTPException(status_code=400, detail="Le départ doit être au moins le lendemain de l'arrivée.")
    if nuits > NUITS_MAX:
        raise HTTPException(status_code=400, detail="Séjour trop long (un an au plus) : faites plutôt un bail.")
    autre = chevauchement(db, l.id, d.date_arrivee, d.date_depart, sauf=r.id)
    if autre:
        raise HTTPException(status_code=409, detail=f"Logement déjà réservé du {fr(autre.date_arrivee)} au "
                                                    f"{fr(autre.date_depart)} ({autre.client_nom}, N° {autre.numero}).")
    prix = d.prix_nuit or l.prix_nuit
    total = prix * nuits - d.remise
    if total <= 0:
        raise HTTPException(status_code=400, detail="La remise ne peut pas dépasser le prix du séjour.")
    if r.id is not None and total < verse(r):
        raise HTTPException(status_code=409, detail=f"Le client a déjà versé {recus.francs(verse(r))} : "
                                                    "le nouveau prix ne peut pas être plus bas.")
    r.logement_id, r.client_nom = l.id, d.client_nom
    r.client_telephone, r.client_piece = d.client_telephone or None, d.client_piece or None
    r.nb_personnes, r.date_arrivee, r.date_depart = d.nb_personnes, d.date_arrivee, d.date_depart
    r.prix_nuit, r.remise, r.montant_total, r.notes = prix, d.remise, total, d.notes or None


@router.get("/sejours")
def liste(debut: date | None = Query(None), fin: date | None = Query(None),
          utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    """Séjours qui touchent la période (par défaut : depuis 30 jours et à venir)."""
    debut = debut or date.today() - timedelta(days=30)
    requete = db.query(Reservation).join(Logement).options(
        selectinload(Reservation.logement).selectinload(Logement.cite), selectinload(Reservation.paiements)
    ).filter(Reservation.date_depart >= debut)
    if fin is not None:
        requete = requete.filter(Reservation.date_arrivee <= fin)
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None:
        requete = requete.filter(Logement.cite_id.in_(autorisees))
    return [reservation_json(r) for r in requete.order_by(Reservation.date_arrivee, Reservation.id).limit(1000)]


@router.post("/sejours")
def creer(d: ReservationIn, utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    r = Reservation(cree_par=utilisateur.id, statut="Confirmée")
    appliquer(db, utilisateur, r, d)
    r.numero = numero_suivant(db, Reservation.numero, f"RES-{date.today().year}", 4)
    db.add(r)
    db.commit()
    return {"id": r.id, "numero": r.numero, "montant_total": montant(r.montant_total)}


@router.put("/sejours/{reservation_id}")
def modifier(reservation_id: int, d: ReservationIn, utilisateur: Utilisateur = Depends(acces),
             db: SessionDB = Depends(get_db)):
    r = charger_reservation(db, utilisateur, reservation_id)
    if r.statut not in ACTIFS:
        raise HTTPException(status_code=409, detail=f"Ce séjour est « {r.statut} » : il ne se modifie plus.")
    appliquer(db, utilisateur, r, d)
    db.commit()
    return {"id": r.id}


class StatutIn(BaseModel):
    statut: Literal["Arrivé", "Parti"]


@router.post("/sejours/{reservation_id}/statut")
def changer_statut(reservation_id: int, d: StatutIn, utilisateur: Utilisateur = Depends(acces),
                   db: SessionDB = Depends(get_db)):
    r = charger_reservation(db, utilisateur, reservation_id)
    attendu = {"Arrivé": "Confirmée", "Parti": "Arrivé"}[d.statut]
    if r.statut != attendu:
        raise HTTPException(status_code=409, detail=f"Ce séjour est « {r.statut} ».")
    if d.statut == "Arrivé" and r.date_arrivee > date.today():
        raise HTTPException(status_code=409, detail=f"L'arrivée est prévue le {fr(r.date_arrivee)}.")
    r.statut = d.statut
    db.commit()
    return {"ok": True, "reste": montant(r.montant_total - verse(r))}


class AnnulationIn(BaseModel):  # pas Formulaire : le mot de passe ne doit pas être retouché
    motif: Texte | None = Field(None, max_length=500)
    mot_de_passe_admin: str | None = None


@router.post("/sejours/{reservation_id}/annuler")
def annuler_reservation(reservation_id: int, d: AnnulationIn, utilisateur: Utilisateur = Depends(acces),
                        db: SessionDB = Depends(get_db)):
    r = charger_reservation(db, utilisateur, reservation_id)
    if r.statut not in ACTIFS:
        raise HTTPException(status_code=409, detail=f"Ce séjour est déjà « {r.statut} ».")
    if verse(r) > 0:
        if utilisateur.role.value != "Admin":
            raise HTTPException(status_code=403, detail="Le client a déjà versé de l'argent : seul l'Admin peut "
                                                        "annuler ce séjour.")
        confirmer_mot_de_passe_admin(utilisateur, d.mot_de_passe_admin or "")
    elif utilisateur.role.value not in ("Admin", "Gestionnaire"):
        raise HTTPException(status_code=403, detail="Annulation réservée à l'Admin et au Gestionnaire.")
    r.statut = "Annulée"
    r.motif_annulation = (d.motif or "").strip() or None
    db.commit()
    return {"ok": True}


# ---------- Versements (acompte, solde) ----------

class VersementIn(Formulaire):
    montant: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    mode_paiement: Literal[MODES_PAIEMENT]
    date_paiement: date | None = None
    compte_id: int | None = None


@router.post("/sejours/{reservation_id}/paiements")
def encaisser(reservation_id: int, d: VersementIn, utilisateur: Utilisateur = Depends(acces),
              db: SessionDB = Depends(get_db)):
    r = charger_reservation(db, utilisateur, reservation_id)
    if r.statut == "Annulée":
        raise HTTPException(status_code=409, detail="Ce séjour est annulé.")
    jour = d.date_paiement or date.today()
    if jour > date.today():
        raise HTTPException(status_code=400, detail="La date du versement ne peut pas être dans le futur.")
    periode.verifier_ouverte(db, jour)
    reste = r.montant_total - verse(r)
    if reste <= 0:
        raise HTTPException(status_code=409, detail="Ce séjour est déjà entièrement réglé.")
    if d.montant > reste:
        raise HTTPException(status_code=400, detail=f"Il ne reste que {recus.francs(reste)} à payer pour ce séjour.")
    mandat = r.logement.cite.mandat_actuel
    if mandat is None:
        raise HTTPException(status_code=409, detail="La commission de gestion de ce bien n'est pas renseignée : "
                                                    "l'Admin doit la saisir (Bien → Modifier) avant l'encaissement.")
    pourcentage = mandat.pourcentage_commission
    commission = (d.montant * pourcentage / 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    p = PaiementSejour(
        reservation=r, date_paiement=jour, montant=d.montant, mode_paiement=d.mode_paiement,
        compte_id=tresorerie.verifier_compte_choisi(db, d.compte_id, d.mode_paiement),
        pourcentage_commission=pourcentage, commission=commission, montant_reverse=d.montant - commission,
        numero_recu=numero_suivant(db, PaiementSejour.numero_recu, f"SEJ-{date.today().year}", 5),
        encaisse_par=utilisateur.id, statut="Payé")
    db.add(p)
    db.commit()
    try:
        fabriquer_recu(p)
    except Exception:  # le reçu sera refait à la première ouverture
        pass
    return {"id": p.id, "numero_recu": p.numero_recu, "reste": montant(reste - d.montant)}


def fabriquer_recu(p: PaiementSejour) -> Path:
    r = p.reservation
    deja = sum((x.montant for x in r.paiements if x.statut == "Payé" and x.id <= p.id), ZERO)
    reste = r.montant_total - deja
    nature = "solde" if reste <= 0 else ("acompte" if deja == p.montant else "versement")
    donnees = {
        "numero": p.numero_recu, "date": fr(p.date_paiement), "client": r.client_nom,
        "montant": p.montant, "montant_lettres": recus.en_lettres(p.montant),
        "motif": f"Séjour en location meublée ({nature})",
        "sejour": f"Logement {r.logement.numero_logement}, {r.logement.cite.nom} — du {fr(r.date_arrivee)} "
                  f"au {fr(r.date_depart)} ({r.nb_nuits} nuit{'s' if r.nb_nuits > 1 else ''})",
        "reservation": r.numero, "mode": p.mode_paiement,
        "total": recus.francs(r.montant_total), "deja": recus.francs(deja), "reste": recus.francs(max(reste, ZERO)),
        "caissier": p.caissier.nom_complet if p.caissier else "",
    }
    chemin = DOSSIER / str(p.date_paiement.year) / f"{p.numero_recu}.pdf"
    chemin.parent.mkdir(parents=True, exist_ok=True)
    chemin.write_bytes(recus.recu_sejour_pdf(donnees))
    return chemin


@router.get("/sejours/paiements/{paiement_id}/recu")
def recu(paiement_id: int, utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    p = charger(db, PaiementSejour, paiement_id, "Versement introuvable.")
    charger_reservation(db, utilisateur, p.reservation_id)  # droits
    chemin = DOSSIER / str(p.date_paiement.year) / f"{p.numero_recu}.pdf"
    if not chemin.exists():
        if p.statut != "Payé":
            raise HTTPException(status_code=409, detail="Ce versement est annulé : pas de reçu.")
        chemin = fabriquer_recu(p)
    return FileResponse(chemin, media_type="application/pdf", filename=chemin.name, content_disposition_type="inline")


class AnnulationVersement(BaseModel):
    mot_de_passe_admin: str
    motif: Texte | None = Field(None, max_length=500)


@router.post("/sejours/paiements/{paiement_id}/annuler")
def annuler_versement(paiement_id: int, d: AnnulationVersement, admin: Utilisateur = Depends(exiger_admin),
                      db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, d.mot_de_passe_admin)
    p = charger(db, PaiementSejour, paiement_id, "Versement introuvable.")
    if p.statut != "Payé":
        raise HTTPException(status_code=409, detail="Ce versement est déjà annulé.")
    periode.verifier_ouverte(db, p.date_paiement)
    p.statut, p.date_annulation = "Annulé", datetime.now()
    p.motif_annulation = (d.motif or "").strip() or None
    db.commit()
    return {"ok": True}


# ---------- Calendrier et message au client ----------

@router.get("/sejours/calendrier")
def calendrier(mois: str = Query(..., pattern=r"^\d{4}-\d{2}$"), utilisateur: Utilisateur = Depends(acces),
               db: SessionDB = Depends(get_db)):
    debut = date(int(mois[:4]), int(mois[5:]), 1)
    fin = (debut.replace(day=28) + timedelta(days=4)).replace(day=1)  # 1er du mois suivant
    logements = [l for l in logements_du_perimetre(db, utilisateur) if l.prix_nuit is not None]
    ids = [l.id for l in logements]
    sejours = db.query(Reservation).filter(Reservation.logement_id.in_(ids), Reservation.statut != "Annulée",
                                           Reservation.date_arrivee < fin, Reservation.date_depart > debut).all() if ids else []
    return {
        "debut": debut.isoformat(), "nb_jours": (fin - debut).days,
        "logements": [{"id": l.id, "libelle": f"{l.numero_logement} — {l.cite.nom}", "prix_nuit": montant(l.prix_nuit)}
                      for l in logements],
        "sejours": [{"id": r.id, "logement_id": r.logement_id, "client": r.client_nom, "statut": r.statut,
                     "arrivee": r.date_arrivee.isoformat(), "depart": r.date_depart.isoformat()} for r in sejours],
    }


@router.post("/sejours/{reservation_id}/whatsapp")
def whatsapp(reservation_id: int, utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    r = charger_reservation(db, utilisateur, reservation_id)
    deja = verse(r)
    valeurs = {"client": r.client_nom, "numero": r.numero, "logement": r.logement.numero_logement,
               "bien": r.logement.cite.nom, "arrivee": fr(r.date_arrivee), "depart": fr(r.date_depart),
               "nuits": r.nb_nuits, "total": recus.francs(r.montant_total), "verse": recus.francs(deja),
               "reste": recus.francs(r.montant_total - deja), "entreprise": recus.ENTETE["nom"]}
    texte = quote(lire_modeles()["sejour"].format_map(recus._ValeursModele(valeurs)))
    numero = numero_whatsapp(r.client_telephone)
    return {"lien": f"https://wa.me/{numero}?text={texte}" if numero else f"https://wa.me/?text={texte}",
            "a_numero": bool(numero), "locataire": r.client_nom}
