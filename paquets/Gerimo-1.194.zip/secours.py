"""PC de secours : il vient chercher les sauvegardes du PC principal par le réseau, et peut prendre le relais.

Rôles (pc_secours/config.json, clé « role ») : absent = PC principal ; « secours » = en veille ;
« relais » = le PC de secours fait le serveur (le principal est en panne) ; « rendu » = il a rendu la main et attend
que le principal reprenne ses données.

Prendre le relais (PC de secours) : refusé si le PC principal répond encore ; la dernière copie reçue est restaurée,
le certificat Gérimo de l'agence est mis en place (les appareils lui font déjà confiance), puis le serveur démarre.
Rendre la main : le PC de secours se fige (plus aucune saisie), fait une dernière sauvegarde ; le PC principal, qui
attendait (service suspendu, avec un lien vers le PC de secours), la récupère, la restaure, puis reprend le service.
Le PC principal ne sert jamais pendant que le PC de secours tient le relais (pas de doubles données).

Côté PC principal (routes ci-dessous) :
- l'Admin crée un code de jumelage (9 chiffres, valable 30 minutes, une seule fois, 5 essais au plus) ;
- le PC de secours l'échange contre une clé secrète (jeton), gardée hachée par le principal ;
- avec ce jeton, et seulement avec lui, le PC de secours lit l'état et télécharge la dernière sauvegarde ;
- le principal note chaque copie emportée (journaux/secours_copies.json) et prévient l'Admin si le PC de secours
  ne vient plus (assistant) ; l'Admin peut oublier le PC de secours à tout moment.

Côté PC de secours (fonctions jumeler() et recuperer(), appelées par la fenêtre de Gérimo Serveur en mode secours) :
- réglages dans pc_secours/config.json, copies reçues dans pc_secours/sauvegardes/ (vérifiées, triées comme les autres) ;
- connexion chiffrée (https) au principal, toujours (jamais en clair) : au jumelage, le PC principal prouve qu'il
  connaît le code (preuve calculée avec le code, sans l'envoyer) et donne son certificat Gérimo ; le PC de secours
  ne continue qu'en vérifiant le serveur avec ce certificat. Un faux serveur glissé sur le réseau (qui ne connaît
  pas le code) est démasqué avant que le code ou la clé secrète ne circule.
- le trousseau de l'entreprise (coffre.py) est reçu avec le certificat : le PC de secours relit les sauvegardes
  chiffrées du principal ; les deux PC n'acceptent l'un de l'autre que des sauvegardes chiffrées avec cette clé.
"""
import hashlib
import hmac
import json
import secrets
import shutil
import socket
import ssl
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path, PurePosixPath
import io
import os
import threading
import time
import zipfile

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session as SessionDB

import certificats
import coffre
import sauvegarde
from models import Utilisateur
from securite import exiger_admin, get_db

router = APIRouter(prefix="/api")
ICI = Path(__file__).parent
EN_TETE = "X-Gerimo-Secours"
DUREE_CODE = timedelta(minutes=30)
ESSAIS_MAX = 5
RETARD_ALERTE = timedelta(hours=3)   # le PC de secours n'a pas emporté de copie depuis… → alerte
FICHIER_COPIES = ICI / "journaux" / "secours_copies.json"
PORT_HTTP = int(os.getenv("ISUP_PORT", "8000"))  # port du serveur de CE PC (8000 ; autre valeur pour les essais)
SURVEILLANCE = int(os.getenv("GERIMO_SURVEILLANCE_SECONDES", "60"))


def _hacher(texte: str) -> str:
    return hashlib.sha256(texte.encode()).hexdigest()


def cle_de_preuve(code: str) -> bytes:
    """Clé tirée du code de jumelage, lente à calculer (200 000 tours) : deviner le code à partir d'une preuve
    prendrait bien plus que les 30 minutes de validité du code."""
    chiffres = "".join(c for c in code if c.isdigit())
    return hashlib.pbkdf2_hmac("sha256", chiffres.encode(), b"gerimo/jumelage/v1", 200_000)


def preuve(cle: bytes, defi: str, autorite: str) -> str:
    return hmac.new(cle, f"{defi}\n{autorite}".encode(), hashlib.sha256).hexdigest()


def requete_https(request: Request) -> bool:
    """Les échanges qui donnent des clés passent en https (ou restent sur ce PC : tests, outils locaux)."""
    return request.url.scheme == "https" or (request.client.host if request.client else "") in ("testclient",)


# Le jumelage est un réglage DE CE PC, pas une donnée de l'agence : il est gardé dans un fichier (journaux/) et non
# dans la base. Ainsi une restauration (par exemple les données reprises du PC de secours) ne l'efface jamais.
FICHIER_JUMELAGE = ICI / "journaux" / "secours_jumelage.json"


def _lire(db, cle: str) -> str:
    try:
        return json.loads(FICHIER_JUMELAGE.read_text(encoding="utf-8")).get(cle, "")
    except (OSError, ValueError):
        return ""


def _ecrire(db, cle: str, valeur: str) -> None:
    try:
        donnees = json.loads(FICHIER_JUMELAGE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        donnees = {}
    donnees[cle] = valeur
    FICHIER_JUMELAGE.parent.mkdir(exist_ok=True)
    FICHIER_JUMELAGE.write_text(json.dumps(donnees), encoding="utf-8")


# ====================== Côté PC principal ======================

def jumelage(db: SessionDB) -> dict | None:
    """PC de secours jumelé : {"nom", "jumele_le"} ; None sinon."""
    if not _lire(db, "secours_jeton"):
        return None
    return {"nom": _lire(db, "secours_nom"), "jumele_le": _lire(db, "secours_jumele_le")}


def copies_emportees() -> dict:
    try:
        return json.loads(FICHIER_COPIES.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _ecrire_copies(**valeurs) -> None:
    """Gardé dans un fichier et non dans la base : sinon chaque copie serait un « changement » à sauvegarder."""
    donnees = copies_emportees()
    donnees.update(valeurs)
    FICHIER_COPIES.parent.mkdir(exist_ok=True)
    FICHIER_COPIES.write_text(json.dumps(donnees), encoding="utf-8")


def noter_copie(nom: str) -> None:
    _ecrire_copies(quand=datetime.now().isoformat(timespec="seconds"), fichier=nom)


def noter_adresse_secours(adresse: str, port: str = "") -> None:
    """Adresse du PC de secours sur le réseau : le principal la retient pour savoir s'il a pris le relais."""
    port = port if port.isdigit() else "8000"
    deja = copies_emportees()
    if adresse and (adresse, port) != (deja.get("adresse_secours"), deja.get("port_secours")):
        _ecrire_copies(adresse_secours=adresse, port_secours=port)


def en_retard(maintenant: datetime | None = None) -> dict | None:
    """Le PC de secours est-il à la traîne ? {"depuis": date de sa dernière copie} ou None."""
    liste = sauvegarde.sauvegardes(sauvegarde.DOSSIER)
    if not liste:
        return None
    copie = copies_emportees()
    derniere_emportee = None
    if copie.get("fichier"):
        m = sauvegarde.MOTIF_NOM.match(copie["fichier"])
        derniere_emportee = datetime.strptime(m.group(1), "%Y-%m-%d_%H%M%S") if m else None
    plus_recente = liste[-1][1]
    maintenant = maintenant or datetime.now()
    if derniere_emportee is not None and derniere_emportee >= plus_recente:
        return None
    if maintenant - plus_recente < RETARD_ALERTE:  # sauvegarde toute récente : il a le temps de venir
        return None
    return {"depuis": copie.get("quand")}


def verifier_jeton(db: SessionDB, jeton: str | None) -> None:
    attendu = _lire(db, "secours_jeton")
    if not attendu or not jeton or not hmac.compare_digest(attendu, _hacher(jeton)):
        raise HTTPException(status_code=403, detail="PC de secours non reconnu : refaites le jumelage.")


@router.get("/secours")
def etat_principal(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    j = jumelage(db)
    copie = copies_emportees()
    return {"jumele": j is not None, **(j or {}), "derniere_copie": copie.get("quand"),
            "derniere_copie_fichier": copie.get("fichier"), "en_retard": bool(j and en_retard())}


@router.post("/secours/code")
def creer_code(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    code = f"{secrets.randbelow(10 ** 9):09d}"
    _ecrire(db, "secours_code", json.dumps({"hache": _hacher(code), "essais": 0, "presentations": 0,
                                            "preuve": cle_de_preuve(code).hex(),
                                            "expire": (datetime.now() + DUREE_CODE).isoformat()}))
    db.commit()
    reseau = sorted(a for a in certificats.adresses_locales() if not a.startswith("127."))
    return {"code": f"{code[:3]}-{code[3:6]}-{code[6:]}", "valable_minutes": int(DUREE_CODE.total_seconds() // 60),
            "adresses": reseau}


class JumelageIn(BaseModel):
    code: str = Field(max_length=20)
    nom_pc: str = Field("", max_length=80)


class PresentationIn(BaseModel):
    defi: str = Field(min_length=32, max_length=64)


@router.post("/secours/presentation")
def se_presenter(d: PresentationIn, db: SessionDB = Depends(get_db)):
    """1re étape du jumelage : le PC principal donne son certificat Gérimo avec une preuve qu'il connaît le code
    (le code lui-même ne circule pas). 10 présentations au plus par code."""
    try:
        attente = json.loads(_lire(db, "secours_code") or "{}")
    except ValueError:
        attente = {}
    if not attente or datetime.fromisoformat(attente["expire"]) < datetime.now() or not attente.get("preuve"):
        raise HTTPException(status_code=403, detail="Pas de code de jumelage en cours (ou code expiré) : "
                                                    "créez-en un sur le PC principal.")
    attente["presentations"] = attente.get("presentations", 0) + 1
    _ecrire(db, "secours_code", "" if attente["presentations"] > 10 else json.dumps(attente))
    if attente["presentations"] > 10:
        raise HTTPException(status_code=403, detail="Trop d'essais : créez un nouveau code.")
    autorite = certificats.CA_CERT.read_text(encoding="ascii") if certificats.CA_CERT.exists() else ""
    return {"autorite": autorite, "preuve": preuve(bytes.fromhex(attente["preuve"]), d.defi, autorite)}


@router.post("/secours/jumeler")
def jumeler_principal(d: JumelageIn, request: Request, db: SessionDB = Depends(get_db)):
    """Appelé par le PC de secours (sans compte) : le code à usage unique donne la clé secrète. En https seulement."""
    if not requete_https(request):
        raise HTTPException(status_code=403, detail="Le jumelage passe par la connexion sécurisée (https).")
    try:
        attente = json.loads(_lire(db, "secours_code") or "{}")
    except ValueError:
        attente = {}
    if not attente or datetime.fromisoformat(attente["expire"]) < datetime.now():
        raise HTTPException(status_code=403, detail="Pas de code de jumelage en cours (ou code expiré) : "
                                                    "créez-en un sur le PC principal.")
    code = "".join(c for c in d.code if c.isdigit())
    if not hmac.compare_digest(attente["hache"], _hacher(code)):
        attente["essais"] += 1
        _ecrire(db, "secours_code", "" if attente["essais"] >= ESSAIS_MAX else json.dumps(attente))
        db.commit()
        raise HTTPException(status_code=403, detail="Code incorrect." + (" Trop d'essais : créez un nouveau code."
                                                                         if attente["essais"] >= ESSAIS_MAX else ""))
    jeton = secrets.token_urlsafe(32)
    _ecrire(db, "secours_code", "")
    _ecrire(db, "secours_jeton", _hacher(jeton))
    _ecrire(db, "secours_nom", d.nom_pc.strip()[:80] or "PC de secours")
    _ecrire(db, "secours_jumele_le", datetime.now().isoformat(timespec="seconds"))
    db.commit()
    import entreprise
    return {"jeton": jeton, "entreprise": entreprise.identite(db)["nom_complet"],
            "autorite": certificats.CA_CERT.read_text(encoding="ascii") if certificats.CA_CERT.exists() else ""}


@router.get("/secours/autorite")
def donner_autorite(request: Request, db: SessionDB = Depends(get_db),
                    jeton: str | None = Header(None, alias=EN_TETE)):
    """Le certificat Gérimo de l'agence (avec sa clé) : le PC de secours en aura besoin s'il prend le relais,
    pour que les téléphones et les postes lui fassent confiance sans rien réinstaller. En https seulement."""
    verifier_jeton(db, jeton)
    if not requete_https(request):
        raise HTTPException(status_code=403, detail="Ces clés ne passent que par la connexion sécurisée (https).")
    cles = coffre.exporter()  # trousseau de l'entreprise : pour relire les sauvegardes chiffrées
    if not (certificats.CA_CERT.exists() and certificats.CA_CLE.exists()):
        return {"cert": "", "cle": "", "cles": cles}
    return {"cert": certificats.CA_CERT.read_text(encoding="ascii"), "cle": certificats.CA_CLE.read_text(encoding="ascii"),
            "cles": cles}


@router.get("/secours/paquet")
def donner_paquet(db: SessionDB = Depends(get_db), jeton: str | None = Header(None, alias=EN_TETE)):
    """Les fichiers du logiciel de ce PC : le PC de secours se met à la même version, sans Internet."""
    verifier_jeton(db, jeton)
    import maj_fichiers
    from fastapi.responses import Response
    tampon = io.BytesIO()
    with zipfile.ZipFile(tampon, "w", zipfile.ZIP_DEFLATED) as z:
        for chemin in ICI.rglob("*"):
            relatif = PurePosixPath(chemin.relative_to(ICI).as_posix())
            if chemin.is_file() and maj_fichiers.chemin_autorise(relatif):
                z.write(chemin, str(relatif))
    return Response(tampon.getvalue(), media_type="application/zip")


@router.post("/secours/oublier")
def oublier(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    for cle in ("secours_jeton", "secours_nom", "secours_jumele_le", "secours_code"):
        _ecrire(db, cle, "")
    db.commit()
    FICHIER_COPIES.unlink(missing_ok=True)
    return {"ok": True}


@router.get("/secours/etat")
def etat_pour_le_secours(request: Request, db: SessionDB = Depends(get_db),
                         jeton: str | None = Header(None, alias=EN_TETE)):
    verifier_jeton(db, jeton)
    import version
    liste = sauvegarde.sauvegardes(sauvegarde.DOSSIER)
    derniere = liste[-1] if liste else None
    noter_adresse_secours(request.client.host if request.client else "", request.headers.get("X-Gerimo-Port", ""))
    infos = version.infos_version()
    return {"version": infos.get("version"), "numero": version.numero_de(infos),
            "derniere": {"fichier": derniere[0].name, "date": derniere[1].isoformat(),
                         "taille": derniere[0].stat().st_size} if derniere else None}


@router.get("/secours/sauvegarde/{nom}")
def donner_sauvegarde(nom: str, db: SessionDB = Depends(get_db), jeton: str | None = Header(None, alias=EN_TETE)):
    verifier_jeton(db, jeton)
    chemin = sauvegarde.DOSSIER / Path(nom).name
    if not sauvegarde.MOTIF_NOM.match(chemin.name) or not chemin.exists():
        raise HTTPException(status_code=404, detail="Sauvegarde introuvable.")
    noter_copie(chemin.name)
    return FileResponse(chemin, media_type="application/zip", filename=chemin.name)


# ====================== Côté PC de secours ======================

DOSSIER_SECOURS = ICI / "pc_secours"   # (nom différent du module secours.py)
CONFIG = DOSSIER_SECOURS / "config.json"
RECUES = DOSSIER_SECOURS / "sauvegardes"


def config() -> dict:
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _enregistrer_config(c: dict) -> None:
    DOSSIER_SECOURS.mkdir(exist_ok=True)
    CONFIG.write_text(json.dumps(c, ensure_ascii=False, indent=1), encoding="utf-8")


def adresses_possibles(saisie: str) -> list[str]:
    """« 192.168.1.10 » → https://…:8443 d'abord (chiffré), puis http://…:8000 ; une adresse complète est gardée ;
    « 192.168.1.10:9000 » : ce port-là (chiffré d'abord, puis en clair)."""
    saisie = saisie.strip().rstrip("/")
    if saisie.startswith(("http://", "https://")):
        return [saisie]
    hote, _, port = saisie.partition(":")
    if port.isdigit():
        return [f"https://{hote}:{port}", f"http://{hote}:{port}"]
    return [f"https://{hote}:{certificats.PORT_HTTPS}", f"http://{hote}:8000"]


def _contexte(c: dict | None) -> ssl.SSLContext | None:
    """Vérifie le serveur avec le certificat Gérimo reçu au jumelage ; au jumelage même, on ne peut pas encore."""
    if c and c.get("autorite"):
        ctx = ssl.create_default_context(cadata=c["autorite"])
        ctx.check_hostname = False  # l'adresse du principal peut changer ; c'est l'autorité qui compte
        return ctx
    ctx = ssl.create_default_context()
    ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    return ctx


def _requete(url: str, c: dict | None, donnees: dict | None = None, delai: float = 15):
    corps = json.dumps(donnees).encode() if donnees is not None else None
    req = urllib.request.Request(url, data=corps, method="POST" if corps else "GET",
                                 headers={"Content-Type": "application/json", "X-Gerimo-Port": str(PORT_HTTP),
                                          **({EN_TETE: c["jeton"]} if c and c.get("jeton") else {})})
    return urllib.request.urlopen(req, timeout=delai, context=_contexte(c) if url.startswith("https") else None)


def _message_erreur(e: Exception) -> str:
    if isinstance(e, urllib.error.HTTPError):
        try:
            return json.loads(e.read().decode()).get("detail", str(e))
        except ValueError:
            return str(e)
    return f"le PC principal ne répond pas ({getattr(e, 'reason', e)})"


def adresses_jumelage(saisie: str) -> list[str]:
    """Le jumelage ne passe qu'en https : « 192.168.1.10 » → https://…:8443 ; une adresse http://… devient
    https://…:8443 ; « 192.168.1.10:9000 » → ce port en https, puis 8443."""
    urls = []
    for url in adresses_possibles(saisie):
        u = urllib.parse.urlparse(url)
        if u.scheme == "http":
            url = f"https://{u.hostname}:{certificats.PORT_HTTPS}"
        if url not in urls:
            urls.append(url)
    return urls


def verifier_presentation(code: str, defi: str, rep: dict) -> str:
    """Renvoie le certificat Gérimo du PC principal si sa preuve est bonne ; sinon ValueError."""
    autorite = rep.get("autorite") or ""
    if not hmac.compare_digest(preuve(cle_de_preuve(code), defi, autorite), str(rep.get("preuve", ""))):
        raise ValueError("Ce serveur n'a pas pu prouver qu'il est le PC principal (code incorrect, ou autre appareil "
                         "qui se fait passer pour lui) : vérifiez l'adresse et le code.")
    if "BEGIN CERTIFICATE" not in autorite:
        raise ValueError("Le PC principal n'a pas encore de connexion sécurisée : redémarrez Gérimo Serveur sur le "
                         "PC principal, puis recommencez.")
    return autorite


def jumeler(adresse: str, code: str, nom_pc: str | None = None) -> dict:
    """Sur le PC de secours : vérifie le PC principal (preuve du code + certificat), puis échange le code contre
    la clé secrète, par une connexion https vérifiée avec ce certificat."""
    derniere_erreur = "adresse vide"
    for url in adresses_jumelage(adresse):
        defi = secrets.token_hex(16)
        try:
            with _requete(f"{url}/api/secours/presentation", None, {"defi": defi}) as r:
                presentation = json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            raise ValueError(_message_erreur(e))
        except (OSError, ValueError) as e:
            derniere_erreur = _message_erreur(e) if isinstance(e, OSError) else str(e)
            continue
        verifie = {"autorite": verifier_presentation(code, defi, presentation)}
        try:
            with _requete(f"{url}/api/secours/jumeler", verifie,
                          {"code": code, "nom_pc": nom_pc or socket.gethostname()}) as r:
                rep = json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            raise ValueError(_message_erreur(e))
        except OSError as e:
            raise ValueError(f"Jumelage interrompu : le serveur n'a pas présenté le bon certificat ({_message_erreur(e)}).")
        c = {**config(), "adresse": url, "jeton": rep["jeton"], "autorite": verifie["autorite"], "role": "secours",
             "entreprise": rep.get("entreprise", ""), "jumele_le": datetime.now().isoformat(timespec="seconds")}
        _enregistrer_config(c)
        recuperer_autorite()  # pour un éventuel relais
        return config()
    raise ValueError(f"Jumelage impossible : {derniere_erreur}.")


def _noter_etat(**valeurs) -> None:
    c = config()
    c.update(valeurs)
    _enregistrer_config(c)


def recuperer() -> dict:
    """Sur le PC de secours : télécharge la dernière sauvegarde du principal si on ne l'a pas encore.
    Renvoie {"etat": "nouvelle"|"a_jour"|"erreur"|"non_jumele", ...}."""
    c = config()
    if not c.get("jeton"):
        return {"etat": "non_jumele"}
    maintenant = datetime.now().isoformat(timespec="seconds")
    adresse = urllib.parse.urlparse(c.get("adresse", ""))
    if adresse.scheme == "http" and c.get("autorite"):
        # jumelé avant le « tout https » : même PC principal, connexion vérifiée avec son certificat
        _noter_etat(adresse=f"https://{adresse.hostname}:{certificats.PORT_HTTPS}")
        c = config()
        recuperer_autorite()
    try:
        with _requete(f"{c['adresse']}/api/secours/etat", c) as r:
            etat = json.loads(r.read().decode())
        derniere = etat.get("derniere")
        _noter_etat(version_principal=etat.get("version"), numero_principal=etat.get("numero"),
                    dernier_contact=maintenant)
        if not derniere:
            return {"etat": "a_jour", "message": "Le PC principal n'a encore aucune sauvegarde."}
        RECUES.mkdir(parents=True, exist_ok=True)
        cible = RECUES / Path(derniere["fichier"]).name
        if not sauvegarde.MOTIF_NOM.match(cible.name):
            raise ValueError("nom de sauvegarde inattendu")
        if cible.exists() and cible.stat().st_size == derniere["taille"]:
            return {"etat": "a_jour", "fichier": cible.name}
        provisoire = RECUES / (cible.name + ".en-cours")
        try:
            with _requete(f"{c['adresse']}/api/secours/sauvegarde/{urllib.parse.quote(cible.name)}", c, delai=120) as r, \
                    open(provisoire, "wb") as f:
                shutil.copyfileobj(r, f)
            if not sauvegarde.cle_connue(provisoire):
                recuperer_autorite()  # le principal a changé de clé (code de secours saisi) : on la reprend
            probleme = exiger_chiffree(provisoire) or sauvegarde.verifier_archive(provisoire)
            if probleme:
                raise ValueError(f"copie abîmée ({probleme})")
            provisoire.replace(cible)
        finally:
            provisoire.unlink(missing_ok=True)
        sauvegarde.trier(RECUES)
        _noter_etat(derniere_copie=maintenant, derniere_copie_fichier=cible.name, derniere_erreur="")
        return {"etat": "nouvelle", "fichier": cible.name}
    except (OSError, ValueError, KeyError) as e:
        message = _message_erreur(e) if isinstance(e, OSError) else str(e)
        _noter_etat(derniere_erreur=f"{maintenant} : {message}")
        return {"etat": "erreur", "message": message}


def exiger_chiffree(chemin: Path) -> str | None:
    """Entre les deux PC, seules passent les sauvegardes chiffrées avec la clé de l'entreprise : un faux serveur
    sur le réseau ne peut ni en fabriquer une, ni en modifier une."""
    if not coffre.est_chiffre(chemin):
        return "sauvegarde non chiffrée, refusée"
    if not sauvegarde.cle_connue(chemin):
        return "sauvegarde chiffrée avec une clé inconnue, refusée"
    return None


def derniere_recue() -> tuple[Path, datetime] | None:
    liste = sauvegarde.sauvegardes(RECUES)
    return (liste[-1][0], liste[-1][1]) if liste else None


# ====================== Rôle de ce PC, relais ======================

def role() -> str:
    """« principal » (par défaut), « secours » (en veille), « relais » ou « rendu »."""
    return config().get("role") or "principal"


def definir_role(nouveau: str, **valeurs) -> None:
    c = config()
    c.update(valeurs, role=nouveau)
    _enregistrer_config(c)


def _sonder(url: str, delai: float = 4) -> bool:
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
        with urllib.request.urlopen(url, timeout=delai, context=ctx if url.startswith("https") else None) as r:
            return r.status == 200
    except Exception:  # noqa: BLE001
        return False


def principal_repond(essais: int = 3, pause: float = 5) -> bool:
    """Le PC principal sert-il encore ? (plusieurs essais : une coupure d'une seconde n'est pas une panne)"""
    c = config()
    adresse = urllib.parse.urlparse(c.get("adresse", ""))
    if not adresse.hostname:
        return False
    urls = [f"{c['adresse']}/connexion"]
    if adresse.scheme == "https" and adresse.port in (None, certificats.PORT_HTTPS):
        urls.append(f"http://{adresse.hostname}:8000/connexion")  # même serveur, en clair (https coupé ?)
    for i in range(essais):
        if any(_sonder(u) for u in urls):
            return True
        if i < essais - 1:
            time.sleep(pause)
    return False


def recuperer_autorite() -> bool:
    """Après le jumelage : garde le certificat Gérimo de l'agence et sa clé (pour un éventuel relais)."""
    c = config()
    try:
        with _requete(f"{c['adresse']}/api/secours/autorite", c) as r:
            a = json.loads(r.read().decode())
    except (OSError, ValueError, KeyError):
        return False
    if a.get("cles"):
        coffre.adopter(a["cles"])
    if a.get("cert") and a.get("cle"):
        # write_bytes : à l'identique (write_text changerait les fins de ligne sous Windows)
        (DOSSIER_SECOURS / "autorite-gerimo.crt").write_bytes(a["cert"].encode("ascii"))
        (DOSSIER_SECOURS / "autorite-gerimo.key").write_bytes(a["cle"].encode("ascii"))
        return True
    return False


def version_a_rattraper() -> bool:
    """Le PC principal a-t-il une version plus récente que celle de ce PC de secours ?"""
    import version
    numero = config().get("numero_principal")
    return bool(numero) and numero > version.numero_de(version.infos_version())


def rattraper_version(cible: Path = ICI) -> bool:
    """Installe ici les fichiers du logiciel du PC principal (mêmes règles qu'une mise à jour en ligne).
    Il faut ensuite relancer le programme."""
    import maj_fichiers
    import version
    c = config()
    with _requete(f"{c['adresse']}/api/secours/paquet", c, delai=180) as r:
        contenu = r.read(maj_fichiers.TAILLE_MAX + 1)
    fichiers = maj_fichiers.lire_paquet(contenu)
    maj_fichiers.verifier_code(fichiers)
    maj_fichiers.appliquer(fichiers, cible, version.infos_version().get("version", "?"))
    return True


class RelaisImpossible(Exception):
    pass


def prendre_relais(sonder_principal: bool = True) -> dict:
    """Sur le PC de secours : restaure la dernière copie reçue et devient le serveur."""
    if role() != "secours":
        raise RelaisImpossible("Ce PC n'est pas en mode « PC de secours ».")
    derniere = derniere_recue()
    if derniere is None:
        raise RelaisImpossible("Aucune sauvegarde reçue du PC principal : impossible de prendre le relais.")
    if sonder_principal and principal_repond():
        raise RelaisImpossible("Le PC principal répond encore : deux serveurs en même temps créeraient deux versions "
                               "différentes des données. Arrêtez d'abord Gérimo sur le PC principal (ou débranchez-le).")
    archive, quand = derniere
    sauvegarde.restaurer(archive)
    # certificat Gérimo de l'agence : les appareils lui font déjà confiance ; celui du serveur sera refait pour ce PC
    cert, cle = DOSSIER_SECOURS / "autorite-gerimo.crt", DOSSIER_SECOURS / "autorite-gerimo.key"
    if cert.exists() and cle.exists():
        certificats.DOSSIER.mkdir(exist_ok=True)
        shutil.copyfile(cert, certificats.CA_CERT)
        shutil.copyfile(cle, certificats.CA_CLE)
        certificats.SRV_CERT.unlink(missing_ok=True)
    definir_role("relais", relais_depuis=datetime.now().isoformat(timespec="seconds"),
                 donnees_du=quand.isoformat(timespec="minutes"), fichier_rendu="")
    return {"donnees_du": quand}


# Service suspendu sur CE PC : principal qui attend que le secours rende la main
SUSPENSION = {"actif": False, "message": "", "lien": ""}


def service_suspendu() -> dict | None:
    """Ce PC ne doit pas servir en ce moment ? Renvoie le message à afficher (et un lien éventuel)."""
    if role() == "secours":  # PC de secours en veille : il ne sert jamais (ses données ne sont qu'une copie)
        adresse = config().get("adresse", "")
        return {"message": "Ce PC est le PC de secours (en veille) : Gérimo fonctionne sur le serveur principal.",
                "lien": adresse + "/app" if adresse else ""}
    if role() == "rendu":
        adresse = config().get("adresse", "")
        return {"message": "Gérimo revient sur le PC principal : patientez une minute, puis rechargez la page.",
                "lien": adresse + "/app" if adresse else ""}
    return SUSPENSION if SUSPENSION["actif"] else None


def rendre_la_main() -> str:
    """Sur le PC de secours en relais : se fige, fait la dernière sauvegarde que le principal viendra chercher."""
    if role() != "relais":
        raise RelaisImpossible("Ce PC ne tient pas le relais.")
    definir_role("rendu", fichier_rendu="")  # plus aucune saisie à partir d'ici (service suspendu)
    archive = sauvegarde.creer_sauvegarde("rendu")
    definir_role("rendu", fichier_rendu=archive.name, rendu_le=datetime.now().isoformat(timespec="seconds"))
    return archive.name


QUAND_REPRIS = None  # fonction appelée quand le principal a repris ses données (la fenêtre relance le programme)


def verifier_principal(cle: str | None) -> None:
    jeton = config().get("jeton", "")
    if not jeton or not cle or not hmac.compare_digest(_hacher(jeton), cle):
        raise HTTPException(status_code=403, detail="PC principal non reconnu.")


@router.get("/secours/relais")
def etat_relais():
    """Public : le PC principal demande si ce PC tient le relais (aucune donnée de l'agence ici)."""
    c = config()
    r = role()
    reponse = {"role": r}
    if r in ("relais", "rendu"):
        reponse.update(depuis=c.get("relais_depuis"), donnees_du=c.get("donnees_du"))
    if r == "rendu":
        reponse["fichier"] = c.get("fichier_rendu", "")
    return reponse


@router.get("/secours/rendu/{nom}")
def donner_rendu(nom: str, cle: str | None = Header(None, alias="X-Gerimo-Principal")):
    verifier_principal(cle)
    if role() != "rendu" or not nom or Path(nom).name != config().get("fichier_rendu"):
        raise HTTPException(status_code=404, detail="Pas de données à rendre.")
    return FileResponse(sauvegarde.DOSSIER / Path(nom).name, media_type="application/zip", filename=Path(nom).name)


@router.post("/secours/repris")
def principal_a_repris(cle: str | None = Header(None, alias="X-Gerimo-Principal")):
    verifier_principal(cle)
    if role() != "rendu":
        raise HTTPException(status_code=409, detail="Ce PC n'a rien rendu.")
    definir_role("secours", relais_depuis="", donnees_du="", fichier_rendu="",
                 repris_le=datetime.now().isoformat(timespec="seconds"))
    if QUAND_REPRIS:
        threading.Thread(target=QUAND_REPRIS, daemon=True).start()
    return {"ok": True}


# ====================== Côté PC principal : surveiller un éventuel relais ======================

def _url_secours() -> str:
    c = copies_emportees()
    return f"http://{c['adresse_secours']}:{c.get('port_secours') or 8000}" if c.get("adresse_secours") else ""


def _jeton_hache_principal() -> str:
    return _lire(None, "secours_jeton")


def verifier_relais() -> str:
    """PC principal : demande au PC de secours où il en est, et agit. Renvoie ce qui a été constaté."""
    url = _url_secours()
    cle = _jeton_hache_principal() if url else ""
    if not url or not cle:
        SUSPENSION["actif"] = False
        return "pas_de_secours"
    try:
        with urllib.request.urlopen(f"{url}/api/secours/relais", timeout=4) as r:
            etat = json.loads(r.read().decode())
    except Exception:  # noqa: BLE001 — PC de secours éteint, ou en veille (sans serveur)
        if copies_emportees().get("etat_secours") in ("relais", "rendu"):
            # il tenait le relais : une coupure du réseau ne doit pas faire repartir ce PC avec d'anciennes données
            SUSPENSION.update(actif=True, lien="", message="Le PC de secours tenait le relais et ne répond plus. "
                              "Rallumez-le (ou rebranchez-le au réseau). Si ses données sont perdues, l'Admin peut "
                              "reprendre quand même depuis la fenêtre Gérimo Serveur de ce PC.")
            return "injoignable_en_relais"
        SUSPENSION["actif"] = False
        return "injoignable"
    _ecrire_copies(etat_secours=etat.get("role"))
    if etat.get("role") == "relais":
        hote = urllib.parse.urlparse(url).hostname
        depuis = datetime.fromisoformat(etat["depuis"]).strftime("%d/%m/%Y à %H:%M") if etat.get("depuis") else ""
        SUSPENSION.update(actif=True, lien=f"https://{hote}:{certificats.PORT_HTTPS}/app",
                          message=f"Le PC de secours tient le relais depuis le {depuis} : travaillez sur le PC de "
                                  "secours. Pour revenir ici, cliquez sur « Rendre la main » dans la fenêtre Gérimo "
                                  "du PC de secours.")
        return "relais"
    if etat.get("role") == "rendu":
        SUSPENSION.update(actif=True, lien="", message="Récupération des données du PC de secours… patientez.")
        if not etat.get("fichier"):
            return "rendu_en_preparation"
        try:
            if copies_emportees().get("fichier_repris") == etat["fichier"]:
                _confirmer_reprise(url, cle)  # déjà restauré : il ne manquait que la confirmation (jamais deux fois)
            else:
                reprendre_donnees(url, etat["fichier"], cle)
        except Exception as e:  # noqa: BLE001 — on reste suspendu et on réessaie à la vérification suivante
            SUSPENSION["message"] = f"Récupération des données du PC de secours impossible ({e}) : nouvel essai " \
                                    "dans une minute."
            return "echec_reprise"
        _ecrire_copies(etat_secours="secours")
        SUSPENSION["actif"] = False
        return "repris"
    SUSPENSION["actif"] = False
    return etat.get("role", "?")


def reprendre_quand_meme() -> None:
    """Admin, sur le PC principal : le PC de secours est perdu ; ce PC reprend avec ses propres données."""
    _ecrire_copies(etat_secours="abandonne")
    SUSPENSION["actif"] = False


def reprendre_donnees(url: str, fichier: str, cle: str) -> None:
    """PC principal : télécharge la dernière sauvegarde du PC de secours, la restaure, et le prévient."""
    sauvegarde.DOSSIER.mkdir(exist_ok=True)
    cible = sauvegarde.DOSSIER / Path(fichier).name
    provisoire = cible.with_name(cible.name + ".en-cours")
    try:
        requete = urllib.request.Request(f"{url}/api/secours/rendu/{urllib.parse.quote(cible.name)}",
                                         headers={"X-Gerimo-Principal": cle})
        with urllib.request.urlopen(requete, timeout=300) as r, open(provisoire, "wb") as f:
            shutil.copyfileobj(r, f)
        probleme = exiger_chiffree(provisoire) or sauvegarde.verifier_archive(provisoire)
        if probleme:
            raise ValueError(f"copie abîmée ({probleme})")
        provisoire.replace(cible)
    finally:
        provisoire.unlink(missing_ok=True)
    sauvegarde.restaurer(cible)
    _ecrire_copies(fichier_repris=cible.name)
    _confirmer_reprise(url, cle)


def _confirmer_reprise(url: str, cle: str) -> None:
    requete = urllib.request.Request(f"{url}/api/secours/repris", data=b"", method="POST",
                                     headers={"X-Gerimo-Principal": cle})
    urllib.request.urlopen(requete, timeout=15).close()


def demarrer_surveillance() -> None:
    """Au démarrage du PC principal : vérifie tout de suite (avant de servir), puis chaque minute."""
    if role() != "principal" or os.getenv("GERIMO_SANS_SAUVEGARDE_AUTO"):
        return

    def verifier():
        try:
            verifier_relais()
        except Exception as e:  # noqa: BLE001 — ne jamais arrêter le serveur pour ça
            print(f"Vérification du PC de secours impossible : {e}")

    verifier()

    def boucle():
        while True:
            time.sleep(SURVEILLANCE)
            verifier()
    threading.Thread(target=boucle, daemon=True, name="secours").start()
