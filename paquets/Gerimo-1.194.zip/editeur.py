"""Signature de l'éditeur de Gérimo : mises à jour et licences (audit de sécurité du 12/10/2026, point 4).

L'éditeur (le PC de développement de Boss) possède une clé PRIVÉE, gardée hors de Git dans cle_editeur/ (à copier
aussi sur une clé USB rangée en lieu sûr : sans elle, plus de mise à jour ni de licence possible). Les serveurs
n'ont que la clé PUBLIQUE ci-dessous : ils peuvent vérifier une signature, jamais en fabriquer une.

- Mise à jour : signature.json accompagne chaque publication (empreinte SHA-256 de chaque fichier du logiciel +
  signature Ed25519). Un serveur n'installe une mise à jour que si tout correspond : un dépôt GitHub piraté, un faux
  serveur de mises à jour ou un paquet modifié en route sont refusés.
- Licence : texte signé par l'éditeur (licence.py).
Chaque usage signe un texte préfixé différent : une signature de mise à jour ne vaut jamais licence, et inversement.
"""
import base64
import hashlib
import json

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

# Clés publiques acceptées (la première est l'actuelle ; une ancienne peut rester le temps d'un changement de clé)
CLES_PUBLIQUES = ["bJ5ZlbkG2OFwHYqTGt2IhCvgSjT5XsbBKcqZxz35lsA="]

USAGE_MAJ = "gerimo/mise-a-jour/v1"
USAGE_LICENCE = "gerimo/licence/v1"
FICHIER_SIGNATURE = "signature.json"


class SignatureInvalide(ValueError):
    pass


def texte_a_signer(usage: str, contenu: dict) -> bytes:
    """Forme unique (clés triées, sans espaces) : la même signée par l'éditeur et vérifiée par le serveur."""
    return (usage + "\n" + json.dumps(contenu, ensure_ascii=False, sort_keys=True, separators=(",", ":"))).encode("utf-8")


def verifier(usage: str, contenu: dict, signature_b64: str, cles: list[str] | None = None) -> None:
    try:
        signature = base64.b64decode(signature_b64, validate=True)
    except (ValueError, TypeError):
        raise SignatureInvalide("signature illisible") from None
    message = texte_a_signer(usage, contenu)
    for cle in cles if cles is not None else CLES_PUBLIQUES:
        try:
            Ed25519PublicKey.from_public_bytes(base64.b64decode(cle)).verify(signature, message)
            return
        except (InvalidSignature, ValueError):
            continue
    raise SignatureInvalide("signature de l'éditeur invalide")


def empreinte(contenu: bytes) -> str:
    return hashlib.sha256(contenu).hexdigest()


def verifier_paquet(fichiers: dict[str, bytes], cles: list[str] | None = None) -> dict:
    """Mise à jour : signature valable ET chaque fichier identique à celui que l'éditeur a signé. Renvoie le contenu
    signé ({"version", "empreintes"}) ; lève SignatureInvalide sinon."""
    brut = fichiers.get(FICHIER_SIGNATURE)
    if not brut:
        raise SignatureInvalide("mise à jour non signée par l'éditeur de Gérimo")
    try:
        signe = json.loads(brut.decode("utf-8"))
        contenu = {"version": signe["version"], "empreintes": signe["empreintes"]}
    except (ValueError, KeyError, UnicodeDecodeError):
        raise SignatureInvalide("fichier de signature illisible") from None
    verifier(USAGE_MAJ, contenu, signe.get("signature", ""), cles)
    attendus = contenu["empreintes"]
    presents = {nom for nom in fichiers if nom != FICHIER_SIGNATURE}
    if presents != set(attendus):
        raise SignatureInvalide("fichiers différents de ceux signés par l'éditeur")
    for nom in presents:
        # (fins de ligne Windows ajoutées en route par un outil : même contenu)
        if attendus[nom] not in (empreinte(fichiers[nom]), empreinte(fichiers[nom].replace(b"\r\n", b"\n"))):
            raise SignatureInvalide(f"{nom} a été modifié depuis la signature de l'éditeur")
    try:
        publication = json.loads(fichiers["publication.json"].decode("utf-8"))
    except (KeyError, ValueError, UnicodeDecodeError):
        raise SignatureInvalide("publication.json absent ou illisible") from None
    if publication.get("version") != contenu["version"]:
        raise SignatureInvalide("numéro de version différent de celui signé")
    return contenu
