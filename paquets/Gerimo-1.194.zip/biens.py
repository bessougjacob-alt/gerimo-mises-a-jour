"""Étape 2 : propriétaires, biens (table cites), logements et parcelles.

Vocabulaire de l'interface : un « Bien » (cité, immeuble, lotissement…) regroupe
des logements et/ou des parcelles. En base, la table des biens s'appelle cites.

Règles d'accès (vérifiées ici, côté serveur) :
- Propriétaires : Admin uniquement.
- Biens : l'Admin les crée, modifie et supprime ; un Gestionnaire ne voit que les siens.
- Logements et parcelles : Admin et Gestionnaire (dans ses biens) ajoutent et modifient.
- Toute suppression : Admin uniquement, avec son mot de passe redemandé.
"""
import re
import unicodedata
from datetime import date
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session as SessionDB, selectinload

from commun import (Cni, Code, Email, Formulaire, Mots, NomBien, NomPersonne, Paragraphe, Suppression, Telephone, Texte,
                    charger, enregistrer, est_admin, montant, supprimer)
from models import (APPROBATIONS_PARCELLE, Cite, ContratGestion, GestionnaireMandataire,
                    Logement, Parcelle, PieceJointe, Proprietaire, RoleUtilisateur,
                    Utilisateur, STATUTS_EN_COURS, STATUTS_LOGEMENT, TYPES_BATIMENT,
                    TYPES_BATIMENT_LOGEMENT, TYPES_LOGEMENT_FICHE)
from securite import (cites_autorisees, confirmer_mot_de_passe_admin, exiger_admin,
                      exiger_module, get_db, verifier_cite_autorisee)

router = APIRouter(prefix="/api")

acces_biens = exiger_module("biens")
acces_proprietaires = exiger_module("proprietaires")


# ---------- Données reçues des formulaires ----------

class ProprietaireIn(Formulaire):
    nom_complet: NomPersonne = Field(min_length=1, max_length=150)
    cni: Cni | None = Field(None, max_length=50)
    telephone: Telephone | None = Field(None, max_length=30)
    ville: Mots | None = Field(None, max_length=80)
    email: Email | None = Field(None, max_length=150)


# % de commission ISUP, saisi par l'Admin pour chaque bien (0 % pour un bien d'ISUP)
Pourcentage = Field(ge=0, le=100, max_digits=5, decimal_places=2)


class CiteIn(Formulaire):
    nom: NomBien = Field(min_length=1, max_length=150)
    adresse: Texte | None = Field(None, max_length=200)
    proprietaire_id: int
    pourcentage_commission: Decimal = Pourcentage
    description: Paragraphe | None = Field(None, max_length=2000)
    gestionnaires_ids: list[int] = []


class NouvelleCite(Formulaire):
    nom: NomBien = Field(min_length=1, max_length=150)
    adresse: Texte | None = Field(None, max_length=200)
    proprietaire_id: int
    pourcentage_commission: Decimal = Pourcentage


class ChoixBien(Formulaire):
    """Bien existant (cite_id) ou « + Nouveau bien… » (nouvelle_cite, Admin)."""
    cite_id: int | None = None
    nouvelle_cite: NouvelleCite | None = None


class LogementIn(ChoixBien):
    type_batiment: Literal[TYPES_BATIMENT_LOGEMENT]
    numero_logement: Code = Field(min_length=1, max_length=30)
    type_logement: Literal[TYPES_LOGEMENT_FICHE]
    loyer: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    statut_logement: Literal[STATUTS_LOGEMENT] = "Libre"


class ParcelleIn(ChoixBien):
    numero_parcelle: Code = Field(min_length=1, max_length=30)
    superficie: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    situation_geographique: Texte | None = Field(None, max_length=200)
    documents: Paragraphe | None = Field(None, max_length=1000)
    prix_entree: Decimal | None = Field(None, ge=0, max_digits=14, decimal_places=2)
    dernier_prix: Decimal | None = Field(None, ge=0, max_digits=14, decimal_places=2)
    approbation: Literal[APPROBATIONS_PARCELLE] = "En attente"
    disponible: bool = True


# ---------- Mise en forme des réponses ----------

def logement_json(l: Logement) -> dict:
    return {
        "id": l.id, "cite_id": l.cite_id, "numero_logement": l.numero_logement,
        "type_batiment": l.type_batiment, "type_logement": l.type_logement,
        "loyer": montant(l.loyer), "statut_logement": l.statut_logement,
    }


def parcelle_json(p: Parcelle) -> dict:
    return {
        "id": p.id, "cite_id": p.cite_id, "numero_parcelle": p.numero_parcelle,
        "superficie": montant(p.superficie), "situation_geographique": p.situation_geographique,
        "documents": p.documents,
        "prix_entree": montant(p.prix_entree) if p.prix_entree is not None else None,
        "dernier_prix": montant(p.dernier_prix) if p.dernier_prix is not None else None,
        "approbation": p.approbation, "disponible": p.disponible,
    }


def cite_json(c: Cite, est_admin: bool) -> dict:
    donnees = {
        "id": c.id, "nom": c.nom, "adresse": c.adresse, "description": c.description,
        "logements": [logement_json(l) for l in c.logements],
        "parcelles": [parcelle_json(p) for p in c.parcelles],
    }
    if est_admin:  # le Gestionnaire n'a accès ni aux propriétaires ni aux commissions
        donnees["proprietaire"] = (
            {"id": c.proprietaire.id, "nom_complet": c.proprietaire.nom_complet} if c.proprietaire else None
        )
        mandat = c.mandat_actuel
        donnees["pourcentage_commission"] = montant(mandat.pourcentage_commission) if mandat else None
        donnees["gestionnaires"] = [{"id": u.id, "nom_complet": u.nom_complet} for u in c.gestionnaires]
    return donnees


# ---------- Contrôles communs ----------

def gestionnaires_valides(db: SessionDB, ids: list[int]) -> list[Utilisateur]:
    if not ids:
        return []
    comptes = db.query(Utilisateur).filter(
        Utilisateur.id.in_(set(ids)), Utilisateur.role == RoleUtilisateur.Gestionnaire
    ).all()
    if len(comptes) != len(set(ids)):
        raise HTTPException(status_code=400, detail="Un des gestionnaires choisis n'existe pas.")
    return comptes


def entreprise_mandataire(db: SessionDB) -> GestionnaireMandataire:
    """L'entreprise mandataire (« Mon entreprise ») : créée au premier mandat si besoin, sous un nom neutre
    (l'identité affichée sur les documents est toujours celle de « Mon entreprise »)."""
    mandataire = db.query(GestionnaireMandataire).order_by(GestionnaireMandataire.id).first()
    if mandataire is None:
        mandataire = GestionnaireMandataire(nom="Mon entreprise")
        db.add(mandataire)
        db.flush()
    return mandataire


def definir_commission(db: SessionDB, cite: Cite, pourcentage: Decimal) -> None:
    """Nouveau mandat daté si le % ou le propriétaire change ; l'ancien reste en historique."""
    actuel = cite.mandat_actuel
    if (actuel is not None and actuel.pourcentage_commission == pourcentage
            and actuel.proprietaire_id == cite.proprietaire_id):
        return
    mandat = ContratGestion(gestionnaire_id=entreprise_mandataire(db).id, proprietaire_id=cite.proprietaire_id,
                            pourcentage_commission=pourcentage, date_debut=date.today())
    cite.mandats.insert(0, mandat)  # devient le mandat actuel


def resoudre_bien(db: SessionDB, utilisateur: Utilisateur, donnees: ChoixBien) -> Cite:
    """Renvoie le bien choisi, ou crée le nouveau bien (Admin uniquement)."""
    if donnees.nouvelle_cite is not None:
        if not est_admin(utilisateur):
            raise HTTPException(status_code=403, detail="Seul l'Admin peut créer un bien.")
        charger(db, Proprietaire, donnees.nouvelle_cite.proprietaire_id, "Propriétaire introuvable.")
        cite = Cite(nom=donnees.nouvelle_cite.nom, adresse=donnees.nouvelle_cite.adresse or None,
                    proprietaire_id=donnees.nouvelle_cite.proprietaire_id)
        definir_commission(db, cite, donnees.nouvelle_cite.pourcentage_commission)
        db.add(cite)
        db.flush()  # pour obtenir l'id du nouveau bien
        return cite
    if donnees.cite_id is not None:
        verifier_cite_autorisee(utilisateur, donnees.cite_id)
        return charger(db, Cite, donnees.cite_id, "Bien introuvable.")
    raise HTTPException(status_code=400, detail="Choisissez un bien.")


# ---------- Listes déroulantes ----------

@router.get("/biens/options")
def options(utilisateur: Utilisateur = Depends(acces_biens), db: SessionDB = Depends(get_db)):
    autorisees = cites_autorisees(utilisateur)
    requete = db.query(Cite).order_by(Cite.nom)
    if autorisees is not None:
        requete = requete.filter(Cite.id.in_(autorisees))
    donnees = {
        "types_batiment": TYPES_BATIMENT,
        "types_logement": TYPES_LOGEMENT_FICHE,
        "statuts_logement": STATUTS_LOGEMENT,
        "approbations": APPROBATIONS_PARCELLE,
        "cites": [{"id": c.id, "nom": c.nom} for c in requete],
        "peut_creer_cite": est_admin(utilisateur),
    }
    if est_admin(utilisateur):
        proprietaires = db.query(Proprietaire).order_by(Proprietaire.nom_complet).all()
        libelles = libelles_proprietaires(proprietaires)  # homonymes : nom suivi du téléphone
        donnees["proprietaires"] = [{"id": p.id, "nom_complet": libelles[p.id]} for p in proprietaires]
        donnees["gestionnaires"] = [
            {"id": u.id, "nom_complet": u.nom_complet}
            for u in db.query(Utilisateur).filter_by(role=RoleUtilisateur.Gestionnaire, actif=True)
                       .order_by(Utilisateur.nom_complet)
        ]
    return donnees


# ---------- Biens ----------

@router.get("/biens")
def liste_biens(utilisateur: Utilisateur = Depends(acces_biens), db: SessionDB = Depends(get_db)):
    requete = db.query(Cite).options(
        selectinload(Cite.logements), selectinload(Cite.parcelles), selectinload(Cite.mandats),
        selectinload(Cite.proprietaire), selectinload(Cite.gestionnaires)
    ).order_by(Cite.nom)
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None:
        requete = requete.filter(Cite.id.in_(autorisees))
    return [cite_json(c, est_admin(utilisateur)) for c in requete]


def appliquer_cite(db: SessionDB, cite: Cite, donnees: CiteIn) -> None:
    charger(db, Proprietaire, donnees.proprietaire_id, "Propriétaire introuvable.")
    cite.nom = donnees.nom
    cite.adresse = donnees.adresse or None
    cite.proprietaire_id = donnees.proprietaire_id
    cite.description = donnees.description or None
    cite.gestionnaires = gestionnaires_valides(db, donnees.gestionnaires_ids)
    definir_commission(db, cite, donnees.pourcentage_commission)


@router.post("/cites")
def creer_cite(donnees: CiteIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    cite = Cite()
    appliquer_cite(db, cite, donnees)
    db.add(cite)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": cite.id}


@router.put("/cites/{cite_id}")
def modifier_cite(cite_id: int, donnees: CiteIn, admin: Utilisateur = Depends(exiger_admin),
                  db: SessionDB = Depends(get_db)):
    cite = charger(db, Cite, cite_id, "Bien introuvable.")
    appliquer_cite(db, cite, donnees)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": cite.id}


@router.post("/cites/{cite_id}/supprimer")
def supprimer_cite(cite_id: int, donnees: Suppression, admin: Utilisateur = Depends(exiger_admin),
                   db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    cite = charger(db, Cite, cite_id, "Bien introuvable.")
    if cite.logements or cite.parcelles:
        raise HTTPException(status_code=409,
                            detail="Ce bien contient encore des logements ou des parcelles : supprimez-les d'abord.")
    cite.gestionnaires = []
    for mandat in list(cite.mandats):  # bien vide : aucun encaissement n'en dépend
        db.delete(mandat)
    return supprimer(db, cite, "Ce bien est encore utilisé (dépenses, mandats…) : suppression impossible.")


# ---------- Logements ----------

def appliquer_logement(db: SessionDB, utilisateur: Utilisateur, logement: Logement, donnees: LogementIn) -> None:
    cite = resoudre_bien(db, utilisateur, donnees)
    logement.cite_id = cite.id
    logement.type_batiment = donnees.type_batiment
    logement.numero_logement = donnees.numero_logement
    logement.type_logement = donnees.type_logement
    logement.loyer = donnees.loyer
    logement.statut_logement = donnees.statut_logement


DOUBLON_LOGEMENT = "Ce numéro de logement existe déjà dans ce bien."


@router.post("/logements")
def creer_logement(donnees: LogementIn, utilisateur: Utilisateur = Depends(acces_biens),
                   db: SessionDB = Depends(get_db)):
    logement = Logement()
    appliquer_logement(db, utilisateur, logement, donnees)
    db.add(logement)
    enregistrer(db, DOUBLON_LOGEMENT)
    return {"id": logement.id}


@router.put("/logements/{logement_id}")
def modifier_logement(logement_id: int, donnees: LogementIn, utilisateur: Utilisateur = Depends(acces_biens),
                      db: SessionDB = Depends(get_db)):
    logement = charger(db, Logement, logement_id, "Logement introuvable.")
    verifier_cite_autorisee(utilisateur, logement.cite_id)
    appliquer_logement(db, utilisateur, logement, donnees)
    # avec un contrat en cours, le statut est imposé par le contrat
    synchroniser_statut_logement(logement, liberer=False)
    enregistrer(db, DOUBLON_LOGEMENT)
    return {"id": logement.id}


def synchroniser_statut_logement(logement: Logement, liberer: bool = True, sans=None) -> None:
    """Le statut du logement suit ses contrats : Occupé, Réservé (en attente) ou Libre.

    liberer=False : sans contrat en cours, on garde le statut choisi à la main.
    sans : contrat à ignorer (celui qu'on est en train de supprimer).
    """
    statuts = {c.statut_contrat for c in logement.contrats
               if c is not sans and c.statut_contrat in STATUTS_EN_COURS}
    if statuts - {"En attente"}:
        logement.statut_logement = "Occupé"
    elif statuts:
        logement.statut_logement = "Réservé"
    elif liberer and logement.statut_logement in ("Occupé", "Réservé"):
        logement.statut_logement = "Libre"


@router.post("/logements/{logement_id}/supprimer")
def supprimer_logement(logement_id: int, donnees: Suppression, admin: Utilisateur = Depends(exiger_admin),
                       db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    logement = charger(db, Logement, logement_id, "Logement introuvable.")
    if logement.contrats:
        raise HTTPException(status_code=409,
                            detail="Ce logement a des contrats de bail : suppression impossible.")
    return supprimer(db, logement, "Ce logement est encore utilisé (impayés…) : suppression impossible.")


# ---------- Parcelles ----------

def appliquer_parcelle(db: SessionDB, utilisateur: Utilisateur, parcelle: Parcelle, donnees: ParcelleIn) -> None:
    cite = resoudre_bien(db, utilisateur, donnees)
    parcelle.cite_id = cite.id
    parcelle.numero_parcelle = donnees.numero_parcelle
    parcelle.superficie = donnees.superficie
    parcelle.situation_geographique = donnees.situation_geographique or None
    parcelle.documents = donnees.documents or None
    parcelle.prix_entree = donnees.prix_entree
    parcelle.dernier_prix = donnees.dernier_prix
    parcelle.approbation = donnees.approbation
    parcelle.disponible = donnees.disponible


DOUBLON_PARCELLE = "Ce numéro de parcelle existe déjà dans ce bien."


@router.post("/parcelles")
def creer_parcelle(donnees: ParcelleIn, utilisateur: Utilisateur = Depends(acces_biens),
                   db: SessionDB = Depends(get_db)):
    parcelle = Parcelle()
    appliquer_parcelle(db, utilisateur, parcelle, donnees)
    db.add(parcelle)
    enregistrer(db, DOUBLON_PARCELLE)
    return {"id": parcelle.id}


@router.put("/parcelles/{parcelle_id}")
def modifier_parcelle(parcelle_id: int, donnees: ParcelleIn, utilisateur: Utilisateur = Depends(acces_biens),
                      db: SessionDB = Depends(get_db)):
    parcelle = charger(db, Parcelle, parcelle_id, "Parcelle introuvable.")
    verifier_cite_autorisee(utilisateur, parcelle.cite_id)
    appliquer_parcelle(db, utilisateur, parcelle, donnees)
    enregistrer(db, DOUBLON_PARCELLE)
    return {"id": parcelle.id}


@router.post("/parcelles/{parcelle_id}/supprimer")
def supprimer_parcelle(parcelle_id: int, donnees: Suppression, admin: Utilisateur = Depends(exiger_admin),
                       db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    parcelle = charger(db, Parcelle, parcelle_id, "Parcelle introuvable.")
    return supprimer(db, parcelle, "Cette parcelle est encore utilisée : suppression impossible.")


# ---------- Propriétaires (Admin uniquement) ----------

@router.get("/proprietaires")
def liste_proprietaires(admin: Utilisateur = Depends(acces_proprietaires), db: SessionDB = Depends(get_db)):
    proprietaires = db.query(Proprietaire).options(
        selectinload(Proprietaire.cites).selectinload(Cite.logements),
        selectinload(Proprietaire.cites).selectinload(Cite.parcelles),
    ).order_by(Proprietaire.nom_complet)
    nb_pieces = dict(db.query(PieceJointe.proprietaire_id, func.count(PieceJointe.id))
                     .filter(PieceJointe.proprietaire_id.isnot(None)).group_by(PieceJointe.proprietaire_id).all())
    return [{
        "id": p.id, "nom_complet": p.nom_complet, "cni": p.cni, "telephone": p.telephone, "ville": p.ville,
        "email": p.email, "nb_pieces": nb_pieces.get(p.id, 0),
        "cites": [{"id": c.id, "nom": c.nom, "adresse": c.adresse, "nb_logements": len(c.logements),
                   "nb_parcelles": len(c.parcelles)} for c in p.cites],
    } for p in proprietaires]


# ---------- Homonymes : deux propriétaires peuvent porter le même nom (demande de Boss du 11/11/2026) ----------

def cle_nom(nom) -> str:
    """« Adéyémi  Babatoundé » → « adeyemi babatounde » : comparer deux noms sans accents, majuscules ni ponctuation."""
    t = unicodedata.normalize("NFD", str(nom or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", t).strip()


def homonymes(db: SessionDB, nom: str, sauf: int | None = None) -> list[Proprietaire]:
    cle = cle_nom(nom)
    return [p for p in db.query(Proprietaire).options(selectinload(Proprietaire.cites))
            if cle_nom(p.nom_complet) == cle and p.id != sauf]


def distinction(p: Proprietaire) -> str:
    """Ce qui distingue deux homonymes : téléphone, sinon CNI, sinon ville, sinon le numéro de la fiche."""
    if p.telephone:
        return f"tél. {p.telephone}"
    if p.cni:
        return f"CNI {p.cni}"
    return p.ville or f"fiche n° {p.id}"


def libelles_proprietaires(proprietaires) -> dict[int, str]:
    """Nom affiché dans les listes : le nom seul, complété (téléphone…) quand un autre porte le même."""
    proprietaires = list(proprietaires)
    nb = {}
    for p in proprietaires:
        nb[cle_nom(p.nom_complet)] = nb.get(cle_nom(p.nom_complet), 0) + 1
    return {p.id: p.nom_complet + (f" — {distinction(p)}" if nb[cle_nom(p.nom_complet)] > 1 else "")
            for p in proprietaires}


def verifier_homonymes(db: SessionDB, p: Proprietaire) -> None:
    """Refuse une fiche impossible à distinguer d'un propriétaire existant du même nom (contrôle serveur ; l'écran
    prévient avant)."""
    autres = homonymes(db, p.nom_complet, sauf=p.id)
    if not autres:
        return
    liste = " ; ".join(f"{a.nom_complet} ({distinction(a)}, {len(a.cites)} bien{'s' if len(a.cites) > 1 else ''})"
                       for a in autres)
    chiffres = lambda t: re.sub(r"\D", "", t or "")[-10:]  # noqa: E731 — « +225 07… » = « 07… »
    if p.telephone and any(chiffres(a.telephone) == chiffres(p.telephone) for a in autres):
        raise HTTPException(status_code=409, detail=f"Un propriétaire du même nom et du même téléphone existe déjà "
                            f"({liste}) : c'est la même personne. Choisissez sa fiche au lieu d'en créer une autre.")
    if not (p.telephone or p.cni):
        raise HTTPException(status_code=409, detail=f"Un propriétaire du même nom existe déjà ({liste}). Si c'est une "
                            "autre personne, indiquez son téléphone ou sa CNI pour les distinguer ; si c'est la même, "
                            "utilisez sa fiche existante.")


@router.get("/proprietaires/homonymes")
def chercher_homonymes(nom: str, sauf: int | None = None, admin: Utilisateur = Depends(acces_proprietaires),
                       db: SessionDB = Depends(get_db)):
    return [{"id": p.id, "nom_complet": p.nom_complet, "distinction": distinction(p),
             "biens": [c.nom for c in p.cites]} for p in homonymes(db, nom, sauf)]


class FusionIn(BaseModel):
    vers_id: int
    mot_de_passe_admin: str


@router.post("/proprietaires/{proprietaire_id}/fusionner")
def fusionner_proprietaires(proprietaire_id: int, donnees: FusionIn, admin: Utilisateur = Depends(exiger_admin),
                            db: SessionDB = Depends(get_db)):
    """Fiche créée deux fois pour la même personne : tout ce qui est rattaché à la fiche « proprietaire_id » (biens,
    mandats, RIB, reversements, pièces jointes) passe sur la fiche « vers_id », puis la fiche vide est supprimée."""
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    source = charger(db, Proprietaire, proprietaire_id, "Propriétaire introuvable.")
    cible = charger(db, Proprietaire, donnees.vers_id, "Propriétaire introuvable.")
    if source.id == cible.id:
        raise HTTPException(status_code=400, detail="Choisissez une autre fiche que celle-ci.")
    from models import Beneficiaire, Reversement
    deplaces = {}
    for modele in (Cite, ContratGestion, Beneficiaire, Reversement, PieceJointe):
        lignes = db.query(modele).filter(modele.proprietaire_id == source.id).all()
        for ligne in lignes:  # une par une (et non en masse) : chaque changement est inscrit au journal
            ligne.proprietaire_id = cible.id
        deplaces[modele.__tablename__] = len(lignes)
    for champ in ("telephone", "cni", "ville", "email"):  # la fiche gardée récupère ce qui lui manquait
        if not getattr(cible, champ) and getattr(source, champ):
            setattr(cible, champ, getattr(source, champ))
    db.flush()
    db.expire(source)
    db.delete(source)
    enregistrer(db, "Fusion impossible.")
    return {"ok": True, "biens": deplaces["cites"], "vers": cible.nom_complet}


def appliquer_proprietaire(p: Proprietaire, donnees: ProprietaireIn) -> None:
    p.nom_complet = donnees.nom_complet
    p.cni = donnees.cni or None
    p.telephone = donnees.telephone or None
    p.ville = donnees.ville or None
    p.email = donnees.email or None


@router.post("/proprietaires")
def creer_proprietaire(donnees: ProprietaireIn, admin: Utilisateur = Depends(acces_proprietaires),
                       db: SessionDB = Depends(get_db)):
    p = Proprietaire()
    appliquer_proprietaire(p, donnees)
    verifier_homonymes(db, p)
    db.add(p)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": p.id}


@router.put("/proprietaires/{proprietaire_id}")
def modifier_proprietaire(proprietaire_id: int, donnees: ProprietaireIn,
                          admin: Utilisateur = Depends(acces_proprietaires), db: SessionDB = Depends(get_db)):
    p = charger(db, Proprietaire, proprietaire_id, "Propriétaire introuvable.")
    if cle_nom(p.nom_complet) != cle_nom(donnees.nom_complet):  # sans changement de nom, déjà acceptée avant
        # contrôle sur une copie, avant de toucher à la fiche
        verifier_homonymes(db, Proprietaire(id=p.id, nom_complet=donnees.nom_complet,
                                            telephone=donnees.telephone or None, cni=donnees.cni or None))
    appliquer_proprietaire(p, donnees)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": p.id}


@router.post("/proprietaires/{proprietaire_id}/supprimer")
def supprimer_proprietaire(proprietaire_id: int, donnees: Suppression, admin: Utilisateur = Depends(exiger_admin),
                           db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    p = charger(db, Proprietaire, proprietaire_id, "Propriétaire introuvable.")
    if p.cites:
        raise HTTPException(status_code=409,
                            detail="Ce propriétaire a encore des biens : supprimez-les ou changez leur propriétaire d'abord.")
    return supprimer(db, p, "Ce propriétaire est encore utilisé (mandats de gestion…) : suppression impossible.")
