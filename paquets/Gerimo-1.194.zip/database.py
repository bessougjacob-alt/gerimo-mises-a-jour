from sqlalchemy import create_engine, event
from sqlalchemy.engine import URL
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv
import os

load_dotenv()

# URL.create : le mot de passe peut contenir @ : / # sans casser l'adresse de connexion
DATABASE_URL = URL.create(
    "postgresql+psycopg2",
    username=os.getenv("DB_USER"),
    password=os.getenv("DB_PASSWORD"),
    host=os.getenv("DB_HOST"),
    port=int(os.getenv("DB_PORT") or 5432),
    database=os.getenv("DB_NAME"),
)

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)


@event.listens_for(engine, "do_connect")
def _identifiants_du_moment(dialect, conn_rec, cargs, cparams):
    """Identifiants relus à chaque nouvelle connexion. Au tout premier lancement, ce module est chargé AVANT que
    l'assistant écrive le .env, puis le .env passe au compte limité : sans cela, le moteur gardait les identifiants
    (vides) du chargement → « fe_sendauth: no password supplied » chez un client le 09/11/2026."""
    for cle, variable in (("user", "DB_USER"), ("password", "DB_PASSWORD"), ("host", "DB_HOST"), ("dbname", "DB_NAME")):
        if os.getenv(variable):
            cparams[cle] = os.getenv(variable)
    if os.getenv("DB_PORT"):
        cparams["port"] = int(os.getenv("DB_PORT"))
