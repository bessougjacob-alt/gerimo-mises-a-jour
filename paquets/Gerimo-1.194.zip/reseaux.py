"""Réseaux sociaux : annonces pour le groupe Facebook « IMMOBILIER INDENIE-DJUABLIN », la page ISUP,
WhatsApp, et invitation des locataires à rejoindre le groupe.

Important : depuis avril 2024, Facebook ne permet plus aux logiciels de publier automatiquement dans
un groupe (fermeture de l'« API Groupes » par Meta). Le logiciel prépare donc l'annonce (texte soigné
+ photos), la copie, et ouvre le groupe : il ne reste qu'à coller et cliquer « Publier ».
Chaque publication est notée dans l'historique.
"""
from typing import Literal

from fastapi import APIRouter, Depends
from pydantic import Field
from sqlalchemy.orm import Session as SessionDB, selectinload

import parametres
import recus
from commun import Formulaire, Paragraphe, Texte
from models import Cite, Contrat, Logement, Publication, Utilisateur, STATUTS_EN_COURS
from securite import cites_autorisees, exiger_module, get_db

router = APIRouter(prefix="/api")
acces_reseaux = exiger_module("reseaux_sociaux")

CANAUX = ("Groupe Facebook", "Page Facebook", "Statut WhatsApp", "Groupe WhatsApp", "Autre")


class AnnonceIn(Formulaire):
    logement_ids: list[int] = Field(min_length=1, max_length=10)


class PublicationIn(Formulaire):
    titre: Texte = Field(min_length=1, max_length=200)
    texte: Paragraphe = Field(min_length=1, max_length=5000)
    canal: Literal[CANAUX]


def logements_libres(db: SessionDB, u: Utilisateur):
    requete = db.query(Logement).join(Cite).options(selectinload(Logement.cite)).filter(
        Logement.statut_logement == "Libre")
    autorisees = cites_autorisees(u)
    if autorisees is not None:
        requete = requete.filter(Logement.cite_id.in_(autorisees))
    return requete.order_by(Cite.nom, Logement.numero_logement).all()


@router.get("/reseaux")
def accueil(u: Utilisateur = Depends(acces_reseaux), db: SessionDB = Depends(get_db)):
    valeurs = parametres.tous(db)
    # locataires en cours (pour l'invitation au groupe)
    requete = db.query(Contrat).join(Logement).options(selectinload(Contrat.locataire)).filter(
        Contrat.statut_contrat.in_(STATUTS_EN_COURS))
    autorisees = cites_autorisees(u)
    if autorisees is not None:
        requete = requete.filter(Logement.cite_id.in_(autorisees))
    locataires = {c.locataire.id: c.locataire for c in requete}
    return {
        "comptes": {cle: valeurs[cle] for cle in parametres.PUBLICS},
        "canaux": CANAUX,
        "logements_libres": [{"id": l.id, "logement": f"Logement {l.numero_logement}, {l.cite.nom}",
                              "type_logement": l.type_logement, "loyer": float(l.loyer), "adresse": l.cite.adresse or ""}
                             for l in logements_libres(db, u)],
        "locataires": sorted(({"id": l.id, "nom_complet": l.nom_complet, "telephone": l.telephone or ""}
                              for l in locataires.values()), key=lambda x: x["nom_complet"]),
        "publications": [{"id": p.id, "titre": p.titre, "canal": p.canal, "texte": p.texte,
                          "date": p.cree_le.strftime("%d/%m/%Y %H:%M"), "auteur": p.auteur.nom_complet if p.auteur else ""}
                         for p in db.query(Publication).order_by(Publication.cree_le.desc()).limit(30)],
    }


@router.post("/reseaux/annonce")
def rediger_annonce(d: AnnonceIn, u: Utilisateur = Depends(acces_reseaux), db: SessionDB = Depends(get_db)):
    """Texte d'annonce prêt à publier, à partir des logements libres choisis."""
    autorises = {l.id: l for l in logements_libres(db, u)}
    choisis = [autorises[i] for i in d.logement_ids if i in autorises]
    if not choisis:
        return {"titre": "", "texte": ""}
    v = parametres.tous(db)
    blocs = []
    for l in choisis:
        lieu = l.cite.nom + (f" — {l.cite.adresse}" if l.cite.adresse else "")
        usage = "à usage commercial" if l.type_logement == "Magasin" else "à usage d'habitation"
        blocs.append(f"🏠 {l.type_logement.upper()} À LOUER — {lieu}\n"
                     f"• {l.type_logement} {usage} ({l.type_batiment})\n"
                     f"• Loyer : {recus.francs(l.loyer)} / mois\n"
                     f"• Disponible immédiatement")
    titre = (f"{choisis[0].type_logement} à louer — {choisis[0].cite.nom}" if len(choisis) == 1
             else f"{len(choisis)} logements à louer à {recus.ENTETE['ville']}")
    texte = (f"📢 {recus.ENTETE['nom']} — {recus.ENTETE['activite']}\n\n" + "\n\n".join(blocs) + "\n\n"
             "✅ Visites sur rendez-vous\n"
             f"📞 Appel / WhatsApp : {v['whatsapp_numero'] or recus.ENTETE['telephones']}\n"
             f"📍 {recus.ENTETE['adresse']}\n\n"
             f"#{recus.ENTETE['ville'].replace(' ', '')} #Immobilier #ALouer")
    return {"titre": titre, "texte": texte}


@router.post("/reseaux/publications")
def noter_publication(d: PublicationIn, u: Utilisateur = Depends(acces_reseaux), db: SessionDB = Depends(get_db)):
    p = Publication(titre=d.titre, texte=d.texte, canal=d.canal, cree_par=u.id)
    db.add(p)
    db.commit()
    return {"id": p.id}
