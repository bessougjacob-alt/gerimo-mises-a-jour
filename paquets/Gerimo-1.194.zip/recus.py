"""Mise en page des documents PDF (étape 5) : reçu de paiement et quittance de loyer.

Une page A4 = deux exemplaires identiques séparés par une ligne de découpe :
« ORIGINAL — Locataire » en haut, « DUPLICATA — ISUP » en bas (souche).
Le reçu affiche caution, avance et reste à payer ; la quittance, JAMAIS.
"""
import re
from decimal import Decimal
from pathlib import Path

from fpdf import FPDF
from num2words import num2words

DOSSIER = Path(__file__).parent
POLICES = DOSSIER / "static" / "fonts"
LOGO = DOSSIER / "static" / "img" / "icone-512.png"  # Gérimo, puis le logo de « Mon entreprise »
LOGO_GERIMO = LOGO


def logo_document():
    """Logo imprimé sur les documents : celui de « Mon entreprise » seulement (jamais le logo de Gérimo,
    demande de Boss du 21/10/2026). Sans logo envoyé : None, et l'en-tête commence au bord gauche."""
    return LOGO if LOGO != LOGO_GERIMO and LOGO.exists() else None

# Couleurs du logo (CLAUDE.md)
ORANGE = (193, 85, 45)
VERT = (120, 179, 72)
MARINE = (29, 59, 83)
ENCRE = (28, 38, 32)
GRIS = (92, 101, 94)
FOND_VERT = (238, 245, 232)

# En-tête de tous les documents : valeurs de « Mon entreprise » (Paramètres), recopiées ici au démarrage et à chaque
# enregistrement par entreprise.appliquer() (vides tant que « Mon entreprise » n'est pas renseignée).
ENTETE = {
    "nom": "",
    "activite": "",
    "adresse": "",
    "contact": "",
    "rccm": "",
    "ville": "", "telephones": "", "telephones_gerant": "", "email": "",
    "ncc": "",
}


def d_entreprise() -> str:
    """« d'ISUP SARL », « de Agence Horizon » : « de » élidé devant une voyelle ou un h."""
    nom = ENTETE["nom"]
    return ("d'" if nom[:1].upper() in "AEIOUYÉÈÊÂÎÔH" else "de ") + nom


def francs(valeur) -> str:
    """75000 → « 75 000 F CFA » (espaces insécables : le nombre ne se coupe pas)."""
    return f"{Decimal(valeur):,.0f}".replace(",", " ") + " F CFA"


def en_lettres(valeur) -> str:
    """75000 → « Soixante-quinze mille francs CFA »."""
    texte = num2words(int(Decimal(valeur)), lang="fr")
    return texte[0].upper() + texte[1:] + " francs CFA"


class PDF(FPDF):
    def __init__(self):
        super().__init__(format="A4")
        self.set_auto_page_break(False)
        self.set_margins(12, 10, 12)
        self.add_font("Montserrat", "", str(POLICES / "Montserrat-Medium.ttf"))
        self.add_font("Montserrat", "B", str(POLICES / "Montserrat-Bold.ttf"))
        self.add_font("MontserratSemi", "", str(POLICES / "Montserrat-SemiBold.ttf"))
        self.set_author(f"{ENTETE['nom']}")

    def texte(self, x, y, contenu, taille=9, couleur=ENCRE, style="", police="Montserrat", largeur=0, align="L"):
        self.set_font(police, style, taille)
        self.set_text_color(*couleur)
        self.set_xy(x, y)
        self.cell(largeur, taille * 0.45, contenu, align=align)


def _ligne(pdf: PDF, y: float, libelle: str, valeur: str, largeur_valeur: float = 140) -> float:
    """Une ligne « libellé : valeur » ; renvoie la position y suivante."""
    pdf.texte(16, y, libelle, taille=8.5, couleur=GRIS)
    pdf.set_font("MontserratSemi", "", 9.5)
    pdf.set_text_color(*ENCRE)
    pdf.set_xy(54, y - 0.4)
    pdf.multi_cell(largeur_valeur, 4.6, valeur)
    return max(pdf.get_y(), y + 4.6) + 1.6


def _entete(pdf: PDF, y0: float, titre: str, numero: str, date: str, mention: str,
            ligne_numero: str | None = None) -> float:
    """En-tête ISUP commun à tous les documents ; renvoie le y où commence le corps.

    ligne_numero : texte affiché à la place de « N° … » (ex. une période pour un rapport).
    """
    logo, x = logo_document(), 12
    if logo:
        pdf.image(str(logo), x=12, y=y0 + 2, w=21)
        x = 37
    pdf.texte(x, y0 + 3, ENTETE["nom"], taille=15, couleur=ORANGE, style="B")
    pdf.texte(x, y0 + 10.5, ENTETE["activite"], taille=8, couleur=MARINE)
    pdf.texte(x, y0 + 15, ENTETE["adresse"], taille=7, couleur=GRIS)
    pdf.texte(x, y0 + 18.8, ENTETE["contact"], taille=7, couleur=GRIS)
    pdf.texte(x, y0 + 22.6, ENTETE["rccm"], taille=7, couleur=GRIS)
    pdf.texte(x, y0 + 26.4, ENTETE["ncc"], taille=7, couleur=GRIS)

    pdf.texte(120, y0 + 3, titre, taille=13, couleur=MARINE, style="B", largeur=78, align="R")
    pdf.texte(110, y0 + 10.5, ligne_numero or f"N° {numero}", taille=10.5, couleur=ORANGE, style="B", largeur=88,
              align="R")
    pdf.texte(120, y0 + 16, f"Date : {date}", taille=8.5, couleur=ENCRE, largeur=78, align="R")
    pdf.texte(120, y0 + 21, mention, taille=7, couleur=GRIS, largeur=78, align="R")

    pdf.set_draw_color(*VERT)
    pdf.set_line_width(0.6)
    pdf.line(12, y0 + 31, 198, y0 + 31)
    return y0 + 35


def _montant(pdf: PDF, y: float, d: dict) -> float:
    """Montant en lettres puis en chiffres (mis en valeur)."""
    y = _ligne(pdf, y, "La somme de", d["montant_lettres"])
    pdf.set_fill_color(*FOND_VERT)
    pdf.rect(54, y - 1, 70, 8, style="F")
    pdf.texte(56, y + 0.6, francs(d["montant"]), taille=12, couleur=MARINE, style="B")
    pdf.texte(16, y + 1, "En chiffres", taille=8.5, couleur=GRIS)
    return y + 10


def _pied(pdf: PDF, y0: float, date: str, sous_signature: str = "") -> None:
    """« Fait à {ENTETE['ville']} », et cadre pour la signature et le cachet."""
    y_pied = y0 + 115
    pdf.texte(16, y_pied, f"Fait à {ENTETE['ville']}, le {date}", taille=9, couleur=ENCRE)
    if sous_signature:
        pdf.texte(16, y_pied + 6, sous_signature, taille=8, couleur=GRIS)
    pdf.set_draw_color(*GRIS)
    pdf.set_line_width(0.2)
    pdf.rect(128, y_pied - 3, 70, 22)
    pdf.texte(128, y_pied - 1.5, "Signature et cachet", taille=7.5, couleur=GRIS, largeur=70, align="C")


def _page_double(dessiner, titre_pdf: str,
                 mentions: tuple[str, str] | None = None) -> bytes:
    """Une page A4 : original en haut, duplicata (souche) en bas, ligne de découpe au milieu."""
    mentions = mentions or ("ORIGINAL — Locataire", f"DUPLICATA — {ENTETE['nom']} (souche)")
    pdf = PDF()
    pdf.set_title(titre_pdf)
    pdf.add_page()
    dessiner(pdf, 6, mentions[0])
    pdf.set_draw_color(*GRIS)
    pdf.set_line_width(0.2)
    pdf.set_dash_pattern(dash=2, gap=1.5)
    pdf.line(8, 148.5, 202, 148.5)
    pdf.set_dash_pattern()
    pdf.texte(8, 145.5, "Découper ici", taille=6, couleur=GRIS)
    dessiner(pdf, 152, mentions[1])
    return bytes(pdf.output())


# ---------- Reçu de paiement ----------

def _recu(pdf: PDF, y0: float, d: dict, mention: str) -> None:
    y = _entete(pdf, y0, "REÇU DE PAIEMENT", d["numero_recu"], d["date"], mention)
    y = _ligne(pdf, y, "Reçu de", d["locataire"])
    y = _montant(pdf, y, d)
    y = _ligne(pdf, y, "Motif", d["motif"])
    y = _ligne(pdf, y, "Période", d["periode"] or "—")
    y = _ligne(pdf, y, "Logement", f"{d['logement']} — Contrat N° {d['numero_contrat']}")
    y = _ligne(pdf, y, "Mode de paiement", d["mode"])
    if d.get("detail"):
        y = _ligne(pdf, y, "Détail", d["detail"])

    # --- Situation du contrat : caution, avance, reste (jamais sur une quittance, ni sur le reçu d'un versement
    # partiel, dont la ligne « Détail » donne déjà le reste du mois : décision de Boss du 10/11/2026) ---
    if not d.get("sans_situation"):
        y += 1
        pdf.set_draw_color(*VERT)
        pdf.set_line_width(0.3)
        pdf.set_fill_color(250, 251, 249)
        pdf.rect(16, y, 182, 13, style="DF")
        colonnes = [
            ("Caution", d["caution"]),
            ("Avance", d["avance"]),
            ("Reste à payer à ce jour", d["reste"]),
        ]
        for i, (libelle, valeur) in enumerate(colonnes):
            x = 19 + i * 60
            pdf.texte(x, y + 2, libelle, taille=7.5, couleur=GRIS)
            pdf.texte(x, y + 7, valeur, taille=9.5, couleur=MARINE, police="MontserratSemi")

    _pied(pdf, y0, d["date"], f"Encaissé par : {d['caissier']}" if d.get("caissier") else "")


def recu_pdf(d: dict) -> bytes:
    """Construit le PDF du reçu à partir des données préparées par paiements.py."""
    return _page_double(lambda pdf, y0, mention: _recu(pdf, y0, d, mention), f"Reçu de paiement — {ENTETE['nom']}")


def _recu_sejour(pdf: PDF, y0: float, d: dict, mention: str) -> None:
    y = _entete(pdf, y0, "REÇU DE PAIEMENT", d["numero"], d["date"], mention)
    y = _ligne(pdf, y, "Reçu de", d["client"])
    y = _montant(pdf, y, d)
    y = _ligne(pdf, y, "Motif", d["motif"])
    y = _ligne(pdf, y, "Séjour", d["sejour"])
    y = _ligne(pdf, y, "Réservation", f"N° {d['reservation']}")
    y = _ligne(pdf, y, "Mode de paiement", d["mode"])
    y += 1
    pdf.set_draw_color(*VERT)
    pdf.set_line_width(0.3)
    pdf.set_fill_color(250, 251, 249)
    pdf.rect(16, y, 182, 13, style="DF")
    for i, (libelle, valeur) in enumerate((("Prix du séjour", d["total"]), ("Déjà réglé", d["deja"]),
                                           ("Reste à payer", d["reste"]))):
        x = 19 + i * 60
        pdf.texte(x, y + 2, libelle, taille=7.5, couleur=GRIS)
        pdf.texte(x, y + 7, valeur, taille=9.5, couleur=MARINE, police="MontserratSemi")
    _pied(pdf, y0, d["date"], f"Encaissé par : {d['caissier']}" if d.get("caissier") else "")


def recu_sejour_pdf(d: dict) -> bytes:
    """Reçu d'un versement pour un séjour en courte durée (sejours.py)."""
    return _page_double(lambda pdf, y0, mention: _recu_sejour(pdf, y0, d, mention), f"Reçu de séjour — {ENTETE['nom']}",
                        ("ORIGINAL — Client", f"DUPLICATA — {ENTETE['nom']} (souche)"))


# ---------- Quittance de loyer ----------
# Règle : une quittance n'affiche JAMAIS la caution, l'avance ni le reste à payer.

def _quittance(pdf: PDF, y0: float, d: dict, mention: str) -> None:
    y = _entete(pdf, y0, "QUITTANCE DE LOYER", d["numero"], d["date"], mention)
    # texte d'usage d'une quittance
    pdf.set_font("Montserrat", "", 9.5)
    pdf.set_text_color(*ENCRE)
    pdf.set_xy(16, y)
    pdf.multi_cell(182, 5.2, d["declaration"])
    y = pdf.get_y() + 3
    y = _ligne(pdf, y, "Locataire", d["locataire"])
    y = _ligne(pdf, y, "Logement", f"{d['logement']} — Contrat N° {d['numero_contrat']}")
    y = _ligne(pdf, y, "Période", d["periode"])
    y = _ligne(pdf, y, "Loyer mensuel", d["loyer_mensuel"])
    y = _montant(pdf, y, d)
    _ligne(pdf, y, "Payé le", f"{d['date']} — {d['mode']}")
    _pied(pdf, y0, d["date"], f"Pour {ENTETE['nom']}")


def quittance_pdf(d: dict) -> bytes:
    """Construit le PDF de la quittance à partir des données préparées par paiements.py."""
    return _page_double(lambda pdf, y0, mention: _quittance(pdf, y0, d, mention), f"Quittance de loyer — {ENTETE['nom']}")


# ---------- Achats / Ventes de biens : facture, reçu de vente, décharge ----------

def _facture(pdf: PDF, y0: float, d: dict, mention: str) -> None:
    y = _entete(pdf, y0, d.get("titre", "FACTURE"), d["numero_document"], d["date"], mention)
    y = _ligne(pdf, y, "Client", d["client"])
    if d.get("client_coordonnees"):
        y = _ligne(pdf, y, "Coordonnées", d["client_coordonnees"])
    y = _ligne(pdf, y, "Opération", d["libelle_operation"])
    # tableau : désignation / montant
    y += 1
    pdf.set_fill_color(*MARINE)
    pdf.rect(16, y, 182, 7, style="F")
    pdf.texte(19, y + 1.6, "Désignation", taille=8.5, couleur=(255, 255, 255), style="B")
    pdf.texte(150, y + 1.6, "Montant", taille=8.5, couleur=(255, 255, 255), style="B", largeur=45, align="R")
    pdf.set_font("Montserrat", "", 9)
    pdf.set_text_color(*ENCRE)
    pdf.set_xy(19, y + 9)
    pdf.multi_cell(125, 4.8, d["designation"])
    bas = max(pdf.get_y(), y + 15)
    pdf.texte(150, y + 9.4, francs(d["montant"]), taille=9.5, couleur=ENCRE, police="MontserratSemi", largeur=45, align="R")
    pdf.set_draw_color(*VERT)
    pdf.set_line_width(0.3)
    pdf.line(16, bas + 1, 198, bas + 1)
    pdf.texte(110, bas + 3, "TOTAL", taille=9.5, couleur=MARINE, style="B", largeur=40, align="R")
    pdf.texte(150, bas + 3, francs(d["montant"]), taille=10.5, couleur=MARINE, style="B", largeur=45, align="R")
    y = bas + 11
    pdf.set_font("Montserrat", "", 9)
    pdf.set_text_color(*ENCRE)
    pdf.set_xy(16, y)
    pdf.multi_cell(182, 4.8, f"Arrêtée la présente facture à la somme de {d['montant_lettres'][0].lower()}"
                             f"{d['montant_lettres'][1:]}.")
    y = pdf.get_y() + 2
    y = _ligne(pdf, y, "Règlement", f"Payée le {d['date']} — {d['mode']}")
    if d.get("rib_entreprise"):  # coordonnées bancaires de l'entreprise (Paramètres), pour payer par virement
        _ligne(pdf, y, "Nos coordonnées", d["rib_entreprise"])
    _pied(pdf, y0, d["date"], f"Pour {ENTETE['nom']}")


def _recu_vente(pdf: PDF, y0: float, d: dict, mention: str) -> None:
    y = _entete(pdf, y0, "REÇU DE PAIEMENT", d["numero_document"], d["date"], mention)
    y = _ligne(pdf, y, "Reçu de", d["partie"])
    y = _montant(pdf, y, d)
    y = _ligne(pdf, y, "Motif", d["motif"])
    if d.get("pour_compte"):  # vente indirecte : ISUP intermédiaire
        y = _ligne(pdf, y, "Intermédiaire", d["pour_compte"])
    y = _ligne(pdf, y, "Opération", d["libelle_operation"])
    _ligne(pdf, y, "Mode de paiement", d["mode"])
    _pied(pdf, y0, d["date"], f"Encaissé par : {d['saisi_par']}" if d.get("saisi_par") else "")


def _decharge(pdf: PDF, y0: float, d: dict, mention: str) -> None:
    y = _entete(pdf, y0, "DÉCHARGE", d["numero_document"], d["date"], mention)
    pdf.set_font("Montserrat", "", 9.5)
    pdf.set_text_color(*ENCRE)
    pdf.set_xy(16, y)
    pdf.multi_cell(182, 5.2, d["declaration"], align="J")
    y = pdf.get_y() + 3
    y = _montant(pdf, y, d)
    y = _ligne(pdf, y, "Objet", d["designation"])
    _ligne(pdf, y, "Opération", f"{d['libelle_operation']} — {d['mode']}")
    # deux signatures : le bénéficiaire (vendeur) et ISUP
    y_pied = y0 + 115
    pdf.texte(16, y_pied - 7, f"Fait à {ENTETE['ville']}, le {d['date']}", taille=9, couleur=ENCRE)
    for x, qui, nom in ((16, "Le bénéficiaire", d["partie"]), (110, f"Pour {ENTETE['nom']}", "")):
        pdf.set_draw_color(*GRIS)
        pdf.set_line_width(0.2)
        pdf.rect(x, y_pied - 2, 88, 21)
        pdf.texte(x, y_pied - 0.5, qui + (" (« Lu et approuvé »)" if nom else ""), taille=7.5, couleur=GRIS,
                  largeur=88, align="C")
        if nom:
            pdf.texte(x, y_pied + 15, nom, taille=7.5, couleur=GRIS, largeur=88, align="C")


def document_operation_pdf(type_document: str, d: dict) -> bytes:
    """Facture, Reçu de paiement ou Décharge d'une opération d'achat / vente."""
    dessin = {"Facture": _facture, "Reçu de paiement": _recu_vente, "Décharge": _decharge}[type_document]
    # la décharge signée par le vendeur est gardée par ISUP ; facture et reçu vont au client
    mentions = ((f"ORIGINAL — {ENTETE['nom']}", "COPIE — Bénéficiaire") if type_document == "Décharge"
                else ("ORIGINAL — Client", f"DUPLICATA — {ENTETE['nom']} (souche)"))
    return _page_double(lambda pdf, y0, mention: dessin(pdf, y0, d, mention), f"{type_document} — {ENTETE['nom']}", mentions)


# ---------- Reversements (précomptabilité, partie 2) ----------

def _coordonnees_texte(c: dict) -> str:
    morceaux = []
    if c.get("banque"):
        morceaux.append(c["banque"])
    if c.get("rib"):
        morceaux.append(f"RIB {c['rib']}")
    if c.get("iban"):
        morceaux.append(f"IBAN {c['iban']}")
    if c.get("bic"):
        morceaux.append(f"BIC {c['bic']}")
    return " — ".join(morceaux)


def _bordereau(pdf: PDF, y0: float, d: dict, mention: str) -> None:
    titre = {"Loyers": "BORDEREAU DE REVERSEMENT", "Vente": "BORDEREAU DE VERSEMENT",
             "Caution": "RESTITUTION DE CAUTION"}[d["type"]]
    y = _entete(pdf, y0, titre, d["numero"], d["date"], mention)
    y = _ligne(pdf, y, "Versé à", d["beneficiaire"])
    y = _montant(pdf, y, d)
    y = _ligne(pdf, y, "Motif", d["motif"])
    paiement = f"{d['mode']} — depuis : {d['compte']}"
    if d["mode"] == "Virement" and _coordonnees_texte(d["coordonnees"]):
        paiement += f" — vers : {_coordonnees_texte(d['coordonnees'])}"
    elif d["mode"] == "Mobile Money" and d["coordonnees"].get("mobile_money"):
        paiement += f" — vers le n° {d['coordonnees']['mobile_money']}"
    y = _ligne(pdf, y, "Paiement", paiement)
    if d["reference"]:
        y = _ligne(pdf, y, "Référence", d["reference"])
    if d["type"] == "Caution":
        y = _ligne(pdf, y, "Caution détenue", d["caution"]["caution_avant"])
        if d["caution"]["motif_retenue"]:
            y = _ligne(pdf, y, "Retenue", f"{d['caution']['retenue']} — {d['caution']['motif_retenue']}")
        _ligne(pdf, y, "Reste détenu", f"{d['reste_apres']} après cette restitution")
    else:
        _ligne(pdf, y, "Reste à verser", f"{d['reste_apres']} après ce versement")
    # deux signatures : le bénéficiaire reconnaît avoir reçu la somme, l'entreprise atteste le versement
    y_pied = y0 + 115
    pdf.texte(16, y_pied - 7, f"Fait à {ENTETE['ville']}, le {d['date']}", taille=9, couleur=ENCRE)
    for x, qui, nom in ((16, "Le bénéficiaire (« Reçu la somme ci-dessus »)", d["beneficiaire"]),
                        (110, f"Pour {ENTETE['nom']}", d.get("saisi_par", ""))):
        pdf.set_draw_color(*GRIS)
        pdf.set_line_width(0.2)
        pdf.rect(x, y_pied - 2, 88, 21)
        pdf.texte(x, y_pied - 0.5, qui, taille=7.5, couleur=GRIS, largeur=88, align="C")
        if nom:
            pdf.texte(x, y_pied + 15, nom, taille=7.5, couleur=GRIS, largeur=88, align="C")


def bordereau_reversement_pdf(d: dict) -> bytes:
    """Bordereau en deux exemplaires : l'original signé reste à l'entreprise, la copie au bénéficiaire."""
    return _page_double(lambda pdf, y0, mention: _bordereau(pdf, y0, d, mention),
                        f"Bordereau {d['numero']} — {ENTETE['nom']}",
                        (f"ORIGINAL — {ENTETE['nom']}", "COPIE — Bénéficiaire"))


def ordre_virement_pdf(d: dict) -> bytes:
    """Ordre de virement adressé à la banque de l'entreprise (à signer, puis à déposer ou recopier en ligne)."""
    pdf = PDF()
    pdf.set_title(f"Ordre de virement {d['numero']} — {ENTETE['nom']}")
    pdf.add_page()
    e, c = d["entreprise"], d["coordonnees"]
    y = _entete(pdf, 8, "ORDRE DE VIREMENT", d["numero"], d["date"], "À remettre à la banque")
    y = _ligne(pdf, y + 2, "À l'attention de", e["banque"] or "Notre banque")
    y += 3
    for titre, lignes in (
        ("DONNEUR D'ORDRE (compte à débiter)", [("Titulaire", e["titulaire"]), ("RIB", e["rib"] or "—"),
                                               ("IBAN", e["iban"] or "—"), ("BIC / SWIFT", e["bic"] or "—")]),
        ("BÉNÉFICIAIRE (compte à créditer)", [("Nom", c.get("titulaire") or d["beneficiaire"]),
                                              ("Banque", c.get("banque") or "—"), ("RIB", c.get("rib") or "—"),
                                              ("IBAN", c.get("iban") or "—"), ("BIC / SWIFT", c.get("bic") or "—")]),
    ):
        pdf.set_fill_color(*FOND_VERT)
        pdf.rect(12, y, 186, 7, style="F")
        pdf.texte(16, y + 1.6, titre, taille=8.5, couleur=MARINE, style="B")
        y += 10
        for libelle, valeur in lignes:
            y = _ligne(pdf, y, libelle, valeur)
        y += 3
    y = _montant(pdf, y, d)
    y = _ligne(pdf, y, "Motif du virement", f"{d['motif']} — Réf. {d['numero']}")
    y += 4
    pdf.set_font("Montserrat", "", 9.5)
    pdf.set_text_color(*ENCRE)
    pdf.set_xy(16, y)
    pdf.multi_cell(182, 5.2, f"Nous vous prions de bien vouloir débiter notre compte ci-dessus de la somme de "
                             f"{francs(d['montant'])} et d'en créditer le compte du bénéficiaire désigné ci-dessus.",
                   align="J")
    y = pdf.get_y() + 10
    pdf.texte(16, y, f"Fait à {ENTETE['ville']}, le {d['date']}", taille=9, couleur=ENCRE)
    pdf.set_draw_color(*GRIS)
    pdf.set_line_width(0.2)
    pdf.rect(118, y - 3, 80, 30)
    pdf.texte(118, y - 1.5, "Signature autorisée et cachet", taille=7.5, couleur=GRIS, largeur=80, align="C")
    return bytes(pdf.output())


# ---------- Rapport d'activité et relevés de reversement (étape 8) ----------

class _PDFRapport(PDF):
    def __init__(self, periode: str):
        super().__init__()
        self.periode = periode
        self.set_margins(14, 12, 14)
        self.set_auto_page_break(True, margin=20)

    def footer(self):
        self.set_draw_color(*VERT)
        self.set_line_width(0.3)
        self.line(14, 284, 196, 284)
        self.texte(14, 286, f"{ENTETE['nom']} — Rapport du {self.periode}", taille=7, couleur=GRIS)
        self.texte(14, 286, f"Page {self.page_no()}/{{nb}}", taille=7, couleur=GRIS, largeur=182, align="R")


def _f(valeur) -> str:
    """Montant court pour les tableaux : 1 250 000 F."""
    return f"{Decimal(str(valeur or 0)):,.0f}".replace(",", " ") + " F"


def _titre_section(pdf: PDF, texte: str) -> None:
    if pdf.get_y() > 245:
        pdf.add_page()
    pdf.ln(3)
    pdf.set_font("Montserrat", "B", 10.5)
    pdf.set_text_color(*MARINE)
    pdf.cell(0, 6, texte, new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(*VERT)
    pdf.set_line_width(0.5)
    pdf.line(14, pdf.get_y(), 60, pdf.get_y())
    pdf.ln(2)


def _tableau(pdf: PDF, colonnes: list[tuple[str, float, str]], lignes: list[list[str]],
             total: list[str] | None = None) -> None:
    """Tableau simple : en-tête marine, lignes alternées, ligne de total en gras."""
    def entete():
        pdf.set_fill_color(*MARINE)
        pdf.set_text_color(255, 255, 255)
        pdf.set_font("Montserrat", "B", 8)
        for titre, largeur, align in colonnes:
            pdf.cell(largeur, 7, titre, align=align, fill=True)
        pdf.ln()

    entete()
    pdf.set_font("Montserrat", "", 8.5)
    for i, ligne in enumerate(lignes):
        if pdf.get_y() > 270:
            pdf.add_page()
            entete()
            pdf.set_font("Montserrat", "", 8.5)
        pdf.set_fill_color(*((247, 249, 246) if i % 2 else (255, 255, 255)))
        pdf.set_text_color(*ENCRE)
        for (_, largeur, align), valeur in zip(colonnes, ligne):
            pdf.cell(largeur, 6.5, str(valeur), align=align, fill=True)
        pdf.ln()
    if not lignes:
        pdf.set_text_color(*GRIS)
        pdf.cell(sum(c[1] for c in colonnes), 7, "Aucune donnée sur la période.", align="C")
        pdf.ln()
    if total:
        pdf.set_fill_color(*FOND_VERT)
        pdf.set_text_color(*MARINE)
        pdf.set_font("MontserratSemi", "", 8.5)
        for (_, largeur, align), valeur in zip(colonnes, total):
            pdf.cell(largeur, 7, str(valeur), align=align, fill=True)
        pdf.ln()


def _cartes(pdf: PDF, cartes: list[tuple[str, str]]) -> None:
    """Chiffres clés en cartes (4 par ligne)."""
    largeur, hauteur, ecart = 43.5, 15, 2.5
    y0 = pdf.get_y()  # position de départ fixe (écrire du texte déplace le curseur)
    for i, (libelle, valeur) in enumerate(cartes):
        x = 14 + (i % 4) * (largeur + ecart)
        y = y0 + (i // 4) * (hauteur + ecart)
        pdf.set_fill_color(250, 251, 249)
        pdf.set_draw_color(*VERT)
        pdf.set_line_width(0.3)
        pdf.rect(x, y, largeur, hauteur, style="DF")
        pdf.texte(x + 2.5, y + 2, libelle, taille=6.8, couleur=GRIS)
        pdf.texte(x + 2.5, y + 8, valeur, taille=10.5, couleur=MARINE, style="B")
    lignes = (len(cartes) + 3) // 4
    pdf.set_y(y0 + lignes * (hauteur + ecart))


def _page_releve(pdf, p: dict, periode: str):
    """Une page « Relevé de reversement » à remettre au propriétaire."""
    from datetime import date as _date
    pdf.add_page()
    y = _entete(pdf, 6, "RELEVÉ DE REVERSEMENT", "", _date.today().strftime("%d/%m/%Y"),
                "Document à remettre au propriétaire", ligne_numero=f"Du {periode}")
    pdf.set_y(y)
    _ligne(pdf, pdf.get_y(), "Propriétaire", p["proprietaire"] + (f" — Tél. {p['telephone']}" if p["telephone"] else ""))
    pdf.set_y(pdf.get_y() + 2)
    _tableau(pdf, [("Bien", 64, "L"), ("Loyers", 30, "R"), ("Commission", 28, "R"), ("Dépenses", 28, "R"), ("Net", 32, "R")],
             [[b["bien"], _f(b["loyers"]), _f(b["commission"]), _f(b["depenses"]), _f(b["net"])] for b in p["biens"]],
             ["TOTAL", _f(p["loyers"]), _f(p["commission"]), _f(p["depenses"]), _f(p["net"])])
    pdf.ln(3)
    net = Decimal(str(p["net"]))
    lettres = en_lettres(net) if net > 0 else "Zéro franc CFA"
    y = _ligne(pdf, pdf.get_y(), "Net à reverser", f"{francs(net)} ({lettres[0].lower() + lettres[1:]})")
    if p["cautions"]:
        y = _ligne(pdf, y + 1, "Cautions perçues", f"{francs(p['cautions'])} — conservées par l'entreprise, "
                                                     "restituées au locataire à la fin du bail")
    pdf.set_y(y)
    y = max(pdf.get_y() + 10, 200)
    for x, qui in ((14, "Le propriétaire (« Lu et approuvé »)"), (106, f"Pour {ENTETE['nom']}")):
        pdf.set_draw_color(*GRIS)
        pdf.set_line_width(0.2)
        pdf.rect(x, y, 90, 30)
        pdf.texte(x, y + 2, qui, taille=8, couleur=GRIS, largeur=90, align="C")
    pdf.texte(14, y + 34, f"Fait à {ENTETE['ville']}, le {_date.today().strftime('%d/%m/%Y')}", taille=9, couleur=ENCRE)


def releve_proprietaire_pdf(p: dict, periode: str) -> bytes:
    """Relevé d'un seul propriétaire (envoyé par WhatsApp ou e-mail)."""
    pdf = _PDFRapport(periode)
    pdf.set_title(f"Relevé de reversement — {p['proprietaire']} — {periode}")
    _page_releve(pdf, p, periode)
    return bytes(pdf.output())


def rapport_pdf(r: dict, admin: bool) -> bytes:
    debut = ".".join(reversed(r["debut"].split("-"))).replace(".", "/")
    fin = ".".join(reversed(r["fin"].split("-"))).replace(".", "/")
    periode = f"{debut} au {fin}"
    pdf = _PDFRapport(periode)
    pdf.set_title(f"Rapport d'activité — {periode}")
    pdf.add_page()
    from datetime import date as _date
    y = _entete(pdf, 6, "RAPPORT D'ACTIVITÉ", "", _date.today().strftime("%d/%m/%Y"), "",
                ligne_numero=f"Du {periode}")
    pdf.set_y(y)

    k = r["kpis"]
    cartes = [("Total encaissé", _f(k["total_encaisse"])), ("Loyers encaissés", _f(k["loyers"])),
              ("Cautions perçues", _f(k["cautions"])), ("Dépenses", _f(k["depenses"]))]
    if admin:
        cartes += [("Commission de gestion", _f(k["commission_entreprise"])), ("Dépenses propriétaires", _f(k["depenses_proprietaires"])),
                   ("Net à reverser", _f(k["net_a_reverser"]))]
    cartes += [("Taux d'impayés", f"{k['taux_impayes']:.1f} %".replace(".", ",")),
               ("Contrats en retard", str(k["contrats_en_retard"])), ("Contrats à risque", str(k["contrats_a_risque"]))]
    _cartes(pdf, cartes)

    if admin:
        _titre_section(pdf, "Reversements propriétaires vs commission de gestion")
        cols = [("Propriétaire", 62, "L"), ("Loyers", 30, "R"), ("Commission de gestion", 30, "R"),
                ("Dépenses", 28, "R"), ("Net à reverser", 32, "R")]
        lignes = [[p["proprietaire"] + (" (bien de l'entreprise)" if p["bien_entreprise"] else ""), _f(p["loyers"]), _f(p["commission"]),
                   _f(p["depenses"]), _f(p["net"])] for p in r["reversements"]]
        tot = lambda cle: sum(Decimal(str(p[cle])) for p in r["reversements"])
        _tableau(pdf, cols, lignes, ["TOTAL", _f(tot("loyers")), _f(tot("commission")), _f(tot("depenses")), _f(tot("net"))])
        pdf.set_font("Montserrat", "", 7.5)
        pdf.set_text_color(*GRIS)
        pdf.multi_cell(0, 4, "Net à reverser = loyers encaissés − commission de gestion − dépenses à la charge du propriétaire. "
                             "Les cautions, conservées par l'entreprise, ne sont pas reversées.")

    _titre_section(pdf, "Situation par bien")
    _tableau(pdf, [("Bien", 72, "L"), ("Loyers", 34, "R"), ("Dépenses", 34, "R"), ("Occupation", 42, "R")],
             [[b["bien"], _f(b["loyers"]), _f(b["depenses"]),
               f"{b['occupes']}/{b['logements']}" + (f" ({b['taux_occupation']} %)" if b["taux_occupation"] is not None else "")]
              for b in r["par_bien"]])

    _titre_section(pdf, "Encaissements par mode de paiement")
    _tableau(pdf, [("Mode de paiement", 120, "L"), ("Montant", 62, "R")],
             [[m["mode"], _f(m["montant"])] for m in r["par_mode"]],
             ["TOTAL", _f(k["total_encaisse"])])

    _titre_section(pdf, "Contrats en retard")
    _tableau(pdf, [("Contrat", 32, "L"), ("Locataire", 50, "L"), ("Logement", 56, "L"), ("Mois", 14, "R"), ("Montant dû", 30, "R")],
             [[c["numero_contrat"], c["locataire"], c["logement"],
               str(c["nb_mois"]) + (" !" if c["a_risque"] else ""), _f(c["montant"])] for c in r["a_risque"]])

    # Un relevé par propriétaire, à lui remettre
    if admin:
        for p in r["reversements"]:
            _page_releve(pdf, p, periode)
    return bytes(pdf.output())


# ---------- Contrat de bail (texte tiré du modèle modeles/contrat_bail.txt) ----------

def resultat_pdf(r: dict) -> bytes:
    """Compte de résultat simplifié, TVA et trésorerie d'une période (précomptabilité)."""
    from datetime import date as _date
    jj = lambda iso: "/".join(reversed(iso.split("-")))  # noqa: E731
    periode = f"{jj(r['debut'])} au {jj(r['fin'])}"
    pdf = _PDFRapport(periode)
    pdf.set_title(f"Résultat et TVA — {periode}")
    pdf.add_page()
    y = _entete(pdf, 6, "RÉSULTAT ET TVA", "", _date.today().strftime("%d/%m/%Y"), "",
                ligne_numero=f"Du {periode}")
    pdf.set_y(y)
    t = r["tva"]
    cartes = [("Produits", _f(r["total_produits"])), ("Charges", _f(r["total_charges"])),
              ("Résultat", _f(r["resultat"]))]
    if t["assujetti"]:
        cartes.append(("TVA à reverser" if t["a_payer"] >= 0 else "Crédit de TVA", _f(abs(t["a_payer"]))))
    _cartes(pdf, cartes)
    ht = " (hors TVA)" if t["assujetti"] else ""
    _titre_section(pdf, "Produits" + ht)
    _tableau(pdf, [("Poste", 132, "L"), ("Montant", 50, "R")],
             [[x["poste"], _f(x["montant"])] for x in r["produits"]], ["Total des produits", _f(r["total_produits"])])
    _titre_section(pdf, "Charges de l'entreprise" + ht)
    _tableau(pdf, [("Poste", 132, "L"), ("Montant", 50, "R")],
             [[x["poste"], _f(x["montant"])] for x in r["charges"]], ["Total des charges", _f(r["total_charges"])])
    _titre_section(pdf, "Résultat de la période")
    _tableau(pdf, [("", 132, "L"), ("Montant", 50, "R")], [["Produits", _f(r["total_produits"])],
                                                           ["Charges", "− " + _f(r["total_charges"])]],
             ["Résultat (bénéfice si positif, perte si négatif)", _f(r["resultat"])])
    if r["par_mois"]:
        _titre_section(pdf, "Résultat mois par mois")
        _tableau(pdf, [("Mois", 62, "L"), ("Produits", 40, "R"), ("Charges", 40, "R"), ("Résultat", 40, "R")],
                 [[f"{jj(m['debut'])[3:]}", _f(m["total_produits"]), _f(m["total_charges"]), _f(m["resultat"])]
                  for m in r["par_mois"]])
    if t["assujetti"]:
        _titre_section(pdf, f"TVA (taux {str(t['taux']).replace('.', ',')} %)")
        _tableau(pdf, [("", 132, "L"), ("Montant", 50, "R")],
                 [["TVA collectée sur les commissions", _f(t["collectee"])],
                  ["TVA payée sur les dépenses (récupérable)", "− " + _f(t["deductible"])]],
                 ["TVA à reverser à l'État" if t["a_payer"] >= 0 else "Crédit de TVA (à reporter)",
                  _f(abs(t["a_payer"]))])
    if r["biens"]["achats"] or r["biens"]["ventes"]:
        _titre_section(pdf, "Achats et ventes de biens (hors activité courante)")
        _tableau(pdf, [("", 132, "L"), ("Montant", 50, "R")],
                 [["Achats de biens (investissements)", _f(r["biens"]["achats"])],
                  ["Ventes de biens (cessions)", _f(r["biens"]["ventes"])]])
    _titre_section(pdf, "Trésorerie")
    _tableau(pdf, [("Compte", 92, "L"), ("Début de période", 45, "R"), ("Fin de période", 45, "R")],
             [[x["compte"], _f(x["debut"]), _f(x["fin"])] for x in r["tresorerie"]],
             ["Total", _f(sum(x["debut"] for x in r["tresorerie"])), _f(sum(x["fin"] for x in r["tresorerie"]))])
    pdf.ln(4)
    pdf.set_font("Montserrat", "", 7.5)
    pdf.set_text_color(*GRIS)
    pdf.multi_cell(182, 4, "Document de précomptabilité établi à partir des opérations enregistrées dans Gérimo. "
                           "Il ne remplace pas les états financiers SYSCOHADA établis par le comptable.")
    return bytes(pdf.output())


# ---------- Rapport mensuel par bien (rapport_bien.py), A4 paysage ----------

class _PDFParBien(PDF):
    """A4 paysage : 297 × 210 mm, marges de 12 mm (largeur utile 273 mm)."""
    def __init__(self, periode: str):
        FPDF.__init__(self, orientation="L", format="A4")
        self.set_margins(12, 10, 12)
        self.set_auto_page_break(True, margin=16)
        self.add_font("Montserrat", "", str(POLICES / "Montserrat-Medium.ttf"))
        self.add_font("Montserrat", "B", str(POLICES / "Montserrat-Bold.ttf"))
        self.add_font("MontserratSemi", "", str(POLICES / "Montserrat-SemiBold.ttf"))
        self.set_author(f"{ENTETE['nom']}")
        self.periode = periode
        self.bien = ""

    def footer(self):
        self.set_draw_color(*VERT)
        self.set_line_width(0.3)
        self.line(12, 199, 285, 199)
        self.texte(12, 201, f"{ENTETE['nom']} — {self.bien} — {self.periode}", taille=7, couleur=GRIS)
        self.texte(12, 201, f"Page {self.page_no()}/{{nb}}", taille=7, couleur=GRIS, largeur=273, align="R")


def _coupe(pdf: FPDF, texte, largeur: float) -> str:
    """Raccourcit un texte (avec « … ») pour qu'il tienne dans sa colonne."""
    texte = str(texte or "")
    if pdf.get_string_width(texte) <= largeur - 2:
        return texte
    while texte and pdf.get_string_width(texte + "…") > largeur - 2:
        texte = texte[:-1]
    return texte.rstrip() + "…"


def _tableau_large(pdf: FPDF, colonnes: list[tuple[str, float, str]], lignes: list[list[str]],
                   total: list[str] | None = None, styles: list[str] | None = None) -> None:
    """Tableau sur toute la largeur ; en-tête (titres sur deux lignes possibles) répété à chaque nouvelle page."""
    def entete():
        pdf.set_font("Montserrat", "B", 7.5)
        pdf.set_text_color(255, 255, 255)
        pdf.set_fill_color(*MARINE)
        y, x = pdf.get_y(), pdf.l_margin
        pdf.rect(x, y, sum(c[1] for c in colonnes), 9, style="F")
        for titre, largeur, align in colonnes:
            morceaux = titre.split("\n")
            for k, morceau in enumerate(morceaux):
                pdf.set_xy(x, y + (4.5 - 1.9 * len(morceaux)) + k * 3.8 + 0.4)
                pdf.cell(largeur, 3.8, morceau, align=align)
            x += largeur
        pdf.set_xy(pdf.l_margin, y + 9)

    entete()
    for i, ligne in enumerate(lignes):
        if pdf.get_y() > 186:
            pdf.add_page()
            entete()
        style = styles[i] if styles else ""
        pdf.set_fill_color(*((247, 249, 246) if i % 2 else (255, 255, 255)))
        pdf.set_text_color(*(GRIS if style == "discret" else ENCRE))
        pdf.set_font("Montserrat", "", 8)
        for (_, largeur, align), valeur in zip(colonnes, ligne):
            pdf.cell(largeur, 6.6, _coupe(pdf, valeur, largeur), align=align, fill=True)
        pdf.ln()
    if not lignes:
        pdf.set_text_color(*GRIS)
        pdf.set_font("Montserrat", "", 8)
        pdf.cell(sum(c[1] for c in colonnes), 7, "Aucune donnée sur la période.", align="C")
        pdf.ln()
    if total:
        if pdf.get_y() > 190:
            pdf.add_page()
        pdf.set_fill_color(*FOND_VERT)
        pdf.set_text_color(*MARINE)
        pdf.set_font("MontserratSemi", "", 8.3)
        for (_, largeur, align), valeur in zip(colonnes, total):
            pdf.cell(largeur, 7.2, _coupe(pdf, valeur, largeur), align=align, fill=True)
        pdf.ln()


def _page_bien(pdf: _PDFParBien, b: dict, periode: str, finances: bool) -> None:
    from datetime import date as _date
    pdf.bien = b["bien"]
    pdf.add_page()
    # En-tête : l'entreprise à gauche, le titre et la période à droite
    logo, x = logo_document(), 12
    if logo:
        pdf.image(str(logo), x=12, y=8, w=18)
        x = 33
    pdf.texte(x, 9, ENTETE["nom"], taille=13, couleur=ORANGE, style="B")
    pdf.texte(x, 15.5, ENTETE["activite"], taille=7.5, couleur=MARINE)
    pdf.texte(x, 19.5, ENTETE["adresse"], taille=6.8, couleur=GRIS)
    pdf.texte(x, 23, ENTETE["contact"], taille=6.8, couleur=GRIS)
    pdf.texte(150, 9, "RAPPORT MENSUEL DU BIEN", taille=13, couleur=MARINE, style="B", largeur=135, align="R")
    pdf.texte(150, 16, periode[:1].upper() + periode[1:], taille=11, couleur=ORANGE, style="B", largeur=135, align="R")
    pdf.texte(150, 22, f"Établi le {_date.today().strftime('%d/%m/%Y')}", taille=7, couleur=GRIS,
              largeur=135, align="R")
    pdf.set_draw_color(*VERT)
    pdf.set_line_width(0.6)
    pdf.line(12, 29, 285, 29)

    # Fiche du bien (deux colonnes)
    gauche = [("Bien", b["bien"]), ("Type de bien", b["type_bien"]), ("Adresse", b["adresse"] or "—"),
              ("Logements", f"{b['nb_logements']} dont {b['occupes']} occupé(s)")]
    droite = []
    if finances:
        droite = [("Propriétaire", b["proprietaire"]), ("Contact", b["proprietaire_telephone"] or "—"),
                  ("Commission de gestion", f"{str(b['pourcentage_commission']).replace('.', ',')} %"
                   if b["pourcentage_commission"] is not None else "—")]
    pdf.set_fill_color(250, 251, 249)
    pdf.rect(12, 32, 273, 25, style="F")
    for x, infos in ((15, gauche), (152, droite)):
        y = 34
        for libelle, valeur in infos:
            pdf.texte(x, y, libelle, taille=7.5, couleur=GRIS)
            pdf.set_font("MontserratSemi", "", 8.8)
            pdf.set_text_color(*(ORANGE if libelle in ("Bien", "Propriétaire") else ENCRE))
            pdf.set_xy(x + 36, y - 0.5)
            pdf.cell(94, 4.6, _coupe(pdf, valeur, 94))
            y += 5.6
    pdf.set_xy(12, 60)

    # Tableau des logements
    f = _f
    if finances:
        cols = [("N°", 15, "L"), ("Type", 26, "L"), ("Locataire", 47, "L"), ("Contact", 28, "L"),
                ("Loyer\nmensuel", 24, "R"), ("Loyer\nencaissé", 24, "R"), ("Commission\nagence", 23, "R"),
                ("Part\npropriétaire", 25, "R"), ("Loyer\nimpayé", 22, "R"), ("Mois\nimpayés", 18, "C"),
                ("Dépenses", 21, "R")]
    else:
        cols = [("N°", 16, "L"), ("Type", 30, "L"), ("Locataire", 60, "L"), ("Contact", 32, "L"),
                ("Loyer\nmensuel", 28, "R"), ("Loyer\nencaissé", 28, "R"), ("Loyer\nimpayé", 28, "R"),
                ("Mois\nimpayés", 22, "C"), ("Dépenses", 29, "R")]
    lignes, styles = [], []
    for l in b["lignes"]:
        ou_tiret = lambda v: f(v) if v else "—"  # noqa: E731
        ligne = [l["numero"], l["type_logement"], l["locataire"], l["telephone"] or "—", f(l["loyer_mensuel"]),
                 ou_tiret(l["encaisse"])]
        if finances:
            ligne += [ou_tiret(l["commission"]), ou_tiret(l["part_proprietaire"])]
        ligne += [ou_tiret(l["impaye"]), str(len(l["mois_impayes"]) or "—"), ou_tiret(l["depenses"])]
        lignes.append(ligne)
        styles.append("discret" if l["locataire"].startswith("—") else "")
    if b["depenses_communes"]:
        lignes.append(["", "", "Dépenses communes du bien", "", "", ""] + (["", ""] if finances else [])
                      + ["", "", f(b["depenses_communes"])])
        styles.append("discret")
    t = b["totaux"]
    total = ["TOTAL", "", "", "", f(t["loyer_mensuel"]), f(t["encaisse"])]
    if finances:
        total += [f(t["commission"]), f(t["part_proprietaire"])]
    total += [f(t["impaye"]), "", f(t["depenses"])]
    _tableau_large(pdf, cols, lignes, total, styles)

    # Récapitulatif en cartes : ce que le propriétaire touche
    pdf.ln(4)
    if pdf.get_y() > 165:
        pdf.add_page()
    cartes = [("Loyers encaissés", f(t["encaisse"]))]
    if finances:
        cartes += [("Commission agence", f(t["commission"])), ("Part propriétaire", f(t["part_proprietaire"])),
                   ("Dépenses propriétaire", f(t["depenses_proprietaire"])),
                   ("Net à reverser", f(t["net_a_reverser"]))]
    cartes += [("Loyers impayés", f(t["impaye"])), ("Total dépenses", f(t["depenses"]))]
    if t["cautions"]:
        cartes.append(("Cautions perçues", f(t["cautions"])))
    largeur = (273 - 2.5 * (len(cartes) - 1)) / len(cartes)
    y0 = pdf.get_y()
    for i, (libelle, valeur) in enumerate(cartes):
        x = 12 + i * (largeur + 2.5)
        net = libelle == "Net à reverser"
        pdf.set_fill_color(*(FOND_VERT if net else (250, 251, 249)))
        pdf.set_draw_color(*(ORANGE if net else VERT))
        pdf.set_line_width(0.5 if net else 0.3)
        pdf.rect(x, y0, largeur, 14, style="DF")
        pdf.set_font("Montserrat", "", 6.6)
        pdf.texte(x + 2, y0 + 2, _coupe(pdf, libelle, largeur - 2), taille=6.6, couleur=GRIS, largeur=largeur - 4)
        pdf.texte(x + 2, y0 + 7.5, valeur, taille=9.5, couleur=MARINE, style="B", largeur=largeur - 4)
    pdf.set_xy(12, y0 + 16)
    pdf.set_font("Montserrat", "", 6.8)
    pdf.set_text_color(*GRIS)
    note = ("Loyers encaissés pendant la période (cautions à part). Loyer impayé : loyer des mois de la période "
            "dont la date limite est passée et qui n'est pas réglé.")
    if finances:
        note += (" Part du propriétaire = loyers encaissés − commission de l'agence ; net à reverser = part du "
                 "propriétaire − dépenses à sa charge. Les cautions, conservées par l'entreprise, ne sont pas reversées.")
    pdf.multi_cell(273, 3.6, note)

    # Détail des dépenses
    if b["detail_depenses"]:
        pdf.ln(2)
        if pdf.get_y() > 170:
            pdf.add_page()
        pdf.set_font("Montserrat", "B", 9.5)
        pdf.set_text_color(*MARINE)
        pdf.cell(0, 6, "Détail des dépenses", new_x="LMARGIN", new_y="NEXT")
        jj = lambda iso: "/".join(reversed(iso.split("-")))  # noqa: E731
        _tableau_large(pdf, [("Date", 24, "L"), ("Logement", 26, "L"), ("Motif", 108, "L"), ("Catégorie", 45, "L"),
                             ("À la charge de", 35, "L"), ("Montant", 35, "R")],
                       [[jj(d["date"]), d["logement"], d["motif"], d["categorie"], d["a_la_charge_de"],
                         f(d["montant"])] for d in b["detail_depenses"]],
                       ["TOTAL", "", "", "", "", f(t["depenses"])])

    # Fait à … et signature
    if pdf.get_y() > 168:
        pdf.add_page()
    y = max(pdf.get_y() + 5, 170)
    pdf.texte(12, y, f"Fait à {ENTETE['ville']}, le {_date.today().strftime('%d/%m/%Y')}", taille=8.5, couleur=ENCRE)
    pdf.set_draw_color(*GRIS)
    pdf.set_line_width(0.2)
    pdf.rect(200, y - 2, 85, 24)
    pdf.texte(200, y - 0.5, f"Pour {ENTETE['nom']} (signature et cachet)", taille=7.2, couleur=GRIS, largeur=85,
              align="C")


def rapport_par_bien_pdf(r: dict) -> bytes:
    """Rapport mensuel par bien : une page (ou plus) par bien, en A4 paysage."""
    pdf = _PDFParBien(r["periode"])
    sujet = r["biens"][0]["bien"] if len(r["biens"]) == 1 else "tous les biens"
    pdf.set_title(f"Rapport mensuel — {sujet} — {r['periode']}")
    for b in r["biens"]:
        _page_bien(pdf, b, r["periode"], r["finances"])
    return bytes(pdf.output())


def valeurs_entreprise() -> dict:
    """Zones utilisables dans tous les modèles (messages WhatsApp, politique de confidentialité, contrat…) :
    l'identité de « Mon entreprise », jamais écrite en dur dans les textes."""
    telephones = ENTETE.get("telephones", "")
    return {"entreprise": ENTETE["nom"], "d_entreprise": d_entreprise(), "activite": ENTETE["activite"],
            "adresse": ENTETE["adresse"], "ville": ENTETE["ville"], "telephones": telephones,
            "telephone": telephones.split("/")[0].strip(), "email": ENTETE.get("email", ""),
            "rccm": ENTETE.get("rccm", ""), "ncc": ENTETE.get("ncc", "")}


class _ValeursModele(dict):
    """Zone absente : celle de l'entreprise si elle existe ({entreprise}, {telephone}…), sinon laissée telle
    quelle ({zone}) au lieu de planter."""
    def __missing__(self, cle):
        return valeurs_entreprise().get(cle, "{" + cle + "}")


CONDITION = re.compile(r"\[si (\w+) :(.*?)\]", re.S)


def remplir_modele(modele: str, valeurs: dict) -> list[tuple[str, str]]:
    """Découpe le modèle en blocs (« titre », « liste », « fort », « texte », « centre », « droite ») et remplit
    les zones. « [si avance : …] » n'est gardé que si la valeur « avance » est remplie ; un bloc vide disparaît."""
    blocs, paragraphe = [], []

    def finir_paragraphe():
        if paragraphe:
            texte = " ".join(paragraphe)
            if texte.startswith("= "):
                blocs.append(("centre", texte[2:]))
            elif texte.startswith("> "):
                blocs.append(("droite", texte[2:]))
            else:
                lettres = [c for c in texte if c.isalpha()]
                fort = lettres and all(c.isupper() for c in lettres)  # ligne en MAJUSCULES : en gras
                blocs.append(("fort" if fort else "texte", texte))
            paragraphe.clear()

    for ligne in modele.splitlines():
        ligne = ligne.strip()
        if ligne.startswith("## "):
            finir_paragraphe()
            blocs.append(("titre", ligne[3:].strip()))
        elif ligne.startswith("#"):
            continue  # commentaire
        elif ligne.startswith("- "):
            finir_paragraphe()
            blocs.append(("liste", ligne[2:].strip()))
        elif not ligne:
            finir_paragraphe()
        else:
            paragraphe.append(ligne)
    finir_paragraphe()
    resultat = []
    for genre, texte in blocs:
        # « [si x : texte] » : l'espace qui suit les deux-points est retiré, les autres sont gardées
        texte = CONDITION.sub(lambda m: m.group(2).removeprefix(" ") if valeurs.get(m.group(1)) else "", texte)
        texte = texte.format_map(_ValeursModele(valeurs)).strip()
        if texte:
            resultat.append((genre, texte))
    return resultat


class _PDFContrat(PDF):
    def __init__(self, numero: str):
        super().__init__()
        self.numero = numero
        self.set_margins(16, 12, 16)
        self.set_auto_page_break(True, margin=24)

    def footer(self):
        # Comme le contrat papier de l'agence : numéro de page dans un petit cadre en bas à droite
        self.texte(16, 283, f"Contrat N° {self.numero}", taille=7, couleur=GRIS)
        self.set_draw_color(*GRIS)
        self.set_line_width(0.2)
        self.rect(182, 279.5, 12, 9)
        self.texte(182, 282, str(self.page_no()), taille=10, couleur=ENCRE, style="B", largeur=12, align="C")


TAILLE_CONTRAT = 9.5


def _ecrire_contrat(pdf: PDF, texte: str, hauteur: float, align: str = "J", style: str = "") -> None:
    """Un paragraphe du modèle : **gras** et --souligné-- compris."""
    pdf.set_font("Montserrat", style, TAILLE_CONTRAT)
    pdf.set_text_color(*ENCRE)
    pdf.multi_cell(0, hauteur, texte, align=align, markdown=True)


def contrat_pdf(d: dict, modele: str) -> bytes:
    """Contrat de bail sur plusieurs pages, mis en page comme le contrat papier d'une agence cliente : logos de part
    et d'autre du titre encadré, articles soulignés, signatures « POUR LE BAILLEUR / POUR LE PRENEUR »."""
    pdf = _PDFContrat(d["numero_contrat"])
    pdf.set_title(f"Contrat de bail {d['numero_contrat']} — {ENTETE['nom']}")
    pdf.add_page()
    logo = logo_document()
    if logo:
        pdf.image(str(logo), x=16, y=9, w=28)
        pdf.image(str(logo), x=166, y=9, w=28)
    pdf.set_fill_color(235, 235, 235)
    pdf.set_draw_color(*GRIS)
    pdf.set_line_width(0.3)
    pdf.rect(70, 10, 70, 18, style="DF", round_corners=True, corner_radius=3)
    pdf.texte(70, 13.5, "CONTRAT DE BAIL", taille=11, style="B", largeur=70, align="C")
    pdf.texte(70, 21, d["titre_contrat"], taille=11, style="B", largeur=70, align="C")
    pdf.set_y(42)

    for genre, texte in remplir_modele(modele, d):
        if genre == "titre":
            if pdf.get_y() > 250:
                pdf.add_page()  # un titre n'est jamais seul en bas de page
            pdf.ln(1.5)
            m = re.match(r"(ARTICLE\s*\d+)\s*(.*)", texte, re.I)
            _ecrire_contrat(pdf, f"--**{m.group(1)}**--**{' ' + m.group(2) if m.group(2) else ''}**" if m
                            else f"**{texte}**", 6, align="L")
            pdf.ln(0.8)
        elif genre == "liste":
            pdf.set_font("Montserrat", "", TAILLE_CONTRAT)
            pdf.set_x(22)
            pdf.cell(5, 5, "•")
            _ecrire_contrat(pdf, texte, 5)
            pdf.ln(0.6)
        else:
            align = {"centre": "C", "droite": "R"}.get(genre, "J")
            # le gras vient seulement des **…** du modèle (« ENTRE : », « ET » restent maigres comme sur le papier)
            _ecrire_contrat(pdf, texte, 5.1, align=align)
            pdf.ln(2.2)

    # Signatures, comme sur le contrat papier
    if pdf.get_y() > 225:
        pdf.add_page()
    y = pdf.get_y() + 10
    pdf.set_font("Montserrat", "", TAILLE_CONTRAT)
    pdf.set_text_color(*ENCRE)
    pdf.set_xy(16, y)
    pdf.cell(80, 5, "--**POUR  LE  BAILLEUR**--", markdown=True)
    pdf.set_xy(124, y)
    pdf.cell(70, 5, "--**POUR  LE  PRENEUR**--", markdown=True)
    pdf.texte(16, y + 8, "P/O LE (LA) GÉRANT(E)", taille=TAILLE_CONTRAT)
    # Téléphones du gérant (Mon entreprise), un par ligne comme sur le contrat papier
    for i, numero in enumerate(n.strip() for n in ENTETE["telephones_gerant"].split("/") if n.strip()):
        if i < 3:
            pdf.texte(16, y + 15 + i * 6.5, numero, taille=TAILLE_CONTRAT, style="B")
    pdf.texte(16, y + 40, ENTETE["nom"].upper(), taille=TAILLE_CONTRAT, style="B")
    return bytes(pdf.output())
