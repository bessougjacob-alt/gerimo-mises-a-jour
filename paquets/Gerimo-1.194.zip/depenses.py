"""Étape 7 : dépenses par bien, et dépenses de fonctionnement de l'entreprise (sans bien, 06/10/2026).

Règles (vérifiées ici, côté serveur) :
- Admin, Caisse (tous les biens) et Gestionnaire (dans ses biens) ajoutent et modifient.
- Suppression : Admin et Caisse (règle du 03/10/2026 : la Caisse gère tout ce qui touche
  à l'argent), avec le mot de passe de la personne connectée redemandé.
- « À la charge de » : Propriétaire (dépense faite pour son compte, déduite de son reversement
  dans les rapports) ou Entreprise (l'entreprise cliente, « Mon entreprise »).
- Dépense de fonctionnement (loyer du bureau, salaires…) : sans bien, toujours à la charge de l'entreprise,
  saisie par l'Admin, la Caisse ou le Comptable (pas par un Gestionnaire).
- TVA comprise (facultative, pour la TVA déductible) et n° de justificatif.
- Période clôturée par l'Admin : plus d'ajout, de modification ni de suppression (periode.py).
"""
from datetime import date
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field, field_validator
from sqlalchemy.orm import Session as SessionDB, selectinload

import periode
import tresorerie
from commun import Formulaire, Suppression, Texte, charger, enregistrer, montant, supprimer
from models import (CATEGORIES_BIEN, CATEGORIES_DEPENSE, CATEGORIES_FONCTIONNEMENT, CHARGES_DEPENSE, MODES_PAIEMENT,
                    Cite, Depense, Logement, Utilisateur)
from securite import (cites_autorisees, exiger_module, get_db, utilisateur_connecte, verifier_cite_autorisee,
                      verifier_mot_de_passe)

router = APIRouter(prefix="/api")
acces_depenses = exiger_module("depenses")


ANCIEN_LIBELLE_ENTREPRISE = "ISUP" + " SARL"  # libellé d'avant le 13/10/2026 (téléphones pas encore à jour)


class DepenseIn(Formulaire):
    cite_id: int | None = None     # vide = dépense de fonctionnement de l'entreprise
    logement_id: int | None = None
    montant: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    motif: Texte = Field(min_length=1, max_length=200)
    categorie: Literal[CATEGORIES_DEPENSE] = "Autre"
    a_la_charge_de: Literal[CHARGES_DEPENSE] = "Propriétaire"
    mode_paiement: Literal[MODES_PAIEMENT] = "Espèce"

    @field_validator("a_la_charge_de", mode="before")
    @classmethod
    def ancien_libelle(cls, v):
        # saisies hors réseau faites avant le 13/10/2026 : l'entreprise y portait l'ancien libellé
        return "Entreprise" if v == ANCIEN_LIBELLE_ENTREPRISE else v
    date_depense: date
    compte_id: int | None = None   # trésorerie : vide = compte du mode de paiement
    montant_tva: Decimal = Field(Decimal(0), ge=0, max_digits=12, decimal_places=2)
    justificatif: Texte | None = Field(None, max_length=80)


def depense_json(d: Depense) -> dict:
    return {
        "id": d.id, "cite_id": d.cite_id, "bien": d.cite.nom if d.cite else "Fonctionnement de l'entreprise",
        "adresse": d.cite.adresse if d.cite else None, "fonctionnement": d.cite_id is None,
        "montant_tva": montant(d.montant_tva), "justificatif": d.justificatif or "",
        "logement_id": d.logement_id,
        "logement": f"Logement {d.logement.numero_logement}" if d.logement else None,
        "montant": montant(d.montant), "motif": d.motif, "categorie": d.categorie,
        "a_la_charge_de": d.a_la_charge_de, "mode_paiement": d.mode_paiement,
        "date_depense": d.date_depense.isoformat(), "compte_id": d.compte_id,
        "saisi_par": d.auteur.nom_complet if d.auteur else None,
    }


@router.get("/depenses/options")
def options(utilisateur: Utilisateur = Depends(acces_depenses), db: SessionDB = Depends(get_db)):
    autorisees = cites_autorisees(utilisateur)
    requete = db.query(Cite).options(selectinload(Cite.logements)).order_by(Cite.nom)
    if autorisees is not None:
        requete = requete.filter(Cite.id.in_(autorisees))
    return {
        "categories": CATEGORIES_DEPENSE, "categories_bien": CATEGORIES_BIEN,
        "categories_fonctionnement": CATEGORIES_FONCTIONNEMENT + ("Autre",),
        "fonctionnement_autorise": utilisateur.role.value != "Gestionnaire",
        "charges": CHARGES_DEPENSE, "modes_paiement": MODES_PAIEMENT,
        "biens": [{"id": c.id, "nom": c.nom,
                   "logements": [{"id": l.id, "numero": l.numero_logement} for l in c.logements]}
                  for c in requete],
    }


@router.get("/depenses")
def liste(utilisateur: Utilisateur = Depends(acces_depenses), db: SessionDB = Depends(get_db)):
    requete = db.query(Depense).options(selectinload(Depense.cite), selectinload(Depense.logement),
                                        selectinload(Depense.auteur))
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None:
        requete = requete.filter(Depense.cite_id.in_(autorisees))
    return [depense_json(d) for d in requete.order_by(Depense.date_depense.desc(), Depense.id.desc()).limit(500)]


def appliquer(db: SessionDB, utilisateur: Utilisateur, d: Depense, donnees: DepenseIn) -> None:
    if donnees.cite_id is None:
        if utilisateur.role.value == "Gestionnaire":
            raise HTTPException(status_code=403, detail="Les dépenses de fonctionnement de l'entreprise sont saisies "
                                                        "par l'Admin, la Caisse ou le Comptable.")
        donnees.logement_id, donnees.a_la_charge_de = None, "Entreprise"
    else:
        try:
            verifier_cite_autorisee(utilisateur, donnees.cite_id)
        except HTTPException:
            raise HTTPException(status_code=404, detail="Bien introuvable.")
        charger(db, Cite, donnees.cite_id, "Bien introuvable.")
    if donnees.montant_tva >= donnees.montant:
        raise HTTPException(status_code=400, detail="La TVA doit être inférieure au montant (TVA comprise).")
    periode.verifier_ouverte(db, donnees.date_depense, d.date_depense)
    if donnees.logement_id is not None:
        logement = charger(db, Logement, donnees.logement_id, "Logement introuvable.")
        if logement.cite_id != donnees.cite_id:
            raise HTTPException(status_code=400, detail="Ce logement n'appartient pas au bien choisi.")
    if donnees.date_depense > date.today():
        raise HTTPException(status_code=400, detail="La date de la dépense ne peut pas être dans le futur.")
    d.cite_id = donnees.cite_id
    d.logement_id = donnees.logement_id
    d.montant = donnees.montant
    d.motif = donnees.motif
    d.categorie = donnees.categorie
    d.a_la_charge_de = donnees.a_la_charge_de
    d.mode_paiement = donnees.mode_paiement
    d.date_depense = donnees.date_depense
    d.compte_id = tresorerie.verifier_compte_choisi(db, donnees.compte_id, donnees.mode_paiement)
    d.montant_tva, d.justificatif = donnees.montant_tva, donnees.justificatif or None


@router.post("/depenses")
def creer(donnees: DepenseIn, utilisateur: Utilisateur = Depends(acces_depenses), db: SessionDB = Depends(get_db)):
    d = Depense(saisi_par=utilisateur.id)
    appliquer(db, utilisateur, d, donnees)
    db.add(d)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": d.id}


@router.put("/depenses/{depense_id}")
def modifier(depense_id: int, donnees: DepenseIn, utilisateur: Utilisateur = Depends(acces_depenses),
             db: SessionDB = Depends(get_db)):
    d = charger(db, Depense, depense_id, "Dépense introuvable.")
    try:
        verifier_cite_autorisee(utilisateur, d.cite_id)  # dépense d'un autre bien : invisible
    except HTTPException:
        raise HTTPException(status_code=404, detail="Dépense introuvable.")
    appliquer(db, utilisateur, d, donnees)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": d.id}


@router.post("/depenses/{depense_id}/supprimer")
def supprimer_depense(depense_id: int, donnees: Suppression, utilisateur: Utilisateur = Depends(utilisateur_connecte),
                      db: SessionDB = Depends(get_db)):
    if utilisateur.role.value not in ("Admin", "Caisse"):
        raise HTTPException(status_code=403, detail="Suppression réservée à l'Admin et à la Caisse.")
    if not verifier_mot_de_passe(donnees.mot_de_passe_admin or "", utilisateur.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été supprimé.")
    d = charger(db, Depense, depense_id, "Dépense introuvable.")
    periode.verifier_ouverte(db, d.date_depense)
    return supprimer(db, d, "Suppression impossible.")
