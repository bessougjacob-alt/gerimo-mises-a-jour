"""Compte PostgreSQL à droits limités pour le logiciel.

À l'installation, Gérimo reçoit le mot de passe du compte « postgres » (super-administrateur : il peut tout faire
sur le PC, y compris lancer des programmes). Au premier démarrage, le serveur crée son propre compte
« gerimo_app », SANS ces pouvoirs : il possède seulement la base de Gérimo (tables, sauvegarde, restauration,
mises à jour). Le fichier .env est réécrit avec ce compte : le mot de passe « postgres » n'y reste pas.
Ainsi, même en cas de faille dans le logiciel, l'attaquant ne pourrait ni lancer de programme sur le PC, ni lire
ses fichiers, ni toucher aux autres bases.

Le mot de passe de gerimo_app est tiré au hasard (personne n'a besoin de le connaître).
"""
import secrets
from pathlib import Path

ROLE = "gerimo_app"


def _guillemets(valeur: str) -> str:
    return '"' + valeur.replace("\\", "\\\\").replace('"', '\\"') + '"'


def ecrire_env(chemin: Path, hote, port, base, utilisateur, mot_de_passe) -> None:
    provisoire = chemin.with_name(chemin.name + ".tmp")
    provisoire.write_text(f"DB_HOST={hote}\nDB_PORT={port}\nDB_NAME={base}\nDB_USER={utilisateur}\n"
                          f"DB_PASSWORD={_guillemets(mot_de_passe)}\n", encoding="utf-8")
    provisoire.replace(chemin)


def confier_la_base(c, role: str, base: str) -> None:
    """Donne au compte limité tout ce que contient la base (tables, séquences, types, fonctions).
    À relancer après une migration faite avec « postgres » : sinon les nouvelles tables lui appartiennent
    et le logiciel (sauvegarde comprise) n'a pas le droit de les lire."""
    from psycopg2 import sql
    r = sql.Identifier(role)
    c.execute(sql.SQL("ALTER DATABASE {} OWNER TO {}").format(sql.Identifier(base), r))
    c.execute(sql.SQL("ALTER SCHEMA public OWNER TO {}").format(r))
    # tout ce que contient la base passe au compte limité (tables, séquences, types, fonctions)
    c.execute("SELECT c.relname, c.relkind FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace "
              "WHERE n.nspname = 'public' AND c.relkind IN ('r', 'p', 'v', 'm', 'S') "
              "AND pg_get_userbyid(c.relowner) <> %s", (role,))
    for nom, genre in c.fetchall():
        if genre == "S":  # séquence rattachée à une table : suit sa table
            c.execute("SELECT 1 FROM pg_depend d JOIN pg_class s ON s.oid = d.objid "
                      "WHERE s.relname = %s AND d.deptype IN ('a', 'i')", (nom,))
            if c.fetchone():
                continue
        genre_sql = {"v": "VIEW", "m": "MATERIALIZED VIEW", "S": "SEQUENCE"}.get(genre, "TABLE")
        c.execute(sql.SQL("ALTER {} public.{} OWNER TO {}").format(sql.SQL(genre_sql), sql.Identifier(nom), r))
    c.execute("SELECT t.typname FROM pg_type t JOIN pg_namespace n ON n.oid = t.typnamespace "
              "WHERE n.nspname = 'public' AND t.typtype IN ('e', 'd') AND pg_get_userbyid(t.typowner) <> %s",
              (role,))
    for (nom,) in c.fetchall():
        c.execute(sql.SQL("ALTER TYPE public.{} OWNER TO {}").format(sql.Identifier(nom), r))
    c.execute("SELECT p.oid::regprocedure::text FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace "
              "WHERE n.nspname = 'public' AND pg_get_userbyid(p.proowner) <> %s", (role,))
    for (signature,) in c.fetchall():
        c.execute(sql.SQL("ALTER FUNCTION {} OWNER TO {}").format(sql.SQL(signature), r))


def passer_en_compte_limite(chemin_env: Path, role: str = ROLE) -> bool:
    """Si .env utilise un super-administrateur : crée le compte limité, lui confie la base, réécrit .env.
    Renvoie True si le changement a été fait (False s'il n'y avait rien à faire)."""
    import psycopg2
    from dotenv import dotenv_values
    from psycopg2 import sql
    env = dotenv_values(chemin_env)
    hote, port, base = env.get("DB_HOST") or "localhost", int(env.get("DB_PORT") or 5432), env.get("DB_NAME")
    admin = psycopg2.connect(host=hote, port=port, dbname=base, user=env.get("DB_USER"),
                             password=env.get("DB_PASSWORD"), connect_timeout=8)
    admin.autocommit = True
    try:
        with admin.cursor() as c:
            c.execute("SELECT rolsuper FROM pg_roles WHERE rolname = current_user")
            if not c.fetchone()[0]:
                return False  # déjà un compte limité
            mot_de_passe = secrets.token_urlsafe(24)
            c.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (role,))
            ordre = "ALTER ROLE {} WITH LOGIN NOSUPERUSER NOCREATEROLE NOCREATEDB PASSWORD %s" if c.fetchone() else \
                "CREATE ROLE {} WITH LOGIN NOSUPERUSER NOCREATEROLE NOCREATEDB PASSWORD %s"
            c.execute(sql.SQL(ordre).format(sql.Identifier(role)), (mot_de_passe,))
            confier_la_base(c, role, base)
    finally:
        admin.close()
    # le compte limité doit fonctionner AVANT d'oublier l'ancien
    essai = psycopg2.connect(host=hote, port=port, dbname=base, user=role, password=mot_de_passe, connect_timeout=8)
    essai.close()
    ecrire_env(chemin_env, hote, port, base, role, mot_de_passe)
    return True
