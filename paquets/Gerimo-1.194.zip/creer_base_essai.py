"""Base d'essai pour le développement : une COPIE de la vraie base, sur laquelle on peut tout casser.

Gérimo Serveur.exe travaille sur la vraie base « isup_erp ». Le dossier de développement (VS Code, demarrer.bat,
migrer.py) doit travailler sur sa copie « gerimo_essai » : ainsi un essai ou une nouvelle table en cours
de mise au point ne touche jamais les vraies données.

Lancement, dans le terminal :  python creer_base_essai.py
- copie la vraie base dans gerimo_essai (la vraie base est seulement LUE) ;
- si gerimo_essai existe déjà, demande confirmation avant de la remplacer (pour repartir des données du jour) ;
- branche le fichier .env du dossier de développement sur gerimo_essai (seule la ligne DB_NAME change).
"""
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

import psycopg2
from dotenv import dotenv_values
from psycopg2 import sql

import sauvegarde

RACINE = Path(__file__).parent
VRAIE_BASE = "isup_erp"
BASE_ESSAI = "gerimo_essai"


def main() -> None:
    chemin_env = RACINE / ".env"
    env = dotenv_values(chemin_env)
    hote, port = env.get("DB_HOST") or "localhost", str(env.get("DB_PORT") or 5432)
    utilisateur, mot_de_passe = env.get("DB_USER"), env.get("DB_PASSWORD") or ""

    admin = psycopg2.connect(host=hote, port=port, dbname="postgres", user=utilisateur, password=mot_de_passe)
    admin.autocommit = True
    with admin.cursor() as c:
        c.execute("SELECT 1 FROM pg_database WHERE datname = %s", (BASE_ESSAI,))
        if c.fetchone():
            reponse = input(f"La base d'essai « {BASE_ESSAI} » existe déjà. La remplacer par une copie des vraies "
                            f"données d'aujourd'hui ? Les essais faits dedans seront perdus. (oui/non) : ")
            if reponse.strip().lower() != "oui":
                print("Rien n'a été changé.")
                return
            c.execute(sql.SQL("DROP DATABASE {} WITH (FORCE)").format(sql.Identifier(BASE_ESSAI)))
        c.execute(sql.SQL("CREATE DATABASE {} ENCODING 'UTF8' TEMPLATE template0").format(sql.Identifier(BASE_ESSAI)))
    admin.close()

    variables = dict(os.environ, PGPASSWORD=mot_de_passe, PGCLIENTENCODING="UTF8")
    connexion = ["-h", hote, "-p", port, "-U", utilisateur]
    with tempfile.TemporaryDirectory() as dossier:
        copie = Path(dossier) / "copie.sql"
        print(f"Copie de la vraie base « {VRAIE_BASE} » (lecture seule)...")
        subprocess.run([sauvegarde.outil_postgres("pg_dump"), *connexion, "-d", VRAIE_BASE, "--no-owner",
                        "--encoding=UTF8", "-f", str(copie)], env=variables, check=True)
        print(f"Remplissage de la base d'essai « {BASE_ESSAI} »...")
        subprocess.run([sauvegarde.outil_postgres("psql"), *connexion, "-d", BASE_ESSAI, "-X", "-q",
                        "-v", "ON_ERROR_STOP=1", "-f", str(copie)], env=variables, check=True,
                       stdout=subprocess.DEVNULL)

    # seule la ligne DB_NAME du .env change (le mot de passe n'est ni lu à l'écran ni modifié)
    texte = chemin_env.read_text(encoding="utf-8")
    nouveau = re.sub(r"(?m)^DB_NAME=.*$", f"DB_NAME={BASE_ESSAI}", texte)
    if nouveau != texte:
        provisoire = chemin_env.with_name(".env.tmp")
        provisoire.write_text(nouveau, encoding="utf-8")
        provisoire.replace(chemin_env)
    print(f"✅ Base d'essai prête. Le dossier de développement travaille maintenant sur « {BASE_ESSAI} » ;"
          f" Gérimo Serveur garde la vraie base « {VRAIE_BASE} ».")


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError:
        sys.exit("❌ La copie a échoué (voir le message ci-dessus). La vraie base n'a pas été modifiée.")
