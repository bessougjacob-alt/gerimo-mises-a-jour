"""Carte de visite (« vCard ») à partir de la maquette PDF de l'entreprise, que l'Admin envoie (« Uploader vCard » :
PDF, ou .ai enregistré compatible PDF), adoptée par « Remplacer l'ancienne maquette ». Aucune maquette n'est livrée
avec le logiciel : tant que l'entreprise n'a pas envoyé la sienne, la carte de visite n'est pas disponible.

Seuls le nom/prénoms, la fonction et les téléphones changent ; tout le reste (logo, fond, QR code,
adresse, e-mail) est repris tel quel de la maquette. Sur la face « coordonnées » (celle qui porte les téléphones),
le nom est le plus gros texte et la fonction la ligne juste en dessous ; leur alignement (droite, gauche, centre)
est gardé. Le texte remplacé est réécrit en Montserrat, dans la graisse la plus proche de l'original.
- La FONCTION est celle de l'utilisateur connecté, fixée par l'Admin : elle n'est pas modifiable ici.
- Deux formats : « imprimeur » (recto + verso au format 85 × 55 mm avec 3 mm de fond perdu, ce que
  demandent les imprimeurs) et « planche » (10 cartes par feuille A4 avec traits de coupe, recto puis
  verso, pour une impression au bureau en recto-verso).
"""
import re
import shutil
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

import pymupdf
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import Response
from pydantic import Field
from sqlalchemy.orm import Session as SessionDB

import parametres
import recus
from commun import Email, Formulaire, NomPersonne, Telephone
from models import Utilisateur
from securite import exiger_admin, get_db, utilisateur_connecte
from whatsapp import numero_whatsapp

router = APIRouter(prefix="/api")

DOSSIER = Path(__file__).parent
MAQUETTES = DOSSIER / "documents" / "entreprise"   # maquette envoyée par l'Admin (gardée lors des mises à jour)
POLICES = DOSSIER / "static" / "fonts"
MM = 72 / 25.4
TELEPHONE = re.compile(r"^[\d\s.+()-]{8,}$")
TAILLE_MAX = 30_000_000   # un .ai d'Illustrator est souvent lourd


def maquette_active() -> Path:
    perso = MAQUETTES / "carte_visite.pdf"
    if not perso.exists():
        raise HTTPException(status_code=409, detail="Aucune maquette de carte de visite : l'Admin envoie d'abord celle "
                                                    "de l'entreprise (bouton « Uploader vCard »).")
    return perso


def maquette_proposee() -> Path:
    """Maquette envoyée par « Uploader vCard », pas encore adoptée."""
    return MAQUETTES / "carte_visite_proposee.pdf"


class CarteIn(Formulaire):
    nom: NomPersonne = Field(min_length=1, max_length=60)
    prenoms: NomPersonne = Field("", max_length=80)
    telephone1: Telephone = Field(min_length=8, max_length=30)
    telephone2: Telephone | None = Field(None, max_length=30)
    format: str = Field("imprimeur", pattern="^(imprimeur|planche)$")


class EnvoiCarte(CarteIn):
    destinataire: Email = Field(min_length=3, max_length=150)


def _couleur(entier: int) -> tuple[float, float, float]:
    return ((entier >> 16) & 255) / 255, ((entier >> 8) & 255) / 255, (entier & 255) / 255


def _police(nom_police: str) -> Path:
    """Montserrat de la graisse la plus proche de celle de la maquette."""
    n = nom_police.lower()
    for mot, graisse in (("semibold", "SemiBold"), ("extrabold", "Bold"), ("black", "Bold"), ("bold", "Bold"),
                         ("light", "Light"), ("thin", "Light"), ("medium", "Medium")):
        if mot in n:
            return POLICES / f"Montserrat-{graisse}.ttf"
    return POLICES / "Montserrat-Medium.ttf"


def _spans(page: pymupdf.Page) -> list[dict]:
    # moins de 3 caractères : lettres isolées des logos et slogans dessinés, ignorées
    return [s for b in page.get_text("dict")["blocks"] for l in b.get("lines", []) for s in l["spans"]
            if len(s["text"].strip()) >= 3]


def analyser(doc: pymupdf.Document) -> dict:
    """Repère sur la maquette la face « coordonnées », le nom, la fonction et les lignes de téléphone."""
    if not 1 <= doc.page_count <= 2:
        raise HTTPException(status_code=400, detail="La maquette doit avoir 1 ou 2 pages (recto et verso de la carte).")
    for numero, page in enumerate(doc):
        spans = _spans(page)
        tels = sorted((s for s in spans if TELEPHONE.match(s["text"].strip())), key=lambda s: s["origin"][1])
        autres = [s for s in spans if s not in tels and "@" not in s["text"]]
        if not tels or not autres:
            continue
        nom = max(autres, key=lambda s: (round(s["size"], 1), -s["origin"][1]))
        dessous = [s for s in autres if s is not nom and 0 < s["origin"][1] - nom["origin"][1] < 3 * nom["size"]
                   and s["bbox"][0] < nom["bbox"][2] and s["bbox"][2] > nom["bbox"][0]]
        fonction = min(dessous, key=lambda s: s["origin"][1]) if dessous else None
        return {"page_infos": numero, "page_logo": 1 - numero if doc.page_count == 2 else None,
                "nom": nom, "fonction": fonction, "tels": tels}
    raise HTTPException(status_code=400, detail=(
        "Maquette non reconnue : la face des coordonnées doit contenir le nom (le plus gros texte), la fonction "
        "juste en dessous et au moins un numéro de téléphone, écrits en texte (pas « vectorisés » / convertis en "
        "tracés dans Illustrator)."))


def _alignement(nom: dict, fonction: dict | None, page: pymupdf.Page) -> str:
    if fonction:
        g, d = abs(nom["bbox"][0] - fonction["bbox"][0]), abs(nom["bbox"][2] - fonction["bbox"][2])
        c = abs((nom["bbox"][0] + nom["bbox"][2]) - (fonction["bbox"][0] + fonction["bbox"][2])) / 2
        if min(g, d, c) < 2.5:
            return "gauche" if g <= min(d, c) else "droite" if d <= c else "centre"
    milieu, centre_carte = (nom["bbox"][0] + nom["bbox"][2]) / 2, (page.trimbox.x0 + page.trimbox.x1) / 2
    if abs(milieu - centre_carte) < 3:
        return "centre"
    return "droite" if milieu > page.trimbox.x0 + page.trimbox.width * 0.6 else "gauche"


def _personnaliser(doc: pymupdf.Document, nom: str, fonction: str, telephones: list[str]) -> dict:
    """Remplace nom, fonction et téléphones sur la face « coordonnées » de la maquette."""
    a = analyser(doc)
    page = doc[a["page_infos"]]
    span_nom, span_fonction, tels = a["nom"], a["fonction"], a["tels"]
    lignes_haut = [span_nom] + ([span_fonction] if span_fonction else [])
    alignement = _alignement(span_nom, span_fonction, page)
    gauche = min(s["bbox"][0] for s in lignes_haut)
    droite = max(s["bbox"][2] for s in lignes_haut)
    centre = (gauche + droite) / 2
    # place disponible : jusqu'au bord de la carte (3 mm de marge) ou jusqu'au trait vertical le plus proche
    bord_g, bord_d = page.trimbox.x0 + 3 * MM, page.trimbox.x1 - 3 * MM
    haut, bas = span_nom["bbox"][1], max(s["bbox"][3] for s in lignes_haut)
    for dessin in page.get_drawings():
        r = dessin["rect"]
        if r.width < 3 and r.height > 10 and r.y0 < bas and r.y1 > haut:
            if r.x1 <= gauche:
                bord_g = max(bord_g, r.x1 + 12)
            elif r.x0 >= droite:
                bord_d = min(bord_d, r.x0 - 12)

    for s in lignes_haut + tels:
        page.add_redact_annot(pymupdf.Rect(s["bbox"]))
    page.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE,
                          text=pymupdf.PDF_REDACT_TEXT_REMOVE)

    polices = {}

    def police_de(span: dict) -> tuple[str, pymupdf.Font]:
        fichier = _police(span["font"])
        if fichier not in polices:
            nom_interne = f"CV{len(polices)}"
            page.insert_font(fontname=nom_interne, fontfile=str(fichier))
            polices[fichier] = (nom_interne, pymupdf.Font(fontfile=str(fichier)))
        return polices[fichier]

    def ecrire(texte: str, span: dict) -> None:
        nom_interne, police = police_de(span)
        place = {"droite": droite - bord_g, "gauche": bord_d - gauche,
                 "centre": 2 * min(centre - bord_g, bord_d - centre)}[alignement]
        taille = span["size"]
        while police.text_length(texte, taille) > place and taille > 4:
            taille -= 0.25  # nom long : on réduit un peu plutôt que de déborder
        largeur = police.text_length(texte, taille)
        x = {"droite": droite - largeur, "gauche": gauche, "centre": centre - largeur / 2}[alignement]
        page.insert_text((x, span["origin"][1]), texte, fontname=nom_interne, fontsize=taille,
                         color=_couleur(span["color"]))

    ecrire(nom.upper(), span_nom)
    if span_fonction and fonction:
        ecrire(fonction.upper(), span_fonction)
    for span, numero in zip(tels, telephones):
        nom_interne, _ = police_de(span)
        page.insert_text(span["origin"], numero, fontname=nom_interne, fontsize=span["size"],
                         color=_couleur(span["color"]))
    return a


def format_telephone(numero: str) -> str:
    """« 0749622566 » → « 07 49 62 25 66 » (sinon laissé tel quel)."""
    chiffres = re.sub(r"\D", "", numero)
    if len(chiffres) == 13 and chiffres.startswith("225"):
        chiffres = chiffres[3:]
    if len(chiffres) == 10:
        return " ".join(chiffres[i:i + 2] for i in range(0, 10, 2))
    return numero.strip()


def _carte(d: CarteIn, fonction: str, maquette: Path | None = None) -> tuple[pymupdf.Document, dict]:
    maquette = maquette or maquette_active()
    if not maquette.exists():
        raise HTTPException(status_code=500, detail="Maquette de la carte introuvable : envoyez-en une (« Uploader vCard »).")
    doc = pymupdf.open(maquette)
    nom = " ".join(x for x in (d.nom, d.prenoms) if x)
    telephones = [format_telephone(t) for t in (d.telephone1, d.telephone2) if t]
    return doc, _personnaliser(doc, nom, fonction, telephones)


def pdf_imprimeur(doc: pymupdf.Document, a: dict, nom: str) -> bytes:
    """Recto (coordonnées) puis verso (logo), 91 × 61 mm dont 3 mm de fond perdu."""
    sortie = pymupdf.open()
    for numero in (a["page_infos"], a["page_logo"]):
        if numero is not None:
            sortie.insert_pdf(doc, from_page=numero, to_page=numero)
    sortie.set_metadata({"title": f"Carte de visite — {nom}", "author": recus.ENTETE["nom"],
                         "subject": "85 x 55 mm, fond perdu 3 mm, recto (coordonnées) + verso (logo)"})
    return sortie.tobytes(garbage=3, deflate=True)


def pdf_planche(doc: pymupdf.Document, a: dict, nom: str) -> bytes:
    """10 cartes par A4 (2 × 5), traits de coupe ; page 2 = versos placés pour le recto-verso."""
    sortie = pymupdf.open()
    largeur, hauteur = 85 * MM, 55 * MM
    x0 = (pymupdf.paper_size("a4")[0] - 2 * largeur) / 2
    y0 = (pymupdf.paper_size("a4")[1] - 5 * hauteur) / 2
    coupe = doc[a["page_infos"]].trimbox
    faces = [(a["page_infos"], False)] + ([(a["page_logo"], True)] if a["page_logo"] is not None else [])
    for numero_page, miroir in faces:
        page = sortie.new_page(width=pymupdf.paper_size("a4")[0], height=pymupdf.paper_size("a4")[1])
        for ligne in range(5):
            for col in range(2):
                colonne = 1 - col if miroir else col  # verso : colonnes inversées (retournement grand côté)
                rect = pymupdf.Rect(x0 + colonne * largeur, y0 + ligne * hauteur,
                                    x0 + (colonne + 1) * largeur, y0 + (ligne + 1) * hauteur)
                page.show_pdf_page(rect, doc, numero_page, clip=coupe)
        # traits de coupe à l'extérieur des cartes
        gris = (0.45, 0.45, 0.45)
        for i in range(3):
            x = x0 + i * largeur
            page.draw_line((x, y0 - 8 * MM), (x, y0 - 2 * MM), color=gris, width=0.3)
            page.draw_line((x, y0 + 5 * hauteur + 2 * MM), (x, y0 + 5 * hauteur + 8 * MM), color=gris, width=0.3)
        for j in range(6):
            y = y0 + j * hauteur
            page.draw_line((x0 - 8 * MM, y), (x0 - 2 * MM, y), color=gris, width=0.3)
            page.draw_line((x0 + 2 * largeur + 2 * MM, y), (x0 + 2 * largeur + 8 * MM, y), color=gris, width=0.3)
        page.insert_text((x0, 7 * MM), f"Cartes de visite — {nom} — {'recto' if not miroir else 'verso'} — "
                                       "imprimer en recto-verso, taille réelle (100 %), retournement grand côté",
                         fontsize=6.5, color=gris)
    sortie.set_metadata({"title": f"Planche de cartes de visite — {nom}", "author": "Gérimo"})
    return sortie.tobytes(garbage=3, deflate=True)


def fabriquer(d: CarteIn, u: Utilisateur) -> tuple[bytes, str]:
    doc, a = _carte(d, parametres.fonction_de(u))
    nom = " ".join(x for x in (d.nom, d.prenoms) if x)
    contenu = pdf_planche(doc, a, nom) if d.format == "planche" else pdf_imprimeur(doc, a, nom)
    fichier = re.sub(r"[^A-Za-z0-9]+", "_", f"Carte_visite_{nom}").strip("_") + \
        ("_planche_A4" if d.format == "planche" else "") + ".pdf"
    return contenu, fichier


def v_nom(db) -> str:
    return parametres.lire(db, "entreprise_nom")


@router.get("/carte-visite")
def infos(u: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    """Valeurs proposées dans le formulaire ; la fonction est imposée."""
    morceaux = u.nom_complet.split()
    prenoms = morceaux[1:]
    # « GOME JACOB » → « G. Jacob » (comme sur la maquette) : prénoms intermédiaires en initiale
    abrege = " ".join([p[0].upper() + "." for p in prenoms[:-1]] + [p.capitalize() for p in prenoms[-1:]])
    v = parametres.tous(db)
    return {"nom": morceaux[0] if morceaux else "", "prenoms": abrege,
            "fonction": parametres.fonction_de(u), "telephone1": v["whatsapp_numero"], "telephone2": "",
            "email_imprimeur": v["email_imprimeur"], "whatsapp_imprimeur": v["whatsapp_imprimeur"],
            "email_configure": bool(v["smtp_serveur"] and v["smtp_utilisateur"]),
            "maquette_proposee": u.role.value == "Admin" and maquette_proposee().exists(),
            "maquette": (MAQUETTES / "carte_visite.pdf").exists()}


@router.post("/carte-visite/pdf")
def pdf(d: CarteIn, u: Utilisateur = Depends(utilisateur_connecte)):
    contenu, fichier = fabriquer(d, u)
    return Response(contenu, media_type="application/pdf", headers={"Content-Disposition": f'inline; filename="{fichier}"'})


@router.post("/carte-visite/apercu")
def apercu(d: CarteIn, proposee: bool = False, u: Utilisateur = Depends(utilisateur_connecte)):
    """Image du recto pour l'aperçu à l'écran ; « proposee » : la maquette envoyée, pas encore adoptée (Admin)."""
    if proposee:
        if u.role.value != "Admin":
            raise HTTPException(status_code=403, detail="Action réservée à l'administrateur.")
        if not maquette_proposee().exists():
            raise HTTPException(status_code=404, detail="Aucune nouvelle maquette envoyée.")
    doc, a = _carte(d, parametres.fonction_de(u), maquette_proposee() if proposee else None)
    page = doc[a["page_infos"]]
    image = page.get_pixmap(dpi=220, clip=page.trimbox).tobytes("png")
    return Response(image, media_type="image/png", headers={"Cache-Control": "no-store"})


# ---------- Maquette (Admin) : « Uploader vCard », puis « Remplacer l'ancienne maquette » ----------

@router.post("/carte-visite/maquette")
async def envoyer_maquette(request: Request, admin: Utilisateur = Depends(exiger_admin)):
    """Reçoit une nouvelle maquette et vérifie qu'elle est utilisable ; elle n'est adoptée qu'après l'aperçu."""
    contenu = b""
    async for morceau in request.stream():
        contenu += morceau
        if len(contenu) > TAILLE_MAX:
            raise HTTPException(status_code=413, detail="Fichier trop lourd (30 Mo maximum).")
    if contenu.startswith(b"%!PS"):
        raise HTTPException(status_code=400, detail=(
            "Ce fichier Illustrator n'est pas compatible PDF. Dans Illustrator : Fichier → Enregistrer une copie → "
            "Adobe PDF, puis envoyez ce PDF."))
    if b"%PDF" not in contenu[:1024]:
        raise HTTPException(status_code=400, detail="La maquette doit être un fichier PDF (ou un .ai compatible PDF).")
    try:
        doc = pymupdf.open(stream=contenu, filetype="pdf")
    except Exception:
        raise HTTPException(status_code=400, detail="Fichier PDF illisible ou abîmé.")
    a = analyser(doc)
    MAQUETTES.mkdir(parents=True, exist_ok=True)
    maquette_proposee().write_bytes(contenu)
    return {"ok": True, "recto_verso": a["page_logo"] is not None, "fonction": a["fonction"] is not None,
            "telephones": len(a["tels"])}


@router.post("/carte-visite/maquette/remplacer")
def remplacer_maquette(admin: Utilisateur = Depends(exiger_admin)):
    """Adopte la maquette envoyée. L'ancienne, si elle avait été envoyée, est rangée dans
    documents/entreprise/anciennes (rien n'est détruit) ; celle d'origine reste dans modeles/."""
    nouvelle = maquette_proposee()
    if not nouvelle.exists():
        raise HTTPException(status_code=404, detail="Envoyez d'abord la nouvelle maquette (« Uploader vCard »).")
    actuelle = MAQUETTES / "carte_visite.pdf"
    if actuelle.exists():
        rangement = MAQUETTES / "anciennes"
        rangement.mkdir(exist_ok=True)
        shutil.move(actuelle, rangement / f"carte_visite_{datetime.now():%Y%m%d_%H%M%S}.pdf")
    nouvelle.replace(actuelle)
    return {"ok": True}


@router.post("/carte-visite/envoyer-email")
def envoyer_email(d: EnvoiCarte, u: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    contenu, fichier = fabriquer(CarteIn(**d.model_dump(exclude={"destinataire"}) | {"format": "imprimeur"}), u)
    nom = " ".join(x for x in (d.nom, d.prenoms) if x)
    parametres.envoyer_email(
        db, d.destinataire, f"Impression de cartes de visite — {nom} — {v_nom(db)}",
        f"Bonjour,\n\nVeuillez trouver ci-joint le fichier d'impression de la carte de visite de {nom} ({v_nom(db)}).\n"
        "Format : 85 × 55 mm, fond perdu 3 mm inclus, recto (coordonnées) + verso (logo).\n"
        "Merci de nous indiquer le délai et le prix pour la quantité souhaitée.\n\n"
        f"Cordialement,\n{u.nom_complet}\n{v_nom(db)} — {parametres.lire(db, 'whatsapp_numero')}",
        [(fichier, contenu, "application/pdf")])
    return {"ok": True}


@router.post("/carte-visite/whatsapp")
def whatsapp(d: CarteIn, u: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    nom = " ".join(x for x in (d.nom, d.prenoms) if x)
    numero = numero_whatsapp(parametres.lire(db, "whatsapp_imprimeur"))
    texte = quote(f"Bonjour, je vous envoie le fichier PDF d'impression de la carte de visite de {nom} ({v_nom(db)}) : "
                  "85 × 55 mm, fond perdu 3 mm, recto-verso. Merci de m'indiquer le prix et le délai. "
                  f"— {u.nom_complet}, le {datetime.now().strftime('%d/%m/%Y')}")
    return {"lien": f"https://wa.me/{numero}?text={texte}" if numero else f"https://wa.me/?text={texte}",
            "a_numero": bool(numero)}
