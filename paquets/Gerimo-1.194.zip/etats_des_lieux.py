"""États des lieux d'entrée et de sortie.

Déroulé (bonnes pratiques de la gestion locative) :
1. Le gestionnaire crée l'état des lieux d'un contrat : la grille des pièces est proposée selon
   le type de logement (studio, 2 à 8 pièces, villa, magasin) ; pour une SORTIE, l'état noté à
   l'entrée est rappelé en face de chaque élément, et les dégradations sont repérées.
2. Il note l'état de chaque élément, les compteurs (CIE, SODECI), les clés, et ajoute des photos
   (appareil photo de la tablette / du téléphone, ou fichiers).
3. Le locataire et l'agent ISUP signent à l'écran (doigt ou souris). L'état des lieux est alors
   VERROUILLÉ (plus aucune modification) et le PDF signé est enregistré.
4. Une copie signée est envoyée au locataire : e-mail (pièce jointe) ou WhatsApp.

Droits : Admin et Gestionnaire (ses biens). Suppression : Admin, mot de passe redemandé.
"""
import base64
import io
import re
from datetime import date, datetime
from decimal import Decimal
from typing import Literal
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from PIL import Image, UnidentifiedImageError
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session as SessionDB, selectinload

import documents_pdf
import fichiers
import parametres
import recus
from commun import Email, Formulaire, Paragraphe, Suppression, Texte, charger, montant, numero_suivant
from contrats import charger_contrat
from models import Contrat, EtatDesLieux, Logement, PhotoEdl, Utilisateur, STATUTS_EN_COURS, TYPES_EDL
from securite import (cites_autorisees, confirmer_mot_de_passe_admin, exiger_admin, exiger_module, get_db)
from whatsapp import numero_whatsapp

router = APIRouter(prefix="/api")
acces_edl = exiger_module("etats_des_lieux")

ETATS = ("Neuf", "Bon état", "État d'usage", "Mauvais état", "Hors service", "Absent / sans objet")
# Du meilleur au pire : sert à repérer une dégradation entre l'entrée et la sortie
RANG_ETAT = {"Neuf": 0, "Bon état": 1, "État d'usage": 2, "Mauvais état": 3, "Hors service": 4}

ELEMENTS_COMMUNS = ("Murs et peinture", "Plafond", "Sol / carrelage", "Porte et serrure",
                    "Fenêtres, vitres et grilles", "Prises et interrupteurs", "Éclairage")
ELEMENTS_PAR_PIECE = {
    "Salon": ELEMENTS_COMMUNS + ("Ventilateur / climatiseur",),
    "Chambre": ELEMENTS_COMMUNS + ("Placard",),
    "Cuisine": ELEMENTS_COMMUNS + ("Évier et robinetterie", "Paillasse / plan de travail", "Placards"),
    "Douche / WC": ("Murs et carrelage mural", "Sol / carrelage", "Porte et serrure", "WC (cuvette, chasse d'eau)",
                    "Lavabo", "Douche et robinetterie", "Évacuations", "Éclairage"),
    "Pièce principale": ELEMENTS_COMMUNS + ("Placard",),
    "Couloir / entrée": ("Murs et peinture", "Sol / carrelage", "Éclairage"),
    "Extérieur (cour, terrasse, portail)": ("Portail / clôture", "Cour / terrasse", "Gouttières", "Éclairage extérieur"),
    "Espace de vente": ELEMENTS_COMMUNS + ("Rideau métallique / devanture",),
    "Arrière-boutique / réserve": ELEMENTS_COMMUNS,
}


def pieces_proposees(type_logement: str) -> list[str]:
    """Pièces habituelles selon le type de logement (libellés officiels)."""
    if type_logement == "Magasin":
        return ["Espace de vente", "Arrière-boutique / réserve", "Douche / WC"]
    if type_logement in ("Studio", "À préciser"):  # type inconnu : pièces de base, à compléter
        return ["Pièce principale", "Cuisine", "Douche / WC", "Extérieur (cour, terrasse, portail)"]
    nb = 9 if type_logement.startswith("Villa") else int(type_logement.split()[0])
    pieces = ["Salon"] + [f"Chambre {i}" for i in range(1, nb)]
    pieces += ["Cuisine", "Douche / WC"] + (["Douche / WC 2"] if nb >= 4 else [])
    return pieces + ["Couloir / entrée", "Extérieur (cour, terrasse, portail)"]


def elements_de(piece: str) -> tuple[str, ...]:
    for modele, elements in ELEMENTS_PAR_PIECE.items():
        if piece == modele or piece.startswith(modele.split(" /")[0]):
            return elements
    return ELEMENTS_COMMUNS


def grille(type_logement: str) -> list[dict]:
    return [{"piece": p, "elements": [{"element": e, "etat": "Bon état", "observation": ""} for e in elements_de(p)]}
            for p in pieces_proposees(type_logement)]


# ---------- Données reçues ----------

class ElementIn(Formulaire):
    element: Texte = Field(min_length=1, max_length=80)
    etat: Literal[ETATS] = "Bon état"
    observation: Texte = Field("", max_length=300)
    etat_entree: str | None = Field(None, max_length=30)  # rappel (sortie)


class PieceIn(Formulaire):
    piece: Texte = Field(min_length=1, max_length=80)
    elements: list[ElementIn] = Field(default_factory=list, max_length=40)


class CompteurIn(Formulaire):
    numero: Texte = Field("", max_length=40)
    index: Texte = Field("", max_length=40)


class EdlIn(Formulaire):
    contrat_id: int
    type_edl: Literal[TYPES_EDL]
    date_edl: date | None = None
    pieces: list[PieceIn] = Field(default_factory=list, max_length=30)
    compteur_electricite: CompteurIn = Field(default_factory=CompteurIn)
    compteur_eau: CompteurIn = Field(default_factory=CompteurIn)
    nb_cles: int = Field(0, ge=0, le=50)
    observations: Paragraphe = Field("", max_length=3000)
    retenues: Decimal = Field(Decimal(0), ge=0, max_digits=12, decimal_places=2)


class PhotoIn(BaseModel):
    piece: str | None = Field(None, max_length=80)
    legende: str | None = Field(None, max_length=200)
    contenu: str


class SignatureIn(BaseModel):
    signature_locataire: str
    signature_agent: str


class EnvoiEmail(Formulaire):
    destinataire: Email = Field(min_length=3, max_length=150)


# ---------- Outils ----------

def charger_edl(db: SessionDB, utilisateur: Utilisateur, edl_id: int) -> EtatDesLieux:
    edl = charger(db, EtatDesLieux, edl_id, "État des lieux introuvable.")
    try:
        charger_contrat(db, utilisateur, edl.contrat_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="État des lieux introuvable.")
    return edl


def exiger_brouillon(edl: EtatDesLieux) -> None:
    if edl.statut == "Signé":
        raise HTTPException(status_code=409, detail="Cet état des lieux est signé : il ne peut plus être modifié.")


def edl_entree(db: SessionDB, contrat_id: int) -> EtatDesLieux | None:
    return db.query(EtatDesLieux).filter_by(contrat_id=contrat_id, type_edl="Entrée").first()


def rangs_entree(entree: EtatDesLieux | None) -> dict:
    """{(pièce, élément): état à l'entrée}."""
    if entree is None:
        return {}
    return {(p["piece"], e["element"]): e["etat"] for p in entree.pieces for e in p.get("elements", [])}


def degradations(edl: EtatDesLieux, entree: EtatDesLieux | None) -> list[dict]:
    """Sortie : éléments dont l'état s'est dégradé depuis l'entrée."""
    if edl.type_edl != "Sortie":
        return []
    avant = rangs_entree(entree)
    resultat = []
    for p in edl.pieces:
        for e in p.get("elements", []):
            etat_entree = avant.get((p["piece"], e["element"])) or e.get("etat_entree")
            if etat_entree in RANG_ETAT and e["etat"] in RANG_ETAT and RANG_ETAT[e["etat"]] > RANG_ETAT[etat_entree]:
                resultat.append({"piece": p["piece"], "element": e["element"], "entree": etat_entree,
                                 "sortie": e["etat"], "observation": e.get("observation", "")})
    return resultat


def edl_json(edl: EtatDesLieux, db: SessionDB, complet: bool = False) -> dict:
    c = edl.contrat
    donnees = {
        "id": edl.id, "numero": edl.numero, "type_edl": edl.type_edl, "statut": edl.statut,
        "date_edl": edl.date_edl.isoformat(), "contrat_id": c.id, "numero_contrat": c.numero_contrat,
        "locataire": c.locataire.nom_complet, "telephone": c.locataire.telephone, "email": c.locataire.email,
        "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}",
        "nb_photos": len(edl.photos), "envoye_le": edl.envoye_le.strftime("%d/%m/%Y") if edl.envoye_le else None,
        "signe_le": edl.signe_le.strftime("%d/%m/%Y à %H:%M") if edl.signe_le else None,
    }
    if complet:
        entree = edl_entree(db, c.id) if edl.type_edl == "Sortie" else None
        donnees.update({
            "pieces": edl.pieces, "compteurs": edl.compteurs, "nb_cles": edl.nb_cles,
            "observations": edl.observations or "", "retenues": montant(edl.retenues),
            "caution": montant(c.montant_caution),
            "photos": [{"id": p.id, "piece": p.piece, "legende": p.legende,
                        "url": f"/api/etats-des-lieux/photos/{p.id}"} for p in edl.photos],
            "degradations": degradations(edl, entree),
        })
    return donnees


def contrats_visibles(db: SessionDB, utilisateur: Utilisateur):
    requete = db.query(Contrat).join(Logement).options(
        selectinload(Contrat.locataire), selectinload(Contrat.logement).selectinload(Logement.cite))
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None:
        requete = requete.filter(Logement.cite_id.in_(autorisees))
    return requete.order_by(Contrat.numero_contrat.desc()).all()


# ---------- Listes ----------

@router.get("/etats-des-lieux")
def liste(utilisateur: Utilisateur = Depends(acces_edl), db: SessionDB = Depends(get_db)):
    contrats = contrats_visibles(db, utilisateur)
    ids = [c.id for c in contrats]
    edls = db.query(EtatDesLieux).options(selectinload(EtatDesLieux.photos)).filter(
        EtatDesLieux.contrat_id.in_(ids)).order_by(EtatDesLieux.date_edl.desc(), EtatDesLieux.id.desc()).all() if ids else []
    faits = {(e.contrat_id, e.type_edl) for e in edls}
    a_faire = []
    for c in contrats:
        logement = f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}"
        depart_proche = (c.statut_contrat in STATUTS_EN_COURS and c.date_depart is not None
                         and (c.date_depart - date.today()).days <= 7)
        if depart_proche and (c.id, "Sortie") not in faits:  # le locataire s'en va : la sortie passe avant
            a_faire.append({"contrat_id": c.id, "type_edl": "Sortie", "locataire": c.locataire.nom_complet,
                            "logement": logement, "numero_contrat": c.numero_contrat,
                            "raison": f"Départ prévu le {c.date_depart.strftime('%d/%m/%Y')}"})
        elif c.statut_contrat in STATUTS_EN_COURS and not depart_proche and (c.id, "Entrée") not in faits:
            a_faire.append({"contrat_id": c.id, "type_edl": "Entrée", "locataire": c.locataire.nom_complet,
                            "logement": logement, "numero_contrat": c.numero_contrat,
                            "raison": f"Contrat du {c.date_debut.strftime('%d/%m/%Y')} sans état des lieux d'entrée"})
        elif c.statut_contrat in ("Résilié", "Expiré") and (c.id, "Sortie") not in faits:
            a_faire.append({"contrat_id": c.id, "type_edl": "Sortie", "locataire": c.locataire.nom_complet,
                            "logement": logement, "numero_contrat": c.numero_contrat,
                            "raison": f"Contrat {c.statut_contrat.lower()} sans état des lieux de sortie"})
    return {"etats": [edl_json(e, db) for e in edls], "a_faire": a_faire,
            "brouillons": sum(1 for e in edls if e.statut == "Brouillon")}


@router.get("/etats-des-lieux/options")
def options(utilisateur: Utilisateur = Depends(acces_edl), db: SessionDB = Depends(get_db)):
    contrats = contrats_visibles(db, utilisateur)
    return {
        "etats": ETATS, "types": TYPES_EDL,
        "pieces_types": list(ELEMENTS_PAR_PIECE), "elements_communs": ELEMENTS_COMMUNS,
        "contrats": [{"id": c.id, "numero_contrat": c.numero_contrat, "statut_contrat": c.statut_contrat,
                      "locataire": c.locataire.nom_complet, "type_logement": c.logement.type_logement,
                      "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}"}
                     for c in contrats],
    }


@router.get("/etats-des-lieux/modele")
def modele(contrat_id: int, type_edl: Literal[TYPES_EDL], utilisateur: Utilisateur = Depends(acces_edl),
           db: SessionDB = Depends(get_db)):
    """Grille pré-remplie : selon le logement (entrée) ou reprise de l'entrée (sortie)."""
    c = charger_contrat(db, utilisateur, contrat_id)
    if type_edl == "Sortie":
        entree = edl_entree(db, c.id)
        if entree is not None:
            pieces = [{"piece": p["piece"], "elements": [
                {"element": e["element"], "etat": e["etat"], "observation": "", "etat_entree": e["etat"]}
                for e in p.get("elements", [])]} for p in entree.pieces]
            return {"pieces": pieces, "compteurs": {}, "nb_cles": entree.nb_cles, "depuis_entree": True,
                    "caution": montant(c.montant_caution)}
    return {"pieces": grille(c.logement.type_logement), "compteurs": {}, "nb_cles": 2, "depuis_entree": False,
            "caution": montant(c.montant_caution)}


# ---------- Créer, modifier ----------

def appliquer(edl: EtatDesLieux, d: EdlIn) -> None:
    edl.date_edl = d.date_edl or date.today()
    edl.pieces = [p.model_dump() for p in d.pieces]
    edl.compteurs = {"electricite": d.compteur_electricite.model_dump(), "eau": d.compteur_eau.model_dump()}
    edl.nb_cles = d.nb_cles
    edl.observations = d.observations or None
    edl.retenues = d.retenues if d.type_edl == "Sortie" else Decimal(0)
    edl.modifie_le = datetime.now()


@router.post("/etats-des-lieux")
def creer(d: EdlIn, utilisateur: Utilisateur = Depends(acces_edl), db: SessionDB = Depends(get_db)):
    c = charger_contrat(db, utilisateur, d.contrat_id)
    if db.query(EtatDesLieux).filter_by(contrat_id=c.id, type_edl=d.type_edl).first():
        raise HTTPException(status_code=409, detail=f"Ce contrat a déjà un état des lieux de {d.type_edl.lower()}.")
    if d.date_edl and d.date_edl > date.today():
        raise HTTPException(status_code=400, detail="La date de l'état des lieux ne peut pas être dans le futur.")
    if d.type_edl == "Sortie" and d.retenues > (c.montant_caution or 0):
        raise HTTPException(status_code=400, detail="Les retenues ne peuvent pas dépasser la caution versée.")
    edl = EtatDesLieux(numero=numero_suivant(db, EtatDesLieux.numero, f"EDL-{date.today().year}", 4),
                       contrat_id=c.id, type_edl=d.type_edl, cree_par=utilisateur.id, statut="Brouillon")
    appliquer(edl, d)
    db.add(edl)
    db.commit()
    return {"id": edl.id, "numero": edl.numero}


@router.get("/etats-des-lieux/{edl_id}")
def detail(edl_id: int, utilisateur: Utilisateur = Depends(acces_edl), db: SessionDB = Depends(get_db)):
    return edl_json(charger_edl(db, utilisateur, edl_id), db, complet=True)


@router.put("/etats-des-lieux/{edl_id}")
def modifier(edl_id: int, d: EdlIn, utilisateur: Utilisateur = Depends(acces_edl), db: SessionDB = Depends(get_db)):
    edl = charger_edl(db, utilisateur, edl_id)
    exiger_brouillon(edl)
    if d.contrat_id != edl.contrat_id or d.type_edl != edl.type_edl:
        raise HTTPException(status_code=400, detail="Le contrat et le type ne peuvent pas changer.")
    if d.date_edl and d.date_edl > date.today():
        raise HTTPException(status_code=400, detail="La date de l'état des lieux ne peut pas être dans le futur.")
    if d.type_edl == "Sortie" and d.retenues > (edl.contrat.montant_caution or 0):
        raise HTTPException(status_code=400, detail="Les retenues ne peuvent pas dépasser la caution versée.")
    appliquer(edl, d)
    db.commit()
    return {"id": edl.id}


# ---------- Photos ----------

@router.post("/etats-des-lieux/{edl_id}/photos")
def ajouter_photo(edl_id: int, d: PhotoIn, utilisateur: Utilisateur = Depends(acces_edl),
                  db: SessionDB = Depends(get_db)):
    edl = charger_edl(db, utilisateur, edl_id)
    exiger_brouillon(edl)
    if len(edl.photos) >= 120:
        raise HTTPException(status_code=409, detail="120 photos maximum par état des lieux.")
    relatif, _, _ = fichiers.enregistrer_fichier(d.contenu, f"etats_des_lieux/{edl.numero}",
                                                 pdf_autorise=False, cote_max=1600)
    photo = PhotoEdl(etat_des_lieux_id=edl.id, chemin_fichier=relatif,
                     piece=(d.piece or "").strip()[:80] or None,
                     legende=re.sub(r"[<>{}`\\]", "", d.legende or "").strip()[:200] or None)
    db.add(photo)
    db.commit()
    return {"id": photo.id, "piece": photo.piece, "legende": photo.legende,
            "url": f"/api/etats-des-lieux/photos/{photo.id}"}


@router.get("/etats-des-lieux/photos/{photo_id}")
def voir_photo(photo_id: int, utilisateur: Utilisateur = Depends(acces_edl), db: SessionDB = Depends(get_db)):
    photo = charger(db, PhotoEdl, photo_id, "Photo introuvable.")
    charger_edl(db, utilisateur, photo.etat_des_lieux_id)
    return fichiers.servir(photo.chemin_fichier, type_mime="image/jpeg")


@router.post("/etats-des-lieux/photos/{photo_id}/retirer")
def retirer_photo(photo_id: int, utilisateur: Utilisateur = Depends(acces_edl), db: SessionDB = Depends(get_db)):
    """Retirer une photo d'un BROUILLON (après signature, plus rien ne bouge)."""
    photo = charger(db, PhotoEdl, photo_id, "Photo introuvable.")
    edl = charger_edl(db, utilisateur, photo.etat_des_lieux_id)
    exiger_brouillon(edl)
    chemin = photo.chemin_fichier
    db.delete(photo)
    db.commit()
    fichiers.effacer(chemin)
    return {"ok": True}


# ---------- Signature et PDF ----------

def signature_png(data_url: str) -> str:
    """Contrôle la signature dessinée (vraie image PNG, pas vide) et la renvoie en data URL propre."""
    type_mime, octets = fichiers.decoder(data_url)
    if type_mime != "image/png" or len(octets) > 600_000:
        raise HTTPException(status_code=400, detail="Signature illisible.")
    try:
        image = Image.open(io.BytesIO(octets))
        image.load()
    except (UnidentifiedImageError, OSError):
        raise HTTPException(status_code=400, detail="Signature illisible.")
    # zone réellement dessinée : pixels foncés (fond transparent ou blanc ignoré)
    fond = Image.new("RGBA", image.size, (255, 255, 255, 255))
    fond.alpha_composite(image.convert("RGBA"))
    boite = fond.convert("L").point(lambda v: 255 if v < 200 else 0).getbbox()
    if boite is None or (boite[2] - boite[0]) < 25:
        raise HTTPException(status_code=400, detail="Chaque partie doit signer dans son cadre.")
    image = image.crop(boite)
    sortie = io.BytesIO()
    image.save(sortie, "PNG", optimize=True)
    return "data:image/png;base64," + base64.b64encode(sortie.getvalue()).decode()


def donnees_pdf(db: SessionDB, edl: EtatDesLieux) -> dict:
    c = edl.contrat
    entree = edl_entree(db, c.id) if edl.type_edl == "Sortie" else None
    auteur = edl.auteur.nom_complet if edl.auteur else ""
    return {
        "numero": edl.numero, "type_edl": edl.type_edl, "statut": edl.statut,
        "date": edl.date_edl.strftime("%d/%m/%Y"), "numero_contrat": c.numero_contrat,
        "locataire": c.locataire.nom_complet, "telephone": c.locataire.telephone or "",
        "cni": c.locataire.cni or "",
        "logement": f"Logement {c.logement.numero_logement} ({c.logement.type_logement}), {c.logement.cite.nom}",
        "adresse": c.logement.cite.adresse or "",
        "proprietaire": c.logement.cite.proprietaire.nom_complet if c.logement.cite.proprietaire else "",
        "date_debut": c.date_debut.strftime("%d/%m/%Y"),
        "pieces": edl.pieces, "compteurs": edl.compteurs or {}, "nb_cles": edl.nb_cles,
        "observations": edl.observations or "",
        "caution": c.montant_caution or Decimal(0), "retenues": edl.retenues or Decimal(0),
        "degradations": degradations(edl, entree),
        "photos": [(p.piece or "", p.legende or "", fichiers.chemin_absolu(p.chemin_fichier)) for p in edl.photos],
        "signature_locataire": edl.signature_locataire, "signature_agent": edl.signature_agent,
        "agent": auteur, "signe_le": edl.signe_le.strftime("%d/%m/%Y à %H:%M") if edl.signe_le else "",
    }


@router.post("/etats-des-lieux/{edl_id}/signer")
def signer(edl_id: int, d: SignatureIn, utilisateur: Utilisateur = Depends(acces_edl),
           db: SessionDB = Depends(get_db)):
    edl = charger_edl(db, utilisateur, edl_id)
    exiger_brouillon(edl)
    if not edl.pieces:
        raise HTTPException(status_code=409, detail="Ajoutez au moins une pièce avant de signer.")
    edl.signature_locataire = signature_png(d.signature_locataire)
    edl.signature_agent = signature_png(d.signature_agent)
    edl.statut = "Signé"
    edl.signe_le = datetime.now()
    if edl.cree_par is None:
        edl.cree_par = utilisateur.id
    db.flush()
    contenu = documents_pdf.etat_des_lieux_pdf(donnees_pdf(db, edl))
    relatif = f"etats_des_lieux/{edl.date_edl.year}/{edl.numero}.pdf"
    chemin = fichiers.DOSSIER_DOCUMENTS / relatif
    chemin.parent.mkdir(parents=True, exist_ok=True)
    chemin.write_bytes(contenu)
    edl.chemin_pdf = relatif
    db.commit()
    return {"ok": True, "numero": edl.numero}


def contenu_pdf(db: SessionDB, edl: EtatDesLieux) -> bytes:
    if edl.statut == "Signé" and edl.chemin_pdf:
        chemin = fichiers.chemin_absolu(edl.chemin_pdf)
        if chemin.exists():
            return chemin.read_bytes()
    return documents_pdf.etat_des_lieux_pdf(donnees_pdf(db, edl))  # brouillon : marqué « BROUILLON »


@router.get("/etats-des-lieux/{edl_id}/pdf")
def pdf(edl_id: int, utilisateur: Utilisateur = Depends(acces_edl), db: SessionDB = Depends(get_db)):
    edl = charger_edl(db, utilisateur, edl_id)
    return Response(contenu_pdf(db, edl), media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="{edl.numero}.pdf"'})


# ---------- Envoi au locataire ----------

def message_envoi(edl: EtatDesLieux) -> str:
    c = edl.contrat
    return (f"Bonjour {c.locataire.nom_complet},\n\n"
            f"Veuillez trouver ci-joint la copie signée de l'état des lieux de {edl.type_edl.lower()} "
            f"N° {edl.numero} du {edl.date_edl.strftime('%d/%m/%Y')}, pour le logement {c.logement.numero_logement} "
            f"({c.logement.cite.nom}).\n\nConservez-la précieusement : elle servira de référence "
            f"{'à votre départ' if edl.type_edl == 'Entrée' else 'pour la restitution de votre caution'}.\n\n"
            f"Cordialement,\n{recus.ENTETE['nom']} — {recus.ENTETE['activite']}\nTél. {recus.ENTETE['telephones']}")


def exiger_signe(edl: EtatDesLieux) -> None:
    if edl.statut != "Signé":
        raise HTTPException(status_code=409, detail="Faites d'abord signer l'état des lieux : on n'envoie que la copie signée.")


@router.post("/etats-des-lieux/{edl_id}/envoyer-email")
def envoyer_email(edl_id: int, d: EnvoiEmail, utilisateur: Utilisateur = Depends(acces_edl),
                  db: SessionDB = Depends(get_db)):
    edl = charger_edl(db, utilisateur, edl_id)
    exiger_signe(edl)
    parametres.envoyer_email(db, d.destinataire, f"État des lieux de {edl.type_edl.lower()} N° {edl.numero} — {recus.ENTETE['nom']}",
                             message_envoi(edl), [(f"{edl.numero}.pdf", contenu_pdf(db, edl), "application/pdf")])
    if not edl.contrat.locataire.email:  # on retient l'adresse pour la prochaine fois
        edl.contrat.locataire.email = d.destinataire
    edl.envoye_le = datetime.now()
    db.commit()
    return {"ok": True}


@router.post("/etats-des-lieux/{edl_id}/whatsapp")
def lien_whatsapp(edl_id: int, utilisateur: Utilisateur = Depends(acces_edl), db: SessionDB = Depends(get_db)):
    edl = charger_edl(db, utilisateur, edl_id)
    exiger_signe(edl)
    numero = numero_whatsapp(edl.contrat.locataire.telephone)
    edl.envoye_le = datetime.now()
    db.commit()
    texte = quote(message_envoi(edl))
    return {"lien": f"https://wa.me/{numero}?text={texte}" if numero else f"https://wa.me/?text={texte}",
            "nom_fichier": f"{edl.numero}.pdf", "a_numero": bool(numero)}


@router.post("/etats-des-lieux/{edl_id}/supprimer")
def supprimer(edl_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, d.mot_de_passe_admin)
    edl = charger(db, EtatDesLieux, edl_id, "État des lieux introuvable.")
    chemins = [p.chemin_fichier for p in edl.photos] + [edl.chemin_pdf]
    db.delete(edl)
    db.commit()
    for chemin in chemins:
        fichiers.effacer(chemin)
    return {"ok": True}
