"""Suivi à distance par l'éditeur de Gérimo (le maintenancier).

Chaque installation envoie toute seule, sur Internet, dans la base en ligne de l'éditeur (Supabase) :
- une fois par jour, son « contact » : entreprise, ville, téléphone de l'entreprise, version, licence (et sa fin),
  nombre de comptes, nombre de
  personnes qui ont travaillé (jour / 30 jours) et types d'appareils. Obligatoire (va avec la licence).
- les rapports de bugs : erreurs inattendues du serveur et des écrans, SANS données de la base (noms,
  téléphones, montants et valeurs retirés), sauf si l'Admin les a coupés (Paramètres → À propos) ;
- les problèmes signalés par un utilisateur (bouton « Signaler un problème »), toujours permis.

Rien n'est lu en retour : la clé publique de l'éditeur ne permet que de DÉPOSER (règles de la base en
ligne, installation/suivi_supabase.sql). Sans Internet, tout attend dans la table suivi_envois.
La lecture (installations, bugs) se fait en dehors de Gérimo : rien de la maintenance n'est dans le logiciel des clients.
"""
import hashlib
import json
import os
import platform
import re
import secrets
import sys
import threading
import time
import traceback
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session as SessionDB

import licence
import parametres
from models import Utilisateur
from securite import exiger_admin, get_db, utilisateur_connecte

router = APIRouter()

# Base en ligne de l'éditeur. La clé « publique » (publishable / anon) est faite pour être livrée dans le
# logiciel : avec elle on ne peut que déposer, jamais lire ni effacer.
ADRESSE = "https://kwejnhieqwxfjdehkslv.supabase.co"
CLE_PUBLIQUE = "sb_publishable_3b0ofzoG1S-32t5oxjqWMg_f2JQrPF6"

DOSSIER = Path(__file__).parent
TABLES = {"contact": "contacts", "bug": "rapports"}
COLONNES_CONTACT = ("installation", "code_pc", "entreprise", "ville", "version", "licence", "comptes", "actifs_jour",
                    "actifs_30j", "details")
ATTENTE_MAX = 300          # rapports en attente gardés au plus (les plus anciens partent)
GARDE_ENVOYES = timedelta(days=30)
TOUTES_LES = 30 * 60       # la boucle passe toutes les 30 minutes


def reglage() -> tuple[str, str]:
    adresse = re.sub(r"/rest/v1/?$", "", os.getenv("GERIMO_SUIVI_ADRESSE", ADRESSE).strip().rstrip("/"))
    return adresse, os.getenv("GERIMO_SUIVI_CLE", CLE_PUBLIQUE).strip()


def configure() -> bool:
    return all(reglage())


def envoi_permis() -> bool:
    """Seul Gérimo installé (exe) envoie en ligne. La version d'essai (dossier du projet, tests) n'envoie rien,
    sauf vers une adresse donnée exprès (GERIMO_SUIVI_ADRESSE : la fausse base des tests)."""
    return getattr(sys, "frozen", False) or bool(os.getenv("GERIMO_SUIVI_ADRESSE"))


def installation(db: SessionDB) -> str:
    """Identifiant tiré au hasard une fois pour toutes (suit la base : une restauration garde le même)."""
    ident = parametres.lire(db, "suivi_installation")
    if not ident:
        ident = secrets.token_hex(12)
        db.execute(text("INSERT INTO parametres (cle, valeur, modifie_le) VALUES ('suivi_installation', :v, NOW()) "
                        "ON CONFLICT (cle) DO NOTHING"), {"v": ident})
        db.commit()
        ident = parametres.lire(db, "suivi_installation")
    return ident


def bugs_auto(db: SessionDB) -> bool:
    return parametres.lire(db, "suivi_bugs_auto") != "non"


# ---------- Ce qui est envoyé ----------

def _version() -> str:
    import version
    try:
        return str(version.infos_version().get("version", ""))
    except Exception:  # noqa: BLE001
        return ""


def contact(db: SessionDB) -> dict:
    """Le « contact » du jour : rien sur les locataires, propriétaires, biens ni montants."""
    comptes = db.execute(text("SELECT role::text AS role, COUNT(*) AS n FROM utilisateurs WHERE actif "
                              "GROUP BY role ORDER BY role")).all()
    actifs = db.execute(text(
        "SELECT COUNT(DISTINCT utilisateur_id) FILTER (WHERE quand >= CURRENT_DATE) AS jour, "
        "COUNT(DISTINCT utilisateur_id) AS mois FROM journal "
        "WHERE operation = 'CONNEXION' AND quand >= CURRENT_DATE - INTERVAL '30 days'")).one()
    en_session = db.execute(text("SELECT COUNT(DISTINCT utilisateur_id) FROM sessions "
                                 "WHERE derniere_activite >= CURRENT_DATE")).scalar() or 0
    appareils = db.execute(text(
        "SELECT COALESCE(apres->>'appareil', 'navigateur') AS a, COUNT(DISTINCT utilisateur_id) AS n FROM journal "
        "WHERE operation = 'CONNEXION' AND quand >= CURRENT_DATE - INTERVAL '30 days' GROUP BY 1 ORDER BY 1")).all()
    etat = licence.etat(db)
    return {
        "installation": installation(db),
        "code_pc": etat.get("code_pc", ""),
        "entreprise": parametres.lire(db, "entreprise_nom")[:150],
        "ville": parametres.lire(db, "entreprise_ville")[:80],
        "version": _version(),
        "licence": " ".join(x for x in (etat.get("statut", ""), etat.get("numero", "")) if x)[:40],
        "comptes": sum(c.n for c in comptes),
        "actifs_jour": max(actifs.jour or 0, en_session),
        "actifs_30j": max(actifs.mois or 0, en_session),
        "details": {"telephone": parametres.lire(db, "entreprise_telephones")[:60],  # celui de « Mon entreprise » seulement
                    "licence_fin": etat.get("fin"), "licence_jours": etat.get("jours_restants"),
                    "comptes_par_profil": {c.role: c.n for c in comptes},
                    "appareils_30j": {a.a: a.n for a in appareils},
                    "systeme": f"{platform.system()} {platform.release()}"[:60],
                    "mode": "installé" if getattr(sys, "frozen", False) else "développement",
                    "bugs_auto": bugs_auto(db)},
    }


# ---------- Rapports de bugs : sans aucune donnée de la base ----------

TELEPHONE = re.compile(r"(?<!\d)(?:\+?225[\s.-]?)?0\d(?:[\s.-]?\d{2}){4}(?!\d)")
EMAIL = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")
GARDES = re.compile(r"^(?:[a-z_][a-z0-9_.]*|[A-Z][A-Za-z]*(?:Type|Error|Exception|Warning)|[A-Z][a-z]+[A-Z]\w*)$")


def _guillemets(m: re.Match) -> str:
    """'nom_complet', 'NoneType' : on garde (c'est le code) ; 'Kouassi Ama', '0707…' : retiré."""
    dedans = m.group(2)
    return m.group(0) if len(dedans) <= 40 and GARDES.match(dedans) else f"{m.group(1)}…{m.group(3)}"


def nettoyer(texte: str, longueur: int = 1500) -> str:
    """Retire d'un message d'erreur tout ce qui pourrait venir des données : requête SQL et ses valeurs,
    valeurs entre guillemets ou parenthèses, e-mails, téléphones, nombres."""
    t = str(texte or "")
    t = re.split(r"\[SQL:|\(Background on this error", t)[0]
    t = re.sub(r"\[parameters:.*", "", t, flags=re.S)
    t = EMAIL.sub("[e-mail]", t)
    t = TELEPHONE.sub("[téléphone]", t)
    t = re.sub(r"=\([^)]*\)", "=(…)", t)                    # DETAIL: Key (telephone)=(07…) already exists
    t = re.sub(r"(')([^'\n]*)(')", _guillemets, t)
    t = re.sub(r'(")([^"\n]*)(")', _guillemets, t)
    t = re.sub(r"(«\s?)([^»\n]*)(\s?»)", lambda m: "«…»", t)
    t = re.sub(r"\d[\d\s.,]{2,}\d|\d{3,}", "[nombre]", t)
    return re.sub(r"\s+", " ", t).strip()[:longueur]


def _chemin_neutre(chemin: str) -> str:
    """/api/contrats/42/pdf → /api/contrats/{n}/pdf"""
    return re.sub(r"/\d+(?=/|$)", "/{n}", re.sub(r"[?#].*", "", chemin or ""))[:200]


def pile_python(exc: BaseException) -> tuple[list[str], str]:
    """Lignes du code de Gérimo traversées par l'erreur (fichier, ligne, fonction, instruction) + empreinte."""
    cadres = []
    for c in traceback.extract_tb(exc.__traceback__):
        try:
            fichier = Path(c.filename).resolve().relative_to(DOSSIER.resolve())
        except ValueError:
            continue  # bibliothèques : sans intérêt pour l'éditeur
        cadres.append((fichier.as_posix(), c.lineno, c.name, (c.line or "").strip()[:160]))
    cadres = cadres[-12:]
    empreinte = hashlib.sha256((type(exc).__name__ + "|" + "|".join(f"{f}:{n}" for f, _, n, _ in cadres[-5:]))
                               .encode()).hexdigest()[:24]
    return [f"{f}:{l} dans {n} — {code}" for f, l, n, code in cadres], empreinte


def noter_bug(db: SessionDB, contenu: dict, empreinte: str) -> None:
    """Met un rapport dans la file. Le même bug déjà en attente (ou envoyé dans les 24 h) est seulement compté."""
    deja = db.execute(text("SELECT id FROM suivi_envois WHERE genre = 'bug' AND empreinte = :e "
                           "AND (envoye_le IS NULL OR envoye_le > NOW() - INTERVAL '24 hours') "
                           "ORDER BY id DESC LIMIT 1"), {"e": empreinte}).first()
    if deja:
        db.execute(text("UPDATE suivi_envois SET nb = nb + 1 WHERE id = :i"), {"i": deja.id})
    else:
        db.execute(text("INSERT INTO suivi_envois (genre, contenu, empreinte) VALUES ('bug', CAST(:c AS JSONB), :e)"),
                   {"c": json.dumps(contenu, ensure_ascii=False), "e": empreinte})
    db.commit()


def _session():
    """Session à part (celle de la requête a pu être abîmée par l'erreur) ; remplacée dans les tests."""
    from database import SessionLocal
    return SessionLocal()


def noter_erreur_serveur(request: Request, exc: BaseException, profil: str = "") -> None:
    """Appelée par main.py pour toute erreur inattendue. Ne doit jamais elle-même planter."""
    try:
        lignes, empreinte = pile_python(exc)
        with _session() as db:
            if not bugs_auto(db):
                return
            noter_bug(db, {"genre": "automatique", "origine": "serveur", "profil": profil,
                           "titre": f"{type(exc).__name__} sur {request.method} {_chemin_neutre(request.url.path)}",
                           "message": nettoyer(str(exc)), "details": "\n".join(lignes),
                           "survenu_le": datetime.now().isoformat(timespec="seconds")}, empreinte)
    except Exception as e:  # noqa: BLE001
        print(f"Suivi : rapport de bug non noté ({e})")


# ---------- Envoi ----------

def _poster(table: str, ligne: dict, timeout: int = 20) -> None:
    adresse, cle = reglage()
    requete = urllib.request.Request(f"{adresse}/rest/v1/{table}", method="POST",
                                     data=json.dumps(ligne, ensure_ascii=False).encode("utf-8"),
                                     headers={"apikey": cle, "Content-Type": "application/json",
                                              "Prefer": "return=minimal", "User-Agent": "Gerimo-suivi"})
    if cle.startswith("eyJ"):  # ancienne clé « anon » (JWT) : aussi en Authorization
        requete.add_header("Authorization", f"Bearer {cle}")
    with urllib.request.urlopen(requete, timeout=timeout) as reponse:
        reponse.read(1000)


def _ligne(db: SessionDB, genre: str, contenu: dict, nb: int) -> dict:
    if genre == "contact":  # exactement les colonnes de la table « contacts » (sinon refus 400)
        return {k: contenu.get(k) for k in COLONNES_CONTACT}
    return {"installation": installation(db), "entreprise": parametres.lire(db, "entreprise_nom")[:150],
            "ville": parametres.lire(db, "entreprise_ville")[:80], "version": _version(),
            "genre": contenu.get("genre", "automatique"), "origine": contenu.get("origine", "")[:20],
            "profil": contenu.get("profil", "")[:20], "titre": contenu.get("titre", "")[:200],
            "message": contenu.get("message", "")[:4000], "details": contenu.get("details", "")[:12000],
            "empreinte": contenu.get("empreinte_envoi", "")[:64], "nb": nb,
            "rappel_nom": contenu.get("rappel_nom", "")[:120], "rappel_telephone": contenu.get("rappel_telephone", "")[:40],
            "survenu_le": contenu.get("survenu_le")}


def envoyer_en_attente(db: SessionDB, limite: int = 50, timeout: int = 20) -> dict:
    """Envoie ce qui attend. S'arrête au premier « pas d'Internet » (on réessaiera à la prochaine boucle)."""
    bilan = {"envoyes": 0, "restants": 0, "erreur": ""}
    if not configure():
        bilan["erreur"] = "suivi pas encore configuré par l'éditeur"
    elif not envoi_permis():
        bilan["erreur"] = "version d'essai : rien n'est envoyé en ligne"
    else:
        lignes = db.execute(text("SELECT id, genre, contenu, empreinte, nb, essais FROM suivi_envois "
                                 "WHERE envoye_le IS NULL ORDER BY id LIMIT :l"), {"l": limite}).all()
        for l in lignes:
            contenu = {**l.contenu, "empreinte_envoi": l.empreinte or ""}
            try:
                _poster(TABLES[l.genre], _ligne(db, l.genre, contenu, l.nb), timeout)
                db.execute(text("UPDATE suivi_envois SET envoye_le = NOW(), dernier_essai = NOW() WHERE id = :i"), {"i": l.id})
                bilan["envoyes"] += 1
            except urllib.error.HTTPError as e:
                # refus de la base en ligne : ligne abîmée → abandonnée après 5 essais ; clé refusée → on garde
                db.execute(text("UPDATE suivi_envois SET essais = essais + 1, dernier_essai = NOW() WHERE id = :i"), {"i": l.id})
                if e.code in (400, 409, 413, 422) and l.essais >= 4:
                    db.execute(text("DELETE FROM suivi_envois WHERE id = :i"), {"i": l.id})
                bilan["erreur"] = f"la base de l'éditeur a répondu {e.code}"
                if e.code in (401, 403, 404, 429) or e.code >= 500:
                    break
            except (urllib.error.URLError, TimeoutError, OSError):
                bilan["erreur"] = "pas de connexion Internet"
                break
            finally:
                db.commit()
    bilan["restants"] = db.execute(text("SELECT COUNT(*) FROM suivi_envois WHERE envoye_le IS NULL")).scalar()
    return bilan


def noter_contact_du_jour(db: SessionDB, aujourdhui: date | None = None) -> bool:
    """Un seul contact par jour (le dernier de la journée remplace celui qui attend encore)."""
    aujourdhui = aujourdhui or date.today()
    if parametres.lire(db, "suivi_dernier_contact") == aujourdhui.isoformat():
        return False
    db.execute(text("DELETE FROM suivi_envois WHERE genre = 'contact' AND envoye_le IS NULL"))
    db.execute(text("INSERT INTO suivi_envois (genre, contenu) VALUES ('contact', CAST(:c AS JSONB))"),
               {"c": json.dumps(contact(db), ensure_ascii=False)})
    db.execute(text("INSERT INTO parametres (cle, valeur, modifie_le) VALUES ('suivi_dernier_contact', :v, NOW()) "
                    "ON CONFLICT (cle) DO UPDATE SET valeur = EXCLUDED.valeur, modifie_le = NOW()"),
               {"v": aujourdhui.isoformat()})
    db.commit()
    return True


def faire_le_menage(db: SessionDB) -> None:
    db.execute(text("DELETE FROM suivi_envois WHERE envoye_le < :d"), {"d": datetime.now() - GARDE_ENVOYES})
    db.execute(text("DELETE FROM suivi_envois WHERE id IN (SELECT id FROM suivi_envois WHERE envoye_le IS NULL "
                    "AND genre = 'bug' ORDER BY id DESC OFFSET :m)"), {"m": ATTENTE_MAX})
    db.commit()


def un_tour() -> dict | None:
    with _session() as db:
        if not configure():
            return None
        try:  # abonnement payé : clé débloquée en ligne (licence.py)
            licence.installer_cle_en_ligne(db)
        except Exception as e:  # noqa: BLE001
            print(f"Suivi : clé en ligne non vérifiée ({e})")
        if not envoi_permis():
            return None
        noter_contact_du_jour(db)
        bilan = envoyer_en_attente(db)
        faire_le_menage(db)
        return bilan


def _boucle():
    time.sleep(3 * 60)  # laisse le serveur démarrer tranquillement
    while True:
        try:
            un_tour()
        except Exception as e:  # noqa: BLE001 — ne jamais arrêter la boucle
            print(f"Suivi à distance : {e}")
        time.sleep(TOUTES_LES)


def demarrer() -> None:
    if os.getenv("GERIMO_SANS_SUIVI"):
        return
    threading.Thread(target=_boucle, daemon=True, name="suivi").start()


# ---------- Routes ----------

class SignalementIn(BaseModel):
    description: str = Field(min_length=10, max_length=3000)
    ecran: str = Field("", max_length=60)
    rappel_nom: str = Field("", max_length=120)
    rappel_telephone: str = Field("", max_length=40)


class ErreurEcranIn(BaseModel):
    message: str = Field("", max_length=2000)
    source: str = Field("", max_length=300)
    ligne: int = 0
    colonne: int = 0
    pile: str = Field("", max_length=6000)
    ecran: str = Field("", max_length=60)


_erreurs_ecran: dict[int, list[float]] = {}


def _source_neutre(source: str) -> str:
    """https://192.168.1.10:8443/static/js/app.js?v=3 → static/js/app.js"""
    m = re.search(r"/(static/[\w./-]+\.js)", source or "")
    return m.group(1) if m else ("page" if source else "")


@router.post("/api/suivi/erreur-ecran")
def erreur_ecran(d: ErreurEcranIn, u: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    """Erreur JavaScript d'un écran (au plus 10 par heure et par utilisateur)."""
    maintenant = time.time()
    recentes = [t for t in _erreurs_ecran.get(u.id, []) if maintenant - t < 3600]
    if len(recentes) >= 10 or not bugs_auto(db):
        return {"ok": True, "garde": False}
    _erreurs_ecran[u.id] = recentes + [maintenant]
    source = _source_neutre(d.source)
    pile = [f"{_source_neutre(m.group(0))}:{m.group(1)}" for m in re.finditer(r"/static/[\w./-]+\.js(?:\?[^:\s)]*)?:(\d+:\d+)", d.pile)]
    message = nettoyer(d.message, 500)
    ecran = re.sub(r"[^\w-]", "", d.ecran)[:40]
    empreinte = hashlib.sha256(f"{message}|{source}:{d.ligne}".encode()).hexdigest()[:24]
    noter_bug(db, {"genre": "automatique", "origine": "écran", "profil": u.role.value,
                   "titre": f"Erreur d'écran ({ecran or 'inconnu'}) : {message[:120]}", "message": message,
                   "details": "\n".join([f"{source}:{d.ligne}:{d.colonne}"] + pile[:12]),
                   "survenu_le": datetime.now().isoformat(timespec="seconds")}, empreinte)
    return {"ok": True, "garde": True}


@router.post("/api/suivi/signaler")
def signaler(d: SignalementIn, u: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    """Problème décrit par un utilisateur : toujours permis, envoyé tout de suite si Internet est là."""
    description = re.sub(r"[<>`]", "", d.description).strip()
    if len(description) < 10:
        raise HTTPException(status_code=400, detail="Décrivez le problème en quelques mots (10 caractères au moins).")
    ecran = re.sub(r"[^\w-]", "", d.ecran)[:40]
    empreinte = "u-" + secrets.token_hex(8)
    noter_bug(db, {"genre": "utilisateur", "origine": ecran or "", "profil": u.role.value,
                   "titre": f"Signalé par un utilisateur ({u.role.value}{', écran ' + ecran if ecran else ''})",
                   "message": description, "details": "",
                   "rappel_nom": re.sub(r"[<>`]", "", d.rappel_nom).strip(),
                   "rappel_telephone": re.sub(r"[^\d +().-]", "", d.rappel_telephone).strip(),
                   "survenu_le": datetime.now().isoformat(timespec="seconds")}, empreinte)
    bilan = envoyer_en_attente(db, limite=10, timeout=10)
    envoye = not db.execute(text("SELECT 1 FROM suivi_envois WHERE empreinte = :e AND envoye_le IS NULL"),
                            {"e": empreinte}).first()
    return {"envoye": envoye, "message": "Merci : votre signalement est parti chez le maintenancier de Gérimo." if envoye
            else "Merci : votre signalement est gardé et partira tout seul dès qu'Internet sera disponible."}


@router.get("/api/suivi")
def etat_suivi(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    """Pour l'Admin : ce qui est envoyé (en clair), ce qui attend, le dernier envoi."""
    ligne = db.execute(text("SELECT COUNT(*) FILTER (WHERE envoye_le IS NULL) AS attente, MAX(envoye_le) AS dernier "
                            "FROM suivi_envois")).one()
    return {"configure": configure(), "bugs_auto": bugs_auto(db), "en_attente": ligne.attente,
            "dernier_envoi": ligne.dernier.strftime("%d/%m/%Y à %H:%M") if ligne.dernier else None,
            "apercu": contact(db)}


class BugsAutoIn(BaseModel):
    actif: bool


@router.put("/api/suivi/bugs-auto")
def regler_bugs_auto(d: BugsAutoIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    db.execute(text("INSERT INTO parametres (cle, valeur, modifie_le) VALUES ('suivi_bugs_auto', :v, NOW()) "
                    "ON CONFLICT (cle) DO UPDATE SET valeur = EXCLUDED.valeur, modifie_le = NOW()"),
               {"v": "oui" if d.actif else "non"})
    if not d.actif:  # coupé : ceux qui attendaient ne partent pas non plus
        db.execute(text("DELETE FROM suivi_envois WHERE genre = 'bug' AND envoye_le IS NULL "
                        "AND contenu->>'genre' = 'automatique'"))
    db.commit()
    return {"ok": True}
