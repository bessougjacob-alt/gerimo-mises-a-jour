"""Saisie intelligente : mots déjà utilisés dans le logiciel.

L'écran les ajoute au dictionnaire intégré (static/js/vocabulaire.js) : les suggestions
s'enrichissent avec l'usage. Aucun nom de personne n'est renvoyé ici.
"""
from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session as SessionDB

from models import Utilisateur
from securite import get_db, utilisateur_connecte

router = APIRouter(prefix="/api")

# liste → requête renvoyant les valeurs distinctes déjà saisies
REQUETES = {
    "villes": "SELECT DISTINCT ville FROM proprietaires WHERE ville IS NOT NULL",
    "professions": "SELECT DISTINCT profession FROM locataires WHERE profession IS NOT NULL",
    "adresses": """SELECT DISTINCT adresse FROM cites WHERE adresse IS NOT NULL
                   UNION SELECT DISTINCT situation_geographique FROM parcelles WHERE situation_geographique IS NOT NULL""",
    "motifs_resiliation": "SELECT DISTINCT motif_resiliation FROM contrats WHERE motif_resiliation IS NOT NULL",
    "motifs_annulation": "SELECT DISTINCT motif_annulation FROM paiements WHERE motif_annulation IS NOT NULL",
    "observations": "SELECT DISTINCT observation FROM encaissements WHERE observation IS NOT NULL",
    "motifs_depense": "SELECT DISTINCT motif FROM depenses WHERE motif IS NOT NULL",
}


@router.get("/vocabulaire")
def vocabulaire(utilisateur: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    return {cle: sorted({v.strip() for (v,) in db.execute(text(sql)) if v and v.strip()})[:500]
            for cle, sql in REQUETES.items()}
