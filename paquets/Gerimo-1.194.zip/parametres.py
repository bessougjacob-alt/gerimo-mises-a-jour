"""Paramètres du logiciel (Admin) et envoi des e-mails.

- Réseaux sociaux d'ISUP (groupe et page Facebook, WhatsApp), coordonnées de l'imprimeur.
- Serveur d'envoi des e-mails (SMTP) : par exemple Gmail avec un « mot de passe d'application ».
  Le mot de passe n'est jamais renvoyé à l'écran.
- Clé de l'intelligence artificielle de l'assistant (jamais renvoyée à l'écran non plus).
- Ces secrets sont chiffrés dans la base avec la clé de l'entreprise (coffre.py) : ni la base ni une sauvegarde
  ne les montrent en clair.
- Fonction de chaque utilisateur (imprimée sur sa carte de visite, non modifiable par lui).
"""
import os
import re
import smtplib
import ssl
from datetime import datetime
from email.message import EmailMessage
from email.utils import formataddr

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session as SessionDB

import banque
import coffre
import entreprise
from commun import Email, Formulaire, Texte, charger
from models import Parametre, Utilisateur
from securite import exiger_admin, get_db, utilisateur_connecte

router = APIRouter(prefix="/api")

# Paramètres modifiables (et leur valeur par défaut)
DEFAUTS = {
    "facebook_groupe_nom": "",
    "facebook_groupe_url": "",
    "facebook_page_url": "",
    "whatsapp_numero": "",
    # reçoit les demandes « Mot de passe oublié ? » (vide = numéro WhatsApp ISUP)
    "whatsapp_admin": "",
    "whatsapp_groupe_lien": "",
    "site_web": "",
    "smtp_serveur": "", "smtp_port": "587", "smtp_utilisateur": "", "smtp_mot_de_passe": "",
    "email_expediteur": "",
    "email_imprimeur": "", "whatsapp_imprimeur": "",
    # Clé de l'intelligence artificielle (Claude, Anthropic) utilisée par l'assistant
    "ia_cle_api": "",
    # Modèle de l'IA choisi par l'Admin selon le budget (voir ia.MODELES)
    "ia_modele": "intelligent",
    # Mises à jour en ligne : dépôt GitHub (« compte/depot ») et jeton d'accès en lecture (dépôt privé)
    "maj_depot": "", "maj_jeton": "",
    # « oui » : sur le réseau, Gérimo n'accepte plus que les connexions chiffrées (https)
    "https_obligatoire": "non",
    # Coordonnées bancaires de l'entreprise (publiques : imprimées sur les factures, reçus, ordres de virement)
    "banque_nom": "", "banque_titulaire": "", "banque_code": "", "banque_guichet": "", "banque_compte": "",
    "banque_cle_rib": "", "banque_iban": "", "banque_bic": "",
    # TVA (précomptabilité) : « oui » si l'entreprise est assujettie ; taux en % (18 % en Côte d'Ivoire)
    "tva_assujetti": "non", "tva_taux": "18",
    # Pénalités de retard (penalites.py) : désactivées tant que l'Admin ne les met pas en marche
    "penalite_active": "non", "penalite_mode": "pourcentage", "penalite_valeur": "10", "penalite_tolerance": "0",
    "penalite_cumul": "une_fois", "penalite_beneficiaire": "entreprise",
    # Mode hors réseau (hors_reseau.py) : copie consultable sur les téléphones quand le serveur est injoignable
    "hors_reseau_actif": "oui", "hors_reseau_jours": "7",
    # Mode veille (veille.py) : minutes sans activité avant la mise en veille sur PC (0 = jamais)
    "veille_minutes": "20",
    # Bandeau « Bonjour » de l'accueil : nombre de notifications qui défilent (les plus proches d'aujourd'hui)
    "defilement_max": "15",
    # Identité de l'entreprise (« Mon entreprise ») : voir entreprise.py
    **entreprise.DEFAUTS,
}
CLES_BANQUE = ("banque_nom", "banque_titulaire", "banque_code", "banque_guichet", "banque_compte", "banque_cle_rib",
               "banque_iban", "banque_bic")
# Visibles par tous les utilisateurs connectés (liens à ouvrir, numéros)
PUBLICS = ("facebook_groupe_nom", "facebook_groupe_url", "facebook_page_url", "whatsapp_numero",
           "whatsapp_groupe_lien", "site_web", "email_imprimeur", "whatsapp_imprimeur") + CLES_BANQUE \
    + tuple(entreprise.DEFAUTS)
SECRETS = ("smtp_mot_de_passe", "ia_cle_api", "maj_jeton")

# Fonction par défaut sur la carte de visite, si l'Admin n'en a pas fixé
FONCTION_PAR_ROLE = {"Admin": "Direction", "Gestionnaire": "Gestionnaire immobilier", "Caisse": "Caissier(ère)",
                     "Comptable": "Comptable"}


def _en_clair(cle: str, valeur: str) -> str:
    """Les secrets sont chiffrés dans la base (coffre.py) ; illisible (clé perdue) = à ressaisir, donc vide."""
    if cle not in SECRETS or not valeur:
        return valeur
    try:
        return coffre.dechiffrer_secret(valeur)
    except (coffre.CleInconnue, coffre.Abime):
        return ""


def lire(db: SessionDB, cle: str) -> str:
    p = db.get(Parametre, cle)
    return _en_clair(cle, (p.valeur if p and p.valeur is not None else DEFAUTS.get(cle, "")) or "")


def chiffrer_secrets(db: SessionDB) -> int:
    """Au démarrage : chiffre les secrets encore en clair (enregistrés avant le coffre). Renvoie leur nombre."""
    n = 0
    for p in db.query(Parametre).filter(Parametre.cle.in_(SECRETS)):
        if p.valeur and not p.valeur.startswith(coffre.PREFIXE_SECRET):
            p.valeur = coffre.chiffrer_secret(p.valeur)
            n += 1
    if n:
        db.commit()
    return n


def secrets_illisibles(db: SessionDB) -> list[str]:
    """Secrets chiffrés avec une clé absente du trousseau (PC remplacé sans le code de secours)."""
    illisibles = []
    for p in db.query(Parametre).filter(Parametre.cle.in_(SECRETS)):
        if p.valeur and p.valeur.startswith(coffre.PREFIXE_SECRET):
            try:
                coffre.dechiffrer_secret(p.valeur)
            except (coffre.CleInconnue, coffre.Abime):
                illisibles.append(p.cle)
    return illisibles


def cle_ia(db: SessionDB) -> str:
    """Clé de l'IA : celle saisie dans Paramètres, sinon ANTHROPIC_API_KEY du fichier .env."""
    return lire(db, "ia_cle_api") or os.getenv("ANTHROPIC_API_KEY", "")


def tous(db: SessionDB) -> dict:
    valeurs = dict(DEFAUTS)
    for p in db.query(Parametre).filter(Parametre.cle.in_(DEFAUTS)):
        valeurs[p.cle] = _en_clair(p.cle, p.valeur or "")
    return valeurs


# ---------- Coordonnées bancaires de l'entreprise (contrôles dans banque.py) ----------

def verifier_banque(valeurs: dict[str, str]) -> dict[str, str]:
    """Nettoie et vérifie le RIB, l'IBAN et le BIC de l'entreprise ; HTTPException si incohérent."""
    v = banque.verifier(valeurs.get("banque_code", ""), valeurs.get("banque_guichet", ""),
                        valeurs.get("banque_compte", ""), valeurs.get("banque_cle_rib", ""),
                        valeurs.get("banque_iban", ""), valeurs.get("banque_bic", ""))
    return {**valeurs, "banque_code": v["code"], "banque_guichet": v["guichet"], "banque_compte": v["compte"],
            "banque_cle_rib": v["cle"], "banque_iban": v["iban"], "banque_bic": v["bic"]}


def fonction_de(utilisateur: Utilisateur) -> str:
    return utilisateur.fonction or FONCTION_PAR_ROLE.get(utilisateur.role.value, "")


# ---------- Écran Paramètres (Admin) ----------

class ParametresIn(BaseModel):
    valeurs: dict[str, str | None]


@router.get("/parametres")
def lire_parametres(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    valeurs = tous(db)
    for cle in SECRETS:
        valeurs[cle] = "" if not valeurs[cle] else "********"
    utilisateurs = db.query(Utilisateur).order_by(Utilisateur.nom_complet).all()
    return {"valeurs": valeurs, "utilisateurs": [
        {"id": u.id, "nom_complet": u.nom_complet, "role": u.role.value, "actif": u.actif,
         "fonction": u.fonction or "", "fonction_par_defaut": FONCTION_PAR_ROLE.get(u.role.value, "")}
        for u in utilisateurs]}


@router.put("/parametres")
def modifier_parametres(donnees: ParametresIn, request: Request, admin: Utilisateur = Depends(exiger_admin),
                        db: SessionDB = Depends(get_db)):
    banque = {c: (donnees.valeurs[c] or "").strip()[:500] for c in CLES_BANQUE if donnees.valeurs.get(c) is not None}
    if banque:  # contrôlées ensemble (l'IBAN doit concorder avec le RIB), avec les valeurs déjà enregistrées
        actuelles = {c: lire(db, c) for c in CLES_BANQUE}
        verifiees = verifier_banque({**actuelles, **banque})
        donnees.valeurs.update({c: verifiees[c] for c in banque})
    for cle, valeur in donnees.valeurs.items():
        if cle not in DEFAUTS or valeur is None:
            continue
        valeur = valeur.strip()[:500]
        if cle in SECRETS and valeur == "********":  # inchangé
            continue
        if any(c in valeur for c in "<>`"):
            raise HTTPException(status_code=400, detail="Caractères non acceptés dans les paramètres.")
        if cle.endswith("_url") or cle in ("whatsapp_groupe_lien", "site_web"):
            if valeur and not valeur.startswith(("https://", "http://")):
                raise HTTPException(status_code=400, detail=f"Le lien doit commencer par https:// ({cle}).")
        if cle == "maj_depot" and valeur:
            valeur = re.sub(r"^https?://github\.com/", "", valeur).removesuffix(".git").strip("/")
            if not re.fullmatch(r"[A-Za-z0-9-]+/[A-Za-z0-9._-]+", valeur):
                raise HTTPException(status_code=400, detail="Dépôt GitHub : écrivez « compte/depot » (ex. bessou/gerimo).")
        if cle == "ia_modele" and valeur not in ("economique", "equilibre", "intelligent"):
            raise HTTPException(status_code=400, detail="Choix du modèle d'IA non reconnu.")
        if cle == "https_obligatoire":
            if valeur not in ("oui", "non"):
                raise HTTPException(status_code=400, detail="Connexion sécurisée : choix non reconnu.")
            locale = (request.client.host if request.client else "") in ("127.0.0.1", "::1", "testclient")
            if valeur == "oui" and request.url.scheme != "https" and not locale:
                raise HTTPException(status_code=400, detail="Pour rendre la connexion sécurisée obligatoire, ouvrez "
                                    "d'abord Gérimo en https:// (ou depuis le PC serveur) : sinon vous seriez bloqué.")
        if cle.startswith("entreprise_"):
            valeur = entreprise.verifier(cle, valeur)
        if cle == "tva_assujetti" and valeur not in ("oui", "non"):
            raise HTTPException(status_code=400, detail="TVA : choix non reconnu.")
        if cle == "tva_taux":
            try:
                if not 0 <= float(valeur.replace(",", ".")) <= 50:
                    raise ValueError
            except ValueError:
                raise HTTPException(status_code=400, detail="Taux de TVA : un nombre entre 0 et 50 (ex : 18).")
            valeur = valeur.replace(",", ".")
        choix = {"penalite_active": ("oui", "non"), "penalite_mode": ("pourcentage", "fixe"),
                 "penalite_cumul": ("une_fois", "par_mois"), "penalite_beneficiaire": ("entreprise", "proprietaire")}
        if cle in choix and valeur not in choix[cle]:
            raise HTTPException(status_code=400, detail="Pénalités de retard : choix non reconnu.")
        if cle == "penalite_valeur":
            try:
                if not 0 <= float(valeur.replace(",", ".") or "0") <= 1_000_000:
                    raise ValueError
            except ValueError:
                raise HTTPException(status_code=400, detail="Pénalité : un nombre (pourcentage ou montant en francs).")
            valeur = valeur.replace(",", ".")
        if cle == "penalite_tolerance" and not (valeur.isdigit() and int(valeur) <= 60):
            raise HTTPException(status_code=400, detail="Délai de tolérance : un nombre de jours entre 0 et 60.")
        if cle == "hors_reseau_actif" and valeur not in ("oui", "non"):
            raise HTTPException(status_code=400, detail="Mode hors réseau : choix non reconnu.")
        if cle == "hors_reseau_jours" and not (valeur.isdigit() and 1 <= int(valeur) <= 30):
            raise HTTPException(status_code=400, detail="Mode hors réseau : un nombre de jours entre 1 et 30.")
        if cle == "veille_minutes" and not (valeur.isdigit() and int(valeur) <= 240):
            raise HTTPException(status_code=400, detail="Mode veille : un nombre de minutes entre 0 (jamais) et 240.")
        if cle == "defilement_max" and not (valeur.isdigit() and 1 <= int(valeur) <= 100):
            raise HTTPException(status_code=400, detail="Notifications qui défilent : un nombre entre 1 et 100.")
        if cle == "smtp_port" and valeur and not valeur.isdigit():
            raise HTTPException(status_code=400, detail="Le port SMTP est un nombre (587 ou 465).")
        if cle in SECRETS:
            valeur = coffre.chiffrer_secret(valeur)
        p = db.get(Parametre, cle)
        if p is None:
            db.add(Parametre(cle=cle, valeur=valeur, modifie_le=datetime.now()))
        else:
            p.valeur, p.modifie_le = valeur, datetime.now()
    db.commit()
    entreprise.charger(db)   # en-tête des documents à jour tout de suite
    return {"ok": True}


@router.get("/parametres/publics")
def parametres_publics(utilisateur: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    valeurs = tous(db)
    publics = {cle: valeurs[cle] for cle in PUBLICS}
    publics["email_configure"] = bool(valeurs["smtp_serveur"] and valeurs["smtp_utilisateur"])
    publics["ia_configuree"] = bool(cle_ia(db))
    return publics


class FonctionIn(Formulaire):
    fonction: Texte = Field("", max_length=120)


@router.put("/utilisateurs/{utilisateur_id}/fonction")
def modifier_fonction(utilisateur_id: int, donnees: FonctionIn, admin: Utilisateur = Depends(exiger_admin),
                      db: SessionDB = Depends(get_db)):
    u = charger(db, Utilisateur, utilisateur_id, "Utilisateur introuvable.")
    u.fonction = donnees.fonction or None
    db.commit()
    return {"ok": True}


# ---------- Envoi d'e-mails ----------

def envoyer_email(db: SessionDB, destinataire: str, sujet: str, texte: str,
                  pieces: list[tuple[str, bytes, str]] = ()) -> None:
    """Envoie un e-mail avec pièces jointes [(nom, octets, type MIME)]."""
    v = tous(db)
    if not (v["smtp_serveur"] and v["smtp_utilisateur"] and v["smtp_mot_de_passe"]):
        raise HTTPException(status_code=409, detail="L'envoi d'e-mails n'est pas encore configuré : "
                                                    "l'Admin doit le régler dans Paramètres → E-mail.")
    message = EmailMessage()
    message["From"] = formataddr((v["entreprise_nom"], v["email_expediteur"] or v["smtp_utilisateur"]))
    message["To"] = destinataire
    message["Subject"] = sujet
    message.set_content(texte)
    for nom, octets, type_mime in pieces:
        principal, _, secondaire = type_mime.partition("/")
        message.add_attachment(octets, maintype=principal, subtype=secondaire, filename=nom)
    port = int(v["smtp_port"] or 587)
    try:
        if port == 465:
            with smtplib.SMTP_SSL(v["smtp_serveur"], port, context=ssl.create_default_context(), timeout=30) as smtp:
                smtp.login(v["smtp_utilisateur"], v["smtp_mot_de_passe"])
                smtp.send_message(message)
        else:
            with smtplib.SMTP(v["smtp_serveur"], port, timeout=30) as smtp:
                smtp.starttls(context=ssl.create_default_context())
                smtp.login(v["smtp_utilisateur"], v["smtp_mot_de_passe"])
                smtp.send_message(message)
    except smtplib.SMTPAuthenticationError:
        raise HTTPException(status_code=502, detail="E-mail refusé : identifiant ou mot de passe SMTP incorrect "
                                                    "(Gmail : utilisez un « mot de passe d'application »).")
    except (smtplib.SMTPException, OSError) as e:
        raise HTTPException(status_code=502, detail=f"E-mail non envoyé (vérifiez Internet et les paramètres) : {e}")


class TestEmail(Formulaire):
    destinataire: Email = Field(min_length=3, max_length=150)


@router.post("/parametres/test-email")
def tester_email(donnees: TestEmail, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    nom = lire(db, "entreprise_nom")
    envoyer_email(db, donnees.destinataire, f"Test d'envoi — Gérimo ({nom})",
                  f"Bonjour,\n\nCe message confirme que l'envoi d'e-mails depuis Gérimo fonctionne.\n\n{nom}")
    return {"ok": True}
