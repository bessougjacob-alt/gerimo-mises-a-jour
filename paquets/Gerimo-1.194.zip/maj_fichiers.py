"""Installation des fichiers d'une mise à jour téléchargée, avec retour arrière.

Module volontairement léger (aucune dépendance au reste du logiciel) : il est utilisé par le serveur
(version.py) pour installer la mise à jour, et par le programme ISUP ERP Serveur.exe au démarrage
(installation/lanceur_serveur.py) pour revenir à l'ancienne version si la nouvelle ne démarre pas.

Seuls les fichiers du logiciel sont remplacés : les fichiers .py à la racine, static/, modeles/, migrations/,
schema.sql, requirements.txt, publication.json et nouveautes.json. Jamais .env, les documents, les sauvegardes ni les journaux.
"""
import io
import json
import shutil
import zipfile
from datetime import datetime
from pathlib import PurePosixPath, Path

DOSSIERS_AUTORISES = ("static", "modeles", "migrations")
FICHIERS_RACINE = ("schema.sql", "requirements.txt", "publication.json", "nouveautes.json", "signature.json")
EXCLUS = {"vider_donnees.py", "test_connexion.py", "create_admin.py"}  # outils à lancer à la main, jamais livrés
TAILLE_MAX = 80 * 1024 * 1024


def marque(cible: Path) -> Path:
    """Fichier présent pendant qu'une mise à jour n'a pas encore prouvé qu'elle démarre."""
    return cible / "sauvegardes" / "maj_en_cours.json"


def chemin_autorise(relatif: PurePosixPath) -> bool:
    parties = relatif.parts
    if not parties or any(p in ("", ".", "..") or ":" in p or p.startswith(".") for p in parties):
        return False
    if len(parties) == 1:
        nom = parties[0]
        return (nom.endswith(".py") and nom not in EXCLUS) or nom in FICHIERS_RACINE
    return parties[0] in DOSSIERS_AUTORISES and "__pycache__" not in parties


def lire_paquet(contenu: bytes) -> dict[str, bytes]:
    """Fichiers utiles du zip (zip de GitHub : tout est dans un dossier « compte-depot-xxxx/ »)."""
    if len(contenu) > TAILLE_MAX:
        raise ValueError("Paquet de mise à jour trop gros.")
    try:
        archive = zipfile.ZipFile(io.BytesIO(contenu))
    except zipfile.BadZipFile:
        raise ValueError("Le fichier téléchargé n'est pas un paquet de mise à jour valable.")
    noms = [n for n in archive.namelist() if not n.endswith("/")]
    racines = {n.split("/", 1)[0] for n in noms}
    prefixe = (racines.pop() + "/") if len(racines) == 1 and all("/" in n for n in noms) else ""
    fichiers: dict[str, bytes] = {}
    total = 0
    for nom in noms:
        relatif = PurePosixPath(nom[len(prefixe):])
        if chemin_autorise(relatif):
            info = archive.getinfo(nom)
            total += info.file_size
            if total > TAILLE_MAX:
                raise ValueError("Paquet de mise à jour trop gros.")
            fichiers[str(relatif)] = archive.read(nom)
    if "main.py" not in fichiers or "publication.json" not in fichiers:
        raise ValueError("Paquet incomplet (main.py ou publication.json absent).")
    return fichiers


def verifier_code(fichiers: dict[str, bytes]) -> None:
    """Chaque fichier Python doit être correct (sinon le serveur ne redémarrerait pas)."""
    for nom, contenu in fichiers.items():
        if nom.endswith(".py"):
            try:
                compile(contenu, nom, "exec")
            except SyntaxError as e:
                raise ValueError(f"Erreur dans {nom} (ligne {e.lineno}) : mise à jour refusée.")


def appliquer(fichiers: dict[str, bytes], cible: Path, version_avant: str) -> Path:
    """Copie de sécurité des fichiers remplacés, puis installation. Renvoie le dossier de la copie."""
    base = cible / "sauvegardes" / f"code_avant_maj_{version_avant}_{datetime.now():%Y%m%d_%H%M%S}"
    copie, n = base, 1
    while copie.exists():  # deux mises à jour dans la même seconde
        n += 1
        copie = base.with_name(f"{base.name}_{n}")
    copie.mkdir(parents=True)
    ajoutes = []
    for nom in fichiers:
        actuel = cible / nom
        if actuel.exists():
            (copie / nom).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(actuel, copie / nom)
        else:
            ajoutes.append(nom)
    marque(cible).write_text(json.dumps({"copie": str(copie), "ajoutes": ajoutes, "version_avant": version_avant},
                                        ensure_ascii=False), encoding="utf-8")
    try:
        for nom, contenu in fichiers.items():
            (cible / nom).parent.mkdir(parents=True, exist_ok=True)
            (cible / nom).write_bytes(contenu)
    except OSError:
        restaurer(cible)
        raise
    return copie


def restaurer(cible: Path) -> str | None:
    """Remet les fichiers d'avant la dernière mise à jour. Renvoie la version restaurée (ou None)."""
    fichier = marque(cible)
    if not fichier.exists():
        return None
    info = json.loads(fichier.read_text(encoding="utf-8"))
    copie = Path(info["copie"])
    for chemin in copie.rglob("*"):
        if chemin.is_file():
            destination = cible / chemin.relative_to(copie)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(chemin, destination)
    for nom in info.get("ajoutes", []):
        (cible / nom).unlink(missing_ok=True)
    fichier.unlink()
    return info.get("version_avant")


def confirmer(cible: Path) -> None:
    """La nouvelle version a démarré : plus besoin de pouvoir revenir en arrière automatiquement."""
    marque(cible).unlink(missing_ok=True)
