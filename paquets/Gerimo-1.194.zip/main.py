from datetime import datetime
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.orm import Session as SessionDB

from models import DemandeReinitialisation, Utilisateur
from urllib.parse import quote
import achats_ventes
import agenda
import assistant
import biens
import carte_visite
import certificats
import os
import contrats
import courriers
import depenses
import etats_des_lieux
import hors_reseau
import ia
import import_donnees
import journal
import lexique
import licence
import pont
import comptabilite
import entreprise
import reversements
import tresorerie
import exports
import paiements
import parametres
import veille
import pieces
import rapport_bien
import rapports
import recherche
import reseaux
import sauvegarde
import secours
import securite
import sejours
import signalements
import suivi
import utilisateurs
import version
import vocabulaire
import whatsapp
from securite import get_db, utilisateur_connecte

DOSSIER_STATIC = Path(__file__).parent / "static"

app = FastAPI(title="Gérimo - Gestion Locative")
app.mount("/static", StaticFiles(directory=DOSSIER_STATIC), name="static")
app.include_router(biens.router)
app.include_router(contrats.router)
app.include_router(paiements.router)
app.include_router(depenses.router)
app.include_router(achats_ventes.router)
app.include_router(vocabulaire.router)
app.include_router(whatsapp.router)
app.include_router(recherche.router)
app.include_router(rapports.router)
app.include_router(rapport_bien.router)
for module in (pieces, parametres, etats_des_lieux, courriers, agenda, assistant, ia, signalements, reseaux,
               exports, sauvegarde, carte_visite, version, utilisateurs, journal, import_donnees, pont, tresorerie,
               reversements, comptabilite, entreprise, sejours, secours, hors_reseau, veille, licence, lexique, suivi):
    app.include_router(module.router)


@app.on_event("startup")
def au_demarrage():
    # identité de l'entreprise (« Mon entreprise ») dans l'en-tête des documents
    try:
        from database import SessionLocal
        with SessionLocal() as db:
            entreprise.charger(db)
            parametres.chiffrer_secrets(db)  # secrets enregistrés avant le coffre : chiffrés maintenant
    except Exception:  # noqa: BLE001 — base pas encore prête : valeurs par défaut
        pass
    # sauvegarde quotidienne + copie sur la clé USB dès qu'elle est branchée (vérifié toutes les heures)
    sauvegarde.demarrer_sauvegardes_automatiques()
    # PC principal : le PC de secours tient-il le relais ? (si oui, ce PC ne sert pas : pas de doubles données)
    secours.demarrer_surveillance()
    # suivi à distance par l'éditeur : contact du jour et rapports de bugs (suivi.py)
    suivi.demarrer()

# Noms des champs tels qu'affichés dans les formulaires
LIBELLES_CHAMPS = {
    "nom_complet": "Nom complet", "cni": "CNI", "telephone": "Téléphone", "ville": "Ville",
    "nom": "Nom du bien", "adresse": "Adresse / Situation", "proprietaire_id": "Propriétaire",
    "cite_id": "Bien", "type_batiment": "Type de bien", "pourcentage_commission": "Commission de gestion (%)",
    "numero_parcelle": "Numéro de parcelle (lot)", "superficie": "Superficie",
    "situation_geographique": "Situation géographique", "documents": "Documents",
    "prix_entree": "Prix d'entrée", "dernier_prix": "Dernier prix",
    "approbation": "Approbation", "disponible": "Disponibilité",
    "numero_logement": "Numéro de logement", "type_logement": "Type de logement",
    "loyer": "Loyer mensuel", "statut_logement": "Statut",
    "profession": "Profession", "logement_id": "Logement", "locataire_id": "Locataire",
    "type_contrat": "Type de contrat", "usage_bien": "Usage du bien", "terme_loyer": "Loyer payé en",
    "montant_loyer": "Montant du loyer", "mois_caution": "Mois de caution", "mois_avance": "Mois d'avance",
    "date_debut": "Date de début", "date_fin": "Date de fin", "statut_contrat": "Statut du contrat",
    "date_resiliation": "Date de résiliation", "motif": "Motif",
    "contrat_id": "Contrat", "motif_paiement": "Motif", "nb_mois": "Nombre de mois",
    "mode_paiement": "Mode de paiement", "date_paiement": "Date", "montant": "Montant",
    "observation": "Observation",
    "categorie": "Catégorie", "a_la_charge_de": "À la charge de", "date_depense": "Date",
    "type_operation": "Type d'opération", "origine": "Bien concerné", "parcelle_id": "Parcelle",
    "designation": "Désignation du bien", "partie_nom": "Acheteur / vendeur", "partie_telephone": "Téléphone",
    "partie_cni": "CNI", "date_operation": "Date",
    "proprietaire_nom": "Propriétaire vendeur", "proprietaire_telephone": "Téléphone du propriétaire",
    "proprietaire_cni": "CNI du propriétaire", "commission_montant": "Commission d'intermédiation",
    "commission_payee_par": "Commission payée par",
}


@app.exception_handler(RequestValidationError)
def erreur_formulaire(request: Request, exc: RequestValidationError):
    """Transforme les erreurs de validation (en anglais) en un message clair."""
    erreur = exc.errors()[0]
    champ = next((str(p) for p in reversed(erreur["loc"]) if isinstance(p, str)), "")
    libelle = LIBELLES_CHAMPS.get(champ)
    # nos règles de saisie (commun.py) donnent déjà un message en français
    precision = str(erreur.get("ctx", {}).get("error", "")) if erreur.get("type") == "value_error" else ""
    if libelle and precision:
        message = f"« {libelle} » : {precision}"
    elif libelle:
        message = f"Vérifiez le champ « {libelle} »."
    else:
        message = "Formulaire incomplet ou invalide."
    return JSONResponse(status_code=422, content={"detail": message})

# Les pages ne doivent pas rester en cache : après déconnexion, le bouton
# « Précédent » du navigateur ne doit pas réafficher l'application.
SANS_CACHE = {"Cache-Control": "no-store"}


# Protections du navigateur : la page ne peut pas être affichée dans un autre site (piège au clic),
# les fichiers ne sont pas « devinés », aucun script ou contenu extérieur n'est chargé.
EN_TETES_SECURITE = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "same-origin",
    "Permissions-Policy": "camera=(self), microphone=(), geolocation=()",
    "Content-Security-Policy": ("default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
                                "img-src 'self' data: blob:; media-src 'self' blob:; font-src 'self' data:; "
                                "connect-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'self'; "
                                "form-action 'self'"),
}
# Accessibles même sans connexion sécurisée : de quoi installer le certificat
LIBRES_EN_CLAIR = ("/securiser", "/certificat-gerimo.crt", "/api/connexion-securisee", "/api/identite", "/static/", "/entreprise/logo",
                   "/api/entreprise")
_cache_obligatoire = {"valeur": False, "lu": 0.0}


def connexion_locale(request: Request) -> bool:
    """Le PC serveur lui-même (rien ne passe sur le réseau), ou les tests automatiques."""
    return (request.client.host if request.client else "") in ("127.0.0.1", "::1", "localhost", "testclient")


def https_obligatoire() -> bool:
    import time
    if time.time() - _cache_obligatoire["lu"] > 15:
        from database import SessionLocal
        try:
            with SessionLocal() as db:
                _cache_obligatoire["valeur"] = parametres.lire(db, "https_obligatoire") == "oui"
        except Exception:  # noqa: BLE001
            pass
        _cache_obligatoire["lu"] = time.time()
    return _cache_obligatoire["valeur"]


@app.middleware("http")
async def erreurs_inattendues(request: Request, call_next):
    """Erreur imprévue : message clair à l'écran, et rapport sans données envoyé à l'éditeur (suivi.py)."""
    try:
        return await call_next(request)
    except Exception as exc:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        suivi.noter_erreur_serveur(request, exc)
        return JSONResponse(status_code=500, content={"detail": "Erreur inattendue du logiciel. Elle a été notée "
                            "pour le maintenancier de Gérimo ; réessayez, ou signalez-la (menu → Signaler un problème)."})


@app.middleware("http")
async def securite_reseau(request: Request, call_next):
    """Sur le réseau, si l'Admin l'a rendu obligatoire : rien ne passe en clair (mots de passe, données)."""
    chemin = request.url.path
    if (request.url.scheme != "https" and not connexion_locale(request) and not chemin.startswith(LIBRES_EN_CLAIR)
            and certificats.disponible() and https_obligatoire()):
        if chemin.startswith("/api/"):
            reponse = JSONResponse(status_code=403, content={"detail": "Connexion non sécurisée refusée : "
                                                             "ouvrez Gérimo avec l'adresse https:// (voir /securiser)."})
        else:
            reponse = RedirectResponse("/securiser")
    else:
        reponse = await call_next(request)
    for nom, valeur in EN_TETES_SECURITE.items():
        reponse.headers.setdefault(nom, valeur)
    return reponse


@app.middleware("http")
async def licence_valable(request: Request, call_next):
    """Sans licence valable (essai terminé, clé expirée, autre PC) : lecture seule, jamais de données prises en otage."""
    if licence.saisie_bloquee(request.method, request.url.path):
        message = licence.lecture_seule()
        if message:
            return JSONResponse(status_code=402, content={"detail": message})
    if licence.fonction_reduite(request.method, request.url.path):  # abonnement impayé après le 15 du mois
        message = licence.fonctions_reduites()
        if message:
            return JSONResponse(status_code=402, content={"detail": message})
    return await call_next(request)


# Toujours permis, même service suspendu : échanges entre PC principal et PC de secours, page et fichiers de base
LIBRES_SI_SUSPENDU = ("/api/secours/", "/static/", "/entreprise/logo", "/api/entreprise", "/securiser",
                      "/certificat-gerimo.crt", "/api/connexion-securisee", "/api/identite", "/sw.js")
PAGE_SUSPENDU = """<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Gérimo — service sur l'autre PC</title>
<meta http-equiv="refresh" content="30"><link rel="stylesheet" href="/static/css/style.css"></head>
<body style="display:flex;align-items:center;justify-content:center;min-height:100vh;padding:16px">
<div class="card" style="max-width:520px"><h3>Gérimo n'est pas disponible sur ce PC en ce moment</h3>
<p>{message}</p>{lien}<p class="petit">Cette page se recharge toute seule.</p></div></body></html>"""


@app.middleware("http")
async def service_sur_l_autre_pc(request: Request, call_next):
    """PC principal pendant que le PC de secours tient le relais, ou PC de secours qui a rendu la main :
    ce PC ne sert pas (sinon il y aurait deux versions différentes des données)."""
    suspendu = secours.service_suspendu()
    if suspendu is None or request.url.path.startswith(LIBRES_SI_SUSPENDU):
        return await call_next(request)
    if request.url.path.startswith("/api/"):
        return JSONResponse(status_code=503, content={"detail": suspendu["message"]})
    import html
    lien = (f'<p><a class="btn primary" href="{html.escape(suspendu["lien"])}">Ouvrir Gérimo sur le bon PC</a></p>'
            if suspendu.get("lien") else "")
    return HTMLResponse(PAGE_SUSPENDU.format(message=html.escape(suspendu["message"]), lien=lien), status_code=503,
                        headers=SANS_CACHE)


@app.middleware("http")
async def toujours_la_derniere_version(request: Request, call_next):
    """Styles et scripts : l'appareil redemande toujours s'ils ont changé (réponse « 304 » très légère
    s'ils sont identiques). Sans cela, un téléphone ou un PC peut garder une ancienne interface
    plusieurs heures après une mise à jour du serveur."""
    reponse = await call_next(request)
    chemin = request.url.path
    if chemin.startswith("/static/") and chemin.endswith((".js", ".css", ".html", ".webmanifest")):
        reponse.headers["Cache-Control"] = "no-cache"
    return reponse


# ---------- Pages ----------

@app.get("/")
def racine(request: Request, db: SessionDB = Depends(get_db)):
    if securite.utilisateur_de_la_requete(db, request):
        return RedirectResponse("/app")
    return RedirectResponse("/connexion")


@app.get("/connexion")
def page_connexion(request: Request, db: SessionDB = Depends(get_db)):
    if securite.utilisateur_de_la_requete(db, request):
        return RedirectResponse("/app")
    return FileResponse(DOSSIER_STATIC / "connexion.html", headers=SANS_CACHE)


@app.get("/app")
def page_application(request: Request, db: SessionDB = Depends(get_db)):
    if securite.utilisateur_de_la_requete(db, request) is None:
        return RedirectResponse("/connexion")
    return FileResponse(DOSSIER_STATIC / "app.html", headers=SANS_CACHE)


@app.get("/securiser")
def page_securiser():
    """Explications pour installer le certificat Gérimo (une fois par appareil)."""
    return FileResponse(DOSSIER_STATIC / "securiser.html", headers=SANS_CACHE)


@app.get("/certificat-gerimo.crt")
def certificat_gerimo():
    if not certificats.CA_CERT.exists():
        raise HTTPException(status_code=404, detail="Connexion sécurisée pas encore activée sur ce serveur.")
    return FileResponse(certificats.CA_CERT, media_type="application/x-x509-ca-cert",
                        filename="certificat-gerimo.crt")


@app.get("/api/identite")
def identite_serveur(defi: str = ""):
    """Preuve d'identité pour l'application Android (défi signé avec la clé de l'autorité Gérimo de l'agence)."""
    if not (16 <= len(defi) <= 64 and all(c in "0123456789abcdef" for c in defi)):
        raise HTTPException(status_code=400, detail="Défi invalide.")
    preuve = certificats.prouver_identite(defi)
    if preuve is None:
        raise HTTPException(status_code=404, detail="Connexion sécurisée pas encore activée sur ce serveur.")
    return JSONResponse(preuve, headers=SANS_CACHE)


@app.get("/api/connexion-securisee")
def infos_connexion_securisee(request: Request):
    return {"disponible": certificats.disponible(), "port": certificats.PORT_HTTPS,
            # port de l'adresse normale (http) : le certificat s'y télécharge sans blocage du navigateur
            "port_http": int(os.environ.get("ISUP_PORT", "8000")),
            "empreinte": certificats.empreinte_autorite(), "en_cours": request.url.scheme == "https",
            "obligatoire": https_obligatoire()}


@app.get("/sw.js")
def service_worker():
    """Service worker à la racine (application installable sur téléphone et tablette)."""
    return FileResponse(DOSSIER_STATIC / "sw.js", media_type="application/javascript",
                        headers={"Cache-Control": "no-cache", "Service-Worker-Allowed": "/"})


# ---------- API d'authentification ----------

class DonneesConnexion(BaseModel):
    role: str
    identifiant: str
    mot_de_passe: str
    # « telephone_verrouille » : téléphone protégé par un code (Android qui le dit, iPhone, iPad) → pas de veille auto
    appareil: str = "pc"


class DonneesOubli(BaseModel):
    identifiant: str


def recus_entete_nom() -> str:
    import recus
    return recus.ENTETE["nom"]


def infos_utilisateur(utilisateur: Utilisateur) -> dict:
    role = utilisateur.role.value
    return {
        "nom_complet": utilisateur.nom_complet,
        "identifiant": utilisateur.identifiant,
        "role": role,
        "fonction": parametres.fonction_de(utilisateur),
        "entreprise": recus_entete_nom(),
        "modules": sorted(securite.MODULES_PAR_ROLE[role]),
    }


def derniere_connexion(db: SessionDB, utilisateur: Utilisateur) -> dict | None:
    """La connexion précédente de cet utilisateur (avant celle-ci) : quand et depuis quel appareil."""
    ligne = db.execute(text("SELECT quand, apres FROM journal WHERE operation = 'CONNEXION' AND utilisateur_id = :u "
                            "ORDER BY id DESC LIMIT 1"), {"u": utilisateur.id}).first()
    if ligne is None:
        return None
    return {"quand": ligne.quand.strftime("%d/%m/%Y à %H:%M"), "appareil": (ligne.apres or {}).get("appareil", "")}


@app.post("/api/connexion")
def connexion(donnees: DonneesConnexion, request: Request, db: SessionDB = Depends(get_db)):
    identifiant = donnees.identifiant.strip()
    poste = {"identifiant": identifiant[:80], "profil": donnees.role[:20],
             "appareil": securite.libelle_appareil(request.headers.get("user-agent", "")),
             "adresse": request.client.host if request.client else ""}
    attente = securite.attente_restante(identifiant, poste["adresse"])
    if attente:
        raise HTTPException(status_code=429, detail=securite.message_blocage(attente))
    utilisateur = securite.verifier_identifiants(db, identifiant, donnees.mot_de_passe, donnees.role)
    if utilisateur is None:
        securite.noter_echec(identifiant, poste["adresse"])
        securite.noter_evenement(db, "ECHEC", None, poste)
        # message volontairement vague : on ne dit pas ce qui est faux
        raise HTTPException(status_code=401, detail="Profil, identifiant ou mot de passe incorrect.")

    if (utilisateur.mdp_provisoire and utilisateur.mdp_provisoire_expire_le
            and utilisateur.mdp_provisoire_expire_le < datetime.now()):
        securite.noter_evenement(db, "ECHEC", None, {**poste, "motif": "mot de passe provisoire expiré"})
        raise HTTPException(status_code=401, detail="Ce mot de passe provisoire a expiré (48 heures) : "
                                                    "demandez-en un nouveau à l'Admin.")
    securite.effacer_echecs(identifiant)
    precedente = derniere_connexion(db, utilisateur)
    securite.noter_evenement(db, "CONNEXION", utilisateur, poste)
    try:
        minutes = int(parametres.lire(db, "veille_minutes") or 20)
    except ValueError:
        minutes = 20
    jeton = securite.ouvrir_session(db, utilisateur, 0 if donnees.appareil == "telephone_verrouille" else minutes,
                                    poste["appareil"])
    infos = infos_utilisateur(utilisateur)
    infos["derniere_connexion"] = precedente
    infos["mdp_a_changer"] = bool(utilisateur.mdp_provisoire)
    reponse = JSONResponse(infos)
    reponse.set_cookie(
        securite.NOM_COOKIE, jeton,
        max_age=int(securite.DUREE_SESSION.total_seconds()),
        httponly=True,      # inaccessible au JavaScript de la page
        samesite="strict",  # non envoyé depuis un autre site
        secure=request.url.scheme == "https",  # en HTTPS : jamais renvoyé en clair
    )
    return reponse


@app.post("/api/deconnexion")
def deconnexion(request: Request, db: SessionDB = Depends(get_db)):
    securite.fermer_session(db, request.cookies.get(securite.NOM_COOKIE))
    reponse = JSONResponse({"ok": True})
    reponse.delete_cookie(securite.NOM_COOKIE)
    return reponse


@app.post("/api/mot-de-passe-oublie")
def mot_de_passe_oublie(donnees: DonneesOubli, db: SessionDB = Depends(get_db)):
    identifiant = donnees.identifiant.strip()[:80]
    deja = identifiant and db.query(DemandeReinitialisation).filter_by(identifiant=identifiant, traitee=False).first()
    if identifiant and not deja:  # une seule demande en attente par identifiant
        utilisateur = db.query(Utilisateur).filter_by(identifiant=identifiant).first()
        db.add(DemandeReinitialisation(
            identifiant=identifiant,
            utilisateur_id=utilisateur.id if utilisateur else None,
        ))
        db.commit()
    # Pas d'envoi automatique (pas d'API WhatsApp payante) : l'employé prévient lui-même l'Admin
    # avec un message pré-rempli. Même réponse que le compte existe ou non.
    numero = whatsapp.numero_whatsapp(parametres.lire(db, "whatsapp_admin") or parametres.lire(db, "whatsapp_numero"))
    message = (f"Bonjour, ici l'utilisateur « {identifiant} » du logiciel Gérimo. "
               "J'ai oublié mon mot de passe : pouvez-vous m'en donner un nouveau ? "
               "(Paramètres → Utilisateurs, la demande y est enregistrée.) Merci.")
    return {"ok": True, "lien": f"https://wa.me/{numero}?text={quote(message)}" if numero and identifiant else None}


@app.get("/api/moi")
def moi(request: Request, utilisateur: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    session = securite.session_de_la_requete(db, request)
    return {**infos_utilisateur(utilisateur), "veille_minutes": session.veille_minutes if session else 0}


@app.get("/api/acces/{module}")
def verifier_acces(module: str, utilisateur: Utilisateur = Depends(utilisateur_connecte)):
    """Contrôle serveur de l'accès à un module (403 si refusé)."""
    if not securite.peut_acceder(utilisateur.role.value, module):
        raise HTTPException(status_code=403, detail="Accès refusé pour votre profil.")
    return {"module": module, "acces": True}
