"""Étape 9 : comptes utilisateurs (Admin uniquement) et mot de passe de chacun.

- L'Admin crée les comptes Admin, Gestionnaire, Caisse et Comptable, fixe leur fonction (carte de visite),
  confie des biens aux gestionnaires, désactive un compte (accès coupé immédiatement),
  et redonne un mot de passe (demandes « Mot de passe oublié ? »).
- Chacun peut changer son propre mot de passe (l'ancien est redemandé) ; ses autres appareils sont déconnectés.
- Mot de passe donné par l'Admin (création, mot de passe oublié) : PROVISOIRE, valable 48 h, à remplacer par
  l'employé à sa première connexion (rien d'autre n'est possible avant). Ainsi personne, pas même l'Admin, ne
  connaît le mot de passe d'un autre : le journal « qui a fait quoi » a un sens. Un mot de passe redonné est
  noté au journal et montré à l'employé.
- Garde-fous : on ne peut ni se désactiver soi-même, ni retirer le dernier Admin actif.
- Suppression : Admin, mot de passe redemandé, seulement pour un compte qui n'a rien enregistré
  (sinon on le désactive : l'historique garde le nom de qui a encaissé, signé…).
"""
import re
from datetime import datetime, timedelta
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session as SessionDB

import parametres
import securite
from commun import Formulaire, NomPersonne, Suppression, Texte, charger, enregistrer, supprimer
from models import Cite, DemandeReinitialisation, RoleUtilisateur, Session, Utilisateur
from securite import confirmer_mot_de_passe_admin, exiger_admin, get_db, utilisateur_connecte

router = APIRouter(prefix="/api")
ROLES = ("Admin", "Gestionnaire", "Caisse", "Comptable")
DUREE_PROVISOIRE = timedelta(hours=48)


def rendre_provisoire(u: Utilisateur) -> None:
    u.mdp_provisoire, u.mdp_provisoire_expire_le = True, datetime.now() + DUREE_PROVISOIRE


def verifier_mot_de_passe_solide(mdp: str) -> None:
    if len(mdp) < 8:
        raise HTTPException(status_code=400, detail="Mot de passe trop court : 8 caractères minimum.")
    if not (re.search(r"[A-Za-zÀ-ÿ]", mdp) and re.search(r"\d", mdp)):
        raise HTTPException(status_code=400, detail="Le mot de passe doit contenir au moins une lettre et un chiffre.")
    if len(mdp.encode("utf-8")) > securite.LONGUEUR_MAX_OCTETS:
        raise HTTPException(status_code=400, detail="Mot de passe trop long (72 caractères maximum).")


Identifiant = Field(min_length=3, max_length=80, pattern=r"^[A-Za-z0-9._\-]+$")


class UtilisateurIn(Formulaire):
    nom_complet: NomPersonne = Field(min_length=1, max_length=150)
    identifiant: str = Identifiant
    role: Literal[ROLES]
    fonction: Texte = Field("", max_length=120)
    appellation: Texte = Field("", max_length=80)
    actif: bool = True
    cites_ids: list[int] = []


class NouvelUtilisateur(UtilisateurIn):
    mot_de_passe: str = Field(min_length=1, max_length=200)


class NouveauMotDePasse(BaseModel):  # pas Formulaire : un mot de passe ne se retouche pas
    mot_de_passe: str = Field(min_length=1, max_length=200)


class ChangementMotDePasse(BaseModel):
    ancien: str = Field("", max_length=200)
    nouveau: str = Field(min_length=1, max_length=200)


def admins_actifs(db: SessionDB) -> int:
    return db.query(Utilisateur).filter(Utilisateur.role == RoleUtilisateur.Admin, Utilisateur.actif.is_(True)).count()


def utilisateur_json(db: SessionDB, u: Utilisateur, derniere: dict) -> dict:
    return {
        "id": u.id, "nom_complet": u.nom_complet, "identifiant": u.identifiant, "role": u.role.value,
        "actif": bool(u.actif), "fonction": u.fonction or "", "appellation": u.appellation or "",
        "fonction_affichee": parametres.fonction_de(u),
        "cites": [{"id": c.id, "nom": c.nom} for c in u.cites_gerees],
        "cree_le": u.cree_le.strftime("%d/%m/%Y") if u.cree_le else "",
        "derniere_connexion": derniere.get(u.id).strftime("%d/%m/%Y à %H:%M") if derniere.get(u.id) else None,
        "mdp_provisoire": bool(u.mdp_provisoire),
        "mdp_provisoire_expire": (u.mdp_provisoire_expire_le.strftime("%d/%m/%Y à %H:%M")
                                  if u.mdp_provisoire and u.mdp_provisoire_expire_le else None),
        "mdp_provisoire_expire_deja": bool(u.mdp_provisoire and u.mdp_provisoire_expire_le
                                           and u.mdp_provisoire_expire_le < datetime.now()),
    }


@router.get("/utilisateurs")
def liste(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    derniere = dict(db.query(Session.utilisateur_id, func.max(Session.cree_le)).group_by(Session.utilisateur_id).all())
    utilisateurs = db.query(Utilisateur).order_by(Utilisateur.actif.desc(), Utilisateur.role, Utilisateur.nom_complet).all()
    demandes, vus = [], set()  # la plus récente par identifiant (clics répétés regroupés)
    for d in db.query(DemandeReinitialisation).filter_by(traitee=False).order_by(DemandeReinitialisation.cree_le.desc()):
        if d.identifiant not in vus:
            vus.add(d.identifiant)
            demandes.append(d)
    return {
        "utilisateurs": [utilisateur_json(db, u, derniere) for u in utilisateurs],
        "roles": ROLES,
        "biens": [{"id": c.id, "nom": c.nom} for c in db.query(Cite).order_by(Cite.nom)],
        "demandes": [{"id": d.id, "identifiant": d.identifiant, "utilisateur_id": d.utilisateur_id,
                      "date": d.cree_le.strftime("%d/%m/%Y à %H:%M") if d.cree_le else ""} for d in demandes],
        "moi": admin.id,
    }


def appliquer(db: SessionDB, u: Utilisateur, d: UtilisateurIn) -> None:
    u.nom_complet, u.identifiant, u.role = d.nom_complet, d.identifiant, RoleUtilisateur(d.role)
    u.fonction = d.fonction or None
    u.appellation = d.appellation or None
    u.actif = d.actif
    # biens confiés : seulement pour un Gestionnaire
    u.cites_gerees = (db.query(Cite).filter(Cite.id.in_(set(d.cites_ids))).all()
                      if d.role == "Gestionnaire" and d.cites_ids else [])


@router.post("/utilisateurs")
def creer(d: NouvelUtilisateur, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    verifier_mot_de_passe_solide(d.mot_de_passe)
    if db.query(Utilisateur).filter(func.lower(Utilisateur.identifiant) == d.identifiant.lower()).first():
        raise HTTPException(status_code=409, detail="Cet identifiant est déjà pris.")
    u = Utilisateur(mot_de_passe=securite.hacher_mot_de_passe(d.mot_de_passe), cree_le=datetime.now())
    rendre_provisoire(u)
    appliquer(db, u, d)
    db.add(u)
    enregistrer(db, "Cet identifiant est déjà pris.")
    return {"id": u.id}


@router.put("/utilisateurs/{utilisateur_id}")
def modifier(utilisateur_id: int, d: UtilisateurIn, admin: Utilisateur = Depends(exiger_admin),
             db: SessionDB = Depends(get_db)):
    u = charger(db, Utilisateur, utilisateur_id, "Utilisateur introuvable.")
    if u.id == admin.id and (not d.actif or d.role != "Admin"):
        raise HTTPException(status_code=409, detail="Vous ne pouvez pas désactiver votre propre compte ni retirer vos droits Admin.")
    if u.role == RoleUtilisateur.Admin and u.actif and (d.role != "Admin" or not d.actif) and admins_actifs(db) <= 1:
        raise HTTPException(status_code=409, detail="Il doit toujours rester au moins un Admin actif.")
    autre = db.query(Utilisateur).filter(func.lower(Utilisateur.identifiant) == d.identifiant.lower(),
                                         Utilisateur.id != u.id).first()
    if autre:
        raise HTTPException(status_code=409, detail="Cet identifiant est déjà pris.")
    role_change = u.role.value != d.role
    appliquer(db, u, d)
    if not d.actif or role_change:  # accès coupé tout de suite (nouvelle connexion obligatoire)
        db.query(Session).filter_by(utilisateur_id=u.id).delete()
    enregistrer(db, "Cet identifiant est déjà pris.")
    return {"id": u.id}


@router.post("/utilisateurs/{utilisateur_id}/mot-de-passe")
def redonner_mot_de_passe(utilisateur_id: int, d: NouveauMotDePasse, admin: Utilisateur = Depends(exiger_admin),
                          db: SessionDB = Depends(get_db)):
    u = charger(db, Utilisateur, utilisateur_id, "Utilisateur introuvable.")
    verifier_mot_de_passe_solide(d.mot_de_passe)
    u.mot_de_passe = securite.hacher_mot_de_passe(d.mot_de_passe)
    if u.id != admin.id:  # l'Admin qui change le sien l'a choisi lui-même : il n'est pas provisoire
        db.query(Session).filter_by(utilisateur_id=u.id).delete()
        rendre_provisoire(u)
        u.mdp_redonne_le, u.mdp_redonne_par = datetime.now(), admin.id
        securite.noter_evenement(db, "MDP_REDONNE", admin, {
            "texte": f"Mot de passe provisoire donné à {u.nom_complet} (« {u.identifiant} »), valable 48 h"})
    db.query(DemandeReinitialisation).filter(func.lower(DemandeReinitialisation.identifiant) == u.identifiant.lower(),
                                             DemandeReinitialisation.traitee.is_(False)).update({"traitee": True},
                                                                                                synchronize_session=False)
    db.commit()
    return {"ok": True}


@router.post("/demandes-reinitialisation/{demande_id}/traiter")
def traiter_demande(demande_id: int, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    d = charger(db, DemandeReinitialisation, demande_id, "Demande introuvable.")
    db.query(DemandeReinitialisation).filter_by(identifiant=d.identifiant, traitee=False).update({"traitee": True})
    db.commit()
    return {"ok": True}


@router.post("/utilisateurs/{utilisateur_id}/supprimer")
def supprimer_compte(utilisateur_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin),
                     db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, d.mot_de_passe_admin)
    u = charger(db, Utilisateur, utilisateur_id, "Utilisateur introuvable.")
    if u.id == admin.id:
        raise HTTPException(status_code=409, detail="Vous ne pouvez pas supprimer votre propre compte.")
    if u.role == RoleUtilisateur.Admin and u.actif and admins_actifs(db) <= 1:
        raise HTTPException(status_code=409, detail="Il doit toujours rester au moins un Admin actif.")
    u.cites_gerees = []
    db.query(Session).filter_by(utilisateur_id=u.id).delete()
    db.query(DemandeReinitialisation).filter_by(utilisateur_id=u.id).update({"utilisateur_id": None})
    return supprimer(db, u, "Ce compte a déjà enregistré des opérations (encaissements, contrats…) : "
                            "désactivez-le plutôt, l'historique sera conservé.")


# ---------- Mon mot de passe (tous les profils) ----------

@router.post("/moi/mot-de-passe")
def changer_mon_mot_de_passe(d: ChangementMotDePasse, request: Request, u: Utilisateur = Depends(utilisateur_connecte),
                             db: SessionDB = Depends(get_db)):
    # mot de passe provisoire : la connexion qui vient d'être faite avec lui suffit (pas besoin de le retaper)
    if not u.mdp_provisoire and not securite.verifier_mot_de_passe(d.ancien, u.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe actuel incorrect.")
    verifier_mot_de_passe_solide(d.nouveau)
    if securite.verifier_mot_de_passe(d.nouveau, u.mot_de_passe):
        raise HTTPException(status_code=400, detail="Le nouveau mot de passe doit être différent de l'ancien.")
    u.mot_de_passe = securite.hacher_mot_de_passe(d.nouveau)
    etait_provisoire = u.mdp_provisoire
    u.mdp_provisoire, u.mdp_provisoire_expire_le = False, None
    # ses autres appareils sont déconnectés (si quelqu'un connaissait l'ancien mot de passe)
    actuelle = securite.session_de_la_requete(db, request)
    autres = db.query(Session).filter(Session.utilisateur_id == u.id)
    if actuelle is not None:
        autres = autres.filter(Session.id != actuelle.id)
    autres.delete(synchronize_session=False)
    securite.noter_evenement(db, "MDP_CHANGE", u, {
        "texte": f"{u.nom_complet} a choisi son mot de passe" + (" (remplace le provisoire)" if etait_provisoire else "")})
    return {"ok": True}
