-- Agenda (rendez-vous, appels, visites, courriers, tâches) et demandes de nouveaux clients.
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS prospects (
    id               SERIAL PRIMARY KEY,
    nom_complet      VARCHAR(150) NOT NULL,
    telephone        VARCHAR(30),
    email            VARCHAR(150),
    besoin           VARCHAR(30)  NOT NULL DEFAULT 'Location',
    type_logement    VARCHAR(40),
    quartier         VARCHAR(150),
    budget_max       NUMERIC(14,2),
    details          TEXT,
    source           VARCHAR(40),
    statut           VARCHAR(20)  NOT NULL DEFAULT 'Nouveau',
    prochaine_action DATE,
    cree_par         INTEGER REFERENCES utilisateurs(id),
    cree_le          TIMESTAMP DEFAULT now(),
    modifie_le       TIMESTAMP
);

-- Journal du suivi d'une demande (appels, visites, notes)
CREATE TABLE IF NOT EXISTS prospects_suivi (
    id          SERIAL PRIMARY KEY,
    prospect_id INTEGER NOT NULL REFERENCES prospects(id) ON DELETE CASCADE,
    note        TEXT NOT NULL,
    cree_par    INTEGER REFERENCES utilisateurs(id),
    cree_le     TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS agenda (
    id              SERIAL PRIMARY KEY,
    titre           VARCHAR(200) NOT NULL,
    type_evenement  VARCHAR(20)  NOT NULL DEFAULT 'Rendez-vous',
    date_evenement  DATE NOT NULL,
    heure           TIME,
    lieu            VARCHAR(200),
    telephone       VARCHAR(30),
    notes           TEXT,
    rappel_minutes  INTEGER NOT NULL DEFAULT 30,
    fait            BOOLEAN NOT NULL DEFAULT false,
    fait_le         TIMESTAMP,
    prospect_id     INTEGER REFERENCES prospects(id) ON DELETE SET NULL,
    contrat_id      INTEGER REFERENCES contrats(id) ON DELETE SET NULL,
    utilisateur_id  INTEGER REFERENCES utilisateurs(id),     -- pour qui (vide = toute l'équipe)
    cree_par        INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT now()
);
CREATE INDEX IF NOT EXISTS agenda_date ON agenda (date_evenement);
