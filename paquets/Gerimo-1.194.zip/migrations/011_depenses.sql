-- ============================================================
-- Migration 011 — Dépenses (étape 7)
-- Catégorie, à la charge de qui (propriétaire ou ISUP), mode de paiement,
-- logement concerné (facultatif) et auteur de la saisie.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================

ALTER TABLE depenses ADD COLUMN IF NOT EXISTS categorie VARCHAR(40) NOT NULL DEFAULT 'Autre';
ALTER TABLE depenses ADD COLUMN IF NOT EXISTS a_la_charge_de VARCHAR(20) NOT NULL DEFAULT 'Propriétaire';
ALTER TABLE depenses ADD COLUMN IF NOT EXISTS mode_paiement mode_paiement NOT NULL DEFAULT 'Espèce';
ALTER TABLE depenses ADD COLUMN IF NOT EXISTS logement_id INTEGER REFERENCES logements(id);
ALTER TABLE depenses ADD COLUMN IF NOT EXISTS saisi_par INTEGER REFERENCES utilisateurs(id);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_depenses_montant_positif') THEN
    ALTER TABLE depenses ADD CONSTRAINT ck_depenses_montant_positif CHECK (montant > 0);
  END IF;
  -- dépense payée pour le compte du propriétaire (déduite de son reversement) ou par ISUP
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_depenses_charge') THEN
    ALTER TABLE depenses ADD CONSTRAINT ck_depenses_charge CHECK (a_la_charge_de IN ('Propriétaire', 'Entreprise'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_depenses_cite_date ON depenses(cite_id, date_depense);
