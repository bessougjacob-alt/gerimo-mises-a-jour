-- ============================================================
-- Migration 028 — Enregistrements faits hors réseau (hors_reseau.py), 08/10/2026
-- Au retour du serveur, chaque téléphone envoie sa file d'attente. Chaque enregistrement est noté ici une fois
-- (uid tiré par le téléphone : un envoi répété ne crée jamais de doublon), puis rejoué par le serveur avec ses
-- règles habituelles. Refusé → « À vérifier » par l'Admin (réessayer ou abandonner).
-- Le journal des actions reçoit une ligne « Saisie hors réseau » par enregistrement (écrite par le logiciel).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS operations_hors_reseau (
    id               SERIAL PRIMARY KEY,
    uid              VARCHAR(64) UNIQUE NOT NULL,
    utilisateur_id   INTEGER NOT NULL REFERENCES utilisateurs(id),
    appareil_nom     VARCHAR(120),
    methode          VARCHAR(6) NOT NULL,
    chemin           VARCHAR(300) NOT NULL,
    corps            JSONB NOT NULL DEFAULT '{}'::jsonb,
    resume           VARCHAR(300) NOT NULL DEFAULT '',
    id_local         BIGINT,                       -- numéro provisoire donné par le téléphone (négatif)
    id_reel          INTEGER,                      -- numéro donné par le serveur
    saisi_le         TIMESTAMP NOT NULL,           -- heure du téléphone
    recu_le          TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP,
    statut           VARCHAR(12) NOT NULL,
    detail           TEXT,                         -- raison du refus
    traite_par       INTEGER REFERENCES utilisateurs(id),
    traite_le        TIMESTAMP,
    CONSTRAINT ck_operations_hors_reseau_statut CHECK (statut IN ('Envoyée', 'À vérifier', 'Abandonnée'))
);
CREATE INDEX IF NOT EXISTS idx_operations_hors_reseau_statut ON operations_hors_reseau(statut, recu_le DESC);
