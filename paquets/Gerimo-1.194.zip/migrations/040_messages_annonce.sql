-- ============================================================
-- Migration 040 — Messages groupés (11/11/2026) : nouveau type « annonce » dans l'historique des messages WhatsApp
-- (message libre envoyé en série à plusieurs locataires : coupure d'eau, fermeture du bureau…)
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE messages_whatsapp DROP CONSTRAINT IF EXISTS messages_whatsapp_type_message_check;
ALTER TABLE messages_whatsapp ADD CONSTRAINT messages_whatsapp_type_message_check
    CHECK (type_message IN ('bienvenue', 'rappel', 'confirmation', 'retard', 'expulsion', 'annonce'));
