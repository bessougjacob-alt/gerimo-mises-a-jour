-- ============================================================
-- Migration 024 — Départ du locataire (préavis), 06/10/2026
-- Le locataire annonce son départ : date du préavis, date de départ prévue, motif.
-- Les loyers s'arrêtent au mois du départ (inclus) ; la résiliation reste manuelle (Admin).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE contrats ADD COLUMN IF NOT EXISTS date_preavis DATE;   -- jour où le locataire a prévenu
ALTER TABLE contrats ADD COLUMN IF NOT EXISTS date_depart DATE;    -- départ prévu (dernier mois de loyer)
ALTER TABLE contrats ADD COLUMN IF NOT EXISTS motif_depart TEXT;
