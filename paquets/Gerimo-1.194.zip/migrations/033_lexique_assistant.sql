-- ============================================================
-- Migration 033 — Lexique de l'assistant Gérimo (13/10/2026)
-- - assistant_questions : questions que Gérimo n'a pas comprises, gardées SANS nom ni numéro (remplacés par
--   des repères), pour que l'Admin y réponde ; la réponse validée est ensuite apprise par Gérimo.
-- - dictee_corrections : ce que la dictée entend mal (« Jérimo ») et ce qu'il faut comprendre (« Gérimo »).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS assistant_questions (
    id          SERIAL PRIMARY KEY,
    texte       VARCHAR(300) NOT NULL,
    cle         VARCHAR(300) NOT NULL UNIQUE,         -- texte simplifié : une même question n'est gardée qu'une fois
    nb          INTEGER NOT NULL DEFAULT 1,           -- nombre de fois qu'elle a été posée
    profils     VARCHAR(80) NOT NULL DEFAULT '',      -- profils qui l'ont posée (Admin, Caisse…)
    premiere    TIMESTAMP NOT NULL DEFAULT NOW(),
    derniere    TIMESTAMP NOT NULL DEFAULT NOW(),
    statut      VARCHAR(12) NOT NULL DEFAULT 'nouvelle' CHECK (statut IN ('nouvelle', 'repondue', 'ignoree')),
    reponse     TEXT,
    etiquette   VARCHAR(30) CHECK (etiquette IS NULL OR etiquette IN ('orienter : Comptable', 'orienter : Caisse')),
    traite_par  INTEGER REFERENCES utilisateurs(id) ON DELETE SET NULL,
    traite_le   TIMESTAMP
);

CREATE TABLE IF NOT EXISTS dictee_corrections (
    id       SERIAL PRIMARY KEY,
    entendu  VARCHAR(80) NOT NULL UNIQUE,
    corrige  VARCHAR(120) NOT NULL,
    cree_le  TIMESTAMP NOT NULL DEFAULT NOW()
);

INSERT INTO dictee_corrections (entendu, corrige) VALUES
    ('jérimo', 'Gérimo'), ('jerimo', 'Gérimo'), ('gérémo', 'Gérimo'), ('geremo', 'Gérimo'), ('gérimot', 'Gérimo'),
    ('jérémo', 'Gérimo'), ('géri mot', 'Gérimo')
ON CONFLICT (entendu) DO NOTHING;
