-- ============================================================
-- Migration 031 — Gérimo vendu à d'autres entreprises : aucune identité par défaut (12/10/2026).
-- Elle recopiait l'identité d'origine dans les installations existantes ; depuis le 13/10/2026 (migration 032),
-- chaque entreprise saisit la sienne dans « Mon entreprise » : il ne reste que la marque « faite ».
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

INSERT INTO parametres (cle, valeur, modifie_le) VALUES ('migration_031_faite', 'oui', NOW())
ON CONFLICT (cle) DO NOTHING;
