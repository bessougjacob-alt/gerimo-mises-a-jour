-- ============================================================
-- Migration 039 — Type de logement « À préciser » (reprise de données), 11/11/2026
-- Une agence qui passe à Gérimo n'a pas toujours le temps de donner le type de chaque logement :
-- l'import les crée en « À préciser », et le type est corrigé plus tard sur la fiche du logement.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TYPE type_logement ADD VALUE IF NOT EXISTS 'À préciser';
