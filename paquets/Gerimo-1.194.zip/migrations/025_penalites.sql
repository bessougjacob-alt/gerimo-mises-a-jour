-- ============================================================
-- Migration 025 — Pénalités de retard, 07/10/2026
-- Part de l'encaissement qui correspond à une pénalité de retard (réglages : Paramètres → Réglages).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE encaissements ADD COLUMN IF NOT EXISTS montant_penalite NUMERIC(12, 2) NOT NULL DEFAULT 0;
