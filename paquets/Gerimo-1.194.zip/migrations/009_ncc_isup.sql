-- ============================================================
-- Migration 009 — sans objet depuis le 13/10/2026 (aucune identité d'entreprise écrite dans le logiciel :
-- le RCCM et le NCC se saisissent dans Paramètres → Réglages → « Mon entreprise »)
-- ============================================================
SELECT 1;
