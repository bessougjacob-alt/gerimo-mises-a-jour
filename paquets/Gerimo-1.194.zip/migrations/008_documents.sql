-- ============================================================
-- Migration 008 — Documents générés (étape 5)
-- Un reçu (ou une quittance) est rattaché à son paiement et n'est généré
-- qu'une fois : on réimprime toujours le même fichier.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================

ALTER TABLE documents ADD COLUMN IF NOT EXISTS paiement_id INTEGER REFERENCES paiements(id);
ALTER TABLE documents ADD COLUMN IF NOT EXISTS genere_par INTEGER REFERENCES utilisateurs(id);

-- un seul document de chaque type par paiement
CREATE UNIQUE INDEX IF NOT EXISTS uq_documents_paiement_type
  ON documents(paiement_id, type_document) WHERE paiement_id IS NOT NULL;
