-- ============================================================
-- Migration 013 — Vente directe / Vente indirecte (demande du 02/10/2026)
-- (les nouveaux libellés sont utilisés dans la migration 014 : PostgreSQL
--  interdit d'utiliser un libellé dans la transaction qui le crée)
-- ============================================================

ALTER TYPE type_operation_av ADD VALUE IF NOT EXISTS 'Vente directe';
ALTER TYPE type_operation_av ADD VALUE IF NOT EXISTS 'Vente indirecte';
