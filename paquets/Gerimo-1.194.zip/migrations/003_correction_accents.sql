-- ============================================================
-- Migration 003 — Correction des accents dans les listes (ENUM)
-- schema.sql avait été exécuté avec un mauvais encodage : « Cité » était
-- enregistré « CitÃ© », etc. On renomme chaque libellé abîmé (aucune
-- donnée supprimée). Peut être exécutée plusieurs fois sans risque.
-- ============================================================

DO $$
DECLARE
  r record;
BEGIN
  FOR r IN SELECT * FROM (VALUES
    ('mode_paiement', 'EspÃ¨ce', 'Espèce'),
    ('mode_paiement', 'ChÃ¨que', 'Chèque'),
    ('motif_paiement', 'RÃ¨glement total', 'Règlement total'),
    ('statut_contrat', 'ExpirÃ©', 'Expiré'),
    ('statut_contrat', 'RÃ©siliÃ©', 'Résilié'),
    ('statut_contrat', 'RenouvelÃ©', 'Renouvelé'),
    ('statut_impayes', 'Ã€ risque', 'À risque'),
    ('statut_impayes', 'RÃ©gularisÃ©', 'Régularisé'),
    ('statut_logement', 'OccupÃ©', 'Occupé'),
    ('statut_logement', 'RÃ©servÃ©', 'Réservé'),
    ('statut_paiement', 'PayÃ©', 'Payé'),
    ('statut_paiement', 'AnnulÃ©', 'Annulé'),
    ('statut_paiement', 'ImpayÃ©', 'Impayé'),
    ('statut_paiement', 'RemboursÃ©', 'Remboursé'),
    ('type_batiment', 'CitÃ©', 'Cité'),
    ('type_batiment', 'RÃ©sidence', 'Résidence'),
    ('type_contrat', 'Location meublÃ©e', 'Location meublée'),
    ('type_contrat', 'Courte durÃ©e', 'Courte durée'),
    ('type_contrat', 'Gestion immobiliÃ¨re', 'Gestion immobilière'),
    ('type_document', 'ReÃ§u de paiement', 'Reçu de paiement'),
    ('type_document', 'DÃ©charge', 'Décharge'),
    ('type_logement', '2 piÃ¨ces', '2 pièces'),
    ('type_logement', '3 piÃ¨ces', '3 pièces'),
    ('type_logement', '4 piÃ¨ces', '4 pièces'),
    ('type_logement', '5 piÃ¨ces', '5 pièces'),
    ('type_logement', '6 piÃ¨ces', '6 pièces'),
    ('type_logement', '7 piÃ¨ces', '7 pièces'),
    ('type_logement', '8 piÃ¨ces', '8 pièces'),
    ('type_logement', 'Villa de plus de 8 piÃ¨ces', 'Villa de plus de 8 pièces'),
    ('usage_bien', 'Mixte (habitation + activitÃ©s)', 'Mixte (habitation + activités)'),
    ('usage_bien', 'Courte durÃ©e', 'Courte durée')
  ) AS v(type_enum, ancien, nouveau)
  LOOP
    IF EXISTS (SELECT 1 FROM pg_enum e JOIN pg_type t ON t.oid = e.enumtypid
               WHERE t.typname = r.type_enum AND e.enumlabel = r.ancien) THEN
      EXECUTE format('ALTER TYPE %I RENAME VALUE %L TO %L', r.type_enum, r.ancien, r.nouveau);
    END IF;
  END LOOP;
END $$;
