-- ============================================================
-- Migration 010 — Historique des messages WhatsApp (étape 6)
-- On note chaque message préparé (on ne peut pas savoir s'il a été
-- réellement envoyé : c'est WhatsApp qui l'envoie). Sert à afficher
-- « Dernier rappel : … » et à éviter les relances en double.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================

CREATE TABLE IF NOT EXISTS messages_whatsapp (
  id                SERIAL PRIMARY KEY,
  type_message      VARCHAR(20) NOT NULL
                    CHECK (type_message IN ('bienvenue', 'rappel', 'confirmation', 'retard', 'expulsion')),
  contrat_id        INTEGER NOT NULL REFERENCES contrats(id),
  paiement_id       INTEGER REFERENCES paiements(id),
  utilisateur_id    INTEGER REFERENCES utilisateurs(id),
  telephone         VARCHAR(30) NOT NULL,
  message           TEXT NOT NULL,
  cree_le           TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_messages_whatsapp_contrat ON messages_whatsapp(contrat_id, type_message);
