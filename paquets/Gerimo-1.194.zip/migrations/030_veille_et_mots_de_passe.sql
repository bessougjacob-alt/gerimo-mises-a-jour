-- ============================================================
-- Migration 030 — Mots de passe personnels et mode veille (veille.py), 12/10/2026
-- Pour que le journal « qui fait quoi » ait un sens :
-- - le mot de passe donné par l'Admin (création du compte, mot de passe oublié) est PROVISOIRE : valable 48 h,
--   il doit être remplacé par l'employé à sa première connexion ;
-- - « mot de passe redonné par l'Admin X le … » est gardé et montré à l'employé ;
-- - mode veille : une session en veille (bouton, Ctrl + L, ou inactivité) ne fait plus rien sans le mot de passe.
-- Les comptes existants, dont le mot de passe a été donné par l'Admin, devront aussi choisir le leur à la
-- prochaine connexion (sauf le premier Admin, créé à l'installation, qui a choisi le sien).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE utilisateurs ADD COLUMN IF NOT EXISTS mdp_provisoire BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE utilisateurs ADD COLUMN IF NOT EXISTS mdp_provisoire_expire_le TIMESTAMP;
ALTER TABLE utilisateurs ADD COLUMN IF NOT EXISTS mdp_redonne_le TIMESTAMP;
ALTER TABLE utilisateurs ADD COLUMN IF NOT EXISTS mdp_redonne_par INTEGER REFERENCES utilisateurs(id) ON DELETE SET NULL;

ALTER TABLE sessions ADD COLUMN IF NOT EXISTS veille BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS derniere_activite TIMESTAMP;
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS veille_minutes INTEGER NOT NULL DEFAULT 20;  -- 0 : jamais automatique
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS essais_reveil INTEGER NOT NULL DEFAULT 0;
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS appareil VARCHAR(40);

-- Une seule fois : les comptes créés par un Admin choisiront leur propre mot de passe
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM parametres WHERE cle = 'migration_030_faite') THEN
        UPDATE utilisateurs SET mdp_provisoire = TRUE
         WHERE id <> (SELECT MIN(id) FROM utilisateurs WHERE role = 'Admin');
        INSERT INTO parametres (cle, valeur, modifie_le) VALUES ('migration_030_faite', 'oui', NOW());
    END IF;
END $$;
