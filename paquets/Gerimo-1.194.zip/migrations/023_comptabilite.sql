-- ============================================================
-- Migration 023 — Précomptabilité, parties 3 et 4 (06/10/2026)
-- Dépenses de fonctionnement (sans bien), TVA sur les dépenses, n° de justificatif,
-- restitution des cautions (avec retenue), compte comptable de chaque compte de trésorerie.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

-- Dépense de fonctionnement de l'entreprise (loyer du bureau, salaires…) : pas de bien concerné
ALTER TABLE depenses ALTER COLUMN cite_id DROP NOT NULL;
ALTER TABLE depenses ADD COLUMN IF NOT EXISTS montant_tva NUMERIC(12,2) NOT NULL DEFAULT 0;  -- TVA comprise dans le montant
ALTER TABLE depenses ADD COLUMN IF NOT EXISTS justificatif VARCHAR(80);                    -- n° de facture ou de reçu

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_depenses_sans_bien') THEN
    ALTER TABLE depenses ADD CONSTRAINT ck_depenses_sans_bien CHECK (cite_id IS NOT NULL OR a_la_charge_de = 'Entreprise');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_depenses_tva') THEN
    ALTER TABLE depenses ADD CONSTRAINT ck_depenses_tva CHECK (montant_tva >= 0 AND montant_tva < montant);
  END IF;
END $$;

-- Restitution de caution au locataire qui part (partie rendue + retenue pour réparations, versée au propriétaire)
ALTER TABLE reversements ADD COLUMN IF NOT EXISTS contrat_id INTEGER REFERENCES contrats(id);
ALTER TABLE reversements ADD COLUMN IF NOT EXISTS retenue NUMERIC(14,2) NOT NULL DEFAULT 0;
ALTER TABLE reversements ADD COLUMN IF NOT EXISTS motif_retenue TEXT;
ALTER TABLE reversements DROP CONSTRAINT IF EXISTS ck_reversements_type;
ALTER TABLE reversements ADD CONSTRAINT ck_reversements_type CHECK (
    (type_reversement = 'Loyers' AND proprietaire_id IS NOT NULL AND achat_vente_id IS NULL) OR
    (type_reversement = 'Vente' AND achat_vente_id IS NOT NULL) OR
    (type_reversement = 'Caution' AND contrat_id IS NOT NULL));
ALTER TABLE reversements DROP CONSTRAINT IF EXISTS ck_reversements_montant;
ALTER TABLE reversements ADD CONSTRAINT ck_reversements_montant CHECK (montant >= 0 AND retenue >= 0 AND montant + retenue > 0);
CREATE INDEX IF NOT EXISTS idx_reversements_contrat ON reversements(contrat_id);

-- Export comptable : numéro du compte SYSCOHADA de chaque caisse, banque ou compte Mobile Money
ALTER TABLE comptes_tresorerie ADD COLUMN IF NOT EXISTS compte_comptable VARCHAR(12);
