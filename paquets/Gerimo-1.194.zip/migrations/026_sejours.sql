-- ============================================================
-- Migration 026 — Location courte durée / meublée (séjours), 07/10/2026
-- Un logement proposé à la nuit a un prix par nuit. Chaque réservation (arrivée, départ, client) peut être
-- réglée en une ou plusieurs fois (acompte puis solde), avec un reçu SEJ-AAAA-NNNNN par versement.
-- La commission de gestion du bien s'applique comme sur les loyers.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE logements ADD COLUMN IF NOT EXISTS prix_nuit NUMERIC(12,2);   -- vide = pas de courte durée

CREATE TABLE IF NOT EXISTS reservations (
    id                 SERIAL PRIMARY KEY,
    numero             VARCHAR(30) UNIQUE NOT NULL,        -- RES-AAAA-NNNN
    logement_id        INTEGER NOT NULL REFERENCES logements(id),
    client_nom         VARCHAR(150) NOT NULL,
    client_telephone   VARCHAR(30),
    client_piece       VARCHAR(80),                        -- CNI, passeport…
    nb_personnes       INTEGER NOT NULL DEFAULT 1,
    date_arrivee       DATE NOT NULL,
    date_depart        DATE NOT NULL,
    prix_nuit          NUMERIC(12,2) NOT NULL,
    remise             NUMERIC(12,2) NOT NULL DEFAULT 0,
    montant_total      NUMERIC(12,2) NOT NULL,
    statut             VARCHAR(12) NOT NULL DEFAULT 'Confirmée',
    notes              TEXT,
    motif_annulation   TEXT,
    cree_par           INTEGER REFERENCES utilisateurs(id),
    cree_le            TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP,
    CONSTRAINT ck_reservations_dates CHECK (date_depart > date_arrivee),
    CONSTRAINT ck_reservations_statut CHECK (statut IN ('Confirmée', 'Arrivé', 'Parti', 'Annulée'))
);
CREATE INDEX IF NOT EXISTS idx_reservations_logement ON reservations(logement_id, date_arrivee);

CREATE TABLE IF NOT EXISTS sejours_paiements (
    id                      SERIAL PRIMARY KEY,
    reservation_id          INTEGER NOT NULL REFERENCES reservations(id),
    numero_recu             VARCHAR(30) UNIQUE NOT NULL,   -- SEJ-AAAA-NNNNN
    date_paiement           DATE NOT NULL,
    montant                 NUMERIC(12,2) NOT NULL,
    mode_paiement           mode_paiement NOT NULL,
    compte_id               INTEGER REFERENCES comptes_tresorerie(id),
    pourcentage_commission  NUMERIC(5,2) NOT NULL DEFAULT 0,
    commission              NUMERIC(12,2) NOT NULL DEFAULT 0,
    montant_reverse         NUMERIC(12,2) NOT NULL DEFAULT 0,
    statut                  VARCHAR(10) NOT NULL DEFAULT 'Payé',
    motif_annulation        TEXT,
    date_annulation         TIMESTAMP,
    encaisse_par            INTEGER REFERENCES utilisateurs(id),
    cree_le                 TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP,
    CONSTRAINT ck_sejours_paiements_montant CHECK (montant > 0),
    CONSTRAINT ck_sejours_paiements_statut CHECK (statut IN ('Payé', 'Annulé'))
);
CREATE INDEX IF NOT EXISTS idx_sejours_paiements_date ON sejours_paiements(date_paiement);

-- Journal des actions (migration 019)
DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['reservations', 'sejours_paiements']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
