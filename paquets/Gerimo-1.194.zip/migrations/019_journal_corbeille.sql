-- Journal « qui a fait quoi » et corbeille (05/10/2026)
--
-- Chaque ajout, modification ou suppression dans les tables de gestion est noté AUTOMATIQUEMENT par la base
-- elle-même (déclencheurs) : impossible d'oublier une action, même en cas d'erreur de programmation.
-- L'utilisateur est transmis par le logiciel au début de chaque transaction (gerimo.utilisateur_id / _nom).
-- Le journal ne peut être ni modifié ni effacé ligne à ligne.
-- Corbeille : une suppression garde la ligne complète (colonne « avant ») ; l'Admin peut la restaurer.
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS journal (
    id              BIGSERIAL PRIMARY KEY,
    quand           TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP,
    utilisateur_id  INTEGER,            -- pas de clé étrangère : le compte peut être supprimé ensuite
    utilisateur_nom VARCHAR(150),
    operation       VARCHAR(12) NOT NULL,  -- INSERT, UPDATE, DELETE, CONNEXION, ECHEC
    table_nom       VARCHAR(60) NOT NULL,
    ligne_id        TEXT,
    avant           JSONB,
    apres           JSONB,
    transaction_id  BIGINT NOT NULL DEFAULT txid_current()
);
CREATE INDEX IF NOT EXISTS journal_quand ON journal (quand DESC);
CREATE INDEX IF NOT EXISTS journal_transaction ON journal (transaction_id);
CREATE INDEX IF NOT EXISTS journal_suppressions ON journal (operation, quand DESC) WHERE operation = 'DELETE';

-- Suppressions déjà restaurées depuis la corbeille
CREATE TABLE IF NOT EXISTS corbeille_restaurations (
    transaction_id BIGINT PRIMARY KEY,
    restaure_le    TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP,
    restaure_par   INTEGER
);

CREATE OR REPLACE FUNCTION journal_ecrire() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
    avant   JSONB;
    apres   JSONB;
    -- colonnes recalculées automatiquement par le logiciel : leur seul changement n'est pas une action
    ignores TEXT[] := ARRAY['mois_impayes_consecutifs', 'modifie_le'];
    uid     TEXT := NULLIF(current_setting('gerimo.utilisateur_id', true), '');
BEGIN
    IF TG_OP <> 'INSERT' THEN avant := to_jsonb(OLD); END IF;
    IF TG_OP <> 'DELETE' THEN apres := to_jsonb(NEW); END IF;
    IF TG_OP = 'UPDATE' AND (avant - ignores) = (apres - ignores) THEN
        RETURN NULL;
    END IF;
    -- les secrets (mot de passe e-mail, clés) ne sont jamais recopiés dans le journal
    IF TG_TABLE_NAME = 'parametres' AND COALESCE(apres->>'cle', avant->>'cle') IN ('smtp_mot_de_passe', 'ia_cle_api', 'maj_jeton') THEN
        IF avant IS NOT NULL THEN avant := jsonb_set(avant, '{valeur}', '"********"'); END IF;
        IF apres IS NOT NULL THEN apres := jsonb_set(apres, '{valeur}', '"********"'); END IF;
    END IF;
    INSERT INTO journal (utilisateur_id, utilisateur_nom, operation, table_nom, ligne_id, avant, apres)
    VALUES (uid::INTEGER, NULLIF(current_setting('gerimo.utilisateur_nom', true), ''), TG_OP, TG_TABLE_NAME,
            COALESCE(apres->>'id', avant->>'id', apres->>'cle', avant->>'cle'), avant, apres);
    RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION journal_proteger() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'Le journal des actions ne peut être ni modifié ni effacé.';
END $$;

DROP TRIGGER IF EXISTS journal_protege ON journal;
CREATE TRIGGER journal_protege BEFORE UPDATE OR DELETE ON journal
    FOR EACH ROW EXECUTE FUNCTION journal_proteger();

-- Tables suivies (les tables techniques recalculées en permanence ne le sont pas :
-- sessions, échéances, impayés, messages WhatsApp préparés, demandes de mot de passe)
DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['utilisateurs', 'gestionnaires_cites', 'proprietaires', 'cites', 'gestionnaires',
                             'contrats_gestion', 'logements', 'parcelles', 'locataires', 'contrats', 'paiements',
                             'encaissements', 'documents', 'depenses', 'achats_ventes', 'pieces_jointes',
                             'etats_des_lieux', 'edl_photos', 'prospects', 'prospects_suivi', 'agenda',
                             'courriers', 'signalements', 'parametres', 'publications']
    LOOP
        IF to_regclass('public.' || t) IS NOT NULL THEN
            EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
            EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                           'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
        END IF;
    END LOOP;
END $$;
