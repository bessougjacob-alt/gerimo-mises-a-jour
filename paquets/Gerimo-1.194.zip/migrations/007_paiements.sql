-- ============================================================
-- Migration 007 — Paiements, encaissements, échéances et impayés (étape 4)
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================

-- Un paiement couvre un ou plusieurs mois complets (période) et a un numéro de reçu
ALTER TABLE paiements ADD COLUMN IF NOT EXISTS numero_recu VARCHAR(30) UNIQUE;
ALTER TABLE paiements ADD COLUMN IF NOT EXISTS periode_debut DATE;       -- 1er du premier mois couvert
ALTER TABLE paiements ADD COLUMN IF NOT EXISTS periode_fin DATE;         -- 1er du dernier mois couvert
ALTER TABLE paiements ADD COLUMN IF NOT EXISTS nb_mois INTEGER;
ALTER TABLE paiements ADD COLUMN IF NOT EXISTS encaisse_par INTEGER REFERENCES utilisateurs(id);
ALTER TABLE paiements ADD COLUMN IF NOT EXISTS date_annulation TIMESTAMP;
ALTER TABLE paiements ADD COLUMN IF NOT EXISTS motif_annulation TEXT;

-- Chaque échéance mensuelle sait quel paiement l'a réglée
ALTER TABLE echeances ADD COLUMN IF NOT EXISTS paiement_id INTEGER REFERENCES paiements(id);

-- Encaissement : % appliqué (pour l'historique) et part de caution (sans commission)
ALTER TABLE encaissements ADD COLUMN IF NOT EXISTS pourcentage_commission NUMERIC(5,2);
ALTER TABLE encaissements ADD COLUMN IF NOT EXISTS montant_caution NUMERIC(12,2) NOT NULL DEFAULT 0;

-- Impayé : rattaché à son contrat et à l'échéance non réglée
ALTER TABLE impayes ADD COLUMN IF NOT EXISTS contrat_id INTEGER REFERENCES contrats(id);
ALTER TABLE impayes ADD COLUMN IF NOT EXISTS echeance_id INTEGER UNIQUE REFERENCES echeances(id);

DO $$
BEGIN
  -- une seule échéance par contrat et par mois
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'uq_echeances_contrat_mois') THEN
    ALTER TABLE echeances ADD CONSTRAINT uq_echeances_contrat_mois UNIQUE (contrat_id, mois_echeance);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_paiements_montant_positif') THEN
    ALTER TABLE paiements ADD CONSTRAINT ck_paiements_montant_positif CHECK (montant > 0);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_echeances_paiement ON echeances(paiement_id);
CREATE INDEX IF NOT EXISTS idx_encaissements_paiement ON encaissements(paiement_id);
CREATE INDEX IF NOT EXISTS idx_impayes_contrat ON impayes(contrat_id);
