-- ============================================================
-- Migration 029 — Argent encaissé hors réseau remis à la caisse (hors_reseau.py), 08/10/2026
-- Un agent qui encaisse hors réseau garde l'argent sur lui. Au retour du serveur, son encaissement devient un vrai
-- reçu ; la Caisse confirme ensuite « argent reçu » quand il lui remet la somme (sans rien ressaisir).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE operations_hors_reseau ADD COLUMN IF NOT EXISTS argent_recu_le TIMESTAMP;
ALTER TABLE operations_hors_reseau ADD COLUMN IF NOT EXISTS argent_recu_par INTEGER REFERENCES utilisateurs(id);
