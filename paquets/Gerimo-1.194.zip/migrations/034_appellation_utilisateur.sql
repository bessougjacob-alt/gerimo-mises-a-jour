-- ============================================================
-- Migration 034 — Comment l'assistant Gérimo appelle chaque utilisateur (14/10/2026)
-- appellation : « Monsieur BESSOU », « Awa »… (vide = le prénom, deviné dans le nom complet)
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';
ALTER TABLE utilisateurs ADD COLUMN IF NOT EXISTS appellation VARCHAR(80);
