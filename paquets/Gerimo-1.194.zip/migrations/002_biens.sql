-- ============================================================
-- Migration 002 — Biens (étape 2)
-- Lien Gestionnaire ↔ cités + règles de cohérence sur les logements
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================

-- Cités dont un compte Gestionnaire a la charge (il ne voit que celles-ci)
CREATE TABLE IF NOT EXISTS gestionnaires_cites (
  utilisateur_id    INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
  cite_id           INTEGER NOT NULL REFERENCES cites(id) ON DELETE CASCADE,
  PRIMARY KEY (utilisateur_id, cite_id)
);

CREATE INDEX IF NOT EXISTS idx_gestionnaires_cites_cite ON gestionnaires_cites(cite_id);

DO $$
BEGIN
  -- Pas deux logements avec le même numéro dans une même cité
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'uq_logements_cite_numero') THEN
    ALTER TABLE logements ADD CONSTRAINT uq_logements_cite_numero UNIQUE (cite_id, numero_logement);
  END IF;
  -- Un loyer est toujours positif
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_logements_loyer_positif') THEN
    ALTER TABLE logements ADD CONSTRAINT ck_logements_loyer_positif CHECK (loyer > 0);
  END IF;
END $$;
