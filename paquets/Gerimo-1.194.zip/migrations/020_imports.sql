-- Reprise des données d'un ancien fichier Excel ou d'un autre logiciel (05/10/2026)
-- Chaque import est noté ici (résumé chiffré uniquement : le fichier du client n'est jamais conservé).
-- Les lignes créées sont retrouvées grâce au journal (même transaction) : un import peut être annulé.
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS imports (
    id             SERIAL PRIMARY KEY,
    quand          TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP,
    par            INTEGER REFERENCES utilisateurs(id),
    source         VARCHAR(200) NOT NULL,      -- nom du fichier ou de la base d'origine
    resume         JSONB NOT NULL DEFAULT '{}',
    transaction_id BIGINT NOT NULL,
    annule_le      TIMESTAMP,
    annule_par     INTEGER REFERENCES utilisateurs(id)
);
