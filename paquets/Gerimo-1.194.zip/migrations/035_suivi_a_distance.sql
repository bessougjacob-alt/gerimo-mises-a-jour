-- ============================================================
-- Migration 035 — Suivi à distance par l'éditeur (19/10/2026)
-- File d'attente des informations envoyées au maintenancier (suivi.py) : « contact » du jour
-- (nombre d'utilisateurs, ville, version) et rapports de bugs. Une ligne reste ici tant qu'Internet
-- manque ; une fois envoyée, elle est gardée 30 jours (pour ne pas renvoyer deux fois le même bug).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';
CREATE TABLE IF NOT EXISTS suivi_envois (
    id            SERIAL PRIMARY KEY,
    genre         VARCHAR(20) NOT NULL,          -- contact | bug
    contenu       JSONB NOT NULL,
    empreinte     VARCHAR(64),                   -- même bug = même empreinte (compté, pas renvoyé)
    nb            INTEGER NOT NULL DEFAULT 1,
    cree_le       TIMESTAMP NOT NULL DEFAULT NOW(),
    essais        INTEGER NOT NULL DEFAULT 0,
    dernier_essai TIMESTAMP,
    envoye_le     TIMESTAMP
);
CREATE INDEX IF NOT EXISTS suivi_envois_attente ON suivi_envois (envoye_le, id);
CREATE INDEX IF NOT EXISTS suivi_envois_empreinte ON suivi_envois (empreinte);
