-- ============================================================
-- Migration 021 — Précomptabilité, partie 1 : trésorerie (06/10/2026)
-- Comptes d'argent (caisses, banques, Mobile Money) en nombre libre, transferts entre comptes,
-- arrêtés de caisse, et profil « Comptable ».
-- Les entrées et sorties viennent des opérations déjà saisies (paiements, dépenses, achats/ventes) :
-- rien n'est saisi deux fois.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

-- Profil Comptable : consulte les finances, tient la trésorerie
ALTER TYPE role_utilisateur ADD VALUE IF NOT EXISTS 'Comptable';

CREATE TABLE IF NOT EXISTS comptes_tresorerie (
    id              SERIAL PRIMARY KEY,
    nom             VARCHAR(80) NOT NULL UNIQUE,         -- ex : Caisse principale, Wave, Banque Atlantique
    type_compte     VARCHAR(20) NOT NULL,
    numero          VARCHAR(60),                         -- n° de compte bancaire ou de téléphone
    -- modes de paiement rangés d'office dans ce compte (ex : Espèce → Caisse principale)
    modes_paiement  TEXT[] NOT NULL DEFAULT '{}',
    solde_initial   NUMERIC(14,2) NOT NULL DEFAULT 0,    -- argent présent au démarrage du suivi
    date_ouverture  DATE NOT NULL DEFAULT CURRENT_DATE,  -- les opérations plus anciennes ne comptent pas
    actif           BOOLEAN NOT NULL DEFAULT TRUE,
    cree_le         TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP,
    CONSTRAINT ck_comptes_type CHECK (type_compte IN ('Caisse', 'Banque', 'Mobile Money'))
);

-- Une première caisse, pour que les encaissements en espèces soient rangés dès le départ
INSERT INTO comptes_tresorerie (nom, type_compte, modes_paiement)
SELECT 'Caisse principale', 'Caisse', ARRAY['Espèce']
WHERE NOT EXISTS (SELECT 1 FROM comptes_tresorerie);

-- Compte choisi à la saisie (vide = compte rangé d'office selon le mode de paiement)
ALTER TABLE paiements ADD COLUMN IF NOT EXISTS compte_id INTEGER REFERENCES comptes_tresorerie(id);
ALTER TABLE depenses ADD COLUMN IF NOT EXISTS compte_id INTEGER REFERENCES comptes_tresorerie(id);
ALTER TABLE achats_ventes ADD COLUMN IF NOT EXISTS compte_id INTEGER REFERENCES comptes_tresorerie(id);

-- Transfert d'un compte à l'autre (versement de la caisse à la banque, retrait Wave…)
CREATE TABLE IF NOT EXISTS transferts_tresorerie (
    id               SERIAL PRIMARY KEY,
    numero           VARCHAR(30) UNIQUE NOT NULL,        -- TRF-AAAA-NNNN
    date_transfert   DATE NOT NULL,
    compte_source    INTEGER NOT NULL REFERENCES comptes_tresorerie(id),
    compte_cible     INTEGER NOT NULL REFERENCES comptes_tresorerie(id),
    montant          NUMERIC(14,2) NOT NULL,
    frais            NUMERIC(14,2) NOT NULL DEFAULT 0,   -- frais de retrait ou de virement (payés par la source)
    libelle          VARCHAR(200),
    reference        VARCHAR(80),                        -- n° de bordereau, de transaction…
    saisi_par        INTEGER REFERENCES utilisateurs(id),
    cree_le          TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP,
    CONSTRAINT ck_transferts_montant CHECK (montant > 0),
    CONSTRAINT ck_transferts_frais CHECK (frais >= 0),
    CONSTRAINT ck_transferts_comptes CHECK (compte_source <> compte_cible)
);

-- Arrêté de caisse : argent réellement compté comparé au solde calculé par le logiciel
CREATE TABLE IF NOT EXISTS arretes_caisse (
    id               SERIAL PRIMARY KEY,
    compte_id        INTEGER NOT NULL REFERENCES comptes_tresorerie(id),
    date_arrete      DATE NOT NULL,
    solde_calcule    NUMERIC(14,2) NOT NULL,
    solde_compte     NUMERIC(14,2) NOT NULL,             -- argent compté (ou solde du relevé)
    ecart            NUMERIC(14,2) NOT NULL,             -- compté − calculé (négatif = il manque de l'argent)
    billetage        JSONB NOT NULL DEFAULT '{}',        -- nombre de billets et pièces (facultatif)
    observation      TEXT,
    saisi_par        INTEGER REFERENCES utilisateurs(id),
    cree_le          TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP,
    CONSTRAINT uq_arrete_compte_jour UNIQUE (compte_id, date_arrete)
);

CREATE INDEX IF NOT EXISTS idx_transferts_date ON transferts_tresorerie(date_transfert);
CREATE INDEX IF NOT EXISTS idx_paiements_date ON paiements(date_paiement);

-- Journal des actions (migration 019) : les nouvelles tables sont suivies elles aussi
DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['comptes_tresorerie', 'transferts_tresorerie', 'arretes_caisse']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
