-- ============================================================
-- Migration 014 — Vente indirecte : propriétaire vendeur et commission
-- - Vente directe   : ISUP représente légalement le propriétaire (pas de mention du propriétaire).
-- - Vente indirecte : ISUP est intermédiaire ; on note le propriétaire vendeur, la commission
--                     d'intermédiation et qui la paie.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================

-- anciennes ventes : ce sont des ventes directes
UPDATE achats_ventes SET type_operation = 'Vente directe' WHERE type_operation = 'Vente';

ALTER TABLE achats_ventes ADD COLUMN IF NOT EXISTS proprietaire_nom VARCHAR(150);
ALTER TABLE achats_ventes ADD COLUMN IF NOT EXISTS proprietaire_telephone VARCHAR(30);
ALTER TABLE achats_ventes ADD COLUMN IF NOT EXISTS proprietaire_cni VARCHAR(50);
ALTER TABLE achats_ventes ADD COLUMN IF NOT EXISTS commission_montant NUMERIC(14,2) NOT NULL DEFAULT 0;
ALTER TABLE achats_ventes ADD COLUMN IF NOT EXISTS commission_payee_par VARCHAR(10);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_achats_ventes_commission') THEN
    ALTER TABLE achats_ventes ADD CONSTRAINT ck_achats_ventes_commission
      CHECK (commission_montant >= 0 AND commission_montant <= montant);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_achats_ventes_payee_par') THEN
    ALTER TABLE achats_ventes ADD CONSTRAINT ck_achats_ventes_payee_par
      CHECK (commission_payee_par IS NULL OR commission_payee_par IN ('Acheteur', 'Vendeur'));
  END IF;
  -- une vente indirecte a toujours un propriétaire vendeur identifié
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_achats_ventes_indirecte') THEN
    ALTER TABLE achats_ventes ADD CONSTRAINT ck_achats_ventes_indirecte
      CHECK (type_operation <> 'Vente indirecte' OR proprietaire_nom IS NOT NULL);
  END IF;
END $$;
