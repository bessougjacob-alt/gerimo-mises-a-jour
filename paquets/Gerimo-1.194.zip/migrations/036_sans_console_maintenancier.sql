-- ============================================================
-- Migration 036 — Plus rien de la maintenance dans le logiciel des clients (19/10/2026)
-- La console et les alertes du maintenancier ont été retirées de Gérimo : on efface la connexion
-- du maintenancier qui avait pu être gardée (e-mail, jeton chiffré, dernier comptage).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';
DELETE FROM parametres WHERE cle IN ('suivi_maint_email', 'suivi_maint_jeton', 'suivi_maint_etat');
