-- ============================================================
-- Migration 005 — Parcelles (demande du 02/10/2026)
-- « Parcelle » devient un type de bien, avec ses champs dédiés.
-- Une parcelle est rattachée à un bien (table cites), comme un logement.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================

-- Nouveau libellé dans la liste « Type de bien »
ALTER TYPE type_batiment ADD VALUE IF NOT EXISTS 'Parcelle';

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'approbation_parcelle') THEN
    CREATE TYPE approbation_parcelle AS ENUM ('Approuvé', 'Non-approuvé', 'En attente');
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS parcelles (
  id                      SERIAL PRIMARY KEY,
  cite_id                 INTEGER NOT NULL REFERENCES cites(id),
  numero_parcelle         VARCHAR(30) NOT NULL,          -- numéro de lot
  superficie              NUMERIC(12,2) NOT NULL CHECK (superficie > 0),   -- en m²
  situation_geographique  VARCHAR(200),
  documents               TEXT,                          -- ex : ACD, plan de bornage…
  prix_entree             NUMERIC(14,2) CHECK (prix_entree >= 0),
  dernier_prix            NUMERIC(14,2) CHECK (dernier_prix >= 0),
  approbation             approbation_parcelle NOT NULL DEFAULT 'En attente',
  disponible              BOOLEAN NOT NULL DEFAULT TRUE, -- Disponibilité : Oui / Non
  cree_le                 TIMESTAMP NOT NULL DEFAULT now(),
  CONSTRAINT uq_parcelles_cite_numero UNIQUE (cite_id, numero_parcelle)
);

CREATE INDEX IF NOT EXISTS idx_parcelles_cite ON parcelles(cite_id);
