-- ============================================================
-- Migration 012 — Achats / Ventes de biens (étape 7)
-- Numéro d'opération, parcelle ou bien hors gestion, pièces d'identité,
-- documents (facture, reçu, décharge) rattachés à l'opération.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================

ALTER TABLE achats_ventes ADD COLUMN IF NOT EXISTS numero VARCHAR(30) UNIQUE;          -- AV-AAAA-NNNN
ALTER TABLE achats_ventes ADD COLUMN IF NOT EXISTS parcelle_id INTEGER REFERENCES parcelles(id);
ALTER TABLE achats_ventes ADD COLUMN IF NOT EXISTS designation TEXT;                    -- description du bien
ALTER TABLE achats_ventes ADD COLUMN IF NOT EXISTS partie_cni VARCHAR(50);
ALTER TABLE achats_ventes ADD COLUMN IF NOT EXISTS observation TEXT;
ALTER TABLE achats_ventes ADD COLUMN IF NOT EXISTS saisi_par INTEGER REFERENCES utilisateurs(id);
-- les documents sont désormais dans la table documents (plusieurs par opération)
ALTER TABLE achats_ventes ALTER COLUMN type_document DROP NOT NULL;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_achats_ventes_montant_positif') THEN
    ALTER TABLE achats_ventes ADD CONSTRAINT ck_achats_ventes_montant_positif CHECK (montant > 0);
  END IF;
END $$;

ALTER TABLE documents ADD COLUMN IF NOT EXISTS achat_vente_id INTEGER REFERENCES achats_ventes(id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_documents_achat_vente_type
  ON documents(achat_vente_id, type_document) WHERE achat_vente_id IS NOT NULL;
