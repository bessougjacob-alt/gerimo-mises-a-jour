-- ============================================================
-- Migration 006 — Commission ISUP par bien (décision du 02/10/2026)
-- L'Admin saisit le % à l'enregistrement de chaque bien. Il est stocké dans
-- contrats_gestion (mandat ISUP ↔ propriétaire ↔ bien), avec historique :
-- un changement de % crée une nouvelle ligne datée.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================

-- La fiche de l'entreprise mandataire (ISUP SARL chez ISUP, créée ici avant le 12/10/2026) est désormais créée au
-- premier mandat avec le nom de « Mon entreprise » (biens.isup_mandataire) : rien d'ISUP chez un nouveau client.

DO $$
BEGIN
  -- un pourcentage est compris entre 0 et 100 (0 % pour les biens appartenant à ISUP)
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_contrats_gestion_pourcentage') THEN
    ALTER TABLE contrats_gestion ADD CONSTRAINT ck_contrats_gestion_pourcentage
      CHECK (pourcentage_commission BETWEEN 0 AND 100);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_contrats_gestion_cite ON contrats_gestion(cite_id);
