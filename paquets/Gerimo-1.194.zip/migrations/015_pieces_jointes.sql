-- Pièces jointes (CNI, passeport, attestation…) des propriétaires et locataires,
-- e-mail (envoi des courriers) et fonction des utilisateurs (carte de visite).
SET client_encoding = 'UTF8';

ALTER TABLE proprietaires ADD COLUMN IF NOT EXISTS email VARCHAR(150);
ALTER TABLE locataires ADD COLUMN IF NOT EXISTS email VARCHAR(150);

-- Fonction affichée sur la carte de visite : fixée par l'Admin, non modifiable par l'utilisateur
ALTER TABLE utilisateurs ADD COLUMN IF NOT EXISTS fonction VARCHAR(120);
UPDATE utilisateurs SET fonction = 'Gérant & Directeur des opérations'
 WHERE role = 'Admin' AND fonction IS NULL AND nom_complet ILIKE 'BESSOU%';

CREATE TABLE IF NOT EXISTS pieces_jointes (
    id              SERIAL PRIMARY KEY,
    proprietaire_id INTEGER REFERENCES proprietaires(id) ON DELETE CASCADE,
    locataire_id    INTEGER REFERENCES locataires(id) ON DELETE CASCADE,
    type_piece      VARCHAR(40)  NOT NULL DEFAULT 'CNI',
    chemin_fichier  VARCHAR(300) NOT NULL,   -- relatif au dossier documents/
    nom_fichier     VARCHAR(200) NOT NULL,
    type_mime       VARCHAR(60)  NOT NULL,
    taille          INTEGER,
    ajoute_par      INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT now(),
    -- une pièce appartient soit à un propriétaire, soit à un locataire
    CONSTRAINT piece_un_seul_titulaire CHECK ((proprietaire_id IS NULL) <> (locataire_id IS NULL))
);
CREATE INDEX IF NOT EXISTS pieces_jointes_proprietaire ON pieces_jointes (proprietaire_id);
CREATE INDEX IF NOT EXISTS pieces_jointes_locataire ON pieces_jointes (locataire_id);
