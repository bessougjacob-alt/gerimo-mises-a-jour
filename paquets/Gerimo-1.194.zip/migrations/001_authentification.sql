-- ============================================================
-- Migration 001 — Authentification (étape 1)
-- Sessions de connexion + demandes de réinitialisation de mot de passe
-- Peut être exécutée plusieurs fois sans risque (IF NOT EXISTS)
-- ============================================================

-- Une ligne par connexion ouverte. Le jeton est stocké haché (SHA-256) :
-- même en lisant la base, on ne peut pas se faire passer pour un utilisateur.
CREATE TABLE IF NOT EXISTS sessions (
  id                SERIAL PRIMARY KEY,
  jeton_hache       CHAR(64) NOT NULL UNIQUE,
  utilisateur_id    INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
  cree_le           TIMESTAMP NOT NULL DEFAULT now(),
  expire_le         TIMESTAMP NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sessions_utilisateur ON sessions(utilisateur_id);

-- « Mot de passe oublié ? » : la demande est enregistrée, l'Admin la traite
-- (écran Utilisateurs, étape 9).
CREATE TABLE IF NOT EXISTS demandes_reinitialisation (
  id                SERIAL PRIMARY KEY,
  identifiant       VARCHAR(80) NOT NULL,
  utilisateur_id    INTEGER REFERENCES utilisateurs(id) ON DELETE CASCADE,
  traitee           BOOLEAN NOT NULL DEFAULT FALSE,
  cree_le           TIMESTAMP NOT NULL DEFAULT now()
);
