-- ============================================================
-- Migration 027 — Téléphones autorisés à travailler hors réseau (hors_reseau.py), 08/10/2026
-- Chaque téléphone reçoit, à la connexion de son utilisateur, une clé qui lui permet de rafraîchir en
-- arrière-plan sa copie des données (et rien d'autre), même application fermée. L'Admin voit la liste
-- et peut retirer un téléphone (perdu, employé parti) : sa copie est alors effacée au prochain contact.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS appareils_hors_reseau (
    id                 SERIAL PRIMARY KEY,
    code_appareil      VARCHAR(64) UNIQUE NOT NULL,      -- tiré au hasard par le téléphone, une fois
    nom                VARCHAR(120) NOT NULL,            -- modèle du téléphone (ex. « Samsung SM-A155F »)
    utilisateur_id     INTEGER NOT NULL REFERENCES utilisateurs(id),
    jeton_hache        CHAR(64) UNIQUE NOT NULL,         -- la clé elle-même n'est jamais gardée en base
    cree_le            TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP,
    derniere_copie_le  TIMESTAMP,
    retire_le          TIMESTAMP,                        -- rempli = téléphone retiré par l'Admin
    retire_par         INTEGER REFERENCES utilisateurs(id)
);
CREATE INDEX IF NOT EXISTS idx_appareils_hors_reseau_utilisateur ON appareils_hors_reseau(utilisateur_id);

-- Journal des actions (migration 019) : autorisation et retrait d'un téléphone ; pas chaque rafraîchissement de
-- la copie (toutes les 15 minutes), qui remplirait le journal pour rien
DROP TRIGGER IF EXISTS journal_actions ON appareils_hors_reseau;
CREATE TRIGGER journal_actions AFTER INSERT OR DELETE ON appareils_hors_reseau
    FOR EACH ROW EXECUTE FUNCTION journal_ecrire();
DROP TRIGGER IF EXISTS journal_actions_maj ON appareils_hors_reseau;
CREATE TRIGGER journal_actions_maj AFTER UPDATE ON appareils_hors_reseau
    FOR EACH ROW WHEN (OLD.utilisateur_id IS DISTINCT FROM NEW.utilisateur_id OR OLD.retire_le IS DISTINCT FROM NEW.retire_le)
    EXECUTE FUNCTION journal_ecrire();
