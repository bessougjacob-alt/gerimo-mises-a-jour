-- ============================================================
-- Migration 038 — Début du suivi d'un contrat dans Gérimo (reprise de données), 11/11/2026
-- Un locataire déjà en place quand l'agence passe à Gérimo garde sa vraie date d'entrée, mais Gérimo ne compte ses
-- loyers qu'à partir de « suivi_depuis » (1er du mois) : les mois d'avant sont réglés dans l'ancien fichier, sauf
-- l'arriéré repris. Vide = depuis le début du bail (cas normal).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE contrats ADD COLUMN IF NOT EXISTS suivi_depuis DATE;
