-- États des lieux d'entrée et de sortie (pièces, compteurs, clés, photos, signatures).
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS etats_des_lieux (
    id                  SERIAL PRIMARY KEY,
    numero              VARCHAR(30) UNIQUE NOT NULL,          -- EDL-2026-0001
    contrat_id          INTEGER NOT NULL REFERENCES contrats(id),
    type_edl            VARCHAR(10) NOT NULL CHECK (type_edl IN ('Entrée', 'Sortie')),
    date_edl            DATE NOT NULL,
    pieces              JSONB NOT NULL DEFAULT '[]',          -- [{piece, elements: [{element, etat, observation}]}]
    compteurs           JSONB NOT NULL DEFAULT '{}',          -- électricité (CIE), eau (SODECI)
    nb_cles             INTEGER NOT NULL DEFAULT 0,
    observations        TEXT,
    retenues            NUMERIC(12,2) NOT NULL DEFAULT 0,     -- sortie : retenues sur la caution
    statut              VARCHAR(10) NOT NULL DEFAULT 'Brouillon' CHECK (statut IN ('Brouillon', 'Signé')),
    signature_locataire TEXT,                                 -- image PNG (data URL)
    signature_agent     TEXT,
    signe_le            TIMESTAMP,
    chemin_pdf          VARCHAR(300),
    envoye_le           TIMESTAMP,
    cree_par            INTEGER REFERENCES utilisateurs(id),
    cree_le             TIMESTAMP DEFAULT now(),
    modifie_le          TIMESTAMP,
    CONSTRAINT edl_un_par_type UNIQUE (contrat_id, type_edl),
    CONSTRAINT edl_retenues_positives CHECK (retenues >= 0)
);

CREATE TABLE IF NOT EXISTS edl_photos (
    id                SERIAL PRIMARY KEY,
    etat_des_lieux_id INTEGER NOT NULL REFERENCES etats_des_lieux(id) ON DELETE CASCADE,
    piece             VARCHAR(80),
    legende           VARCHAR(200),
    chemin_fichier    VARCHAR(300) NOT NULL,
    cree_le           TIMESTAMP DEFAULT now()
);
CREATE INDEX IF NOT EXISTS edl_photos_edl ON edl_photos (etat_des_lieux_id);
