-- ============================================================
-- Migration 037 — Versements partiels sur un loyer (paiements.py), 10/11/2026
-- Arrangement accordé à un locataire en retard : il verse ce qu'il peut. Le versement solde d'abord les mois les
-- plus anciens ; ce qui reste va sur le mois suivant, qui garde un « reste à payer ».
--   ex. loyer 50 000 F, 2 mois dus, 80 000 F versés → 1 mois soldé + 30 000 F sur l'autre (reste 20 000 F).
-- - echeances.montant_verse : ce qui a déjà été versé sur le mois (= le loyer quand le mois est soldé) ;
-- - echeances.paiement_id reste « le paiement qui a soldé le mois » (vide tant que le mois n'est pas soldé) ;
-- - versements_echeances : la part de chaque paiement sur chaque mois, et le reste du mois juste après.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE echeances ADD COLUMN IF NOT EXISTS montant_verse NUMERIC(12, 2) NOT NULL DEFAULT 0;
ALTER TABLE paiements ADD COLUMN IF NOT EXISTS versement_partiel BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS versements_echeances (
    id           SERIAL PRIMARY KEY,
    echeance_id  INTEGER NOT NULL REFERENCES echeances(id) ON DELETE CASCADE,
    paiement_id  INTEGER NOT NULL REFERENCES paiements(id) ON DELETE CASCADE,
    montant      NUMERIC(12, 2) NOT NULL CHECK (montant > 0),
    reste_apres  NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (reste_apres >= 0),
    cree_le      TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_versements_echeance ON versements_echeances (echeance_id);
CREATE INDEX IF NOT EXISTS idx_versements_paiement ON versements_echeances (paiement_id);

-- Les mois déjà réglés (toujours en entier jusqu'ici) : un versement du montant du loyer
INSERT INTO versements_echeances (echeance_id, paiement_id, montant, reste_apres)
SELECT e.id, e.paiement_id, e.montant_loyer, 0
  FROM echeances e
 WHERE e.paiement_id IS NOT NULL AND e.montant_loyer > 0
   AND NOT EXISTS (SELECT 1 FROM versements_echeances v WHERE v.echeance_id = e.id);

UPDATE echeances SET montant_verse = montant_loyer
 WHERE paiement_id IS NOT NULL AND montant_verse <> montant_loyer;
