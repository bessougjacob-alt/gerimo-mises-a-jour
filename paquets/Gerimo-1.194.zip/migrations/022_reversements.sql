-- ============================================================
-- Migration 022 — Précomptabilité, partie 2 : reversements (06/10/2026)
-- Argent réellement versé aux propriétaires (loyers nets) et aux vendeurs des ventes faites en intermédiaire,
-- carnet de RIB des bénéficiaires (propriétaires, employés, fournisseurs…).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

-- Carnet de RIB : coordonnées bancaires (ou Mobile Money) des personnes que l'entreprise paie
CREATE TABLE IF NOT EXISTS beneficiaires (
    id               SERIAL PRIMARY KEY,
    nom              VARCHAR(150) NOT NULL,
    categorie        VARCHAR(20) NOT NULL DEFAULT 'Propriétaire',
    proprietaire_id  INTEGER REFERENCES proprietaires(id) ON DELETE SET NULL,
    banque_nom       VARCHAR(120),
    titulaire        VARCHAR(150),
    banque_code      VARCHAR(5),
    banque_guichet   VARCHAR(5),
    banque_compte    VARCHAR(12),
    banque_cle_rib   VARCHAR(2),
    iban             VARCHAR(34),
    bic              VARCHAR(11),
    mobile_money     VARCHAR(30),                         -- n° Wave, Orange Money… (facultatif)
    observation      TEXT,
    actif            BOOLEAN NOT NULL DEFAULT TRUE,
    cree_le          TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP,
    CONSTRAINT ck_beneficiaires_categorie CHECK (categorie IN ('Propriétaire', 'Employé', 'Fournisseur', 'Autre'))
);

-- Reversement : argent versé à un propriétaire (loyers nets) ou au vendeur d'une vente faite en intermédiaire
CREATE TABLE IF NOT EXISTS reversements (
    id                SERIAL PRIMARY KEY,
    numero            VARCHAR(30) UNIQUE NOT NULL,        -- REV-AAAA-NNNN
    type_reversement  VARCHAR(10) NOT NULL,               -- Loyers | Vente
    proprietaire_id   INTEGER REFERENCES proprietaires(id),
    achat_vente_id    INTEGER REFERENCES achats_ventes(id),
    beneficiaire_nom  VARCHAR(150) NOT NULL,              -- nom au moment du versement (pour les documents)
    beneficiaire_id   INTEGER REFERENCES beneficiaires(id) ON DELETE SET NULL,   -- RIB utilisé (virement)
    date_reversement  DATE NOT NULL,
    montant           NUMERIC(14,2) NOT NULL,
    reste_apres       NUMERIC(14,2) NOT NULL DEFAULT 0,   -- reste à verser juste après (figé pour le bordereau)
    compte_id         INTEGER NOT NULL REFERENCES comptes_tresorerie(id),
    mode_paiement     mode_paiement NOT NULL,
    reference         VARCHAR(80),
    observation       TEXT,
    saisi_par         INTEGER REFERENCES utilisateurs(id),
    cree_le           TIMESTAMP NOT NULL DEFAULT LOCALTIMESTAMP,
    CONSTRAINT ck_reversements_montant CHECK (montant > 0),
    CONSTRAINT ck_reversements_type CHECK (
        (type_reversement = 'Loyers' AND proprietaire_id IS NOT NULL AND achat_vente_id IS NULL) OR
        (type_reversement = 'Vente' AND achat_vente_id IS NOT NULL))
);

CREATE INDEX IF NOT EXISTS idx_reversements_proprietaire ON reversements(proprietaire_id);
CREATE INDEX IF NOT EXISTS idx_reversements_vente ON reversements(achat_vente_id);
CREATE INDEX IF NOT EXISTS idx_reversements_date ON reversements(date_reversement);

-- Journal des actions (migration 019)
DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['beneficiaires', 'reversements']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
