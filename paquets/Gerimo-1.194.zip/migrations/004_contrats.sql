-- ============================================================
-- Migration 004 — Contrats de bail (étape 3)
-- Terme du loyer, résiliation, règles de cohérence
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================

-- Le loyer est payé en début ou en fin de mois, au choix pour chaque bail
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'terme_loyer') THEN
    CREATE TYPE terme_loyer AS ENUM ('Début de mois', 'Fin de mois');
  END IF;
END $$;

ALTER TABLE contrats ADD COLUMN IF NOT EXISTS terme_loyer terme_loyer NOT NULL DEFAULT 'Début de mois';

-- Résiliation (toujours manuelle, par l'Admin) : date et motif gardés pour l'historique
ALTER TABLE contrats ADD COLUMN IF NOT EXISTS date_resiliation DATE;
ALTER TABLE contrats ADD COLUMN IF NOT EXISTS motif_resiliation TEXT;

DO $$
BEGIN
  -- Caution : 3 mois maximum (décision du 02/10/2026)
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_contrats_mois_caution') THEN
    ALTER TABLE contrats ADD CONSTRAINT ck_contrats_mois_caution CHECK (mois_caution BETWEEN 0 AND 3);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_contrats_loyer_positif') THEN
    ALTER TABLE contrats ADD CONSTRAINT ck_contrats_loyer_positif CHECK (montant_loyer > 0);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_contrats_dates') THEN
    ALTER TABLE contrats ADD CONSTRAINT ck_contrats_dates CHECK (date_fin IS NULL OR date_fin >= date_debut);
  END IF;
END $$;

-- Un logement ne peut avoir qu'un seul contrat en cours à la fois
-- (« en cours » = tout sauf Expiré et Résilié)
CREATE UNIQUE INDEX IF NOT EXISTS uq_contrat_en_cours_par_logement
  ON contrats(logement_id)
  WHERE statut_contrat IN ('Actif', 'Renouvelé', 'Suspendu', 'En attente');
