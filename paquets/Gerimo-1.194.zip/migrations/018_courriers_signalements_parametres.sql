-- Courriers (révision de loyer, avenant au bail), problèmes signalés sur les biens,
-- paramètres du logiciel (réseaux sociaux, e-mail) et annonces publiées.
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS courriers (
    id               SERIAL PRIMARY KEY,
    numero           VARCHAR(30) UNIQUE NOT NULL,             -- REV-2026-0001 / AVE-2026-0001
    type_courrier    VARCHAR(30) NOT NULL CHECK (type_courrier IN ('Révision de loyer', 'Avenant au bail')),
    contrat_id       INTEGER NOT NULL REFERENCES contrats(id),
    date_courrier    DATE NOT NULL,
    date_effet       DATE,
    ancien_loyer     NUMERIC(12,2),
    nouveau_loyer    NUMERIC(12,2),
    ancienne_date_fin DATE,
    nouvelle_date_fin DATE,
    objet            VARCHAR(200),
    contenu          TEXT,
    chemin_pdf       VARCHAR(300),
    envois           JSONB NOT NULL DEFAULT '[]',              -- [{canal, date, destinataire}]
    cree_par         INTEGER REFERENCES utilisateurs(id),
    cree_le          TIMESTAMP DEFAULT now(),
    CONSTRAINT courrier_loyer_positif CHECK (nouveau_loyer IS NULL OR nouveau_loyer > 0)
);
CREATE INDEX IF NOT EXISTS courriers_contrat ON courriers (contrat_id);

CREATE TABLE IF NOT EXISTS signalements (
    id              SERIAL PRIMARY KEY,
    cite_id         INTEGER NOT NULL REFERENCES cites(id) ON DELETE CASCADE,
    logement_id     INTEGER REFERENCES logements(id) ON DELETE SET NULL,
    categorie       VARCHAR(40) NOT NULL,
    urgence         VARCHAR(10) NOT NULL DEFAULT 'Normale' CHECK (urgence IN ('Faible', 'Normale', 'Urgente')),
    description     TEXT NOT NULL,
    signale_par     VARCHAR(150),
    statut          VARCHAR(10) NOT NULL DEFAULT 'Ouvert' CHECK (statut IN ('Ouvert', 'En cours', 'Résolu')),
    resolution      TEXT,
    resolu_le       TIMESTAMP,
    photo_chemin    VARCHAR(300),
    cree_par        INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS parametres (
    cle        VARCHAR(60) PRIMARY KEY,
    valeur     TEXT,
    modifie_le TIMESTAMP DEFAULT now()
);
INSERT INTO parametres (cle, valeur) VALUES
    ('facebook_groupe_nom', ''),   -- valeurs d'ISUP : migration 031 (installations d'avant le 12/10/2026)
    ('facebook_groupe_url', ''),
    ('facebook_page_url', ''),
    ('whatsapp_numero', ''),
    ('whatsapp_groupe_lien', ''),
    ('site_web', ''),
    ('smtp_serveur', ''), ('smtp_port', '587'), ('smtp_utilisateur', ''), ('smtp_mot_de_passe', ''),
    ('email_expediteur', ''),
    ('email_imprimeur', ''), ('whatsapp_imprimeur', '')
ON CONFLICT (cle) DO NOTHING;

CREATE TABLE IF NOT EXISTS publications (
    id         SERIAL PRIMARY KEY,
    titre      VARCHAR(200) NOT NULL,
    texte      TEXT NOT NULL,
    canal      VARCHAR(30) NOT NULL,
    cree_par   INTEGER REFERENCES utilisateurs(id),
    cree_le    TIMESTAMP DEFAULT now()
);
