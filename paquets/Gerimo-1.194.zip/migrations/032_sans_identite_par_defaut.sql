-- ============================================================
-- Migration 032 — Aucune identité d'entreprise par défaut dans la base (demande de Boss, 13/10/2026)
-- Chaque entreprise cliente saisit la sienne dans Paramètres → Réglages → « Mon entreprise » (ISUP comprise,
-- qui est cliente du logiciel comme les autres) :
-- - une seule fois : sur une installation qui porte encore l'identité d'origine (nom, RCCM, NCC, téléphone ou
--   site d'ISUP), toute l'identité est vidée — entreprise, contacts, réseaux sociaux, banque, compte d'envoi des
--   e-mails — en attente des vraies informations, saisies ensuite par l'Admin (elles ne seront plus touchées) ;
-- - les dépenses « à la charge de l'entreprise » s'enregistrent « Entreprise » (et non plus un nom de société) ;
-- - la colonne de commission des encaissements s'appelle commission_entreprise ;
-- - le mandataire créé d'office prend un nom neutre (« Mon entreprise »).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM parametres WHERE cle = 'migration_032_faite') THEN
        IF EXISTS (SELECT 1 FROM parametres
                   WHERE (cle LIKE 'entreprise\_%' OR cle LIKE 'facebook\_%' OR cle LIKE 'whatsapp\_%'
                          OR cle IN ('site_web', 'email_expediteur', 'smtp_utilisateur'))
                     AND (valeur ILIKE '%isup%' OR valeur ILIKE '%2603076%' OR valeur ILIKE '%CI-ABG-01-2026-B12-00026%'
                          OR valeur ILIKE '%indenie%' OR replace(valeur, ' ', '') LIKE '%0749622566%'
                          OR (cle = 'entreprise_adresse' AND valeur ILIKE '%Îlot 528%'))) THEN
            DELETE FROM parametres
            WHERE cle LIKE 'entreprise\_%' OR cle LIKE 'banque\_%'
               OR cle IN ('facebook_groupe_nom', 'facebook_groupe_url', 'facebook_page_url', 'whatsapp_numero',
                          'whatsapp_admin', 'whatsapp_groupe_lien', 'site_web', 'email_expediteur',
                          'smtp_serveur', 'smtp_utilisateur', 'smtp_mot_de_passe');
        END IF;
        INSERT INTO parametres (cle, valeur, modifie_le) VALUES ('migration_032_faite', 'oui', NOW());
    END IF;

    -- Dépenses : « Entreprise » au lieu du nom d'une société
    IF EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_depenses_charge'
               AND pg_get_constraintdef(oid) NOT LIKE '%''Entreprise''%') THEN
        ALTER TABLE depenses DROP CONSTRAINT ck_depenses_charge;
    END IF;
    IF EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_depenses_sans_bien'
               AND pg_get_constraintdef(oid) NOT LIKE '%''Entreprise''%') THEN
        ALTER TABLE depenses DROP CONSTRAINT ck_depenses_sans_bien;
    END IF;
    UPDATE depenses SET a_la_charge_de = 'Entreprise' WHERE a_la_charge_de NOT IN ('Propriétaire', 'Entreprise');
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_depenses_charge') THEN
        ALTER TABLE depenses ADD CONSTRAINT ck_depenses_charge CHECK (a_la_charge_de IN ('Propriétaire', 'Entreprise'));
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_depenses_sans_bien') THEN
        ALTER TABLE depenses ADD CONSTRAINT ck_depenses_sans_bien CHECK (cite_id IS NOT NULL OR a_la_charge_de = 'Entreprise');
    END IF;

    -- Encaissements : colonne de la commission
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'encaissements' AND column_name = 'commission_isup') THEN
        ALTER TABLE encaissements RENAME COLUMN commission_isup TO commission_entreprise;
    END IF;

    -- Mandataire créé d'office : nom neutre, sans les numéros d'une société
    UPDATE gestionnaires SET nom = 'Mon entreprise', rccm = NULL, ncc = NULL, adresse = NULL, ville = NULL
    WHERE nom ILIKE 'ISUP%';
END $$;
