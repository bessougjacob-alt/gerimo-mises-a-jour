"""« Déclarer un problème » sur un bien (fuite, panne électrique, toiture, serrure…).

Suivi simple : Ouvert → En cours → Résolu. Les problèmes urgents ou ouverts depuis plus de 7 jours
sont rappelés par l'assistant. Droits : comme le module Biens (Gestionnaire : ses biens).
"""
from datetime import datetime
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from sqlalchemy.orm import Session as SessionDB, selectinload

import fichiers
from commun import Formulaire, Paragraphe, Texte, charger
from models import (Logement, Signalement, Utilisateur, CATEGORIES_PROBLEME, STATUTS_SIGNALEMENT, URGENCES)
from securite import cites_autorisees, exiger_module, get_db, verifier_cite_autorisee

router = APIRouter(prefix="/api")
acces_biens = exiger_module("biens")


class SignalementIn(Formulaire):
    cite_id: int
    logement_id: int | None = None
    categorie: Literal[CATEGORIES_PROBLEME]
    urgence: Literal[URGENCES] = "Normale"
    description: Paragraphe = Field(min_length=3, max_length=2000)
    signale_par: Texte = Field("", max_length=150)
    photo: str | None = None


class StatutIn(Formulaire):
    statut: Literal[STATUTS_SIGNALEMENT]
    resolution: Paragraphe = Field("", max_length=2000)


def signalement_json(s: Signalement) -> dict:
    return {
        "id": s.id, "cite_id": s.cite_id, "cite": s.cite.nom, "logement_id": s.logement_id,
        "logement": s.logement.numero_logement if s.logement else None,
        "categorie": s.categorie, "urgence": s.urgence, "description": s.description,
        "signale_par": s.signale_par or "", "statut": s.statut, "resolution": s.resolution or "",
        "date": s.cree_le.strftime("%d/%m/%Y") if s.cree_le else "",
        "resolu_le": s.resolu_le.strftime("%d/%m/%Y") if s.resolu_le else None,
        "auteur": s.auteur.nom_complet if s.auteur else "",
        "photo": f"/api/signalements/{s.id}/photo" if s.photo_chemin else None,
    }


@router.get("/signalements/options")
def options(utilisateur: Utilisateur = Depends(acces_biens)):
    return {"categories": CATEGORIES_PROBLEME, "urgences": URGENCES, "statuts": STATUTS_SIGNALEMENT}


@router.get("/signalements")
def liste(utilisateur: Utilisateur = Depends(acces_biens), db: SessionDB = Depends(get_db)):
    requete = db.query(Signalement).options(selectinload(Signalement.cite), selectinload(Signalement.logement),
                                            selectinload(Signalement.auteur))
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None:
        requete = requete.filter(Signalement.cite_id.in_(autorisees))
    signalements = requete.order_by(Signalement.statut == "Résolu", Signalement.cree_le.desc()).limit(500).all()
    return [signalement_json(s) for s in signalements]


@router.post("/signalements")
def declarer(d: SignalementIn, utilisateur: Utilisateur = Depends(acces_biens), db: SessionDB = Depends(get_db)):
    verifier_cite_autorisee(utilisateur, d.cite_id)
    if d.logement_id is not None:
        logement = charger(db, Logement, d.logement_id, "Logement introuvable.")
        if logement.cite_id != d.cite_id:
            raise HTTPException(status_code=400, detail="Ce logement n'appartient pas à ce bien.")
    s = Signalement(cite_id=d.cite_id, logement_id=d.logement_id, categorie=d.categorie, urgence=d.urgence,
                    description=d.description, signale_par=d.signale_par or None, cree_par=utilisateur.id)
    if d.photo:
        s.photo_chemin, _, _ = fichiers.enregistrer_fichier(d.photo, "signalements", pdf_autorise=False, cote_max=1600)
    db.add(s)
    db.commit()
    return signalement_json(s)


@router.post("/signalements/{signalement_id}/statut")
def changer_statut(signalement_id: int, d: StatutIn, utilisateur: Utilisateur = Depends(acces_biens),
                   db: SessionDB = Depends(get_db)):
    s = charger(db, Signalement, signalement_id, "Problème introuvable.")
    try:
        verifier_cite_autorisee(utilisateur, s.cite_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Problème introuvable.")
    s.statut = d.statut
    if d.resolution:
        s.resolution = d.resolution
    s.resolu_le = datetime.now() if d.statut == "Résolu" else None
    db.commit()
    return signalement_json(s)


@router.get("/signalements/{signalement_id}/photo")
def photo(signalement_id: int, utilisateur: Utilisateur = Depends(acces_biens), db: SessionDB = Depends(get_db)):
    s = charger(db, Signalement, signalement_id, "Problème introuvable.")
    try:
        verifier_cite_autorisee(utilisateur, s.cite_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Problème introuvable.")
    return fichiers.servir(s.photo_chemin, type_mime="image/jpeg")
