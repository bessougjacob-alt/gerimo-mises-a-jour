"""Recherche globale (barre « Rechercher ici… » en haut de l'écran).

- Cherche dans les biens, logements, parcelles, propriétaires, locataires, contrats et paiements.
- Sans tenir compte des accents ni des majuscules ; plusieurs mots = tous doivent être trouvés.
- Numéro de téléphone : « 0749622566 », « 07 49 62 25 66 » et « +225 07 49… » se valent.
- Quartier / ville : un bien trouvé par son adresse fait aussi remonter ses logements,
  parcelles, locataires, contrats et paiements.
- Droits (vérifiés ici) : Gestionnaire limité à ses biens et sans propriétaires ;
  Caisse limitée aux contrats et paiements (pour encaisser).
"""
import re
import unicodedata

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session as SessionDB, selectinload

from commun import montant
from models import AchatVente, Cite, Contrat, Depense, Locataire, Logement, Paiement, Proprietaire, Utilisateur
from securite import cites_autorisees, get_db, peut_acceder, utilisateur_connecte

router = APIRouter(prefix="/api")
PAR_CATEGORIE = 8  # nombre de résultats affichés par catégorie


def normaliser(texte) -> str:
    """« Séguéla » → « seguela »."""
    t = unicodedata.normalize("NFD", str(texte or ""))
    return "".join(c for c in t if unicodedata.category(c) != "Mn").lower()


def chiffres_tel(telephone) -> str:
    """« +225 07 49 62 25 66 » → « 0749622566 » (indicatif retiré)."""
    c = re.sub(r"\D", "", str(telephone or ""))
    return c[3:] if len(c) > 10 and c.startswith("225") else c


class Requete:
    def __init__(self, q: str):
        self.mots = normaliser(q).split()
        # recherche par téléphone : au moins 4 chiffres et aucune lettre
        self.tel = chiffres_tel(q) if len(re.sub(r"\D", "", q)) >= 4 and not re.search(r"[^\W\d_]", q) else None

    def correspond(self, textes: list, telephones: list = ()) -> bool:
        if self.tel and any(self.tel in chiffres_tel(t) for t in telephones if t):
            return True
        tout = normaliser(" ".join(str(t) for t in textes if t))
        return bool(self.mots) and all(m in tout for m in self.mots)


def _ajouter(resultats: dict, categorie: str, element: dict) -> None:
    groupe = resultats.setdefault(categorie, {"total": 0, "elements": []})
    groupe["total"] += 1
    if len(groupe["elements"]) < PAR_CATEGORIE:
        groupe["elements"].append(element)


@router.get("/recherche")
def recherche(q: str = Query(min_length=1, max_length=100), utilisateur: Utilisateur = Depends(utilisateur_connecte),
              db: SessionDB = Depends(get_db)):
    r = Requete(q)
    role = utilisateur.role.value
    autorisees = cites_autorisees(utilisateur)
    dans_perimetre = (lambda cite_id: True) if autorisees is None else (lambda cite_id: cite_id in autorisees)
    resultats: dict = {}

    def lieu(cite: Cite) -> list:
        """Ce qui décrit un bien : nom, adresse (quartier, ville), propriétaire si autorisé."""
        textes = [cite.nom, cite.adresse]
        if role == "Admin" and cite.proprietaire:
            textes += [cite.proprietaire.nom_complet, cite.proprietaire.ville]
        return textes

    # --- Biens, logements, parcelles (Admin, Gestionnaire) ---
    if peut_acceder(role, "biens"):
        cites = db.query(Cite).options(selectinload(Cite.logements), selectinload(Cite.parcelles),
                                       selectinload(Cite.proprietaire)).order_by(Cite.nom).all()
        for c in (c for c in cites if dans_perimetre(c.id)):
            if r.correspond(lieu(c) + [c.description] + [l.type_batiment for l in c.logements]):
                contenu = f"{len(c.logements)} logement(s)" + (f", {len(c.parcelles)} parcelle(s)" if c.parcelles else "")
                _ajouter(resultats, "Biens", {"titre": c.nom, "detail": " — ".join(filter(None, [contenu, c.adresse])),
                                              "cible": "biens", "filtre": c.nom})
            for l in c.logements:
                if r.correspond(lieu(c) + [f"Logement {l.numero_logement}", l.numero_logement, l.type_logement,
                                           l.type_batiment, l.statut_logement]):
                    _ajouter(resultats, "Logements", {
                        "titre": f"Logement {l.numero_logement} — {c.nom}",
                        "detail": f"{l.type_logement} — Loyer {montant(l.loyer):,} F — {l.statut_logement}".replace(",", " "),
                        "cible": "biens", "filtre": f"Logement {l.numero_logement}"})
            for p in c.parcelles:
                if r.correspond(lieu(c) + [f"Parcelle {p.numero_parcelle}", p.numero_parcelle,
                                           p.situation_geographique, p.documents, p.approbation, "Parcelle"]):
                    _ajouter(resultats, "Parcelles", {
                        "titre": f"Parcelle {p.numero_parcelle} — {c.nom}",
                        "detail": " — ".join(filter(None, [f"{montant(p.superficie)} m²", p.situation_geographique,
                                                           p.approbation])),
                        "cible": "biens", "filtre": f"Parcelle {p.numero_parcelle}"})

    # --- Propriétaires (Admin uniquement) ---
    if peut_acceder(role, "proprietaires"):
        for p in db.query(Proprietaire).options(selectinload(Proprietaire.cites)).order_by(Proprietaire.nom_complet):
            textes = [p.nom_complet, p.cni, p.ville] + [t for c in p.cites for t in (c.nom, c.adresse)]
            if r.correspond(textes, [p.telephone]):
                _ajouter(resultats, "Propriétaires", {
                    "titre": p.nom_complet,
                    "detail": " — ".join(filter(None, [p.telephone and f"Tél. {p.telephone}", p.ville,
                                                       f"{len(p.cites)} bien(s)"])),
                    "cible": "proprietaires", "filtre": p.nom_complet})

    # --- Locataires (Admin, Gestionnaire) ---
    if peut_acceder(role, "locataires"):
        locataires = db.query(Locataire).options(
            selectinload(Locataire.contrats).selectinload(Contrat.logement).selectinload(Logement.cite)
            .selectinload(Cite.proprietaire)).order_by(Locataire.nom_complet).all()
        for l in locataires:
            contrats = [c for c in l.contrats if dans_perimetre(c.logement.cite_id)]
            if autorisees is not None and not contrats:
                continue
            textes = [l.nom_complet, l.cni, l.profession] + [
                t for c in contrats for t in [f"Logement {c.logement.numero_logement}", *lieu(c.logement.cite)]]
            if r.correspond(textes, [l.telephone]):
                ou = ", ".join(f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}" for c in contrats[:2])
                _ajouter(resultats, "Locataires", {
                    "titre": l.nom_complet,
                    "detail": " — ".join(filter(None, [l.telephone and f"Tél. {l.telephone}", ou])),
                    "cible": "locataires", "filtre": l.nom_complet})

    # --- Contrats (Admin, Gestionnaire ; la Caisse les voit pour encaisser) ---
    if peut_acceder(role, "contrats") or peut_acceder(role, "paiements"):
        cible = "contrats" if peut_acceder(role, "contrats") else "paiements"
        contrats = db.query(Contrat).options(
            selectinload(Contrat.locataire), selectinload(Contrat.logement).selectinload(Logement.cite)
            .selectinload(Cite.proprietaire)).order_by(Contrat.numero_contrat.desc()).all()
        for c in (c for c in contrats if dans_perimetre(c.logement.cite_id)):
            textes = [c.numero_contrat, c.locataire.nom_complet, c.locataire.cni, c.type_contrat, c.statut_contrat,
                      f"Logement {c.logement.numero_logement}", *lieu(c.logement.cite)]
            if r.correspond(textes, [c.locataire.telephone]):
                _ajouter(resultats, "Contrats", {
                    "titre": f"N° {c.numero_contrat} — {c.locataire.nom_complet}",
                    "detail": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom} — {c.statut_contrat}",
                    "cible": cible, "filtre": c.numero_contrat if cible == "contrats" else c.locataire.nom_complet})

    # --- Paiements (Admin, Gestionnaire, Caisse) ---
    if peut_acceder(role, "paiements"):
        paiements = db.query(Paiement).options(
            selectinload(Paiement.contrat).selectinload(Contrat.locataire),
            selectinload(Paiement.contrat).selectinload(Contrat.logement).selectinload(Logement.cite)
            .selectinload(Cite.proprietaire),
        ).order_by(Paiement.date_paiement.desc(), Paiement.id.desc()).limit(2000).all()
        for p in (p for p in paiements if dans_perimetre(p.contrat.logement.cite_id)):
            c = p.contrat
            textes = [p.numero_recu, c.numero_contrat, c.locataire.nom_complet, p.mode_paiement, p.motif_paiement,
                      f"Logement {c.logement.numero_logement}", *lieu(c.logement.cite)]
            if r.correspond(textes, [c.locataire.telephone]):
                _ajouter(resultats, "Paiements", {
                    "titre": f"{p.numero_recu} — {c.locataire.nom_complet}",
                    "detail": f"{montant(p.montant):,} F — {p.date_paiement.strftime('%d/%m/%Y')} — {p.statut_paiement}"
                              .replace(",", " "),
                    "cible": "paiements", "filtre": p.numero_recu})

    # --- Dépenses (Admin, Gestionnaire) ---
    if peut_acceder(role, "depenses"):
        depenses = db.query(Depense).options(
            selectinload(Depense.cite).selectinload(Cite.proprietaire), selectinload(Depense.logement),
        ).order_by(Depense.date_depense.desc()).limit(2000).all()
        for d in (d for d in depenses if dans_perimetre(d.cite_id)):
            textes = [d.motif, d.categorie, d.a_la_charge_de, *(lieu(d.cite) if d.cite else ["fonctionnement"])]
            if d.logement:
                textes.append(f"Logement {d.logement.numero_logement}")
            if r.correspond(textes):
                _ajouter(resultats, "Dépenses", {
                    "titre": f"{d.motif} — {d.cite.nom if d.cite else 'Fonctionnement'}",
                    "detail": f"{montant(d.montant):,} F — {d.date_depense.strftime('%d/%m/%Y')} — {d.categorie}"
                              .replace(",", " "),
                    "cible": "depenses", "filtre": d.motif})

    # --- Achats / Ventes (Admin uniquement) ---
    if peut_acceder(role, "achats_ventes"):
        operations = db.query(AchatVente).options(selectinload(AchatVente.cite)) \
            .order_by(AchatVente.date_operation.desc()).limit(2000).all()
        for o in operations:
            textes = [o.numero, o.type_operation, o.partie_nom, o.partie_cni, o.designation,
                      o.proprietaire_nom, o.proprietaire_cni]
            if o.cite:
                textes += [o.cite.nom, o.cite.adresse]
            if r.correspond(textes, [o.partie_telephone, o.proprietaire_telephone]):
                _ajouter(resultats, "Achats / Ventes", {
                    "titre": f"{o.numero} — {o.type_operation} — {o.partie_nom}",
                    "detail": f"{montant(o.montant):,} F — {o.date_operation.strftime('%d/%m/%Y')} — {o.designation or ''}"
                              .replace(",", " ")[:120],
                    "cible": "achats_ventes", "filtre": o.numero})

    ordre = ["Biens", "Logements", "Parcelles", "Propriétaires", "Locataires", "Contrats", "Paiements", "Dépenses",
             "Achats / Ventes"]
    return {"requete": q, "groupes": [{"categorie": k, **resultats[k]} for k in ordre if k in resultats]}
