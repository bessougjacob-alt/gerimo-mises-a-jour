"""Sauvegardes (Admin) : la base de données + tous les documents (PDF, photos, pièces) dans un seul fichier.

Protection contre la perte de données :
- Sauvegarde automatique chaque jour, et toutes les heures pendant les heures de bureau (réglable ; seulement
  s'il y a eu des changements depuis la précédente), et avant chaque mise à jour ou restauration.
- Chaque sauvegarde est VÉRIFIÉE : base complète (marque de fin écrite par PostgreSQL) et .zip lisible.
- Chaque sauvegarde est CHIFFRÉE avec la clé de l'entreprise (coffre.py, fichier ISUP_sauvegarde_….gerimo) : une
  clé USB perdue ne révèle rien, et un fichier modifié ou fabriqué est refusé. Sur un PC neuf, le « code de
  secours » noté par l'Admin permet de la relire. Les anciennes sauvegardes (.zip, d'avant le chiffrement) restent
  restaurables.
- Avant toute restauration, le contenu de la base est contrôlé : aucune commande de psql (antislash), qui
  pourrait lancer un programme sur le PC, ne passe.
- Copie automatique HORS DU PC : dans un dossier choisi par l'Admin (clé USB, disque externe, dossier
  partagé). Si la clé n'est pas branchée, la copie se fait dès qu'elle revient (même si sa lettre change).
- Tri automatique : on garde les 24 dernières, la dernière de chacun des 14 derniers jours et celle de
  chacun des 12 derniers mois.
- Le PC de secours vient chercher chaque nouvelle sauvegarde par le réseau (secours.py).
- Restauration (Admin, mot de passe redemandé) : une sauvegarde de l'état actuel est faite d'abord ;
  la base est remplacée en une seule opération (en cas d'erreur, rien n'est changé) ; les anciens
  documents sont rangés dans sauvegardes/ (rien n'est détruit).
"""
import glob
import json
from contextlib import contextmanager
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import zipfile
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session as SessionDB

import coffre
from database import SessionLocal, engine
from models import Parametre, Utilisateur
from securite import confirmer_mot_de_passe_admin, exiger_admin, get_db

router = APIRouter(prefix="/api")
DOSSIER = Path(__file__).parent / "sauvegardes"
DOCUMENTS = Path(__file__).parent / "documents"
MIGRATIONS = Path(__file__).parent / "migrations"
# Dernier échec de la sauvegarde automatique (effacé à la sauvegarde réussie suivante) : l'Admin est prévenu
FICHIER_ECHEC = Path(__file__).parent / "journaux" / "sauvegarde_echec.json"

CLE_DOSSIER_EXTERNE = "sauvegarde_dossier_externe"
GARDER_RECENTES = 24
GARDER_JOURS = 14
GARDER_MOIS = 12
# Fréquence (Paramètres → Sauvegardes) : « heure » = toutes les heures entre début et fin, sinon une par jour
FREQUENCE_DEFAUT = {"sauvegarde_frequence": "heure", "sauvegarde_heure_debut": "7", "sauvegarde_heure_fin": "19"}
FIN_DUMP = "PostgreSQL database dump complete"
TAILLE_MAX_ENVOI = 4 * 1024 ** 3  # 4 Go

# ISUP_sauvegarde_2026-10-05_093000.gerimo (chiffrée), ou avec un suffixe : _avant-restauration, _envoyee ;
# .zip : ancienne sauvegarde, d'avant le chiffrement
PREFIXE = "Gerimo_sauvegarde_"
# (« ISUP_sauvegarde_… » : nom des sauvegardes faites avant le 13/10/2026, toujours reconnues)
MOTIF_NOM = re.compile(r"^(?:Gerimo|ISUP)_sauvegarde_(\d{4}-\d{2}-\d{2}_\d{6})(?:_([a-z-]+))?\.(?:gerimo|zip)$")
EXTENSION = ".gerimo"
LIBELLES_TYPE = {None: "Quotidienne ou manuelle", "horaire": "De l'heure", "avant-restauration": "Avant une restauration",
                 "avant-mise-a-jour": "Avant une mise à jour", "avant-remise-a-zero": "Avant la remise à zéro",
                 "avant-import": "Avant une reprise de données",
                 "avant-reinstallation": "Avant une réinstallation",
                 "envoyee": "Fichier envoyé"}

_verrou = threading.Lock()  # une seule sauvegarde ou restauration à la fois

LISEZ_MOI = """SAUVEGARDE GÉRIMO — {date}

Contenu :
- base_gerimo.sql : toute la base de données (propriétaires, biens, contrats, paiements…)
- documents/ : reçus, quittances, contrats, états des lieux, photos et pièces jointes

Pour restaurer : dans Gérimo, Paramètres → Sauvegardes → « Restaurer » (Admin).
Si le logiciel ne démarre plus (à faire faire par une personne habituée, sur une base VIDE) :
1. Créer une base vide dans PostgreSQL (le nom indiqué dans le fichier .env du logiciel).
2. Dans le terminal :  psql -U postgres -d <nom de la base> -f base_gerimo.sql
3. Recopier le dossier documents/ dans le dossier du logiciel.
"""


# ---------- Outils PostgreSQL ----------

def outil_postgres(nom: str) -> str:
    trouve = shutil.which(nom)
    if trouve:
        return trouve
    candidats = sorted(glob.glob(rf"C:\Program Files\PostgreSQL\*\bin\{nom}.exe"), reverse=True)
    if not candidats:
        raise HTTPException(status_code=500, detail=f"Outil {nom} introuvable (PostgreSQL installé ?).")
    return candidats[0]


def pg_dump() -> str:
    return outil_postgres("pg_dump")


def _connexion() -> tuple[list[str], dict]:
    """Arguments de connexion communs à pg_dump et psql, et environnement (mot de passe)."""
    env = dict(os.environ, PGPASSWORD=os.getenv("DB_PASSWORD", ""), PGCLIENTENCODING="UTF8")
    arguments = ["-h", os.getenv("DB_HOST", "localhost"), "-p", str(os.getenv("DB_PORT", "5432")),
                 "-U", os.getenv("DB_USER", "postgres"), "-d", os.getenv("DB_NAME", "isup_erp")]
    return arguments, env


# ---------- Vérification ----------

def _dump_complet(chemin_sql: Path) -> bool:
    """pg_dump écrit une marque de fin : sans elle, la sauvegarde est incomplète."""
    if not chemin_sql.exists():
        return False
    with open(chemin_sql, "rb") as f:
        f.seek(max(0, chemin_sql.stat().st_size - 4096))
        return FIN_DUMP.encode() in f.read()


def verifier_archive(chemin: Path) -> str | None:
    """None si la sauvegarde est bonne, sinon la raison du problème.
    Chiffrée : chaque morceau est authentifié (le .zip a été vérifié avant d'être chiffré, il est donc intact)."""
    if coffre.est_chiffre(chemin):
        try:
            coffre.dechiffrer_fichier(chemin, None)
        except coffre.CleInconnue:
            return CLE_INCONNUE
        except coffre.Abime as e:
            return f"fichier abîmé ou modifié ({e})"
        except OSError as e:
            return f"fichier illisible ({e})"
        return None
    return _verifier_zip(chemin)


CLE_INCONNUE = "elle a été chiffrée par une autre installation de Gérimo : il faut son code de secours"


def cle_connue(chemin: Path) -> bool:
    """False si la sauvegarde est chiffrée avec une clé absente du trousseau (code de secours à saisir)."""
    ident = coffre.identifiant_fichier(chemin)
    return ident is None or any(coffre.identifiant(s) == ident for s in coffre.cles(creer=False))


@contextmanager
def archive_en_clair(chemin: Path):
    """Le .zip lisible : le fichier lui-même (ancienne sauvegarde) ou sa copie déchiffrée, effacée après usage."""
    if not coffre.est_chiffre(chemin):
        yield chemin
        return
    DOSSIER.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(dir=DOSSIER, prefix="lecture_") as temp:
        clair = Path(temp) / "sauvegarde.zip"
        coffre.dechiffrer_fichier(chemin, clair)
        yield clair


NOM_SQL = "base_gerimo.sql"
ANCIEN_NOM_SQL = "base_isup_erp.sql"   # sauvegardes faites avant le 13/10/2026


def nom_sql(z: zipfile.ZipFile) -> str | None:
    """Nom du fichier de la base dans la sauvegarde (nouveau ou ancien), ou None s'il manque."""
    noms = z.namelist()
    return next((n for n in (NOM_SQL, ANCIEN_NOM_SQL) if n in noms), None)


def _verifier_zip(chemin: Path) -> str | None:
    try:
        with zipfile.ZipFile(chemin) as z:
            base = nom_sql(z)
            if base is None:
                return "la base de données est absente du fichier"
            abime = z.testzip()  # relit tout le contenu et contrôle chaque fichier
            if abime:
                return f"fichier abîmé à l'intérieur ({abime})"
            with z.open(base) as f:
                taille = z.getinfo(base).file_size
                if taille > 4096:
                    f.seek(taille - 4096)
                if FIN_DUMP.encode() not in f.read():
                    return "la base de données est incomplète"
    except (zipfile.BadZipFile, OSError) as e:
        return f"fichier illisible ({e})"
    return None


# ---------- Création ----------

def derniere_sauvegarde() -> datetime | None:
    liste = sauvegardes(DOSSIER)
    return liste[-1][1] if liste else None


def sauvegardes(dossier: Path) -> list[tuple[Path, datetime, str | None]]:
    """Sauvegardes d'un dossier, de la plus ancienne à la plus récente : (chemin, date, type)."""
    resultat = []
    if dossier and dossier.exists():
        for chemin in dossier.glob("*_sauvegarde_*"):
            m = MOTIF_NOM.match(chemin.name)
            if m:
                resultat.append((chemin, datetime.strptime(m.group(1), "%Y-%m-%d_%H%M%S"), m.group(2)))
    return sorted(resultat, key=lambda s: s[1])


def creer_sauvegarde(suffixe: str = "") -> Path:
    """Crée, vérifie, trie et copie hors du PC. Renvoie le chemin de la sauvegarde locale."""
    with _verrou:
        archive = _creer(suffixe)
    FICHIER_ECHEC.unlink(missing_ok=True)
    trier(DOSSIER)
    copier_hors_du_pc()
    return archive


def _creer(suffixe: str = "") -> Path:
    DOSSIER.mkdir(exist_ok=True)
    horodatage = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    sql = DOSSIER / f"base_{horodatage}.sql"
    arguments, env = _connexion()
    commande = [pg_dump(), *arguments, "--no-owner", "--encoding=UTF8", "-f", str(sql)]
    resultat = subprocess.run(commande, env=env, capture_output=True, text=True, timeout=600)
    if resultat.returncode != 0 or not _dump_complet(sql):
        sql.unlink(missing_ok=True)
        raise HTTPException(status_code=500, detail="La sauvegarde de la base a échoué : "
                                                    + ((resultat.stderr or "").strip()[:300] or "base incomplète"))
    nom = f"{PREFIXE}{horodatage}{'_' + suffixe if suffixe else ''}{EXTENSION}"
    archive = DOSSIER / nom
    provisoire = DOSSIER / (nom + ".en-cours")
    en_clair = DOSSIER / (nom + ".zip.en-cours")
    try:
        with zipfile.ZipFile(en_clair, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(sql, NOM_SQL)
            z.writestr("LISEZ-MOI.txt", LISEZ_MOI.format(date=datetime.now().strftime("%d/%m/%Y à %H:%M")))
            if DOCUMENTS.exists():
                for chemin in DOCUMENTS.rglob("*"):
                    if chemin.is_file():
                        z.write(chemin, Path("documents") / chemin.relative_to(DOCUMENTS))
        probleme = _verifier_zip(en_clair)
        if not probleme:
            coffre.chiffrer_fichier(en_clair, provisoire)
            probleme = verifier_archive(provisoire)
        if probleme:
            raise HTTPException(status_code=500, detail=f"La sauvegarde n'a pas pu être vérifiée : {probleme}.")
        provisoire.replace(archive)  # n'apparaît dans la liste qu'une fois complète, chiffrée et vérifiée
    finally:
        provisoire.unlink(missing_ok=True)
        en_clair.unlink(missing_ok=True)
        sql.unlink(missing_ok=True)
    return archive


def trier(dossier: Path) -> list[str]:
    """Garde les 24 dernières + la dernière de chacun des 14 derniers jours et des 12 derniers mois."""
    liste = sauvegardes(dossier)
    garder = {s[0] for s in liste[-GARDER_RECENTES:]}
    par_jour: dict[str, Path] = {}
    par_mois: dict[str, Path] = {}
    for chemin, date, _ in liste:
        par_jour[date.strftime("%Y-%m-%d")] = chemin  # la plus récente du jour l'emporte
        par_mois[date.strftime("%Y-%m")] = chemin
    garder |= {par_jour[j] for j in sorted(par_jour)[-GARDER_JOURS:]}
    garder |= {par_mois[m] for m in sorted(par_mois)[-GARDER_MOIS:]}
    supprimees = []
    for chemin, _, _ in liste:
        if chemin not in garder:
            try:
                chemin.unlink()
                supprimees.append(chemin.name)
            except OSError:
                pass
    return supprimees


# ---------- Copie hors du PC (clé USB, disque externe, dossier partagé) ----------

def dossier_externe_choisi() -> str:
    try:
        with SessionLocal() as db:
            p = db.get(Parametre, CLE_DOSSIER_EXTERNE)
            return (p.valeur or "").strip() if p else ""
    except Exception:  # noqa: BLE001 — base vide (PC neuf, avant restauration) : pas encore de réglage
        return ""


def trouver_dossier_externe(choisi: str) -> Path | None:
    """Le dossier choisi ; si la clé a changé de lettre (E: devenu F:), le même dossier sur un autre lecteur."""
    if not choisi:
        return None
    chemin = Path(choisi)
    if chemin.is_dir():
        return chemin
    lecteur, reste = os.path.splitdrive(choisi)
    if os.name == "nt" and re.fullmatch(r"[A-Za-z]:", lecteur or ""):
        for lettre in "DEFGHIJKLMNOPQRSTUVWXYZ":
            autre = Path(f"{lettre}:{reste}")
            if lettre != lecteur[0].upper() and Path(f"{lettre}:\\").exists() and autre.is_dir():
                return autre
    return None


def _ecriture_possible(dossier: Path) -> str | None:
    essai = dossier / ".essai_gerimo"
    try:
        essai.write_text("ok", encoding="utf-8")
        essai.unlink()
    except OSError as e:
        return str(e)
    return None


def copier_hors_du_pc() -> dict:
    """Copie la dernière sauvegarde dans le dossier externe si elle n'y est pas encore."""
    choisi = dossier_externe_choisi()
    if not choisi:
        return {"etat": "non_configure"}
    dossier = trouver_dossier_externe(choisi)
    if dossier is None:
        return {"etat": "absent", "dossier": choisi}
    liste = sauvegardes(DOSSIER)
    if not liste:
        return {"etat": "rien", "dossier": str(dossier)}
    source = liste[-1][0]
    cible = dossier / source.name
    if cible.exists() and cible.stat().st_size == source.stat().st_size:
        return {"etat": "ok", "dossier": str(dossier), "fichier": source.name}
    provisoire = dossier / (source.name + ".en-cours")
    try:
        shutil.copyfile(source, provisoire)
        probleme = verifier_archive(provisoire)
        if probleme:
            provisoire.unlink(missing_ok=True)
            return {"etat": "erreur", "dossier": str(dossier), "message": f"copie abîmée ({probleme})"}
        provisoire.replace(cible)
    except OSError as e:
        provisoire.unlink(missing_ok=True)
        return {"etat": "erreur", "dossier": str(dossier), "message": str(e)}
    trier(dossier)
    return {"etat": "ok", "dossier": str(dossier), "fichier": source.name}


def derniere_copie_externe() -> datetime | None:
    dossier = trouver_dossier_externe(dossier_externe_choisi())
    liste = sauvegardes(dossier) if dossier else []
    return liste[-1][1] if liste else None


# ---------- Sauvegarde automatique ----------

def frequence() -> dict:
    """Réglage de la fréquence : {"frequence": "heure"|"jour", "debut": 7, "fin": 19}."""
    valeurs = dict(FREQUENCE_DEFAUT)
    try:
        with SessionLocal() as db:
            for p in db.query(Parametre).filter(Parametre.cle.in_(FREQUENCE_DEFAUT)):
                if p.valeur:
                    valeurs[p.cle] = p.valeur
    except Exception:  # noqa: BLE001 — base vide : réglage par défaut
        pass
    return {"frequence": valeurs["sauvegarde_frequence"], "debut": int(valeurs["sauvegarde_heure_debut"]),
            "fin": int(valeurs["sauvegarde_heure_fin"])}


def changements_depuis(quand: datetime) -> bool:
    """Y a-t-il eu un ajout, une modification ou une suppression depuis cette date ? (journal des actions)"""
    from sqlalchemy import text
    try:
        with engine.connect() as c:
            return bool(c.execute(text("SELECT EXISTS (SELECT 1 FROM journal WHERE quand > :q AND operation IN "
                                       "('INSERT', 'UPDATE', 'DELETE'))"), {"q": quand}).scalar())
    except Exception:  # noqa: BLE001 — journal absent : on sauvegarde par prudence
        return True


def sauvegarde_attendue(derniere: datetime | None, maintenant: datetime, reglage: dict, a_change) -> str | None:
    """« jour », « heure » ou None : faut-il une sauvegarde maintenant ? (`a_change` n'est appelé qu'au besoin)"""
    if derniere is None or (maintenant - derniere).total_seconds() > 24 * 3600:
        return "jour"
    if (reglage["frequence"] == "heure" and reglage["debut"] <= maintenant.hour < reglage["fin"]
            and (maintenant - derniere).total_seconds() >= 55 * 60 and a_change(derniere)):
        return "heure"
    return None


def sauvegarde_si_necessaire() -> str | None:
    """Une sauvegarde par jour, et une par heure de bureau s'il y a eu des changements ;
    sinon, rattrape la copie sur la clé si elle vient d'être branchée."""
    attendue = sauvegarde_attendue(derniere_sauvegarde(), datetime.now(), frequence(), changements_depuis)
    if attendue:
        return creer_sauvegarde("horaire" if attendue == "heure" else "").name
    copier_hors_du_pc()
    return None


def noter_echec(erreur: Exception) -> None:
    """Garde la raison du dernier échec automatique, pour prévenir l'Admin dès le lendemain au plus tard."""
    message = getattr(erreur, "detail", None) or str(erreur) or erreur.__class__.__name__
    try:
        FICHIER_ECHEC.parent.mkdir(exist_ok=True)
        FICHIER_ECHEC.write_text(json.dumps({"quand": datetime.now().isoformat(timespec="seconds"),
                                             "message": str(message)[:300]}, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def dernier_echec() -> dict | None:
    """{"quand": datetime, "message": str} si la dernière sauvegarde automatique a échoué."""
    try:
        d = json.loads(FICHIER_ECHEC.read_text(encoding="utf-8"))
        return {"quand": datetime.fromisoformat(d["quand"]), "message": d.get("message", "")}
    except (OSError, ValueError, KeyError):
        return None


def _boucle_automatique():
    time.sleep(10 * 60)  # laisse le serveur démarrer tranquillement
    while True:
        try:
            sauvegarde_si_necessaire()
        except Exception as e:  # noqa: BLE001 — ne jamais arrêter la boucle
            print(f"Sauvegarde automatique impossible : {e}")
            noter_echec(e)
        time.sleep(600)  # vérifié toutes les 10 minutes


def demarrer_sauvegardes_automatiques() -> None:
    if os.getenv("GERIMO_SANS_SAUVEGARDE_AUTO"):
        return
    threading.Thread(target=_boucle_automatique, daemon=True, name="sauvegardes").start()


# ---------- Restauration ----------

def _extraire_documents(z: zipfile.ZipFile, cible: Path) -> None:
    """Extrait documents/ en refusant tout chemin qui sortirait du dossier (fichier piégé)."""
    racine = cible.resolve()
    for info in z.infolist():
        if not info.filename.startswith("documents/") or info.is_dir():
            continue
        chemin = (cible / info.filename[len("documents/"):]).resolve()
        if racine not in chemin.parents:
            raise HTTPException(status_code=400, detail="Fichier de sauvegarde suspect : restauration refusée.")
        chemin.parent.mkdir(parents=True, exist_ok=True)
        with z.open(info) as source, open(chemin, "wb") as destination:
            shutil.copyfileobj(source, destination)


# ---------- Contrôle du contenu (audit, point 8) ----------
# psql exécute les « commandes antislash » (antislash + point d'exclamation lance un programme sur le PC) : une
# sauvegarde piégée ne doit jamais en contenir. pg_dump n'en écrit que deux, restrict et unrestrict (protection
# ajoutée par PostgreSQL), seules sur leur ligne ; les données (blocs COPY … FROM stdin, jusqu'à la ligne
# antislash-point) ne sont pas lues par psql comme des commandes. Le contrôle suit les chaînes 'texte', E'…',
# $$…$$, "noms" et commentaires comme psql.

ANTISLASH_PERMIS = re.compile(r"^\\(restrict|unrestrict) [A-Za-z0-9]+\s*$")
DEBUT_COPY = re.compile(r"^\s*COPY\s.+\sFROM\s+stdin\s*;\s*$", re.IGNORECASE | re.DOTALL)
DOLLAR = re.compile(r"\$([A-Za-z_][A-Za-z_0-9]*)?\$")


class SauvegardePiegee(Exception):
    pass


def controler_sql(chemin: Path) -> None:
    """Lève SauvegardePiegee si le fichier SQL contient une commande psql ou un programme à lancer."""
    etat, fin_dollar, profondeur = "normal", "", 0
    instruction: list[str] = []
    dans_copy = False
    with open(chemin, encoding="utf-8", errors="replace", newline="") as f:
        for numero, ligne in enumerate(f, 1):
            if dans_copy:
                if ligne.rstrip("\r\n") == "\\.":
                    dans_copy = False
                continue
            if etat == "normal" and not "".join(instruction).strip() and ligne.startswith("\\"):
                if not ANTISLASH_PERMIS.match(ligne.rstrip("\r\n")):
                    raise SauvegardePiegee(f"commande psql interdite ligne {numero}")
                continue
            i, n = 0, len(ligne)
            while i < n:
                c = ligne[i]
                if etat == "normal":
                    if c == "\\":
                        raise SauvegardePiegee(f"commande psql interdite ligne {numero}")
                    if ligne.startswith("--", i):
                        break  # commentaire jusqu'au bout de la ligne
                    if ligne.startswith("/*", i):
                        etat, profondeur = "bloc", 1
                        i += 2
                        continue
                    if c == ";":
                        texte = "".join(instruction) + ";"
                        if re.match(r"\s*COPY\b", texte, re.IGNORECASE) and re.search(r"\bPROGRAM\b", texte, re.IGNORECASE):
                            raise SauvegardePiegee(f"programme à lancer ligne {numero}")
                        instruction = []
                        if DEBUT_COPY.match(texte):
                            if ligne[i + 1:].strip():
                                raise SauvegardePiegee(f"bloc de données mal formé ligne {numero}")
                            dans_copy = True
                            break
                        i += 1
                        continue
                    if c == "'":
                        echappe = i > 0 and ligne[i - 1] in "Ee" and (i < 2 or not (ligne[i - 2].isalnum() or ligne[i - 2] == "_"))
                        etat = "chaine_e" if echappe else "chaine"
                    elif c == '"':
                        etat = "nom"
                    elif c == "$" and not (i > 0 and (ligne[i - 1].isalnum() or ligne[i - 1] == "_")):
                        m = DOLLAR.match(ligne, i)
                        if m:
                            etat, fin_dollar = "dollar", m.group(0)
                            instruction.append(fin_dollar)
                            i = m.end()
                            continue
                    instruction.append(c)
                elif etat == "bloc":
                    if ligne.startswith("*/", i):
                        profondeur -= 1
                        i += 2
                        if profondeur == 0:
                            etat = "normal"
                        continue
                    if ligne.startswith("/*", i):
                        profondeur += 1
                        i += 2
                        continue
                elif etat in ("chaine", "chaine_e"):
                    instruction.append(c)
                    if etat == "chaine_e" and c == "\\":
                        if i + 1 < n:
                            instruction.append(ligne[i + 1])
                        i += 2
                        continue
                    if c == "'":
                        if ligne.startswith("''", i):
                            instruction.append("'")
                            i += 2
                            continue
                        etat = "normal"
                elif etat == "nom":
                    instruction.append(c)
                    if c == '"':
                        etat = "normal"
                elif etat == "dollar":
                    if ligne.startswith(fin_dollar, i):
                        instruction.append(fin_dollar)
                        etat = "normal"
                        i += len(fin_dollar)
                        continue
                i += 1
            if etat == "normal" and not dans_copy:
                instruction.append("\n")


def restaurer(archive: Path, code_secours: str = "") -> dict:
    if code_secours:
        adopter_code(archive, code_secours)
    if not cle_connue(archive):
        raise HTTPException(status_code=409, detail="CODE_SECOURS : cette sauvegarde a été chiffrée par une autre "
                                                    "installation de Gérimo. Saisissez son code de secours.")
    probleme = verifier_archive(archive)
    if probleme:
        raise HTTPException(status_code=400, detail=f"Sauvegarde inutilisable : {probleme}. Rien n'a été modifié.")
    securite = creer_sauvegarde("avant-restauration")  # on peut toujours revenir en arrière
    with _verrou, tempfile.TemporaryDirectory(dir=DOSSIER) as temp, archive_en_clair(archive) as clair:
        temp = Path(temp)
        with zipfile.ZipFile(clair) as z:
            base = nom_sql(z)
            z.extract(base, temp)
            (temp / base).rename(temp / NOM_SQL) if base != NOM_SQL else None
            try:
                controler_sql(temp / NOM_SQL)
            except SauvegardePiegee as e:
                raise HTTPException(status_code=400, detail="Sauvegarde refusée : elle contient de quoi lancer un "
                                                            f"programme sur ce PC ({e}). Rien n'a été modifié.")
            nouveaux_documents = temp / "documents"
            nouveaux_documents.mkdir()
            _extraire_documents(z, nouveaux_documents)

        # 1. La base : tout est remplacé en UNE transaction (en cas d'erreur, rien ne change)
        engine.dispose()  # libère les connexions du logiciel
        arguments, env = _connexion()
        commande = [outil_postgres("psql"), *arguments, "-X", "-q", "-v", "ON_ERROR_STOP=1", "--single-transaction",
                    "-c", "SET lock_timeout = '60s'",
                    "-c", "DROP SCHEMA public CASCADE", "-c", "CREATE SCHEMA public",
                    "-f", str(temp / NOM_SQL)]
        resultat = subprocess.run(commande, env=env, capture_output=True, text=True, encoding="utf-8",
                                  errors="replace", timeout=1800)
        if resultat.returncode != 0:
            raise HTTPException(status_code=500, detail="La restauration a échoué, la base n'a PAS été modifiée : "
                                                        + (resultat.stderr or "").strip()[:300])
        # une sauvegarde d'une ancienne version est mise à niveau (migrations rejouables sans risque)
        for fichier in sorted(MIGRATIONS.glob("*.sql")):
            with engine.begin() as c:
                c.connection.cursor().execute(fichier.read_text(encoding="utf-8"))

        # 2. Les documents : les actuels sont rangés (pas détruits), ceux de la sauvegarde les remplacent
        rangement = None
        if DOCUMENTS.exists():
            rangement = DOSSIER / f"documents_avant_restauration_{datetime.now():%Y-%m-%d_%H%M%S}"
            shutil.move(str(DOCUMENTS), str(rangement))
        shutil.move(str(nouveaux_documents), str(DOCUMENTS))
    return {"securite": securite.name, "documents_ranges": rangement.name if rangement else None}


def adopter_code(archive: Path, code: str) -> None:
    """Code de secours saisi pour une sauvegarde d'une autre installation : il doit être le sien ; sa clé devient
    celle de ce PC (c'est celle de l'entreprise, notée sur papier)."""
    try:
        secret = coffre.secret_du_code(code)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    if coffre.identifiant_fichier(archive) not in (None, coffre.identifiant(secret)):
        raise HTTPException(status_code=400, detail="Ce code de secours ne correspond pas à cette sauvegarde.")
    coffre.ajouter(secret, active=True)


# ---------- API (Admin) ----------

def _info(chemin: Path, date: datetime, type_: str | None, externe: Path | None) -> dict:
    return {"fichier": chemin.name, "date": date.strftime("%d/%m/%Y à %H:%M"),
            "taille_mo": round(chemin.stat().st_size / 1_048_576, 1),
            "type": LIBELLES_TYPE.get(type_, type_), "hors_du_pc": bool(externe and (externe / chemin.name).exists())}


def _chemin_local(nom: str) -> Path:
    chemin = DOSSIER / Path(nom).name
    if not MOTIF_NOM.match(chemin.name) or not chemin.exists():
        raise HTTPException(status_code=404, detail="Sauvegarde introuvable.")
    return chemin


@router.get("/sauvegardes")
def lister(admin: Utilisateur = Depends(exiger_admin)):
    choisi = dossier_externe_choisi()
    externe = trouver_dossier_externe(choisi)
    liste = sauvegardes(DOSSIER)
    copies = sauvegardes(externe) if externe else []
    return {
        "dossier_local": str(DOSSIER),
        "dossier_externe": choisi,
        "dossier_externe_trouve": str(externe) if externe else None,
        "derniere_copie_externe": copies[-1][1].strftime("%d/%m/%Y à %H:%M") if copies else None,
        "sauvegardes": [_info(c, d, t, externe) for c, d, t in reversed(liste)],
        "frequence": frequence(),
    }


class FrequenceIn(BaseModel):
    frequence: str
    debut: int = 7
    fin: int = 19


@router.put("/sauvegardes/frequence")
def regler_frequence(d: FrequenceIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    if d.frequence not in ("heure", "jour"):
        raise HTTPException(status_code=400, detail="Fréquence non reconnue.")
    if not (0 <= d.debut < d.fin <= 24):
        raise HTTPException(status_code=400, detail="Heures de bureau : la fin doit être après le début (0 à 24 h).")
    for cle, valeur in (("sauvegarde_frequence", d.frequence), ("sauvegarde_heure_debut", str(d.debut)),
                        ("sauvegarde_heure_fin", str(d.fin))):
        p = db.get(Parametre, cle)
        if p is None:
            db.add(Parametre(cle=cle, valeur=valeur, modifie_le=datetime.now()))
        else:
            p.valeur, p.modifie_le = valeur, datetime.now()
    db.commit()
    return {"ok": True}


class DossierExterneIn(BaseModel):
    dossier: str = ""


@router.put("/sauvegardes/dossier-externe")
def choisir_dossier_externe(donnees: DossierExterneIn, admin: Utilisateur = Depends(exiger_admin),
                            db: SessionDB = Depends(get_db)):
    dossier = donnees.dossier.strip().strip('"')[:300]
    if dossier:
        chemin = Path(dossier)
        if not chemin.is_absolute():
            raise HTTPException(status_code=400, detail="Indiquez le chemin complet, par exemple E:\\Sauvegardes Gérimo.")
        if chemin.resolve() == DOSSIER.resolve() or DOSSIER.resolve() in chemin.resolve().parents:
            raise HTTPException(status_code=400, detail="Choisissez un dossier HORS du logiciel (clé USB, disque externe…).")
        if not chemin.exists():
            lecteur = os.path.splitdrive(dossier)[0]
            if lecteur and not Path(lecteur + "\\").exists():
                raise HTTPException(status_code=400, detail=f"Le lecteur {lecteur} n'est pas branché sur le PC serveur.")
            try:
                chemin.mkdir(parents=True)
            except OSError as e:
                raise HTTPException(status_code=400, detail=f"Impossible de créer ce dossier : {e}")
        probleme = _ecriture_possible(chemin)
        if probleme:
            raise HTTPException(status_code=400, detail=f"Impossible d'écrire dans ce dossier : {probleme}")
    p = db.get(Parametre, CLE_DOSSIER_EXTERNE)
    if p is None:
        db.add(Parametre(cle=CLE_DOSSIER_EXTERNE, valeur=dossier, modifie_le=datetime.now()))
    else:
        p.valeur, p.modifie_le = dossier, datetime.now()
    db.commit()
    copie = copier_hors_du_pc() if dossier else {"etat": "non_configure"}
    return {"ok": True, "copie": copie}


@router.post("/sauvegarde")
def sauvegarder(admin: Utilisateur = Depends(exiger_admin)):
    archive = creer_sauvegarde()
    return {"fichier": archive.name, "taille_mo": round(archive.stat().st_size / 1_048_576, 1),
            "dossier": str(DOSSIER), "verifiee": True, "copie": copier_hors_du_pc()}


@router.get("/sauvegarde/{nom}")
def telecharger(nom: str, admin: Utilisateur = Depends(exiger_admin)):
    chemin = _chemin_local(nom)
    return FileResponse(chemin, media_type="application/zip" if chemin.suffix == ".zip" else "application/octet-stream",
                        filename=chemin.name)


@router.post("/sauvegardes/envoyer")
async def envoyer(request: Request, admin: Utilisateur = Depends(exiger_admin)):
    """Reçoit un fichier de sauvegarde (par exemple depuis une clé USB branchée sur un autre PC).
    Il est vérifié puis ajouté à la liste ; la restauration se fait ensuite depuis la liste."""
    DOSSIER.mkdir(exist_ok=True)
    nom = f"{PREFIXE}{datetime.now():%Y-%m-%d_%H%M%S}_envoyee"
    provisoire = DOSSIER / (nom + ".en-cours")
    code = request.headers.get("X-Gerimo-Code-Secours", "")
    taille = 0
    try:
        with open(provisoire, "wb") as f:
            async for morceau in request.stream():
                taille += len(morceau)
                if taille > TAILLE_MAX_ENVOI:
                    raise HTTPException(status_code=413, detail="Fichier trop gros (4 Go maximum).")
                f.write(morceau)
        if code:
            adopter_code(provisoire, code)
        if not cle_connue(provisoire):
            raise HTTPException(status_code=409, detail="CODE_SECOURS : ce fichier a été chiffré par une autre "
                                                        "installation de Gérimo. Saisissez son code de secours.")
        probleme = verifier_archive(provisoire)
        if probleme:
            raise HTTPException(status_code=400, detail=f"Ce fichier n'est pas une sauvegarde Gérimo valable : {probleme}.")
        nom += EXTENSION if coffre.est_chiffre(provisoire) else ".zip"
        provisoire.replace(DOSSIER / nom)
    finally:
        provisoire.unlink(missing_ok=True)
    return {"fichier": nom}


class RestaurationIn(BaseModel):
    mot_de_passe_admin: str
    code_secours: str = ""


@router.post("/sauvegardes/{nom}/restaurer")
def restaurer_sauvegarde(nom: str, donnees: RestaurationIn, admin: Utilisateur = Depends(exiger_admin),
                         db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    chemin = _chemin_local(nom)
    db.close()  # sinon la connexion de cette requête bloquerait le remplacement de la base
    return {"ok": True, **restaurer(chemin, donnees.code_secours)}


# ---------- Code de secours (Admin) ----------

@router.get("/sauvegardes/code-secours")
def etat_code_secours(admin: Utilisateur = Depends(exiger_admin)):
    return {"note": coffre.code_note()}


class CodeSecoursIn(BaseModel):
    mot_de_passe_admin: str


@router.post("/sauvegardes/code-secours")
def afficher_code_secours(donnees: CodeSecoursIn, admin: Utilisateur = Depends(exiger_admin)):
    """Le code n'apparaît qu'après le mot de passe de l'Admin (il n'est jamais écrit dans le journal)."""
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    return {"code": coffre.code_secours(), "note": coffre.code_note()}


@router.post("/sauvegardes/code-secours/note")
def confirmer_code_note(admin: Utilisateur = Depends(exiger_admin)):
    coffre.noter_code()
    return {"ok": True}
