"""Lexique de l'assistant Gérimo (sans Internet, sans IA payante) : il retrouve la question connue la plus proche et
donne la réponse validée, en respectant les règles de Boss (13/10/2026).

Sources :
- modeles/conversations/*.txt : conversations de formation (« Nom : texte », thèmes « ## », étiquettes) ;
- modeles/lexique_maison.txt : conversation courante et règles maison, modifiables par l'Admin ;
- table assistant_questions : questions que Gérimo n'avait pas comprises et auxquelles l'Admin a répondu.

Règles :
1. Ne rien inventer ni supposer : les montants et noms des conversations sont des exemples ; une réponse qui contient
   un calcul d'exemple est annoncée « Exemple de calcul (montants fictifs) » ; un thème [chiffres réels] ne donne
   jamais les chiffres de la conversation, seulement où trouver les vrais ; une réponse qui dépend des données
   réelles (repères « [ … ] ») n'est jamais servie telle quelle.
2. [orienter : Comptable] / [orienter : Caisse] : Gérimo oriente vers la personne (nom lu dans les comptes), sauf
   si c'est elle qui demande.
3. Question non comprise : gardée sans nom ni numéro (repères [nom], [téléphone]…) pour que l'Admin y réponde.

Compréhension : texte simplifié (accents, majuscules, ponctuation), écriture SMS développée (« bjr », « rdv »,
« stp »…), mots vides retirés, racines des mots, fautes de frappe corrigées vers le mot connu le plus proche,
puis similarité (TF-IDF) avec chaque question connue.
"""
import math
import random
import re
import unicodedata
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session as SessionDB

from models import RoleUtilisateur, Utilisateur
from securite import confirmer_mot_de_passe_admin, exiger_admin, get_db, peut_acceder

router = APIRouter(prefix="/api")
ICI = Path(__file__).parent
DOSSIER_CONVERSATIONS = ICI / "modeles" / "conversations"
LEXIQUE_MAISON = ICI / "modeles" / "lexique_maison.txt"

SEUIL_FORT = 0.62     # réponse donnée tout de suite
SEUIL_FAIBLE = 0.45   # réponse donnée seulement si aucune autre règle de l'assistant n'a compris

ETIQUETTES = ("orienter : Comptable", "orienter : Caisse", "chiffres réels")
MONTANT = re.compile(r"\d[\d  ]*\s?(?:F|FCFA|francs)\b")  # un montant en francs dans une réponse : forcément un exemple
REPERE = re.compile(r"\[[^\]]*\]")

# ---------- Simplification du texte ----------

SMS = {
    "bjr": "bonjour", "bsr": "bonsoir", "slt": "salut", "stp": "", "svp": "", "rdv": "rendez vous", "rdvs": "rendez vous",
    "tel": "telephone", "tels": "telephone", "pq": "pourquoi", "pk": "pourquoi", "pkoi": "pourquoi",
    "pourkoi": "pourquoi", "koi": "quoi", "cmt": "comment", "cmnt": "comment", "qd": "quand", "kan": "quand",
    "mme": "madame", "mlle": "mademoiselle", "mr": "monsieur", "jsp": "je ne sais pas", "tjs": "toujours",
    "bcp": "beaucoup", "pr": "pour", "ds": "dans", "ke": "que", "kel": "quel", "kelle": "quelle", "ya": "il y a",
    "dc": "donc", "msg": "message", "mdp": "mot de passe", "whatsap": "whatsapp", "watsap": "whatsapp",
    "watsapp": "whatsapp", "wa": "whatsapp", "appli": "application", "ordi": "ordinateur", "pc": "ordinateur",
    "mtn": "maintenant", "auj": "aujourd hui", "ajd": "aujourd hui", "dmn": "demain", "qqn": "quelqu un",
    "qqch": "quelque chose", "infos": "information", "info": "information", "nbr": "nombre", "nb": "nombre",
    "edl": "etat des lieux", "loc": "locataire", "proprio": "proprietaire", "proprios": "proprietaire",
    "jai": "j ai", "chui": "je suis", "jsuis": "je suis", "dacc": "d accord", "dac": "d accord",
}
VIDES = set("""a au aux avec c ca ce ceci cela cet cette ces d de des du elle elles en est et etre il ils j je l la le les
leur leurs lui m ma me mes moi mon n ne nous on ou par pas pour qu que qui s sa se ses si son sur t ta te tes toi ton tu
un une vos votre vous y oui non alors donc mais aussi tout tous toute toutes tres plus moins faire fait fais va vas
vais peut peux pouvez veux voulez dois doit faut il y a ai as avez avons ont suis es sommes etes sont gerimo serge
mariam koffi ibrahim konan diallo hein bon ben ici la-bas quoi comment quel quelle quels quelles""".split())


def simplifier(texte: str) -> str:
    t = unicodedata.normalize("NFD", texte.lower().replace("’", "'"))
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    t = re.sub(r"[^a-z0-9]+", " ", t)
    return " ".join(SMS.get(m, m) for m in t.split()).strip()


def racine(mot: str) -> str:
    for fin in ("ements", "ement", "ations", "ation", "ees", "ee", "es", "er", "ez", "e", "s", "x"):
        if mot.endswith(fin) and len(mot) - len(fin) >= 4:
            return mot[: -len(fin)]
    return mot


def mots(texte: str) -> list[str]:
    return [racine(m) for m in simplifier(texte).split() if m not in VIDES and not m.isdigit()]


# ---------- Entrées du lexique ----------

@dataclass
class Entree:
    questions: list[str]
    reponses: list[str]
    etiquette: str | None = None
    theme: str = ""
    source: str = ""
    noms: list[str] = field(default_factory=list)   # personnages de la conversation (remplacés par le prénom)


def lire_conversation(chemin: Path) -> list[Entree]:
    entrees, theme, etiquette, lignes = [], "", None, []
    for ligne in chemin.read_text(encoding="utf-8").splitlines():
        if ligne.startswith("## "):
            m = re.match(r"^## (.+?)(?:\s+\[([^\]]+)\])?\s*$", ligne)
            theme, etiquette = m.group(1), (m.group(2) if m.group(2) in ETIQUETTES else None)
            continue
        if not theme:
            continue  # en-tête et règles du fichier
        m = re.match(r"^([A-ZÉÈ][\wÀ-ÿ .'-]{0,30}?) : (.+)$", ligne)
        if m:
            lignes.append((m.group(1).strip(), m.group(2).strip(), theme, etiquette))
    if not lignes:
        return []
    demandeur = lignes[0][0]
    noms = sorted({l[0].split()[-1] for l in lignes} - {"Question", "Réponse"})
    attente: list[str] = []   # questions à la suite (plusieurs façons de demander la même chose)
    for qui, phrase, th, et in lignes:
        if qui == demandeur:
            attente.append(phrase)
        elif attente:
            entrees.append(Entree(attente, [phrase], et, th, chemin.name, noms))
            attente = []
    return entrees


def lire_maison(chemin: Path) -> list[Entree]:
    entrees, bloc = [], {"q": [], "r": [], "e": None}

    def fermer():
        if bloc["q"] and bloc["r"]:
            entrees.append(Entree(list(bloc["q"]), list(bloc["r"]), bloc["e"], "maison", chemin.name))
        bloc.update(q=[], r=[], e=None)

    for ligne in chemin.read_text(encoding="utf-8").splitlines():
        ligne = ligne.rstrip()
        if not ligne.strip():
            fermer()
        elif ligne.startswith("#"):
            continue
        elif ligne.startswith("Q:"):
            if bloc["r"]:
                fermer()
            bloc["q"].append(ligne[2:].strip())
        elif ligne.startswith("R+:") and bloc["r"]:
            bloc["r"][-1] += "\n" + ligne[3:].strip()
        elif ligne.startswith("R:"):
            bloc["r"].append(ligne[2:].strip())
        elif ligne.lower().startswith("étiquette:") or ligne.lower().startswith("etiquette:"):
            valeur = ligne.split(":", 1)[1].strip()
            bloc["e"] = valeur if valeur in ETIQUETTES else None
    fermer()
    return entrees


def lire_appris(db: SessionDB) -> list[Entree]:
    lignes = db.execute(text("SELECT texte, reponse, etiquette FROM assistant_questions WHERE statut = 'repondue'")).all()
    return [Entree([REPERE.sub(" ", l.texte)], [l.reponse or ""], l.etiquette, "appris", "Paramètres") for l in lignes
            if l.reponse or l.etiquette]


# ---------- Index de recherche (TF-IDF) ----------

POIDS_THEME, POIDS_REPONSE = 0.5, 0.3   # le thème et la réponse donnent le contexte des questions courtes


def mots_simples(texte: str) -> set[str]:
    """Tous les mots, même courants (pour les petites phrases : « ça va », « on dit quoi »)."""
    return {m for m in simplifier(texte).split() if m != "gerimo"}


def distance(a: str, b: str) -> int:
    """Nombre de lettres à changer, ajouter ou retirer pour passer de a à b."""
    precedente = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        ligne = [i]
        for j, cb in enumerate(b, 1):
            ligne.append(min(precedente[j] + 1, ligne[j - 1] + 1, precedente[j - 1] + (ca != cb)))
        precedente = ligne
    return precedente[-1]


def mot_proche(mot: str, vocabulaire: list[str]) -> str | None:
    """Le mot connu le plus proche (au moins 80 % de lettres communes), ou None."""
    meilleur, ecart = None, 1 + len(mot) // 5
    for v in vocabulaire:
        if abs(len(v) - len(mot)) < ecart and v[0] == mot[0]:
            d = distance(mot, v)
            if d < ecart:
                meilleur, ecart = v, d
    return meilleur


class Index:
    def __init__(self, entrees: list[Entree]):
        self.entrees = entrees
        documents = []   # (n° de l'entrée, {mot: poids}, question simplifiée, mots simples)
        for i, e in enumerate(entrees):
            contexte: dict[str, float] = {}
            if e.theme not in ("maison", "appris"):
                for m in mots(e.theme):
                    contexte[m] = contexte.get(m, 0) + POIDS_THEME
            for m in mots(" ".join(REPERE.sub(" ", r) for r in e.reponses)):
                contexte[m] = contexte.get(m, 0) + POIDS_REPONSE
            for q in e.questions:
                poids = dict(contexte)
                for m in mots(q):
                    poids[m] = poids.get(m, 0) + 1.0
                documents.append((i, poids, simplifier(q), mots_simples(q)))
        n = len(documents) or 1
        df: dict[str, int] = {}
        for _, poids, _, _ in documents:
            for m in poids:
                df[m] = df.get(m, 0) + 1
        self.idf = {m: math.log((n + 1) / (d + 1)) + 1 for m, d in df.items()}
        self.vocabulaire = list(self.idf)
        self.documents = [(i, self._vecteur(poids), simple, ensemble) for i, poids, simple, ensemble in documents]

    def _vecteur(self, poids: dict) -> dict:
        defaut = math.log(len(self.vocabulaire) + 2) + 1
        v = {m: x * self.idf.get(m, defaut) for m, x in poids.items()}
        norme = math.sqrt(sum(x * x for x in v.values())) or 1
        return {m: x / norme for m, x in v.items()}

    def corriger(self, ms: list[str]) -> list[str]:
        """Fautes de frappe : un mot inconnu devient le mot connu le plus proche (« logemant » → « logement »)."""
        sortie = []
        for m in ms:
            if m not in self.idf and len(m) >= 4:
                m = mot_proche(m, self.vocabulaire) or m
            sortie.append(m)
        return sortie

    def chercher(self, texte: str) -> tuple[Entree | None, float]:
        simple = " ".join(m for m in simplifier(texte).split() if m != "gerimo")
        poids: dict[str, float] = {}
        for m in self.corriger(mots(texte)):
            poids[m] = poids.get(m, 0) + 1.0
        q = self._vecteur(poids) if poids else {}
        ensemble = mots_simples(texte)
        meilleur, score = None, 0.0
        for i, v, question, mots_q in self.documents:
            if simple and simple == question:
                s = 1.0
            elif q:
                s = sum(x * v.get(m, 0) for m, x in q.items())
            else:  # que des mots courants : on compare les mots eux-mêmes (petites phrases)
                s = len(ensemble & mots_q) / len(ensemble | mots_q) if ensemble and mots_q else 0.0
            if s > score:
                meilleur, score = self.entrees[i], s
        return meilleur, score


_cache: dict = {"signature": None, "index": None}


def _signature(db: SessionDB) -> tuple:
    fichiers = sorted(DOSSIER_CONVERSATIONS.glob("*.txt")) + ([LEXIQUE_MAISON] if LEXIQUE_MAISON.exists() else [])
    try:
        appris = db.execute(text(
            "SELECT COUNT(*), md5(string_agg(id || texte || coalesce(reponse, '') || coalesce(etiquette, ''), '|' "
            "ORDER BY id)) FROM assistant_questions WHERE statut = 'repondue'")).one()
    except Exception:  # noqa: BLE001 — table pas encore créée
        db.rollback()
        appris = (0, None)
    return tuple((f.name, f.stat().st_mtime) for f in fichiers) + (tuple(appris),)


def index(db: SessionDB) -> Index:
    signature = _signature(db)
    if _cache["signature"] != signature:
        entrees: list[Entree] = []
        if LEXIQUE_MAISON.exists():
            entrees += lire_maison(LEXIQUE_MAISON)
        for f in sorted(DOSSIER_CONVERSATIONS.glob("*.txt")):
            entrees += [e for e in lire_conversation(f) if not any(REPERE.search(r) for r in e.reponses)]
        try:
            entrees += lire_appris(db)
        except Exception:  # noqa: BLE001
            db.rollback()
        _cache.update(signature=signature, index=Index(entrees))
    return _cache["index"]


# ---------- Réponse, selon les règles ----------

def prenom(u: Utilisateur) -> str:
    from assistant import prenom as appellation  # une seule règle pour tout l'assistant
    return appellation(u)


def personnes(db: SessionDB, role: str) -> list[str]:
    return [p.nom_complet for p in db.query(Utilisateur).filter(Utilisateur.actif.is_(True),
                                                                Utilisateur.role == RoleUtilisateur(role))
            .order_by(Utilisateur.nom_complet)]


def orientation(db: SessionDB, cible: str) -> str:
    noms = personnes(db, cible)
    if cible == "Comptable":
        qui = (" ou ".join(noms) + ", le comptable de l'agence") if noms else "le comptable de l'agence"
        domaine = "relève du comptable"
    else:
        qui = (" ou ".join(noms) + ", à la Caisse") if noms else "la personne chargée de la caisse"
        domaine = "concerne l'argent de la caisse"
    return (f"Cette question {domaine} : adressez-vous à {qui}. "
            "Je préfère vous orienter plutôt que de vous donner un chiffre qui ne serait pas le bon.")


def chiffres_reels(u: Utilisateur) -> dict:
    actions = [{"libelle": "Voir les rapports", "type": "ouvrir", "cible": "rapports"}] \
        if peut_acceder(u.role.value, "rapports") else []
    return {"reponse": "Je ne donne que des chiffres réels, et je ne les invente pas. Vous les trouverez sur le tableau "
                       "de bord de l'accueil et dans « Rapports & statistiques ». Je peux aussi vous dire tout de suite : "
                       "« Impayés », « Logements libres » ou « Qu'est-ce que j'ai aujourd'hui ? ».",
            "actions": actions}


def remplir(texte: str, u: Utilisateur, e: Entree) -> str:
    maintenant = datetime.now()
    for nom in e.noms:
        texte = re.sub(rf"\b{re.escape(nom)}\b", "{prenom}", texte)
    return (texte.replace("{prenom}", prenom(u)).replace("{salut}", "Bonsoir" if maintenant.hour >= 18 else "Bonjour")
            .replace("{heure}", maintenant.strftime("%H:%M")).replace("{date}", maintenant.strftime("%d/%m/%Y"))
            .replace(" ,", ",").replace(", !", " !"))


def construire_reponse(db: SessionDB, u: Utilisateur, e: Entree) -> dict:
    role = u.role.value
    reponse = random.choice(e.reponses)
    exemple = bool(MONTANT.search(reponse)) and e.theme != "maison" and e.source != "Paramètres"
    if e.etiquette in ("orienter : Comptable", "orienter : Caisse"):
        cible = e.etiquette.split(": ")[1]
        if role != cible:
            return {"reponse": orientation(db, cible), "actions": [], "mode": "lexique"}
        if exemple:
            return {**chiffres_reels(u), "mode": "lexique"}
    if e.etiquette == "chiffres réels" or reponse.startswith("Chiffres réels uniquement"):
        return {**chiffres_reels(u), "mode": "lexique"}
    texte = remplir(reponse, u, e)
    if exemple:
        texte = "Exemple de calcul (montants fictifs) : " + texte
    return {"reponse": texte, "actions": [], "mode": "lexique"}


def repondre(db: SessionDB, u: Utilisateur, texte: str, seuil: float = SEUIL_FORT) -> dict | None:
    e, score = index(db).chercher(texte)
    if e is None or score < seuil:
        return None
    if e.etiquette and score < SEUIL_FORT:
        return None  # orienter ou chiffres réels : seulement si la question est vraiment reconnue
    rep = construire_reponse(db, u, e)
    rep["score"] = round(score, 2)
    return rep


INTERROGATIFS = re.compile(r"^(comment|pourquoi|ou|quand|quel|quelle|quels|quelles|combien|est ce|qu est ce|c est quoi|"
                           r"a quoi|qui|que|quoi|peut on|puis je|je peux|on peut|tu peux|vous pouvez|faut il|dois je|"
                           r"il faut|ca sert|ca veut dire|explique|expliquez)\b")
EXPLICATION = re.compile(r"^(comment|pourquoi|c est quoi|qu est ce que c est|a quoi|ou (est|se trouve|trouver|je trouve)|"
                         r"ca sert|ca veut dire|explique|expliquez|quelle est la difference)\b")


def est_question(texte: str) -> bool:
    return texte.strip().endswith("?") or bool(INTERROGATIFS.match(simplifier(texte)))


def demande_explication(texte: str) -> bool:
    """« Comment… », « Pourquoi… », « C'est quoi… » : on veut une explication, pas une action ni un chiffre."""
    return bool(EXPLICATION.match(simplifier(texte)))


# ---------- Questions sans réponse (gardées sans nom ni numéro) ----------

TELEPHONE = re.compile(r"(?<!\d)(?:\+?225[\s.-]?)?0\d(?:[\s.-]?\d{2}){4}(?!\d)")
EMAIL = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")
CONTRAT = re.compile(r"\b[A-Z]{2,5}-\d{4}-\d{3,6}\b")
CIVILITE = re.compile(r"\b(M\.|Mr|Mme|Mlle|Monsieur|Madame|Mademoiselle|Docteur|Dr)\s+[A-ZÀ-ÿ][\wÀ-ÿ'-]*(?:\s+[A-ZÀ-Ý][\wÀ-ÿ'-]*)?")


def anonymiser(db: SessionDB, texte: str) -> str:
    t = EMAIL.sub("[e-mail]", texte)
    t = TELEPHONE.sub("[téléphone]", t)
    t = CONTRAT.sub("[numéro]", t)
    t = CIVILITE.sub(lambda m: m.group(1) + " [nom]", t)
    t = re.sub(r"\d[\d  .]{2,}\d|\d{3,}", "[nombre]", t)
    # mots qui sont des noms de personnes enregistrées (locataires, propriétaires, clients, employés)
    for mot in set(re.findall(r"\b[A-ZÀ-Ý][\wÀ-ÿ'-]{2,}\b", t)):
        trouve = db.execute(text(
            "SELECT 1 FROM (SELECT nom_complet AS n FROM locataires UNION ALL SELECT nom_complet FROM proprietaires "
            "UNION ALL SELECT nom_complet FROM utilisateurs UNION ALL SELECT nom_complet FROM prospects) x "
            "WHERE n ~* :motif LIMIT 1"), {"motif": rf"\m{re.escape(mot)}\M"}).first()
        if trouve:
            t = re.sub(rf"\b{re.escape(mot)}\b", "[nom]", t)
    return re.sub(r"\s+", " ", t).strip()[:300]


def noter_question(db: SessionDB, u: Utilisateur, texte: str) -> None:
    if len(simplifier(texte)) < 6:
        return
    try:
        propre = anonymiser(db, texte)
        cle = simplifier(propre)[:300]
        ligne = db.execute(text("SELECT id, profils FROM assistant_questions WHERE cle = :c"), {"c": cle}).first()
        if ligne:
            profils = ", ".join(sorted(set(filter(None, ligne.profils.split(", "))) | {u.role.value}))
            db.execute(text("UPDATE assistant_questions SET nb = nb + 1, derniere = NOW(), profils = :p WHERE id = :i"),
                       {"p": profils, "i": ligne.id})
        else:
            db.execute(text("INSERT INTO assistant_questions (texte, cle, profils) VALUES (:t, :c, :p)"),
                       {"t": propre, "c": cle, "p": u.role.value})
        db.commit()
    except Exception:  # noqa: BLE001 — une question non notée ne doit jamais bloquer l'assistant
        db.rollback()


# ---------- Dictionnaire de la dictée ----------

_corrections: dict = {"signature": None, "liste": []}


def corriger_dictee(db: SessionDB, texte: str) -> str:
    """Ce que la dictée entend mal (« Jérimo ») remplacé par ce qu'il faut comprendre (« Gérimo »)."""
    try:
        signature = db.execute(text("SELECT COUNT(*), MAX(id) FROM dictee_corrections")).one()
        if _corrections["signature"] != tuple(signature):
            _corrections.update(signature=tuple(signature), liste=[
                (l.entendu, l.corrige) for l in db.execute(text("SELECT entendu, corrige FROM dictee_corrections"))])
    except Exception:  # noqa: BLE001 — table pas encore créée
        db.rollback()
        return texte
    for entendu, corrige in sorted(_corrections["liste"], key=lambda x: -len(x[0])):
        motif = r"(?<![\wÀ-ÿ])" + r"\s+".join(re.escape(p) for p in entendu.split()) + r"(?![\wÀ-ÿ])"
        texte = re.sub(motif, corrige, texte, flags=re.IGNORECASE)
    return texte


# ---------- Écrans de l'Admin (Paramètres → Assistant) ----------

@router.get("/assistant/questions")
def lister_questions(statut: str = "nouvelle", admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    if statut not in ("nouvelle", "repondue", "ignoree"):
        raise HTTPException(status_code=400, detail="Statut inconnu.")
    lignes = db.execute(text("SELECT id, texte, nb, profils, premiere, derniere, statut, reponse, etiquette "
                             "FROM assistant_questions WHERE statut = :s ORDER BY nb DESC, derniere DESC LIMIT 300"),
                        {"s": statut}).mappings().all()
    compte = dict(db.execute(text("SELECT statut, COUNT(*) FROM assistant_questions GROUP BY statut")).all())
    return {"questions": [{**l, "premiere": l["premiere"].strftime("%d/%m/%Y"),
                           "derniere": l["derniere"].strftime("%d/%m/%Y à %H:%M")} for l in lignes],
            "compte": {s: compte.get(s, 0) for s in ("nouvelle", "repondue", "ignoree")}}


class TraitementIn(BaseModel):
    action: str = Field(pattern="^(repondre|orienter_comptable|orienter_caisse|ignorer|rouvrir|supprimer)$")
    reponse: str = Field("", max_length=2000)
    texte: str = Field("", max_length=300)
    mot_de_passe_admin: str = ""


@router.post("/assistant/questions/{question_id}")
def traiter_question(question_id: int, d: TraitementIn, admin: Utilisateur = Depends(exiger_admin),
                     db: SessionDB = Depends(get_db)):
    if not db.execute(text("SELECT 1 FROM assistant_questions WHERE id = :i"), {"i": question_id}).first():
        raise HTTPException(status_code=404, detail="Question introuvable.")
    if d.action == "supprimer":
        confirmer_mot_de_passe_admin(admin, d.mot_de_passe_admin)
        db.execute(text("DELETE FROM assistant_questions WHERE id = :i"), {"i": question_id})
        db.commit()
        return {"ok": True}
    valeurs = {"i": question_id, "u": admin.id, "r": None, "e": None, "s": "repondue"}
    if d.action == "repondre":
        if len(d.reponse.strip()) < 2:
            raise HTTPException(status_code=400, detail="Écrivez la réponse que Gérimo doit donner.")
        if any(c in d.reponse for c in "<>`"):
            raise HTTPException(status_code=400, detail="Caractères non acceptés dans la réponse.")
        valeurs["r"] = d.reponse.strip()
    elif d.action in ("orienter_comptable", "orienter_caisse"):
        valeurs["e"] = "orienter : Comptable" if d.action == "orienter_comptable" else "orienter : Caisse"
    else:
        valeurs["s"] = "ignoree" if d.action == "ignorer" else "nouvelle"
    db.execute(text("UPDATE assistant_questions SET statut = :s, reponse = :r, etiquette = :e, traite_par = :u, "
                    "traite_le = NOW() WHERE id = :i"), valeurs)
    if d.texte.strip():  # l'Admin peut reformuler la question (retirer un détail, corriger une faute)
        db.execute(text("UPDATE assistant_questions SET texte = :t WHERE id = :i"),
                   {"t": d.texte.strip()[:300], "i": question_id})
    db.commit()
    return {"ok": True}


class CorrectionIn(BaseModel):
    entendu: str = Field(min_length=2, max_length=80)
    corrige: str = Field(min_length=1, max_length=120)


@router.get("/assistant/dictee")
def lister_corrections(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    return [dict(l) for l in db.execute(text("SELECT id, entendu, corrige FROM dictee_corrections ORDER BY entendu"))
            .mappings()]


@router.post("/assistant/dictee")
def ajouter_correction(d: CorrectionIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    entendu, corrige = d.entendu.strip().lower(), d.corrige.strip()
    if any(c in entendu + corrige for c in "<>`"):
        raise HTTPException(status_code=400, detail="Caractères non acceptés.")
    db.execute(text("INSERT INTO dictee_corrections (entendu, corrige) VALUES (:e, :c) "
                    "ON CONFLICT (entendu) DO UPDATE SET corrige = :c"), {"e": entendu, "c": corrige})
    db.commit()
    return {"ok": True}


@router.delete("/assistant/dictee/{correction_id}")
def supprimer_correction(correction_id: int, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    db.execute(text("DELETE FROM dictee_corrections WHERE id = :i"), {"i": correction_id})
    db.commit()
    return {"ok": True}
