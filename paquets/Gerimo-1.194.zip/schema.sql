-- ============================================================
-- ISUP ERP — Schéma de base de données (module Gestion Locative)
-- À exécuter sur la base isup_erp
-- ============================================================

-- Indispensable sous Windows : sans cette ligne, psql lit les accents de ce
-- fichier avec le mauvais encodage (« Cité » devient « CitÃ© »).
SET client_encoding = 'UTF8';

-- ---------- Types énumérés (listes de valeurs fixes) ----------

CREATE TYPE role_utilisateur AS ENUM ('Admin','Gestionnaire','Caisse');

CREATE TYPE type_batiment AS ENUM (
  'Appartement/Immeuble','Cité','Maison basse','Villa','Duplex','Cour commune','Résidence'
);

CREATE TYPE type_logement AS ENUM (
  'Studio','2 pièces','3 pièces','4 pièces','5 pièces','6 pièces','7 pièces','8 pièces',
  'Villa de plus de 8 pièces','Magasin'
);

CREATE TYPE statut_logement AS ENUM ('Libre','Occupé','Réservé','Maintenance');

CREATE TYPE type_contrat AS ENUM (
  'Bail habitation','Bail commercial','Location meublée','Courte durée','Colocation','Gestion immobilière'
);

CREATE TYPE statut_contrat AS ENUM ('Actif','Expiré','Résilié','Suspendu','En attente','Renouvelé');

CREATE TYPE usage_bien AS ENUM (
  'Habitation','Commercial','Professionnel','Industriel','Stockage',
  'Mixte (habitation + activités)','Courte durée'
);

CREATE TYPE mode_paiement AS ENUM ('Espèce','Mobile Money','Virement','Chèque','Autre');

CREATE TYPE statut_paiement AS ENUM ('Payé','En attente','Annulé','Impayé','Remboursé');

CREATE TYPE motif_paiement AS ENUM ('Loyer mensuel','Caution/avance','Règlement total');

CREATE TYPE statut_impayes AS ENUM ('En retard','À risque','Régularisé');

CREATE TYPE type_document AS ENUM ('Contrat de bail','Reçu de paiement','Facture','Quittance','Décharge');

CREATE TYPE type_operation_av AS ENUM ('Achat','Vente');

-- ---------- Utilisateurs ----------

CREATE TABLE utilisateurs (
  id              SERIAL PRIMARY KEY,
  nom_complet     VARCHAR(150) NOT NULL,
  identifiant     VARCHAR(80) NOT NULL UNIQUE,
  mot_de_passe    VARCHAR(255) NOT NULL,   -- stocké haché (jamais en clair)
  role            role_utilisateur NOT NULL,
  actif           BOOLEAN NOT NULL DEFAULT TRUE,
  cree_le         TIMESTAMP NOT NULL DEFAULT now()
);

-- ---------- Propriétaires et gestionnaires ----------

CREATE TABLE proprietaires (
  id              SERIAL PRIMARY KEY,
  nom_complet     VARCHAR(150) NOT NULL,
  cni             VARCHAR(50),
  telephone       VARCHAR(30),
  ville           VARCHAR(80),
  cree_le         TIMESTAMP NOT NULL DEFAULT now()
);

CREATE TABLE gestionnaires (
  id              SERIAL PRIMARY KEY,
  nom             VARCHAR(150) NOT NULL,
  rccm            VARCHAR(80),
  ncc             VARCHAR(80),
  adresse         VARCHAR(200),
  ville           VARCHAR(80),
  cree_le         TIMESTAMP NOT NULL DEFAULT now()
);

-- ---------- Biens : cités / logements ----------

CREATE TABLE cites (
  id                  SERIAL PRIMARY KEY,
  nom                 VARCHAR(150) NOT NULL,
  adresse             VARCHAR(200),
  nombre_logements    INTEGER DEFAULT 0,
  proprietaire_id     INTEGER REFERENCES proprietaires(id),
  description         TEXT,
  cree_le             TIMESTAMP NOT NULL DEFAULT now()
);

-- Mandat de gestion : lie un gestionnaire à un propriétaire/bien, avec commission
CREATE TABLE contrats_gestion (
  id                  SERIAL PRIMARY KEY,
  gestionnaire_id     INTEGER NOT NULL REFERENCES gestionnaires(id),
  proprietaire_id     INTEGER NOT NULL REFERENCES proprietaires(id),
  cite_id             INTEGER NOT NULL REFERENCES cites(id),
  pourcentage_commission  NUMERIC(5,2) NOT NULL,   -- ex : 15.00 pour 15%
  date_debut          DATE NOT NULL,
  cree_le             TIMESTAMP NOT NULL DEFAULT now()
);

CREATE TABLE logements (
  id                  SERIAL PRIMARY KEY,
  cite_id             INTEGER NOT NULL REFERENCES cites(id),
  type_batiment       type_batiment NOT NULL,
  numero_logement     VARCHAR(30) NOT NULL,
  type_logement       type_logement NOT NULL,
  loyer               NUMERIC(12,2) NOT NULL,
  statut_logement     statut_logement NOT NULL DEFAULT 'Libre',
  cree_le             TIMESTAMP NOT NULL DEFAULT now()
);

-- ---------- Locataires et contrats de bail ----------

CREATE TABLE locataires (
  id              SERIAL PRIMARY KEY,
  nom_complet     VARCHAR(150) NOT NULL,
  cni             VARCHAR(50),
  telephone       VARCHAR(30),
  profession      VARCHAR(100),
  cree_le         TIMESTAMP NOT NULL DEFAULT now()
);

CREATE TABLE contrats (
  id                SERIAL PRIMARY KEY,
  numero_contrat    VARCHAR(40) NOT NULL UNIQUE,
  logement_id       INTEGER NOT NULL REFERENCES logements(id),
  locataire_id      INTEGER NOT NULL REFERENCES locataires(id),
  type_contrat      type_contrat NOT NULL,
  usage_bien        usage_bien NOT NULL,
  statut_contrat    statut_contrat NOT NULL DEFAULT 'Actif',
  montant_loyer     NUMERIC(12,2) NOT NULL,
  mois_caution      INTEGER DEFAULT 0,
  montant_caution   NUMERIC(12,2) DEFAULT 0,
  mois_avance       INTEGER DEFAULT 0 CHECK (mois_avance BETWEEN 0 AND 3),
  montant_avance    NUMERIC(12,2) DEFAULT 0,
  date_debut        DATE NOT NULL,
  date_fin          DATE,
  mois_impayes_consecutifs INTEGER NOT NULL DEFAULT 0,  -- utilisé pour le statut "à risque"
  cree_le           TIMESTAMP NOT NULL DEFAULT now()
);

CREATE TABLE echeances (
  id                SERIAL PRIMARY KEY,
  contrat_id        INTEGER NOT NULL REFERENCES contrats(id),
  mois_echeance     DATE NOT NULL,          -- ex : 2026-10-01 pour "octobre 2026"
  montant_loyer     NUMERIC(12,2) NOT NULL,
  montant_charges   NUMERIC(12,2) DEFAULT 0,
  date_limite       DATE NOT NULL,          -- ex : le 05 du mois
  cree_le           TIMESTAMP NOT NULL DEFAULT now()
);

-- ---------- Paiements et encaissements ----------

CREATE TABLE paiements (
  id                SERIAL PRIMARY KEY,
  contrat_id        INTEGER NOT NULL REFERENCES contrats(id),
  montant           NUMERIC(12,2) NOT NULL,
  date_paiement     DATE NOT NULL DEFAULT CURRENT_DATE,
  statut_paiement   statut_paiement NOT NULL DEFAULT 'En attente',
  mode_paiement     mode_paiement NOT NULL,
  motif_paiement    motif_paiement NOT NULL,
  cree_le           TIMESTAMP NOT NULL DEFAULT now()
);

CREATE TABLE encaissements (
  id                  SERIAL PRIMARY KEY,
  paiement_id         INTEGER NOT NULL REFERENCES paiements(id),
  date_encaissement   DATE NOT NULL DEFAULT CURRENT_DATE,
  montant_encaisse    NUMERIC(12,2) NOT NULL,
  commission_entreprise     NUMERIC(12,2) DEFAULT 0,   -- calculée via % du contrat de gestion
  montant_reverse     NUMERIC(12,2) DEFAULT 0,   -- montant_encaisse - commission_entreprise
  observation         TEXT,
  cree_le             TIMESTAMP NOT NULL DEFAULT now()
);

CREATE TABLE impayes (
  id                SERIAL PRIMARY KEY,
  locataire_id      INTEGER NOT NULL REFERENCES locataires(id),
  logement_id       INTEGER NOT NULL REFERENCES logements(id),
  cite_id           INTEGER NOT NULL REFERENCES cites(id),
  mois              DATE NOT NULL,
  montant_du        NUMERIC(12,2) NOT NULL,
  statut_impayes    statut_impayes NOT NULL DEFAULT 'En retard',
  cree_le           TIMESTAMP NOT NULL DEFAULT now()
);

-- ---------- Dépenses ----------

CREATE TABLE depenses (
  id              SERIAL PRIMARY KEY,
  cite_id         INTEGER NOT NULL REFERENCES cites(id),
  montant         NUMERIC(12,2) NOT NULL,
  motif           VARCHAR(200) NOT NULL,
  date_depense    DATE NOT NULL DEFAULT CURRENT_DATE,
  cree_le         TIMESTAMP NOT NULL DEFAULT now()
);

-- ---------- Documents générés (reçus, factures, contrats, quittances) ----------

CREATE TABLE documents (
  id                SERIAL PRIMARY KEY,
  contrat_id        INTEGER REFERENCES contrats(id),
  type_document     type_document NOT NULL,
  chemin_fichier    VARCHAR(300),
  nom_fichier       VARCHAR(200),
  date_generation   TIMESTAMP NOT NULL DEFAULT now()
);

-- ---------- Achats / Ventes de biens ----------

CREATE TABLE achats_ventes (
  id                SERIAL PRIMARY KEY,
  type_operation    type_operation_av NOT NULL,
  cite_id           INTEGER REFERENCES cites(id),
  partie_nom        VARCHAR(150) NOT NULL,     -- acheteur ou vendeur
  partie_telephone  VARCHAR(30),
  montant           NUMERIC(14,2) NOT NULL,
  mode_paiement     mode_paiement NOT NULL,
  date_operation    DATE NOT NULL DEFAULT CURRENT_DATE,
  type_document     type_document NOT NULL,
  cree_le           TIMESTAMP NOT NULL DEFAULT now()
);

-- ============================================================
-- Index utiles pour les recherches et tableaux de bord fréquents
-- ============================================================

CREATE INDEX idx_logements_cite ON logements(cite_id);
CREATE INDEX idx_contrats_logement ON contrats(logement_id);
CREATE INDEX idx_contrats_locataire ON contrats(locataire_id);
CREATE INDEX idx_contrats_statut ON contrats(statut_contrat);
CREATE INDEX idx_paiements_contrat ON paiements(contrat_id);
CREATE INDEX idx_echeances_contrat ON echeances(contrat_id);
CREATE INDEX idx_impayes_statut ON impayes(statut_impayes);
