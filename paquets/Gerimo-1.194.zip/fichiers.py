"""Fichiers envoyés depuis l'interface : photos (appareil photo ou fichier) et PDF.

Les fichiers arrivent en base64 (« data URL ») dans le JSON. Contrôles côté serveur :
- types acceptés : JPEG, PNG, WebP, HEIC n'est pas lu par tous les navigateurs → refusé ; PDF ;
- taille maximale ;
- les images sont ré-enregistrées en JPEG (redressées, réduites, sans les données cachées EXIF
  comme la position GPS) : un fichier piégé déguisé en image ne passe pas.
Tout est rangé dans documents/ (exclu de Git, à inclure dans les sauvegardes).
"""
import base64
import binascii
import io
import re
import secrets
from datetime import date
from pathlib import Path

from fastapi import HTTPException
from fastapi.responses import FileResponse
from PIL import Image, ImageOps, UnidentifiedImageError

DOSSIER_DOCUMENTS = Path(__file__).parent / "documents"
TAILLE_MAX = 12 * 1024 * 1024        # 12 Mo par fichier
COTE_MAX_IMAGE = 2000                # pixels : assez pour lire une CNI, sans alourdir
DATA_URL = re.compile(r"^data:([\w/+.-]+);base64,(.*)$", re.S)


def decoder(contenu: str) -> tuple[str, bytes]:
    """« data:image/jpeg;base64,… » → (type, octets). Erreur 400 si illisible ou trop gros."""
    m = DATA_URL.match(contenu or "")
    if not m:
        raise HTTPException(status_code=400, detail="Fichier illisible.")
    if len(m.group(2)) > TAILLE_MAX * 4 // 3 + 4:
        raise HTTPException(status_code=413, detail="Fichier trop lourd (12 Mo maximum).")
    try:
        octets = base64.b64decode(m.group(2), validate=True)
    except (binascii.Error, ValueError):
        raise HTTPException(status_code=400, detail="Fichier illisible.")
    return m.group(1).lower(), octets


def image_propre(octets: bytes, cote_max: int = COTE_MAX_IMAGE) -> bytes:
    """Vérifie que c'est une vraie image et la ré-enregistre en JPEG propre."""
    try:
        image = Image.open(io.BytesIO(octets))
        image.load()
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
        raise HTTPException(status_code=400, detail="Ce fichier n'est pas une image valable (JPEG, PNG ou WebP).")
    image = ImageOps.exif_transpose(image)  # photo de téléphone : bon sens de lecture
    if image.mode not in ("RGB", "L"):
        fond = Image.new("RGB", image.size, "white")
        fond.paste(image, mask=image.convert("RGBA").split()[-1])
        image = fond
    image.thumbnail((cote_max, cote_max))
    sortie = io.BytesIO()
    image.save(sortie, "JPEG", quality=85, optimize=True)
    return sortie.getvalue()


def enregistrer_fichier(contenu: str, sous_dossier: str, *, pdf_autorise: bool = True,
                        cote_max: int = COTE_MAX_IMAGE) -> tuple[str, str, int]:
    """Enregistre le fichier ; renvoie (chemin relatif à documents/, type MIME, taille)."""
    type_mime, octets = decoder(contenu)
    if type_mime == "application/pdf":
        if not pdf_autorise:
            raise HTTPException(status_code=400, detail="Seules les photos sont acceptées ici.")
        if not octets.startswith(b"%PDF"):
            raise HTTPException(status_code=400, detail="Ce fichier n'est pas un PDF valable.")
        extension = "pdf"
    elif type_mime in ("image/jpeg", "image/png", "image/webp", "image/jpg"):
        octets = image_propre(octets, cote_max)
        type_mime, extension = "image/jpeg", "jpg"
    else:
        raise HTTPException(status_code=400, detail="Type de fichier non accepté : photo (JPEG, PNG) ou PDF.")
    # nom imprévisible : on ne peut pas deviner l'adresse des autres fichiers
    relatif = Path(sous_dossier) / str(date.today().year) / f"{secrets.token_hex(12)}.{extension}"
    chemin = DOSSIER_DOCUMENTS / relatif
    chemin.parent.mkdir(parents=True, exist_ok=True)
    chemin.write_bytes(octets)
    return relatif.as_posix(), type_mime, len(octets)


def chemin_absolu(relatif: str) -> Path:
    chemin = (DOSSIER_DOCUMENTS / relatif).resolve()
    if DOSSIER_DOCUMENTS.resolve() not in chemin.parents:  # jamais en dehors de documents/
        raise HTTPException(status_code=404, detail="Fichier introuvable.")
    return chemin


def servir(relatif: str | None, nom: str | None = None, type_mime: str | None = None) -> FileResponse:
    if not relatif:
        raise HTTPException(status_code=404, detail="Fichier introuvable.")
    chemin = chemin_absolu(relatif)
    if not chemin.exists():
        raise HTTPException(status_code=404, detail="Fichier introuvable (supprimé du disque ?).")
    return FileResponse(chemin, media_type=type_mime, filename=nom or chemin.name,
                        content_disposition_type="inline", headers={"Cache-Control": "private, max-age=3600"})


CORBEILLE = ".corbeille"  # sous-dossier de documents/ : fichiers des éléments supprimés


def effacer(relatif: str | None) -> None:
    """Le fichier d'un élément supprimé part dans la corbeille (documents/.corbeille/…), pas à la poubelle :
    si l'Admin restaure l'élément, le fichier revient à sa place."""
    if relatif:
        try:
            source = chemin_absolu(relatif)
            if source.exists():
                cible = DOSSIER_DOCUMENTS / CORBEILLE / relatif
                cible.parent.mkdir(parents=True, exist_ok=True)
                source.replace(cible)
        except (HTTPException, OSError):
            pass


def sortir_de_la_corbeille(relatif: str | None) -> None:
    if relatif:
        try:
            cible = chemin_absolu(relatif)
            source = DOSSIER_DOCUMENTS / CORBEILLE / relatif
            if source.exists() and not cible.exists():
                cible.parent.mkdir(parents=True, exist_ok=True)
                source.replace(cible)
        except (HTTPException, OSError):
            pass


def nom_propre(nom: str | None, defaut: str = "fichier") -> str:
    """Nom de fichier affichable : sans chemin ni caractères spéciaux."""
    nom = Path(nom or "").name
    nom = re.sub(r"[^\w .()\-]", "_", nom, flags=re.UNICODE).strip()[:120]
    return nom or defaut
