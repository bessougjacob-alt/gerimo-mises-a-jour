"""Outils partagés par les modules (biens, contrats…)."""
import re
from decimal import Decimal
from typing import Annotated

from fastapi import HTTPException
from pydantic import AfterValidator, BaseModel, ConfigDict
from sqlalchemy import Integer, cast, func, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session as SessionDB

from models import RoleUtilisateur, Utilisateur


class Formulaire(BaseModel):
    """Base des formulaires : les espaces autour des textes sont retirés."""
    model_config = ConfigDict(str_strip_whitespace=True)


# ---------- Contrôle des saisies (la même règle est appliquée à l'écran, dans saisie.js) ----------
# Chaque type renvoie le texte nettoyé, ou lève ValueError avec un message en français
# (affiché sous la forme « « Nom complet » : ne doit pas contenir de chiffres. »).

LETTRES = "A-Za-zÀ-ÖØ-öø-ÿŒœ"
CARACTERES_INTERDITS = re.compile(r"[<>{}`\\]")          # jamais dans un texte
CONTROLE = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")        # caractères invisibles


def _espaces(texte: str) -> str:
    return re.sub(r"\s+", " ", CONTROLE.sub("", texte)).strip()


def _nom_personne(v: str) -> str:
    v = _espaces(v)
    if not v:
        return v
    if re.search(r"\d", v):
        raise ValueError("un nom ne doit pas contenir de chiffres.")
    if not re.fullmatch(rf"[{LETTRES}' ’.\-]+", v) or not re.search(rf"[{LETTRES}]", v):
        raise ValueError("seulement des lettres, espaces, tirets (-), apostrophes et points.")
    return v


def _mots(v: str) -> str:
    """Ville, profession : des mots, sans chiffres."""
    v = _espaces(v)
    if not v:
        return v
    if re.search(r"\d", v):
        raise ValueError("ne doit pas contenir de chiffres.")
    if not re.fullmatch(rf"[{LETTRES}' ’.\-/(),]+", v):
        raise ValueError("seulement des lettres, espaces et tirets.")
    return v


def _nom_bien(v: str) -> str:
    v = _espaces(v)
    if v and not (re.fullmatch(rf"[{LETTRES}0-9' ’.\-,()/&°]+", v) and re.search(rf"[{LETTRES}]", v)):
        raise ValueError("lettres et chiffres seulement (ex : Cité Agnikro, Résidence 2000).")
    return v


def _code(v: str) -> str:
    """Numéro de logement ou de lot : B12, A-4, Lot 12/3…"""
    v = _espaces(v)
    if v and not (re.fullmatch(rf"[{LETTRES}0-9 ./\-]+", v) and re.search(rf"[{LETTRES}0-9]", v)):
        raise ValueError("lettres, chiffres, tiret (-), barre (/) ou point seulement (ex : B12, Lot 12).")
    return v


def _telephone(v: str) -> str:
    v = _espaces(v)
    if not v:
        return v
    if not re.fullmatch(r"\+?[0-9 .\-()]+", v):
        raise ValueError("seulement des chiffres (ex : 07 01 02 03 04).")
    if not 8 <= len(re.sub(r"\D", "", v)) <= 15:
        raise ValueError("numéro incomplet ou trop long (10 chiffres en Côte d'Ivoire).")
    return v


def _cni(v: str) -> str:
    v = _espaces(v).upper()
    if not v:
        return v
    if not re.fullmatch(r"[A-Z0-9 \-]+", v):
        raise ValueError("lettres et chiffres seulement.")
    if not 4 <= len(re.sub(r"[^A-Z0-9]", "", v)) <= 20:
        raise ValueError("numéro trop court ou trop long.")
    return v


def _email(v: str) -> str:
    v = _espaces(v).lower()
    if v and not re.fullmatch(r"[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}", v):
        raise ValueError("adresse e-mail invalide (ex : nom@gmail.com).")
    return v


def _texte(v: str) -> str:
    """Texte libre d'une ligne (adresse, motif…) : tout sauf les caractères dangereux."""
    v = _espaces(v)
    if CARACTERES_INTERDITS.search(v):
        raise ValueError("les caractères < > { } ` \\ ne sont pas acceptés.")
    return v


def _paragraphe(v: str) -> str:
    """Texte libre sur plusieurs lignes (description, documents)."""
    v = "\n".join(re.sub(r"[ \t]+", " ", ligne).strip() for ligne in CONTROLE.sub("", v).splitlines()).strip()
    if CARACTERES_INTERDITS.search(v):
        raise ValueError("les caractères < > { } ` \\ ne sont pas acceptés.")
    return v


NomPersonne = Annotated[str, AfterValidator(_nom_personne)]
Mots = Annotated[str, AfterValidator(_mots)]
NomBien = Annotated[str, AfterValidator(_nom_bien)]
Code = Annotated[str, AfterValidator(_code)]
Telephone = Annotated[str, AfterValidator(_telephone)]
Cni = Annotated[str, AfterValidator(_cni)]
Texte = Annotated[str, AfterValidator(_texte)]
Email = Annotated[str, AfterValidator(_email)]
Paragraphe = Annotated[str, AfterValidator(_paragraphe)]


class Suppression(BaseModel):
    mot_de_passe_admin: str


def montant(valeur: Decimal | None) -> int | float:
    if valeur is None:
        return 0
    return int(valeur) if valeur == valeur.to_integral_value() else float(valeur)


def numero_suivant(db: SessionDB, colonne, prefixe: str, chiffres: int) -> str:
    """Prochain numéro « PREFIXE-NNNN » (ex. BAIL-2026-0001, REC-2026-00001).

    Un verrou évite que deux postes obtiennent le même numéro au même moment.
    """
    db.execute(text("SELECT pg_advisory_xact_lock(hashtext(:cle))"), {"cle": prefixe})
    rang = len(prefixe.split("-")) + 1  # position du numéro dans « BAIL-2026-0001 »
    dernier = db.query(func.max(cast(func.split_part(colonne, "-", rang), Integer))).filter(
        colonne.like(prefixe + "-%")
    ).scalar()
    return f"{prefixe}-{(dernier or 0) + 1:0{chiffres}d}"


def est_admin(utilisateur: Utilisateur) -> bool:
    return utilisateur.role == RoleUtilisateur.Admin


def voit_finances(utilisateur: Utilisateur) -> bool:
    """Chiffres sensibles (commission, reversements, achats/ventes) : Admin, Caisse et Comptable."""
    return utilisateur.role in (RoleUtilisateur.Admin, RoleUtilisateur.Caisse, RoleUtilisateur.Comptable)


def charger(db: SessionDB, modele, id_: int, message: str):
    objet = db.get(modele, id_)
    if objet is None:
        raise HTTPException(status_code=404, detail=message)
    return objet


def enregistrer(db: SessionDB, message_doublon: str) -> None:
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail=message_doublon)


def supprimer(db: SessionDB, objet, message_lie: str) -> dict:
    db.delete(objet)
    try:
        db.commit()
    except IntegrityError:
        # encore utilisé ailleurs (contrat, paiement, dépense…)
        db.rollback()
        raise HTTPException(status_code=409, detail=message_lie)
    return {"ok": True}
