"""Gérimo, l'assistant d'ISUP : rappels, alertes et suivi, calculés à partir des données du logiciel.

Il fonctionne sans Internet et sans abonnement : c'est un assistant « à règles », qui connaît
le métier de la gestion locative. Il :
- liste ce qu'il y a à faire aujourd'hui, du plus urgent au moins urgent (rendez-vous, appels,
  loyers à échéance, impayés, contrats à risque ou en fin de bail, états des lieux, courriers non
  envoyés, clients à rappeler, problèmes signalés, sauvegarde…) — selon les droits de chacun ;
- prépare un résumé à lire à voix haute ;
- comprend des phrases simples en français (« Rappelle-moi d'appeler M. Koffi demain à 10h »,
  « Nouveau client Kouamé Ange 07 07 07 07 07 cherche un 2 pièces à Agnikro, budget 60 000 »)
  et crée le rendez-vous ou la demande de client correspondante.
"""
import re
import unicodedata
from datetime import date, datetime, time, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session as SessionDB, selectinload

import certificats
import parametres
import recus
import sauvegarde
from commun import voit_finances
from agenda import evenements_visibles, logements_correspondants
from models import (Cite, Contrat, Reservation, Courrier, DemandeReinitialisation, Evenement, Logement, Prospect, Signalement, Utilisateur,
                    STATUTS_EN_COURS)
from paiements import contrats_du_perimetre, recalculer_tout, resume_impayes
from securite import cites_autorisees, get_db, peut_acceder, utilisateur_connecte
from whatsapp import derniers_envois, prochaine_echeance

router = APIRouter(prefix="/api")

JOURS = ("lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche")
MOIS = ("janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre",
        "novembre", "décembre")
ORDRE_NIVEAU = {"urgent": 0, "attention": 1, "info": 2}


def f(valeur) -> str:
    return f"{Decimal(str(valeur or 0)):,.0f}".replace(",", " ") + " F"


def jour_fr(d: date) -> str:
    return f"{JOURS[d.weekday()]} {d.day} {MOIS[d.month - 1]}"


def prenom(utilisateur: Utilisateur) -> str:
    """Comment Gérimo appelle l'utilisateur : son appellation choisie (« Monsieur BESSOU »), sinon son prénom,
    le premier mot du nom qui n'est pas écrit en majuscules (« KOFFI Awa Marie » → « Awa »)."""
    if utilisateur.appellation:
        return utilisateur.appellation
    morceaux = (utilisateur.nom_complet or "").split()
    prenoms = [m for m in morceaux if not m.isupper()] or morceaux[1:] or morceaux
    return prenoms[0].capitalize() if prenoms else ""


APPELLATION = re.compile(r"^\s*(?:gerimo\s*,?\s*)?(?:appelle[sz]?[- ]moi|tu peux m['’]?\s*appeler|vous pouvez m['’]?\s*appeler|"
                         r"mon nom c['’]?\s*est|je m['’]?\s*appelle)\s+(.{2,60}?)\s*[.!]?\s*$", re.IGNORECASE)


# ---------- Ce qu'il y a à faire ----------

def taches(db: SessionDB, u: Utilisateur) -> tuple[list[dict], list[dict]]:
    """(tâches triées, rappels horaires du jour pour les pop-up / la voix)."""
    role = u.role.value
    aujourdhui = date.today()
    maintenant = datetime.now()
    liste: list[dict] = []
    rappels: list[dict] = []

    def ajouter(cle, niveau, categorie, titre, detail="", actions=(), quand=None, le=None):
        # le : date de ce que concerne la notification (rendez-vous, mois impayé…) ; sans date = aujourd'hui.
        # Le bandeau « Bonjour » ne fait défiler que les plus proches d'aujourd'hui (réglage defilement_max).
        liste.append({"cle": cle, "niveau": niveau, "categorie": categorie, "titre": titre, "detail": detail,
                      "actions": list(actions), "quand": quand, "le": (le or aujourdhui).isoformat()})

    # 1. Agenda : en retard, aujourd'hui, demain
    if peut_acceder(role, "agenda"):
        evts = evenements_visibles(db, u).options(selectinload(Evenement.prospect)).filter(
            Evenement.fait.is_(False), Evenement.date_evenement <= aujourdhui + timedelta(days=1)
        ).order_by(Evenement.date_evenement, Evenement.heure.nulls_first()).all()
        for e in evts:
            heure = e.heure.strftime("%H:%M") if e.heure else ""
            actions = [{"libelle": "Fait", "type": "agenda_fait", "id": e.id}]
            if e.telephone:
                actions.insert(0, {"libelle": "Appeler / WhatsApp", "type": "whatsapp", "telephone": e.telephone,
                                   "texte": ""})
            if e.date_evenement < aujourdhui:
                ajouter(f"agenda-{e.id}", "urgent", e.type_evenement, f"En retard : {e.titre}",
                        f"Prévu le {e.date_evenement.strftime('%d/%m/%Y')}" + (f" à {heure}" if heure else ""), actions,
                        le=e.date_evenement)
            elif e.date_evenement == aujourdhui:
                en_retard = e.heure and datetime.combine(aujourdhui, e.heure) < maintenant
                ajouter(f"agenda-{e.id}", "urgent" if en_retard else "attention", e.type_evenement,
                        f"{e.type_evenement}{' à ' + heure if heure else ' aujourd’hui'} : {e.titre}",
                        " — ".join(x for x in (e.lieu, e.telephone, e.notes) if x), actions, quand=heure or None,
                        le=e.date_evenement)
            else:
                ajouter(f"agenda-{e.id}", "info", e.type_evenement,
                        f"Demain{' à ' + heure if heure else ''} : {e.titre}", e.lieu or "", actions, le=e.date_evenement)
            # Rappels à l'écran : aujourd'hui et demain (un rendez-vous à 00 h 10 se rappelle la veille au soir)
            if e.heure and e.date_evenement >= aujourdhui:
                rappels.append({"id": e.id, "titre": e.titre, "type": e.type_evenement, "heure": heure,
                                "date": e.date_evenement.isoformat(), "rappel_minutes": e.rappel_minutes,
                                "lieu": e.lieu or "", "telephone": e.telephone or ""})

    # 2. Loyers : échéances proches, impayés, contrats à risque (Finances)
    if peut_acceder(role, "paiements"):
        contrats = contrats_du_perimetre(db, u)
        recalculer_tout(db, contrats)
        envois = derniers_envois(db, [c.id for c in contrats])
        for c in contrats:
            loge = f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}"
            r = resume_impayes(c, aujourdhui)
            if r:
                derniere = envois.get((c.id, "retard"))
                deja = derniere and datetime.strptime(derniere, "%d/%m/%Y").date() > aujourdhui - timedelta(days=7)
                niveau = "urgent" if r["a_risque"] else "attention"
                titre = (f"Contrat à risque : {c.locataire.nom_complet}" if r["a_risque"]
                         else f"Loyer impayé : {c.locataire.nom_complet}")
                actions = [{"libelle": "Encaisser", "type": "encaisser", "id": c.id}]
                if not deja:
                    actions.append({"libelle": "Alerte WhatsApp", "type": "wa_type", "message": "retard", "id": c.id})
                ajouter(f"impaye-{c.id}", niveau, "Impayé",
                        titre, f"{r['nb_mois']} mois — {f(r['montant'])} — {loge}"
                        + (f" — alerte envoyée le {derniere}" if deja else ""), actions, le=r["derniere_limite"])
                if r["a_risque"] and role == "Admin":
                    ajouter(f"risque-{c.id}", "urgent", "Décision",
                            f"Décider pour {c.locataire.nom_complet} (2 mois ou plus d'impayés)",
                            "La résiliation n'est jamais automatique : avis d'expulsion, échéancier ou résiliation.",
                            [{"libelle": "Voir Finances", "type": "ouvrir", "cible": "paiements"}], le=r["derniere_limite"])
                continue
            prochaine = prochaine_echeance(c, aujourdhui)
            if prochaine:
                mois, m, limite = prochaine
                jours = (limite - aujourdhui).days
                envoye = envois.get((c.id, "rappel"))
                if jours <= 3 and not envoye:
                    ajouter(f"rappel-{c.id}", "attention", "Échéance",
                            f"Rappel de loyer à envoyer : {c.locataire.nom_complet}",
                            f"{f(m)} à payer avant le {limite.strftime('%d/%m/%Y')} "
                            f"({'aujourd’hui' if jours == 0 else f'dans {jours} jour' + ('s' if jours > 1 else '')}) — {loge}",
                            [{"libelle": "Rappel WhatsApp", "type": "wa_type", "message": "rappel", "id": c.id},
                             {"libelle": "Encaisser", "type": "encaisser", "id": c.id}], le=limite)

    # 3. Contrats : fin de bail proche (renouvellement / avenant de prolongation)
    if peut_acceder(role, "contrats"):
        requete = db.query(Contrat).join(Logement).filter(
            Contrat.statut_contrat.in_(STATUTS_EN_COURS), Contrat.date_fin.isnot(None),
            Contrat.date_fin <= aujourdhui + timedelta(days=60))
        autorisees = cites_autorisees(u)
        if autorisees is not None:
            requete = requete.filter(Logement.cite_id.in_(autorisees))
        for c in requete:
            jours = (c.date_fin - aujourdhui).days
            ajouter(f"fin-{c.id}", "attention" if jours <= 30 else "info", "Contrat",
                    f"Fin de bail {'dépassée' if jours < 0 else f'dans {jours} jours'} : {c.locataire.nom_complet}",
                    f"Contrat N° {c.numero_contrat} — fin le {c.date_fin.strftime('%d/%m/%Y')}. "
                    "Proposer un renouvellement (avenant de prolongation) ou préparer la sortie.",
                    [{"libelle": "Faire un avenant", "type": "avenant", "id": c.id}], le=c.date_fin)

        # Départs annoncés (préavis) : préparer la sortie, puis l'Admin résilie
        requete = db.query(Contrat).join(Logement).filter(
            Contrat.statut_contrat.in_(STATUTS_EN_COURS), Contrat.date_depart.isnot(None),
            Contrat.date_depart <= aujourdhui + timedelta(days=30))
        if autorisees is not None:
            requete = requete.filter(Logement.cite_id.in_(autorisees))
        for c in requete:
            jours = (c.date_depart - aujourdhui).days
            quand = ("aujourd’hui" if jours == 0 else f"dans {jours} jour{'s' if jours > 1 else ''}" if jours > 0
                     else f"le {c.date_depart.strftime('%d/%m/%Y')}")
            if jours > 0:
                detail = (f"Contrat N° {c.numero_contrat} — départ le {c.date_depart.strftime('%d/%m/%Y')}. "
                          "Prévoir l'état des lieux de sortie et la restitution de la caution.")
            else:
                detail = (f"Contrat N° {c.numero_contrat}. À faire : état des lieux de sortie, restitution de la "
                          "caution, puis résiliation du contrat par l'Admin (le logement redevient libre).")
            ajouter(f"depart-{c.id}", "urgent" if jours <= 0 else "attention" if jours <= 7 else "info", "Départ",
                    f"Départ {'prévu ' if jours > 0 else ''}{quand} : {c.locataire.nom_complet}", detail,
                    [{"libelle": "État des lieux de sortie", "type": "edl", "contrat_id": c.id, "type_edl": "Sortie"},
                     {"libelle": "Voir les contrats", "type": "ouvrir", "cible": "contrats"}], le=c.date_depart)

    # 3 ter. Séjours en courte durée : arrivées et départs d'aujourd'hui et de demain, soldes à encaisser
    if peut_acceder(role, "sejours"):
        import sejours
        autorisees = cites_autorisees(u)
        requete = db.query(Reservation).join(Logement).filter(
            Reservation.statut.in_(sejours.ACTIFS),
            ((Reservation.statut == "Confirmée") & (Reservation.date_arrivee <= aujourdhui + timedelta(days=1)))
            | ((Reservation.statut == "Arrivé") & (Reservation.date_depart <= aujourdhui + timedelta(days=1))))
        if autorisees is not None:
            requete = requete.filter(Logement.cite_id.in_(autorisees))
        for r in requete:
            loge = f"Logement {r.logement.numero_logement}, {r.logement.cite.nom}"
            reste = r.montant_total - sejours.verse(r)
            detail = f"N° {r.numero} — {loge}" + (f" — reste à payer {f(reste)}" if reste > 0 else " — séjour réglé")
            if r.statut == "Confirmée":
                quand = ("en retard depuis le " + r.date_arrivee.strftime("%d/%m/%Y") if r.date_arrivee < aujourdhui
                         else "aujourd’hui" if r.date_arrivee == aujourdhui else "demain")
                ajouter(f"sejour-arrivee-{r.id}", "attention" if r.date_arrivee <= aujourdhui else "info", "Séjour",
                        f"Arrivée {quand} : {r.client_nom}", detail,
                        [{"libelle": "Voir les séjours", "type": "ouvrir", "cible": "sejours"}], le=r.date_arrivee)
            else:
                quand = "aujourd’hui" if r.date_depart == aujourdhui else (
                    "demain" if r.date_depart > aujourdhui else "dépassé (" + r.date_depart.strftime("%d/%m/%Y") + ")")
                ajouter(f"sejour-depart-{r.id}", "urgent" if r.date_depart < aujourdhui or reste > 0 else "attention",
                        "Séjour", f"Départ {quand} : {r.client_nom}", detail,
                        [{"libelle": "Voir les séjours", "type": "ouvrir", "cible": "sejours"}], le=r.date_depart)

    # 3 bis. Début de mois : relevés du mois écoulé à envoyer aux propriétaires (Admin, Caisse)
    if peut_acceder(role, "rapports") and voit_finances(u) and aujourdhui.day <= 7:
        mois_dernier = (aujourdhui.replace(day=1) - timedelta(days=1))
        ajouter(f"releves-{mois_dernier.strftime('%Y-%m')}", "info", "Propriétaires",
                f"Envoyer aux propriétaires leur relevé de {MOIS[mois_dernier.month - 1]} {mois_dernier.year}",
                "Rapports → Rapport détaillé : bouton WhatsApp à côté de chaque propriétaire (PDF joint).",
                [{"libelle": "Ouvrir les relevés", "type": "releves"}])

    # 4. États des lieux à faire / à signer
    if peut_acceder(role, "etats_des_lieux"):
        from etats_des_lieux import liste as liste_edl
        donnees = liste_edl(u, db)
        for a in donnees["a_faire"][:15]:
            ajouter(f"edl-{a['contrat_id']}-{a['type_edl']}", "attention" if a["type_edl"] == "Sortie" else "info",
                    "État des lieux", f"État des lieux d'{'entrée' if a['type_edl'] == 'Entrée' else 'sortie'} à faire : "
                                      f"{a['locataire']}", f"{a['logement']} — {a['raison']}",
                    [{"libelle": "Commencer", "type": "edl", "contrat_id": a["contrat_id"], "type_edl": a["type_edl"]}])
        for e in donnees["etats"]:
            if e["statut"] == "Brouillon":
                ajouter(f"edl-brouillon-{e['id']}", "attention", "État des lieux",
                        f"État des lieux à faire signer : {e['locataire']}", f"N° {e['numero']} — {e['logement']}",
                        [{"libelle": "Ouvrir", "type": "edl_ouvrir", "id": e["id"]}])
            elif not e["envoye_le"]:
                ajouter(f"edl-envoi-{e['id']}", "info", "Courrier",
                        f"Envoyer la copie signée de l'état des lieux à {e['locataire']}", f"N° {e['numero']}",
                        [{"libelle": "Envoyer", "type": "edl_ouvrir", "id": e["id"]}])

    # 5. Courriers préparés mais jamais envoyés
    if peut_acceder(role, "courriers"):
        requete = db.query(Courrier).join(Contrat).join(Logement).filter(
            Courrier.cree_le >= datetime.now() - timedelta(days=60))
        autorisees = cites_autorisees(u)
        if autorisees is not None:
            requete = requete.filter(Logement.cite_id.in_(autorisees))
        for k in requete:
            if not k.envois:
                ajouter(f"courrier-{k.id}", "attention", "Courrier",
                        f"Courrier à envoyer : {k.type_courrier.lower()} pour {k.contrat.locataire.nom_complet}",
                        f"N° {k.numero}", [{"libelle": "Envoyer", "type": "courrier", "id": k.id}],
                        le=k.cree_le.date() if k.cree_le else None)

    # 6. Nouveaux clients à rappeler + logements qui correspondent à leur demande
    if peut_acceder(role, "prospects"):
        prospects = db.query(Prospect).filter(Prospect.statut.notin_(("Converti", "Perdu"))).all()
        for p in prospects:
            correspondances = logements_correspondants(db, u, p, limite=3)
            a_rappeler = p.prochaine_action and p.prochaine_action <= aujourdhui
            if not (a_rappeler or correspondances):
                continue
            detail = []
            if p.type_logement or p.budget_max:
                detail.append(f"cherche {p.type_logement or 'un logement'}"
                              + (f", budget {f(p.budget_max)}" if p.budget_max else "")
                              + (f", à {p.quartier}" if p.quartier else ""))
            if correspondances:
                detail.append("Disponible : " + " ; ".join(f"{c['logement']} ({f(c['loyer'])})" for c in correspondances))
            texte_wa = (f"Bonjour {p.nom_complet}, ici {recus.ENTETE['nom']}. Suite à votre demande, nous avons un logement "
                        f"disponible qui pourrait vous intéresser : {correspondances[0]['logement']}, "
                        f"loyer {f(correspondances[0]['loyer'])}. Quand pouvez-vous passer pour une visite ?"
                        ) if correspondances else f"Bonjour {p.nom_complet}, ici {recus.ENTETE['nom']}. Nous revenons vers vous au sujet de votre recherche."
            actions = [{"libelle": "Fiche client", "type": "prospect", "id": p.id}]
            if p.telephone:
                actions.insert(0, {"libelle": "WhatsApp", "type": "whatsapp", "telephone": p.telephone, "texte": texte_wa})
            niveau = "attention" if (a_rappeler and p.prochaine_action < aujourdhui) or correspondances else "info"
            titre = (f"Logement disponible pour {p.nom_complet}" if correspondances and not a_rappeler
                     else f"Rappeler le client {p.nom_complet}")
            ajouter(f"prospect-{p.id}", niveau, "Client", titre, " — ".join(detail) or (p.details or ""), actions,
                    le=p.prochaine_action if a_rappeler else None)

    # 7. Problèmes signalés sur les biens
    if peut_acceder(role, "biens"):
        requete = db.query(Signalement).options(selectinload(Signalement.cite), selectinload(Signalement.logement)) \
            .filter(Signalement.statut != "Résolu")
        autorisees = cites_autorisees(u)
        if autorisees is not None:
            requete = requete.filter(Signalement.cite_id.in_(autorisees))
        for s in requete:
            age = (aujourdhui - s.cree_le.date()).days if s.cree_le else 0
            if s.urgence == "Urgente" or age >= 7:
                ou = s.cite.nom + (f", logement {s.logement.numero_logement}" if s.logement else "")
                ajouter(f"probleme-{s.id}", "urgent" if s.urgence == "Urgente" else "attention", "Problème",
                        f"{s.categorie} — {ou}", f"Signalé il y a {age} jour{'s' if age > 1 else ''} : {s.description[:120]}",
                        [{"libelle": "Voir", "type": "ouvrir", "cible": "biens"}], le=s.cree_le.date() if s.cree_le else None)

    # 8. Administration (Admin)
    if role == "Admin":
        demandes: dict[str, list] = {}  # une tâche par identifiant, même si la personne a cliqué plusieurs fois
        for d in db.query(DemandeReinitialisation).filter_by(traitee=False).order_by(DemandeReinitialisation.cree_le):
            demandes.setdefault(d.identifiant, []).append(d)
        for ident, liste_d in demandes.items():
            d = liste_d[-1]
            ajouter(f"mdp-{d.id}", "urgent", "Compte", f"Mot de passe oublié : « {ident} »",
                    ("Demandé le " + d.cree_le.strftime("%d/%m/%Y à %H:%M") + ". " if d.cree_le else "")
                    + "Donnez-lui un nouveau mot de passe dans Utilisateurs.",
                    [{"libelle": "Ouvrir Utilisateurs", "type": "utilisateurs"}], le=d.cree_le.date() if d.cree_le else None)
        from sqlalchemy import text
        refus = db.execute(text("SELECT apres->>'identifiant' AS ident, COUNT(*) AS nb FROM journal "
                                "WHERE operation = 'ECHEC' AND quand > :depuis GROUP BY 1 ORDER BY 2 DESC"),
                           {"depuis": maintenant - timedelta(hours=24)}).all()
        total = sum(r.nb for r in refus)
        if total >= 10:
            # quelqu'un essaie peut-être de deviner un mot de passe
            ajouter("connexions-refusees", "attention", "Sécurité", f"{total} connexions refusées en 24 heures",
                    "Comptes visés : " + ", ".join(f"« {r.ident or '?'} » ({r.nb})" for r in refus[:4])
                    + ". Si ce n'est pas un employé qui a oublié son mot de passe, regardez le journal "
                    "(adresse de l'appareil) ; Gérimo fait déjà attendre de plus en plus longtemps après chaque erreur.",
                    [{"libelle": "Voir le journal", "type": "journal"}])
        sans_commission = [c.nom for c in db.query(Cite).options(selectinload(Cite.mandats)) if c.mandat_actuel is None]
        if sans_commission:
            ajouter("commission", "attention", "Paramétrage", "Commission de gestion à renseigner",
                    "Biens : " + ", ".join(sans_commission[:5]) + " — sans elle, aucun encaissement n'est possible.",
                    [{"libelle": "Voir les biens", "type": "ouvrir", "cible": "biens"}])
        derniere = sauvegarde.derniere_sauvegarde()
        echec = sauvegarde.dernier_echec()
        if echec:
            ajouter("sauvegarde-echec", "urgent", "Sécurité", "La sauvegarde automatique a échoué",
                    f"Le {echec['quand'].strftime('%d/%m/%Y à %H:%M')} : {echec['message']} "
                    "Essayez « Sauvegarder » ; si l'erreur revient, faites vérifier le PC serveur.",
                    [{"libelle": "Sauvegarder", "type": "sauvegarde"}])
        elif derniere is None or derniere < datetime.now() - timedelta(hours=26):
            # la sauvegarde est quotidienne : au-delà d'un jour (plus une marge), quelque chose ne va pas
            ajouter("sauvegarde", "urgent" if derniere and derniere < datetime.now() - timedelta(days=3) else "attention",
                    "Sécurité",
                    "Faire une sauvegarde" + (" (aucune encore)" if derniere is None
                                              else f" (dernière le {derniere.strftime('%d/%m/%Y à %H:%M')})"),
                    "Gérimo sauvegarde tout seul chaque jour : s'il ne l'a pas fait depuis plus d'un jour, le PC "
                    "serveur était peut-être éteint. Sauvegardez maintenant.",
                    [{"libelle": "Sauvegarder", "type": "sauvegarde"}])
        import licence
        lic = licence.etat(db)
        restants = lic["jours_restants"]
        merci = licence.renouvellement_recent(db)
        if merci and lic["statut"] == "active":
            ajouter("licence-merci", "info", "Licence", "Paiement reçu, merci !",
                    f"Votre abonnement Gérimo Pro est prolongé jusqu'au {merci['fin']}.",
                    [{"libelle": "Voir la licence", "type": "a_propos"}])
        if lic["controle"] and lic["statut"] in ("retard", "reduite"):
            # abonnement impayé : rappel à partir du 05, fonctions réduites après le 15 (licence.py)
            if lic["statut"] == "reduite" or lic["jours_retard"] >= licence.JOURS_AVANT_RAPPEL:
                ajouter("licence", "urgent" if lic["statut"] == "reduite" else "attention", "Licence",
                        "Abonnement impayé : fonctions réduites" if lic["statut"] == "reduite"
                        else "Abonnement Gérimo à régler",
                        lic["message"] + " Contact de l'éditeur : 07 49 62 25 66.",
                        [{"libelle": "Voir la licence", "type": "a_propos"}])
        # licence en cours : prévenir 7 jours avant sa fin seulement (un abonnement mensuel serait sinon toujours signalé)
        elif lic["controle"] and (lic["statut"] != "active" or (restants is not None and restants <= 7)):
            niveau = ("info" if lic["statut"] == "active"
                      else "urgent" if lic["statut"] == "lecture_seule" or (restants or 0) <= 7
                      else "attention" if lic["statut"] != "essai" or restants <= 15 else "info")
            ajouter("licence", niveau, "Licence",
                    "Gérimo en lecture seule" if lic["statut"] == "lecture_seule"
                    else f"Licence : {restants} jour{'s' if restants > 1 else ''} restant{'s' if restants > 1 else ''}",
                    lic["message"] + f" Code de ce PC : {lic['code_pc']} (Paramètres → À propos → Licence).",
                    [{"libelle": "Voir la licence", "type": "a_propos"}])
        import coffre
        if coffre.disponible() and not coffre.code_note():
            ajouter("code-secours", "attention", "Sécurité", "Noter le code de secours des sauvegardes",
                    "Les sauvegardes sont chiffrées. Si ce PC est remplacé, il faudra ce code pour les relire : "
                    "affichez-le, recopiez-le sur papier et rangez-le hors du bureau.",
                    [{"libelle": "Voir le code", "type": "sauvegardes"}])
        illisibles = parametres.secrets_illisibles(db)
        if illisibles:
            noms = {"smtp_mot_de_passe": "mot de passe des e-mails", "ia_cle_api": "clé de l'IA",
                    "maj_jeton": "jeton des mises à jour"}
            ajouter("secrets-illisibles", "attention", "Paramétrage", "Ressaisir des réglages secrets",
                    "Illisibles sur ce PC (enregistrés avec la clé d'un autre PC) : "
                    + ", ".join(noms.get(c, c) for c in illisibles) + ". Saisissez-les de nouveau dans Paramètres.",
                    [{"libelle": "Voir les réglages", "type": "reglages"}])
        choisi = sauvegarde.dossier_externe_choisi()
        copie = sauvegarde.derniere_copie_externe() if choisi else None
        if not choisi:
            ajouter("sauvegarde-cle", "attention", "Sécurité", "Choisir une clé USB pour les sauvegardes",
                    "Les sauvegardes restent sur le PC serveur : en cas de panne ou de vol, tout serait perdu. "
                    "Branchez une clé USB ou un disque externe et indiquez-le dans Paramètres → Sauvegardes.",
                    [{"libelle": "Choisir la clé", "type": "sauvegardes"}])
        elif copie is None or copie < datetime.now() - timedelta(days=2):
            ajouter("sauvegarde-cle", "attention", "Sécurité", "Brancher la clé USB de sauvegarde",
                    ("Dernière copie hors du PC le " + copie.strftime("%d/%m/%Y") + ". " if copie else "Aucune copie encore. ")
                    + "Branchez la clé sur le PC serveur : la copie se fait toute seule dans l'heure.",
                    [{"libelle": "Voir les sauvegardes", "type": "sauvegardes"}])
        import secours
        if secours.jumelage(db) and secours.en_retard():
            depuis = secours.copies_emportees().get("quand")
            ajouter("secours-retard", "attention", "Sécurité", "Le PC de secours ne reçoit plus les sauvegardes",
                    (f"Dernière copie emportée le {datetime.fromisoformat(depuis).strftime('%d/%m/%Y à %H:%M')}. "
                     if depuis else "Aucune copie emportée pour l'instant. ")
                    + "Vérifiez que le PC de secours est allumé, branché au réseau, et que Gérimo y tourne.",
                    [{"libelle": "Voir les sauvegardes", "type": "sauvegardes"}])
        import pare_feu
        publics = pare_feu.reseaux_publics()
        if publics:
            ajouter("reseau-public", "info", "Sécurité", "Réseau du PC serveur classé « Public »",
                    f"Windows classe « {publics[0]} » en réseau public. Si c'est le réseau du bureau, passez-le en "
                    "« Privé » sur le PC serveur (Paramètres Windows → Réseau et Internet → Wi-Fi ou Ethernet → "
                    "Type de profil réseau : Privé). Gérimo n'accepte de toute façon que les appareils du réseau local.")
        if certificats.disponible() and parametres.lire(db, "https_obligatoire") != "oui":
            ajouter("https", "info", "Sécurité", "Passer tous les appareils en connexion sécurisée",
                    "Quand chaque PC et téléphone ouvre Gérimo en https://, rendez la connexion sécurisée obligatoire "
                    "(Paramètres → Réglages) : plus rien ne circulera en clair sur le réseau.",
                    [{"libelle": "Voir les réglages", "type": "reglages"}])
    if peut_acceder(role, "reseaux_sociaux"):
        requete = db.query(Logement).join(Cite).filter(Logement.statut_logement == "Libre")
        autorisees = cites_autorisees(u)
        if autorisees is not None:
            requete = requete.filter(Logement.cite_id.in_(autorisees))
        libres = requete.count()
        if libres:
            ajouter("annonces", "info", "Annonce", f"{libres} logement{'s' if libres > 1 else ''} libre"
                    f"{'s' if libres > 1 else ''} : publier une annonce",
                    (f"Une annonce sur le groupe Facebook « {groupe} » trouve souvent preneur en quelques jours."
                     if (groupe := parametres.lire(db, "facebook_groupe_nom")) else
                     "Une annonce sur Facebook ou WhatsApp trouve souvent preneur en quelques jours."),
                    [{"libelle": "Publier", "type": "ouvrir", "cible": "reseaux_sociaux"}])

    liste.sort(key=lambda t: (ORDRE_NIVEAU[t["niveau"]], t["quand"] or "99:99"))
    return liste, rappels


def resume_vocal(u: Utilisateur, liste: list[dict]) -> str:
    """Petit texte naturel, lu à voix haute à l'ouverture."""
    maintenant = datetime.now()
    salut = "Bonjour" if maintenant.hour < 18 else "Bonsoir"
    if not liste:
        return f"{salut} {prenom(u)}. Tout est à jour, rien d'urgent aujourd'hui. Bonne journée !"
    compte = {}
    for t in liste:
        compte[t["categorie"]] = compte.get(t["categorie"], 0) + 1
    morceaux = []
    rdv = sum(compte.get(k, 0) for k in ("Rendez-vous", "Visite", "Appel", "Tâche", "Relance", "Courrier"))
    noms = {"Impayé": ("loyer impayé", "loyers impayés"), "Échéance": ("rappel de loyer à envoyer", "rappels de loyer à envoyer"),
            "Client": ("client à recontacter", "clients à recontacter"), "Problème": ("problème à traiter", "problèmes à traiter"),
            "État des lieux": ("état des lieux en attente", "états des lieux en attente"),
            "Contrat": ("fin de bail à préparer", "fins de bail à préparer")}
    if rdv:
        morceaux.append(f"{rdv} {'rendez-vous, appel ou tâche' if rdv == 1 else 'rendez-vous, appels ou tâches'} à l'agenda")
    for cle, (un, plusieurs) in noms.items():
        if compte.get(cle):
            morceaux.append(f"{compte[cle]} {un if compte[cle] == 1 else plusieurs}")
    if not morceaux:
        morceaux.append(f"{len(liste)} {'point' if len(liste) == 1 else 'points'} à voir")
    urgents = [t for t in liste if t["niveau"] == "urgent"]
    texte = f"{salut} {prenom(u)}. Aujourd'hui : " + ", ".join(morceaux[:5]) + "."
    if urgents:
        texte += f" Le plus urgent : {urgents[0]['titre']}."
    return texte


@router.get("/assistant")
def assistant(u: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    liste, rappels = taches(db, u)
    try:
        defilement_max = max(1, int(parametres.lire(db, "defilement_max") or 15))
    except ValueError:
        defilement_max = 15
    return {"taches": liste, "rappels": rappels, "resume": resume_vocal(u, liste), "prenom": prenom(u),
            "defilement_max": defilement_max,
            "date": jour_fr(date.today()).capitalize() + f" {date.today().year}"}


# ---------- Comprendre une phrase ----------

def _norm(texte: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", texte) if unicodedata.category(c) != "Mn").lower()


def lire_date(texte: str, aujourdhui: date) -> tuple[date | None, str]:
    """Trouve une date dans la phrase ; renvoie (date, phrase sans la date)."""
    t = _norm(texte)
    regles = [
        (r"\bapres[- ]demain\b", lambda m: aujourdhui + timedelta(days=2)),
        (r"\bdemain\b", lambda m: aujourdhui + timedelta(days=1)),
        (r"\baujourd'?hui\b|\bce (?:matin|soir|midi|jour)\b|\bcet apres-midi\b", lambda m: aujourdhui),
        (r"\bdans (\d+) jours?\b", lambda m: aujourdhui + timedelta(days=int(m.group(1)))),
        (r"\bdans (\d+) semaines?\b", lambda m: aujourdhui + timedelta(weeks=int(m.group(1)))),
        (r"\bla semaine prochaine\b", lambda m: aujourdhui + timedelta(days=7 - aujourdhui.weekday())),
        (r"\b(\d{1,2})[/.-](\d{1,2})(?:[/.-](\d{2,4}))?\b", lambda m: _date_chiffres(m, aujourdhui)),
        (r"\b(?:le )?(\d{1,2}|1er) (" + "|".join(_norm(x) for x in MOIS) + r")(?: (\d{4}))?\b",
         lambda m: _date_mois(m, aujourdhui)),
        (r"\b(?:ce |le |)(" + "|".join(JOURS) + r")(?: prochain)?\b", lambda m: _prochain_jour(m.group(1), aujourdhui)),
    ]
    for motif, calcul in regles:
        m = re.search(motif, t)
        if m:
            try:
                d = calcul(m)
            except ValueError:
                continue
            if d:
                return d, (texte[:m.start()] + texte[m.end():]).strip()
    return None, texte


def _date_chiffres(m, aujourdhui: date) -> date:
    jour, mois = int(m.group(1)), int(m.group(2))
    annee = int(m.group(3)) if m.group(3) else aujourdhui.year
    if annee < 100:
        annee += 2000
    d = date(annee, mois, jour)
    return d.replace(year=d.year + 1) if not m.group(3) and d < aujourdhui else d


def _date_mois(m, aujourdhui: date) -> date:
    jour = 1 if m.group(1) == "1er" else int(m.group(1))
    mois = [_norm(x) for x in MOIS].index(m.group(2)) + 1
    d = date(int(m.group(3)) if m.group(3) else aujourdhui.year, mois, jour)
    return d.replace(year=d.year + 1) if not m.group(3) and d < aujourdhui else d


def _prochain_jour(nom: str, aujourdhui: date) -> date:
    ecart = (JOURS.index(nom) - aujourdhui.weekday()) % 7
    return aujourdhui + timedelta(days=ecart or 7)


def lire_heure(texte: str) -> tuple[time | None, str]:
    t = _norm(texte)
    m = re.search(r"\b(?:a |vers |pour )?(\d{1,2})\s*(?:h|heures?|:)\s*(\d{2})?\b", t)
    if m and int(m.group(1)) < 24 and int(m.group(2) or 0) < 60:
        return time(int(m.group(1)), int(m.group(2) or 0)), (texte[:m.start()] + texte[m.end():]).strip()
    for mot, h in (("ce matin", 9), ("midi", 12), ("cet apres-midi", 15), ("ce soir", 18)):
        if mot in t:
            return time(h, 0), texte
    return None, texte


TELEPHONE = re.compile(r"(?:\+?225[\s.]?)?\b0\d(?:[\s.-]?\d{2}){4}\b")


def lire_prospect(texte: str) -> dict:
    """« Nouveau client Kouamé Ange 07 07 07 07 07 cherche un 2 pièces à Agnikro budget 60 000 »."""
    t = _norm(texte)
    resultat = {"besoin": "Location"}
    tel = TELEPHONE.search(texte)
    if tel:
        resultat["telephone"] = re.sub(r"\s+", " ", tel.group(0)).strip()
    if "achet" in t or "acqu" in t:
        resultat["besoin"] = "Achat"
    elif "vend" in t:
        resultat["besoin"] = "Vente"
    elif "confier" in t or "gestion" in t or "gerer" in t:
        resultat["besoin"] = "Confier un bien en gestion"
    m = re.search(r"\b([2-8]) ?(?:pieces?|p)\b", t)
    if m:
        resultat["type_logement"] = f"{m.group(1)} pièces"
    elif "studio" in t:
        resultat["type_logement"] = "Studio"
    elif "magasin" in t or "boutique" in t:
        resultat["type_logement"] = "Magasin"
    elif "villa" in t:
        resultat["type_logement"] = "Villa de plus de 8 pièces"
    m = re.search(r"(?:budget|maximum|max|jusqu'?a|moins de)\D{0,12}(\d[\d .]*\d|\d)(?:\s*(?:f|fcfa|francs))?", t)
    if m:
        valeur = int(re.sub(r"\D", "", m.group(1)))
        if "mille" in t[m.end():m.end() + 7] or valeur < 1000:
            valeur *= 1000
        resultat["budget_max"] = valeur
    m = re.search(r"\b(?:a|au quartier|quartier|vers|cote de|cote)\s+([a-zà-ÿ][\w\- ]{2,40}?)(?=,|\.|\bbudget\b|\bmax|\bpour\b|\bavec\b|$)", t)
    if m:
        debut = m.start(1)
        quartier = texte[debut:debut + len(m.group(1))].strip(" ,.")
        if not re.match(r"^\d", quartier):
            resultat["quartier"] = quartier[:1].upper() + quartier[1:]
    # Nom : après « client / cliente / demande de / prospect », avant le téléphone ou « cherche »
    m = re.search(r"(?:client(?:e)?|prospect|demande(?: de)?|monsieur|madame|m\.|mme)\s*:?\s+(.+?)"
                  r"(?=\s*(?:\+?225|0\d[\s.]?\d|,|\bcherche|\bveut|\bsouhaite|\bbesoin|\bpour\b|$))", texte, re.I)
    if m:
        nom = re.sub(r"[^A-Za-zÀ-ÖØ-öø-ÿ' \-.]", "", m.group(1)).strip(" .-")
        nom = re.sub(r"(?i)^(?:m\.|mme|mlle|monsieur|madame|mademoiselle)\s+", "", nom)  # civilité retirée
        if nom and _norm(nom) not in ("de", "du", "un", "une"):
            resultat["nom_complet"] = nom.title() if nom.isupper() or nom.islower() else nom
    return resultat


class Commande(BaseModel):
    texte: str = Field(min_length=1, max_length=500)


# « Gérimo » et « Gerimo » sont le même nom ; la dictée peut aussi écrire « Jérimo », « Gérémo »…
APPEL_GERIMO = re.compile(r"^\s*(?:(?:ok|oh|eh|hey|bonjour|bonsoir|salut|dis)\s+)?[gj][eé]r[iéeè]m(?:o|ot|au|eau)\b[\s,:;!.?-]*",
                          re.IGNORECASE)


def interpreter(db: SessionDB, u: Utilisateur, texte: str) -> dict:
    """Comprend la phrase et agit. Renvoie {reponse, actions, cree}.
    Ordre : vraies données (programme du jour, impayés, logements libres), puis le lexique (lexique.py), puis les
    actions (rappel, rendez-vous, client) ; sinon la question est gardée pour que l'Admin y réponde.
    Une demande d'explication (« Comment… ? », « Pourquoi… ? ») ne crée jamais de rendez-vous ni de client."""
    import lexique
    texte = lexique.corriger_dictee(db, texte)
    texte = APPEL_GERIMO.sub("", texte) or texte
    t = lexique.simplifier(texte)
    aujourdhui = date.today()
    explication = lexique.demande_explication(texte)

    # « Appelle-moi Monsieur BESSOU » : chacun choisit comment Gérimo l'appelle
    m = APPELLATION.match(texte)
    if m and not any(c in m.group(1) for c in "<>`{}[]"):
        u.appellation = m.group(1).strip().strip("«»\"' ")
        db.commit()
        return {"reponse": f"Entendu, je vous appellerai désormais {u.appellation}.", "actions": []}

    # Résumé / programme du jour
    if not explication and re.search(r"\b(resume|programme|planning|aujourd ?hui|a faire|quoi de neuf|bonjour|bonsoir|"
                                     r"salut|coucou|hello|briefing)\b", t) \
            and not re.search(r"\b(rappel|rendez|appeler|client|visite)\b", t):
        liste, _ = taches(db, u)
        lignes = [f"• {x['titre']}" for x in liste[:8]]
        return {"reponse": resume_vocal(u, liste) + ("\n\n" + "\n".join(lignes) if lignes else ""), "actions": []}

    if not explication and re.search(r"\bimpaye", t) and peut_acceder(u.role.value, "paiements"):
        liste, _ = taches(db, u)
        imp = [x for x in liste if x["categorie"] == "Impayé"]
        if not imp:
            return {"reponse": "Aucun impayé : tous les loyers échus sont réglés. 👍", "actions": []}
        return {"reponse": f"{len(imp)} contrat{'s' if len(imp) > 1 else ''} en retard :\n"
                           + "\n".join(f"• {x['titre'][x['titre'].find(':') + 2:]} — {x['detail']}" for x in imp[:10]),
                "actions": [{"libelle": "Ouvrir Finances", "type": "ouvrir", "cible": "paiements"}]}

    if not explication and re.search(r"\b(logements? libres?|disponibles?)\b", t) and peut_acceder(u.role.value, "biens"):
        requete = db.query(Logement).join(Cite).filter(Logement.statut_logement == "Libre")
        autorisees = cites_autorisees(u)
        if autorisees is not None:
            requete = requete.filter(Logement.cite_id.in_(autorisees))
        libres = requete.order_by(Logement.loyer).all()
        if not libres:
            return {"reponse": "Aucun logement libre en ce moment.", "actions": []}
        return {"reponse": f"{len(libres)} logement{'s' if len(libres) > 1 else ''} libre{'s' if len(libres) > 1 else ''} :\n"
                           + "\n".join(f"• {l.numero_logement} — {l.type_logement} — {l.cite.nom} — {f(l.loyer)}"
                                       for l in libres[:12]),
                "actions": [{"libelle": "Publier une annonce", "type": "ouvrir", "cible": "reseaux_sociaux"}]}

    # Lexique : questions sur le logiciel, conversation courante, réponses apprises (sûr de lui)
    connue = lexique.repondre(db, u, texte)
    if connue and (lexique.est_question(texte) or len(t.split()) <= 6):
        return connue
    if explication:  # une explication est demandée : jamais d'action à partir de cette phrase
        return lexique.repondre(db, u, texte, lexique.SEUIL_FAIBLE) or _non_compris(db, u, texte)

    # Nouveau client
    if re.search(r"\b(nouveau client|nouvelle cliente|nouvelle demande|prospect|client (?:qui )?cherche|"
                 r"cherche (?:un|une) (?:logement|maison|studio|magasin|\d))", t):
        if not peut_acceder(u.role.value, "prospects"):
            return {"reponse": "Votre profil ne gère pas les demandes de clients.", "actions": []}
        infos = lire_prospect(texte)
        if not infos.get("nom_complet"):
            return {"reponse": "Je n'ai pas compris le nom du client. Exemple :\n« Nouveau client Kouamé Ange "
                               "07 07 07 07 07 cherche un 2 pièces à Agnikro, budget 60 000 »",
                    "actions": [{"libelle": "Remplir la fiche", "type": "prospect_nouveau", "infos": infos}]}
        from agenda import ProspectIn, creer_prospect
        try:
            fiche = creer_prospect(ProspectIn(**infos, source="Passage au bureau",
                                              details=f"Demande dictée : « {texte.strip()} »"), u, db)
        except Exception:
            return {"reponse": "Certaines informations ne sont pas valables : vérifiez la fiche.",
                    "actions": [{"libelle": "Remplir la fiche", "type": "prospect_nouveau", "infos": infos}]}
        recap = [f"Demande enregistrée pour {fiche['nom_complet']}"]
        if fiche["telephone"]:
            recap.append(f"Tél. {fiche['telephone']}")
        if fiche["type_logement"]:
            recap.append(f"Cherche : {fiche['type_logement']}")
        if fiche["quartier"]:
            recap.append(f"Quartier : {fiche['quartier']}")
        if fiche["budget_max"]:
            recap.append(f"Budget : {f(fiche['budget_max'])}")
        recap.append("Je vous rappellerai de le recontacter demain.")
        if fiche["correspondances"]:
            recap.append("Logements libres qui correspondent :\n" + "\n".join(
                f"• {c['logement']} — {f(c['loyer'])}" for c in fiche["correspondances"]))
        return {"reponse": "\n".join(recap), "cree": {"prospect_id": fiche["id"]},
                "actions": [{"libelle": "Voir la fiche", "type": "prospect", "id": fiche["id"]}]}

    # Rappel / rendez-vous / appel / visite / courrier / tâche
    if re.search(r"\b(rappelle|rappel|note|noter|rdv|rendez|appeler|appelle|visite|courrier|envoyer|tache|penser)\b", t):
        if not peut_acceder(u.role.value, "agenda"):
            return {"reponse": "Votre profil n'a pas d'agenda.", "actions": []}
        jour, reste = lire_date(texte, aujourdhui)
        heure, reste = lire_heure(reste)
        type_evt = ("Appel" if re.search(r"\b(appel|appeler|telephoner)", t) else
                    "Visite" if "visite" in t else
                    "Rendez-vous" if re.search(r"\b(rdv|rendez)", t) else
                    "Courrier" if re.search(r"\b(courrier|lettre|envoyer)", t) else
                    "Relance" if "relanc" in t else "Tâche")
        titre = re.sub(r"(?i)^\s*(?:rappelle[- ]moi|rappel|note|noter|penser a|pense a|il faut)\s*(?:de |d'|d’|:)?\s*", "", reste)
        titre = re.sub(r"\s{2,}", " ", titre).strip(" ,.;:") or texte.strip()
        titre = titre[:1].upper() + titre[1:]
        tel = TELEPHONE.search(texte)
        evt = Evenement(titre=titre[:200], type_evenement=type_evt, date_evenement=jour or aujourdhui, heure=heure,
                        telephone=re.sub(r"\s+", " ", tel.group(0)) if tel else None, rappel_minutes=15 if heure else 0,
                        utilisateur_id=u.id, cree_par=u.id)
        db.add(evt)
        db.commit()
        quand = ("aujourd'hui" if evt.date_evenement == aujourdhui else
                 "demain" if evt.date_evenement == aujourdhui + timedelta(days=1) else jour_fr(evt.date_evenement))
        return {"reponse": f"C'est noté ✅ {type_evt} « {evt.titre} » — {quand}"
                           + (f" à {heure.strftime('%H:%M')}. Je vous préviendrai "
                              + ("30 puis 15 minutes avant." if type_evt in ("Rendez-vous", "Appel", "Visite")
                                 else "15 minutes avant.") if heure
                              else ". Je vous le rappellerai dans la liste du jour."),
                "cree": {"evenement_id": evt.id}, "actions": []}

    return lexique.repondre(db, u, texte, lexique.SEUIL_FAIBLE) or _non_compris(db, u, texte)


def _non_compris(db: SessionDB, u: Utilisateur, texte: str) -> dict:
    """Gérimo ne devine pas : il le dit, propose des exemples, et garde la question pour l'Admin."""
    import lexique
    lexique.noter_question(db, u, texte)
    return {"reponse": "Je n'ai pas encore la réponse à cette question, et je préfère ne pas deviner. Je l'ai notée "
                       "pour que l'Admin me l'apprenne.\n\n"
                       "Je peux déjà vous aider à :\n"
                       "• noter un rappel : « Rappelle-moi d'appeler M. Koffi demain à 10h »\n"
                       "• noter un rendez-vous : « Rendez-vous avec Mme Aya vendredi à 15h au bureau »\n"
                       "• enregistrer un nouveau client : « Nouveau client Kouamé Ange 07 07 07 07 07 cherche un "
                       "2 pièces à Agnikro, budget 60 000 »\n"
                       "• vous dire : « Qu'est-ce que j'ai aujourd'hui ? », « Impayés », « Logements libres »",
            "actions": []}


@router.post("/assistant/commande")
def commande(d: Commande, u: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    return interpreter(db, u, d.texte)
