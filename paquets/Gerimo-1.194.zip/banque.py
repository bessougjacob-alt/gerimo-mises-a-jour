"""Coordonnées bancaires de la zone UEMOA (RIB en 4 parties, IBAN, BIC) : nettoyage et contrôle.

Utilisé pour le RIB de l'entreprise (Paramètres) et pour le carnet de RIB des bénéficiaires.
"""
import re

from fastapi import HTTPException

# Chaque partie du RIB : format attendu et message en cas d'erreur
FORMATS_RIB = {
    "code": (r"[A-Z0-9]{5}", "Code banque : 5 caractères (ex : CI008)."),
    "guichet": (r"[0-9]{5}", "Code guichet : 5 chiffres (ex : 01001)."),
    "compte": (r"[0-9]{12}", "Numéro de compte : 12 chiffres."),
    "cle": (r"[0-9]{2}", "Clé RIB : 2 chiffres."),
}


def iban_valide(iban: str) -> bool:
    """Contrôle international de l'IBAN (norme ISO 13616 : reste de la division par 97 égal à 1)."""
    if not re.fullmatch(r"[A-Z]{2}[0-9]{2}[A-Z0-9]{10,30}", iban):
        return False
    chiffres = "".join(str(int(c, 36)) for c in iban[4:] + iban[:4])
    return int(chiffres) % 97 == 1


def compact(valeur: str | None) -> str:
    return re.sub(r"[\s.\-]", "", valeur or "").upper()


def verifier(code: str = "", guichet: str = "", compte: str = "", cle: str = "", iban: str = "",
             bic: str = "") -> dict[str, str]:
    """Nettoie (majuscules, sans espaces) et vérifie ; HTTPException 400 avec un message clair si incohérent."""
    v = {"code": compact(code), "guichet": compact(guichet), "compte": compact(compte), "cle": compact(cle),
         "iban": compact(iban), "bic": compact(bic)}
    for partie, (motif, message) in FORMATS_RIB.items():
        if v[partie] and not re.fullmatch(motif, v[partie]):
            raise HTTPException(status_code=400, detail=message)
    if v["iban"] and not iban_valide(v["iban"]):
        raise HTTPException(status_code=400, detail="IBAN invalide : vérifiez-le sur le relevé d'identité bancaire "
                                                    "(ex : CI93 CI00 8010 0101 2345 6789 0123).")
    if v["bic"] and not re.fullmatch(r"[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?", v["bic"]):
        raise HTTPException(status_code=400, detail="Code BIC / SWIFT : 8 ou 11 caractères (ex : SGCICIAB).")
    rib = v["code"] + v["guichet"] + v["compte"] + v["cle"]
    # IBAN de la zone UEMOA = pays + 2 chiffres de contrôle + RIB complet : les deux doivent concorder
    if v["iban"] and len(rib) == 24 and v["iban"][4:] != rib:
        raise HTTPException(status_code=400, detail="L'IBAN ne correspond pas au RIB saisi (code banque, guichet, "
                                                    "compte et clé). Vérifiez les deux.")
    return v


def rib_lisible(code, guichet, compte, cle) -> str:
    parties = [p for p in (code, guichet, compte, cle) if p]
    return " ".join(parties)


def iban_lisible(iban: str | None) -> str:
    return " ".join(iban[i:i + 4] for i in range(0, len(iban), 4)) if iban else ""
