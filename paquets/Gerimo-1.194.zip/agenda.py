"""Agenda (rendez-vous, appels, visites, courriers, tâches) et demandes de nouveaux clients (prospects).

- Chacun voit les événements qui lui sont destinés, ceux de toute l'équipe et ceux qu'il a créés.
- Un client qui cherche un logement est noté comme « demande » : l'assistant lui propose
  automatiquement les logements libres qui correspondent (type, budget, quartier) et rappelle le suivi.
- Suppression : Admin, mot de passe redemandé (les autres marquent « fait »).
"""
import unicodedata
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import Field
from sqlalchemy import or_
from sqlalchemy.orm import Session as SessionDB, selectinload

from commun import (Email, Formulaire, Mots, NomPersonne, Paragraphe, Suppression, Telephone, Texte, charger,
                    montant)
from models import (Cite, Contrat, Echeance, Evenement, Logement, Prospect, SuiviProspect, Utilisateur, BESOINS_PROSPECT,
                    SOURCES_PROSPECT, STATUTS_PROSPECT, TYPES_EVENEMENT, TYPES_LOGEMENT)
from securite import (cites_autorisees, confirmer_mot_de_passe_admin, exiger_admin, exiger_module, get_db,
                      peut_acceder)

router = APIRouter(prefix="/api")
acces_agenda = exiger_module("agenda")
acces_prospects = exiger_module("prospects")


# ---------- Agenda ----------

class EvenementIn(Formulaire):
    titre: Texte = Field(min_length=1, max_length=200)
    type_evenement: Literal[TYPES_EVENEMENT] = "Rendez-vous"
    date_evenement: date
    heure: time | None = None
    lieu: Texte = Field("", max_length=200)
    telephone: Telephone | None = Field(None, max_length=30)
    notes: Paragraphe = Field("", max_length=2000)
    rappel_minutes: int = Field(30, ge=0, le=1440)
    prospect_id: int | None = None
    contrat_id: int | None = None
    pour_tous: bool = False


def evenements_visibles(db: SessionDB, utilisateur: Utilisateur):
    return db.query(Evenement).filter(or_(Evenement.utilisateur_id.is_(None),
                                          Evenement.utilisateur_id == utilisateur.id,
                                          Evenement.cree_par == utilisateur.id))


def evenement_json(e: Evenement) -> dict:
    return {
        "id": e.id, "titre": e.titre, "type_evenement": e.type_evenement,
        "date_evenement": e.date_evenement.isoformat(), "heure": e.heure.strftime("%H:%M") if e.heure else None,
        "lieu": e.lieu or "", "telephone": e.telephone or "", "notes": e.notes or "",
        "rappel_minutes": e.rappel_minutes, "fait": e.fait, "pour_tous": e.utilisateur_id is None,
        "prospect_id": e.prospect_id, "contrat_id": e.contrat_id,
        "prospect": e.prospect.nom_complet if e.prospect else None,
    }


def charger_evenement(db: SessionDB, utilisateur: Utilisateur, evenement_id: int) -> Evenement:
    e = evenements_visibles(db, utilisateur).filter(Evenement.id == evenement_id).first()
    if e is None:
        raise HTTPException(status_code=404, detail="Événement introuvable.")
    return e


@router.get("/agenda")
def agenda(debut: date | None = Query(None), fin: date | None = Query(None),
           utilisateur: Utilisateur = Depends(acces_agenda), db: SessionDB = Depends(get_db)):
    debut = debut or date.today().replace(day=1)
    fin = fin or debut + timedelta(days=42)
    if (fin - debut).days > 400:
        raise HTTPException(status_code=400, detail="Période trop longue.")
    evenements = evenements_visibles(db, utilisateur).options(selectinload(Evenement.prospect)).filter(
        Evenement.date_evenement >= debut, Evenement.date_evenement <= fin
    ).order_by(Evenement.date_evenement, Evenement.heure.nulls_first(), Evenement.id).all()
    # Dates limites des loyers (le 05) : repères sur le calendrier pour qui gère les paiements
    echeances = {}
    if peut_acceder(utilisateur.role.value, "paiements"):
        requete = db.query(Echeance.date_limite).join(Contrat).join(Logement).filter(
            Echeance.paiement_id.is_(None), Echeance.date_limite >= debut, Echeance.date_limite <= fin)
        autorisees = cites_autorisees(utilisateur)
        if autorisees is not None:
            requete = requete.filter(Logement.cite_id.in_(autorisees))
        for (limite,) in requete:
            echeances[limite.isoformat()] = echeances.get(limite.isoformat(), 0) + 1
    return {"evenements": [evenement_json(e) for e in evenements], "echeances": echeances}


def appliquer_evenement(e: Evenement, d: EvenementIn, utilisateur: Utilisateur) -> None:
    e.titre, e.type_evenement, e.date_evenement, e.heure = d.titre, d.type_evenement, d.date_evenement, d.heure
    e.lieu, e.telephone, e.notes = d.lieu or None, d.telephone or None, d.notes or None
    e.rappel_minutes = d.rappel_minutes
    e.prospect_id, e.contrat_id = d.prospect_id, d.contrat_id
    e.utilisateur_id = None if d.pour_tous else (e.utilisateur_id or utilisateur.id)


@router.post("/agenda")
def creer_evenement(d: EvenementIn, utilisateur: Utilisateur = Depends(acces_agenda), db: SessionDB = Depends(get_db)):
    if d.prospect_id is not None:
        charger(db, Prospect, d.prospect_id, "Demande introuvable.")
    e = Evenement(cree_par=utilisateur.id)
    appliquer_evenement(e, d, utilisateur)
    db.add(e)
    db.commit()
    return evenement_json(e)


@router.put("/agenda/{evenement_id}")
def modifier_evenement(evenement_id: int, d: EvenementIn, utilisateur: Utilisateur = Depends(acces_agenda),
                       db: SessionDB = Depends(get_db)):
    e = charger_evenement(db, utilisateur, evenement_id)
    appliquer_evenement(e, d, utilisateur)
    db.commit()
    return evenement_json(e)


@router.post("/agenda/{evenement_id}/fait")
def basculer_fait(evenement_id: int, utilisateur: Utilisateur = Depends(acces_agenda), db: SessionDB = Depends(get_db)):
    e = charger_evenement(db, utilisateur, evenement_id)
    e.fait = not e.fait
    e.fait_le = datetime.now() if e.fait else None
    db.commit()
    return evenement_json(e)


class Report(Formulaire):
    minutes: int = Field(15, ge=5, le=60 * 24 * 7)


@router.post("/agenda/{evenement_id}/reporter")
def reporter(evenement_id: int, d: Report, utilisateur: Utilisateur = Depends(acces_agenda),
             db: SessionDB = Depends(get_db)):
    """« Me le rappeler plus tard » : décale l'heure (ou la date) de l'événement."""
    e = charger_evenement(db, utilisateur, evenement_id)
    depart = datetime.combine(max(e.date_evenement, date.today()), e.heure or datetime.now().time().replace(second=0, microsecond=0))
    nouveau = max(depart, datetime.now().replace(second=0, microsecond=0)) + timedelta(minutes=d.minutes)
    e.date_evenement, e.heure, e.rappel_minutes = nouveau.date(), nouveau.time(), 0
    db.commit()
    return evenement_json(e)


@router.post("/agenda/{evenement_id}/supprimer")
def supprimer_evenement(evenement_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin),
                        db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, d.mot_de_passe_admin)
    e = charger(db, Evenement, evenement_id, "Événement introuvable.")
    db.delete(e)
    db.commit()
    return {"ok": True}


# ---------- Demandes de nouveaux clients (prospects) ----------

class ProspectIn(Formulaire):
    nom_complet: NomPersonne = Field(min_length=1, max_length=150)
    telephone: Telephone | None = Field(None, max_length=30)
    email: Email | None = Field(None, max_length=150)
    besoin: Literal[BESOINS_PROSPECT] = "Location"
    type_logement: Literal[TYPES_LOGEMENT] | None = None
    quartier: Mots | None = Field(None, max_length=150)
    budget_max: Decimal | None = Field(None, ge=0, max_digits=14, decimal_places=2)
    details: Paragraphe = Field("", max_length=2000)
    source: Literal[SOURCES_PROSPECT] | None = None
    statut: Literal[STATUTS_PROSPECT] = "Nouveau"
    prochaine_action: date | None = None


class SuiviIn(Formulaire):
    note: Paragraphe = Field(min_length=1, max_length=2000)
    statut: Literal[STATUTS_PROSPECT] | None = None
    prochaine_action: date | None = None


def _sans_accents(texte: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", texte or "") if unicodedata.category(c) != "Mn").lower()


def logements_correspondants(db: SessionDB, utilisateur: Utilisateur, p: Prospect, limite: int = 5) -> list[dict]:
    """Logements libres qui correspondent à la demande : type, budget (loyer ≤ budget), quartier."""
    if p.besoin != "Location":
        return []
    requete = db.query(Logement).join(Cite).options(selectinload(Logement.cite)).filter(
        Logement.statut_logement == "Libre")
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None:
        requete = requete.filter(Logement.cite_id.in_(autorisees))
    resultats = []
    quartier = _sans_accents(p.quartier or "")
    for l in requete:
        if p.type_logement and l.type_logement != p.type_logement:
            continue
        if p.budget_max and l.loyer > p.budget_max:
            continue
        score = 1
        lieu = _sans_accents(f"{l.cite.nom} {l.cite.adresse or ''}")
        if quartier:
            if any(mot in lieu for mot in quartier.split() if len(mot) > 2):
                score += 2
            else:
                score -= 0.5
        resultats.append((score, l))
    resultats.sort(key=lambda x: (-x[0], x[1].loyer))
    return [{"id": l.id, "logement": f"Logement {l.numero_logement}, {l.cite.nom}", "type_logement": l.type_logement,
             "loyer": montant(l.loyer), "adresse": l.cite.adresse or "", "bon_quartier": score >= 3}
            for score, l in resultats[:limite] if score > 0]


def prospect_json(db: SessionDB, utilisateur: Utilisateur, p: Prospect, complet: bool = False) -> dict:
    donnees = {
        "id": p.id, "nom_complet": p.nom_complet, "telephone": p.telephone or "", "email": p.email or "",
        "besoin": p.besoin, "type_logement": p.type_logement, "quartier": p.quartier or "",
        "budget_max": montant(p.budget_max) if p.budget_max is not None else None, "details": p.details or "",
        "source": p.source, "statut": p.statut,
        "prochaine_action": p.prochaine_action.isoformat() if p.prochaine_action else None,
        "cree_le": p.cree_le.date().isoformat() if p.cree_le else None,
        "dernier_suivi": p.suivi[0].cree_le.date().isoformat() if p.suivi else None,
    }
    if complet:
        donnees["suivi"] = [{"note": s.note, "date": s.cree_le.strftime("%d/%m/%Y %H:%M"),
                             "auteur": s.auteur.nom_complet if s.auteur else ""} for s in p.suivi]
        donnees["correspondances"] = logements_correspondants(db, utilisateur, p)
    return donnees


@router.get("/prospects/options")
def options_prospects(utilisateur: Utilisateur = Depends(acces_prospects)):
    return {"besoins": BESOINS_PROSPECT, "sources": SOURCES_PROSPECT, "statuts": STATUTS_PROSPECT,
            "types_logement": TYPES_LOGEMENT}


@router.get("/prospects")
def liste_prospects(utilisateur: Utilisateur = Depends(acces_prospects), db: SessionDB = Depends(get_db)):
    prospects = db.query(Prospect).options(selectinload(Prospect.suivi)).order_by(
        Prospect.statut.in_(("Converti", "Perdu")), Prospect.prochaine_action.nulls_last(), Prospect.cree_le.desc()
    ).limit(500).all()
    return [prospect_json(db, utilisateur, p) for p in prospects]


@router.get("/prospects/{prospect_id}")
def detail_prospect(prospect_id: int, utilisateur: Utilisateur = Depends(acces_prospects),
                    db: SessionDB = Depends(get_db)):
    return prospect_json(db, utilisateur, charger(db, Prospect, prospect_id, "Demande introuvable."), complet=True)


def appliquer_prospect(p: Prospect, d: ProspectIn) -> None:
    for champ in ("nom_complet", "besoin", "type_logement", "source", "statut", "prochaine_action", "budget_max"):
        setattr(p, champ, getattr(d, champ))
    p.telephone, p.email, p.quartier = d.telephone or None, d.email or None, d.quartier or None
    p.details = d.details or None
    p.modifie_le = datetime.now()


@router.post("/prospects")
def creer_prospect(d: ProspectIn, utilisateur: Utilisateur = Depends(acces_prospects), db: SessionDB = Depends(get_db)):
    p = Prospect(cree_par=utilisateur.id)
    appliquer_prospect(p, d)
    if p.prochaine_action is None:  # bon réflexe : rappeler un nouveau client dans les 24 h
        p.prochaine_action = date.today() + timedelta(days=1)
    db.add(p)
    db.commit()
    return prospect_json(db, utilisateur, p, complet=True)


@router.put("/prospects/{prospect_id}")
def modifier_prospect(prospect_id: int, d: ProspectIn, utilisateur: Utilisateur = Depends(acces_prospects),
                      db: SessionDB = Depends(get_db)):
    p = charger(db, Prospect, prospect_id, "Demande introuvable.")
    appliquer_prospect(p, d)
    db.commit()
    return prospect_json(db, utilisateur, p, complet=True)


@router.post("/prospects/{prospect_id}/suivi")
def ajouter_suivi(prospect_id: int, d: SuiviIn, utilisateur: Utilisateur = Depends(acces_prospects),
                  db: SessionDB = Depends(get_db)):
    p = charger(db, Prospect, prospect_id, "Demande introuvable.")
    p.suivi.insert(0, SuiviProspect(note=d.note, cree_par=utilisateur.id, cree_le=datetime.now()))
    if d.statut:
        p.statut = d.statut
    elif p.statut == "Nouveau":
        p.statut = "En cours"
    p.prochaine_action = d.prochaine_action if d.prochaine_action or p.statut in ("Converti", "Perdu") else None
    p.modifie_le = datetime.now()
    db.commit()
    return prospect_json(db, utilisateur, p, complet=True)


@router.post("/prospects/{prospect_id}/supprimer")
def supprimer_prospect(prospect_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin),
                       db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, d.mot_de_passe_admin)
    p = charger(db, Prospect, prospect_id, "Demande introuvable.")
    db.delete(p)
    db.commit()
    return {"ok": True}
