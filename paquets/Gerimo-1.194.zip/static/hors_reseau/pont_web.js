// Gérimo hors réseau dans un navigateur (iPhone/iPad, PC portable…) : le même service que l'application Android
// (window.ISUPAndroid, voir HorsReseau.java), mais avec ce que le navigateur sait faire :
// - la copie et la file d'attente sont chiffrées (AES-GCM) avec une clé tirée au hasard, gardée par le navigateur
//   et impossible à lire par une page (clé « non extractible », rangée dans IndexedDB) ;
// - le mot de passe n'est jamais gardé : seulement une empreinte salée (PBKDF2), pour le reconnaître hors réseau ;
// - 5 essais faux → 5 minutes d'attente ; la copie ne s'ouvre plus après le délai réglé par l'Admin.
// Les navigateurs ne le permettent qu'en connexion sécurisée (https) ou sur le PC serveur (localhost).
// Toutes les fonctions renvoient des promesses (window.GerimoPont) ; sans ces conditions, rien n'est défini.
(function () {
  "use strict";
  if (window.ISUPAndroid || !window.isSecureContext || !window.indexedDB || !(window.crypto && crypto.subtle)) return;
  const BASE = "gerimo_hors_reseau", TABLE = "valeurs", ESSAIS_MAX = 5, BLOCAGE_MS = 5 * 60 * 1000, ITERATIONS = 150000;
  const CLE_OUVERTE = "gerimo_hr_ouvert";  // sessionStorage : copie ouverte par le mot de passe, pour cet onglet
  const texte = new TextEncoder(), lecture = new TextDecoder();

  function base() {
    return new Promise((ok, ko) => {
      const r = indexedDB.open(BASE, 1);
      r.onupgradeneeded = () => r.result.createObjectStore(TABLE);
      r.onsuccess = () => ok(r.result);
      r.onerror = () => ko(r.error);
    });
  }
  async function lire(cle) {
    const db = await base();
    return new Promise((ok, ko) => {
      const r = db.transaction(TABLE).objectStore(TABLE).get(cle);
      r.onsuccess = () => ok(r.result);
      r.onerror = () => ko(r.error);
    });
  }
  async function ecrire(cle, valeur) {
    const db = await base();
    return new Promise((ok, ko) => {
      const t = db.transaction(TABLE, "readwrite");
      if (valeur === undefined) t.objectStore(TABLE).delete(cle); else t.objectStore(TABLE).put(valeur, cle);
      t.oncomplete = () => ok();
      t.onerror = () => ko(t.error);
    });
  }

  // ---------- Chiffrement : clé de l'appareil, créée une fois, jamais lisible ----------
  async function cleAppareil() {
    let cle = await lire("cle");
    if (!cle) {
      cle = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
      await ecrire("cle", cle);
    }
    return cle;
  }
  async function chiffrer(chaine) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    return { iv, donnees: await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await cleAppareil(), texte.encode(chaine)) };
  }
  async function dechiffrer(boite) {
    if (!boite) return null;
    try {
      return lecture.decode(await crypto.subtle.decrypt({ name: "AES-GCM", iv: boite.iv }, await cleAppareil(), boite.donnees));
    } catch { return null; }
  }

  // ---------- Mot de passe : empreinte salée ----------
  async function empreinte(motDePasse, sel) {
    const base = await crypto.subtle.importKey("raw", texte.encode(motDePasse), "PBKDF2", false, ["deriveBits"]);
    return new Uint8Array(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: sel, iterations: ITERATIONS }, base, 256));
  }
  const cleMdp = identifiant => "mdp_" + String(identifiant || "").trim().toLowerCase();
  const memes = (a, b) => a.length === b.length && a.every((x, i) => x === b[i]);

  function expiree(copie) {
    const maintenant = Date.now(), limite = Date.parse(copie.valable_jusqu_au), creee = Date.parse(copie.cree_le);
    return !(limite > maintenant) || maintenant < creee - 86400000;  // horloge reculée : pas de copie prolongée
  }
  async function copie() {
    const t = await dechiffrer(await lire("copie"));
    try { return t ? JSON.parse(t) : null; } catch { return null; }
  }
  const local = { get: c => { try { return localStorage.getItem(c); } catch { return null; } },
                  set: (c, v) => { try { localStorage.setItem(c, v); } catch { /* navigation privée */ } } };

  window.GerimoPont = {
    web: true,
    async memoriserConnexion(identifiant, motDePasse) {
      if (!identifiant || !motDePasse) return;
      const sel = crypto.getRandomValues(new Uint8Array(16));
      await ecrire(cleMdp(identifiant), { sel, empreinte: await empreinte(motDePasse, sel) });
    },
    async garderCopie(json) {
      const c = JSON.parse(json);
      if (!c.utilisateur || !c.valable_jusqu_au) throw new Error("Copie incomplète");
      await ecrire("copie", await chiffrer(json));
    },
    async effacerCopie() { await ecrire("copie", undefined); },
    async etatHorsReseau() {
      const c = await copie();
      if (!c) return JSON.stringify({ copie: false });
      const u = c.utilisateur;
      return JSON.stringify({ copie: true, identifiant: u.identifiant, nom: u.nom_complet, role: u.role, cree_le: c.cree_le,
        valable_jusqu_au: c.valable_jusqu_au, jours: c.jours, expiree: expiree(c), entreprise: (c.entreprise || {}).nom_complet,
        mot_de_passe_connu: !!(await lire(cleMdp(u.identifiant))),
        en_attente: JSON.parse(await this.fileAttente()).length });
    },
    async ouvrirCopie(motDePasse) {
      if (Date.now() < Number(local.get("gerimo_hr_bloque") || 0)) return JSON.stringify({ erreur: "Trop d'essais incorrects. Réessayez dans 5 minutes." });
      const c = await copie();
      if (!c) return JSON.stringify({ erreur: "Aucune copie des données sur cet appareil." });
      if (expiree(c)) return JSON.stringify({ erreur: "Cette copie n'est plus utilisable : reconnectez-vous au serveur." });
      const v = await lire(cleMdp(c.utilisateur.identifiant));
      if (!v || !memes(Array.from(await empreinte(motDePasse || "", v.sel)), Array.from(v.empreinte))) {
        const echecs = Number(local.get("gerimo_hr_echecs") || 0) + 1;
        local.set("gerimo_hr_echecs", echecs >= ESSAIS_MAX ? "0" : String(echecs));
        if (echecs >= ESSAIS_MAX) local.set("gerimo_hr_bloque", String(Date.now() + BLOCAGE_MS));
        return JSON.stringify({ erreur: "Mot de passe incorrect." });
      }
      local.set("gerimo_hr_echecs", "0");
      try { sessionStorage.setItem(CLE_OUVERTE, "1"); } catch { /* sans effet */ }
      return JSON.stringify({ ok: true });
    },
    async copieOuverte() {
      let ouverte = false;
      try { ouverte = sessionStorage.getItem(CLE_OUVERTE) === "1"; } catch { /* non */ }
      if (!ouverte) return null;
      const c = await copie();
      return c && !expiree(c) ? JSON.stringify(c) : null;
    },
    async fileAttente() { return (await dechiffrer(await lire("file"))) || "[]"; },
    async enregistrerFile(json) { JSON.parse(json); await ecrire("file", await chiffrer(json)); },
    async infosAppareil() {
      let code = local.get("gerimo_appareil");
      if (!code) {
        code = Array.from(crypto.getRandomValues(new Uint8Array(16)), b => b.toString(16).padStart(2, "0")).join("");
        local.set("gerimo_appareil", code);
      }
      const ua = navigator.userAgent;
      const nom = /iPhone/.test(ua) ? "iPhone" : /iPad|Macintosh/.test(ua) && navigator.maxTouchPoints > 1 ? "iPad"
        : /Windows/.test(ua) ? "PC Windows" : /Macintosh/.test(ua) ? "Mac" : "Navigateur";
      return JSON.stringify({ code, nom: `${nom} (navigateur)`, identifiant_cle: local.get("gerimo_cle_identifiant") || "" });
    },
    async garderCle(identifiant) { local.set("gerimo_cle_identifiant", identifiant); },  // la clé ne sert qu'aux téléphones Android
    fermer() { try { sessionStorage.removeItem(CLE_OUVERTE); } catch { /* sans effet */ } },
    reessayer() { location.href = "/app"; },
    seReconnecter() { this.fermer(); location.href = "/app"; },
  };
})();
