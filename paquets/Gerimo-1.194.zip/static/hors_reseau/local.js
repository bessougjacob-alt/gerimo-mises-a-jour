// Gérimo hors réseau : fait tourner les écrans habituels quand le serveur est injoignable (voir hors_reseau.py).
// Chargé AVANT app.js, il remplace fetch pour les adresses /api :
// - lectures : réponses de la copie du téléphone (celles du serveur à la dernière connexion), mêmes droits ;
// - enregistrements : notés dans la FILE D'ATTENTE du téléphone (chiffrée), montrés tout de suite dans les écrans
//   avec « ⏳ », puis envoyés au serveur à son retour : c'est lui qui les valide avec ses règles habituelles.
// Ce qui n'est pas possible hors réseau répond par un message clair (« au retour du serveur »).
// Trois façons de tourner : l'application Android (window.ISUPAndroid), un navigateur en connexion sécurisée
// (window.GerimoPont, pont_web.js : iPhone, PC portable…), ou l'aperçu (?apercu=1) qui lit la copie sur le serveur.
(function () {
  "use strict";
  const ANDROID = window.ISUPAndroid && window.ISUPAndroid.copieOuverte ? window.ISUPAndroid : null;
  const APERCU = new URLSearchParams(location.search).has("apercu");
  const PONT = ANDROID || (!APERCU && window.GerimoPont) || null;  // ses fonctions peuvent rendre des promesses
  const vraiFetch = window.fetch.bind(window);
  const EN_ATTENTE = " ⏳";
  const CLE_FILE = "gerimo_file_attente";  // aperçu dans un navigateur (sans téléphone)
  let copie = null, reponses = {}, agenda = { evenements: [], echeances: {} }, file = [];
  let autres = [];  // en attente pour un autre utilisateur de ce téléphone : gardés tels quels

  const cloner = v => (v === undefined ? v : JSON.parse(JSON.stringify(v)));
  const aujourdhui = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };
  const maintenant = () => new Date().toISOString().slice(0, 19);
  const dateFr = iso => iso ? `${iso.slice(8, 10)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}` : "";
  const sansAccents = t => String(t ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const nouvelId = () => -(Date.now() % 1e9 + Math.floor(Math.random() * 1000));  // négatif : pas encore au serveur
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
  // « ⏳ » ajouté pour l'affichage ne doit jamais repartir vers le serveur
  const nettoyer = v => typeof v === "string" ? v.split(EN_ATTENTE).join("")
    : Array.isArray(v) ? v.map(nettoyer) : v && typeof v === "object" ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, nettoyer(x)])) : v;
  const marquer = (objet, champ) => { if (objet && typeof objet[champ] === "string" && !objet[champ].endsWith(EN_ATTENTE)) objet[champ] += EN_ATTENTE; return objet; };

  // « ⏳ » s'affiche dans les listes, mais n'entre jamais dans un champ de formulaire (le contrôle de saisie le
  // refuserait, et il ne doit pas être enregistré)
  for (const Type of [HTMLInputElement, HTMLTextAreaElement]) {
    const valeur = Object.getOwnPropertyDescriptor(Type.prototype, "value");
    Object.defineProperty(Type.prototype, "value", {
      configurable: true, enumerable: valeur.enumerable,
      get() { return valeur.get.call(this); },
      set(v) { valeur.set.call(this, typeof v === "string" ? v.split(EN_ATTENTE).join("") : v); },
    });
  }

  // Hors réseau, la page est en « https » : l'écran essaierait la caméra intégrée au navigateur, que l'appli ne
  // donne pas ; on passe par l'appareil photo du téléphone, comme en ligne
  if (ANDROID && navigator.mediaDevices) {
    try { Object.defineProperty(navigator.mediaDevices, "getUserMedia", { value: undefined, configurable: true }); } catch { /* sans effet */ }
  }

  function json(donnees, statut = 200) {
    return new Response(JSON.stringify(donnees), { status: statut, headers: { "Content-Type": "application/json" } });
  }
  const pasHorsReseau = quoi => json({ detail: `${quoi} n'est pas possible hors réseau : ce sera à faire au retour du serveur.` }, 503);

  // ---------- Enregistrements possibles hors réseau ----------
  // motif (méthode + adresse) → appliquer(op, paramètres) : met à jour les réponses locales et renvoie ce que le
  // serveur aurait répondu ; resume(op) : une phrase pour la liste des enregistrements en attente.
  const liste = chemin => (reponses[chemin] = reponses[chemin] || []);
  const evenement = id => agenda.evenements.find(e => e.id === id);
  const prospect = id => liste("/api/prospects").find(p => p.id === id);
  const ACTIONS = [
    {
      motif: /^POST \/api\/agenda$/,
      appliquer(op) {
        const c = op.corps;
        const e = { id: op.id_local, titre: c.titre, type_evenement: c.type_evenement || "Rendez-vous", date_evenement: c.date_evenement,
          heure: c.heure ? String(c.heure).slice(0, 5) : null, lieu: c.lieu || "", telephone: c.telephone || "", notes: c.notes || "",
          rappel_minutes: c.rappel_minutes ?? 30, fait: false, pour_tous: !!c.pour_tous, prospect_id: c.prospect_id ?? null,
          contrat_id: c.contrat_id ?? null, prospect: null };
        agenda.evenements.push(marquer(e, "titre"));
        agenda.evenements.sort((a, b) => (a.date_evenement + (a.heure || "")).localeCompare(b.date_evenement + (b.heure || "")));
        return e;
      },
      resume: op => `Agenda : ${op.corps.type_evenement || "Rendez-vous"} « ${op.corps.titre} » le ${dateFr(op.corps.date_evenement)}`,
    },
    {
      motif: /^PUT \/api\/agenda\/(-?\d+)$/,
      appliquer(op, [id]) {
        const e = evenement(+id);
        if (!e) throw new Error("Événement introuvable dans la copie.");
        const c = op.corps;
        Object.assign(e, { titre: c.titre, type_evenement: c.type_evenement, date_evenement: c.date_evenement,
          heure: c.heure ? String(c.heure).slice(0, 5) : null, lieu: c.lieu || "", telephone: c.telephone || "", notes: c.notes || "",
          rappel_minutes: c.rappel_minutes ?? e.rappel_minutes, pour_tous: !!c.pour_tous });
        return marquer(e, "titre");
      },
      resume: op => `Agenda : modification de « ${op.corps.titre} »`,
    },
    {
      motif: /^POST \/api\/agenda\/(-?\d+)\/fait$/,
      appliquer(op, [id]) {
        const e = evenement(+id);
        if (!e) throw new Error("Événement introuvable dans la copie.");
        e.fait = !e.fait;
        return marquer(e, "titre");
      },
      resume: op => `Agenda : « ${op.titre || "événement"} » marqué fait / à faire`,
      titre: (op, [id]) => (evenement(+id) || {}).titre,
    },
    {
      motif: /^POST \/api\/agenda\/(-?\d+)\/reporter$/,
      appliquer(op, [id]) {
        const e = evenement(+id);
        if (!e) throw new Error("Événement introuvable dans la copie.");
        const depart = new Date(`${e.date_evenement > aujourdhui() ? e.date_evenement : aujourdhui()}T${e.heure || "08:00"}`);
        const nouveau = new Date(Math.max(depart.getTime(), Date.now()) + (op.corps.minutes || 15) * 60000);
        e.date_evenement = `${nouveau.getFullYear()}-${String(nouveau.getMonth() + 1).padStart(2, "0")}-${String(nouveau.getDate()).padStart(2, "0")}`;
        e.heure = `${String(nouveau.getHours()).padStart(2, "0")}:${String(nouveau.getMinutes()).padStart(2, "0")}`;
        e.rappel_minutes = 0;
        return marquer(e, "titre");
      },
      resume: op => `Agenda : « ${op.titre || "événement"} » reporté`,
      titre: (op, [id]) => (evenement(+id) || {}).titre,
    },
    {
      motif: /^POST \/api\/prospects$/,
      appliquer(op) {
        const c = op.corps;
        const p = { id: op.id_local, nom_complet: c.nom_complet, telephone: c.telephone || "", email: c.email || "", besoin: c.besoin || "Location",
          type_logement: c.type_logement || null, quartier: c.quartier || "", budget_max: c.budget_max ?? null, details: c.details || "",
          source: c.source || null, statut: c.statut || "Nouveau", prochaine_action: c.prochaine_action || null,
          cree_le: aujourdhui(), dernier_suivi: null };
        liste("/api/prospects").unshift(marquer(p, "nom_complet"));
        reponses[`/api/prospects/${p.id}`] = { ...p, suivi: [], correspondances: [] };
        return reponses[`/api/prospects/${p.id}`];
      },
      resume: op => `Demande de ${op.corps.nom_complet} (${op.corps.besoin || "Location"})`,
    },
    {
      motif: /^PUT \/api\/prospects\/(-?\d+)$/,
      appliquer(op, [id]) {
        const p = prospect(+id);
        if (!p) throw new Error("Demande introuvable dans la copie.");
        Object.assign(p, op.corps, { budget_max: op.corps.budget_max ?? null });
        marquer(p, "nom_complet");
        const detail = reponses[`/api/prospects/${id}`] || { suivi: [], correspondances: [] };
        reponses[`/api/prospects/${id}`] = { ...detail, ...p };
        return reponses[`/api/prospects/${id}`];
      },
      resume: op => `Demande de ${op.corps.nom_complet} modifiée`,
    },
    {
      motif: /^POST \/api\/prospects\/(-?\d+)\/suivi$/,
      appliquer(op, [id]) {
        const p = prospect(+id);
        if (!p) throw new Error("Demande introuvable dans la copie.");
        const c = op.corps;
        if (c.statut) p.statut = c.statut; else if (p.statut === "Nouveau") p.statut = "En cours";
        p.prochaine_action = c.prochaine_action || (["Converti", "Perdu"].includes(p.statut) ? p.prochaine_action : null);
        p.dernier_suivi = aujourdhui();
        marquer(p, "nom_complet");
        const detail = reponses[`/api/prospects/${id}`] || { ...p, suivi: [], correspondances: [] };
        detail.suivi = [{ note: c.note + EN_ATTENTE, date: `${dateFr(aujourdhui())} ${new Date().toTimeString().slice(0, 5)}`,
          auteur: copie.utilisateur.nom_complet }, ...(detail.suivi || [])];
        reponses[`/api/prospects/${id}`] = { ...detail, ...p, suivi: detail.suivi };
        return reponses[`/api/prospects/${id}`];
      },
      resume: op => `Suivi de « ${op.titre || "demande"} » : ${String(op.corps.note).slice(0, 60)}`,
      titre: (op, [id]) => (prospect(+id) || {}).nom_complet,
    },
    {
      motif: /^POST \/api\/signalements$/,
      appliquer(op) {
        const c = op.corps;
        const bien = (reponses["/api/biens"] || []).find(b => b.id === c.cite_id) || {};
        const logement = (bien.logements || []).find(l => l.id === c.logement_id);
        const s = { id: op.id_local, cite_id: c.cite_id, cite: bien.nom || "", logement_id: c.logement_id ?? null,
          logement: logement ? logement.numero_logement : null, categorie: c.categorie, urgence: c.urgence || "Normale",
          description: c.description, signale_par: c.signale_par || "", statut: "Ouvert", resolution: "",
          date: dateFr(aujourdhui()), resolu_le: null, auteur: copie.utilisateur.nom_complet, photo: null };
        liste("/api/signalements").unshift(marquer(s, "description"));
        return s;
      },
      resume: op => `Problème signalé : ${op.corps.categorie} — ${String(op.corps.description).slice(0, 60)}`,
    },
    // ----- États des lieux : brouillon, photos, signature (le n° EDL-AAAA-NNNN et le PDF viennent à l'envoi) -----
    {
      motif: /^POST \/api\/etats-des-lieux$/,
      appliquer(op) {
        const c = op.corps, liste = listeEdl();
        if (liste.etats.some(e => e.contrat_id === c.contrat_id && e.type_edl === c.type_edl)) {
          throw new Error(`Ce contrat a déjà un état des lieux de ${String(c.type_edl).toLowerCase()}.`);
        }
        if (c.date_edl && c.date_edl > aujourdhui()) throw new Error("La date de l'état des lieux ne peut pas être dans le futur.");
        const contrat = contratEdl(c.contrat_id);
        const d = { id: op.id_local, numero: NUMERO_PROVISOIRE, type_edl: c.type_edl, statut: "Brouillon", date_edl: c.date_edl || aujourdhui(),
          contrat_id: c.contrat_id, numero_contrat: contrat.numero_contrat || "", locataire: contrat.locataire || "",
          telephone: contrat.telephone || "", email: contrat.email || "", logement: contrat.logement || "",
          nb_photos: 0, envoye_le: null, signe_le: null };
        liste.etats.unshift(marquer({ ...d }, "locataire"));
        liste.a_faire = liste.a_faire.filter(a => !(a.contrat_id === c.contrat_id && a.type_edl === c.type_edl));
        liste.brouillons = (liste.brouillons || 0) + 1;
        reponses[`/api/etats-des-lieux/${d.id}`] = { ...d, ...detailEdl(c), photos: [], degradations: [] };
        return { id: d.id, numero: NUMERO_PROVISOIRE };
      },
      resume: op => `État des lieux d'${String(op.corps.type_edl).toLowerCase() === "entrée" ? "entrée" : "sortie"} : ${contratEdl(op.corps.contrat_id).locataire || "contrat"}`,
    },
    {
      motif: /^PUT \/api\/etats-des-lieux\/(-?\d+)$/,
      appliquer(op, [id]) {
        const d = reponses[`/api/etats-des-lieux/${id}`];
        if (!d) throw new Error("Cet état des lieux n'est pas dans la copie du téléphone : à reprendre au retour du serveur.");
        if (d.statut === "Signé") throw new Error("État des lieux signé : il ne peut plus être modifié.");
        if (op.corps.date_edl && op.corps.date_edl > aujourdhui()) throw new Error("La date de l'état des lieux ne peut pas être dans le futur.");
        Object.assign(d, detailEdl(op.corps), { date_edl: op.corps.date_edl || d.date_edl });
        const ligne = listeEdl().etats.find(e => e.id === +id);
        if (ligne) { ligne.date_edl = d.date_edl; marquer(ligne, "locataire"); }
        return { id: +id };
      },
      resume: op => `État des lieux de ${contratEdl(op.corps.contrat_id).locataire || "contrat"} modifié`,
    },
    {
      motif: /^POST \/api\/etats-des-lieux\/(-?\d+)\/photos$/,
      appliquer(op, [id]) {
        const d = reponses[`/api/etats-des-lieux/${id}`];
        if (!d) throw new Error("Cet état des lieux n'est pas dans la copie du téléphone.");
        const photo = { id: op.id_local, piece: op.corps.piece || null, legende: op.corps.legende || null, url: op.corps.contenu };
        d.photos.push(photo);
        d.nb_photos = d.photos.length;
        const ligne = listeEdl().etats.find(e => e.id === +id);
        if (ligne) ligne.nb_photos = d.photos.length;
        return photo;
      },
      resume: op => `Photo d'état des lieux${op.corps.piece ? " — " + op.corps.piece : ""}`,
    },
    {
      motif: /^POST \/api\/etats-des-lieux\/photos\/(-?\d+)\/retirer$/,
      appliquer(op, [id]) {
        for (const [cle, d] of Object.entries(reponses)) {
          if (!cle.startsWith("/api/etats-des-lieux/") || !d || !Array.isArray(d.photos)) continue;
          if (d.photos.some(ph => ph.id === +id)) {
            d.photos = d.photos.filter(ph => ph.id !== +id);
            d.nb_photos = d.photos.length;
            return { ok: true };
          }
        }
        throw new Error("Photo introuvable dans la copie.");
      },
      resume: () => "Photo d'état des lieux retirée",
    },
    {
      motif: /^POST \/api\/etats-des-lieux\/(-?\d+)\/signer$/,
      appliquer(op, [id]) {
        const d = reponses[`/api/etats-des-lieux/${id}`];
        if (!d) throw new Error("Cet état des lieux n'est pas dans la copie du téléphone.");
        if (!d.pieces || !d.pieces.length) throw new Error("Ajoutez au moins une pièce avant de signer.");
        const quand = new Date();
        d.statut = "Signé";
        d.signe_le = `${dateFr(aujourdhui())} à ${String(quand.getHours()).padStart(2, "0")}:${String(quand.getMinutes()).padStart(2, "0")}`;
        const ligne = listeEdl().etats.find(e => e.id === +id);
        if (ligne) { ligne.statut = "Signé"; ligne.signe_le = d.signe_le; listeEdl().brouillons = Math.max(0, (listeEdl().brouillons || 1) - 1); }
        return { ok: true, numero: d.numero };
      },
      resume: op => `Signature de l'état des lieux${op.titre ? " de " + op.titre : ""} (PDF fait à l'envoi)`,
      titre: (op, [id]) => (reponses[`/api/etats-des-lieux/${id}`] || {}).locataire,
    },
    // ----- Encaissement : bon provisoire (BP-…) ; le vrai reçu REC-… et la période exacte viennent du serveur -----
    {
      motif: /^POST \/api\/paiements$/,
      preparer(corps) {
        corps.date_paiement = corps.date_paiement || aujourdhui();  // date réelle du paiement, pas celle de l'envoi
        corps.bon = `BP-${aujourdhui().replace(/-/g, "").slice(2)}-${String(Math.floor(Math.random() * 9000) + 1000)}`;
        const note = `Bon provisoire ${corps.bon} (encaissé hors réseau le ${dateFr(corps.date_paiement)})`;
        corps.observation = corps.observation ? `${corps.observation} — ${note}` : note;
      },
      appliquer(op) {
        const c = op.corps, opts = reponses["/api/paiements/options"] || { contrats: [] };
        const contrat = opts.contrats.find(x => x.id === c.contrat_id);
        if (!contrat) throw new Error("Contrat introuvable dans la copie du téléphone.");
        if (c.date_paiement > aujourdhui()) throw new Error("La date du paiement ne peut pas être dans le futur.");
        let nb = 0;  // mois que ce bon couvrira sans doute (le serveur décide au retour)
        let reste = 0;  // versement partiel : ce qui va sur le mois suivant, sans le solder
        if (c.motif_paiement === "Caution/avance") {
          if (contrat.entree.payee) throw new Error("La caution et l'avance de ce contrat sont déjà encaissées.");
          contrat.entree.payee = true;
          retirerMoisDus(contrat, c.contrat_id, m => contrat.entree.mois_avance.includes(m.libelle), contrat.entree.mois_avance);
        } else if (c.motif_paiement === "Règlement total") {
          nb = contrat.reglement_total.nb_mois;
          if (!nb) throw new Error("Aucun loyer n'est dû à ce jour sur ce contrat.");
        } else if (c.versement_partiel) {
          // Versement partiel : les mois les plus anciens sont soldés, le reste va sur le mois suivant (l'écran a déjà
          // refusé un montant trop élevé ; le serveur refera la répartition exacte, pénalités comprises, au retour)
          if (!contrat.reglement_total.nb_mois) throw new Error("Aucun loyer n'est dû à ce jour sur ce contrat.");
          let disponible = c.montant;
          for (const m of contrat.reglement_total.mois) {
            if (disponible < m.montant) break;
            disponible -= m.montant;
            nb += 1;
          }
          reste = disponible;
        } else {
          nb = c.nb_mois || 1;
          if (contrat.prochains_mois.length < nb) throw new Error(`Il ne reste que ${contrat.prochains_mois.length} mois à payer sur ce contrat.`);
        }
        if (nb) {  // les mois suivants deviennent les prochains à payer, comme au bureau
          const payes = contrat.prochains_mois.slice(0, nb);
          contrat.prochains_mois = contrat.prochains_mois.slice(nb);
          retirerMoisDus(contrat, c.contrat_id, m => payes.some(x => x.mois === m.mois), payes.map(m => m.libelle));
        }
        if (reste > 0 && contrat.prochains_mois.length) {  // le mois entamé garde son reste à payer
          const entame = contrat.prochains_mois[0];
          for (const m of [entame, contrat.reglement_total.mois.find(x => x.mois === entame.mois)]) {
            if (m) m.montant -= reste;
          }
          contrat.reglement_total.montant -= reste;
          for (const imp of [contrat.impayes, (reponses["/api/impayes"] || []).find(i => i.id === c.contrat_id)]) {
            if (imp && imp.mois.includes(entame.libelle)) {
              imp.montant = Math.max(0, imp.montant - reste);
              imp.deja_verse = (imp.deja_verse || 0) + reste;
            }
          }
        }
        (reponses["/api/paiements"] = reponses["/api/paiements"] || []).unshift({
          id: op.id_local, numero_recu: c.bon, statut_paiement: "En attente", date_paiement: c.date_paiement,
          montant: c.montant, mode_paiement: c.mode_paiement, motif_paiement: c.motif_paiement, nb_mois: nb,
          periode: "fixée au retour du serveur", numero_contrat: contrat.numero_contrat,
          locataire: contrat.locataire.nom_complet + EN_ATTENTE, telephone: contrat.locataire.telephone,
          logement: contrat.logement, adresse: contrat.adresse, encaisse_par: copie.utilisateur.nom_complet,
          motif_annulation: null, repris: false, quittance_possible: false, versement_partiel: reste > 0 });
        return { id: op.id_local, numero_recu: c.bon, montant: c.montant, periode: "fixée au retour du serveur", penalite: 0 };
      },
      apres: op => setTimeout(() => afficherBon(op), 400),
      resume: op => `Encaissement de ${francsTexte(op.corps.montant)} — ${((reponses["/api/paiements/options"] || { contrats: [] })
        .contrats.find(x => x.id === op.corps.contrat_id) || { locataire: {} }).locataire.nom_complet || "contrat"} (bon ${op.corps.bon})`,
    },
    // ----- Dépenses (la Caisse contrôle ensuite celles faites hors réseau par les agents) -----
    {
      motif: /^POST \/api\/depenses$/,
      appliquer(op) { return { id: depenseLocale(op, op.id_local) }; },
      resume: op => `Dépense de ${francsTexte(op.corps.montant)} : ${op.corps.motif}`,
    },
    {
      motif: /^PUT \/api\/depenses\/(-?\d+)$/,
      appliquer(op, [id]) {
        if (!liste("/api/depenses").some(d => d.id === +id)) throw new Error("Dépense introuvable dans la copie du téléphone.");
        return { id: depenseLocale(op, +id) };
      },
      resume: op => `Dépense modifiée : ${op.corps.motif} (${francsTexte(op.corps.montant)})`,
    },
    // ----- Nouveau contrat (et nouveau locataire) : toujours « En attente », l'Admin le valide au bureau -----
    {
      motif: /^POST \/api\/contrats$/,
      preparer(corps, op) {
        corps.statut_contrat = "En attente";
        if (corps.nouveau_locataire) op.autres_ids = { locataire_id: op.id_local - 1 };
      },
      appliquer(op) {
        const c = op.corps, opts = reponses["/api/contrats/options"] || { logements_disponibles: [], locataires: [] };
        const logement = opts.logements_disponibles.find(l => l.id === c.logement_id);
        if (!logement) throw new Error("Ce logement n'est plus libre dans la copie du téléphone.");
        let locataire;
        if (c.nouveau_locataire) {
          const n = c.nouveau_locataire;
          locataire = { id: op.autres_ids.locataire_id, nom_complet: n.nom_complet, cni: n.cni || null, telephone: n.telephone || null,
            profession: n.profession || null, email: n.email || null, nb_pieces: 0, contrats: [] };
          liste("/api/locataires").unshift(marquer({ ...locataire }, "nom_complet"));
          opts.locataires.unshift({ id: locataire.id, nom_complet: n.nom_complet + EN_ATTENTE, telephone: n.telephone || null });
        } else {
          locataire = liste("/api/locataires").find(l => l.id === c.locataire_id)
            || opts.locataires.find(l => l.id === c.locataire_id);
          if (!locataire) throw new Error("Locataire introuvable dans la copie du téléphone.");
        }
        opts.logements_disponibles = opts.logements_disponibles.filter(l => l.id !== c.logement_id);
        const [bien, numero] = logement.libelle.split(" — Logement ");
        const ligne = { id: op.id_local, numero_contrat: "provisoire", statut_contrat: "En attente", a_risque: false,
          type_contrat: c.type_contrat, usage_bien: c.usage_bien, terme_loyer: c.terme_loyer, montant_loyer: c.montant_loyer,
          mois_caution: c.mois_caution, montant_caution: c.montant_loyer * c.mois_caution, mois_avance: c.mois_avance,
          montant_avance: c.montant_loyer * c.mois_avance, date_debut: c.date_debut, date_fin: c.date_fin || null,
          date_resiliation: null, motif_resiliation: null, date_preavis: null, date_depart: null, motif_depart: null,
          locataire: { id: locataire.id, nom_complet: String(locataire.nom_complet).split(EN_ATTENTE).join("") + EN_ATTENTE,
            telephone: locataire.telephone, cni: locataire.cni || null, email: locataire.email || null },
          logement: { id: c.logement_id, numero_logement: numero || "", cite_id: null, cite_nom: bien || "", adresse: null } };
        liste("/api/contrats").unshift(ligne);
        const fiche = liste("/api/locataires").find(l => l.id === locataire.id);
        if (fiche && Array.isArray(fiche.contrats)) fiche.contrats.push({ id: op.id_local, numero_contrat: "provisoire",
          statut_contrat: "En attente", logement: `Logement ${numero || ""}, ${bien || ""}`, adresse: null });
        return { id: op.id_local, numero_contrat: "provisoire (en attente de validation au bureau)", locataire_id: locataire.id };
      },
      resume: op => `Nouveau contrat « en attente » : ${op.corps.nouveau_locataire ? op.corps.nouveau_locataire.nom_complet
        : ((liste("/api/locataires").find(l => l.id === op.corps.locataire_id) || {}).nom_complet || "locataire")}`,
    },
    {
      motif: /^PUT \/api\/locataires\/(-?\d+)$/,
      appliquer(op, [id]) {
        const fiche = liste("/api/locataires").find(l => l.id === +id);
        if (!fiche) throw new Error("Locataire introuvable dans la copie du téléphone.");
        const c = op.corps;
        Object.assign(fiche, { nom_complet: c.nom_complet + EN_ATTENTE, cni: c.cni || null, telephone: c.telephone || null,
          profession: c.profession || null, email: c.email || null });
        for (const ct of liste("/api/contrats")) {
          if (ct.locataire && ct.locataire.id === +id) Object.assign(ct.locataire, { nom_complet: fiche.nom_complet, telephone: fiche.telephone });
        }
        return { id: +id };
      },
      resume: op => `Fiche du locataire ${op.corps.nom_complet} modifiée`,
    },
    {
      motif: /^POST \/api\/pieces$/,
      appliquer(op) {
        const c = op.corps;
        const cle = c.locataire_id != null ? `locataire_id=${c.locataire_id}` : `proprietaire_id=${c.proprietaire_id}`;
        const est_pdf = String(c.contenu || "").startsWith("data:application/pdf");
        const piece = { id: op.id_local, type_piece: c.type_piece || "CNI", nom_fichier: (c.nom_fichier || c.type_piece || "piece") + EN_ATTENTE,
          type_mime: est_pdf ? "application/pdf" : "image/jpeg", taille: Math.round(String(c.contenu || "").length * 0.75),
          date: aujourdhui(), url: c.contenu };
        (reponses[`pieces:${cle}`] = reponses[`pieces:${cle}`] || []).push(piece);
        const fiche = c.locataire_id != null && liste("/api/locataires").find(l => l.id === c.locataire_id);
        if (fiche) fiche.nb_pieces = (fiche.nb_pieces || 0) + 1;
        return piece;
      },
      resume: op => `Pièce jointe (${op.corps.type_piece || "CNI"}) pour ${op.corps.locataire_id != null
        ? ((liste("/api/locataires").find(l => l.id === op.corps.locataire_id) || {}).nom_complet || "le locataire").split(EN_ATTENTE).join("")
        : "le propriétaire"}`,
    },
  ];

  // Dépense ajoutée ou modifiée hors réseau : mêmes contrôles qu'au serveur, puis la ligne de la liste
  function depenseLocale(op, id) {
    const c = op.corps;
    if (c.date_depense > aujourdhui()) throw new Error("La date de la dépense ne peut pas être dans le futur.");
    if ((c.montant_tva || 0) >= c.montant) throw new Error("La TVA doit être inférieure au montant (TVA comprise).");
    if (c.cite_id === null && copie.utilisateur.role === "Gestionnaire") {
      throw new Error("Les dépenses de fonctionnement de l'entreprise sont saisies par l'Admin, la Caisse ou le Comptable.");
    }
    const bien = ((reponses["/api/depenses/options"] || {}).biens || []).find(b => b.id === c.cite_id);
    const logement = bien && (bien.logements || []).find(l => l.id === c.logement_id);
    const ligne = { id, cite_id: c.cite_id, bien: bien ? bien.nom : "Fonctionnement de l'entreprise", adresse: null,
      fonctionnement: c.cite_id === null, montant_tva: c.montant_tva || 0, justificatif: c.justificatif || "",
      logement_id: c.logement_id || null, logement: logement ? `Logement ${logement.numero}` : null, montant: c.montant,
      motif: c.motif + EN_ATTENTE, categorie: c.categorie, a_la_charge_de: c.cite_id === null ? "Entreprise" : c.a_la_charge_de,
      mode_paiement: c.mode_paiement, date_depense: c.date_depense, compte_id: c.compte_id || null,
      saisi_par: copie.utilisateur.nom_complet };
    const depenses = liste("/api/depenses");
    const i = depenses.findIndex(d => d.id === id);
    if (i >= 0) depenses[i] = ligne; else depenses.unshift(ligne);
    return id;
  }

  // Mois réglés par un bon : retirés des mois dus (règlement total), des impayés du contrat et de la liste des impayés
  function retirerMoisDus(contrat, contratId, estPaye, libelles) {
    const dus = contrat.reglement_total.mois.filter(m => !estPaye(m));
    contrat.reglement_total = { ...contrat.reglement_total, nb_mois: dus.length, mois: dus,
      montant: dus.reduce((t, m) => t + m.montant, 0), periode: dus.length ? `${dus[0].libelle} à ${dus.at(-1).libelle}` : "" };
    for (const imp of [contrat.impayes, (reponses["/api/impayes"] || []).find(i => i.id === contratId)]) {
      if (!imp) continue;
      const restants = imp.mois.filter(m => !libelles.includes(m));
      imp.montant = Math.max(0, imp.montant - (imp.mois.length - restants.length) * (imp.montant / Math.max(imp.mois.length, 1)));
      imp.mois = restants;
      imp.nb_mois = restants.length;
    }
    if (contrat.impayes && !contrat.impayes.nb_mois) contrat.impayes = null;
    reponses["/api/impayes"] = (reponses["/api/impayes"] || []).filter(i => i.nb_mois > 0);
  }

  const francsTexte = n => `${Math.round(Number(n) || 0).toLocaleString("fr-FR").replace(/\u202f|\u00a0/g, " ")} F`;

  // Bon provisoire : montré tout de suite, et envoyé au locataire par WhatsApp (WhatsApp l'envoie dès qu'il a du réseau)
  function afficherBon(op) {
    const c = op.corps;
    const contrat = ((reponses["/api/paiements/options"] || { contrats: [] }).contrats.find(x => x.id === c.contrat_id)) || { locataire: {} };
    const publics = reponses["/api/parametres/publics"] || {};
    const entreprise = (copie.entreprise || {}).nom_complet || "";
    const texte = `Bonjour ${contrat.locataire.nom_complet || ""},\nNous avons bien reçu ${francsTexte(c.montant)} le ${dateFr(c.date_paiement)} `
      + `(${c.motif_paiement}, ${c.mode_paiement}), remis à ${copie.utilisateur.nom_complet}.\n`
      + `Bon provisoire N° ${c.bon}. Votre reçu officiel vous sera envoyé dès le retour de notre système.\n`
      + `${entreprise}${publics.entreprise_telephones ? " — " + String(publics.entreprise_telephones).split("/")[0].trim() : ""}`;
    let tel = String(contrat.locataire.telephone || "").replace(/\D/g, "");
    if (tel.length === 10) tel = "225" + tel;
    const echap = t => String(t ?? "").replace(/[&<>"']/g, x => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[x]));
    const html = `<div class="modal-tete"><h3>Bon provisoire ${echap(c.bon)}</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
      <div class="recap" style="line-height:1.7"><b>${francsTexte(c.montant)}</b> reçus le ${dateFr(c.date_paiement)}<br>
        de <b>${echap(contrat.locataire.nom_complet || "")}</b> — ${echap(contrat.logement || "")}<br>
        ${echap(c.motif_paiement)} — ${echap(c.mode_paiement)} — reçu par ${echap(copie.utilisateur.nom_complet)}</div>
      <p class="petit">Hors réseau, ceci n'est qu'un bon provisoire. Le reçu officiel (N° REC-…, avec la période payée) sera créé au retour du serveur ; vous pourrez alors l'envoyer au locataire.</p>
      <div class="actions"><button class="btn" data-fermer>Fermer</button>
        ${tel.length >= 8 ? `<a class="btn primary" style="text-decoration:none" href="https://wa.me/${tel}?text=${encodeURIComponent(texte)}" target="_blank" rel="noopener">Envoyer par WhatsApp</a>` : ""}</div>`;
    if (typeof ouvrirFenetre === "function") ouvrirFenetre(html);
  }

  // États des lieux : liste, contrat (depuis les options) et partie « détail » tirée de ce qui est saisi
  const NUMERO_PROVISOIRE = "provisoire";
  const listeEdl = () => (reponses["/api/etats-des-lieux"] = reponses["/api/etats-des-lieux"] || { etats: [], a_faire: [], brouillons: 0 });
  function contratEdl(id) {
    const c = ((reponses["/api/etats-des-lieux/options"] || {}).contrats || []).find(x => x.id === id) || {};
    const complet = (reponses["/api/contrats"] || []).find(x => x.id === id);
    return { ...c, telephone: complet ? complet.locataire.telephone : "", email: complet ? complet.locataire.email : "" };
  }
  function detailEdl(c) {
    return { pieces: c.pieces || [], nb_cles: c.nb_cles || 0, observations: c.observations || "", retenues: c.retenues || 0,
      compteurs: { electricite: c.compteur_electricite || {}, eau: c.compteur_eau || {} },
      caution: ((copie.edl || {}).cautions || {})[String(c.contrat_id)] || 0 };
  }
  // comme /api/etats-des-lieux/modele : sortie = reprise de l'entrée ; sinon grille selon le logement
  function modeleEdl(url) {
    const contratId = Number(url.searchParams.get("contrat_id")), type = url.searchParams.get("type_edl");
    const m = copie.edl || {};
    const caution = (m.cautions || {})[String(contratId)] || 0;
    const entree = (m.entrees || {})[String(contratId)];
    if (type === "Sortie" && entree) {
      return { pieces: entree.pieces.map(p => ({ piece: p.piece, elements: (p.elements || []).map(e =>
        ({ element: e.element, etat: e.etat, observation: "", etat_entree: e.etat })) })),
        compteurs: {}, nb_cles: entree.nb_cles, depuis_entree: true, caution };
    }
    const contrat = contratEdl(contratId);
    return { pieces: cloner((m.grilles || {})[contrat.type_logement] || []), compteurs: {}, nb_cles: 2, depuis_entree: false, caution };
  }

  function trouverAction(methode, chemin) {
    for (const a of ACTIONS) {
      const m = a.motif.exec(`${methode} ${chemin}`);
      if (m) return { action: a, params: m.slice(1) };
    }
    return null;
  }

  // ---------- File d'attente (téléphone : chiffrée ; aperçu navigateur : localStorage) ----------
  async function lireFile() {
    try { return JSON.parse((PONT ? await PONT.fileAttente() : localStorage.getItem(CLE_FILE)) || "[]"); } catch { return []; }
  }
  let ecriture = Promise.resolve();  // écritures du navigateur : l'une après l'autre, dans l'ordre
  function enregistrerFile() {
    const texte = JSON.stringify([...autres, ...file]);
    if (PONT) ecriture = ecriture.then(() => PONT.enregistrerFile(texte)).catch(() => {
      alert("Enregistrement hors réseau impossible sur cet appareil (mémoire pleine ?).");
    });
    else localStorage.setItem(CLE_FILE, texte);
    majBandeau();
  }

  // Les réponses de la copie, plus chaque enregistrement en attente rejoué dans l'ordre
  function reconstruire() {
    reponses = cloner(copie.reponses) || {};
    agenda = cloner(copie.agenda && copie.agenda.reponse) || { evenements: [], echeances: {} };
    for (const op of file) {
      const t = trouverAction(op.methode, op.chemin);
      try { if (t) t.action.appliquer(cloner(op), t.params); } catch { /* élément disparu de la copie : il partira quand même */ }
    }
  }

  // ---------- Lectures ----------
  function lire(url) {
    const chemin = url.pathname;
    if (chemin === "/api/agenda") {
      const debut = url.searchParams.get("debut") || "0000", fin = url.searchParams.get("fin") || "9999";
      return json({ evenements: agenda.evenements.filter(e => e.date_evenement >= debut && e.date_evenement <= fin),
        echeances: Object.fromEntries(Object.entries(agenda.echeances || {}).filter(([d]) => d >= debut && d <= fin)) });
    }
    if (chemin.startsWith("/api/acces/")) {
      const module = decodeURIComponent(chemin.slice(11));
      return (reponses["/api/moi"] || { modules: [] }).modules.includes(module)
        ? json({ module, acces: true }) : json({ detail: "Accès refusé pour votre profil." }, 403);
    }
    if (chemin === "/api/recherche") return json(rechercher(url.searchParams.get("q") || ""));
    if (chemin === "/api/etats-des-lieux/modele") return json(modeleEdl(url));
    // pièces jointes : pas dans la copie (fichiers) ; on montre celles ajoutées hors réseau
    if (chemin === "/api/pieces") return json(cloner(reponses[`pieces:${url.search.slice(1)}`] || []));
    if (chemin === "/api/hors-reseau/etat") return json(etat());
    const cle = chemin + url.search;
    if (reponses[cle] !== undefined) return json(cloner(reponses[cle]));
    if (reponses[chemin] !== undefined && !url.search) return json(cloner(reponses[chemin]));
    return json({ detail: "Pas disponible hors réseau : cette information s'affichera au retour du serveur." }, 503);
  }

  // Recherche globale (barre du haut) sur la copie : biens, logements, propriétaires, locataires, contrats
  function rechercher(q) {
    const mots = sansAccents(q).split(/\s+/).filter(Boolean);
    const chiffres = q.replace(/\D/g, "");
    const ok = (textes, tels = []) => mots.every(m => textes.some(t => sansAccents(t).includes(m)))
      || (chiffres.length >= 4 && tels.some(t => String(t || "").replace(/\D/g, "").includes(chiffres)));
    const groupes = [];
    const ajouter = (categorie, elements) => { if (elements.length) groupes.push({ categorie, total: elements.length, elements: elements.slice(0, 5) }); };
    const biens = reponses["/api/biens"] || [];
    ajouter("Biens", biens.filter(b => ok([b.nom, b.adresse])).map(b => ({ titre: b.nom, detail: b.adresse || "", cible: "biens", filtre: b.nom })));
    ajouter("Logements", biens.flatMap(b => b.logements.map(l => ({ b, l }))).filter(({ b, l }) => ok([`logement ${l.numero_logement}`, b.nom, l.type_logement]))
      .map(({ b, l }) => ({ titre: `Logement ${l.numero_logement} — ${b.nom}`, detail: `${l.type_logement} — ${l.statut_logement}`, cible: "biens", filtre: b.nom })));
    ajouter("Propriétaires", (reponses["/api/proprietaires"] || []).filter(p => ok([p.nom_complet, p.ville, p.cni], [p.telephone]))
      .map(p => ({ titre: p.nom_complet, detail: p.telephone || "", cible: "proprietaires", filtre: p.nom_complet })));
    ajouter("Locataires", (reponses["/api/locataires"] || []).filter(l => ok([l.nom_complet, l.cni, l.profession], [l.telephone]))
      .map(l => ({ titre: l.nom_complet, detail: l.telephone || "", cible: "locataires", filtre: l.nom_complet })));
    ajouter("Contrats", (reponses["/api/contrats"] || []).filter(c => ok([c.numero_contrat, c.locataire.nom_complet, c.logement.cite_nom], [c.locataire.telephone]))
      .map(c => ({ titre: `N° ${c.numero_contrat} — ${c.locataire.nom_complet}`, detail: `Logement ${c.logement.numero_logement}, ${c.logement.cite_nom}`, cible: "contrats", filtre: c.numero_contrat })));
    return { requete: q, groupes };
  }

  // ---------- Enregistrements ----------
  function ecrire(methode, url, corps) {
    const chemin = url.pathname;
    if (chemin === "/api/deconnexion") return json({ ok: true });
    const t = trouverAction(methode, chemin);
    if (!t) return pasHorsReseau("Cette action");
    const op = { uid: uid(), methode, chemin, corps: nettoyer(corps || {}), saisi_le: maintenant(),
      identifiant: copie.utilisateur.identifiant, id_local: nouvelId(), copie_du: copie.cree_le };
    if (t.action.preparer) t.action.preparer(op.corps, op);
    let reponse;
    try {
      if (t.action.titre) op.titre = String(t.action.titre(op, t.params) || "").split(EN_ATTENTE).join("");
      reponse = t.action.appliquer(cloner(op), t.params);
    } catch (e) {
      return json({ detail: e.message }, 409);
    }
    op.resume = t.action.resume(op);
    // une modification remplace complètement la précédente (même fiche) : on ne garde que la dernière
    if (methode === "PUT") file = file.filter(o => !(o.methode === "PUT" && o.chemin === chemin));
    file.push(op);
    enregistrerFile();
    if (t.action.apres) t.action.apres(op, reponse);
    return json(cloner(reponse));
  }

  window.fetch = async function (entree, init = {}) {
    const url = new URL(typeof entree === "string" ? entree : entree.url, location.href);
    if (url.origin !== location.origin || !url.pathname.startsWith("/api/")) return vraiFetch(entree, init);
    await pret;
    const methode = (init.method || (typeof entree === "string" ? "GET" : entree.method) || "GET").toUpperCase();
    if (methode === "GET") return lire(url);
    let corps = {};
    if (typeof init.body === "string") { try { corps = JSON.parse(init.body); } catch { corps = {}; } }
    else if (init.body) return pasHorsReseau("L'envoi de fichiers");
    return ecrire(methode, url, corps);
  };

  // ---------- Bandeau « Hors réseau » et liste des enregistrements en attente ----------
  function etat() {
    return { cree_le: copie.cree_le, en_attente: file.length };
  }

  function majBandeau() {
    const b = document.getElementById("bandeauHorsReseau");
    if (!b || !copie) return;
    b.querySelector(".hrl-date").textContent = `données du ${dateFr(copie.cree_le).slice(0, 5)} à ${copie.cree_le.slice(11, 16)}`;
    const n = b.querySelector(".hrl-attente");
    n.textContent = file.length ? `${file.length} en attente` : "rien en attente";
    n.classList.toggle("vide", !file.length);
  }

  function installerBandeau() {
    const style = document.createElement("style");
    style.textContent = `
      #bandeauHorsReseau{position:fixed;left:0;right:0;bottom:0;z-index:25;display:flex;align-items:center;gap:.6rem;
        background:#c1552d;color:#fff;font-size:.8rem;line-height:1.3;padding:.5rem calc(.9rem + var(--droite,0px)) calc(.5rem + var(--bas,0px)) calc(.9rem + var(--gauche,0px));
        box-shadow:0 -6px 18px -10px rgba(0,0,0,.4)}
      #bandeauHorsReseau b{font-weight:700}
      #bandeauHorsReseau .hrl-txt{flex:1;min-width:0}
      @media (max-width:640px){#bandeauHorsReseau{flex-wrap:nowrap;gap:.4rem}#bandeauHorsReseau .hrl-suite{display:none}
        #bandeauHorsReseau button{padding:.3rem .5rem;white-space:nowrap}}
      #bandeauHorsReseau button{border:1.5px solid rgba(255,255,255,.8);background:transparent;color:#fff;border-radius:8px;padding:.3rem .65rem;
        font:inherit;font-weight:600;font-size:.76rem;cursor:pointer}
      #bandeauHorsReseau .hrl-attente{background:#fff;color:#c1552d;border-color:#fff}
      #bandeauHorsReseau .hrl-attente.vide{background:transparent;color:#fff}
      body.app{padding-bottom:calc(52px + var(--bas,0px))}
      .fab-assistant{bottom:calc(70px + var(--bas,0px)) !important}
      /* écran étroit : la barre d'icônes de Gérimo est en bas ; le bandeau se pose juste au-dessus */
      @media (max-width:760px){#bandeauHorsReseau{bottom:calc(58px + var(--bas,0px));padding-bottom:.5rem}
        body.app{padding-bottom:calc(110px + var(--bas,0px))}.fab-assistant{bottom:calc(128px + var(--bas,0px)) !important}}
      #fileHorsReseau{position:fixed;inset:0;z-index:80;background:rgba(16,28,38,.45);display:flex;align-items:flex-end;justify-content:center}
      #fileHorsReseau .fhr{background:#fff;width:100%;max-width:560px;max-height:85vh;overflow-y:auto;border-radius:18px 18px 0 0;
        padding:1.1rem 1.1rem calc(1.2rem + var(--bas,0px))}
      @media (min-width:640px){#fileHorsReseau{align-items:center}#fileHorsReseau .fhr{border-radius:18px}}
      #fileHorsReseau h3{margin:0 0 .3rem;color:#1d3b53;font-size:1.02rem}
      #fileHorsReseau .fhr-op{display:flex;gap:.6rem;align-items:center;justify-content:space-between;padding:.6rem 0;border-bottom:1px solid #e2e6df;font-size:.84rem}
      #fileHorsReseau .fhr-op small{display:block;color:#5c655e;font-size:.74rem;margin-top:.1rem}`;
    document.head.appendChild(style);
    const b = document.createElement("div");
    b.id = "bandeauHorsReseau";
    b.setAttribute("role", "status");
    b.innerHTML = `<span class="hrl-txt"><b>Hors réseau</b> · <span class="hrl-date"></span><span class="hrl-suite"> · vos enregistrements partiront au retour du serveur</span></span>
      <button type="button" class="hrl-attente"></button><button type="button" class="hrl-reessayer">Réessayer<span class="hrl-suite"> le serveur</span></button>`;
    document.body.appendChild(b);
    b.querySelector(".hrl-attente").addEventListener("click", ouvrirFile);
    b.querySelector(".hrl-reessayer").addEventListener("click", () => { if (PONT) PONT.reessayer(); else location.href = "/app"; });
    majBandeau();
  }

  function ouvrirFile() {
    let fond = document.getElementById("fileHorsReseau");
    if (!fond) {
      fond = document.createElement("div");
      fond.id = "fileHorsReseau";
      fond.addEventListener("click", e => { if (e.target === fond) fond.remove(); });
      document.body.appendChild(fond);
    }
    const echap = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    fond.innerHTML = `<div class="fhr" role="dialog" aria-modal="true"><h3>Enregistrements en attente (${file.length})</h3>
      <p class="petit" style="margin:0 0 .5rem">Ils partiront tout seuls au retour du serveur, qui les vérifiera. Tant qu'ils ne sont pas partis, vous pouvez en annuler un.</p>
      ${file.map((op, i) => `<div class="fhr-op"><div>${echap(op.resume)}<small>${dateFr(op.saisi_le)} à ${op.saisi_le.slice(11, 16)}</small></div>
        <button type="button" class="btn-sm del" data-i="${i}">Annuler</button></div>`).join("") || '<p class="petit">Rien en attente.</p>'}
      <div style="text-align:right;margin-top:.8rem"><button type="button" class="btn-sm" id="fhrFermer">Fermer</button></div></div>`;
    fond.querySelector("#fhrFermer").addEventListener("click", () => fond.remove());
    fond.querySelectorAll("[data-i]").forEach(bouton => bouton.addEventListener("click", () => {
      const op = file[+bouton.dataset.i];
      const dependants = file.filter(o => o !== op && op.id_local && (o.chemin.includes(`/${op.id_local}`) || JSON.stringify(o.corps).includes(`:${op.id_local}`)));
      const message = dependants.length ? `Annuler « ${op.resume} » et ${dependants.length} enregistrement(s) qui en dépendent ?` : `Annuler « ${op.resume} » ?`;
      if (!confirm(message)) return;
      file = file.filter(o => o !== op && !dependants.includes(o));
      enregistrerFile();
      ecriture.then(() => location.reload());  // les écrans repartent de la copie + ce qui reste en attente
    }));
  }

  // Le téléphone a retrouvé le serveur : on s'y reconnecte dès qu'aucun formulaire n'est ouvert (rien n'est perdu :
  // la file d'attente part à la reconnexion)
  window.serveurRevenu = function () {
    const b = document.getElementById("bandeauHorsReseau");
    if (b) b.querySelector(".hrl-txt").innerHTML = "<b>Le serveur est de retour</b> · reconnexion dès que vous aurez fermé le formulaire en cours";
    const essayer = () => {
      if (document.querySelector(".modal-overlay.show, #fileHorsReseau")) { setTimeout(essayer, 2000); return; }
      ecriture.then(() => { if (PONT && PONT.seReconnecter) PONT.seReconnecter(); else location.href = "/app"; });
    };
    essayer();
  };

  const pret = (async () => {
    if (PONT) {
      const texte = await PONT.copieOuverte();
      if (!texte) { location.replace(ANDROID ? "/connexion" : "/static/hors_reseau/index.html"); throw new Error("Copie fermée"); }
      copie = JSON.parse(texte);
    } else {
      const rep = await vraiFetch("/api/hors-reseau/copie");
      if (!rep.ok) { location.replace("/connexion"); throw new Error("Pas de copie"); }
      copie = await rep.json();
    }
    const toutes = await lireFile();
    file = toutes.filter(op => op.identifiant === copie.utilisateur.identifiant);
    autres = toutes.filter(op => op.identifiant !== copie.utilisateur.identifiant);
    reconstruire();
  })();
  window.horsReseauPret = pret;
  document.addEventListener("DOMContentLoaded", () => { pret.then(installerBandeau).catch(() => {}); });

  // Navigateur : personne ne guette le serveur à sa place (l'appli Android le fait) ; on essaie toutes les 30 s
  if (!ANDROID && !APERCU) {
    const guetter = async () => {
      try {
        const r = await vraiFetch("/api/entreprise", { cache: "no-store" });
        if (r.ok) { window.serveurRevenu(); return; }
      } catch { /* toujours injoignable */ }
      setTimeout(guetter, 30000);
    };
    setTimeout(guetter, 30000);
  }
})();
