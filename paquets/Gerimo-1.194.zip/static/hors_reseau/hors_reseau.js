// Page d'entrée « hors réseau » (hors_reseau.py) : affichée par l'application Android quand le serveur est
// injoignable. Avec le mot de passe de l'utilisateur, le téléphone ouvre sa copie (chiffrée) puis les écrans
// habituels de Gérimo (/app, servis par le téléphone, avec local.js).
// Fonctions du téléphone (window.ISUPAndroid) ou du navigateur (window.GerimoPont, pont_web.js : iPhone, PC
// portable en connexion sécurisée) : etatHorsReseau, ouvrirCopie, reessayer, changerServeur.
// Sans l'un ni l'autre (aperçu, tests), elle mène aux écrans hors réseau nourris directement par le serveur.

const ANDROID = window.ISUPAndroid && window.ISUPAndroid.ouvrirCopie ? window.ISUPAndroid : null;
const PONT = ANDROID || window.GerimoPont || null;
const el = id => document.getElementById(id);

function esc(valeur) {
  return String(valeur ?? "").replace(/[&<>"']/g, c =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
// « 2026-10-08T14:32:05 » → « 08/10/2026 à 14:32 »
function dateFr(iso) {
  if (!iso) return "";
  const [a, m, j] = iso.slice(0, 10).split("-");
  return `${j}/${m}/${a}` + (iso.length > 10 ? ` à ${iso.slice(11, 16)}` : "");
}

async function etatTelephone() {
  if (!PONT) return { copie: true, apercu: true };
  try { return JSON.parse(await PONT.etatHorsReseau()); } catch { return { copie: false }; }
}

async function afficherAccueil() {
  const e = await etatTelephone();
  if (e.entreprise) el("nomEntreprise").textContent = e.entreprise;
  const zone = el("zoneMotDePasse");
  let texte, ouvrable = false;
  if (e.apercu) {
    texte = "Aperçu dans un navigateur : les écrans hors réseau seront nourris par la copie lue sur le serveur.";
    ouvrable = true;
  } else if (!e.copie) {
    texte = `Aucune copie des données n'est enregistrée sur ${ANDROID ? "ce téléphone" : "cet appareil"}. Connectez-vous une fois `
      + "au serveur du bureau : Gérimo gardera alors de quoi travailler hors réseau.";
  } else if (e.expiree) {
    texte = `La copie de <b>${esc(e.nom)}</b> date du ${dateFr(e.cree_le)} : elle n'est plus utilisable (plus de `
      + `${e.jours} jours sans retour au réseau du bureau). Reconnectez-vous au serveur pour la renouveler.`;
  } else if (!e.mot_de_passe_connu) {
    texte = `Une copie de <b>${esc(e.nom)}</b> existe, mais votre mot de passe n'est pas encore connu de ce téléphone : `
      + "reconnectez-vous une fois au serveur avec l'écran de connexion.";
  } else {
    texte = `Continuez à travailler comme d'habitude avec les données de <b>${esc(e.nom)}</b> (profil ${esc(e.role)}) `
      + `du <b>${dateFr(e.cree_le)}</b>. Vos enregistrements seront gardés sur le téléphone et envoyés au serveur dès `
      + "son retour.";
    if (e.en_attente) texte += `<br><b>${e.en_attente} enregistrement(s)</b> attendent déjà d'être envoyés.`;
    ouvrable = true;
  }
  el("texteCopie").innerHTML = texte;
  el("zoneMotDePasse").hidden = !ouvrable;
  if (ouvrable) setTimeout(() => el("motDePasse").focus(), 300);
}

function afficherErreur(message) {
  el("erreur").textContent = message;
  el("erreur").style.display = message ? "block" : "none";
}

el("carteHorsReseau").addEventListener("submit", async e => {
  e.preventDefault();
  afficherErreur("");
  if (!PONT) { location.replace("/api/hors-reseau/app?apercu=1"); return; }
  const bouton = el("btnContinuer");
  bouton.disabled = true;
  try {
    const reponse = JSON.parse(await PONT.ouvrirCopie(el("motDePasse").value));
    if (reponse.erreur) throw new Error(reponse.erreur);
    el("motDePasse").value = "";
    location.replace(ANDROID ? "/app" : "/api/hors-reseau/app");
  } catch (err) {
    afficherErreur(err.message || "Impossible d'ouvrir la copie.");
    el("motDePasse").select();
    bouton.disabled = false;
  }
});

el("btnReessayer").addEventListener("click", () => { if (PONT) PONT.reessayer(); else location.href = "/app"; });
el("btnAdresse").addEventListener("click", () => { if (ANDROID) ANDROID.changerServeur(); });
if (!ANDROID) el("btnAdresse").hidden = true;

// Le téléphone signale où en est sa recherche du serveur (toutes les 30 secondes)
window.etatServeur = message => { el("etatRecherche").textContent = message; };

// Navigateur : on guette nous-mêmes le retour du serveur
if (!ANDROID) {
  const guetter = async () => {
    try {
      if ((await fetch("/api/entreprise", { cache: "no-store" })).ok) { location.href = "/app"; return; }
    } catch { /* toujours injoignable */ }
    const h = new Date();
    window.etatServeur(`Dernier essai à ${String(h.getHours()).padStart(2, "0")}:${String(h.getMinutes()).padStart(2, "0")} : pas de réponse. Gérimo réessaie tout seul toutes les 30 secondes.`);
    setTimeout(guetter, 30000);
  };
  if (PONT) setTimeout(guetter, 30000);
}

afficherAccueil();
