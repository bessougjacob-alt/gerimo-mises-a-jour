// Réseaux sociaux : comptes d'ISUP, annonce rédigée automatiquement à partir des logements libres,
// publication (groupe / page Facebook, WhatsApp), invitation des locataires au groupe.
// Facebook n'autorise plus les logiciels à publier seuls dans un groupe (depuis 2024) :
// le texte est copié, les photos téléchargées, et le groupe s'ouvre — il reste à coller et publier.

let reseaux = null;
let photosAnnonceListe = [];

async function chargerReseaux() {
  try { reseaux = await api("/api/reseaux"); }
  catch (e) { el("reseauxComptes").innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  const c = reseaux.comptes;
  const carte = (icone, titre, texte, lien, couleur) => `<button class="choix" onclick="${lien ? `window.open('${esc(lien)}', '_blank')` : `ouvrirModule('parametres')`}">
      <div class="choix-icone" style="background:${couleur}22">${icone}</div>
      <div><b>${esc(titre)}</b><span>${lien ? esc(texte) : "Lien à renseigner dans Paramètres (Admin)"}</span></div></button>`;
  const fb = '<svg viewBox="0 0 24 24" style="fill:#1877f2;stroke:none"><path d="M24 12.07C24 5.4 18.63 0 12 0S0 5.4 0 12.07C0 18.1 4.39 23.1 10.13 24v-8.44H7.08v-3.49h3.05V9.41c0-3.02 1.79-4.69 4.53-4.69 1.31 0 2.68.24 2.68.24v2.97h-1.51c-1.49 0-1.96.93-1.96 1.89v2.25h3.33l-.53 3.49h-2.8V24C19.61 23.1 24 18.1 24 12.07Z"/></svg>';
  const wa = `<svg viewBox="0 0 24 24" style="fill:#25d366;stroke:none">${ICONES.whatsapp}</svg>`;
  el("reseauxComptes").innerHTML =
    carte(fb, `Groupe Facebook « ${c.facebook_groupe_nom} »`, "Ouvrir le groupe", c.facebook_groupe_url, "#1877f2") +
    carte(fb, "Page Facebook de l'entreprise", "Ouvrir la page", c.facebook_page_url, "#1877f2") +
    carte(wa, `WhatsApp — ${c.whatsapp_numero}`, "Compte WhatsApp de l'entreprise", c.whatsapp_numero ? `https://wa.me/${chiffresTel(c.whatsapp_numero).replace(/^(\d{10})$/, "225$1")}` : "", "#25d366") +
    carte(wa, "Groupe WhatsApp", "Lien d'invitation au groupe", c.whatsapp_groupe_lien, "#25d366");
  el("reseauxLogements").innerHTML = reseaux.logements_libres.map(l =>
    `<label><input type="checkbox" value="${l.id}"> ${esc(l.logement)} — ${esc(l.type_logement)} — ${formatMontant(l.loyer)}</label>`).join("")
    || '<span class="petit">Aucun logement libre en ce moment : rédigez une information libre ci-dessous.</span>';
  remplirSelect(el("inviteLocataire"), reseaux.locataires, {
    valeur: l => l.id, texte: l => `${l.nom_complet}${l.telephone ? " — " + l.telephone : " (pas de numéro)"}`, vide: "— Choisir le locataire —" });
  el("reseauxHistorique").innerHTML = reseaux.publications.map(p => `<div class="row"><span class="who"><b>${esc(p.titre)}</b>
      <br><span class="petit">${esc(p.canal)} — ${esc(p.date)} — ${esc(p.auteur)}</span></span>
      <span class="boutons">${ibtn("voir", "Reprendre ce texte", `reprendreAnnonce(${p.id})`)}</span></div>`).join("")
    || '<div class="vide">Aucune publication pour l\'instant.</div>';
  el("reseauxExplication").textContent = "Facebook ne permet plus à un logiciel de publier seul dans un groupe : le texte est copié et les photos " +
    "téléchargées, puis le groupe s'ouvre. Cliquez dans « Exprimez-vous », collez (Ctrl + V), ajoutez les photos, puis « Publier ».";
}
CHARGEURS.reseaux_sociaux = chargerReseaux;

async function redigerAnnonce() {
  const ids = [...el("reseauxLogements").querySelectorAll("input:checked")].map(c => Number(c.value));
  if (!ids.length) { toast("Cochez un ou plusieurs logements libres."); return; }
  try {
    const a = await api("/api/reseaux/annonce", { method: "POST", body: { logement_ids: ids } });
    el("annonceTitre").value = a.titre;
    el("annonceTexte").value = a.texte;
    toast("Annonce rédigée : relisez-la et ajoutez des photos.");
  } catch (e) { toast(e.message); }
}

function reprendreAnnonce(id) {
  const p = reseaux.publications.find(x => x.id === id);
  if (!p) return;
  el("annonceTitre").value = p.titre;
  el("annonceTexte").value = p.texte;
  el("annonceTexte").scrollIntoView({ behavior: "smooth", block: "center" });
}

async function photosAnnonce(source) {
  const fichiers = source === "photo" ? [await prendrePhoto()].filter(Boolean) : await choisirFichiers({ pdf: false });
  photosAnnonceListe.push(...fichiers);
  afficherPhotosAnnonce();
}
function afficherPhotosAnnonce() {
  el("annoncePhotos").innerHTML = photosAnnonceListe.map((p, i) => `<div class="pj"><img src="${p.apercu}" alt="">
    <button type="button" class="pj-suppr" onclick="photosAnnonceListe.splice(${i}, 1); afficherPhotosAnnonce()">✕</button><div class="pj-nom">Photo ${i + 1}</div></div>`).join("");
}

async function copierAnnonce(silencieux = false) {
  const texte = el("annonceTexte").value.trim();
  if (!texte) { toast("Rédigez d'abord l'annonce."); return false; }
  try { await navigator.clipboard.writeText(texte); }
  catch {   // ancien navigateur : sélection + copie
    el("annonceTexte").select();
    document.execCommand("copy");
  }
  if (!silencieux) toast("Texte copié : collez-le avec Ctrl + V.");
  return true;
}

async function publier(canal) {
  const texte = el("annonceTexte").value.trim();
  const titre = el("annonceTitre").value.trim() || texte.split("\n")[0].slice(0, 120);
  if (!texte) { toast("Rédigez d'abord l'annonce."); return; }
  const c = reseaux.comptes;
  let lien = "";
  if (canal === "Groupe Facebook") lien = c.facebook_groupe_url;
  else if (canal === "Page Facebook") lien = c.facebook_page_url;
  if (canal.includes("Facebook") && !lien) { toast("Le lien Facebook n'est pas encore renseigné (Paramètres, Admin)."); return; }

  // Photos : partage natif avec le texte (tablette / téléphone), sinon téléchargement pour glisser-déposer
  const fichiers = photosAnnonceListe.map((p, i) => {
    const binaire = atob(p.contenu.split(",")[1]);
    const octets = new Uint8Array(binaire.length);
    for (let k = 0; k < binaire.length; k++) octets[k] = binaire.charCodeAt(k);
    return new File([octets], `annonce_${i + 1}.jpg`, { type: "image/jpeg" });
  });
  if (canal === "Statut WhatsApp" && fichiers.length && navigator.canShare?.({ files: fichiers })) {
    try { await navigator.share({ files: fichiers, text: texte }); } catch { /* annulé */ }
  } else {
    await copierAnnonce(true);
    fichiers.forEach(f => telechargerBlob(f, f.name));
    if (canal === "Statut WhatsApp") window.open(`https://wa.me/?text=${encodeURIComponent(texte)}`, "_blank");
    else window.open(lien, "_blank");
    toast(canal.includes("Facebook")
      ? `Texte copié${fichiers.length ? " et photos téléchargées" : ""} : dans Facebook, cliquez « Exprimez-vous », collez (Ctrl + V)${fichiers.length ? ", ajoutez les photos" : ""} puis « Publier ».`
      : "WhatsApp ouvert avec le texte : choisissez le contact, le groupe ou votre statut.", 9000);
  }
  try { await api("/api/reseaux/publications", { method: "POST", body: { titre, texte, canal } }); chargerReseaux(); } catch { /* historique seulement */ }
}

async function inviterLocataire() {
  const l = reseaux.locataires.find(x => String(x.id) === el("inviteLocataire").value);
  if (!l) { toast("Choisissez le locataire."); return; }
  if (!l.telephone) { toast("Ce locataire n'a pas de numéro de téléphone."); return; }
  const c = reseaux.comptes;
  const facebook = el("inviteGroupe").value === "facebook";
  const lien = facebook ? c.facebook_groupe_url : c.whatsapp_groupe_lien;
  if (!lien) { toast("Le lien du groupe n'est pas encore renseigné (Paramètres, Admin)."); return; }
  const texte = facebook
    ? `Bonjour ${l.nom_complet}, ici ${nomEntreprise()}. Rejoignez notre groupe Facebook « ${c.facebook_groupe_nom} » pour suivre nos annonces et informations : ${lien}`
    : `Bonjour ${l.nom_complet}, ici ${nomEntreprise()}. Rejoignez le groupe WhatsApp de nos locataires pour recevoir les informations importantes (travaux, coupures, annonces) : ${lien}`;
  ouvrirWhatsAppTexte(l.telephone, texte);
}
