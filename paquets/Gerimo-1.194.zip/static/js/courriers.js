// Actions / courriers : révision de loyer et avenant au bail, envoyés par e-mail ou WhatsApp.

let courriersCache = [];
let optionsCourriers = null;

// Texte proposé pour chaque objet d'avenant (modifiable avant l'enregistrement)
const MODELES_AVENANT = {
  "Prolongation de la durée du bail": "Les parties conviennent de prolonger la durée du contrat de bail. Le bail se poursuivra aux mêmes charges et conditions jusqu'à la nouvelle date de fin indiquée ci-dessous.",
  "Ajout ou retrait d'un occupant": "Les parties conviennent que [NOM ET PRÉNOMS], titulaire de la CNI N° [NUMÉRO], est autorisé(e) à occuper le logement avec le Locataire, qui demeure seul responsable du paiement du loyer et de l'exécution du bail.",
  "Changement d'usage du local": "Les parties conviennent que le local, initialement loué à usage de [ANCIEN USAGE], sera désormais utilisé à usage de [NOUVEL USAGE]. Le Locataire s'engage à respecter la réglementation applicable à cette activité.",
  "Modalités de paiement": "Les parties conviennent que le loyer sera désormais payé [au début / à la fin] de chaque mois, au plus tard le 05, par [espèces / Mobile Money / virement / chèque].",
  "Travaux ou aménagements autorisés": "Le Bailleur autorise le Locataire à réaliser à ses frais les travaux suivants : [DESCRIPTION]. Ces aménagements resteront acquis au logement à la fin du bail, sans indemnité, sauf accord écrit contraire.",
  "Autre modification": "Les parties conviennent de modifier le contrat de bail comme suit : [DÉCRIRE LA MODIFICATION].",
};

async function chargerCourriers() {
  const zone = el("listeCourriers");
  try { courriersCache = await api("/api/courriers"); }
  catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  if (!courriersCache.length) {
    zone.innerHTML = '<div class="card vide">Aucun courrier pour l\'instant. Choisissez une action ci-dessus.</div>';
    return;
  }
  zone.innerHTML = `<div class="card"><h3>Courriers envoyés ou préparés</h3>${courriersCache.map(k => {
    const envoi = k.envois.length ? `<span class="envoye">Envoyé (${esc(k.envois.at(-1).canal)}) le ${esc(k.envois.at(-1).date)}</span>` : '<span class="pill warn">À envoyer</span>';
    return `<div class="row"${motsCles({ tel: [k.telephone], textes: [k.numero_contrat] })}>
      <span class="who">N° ${esc(k.numero)} — <b>${esc(k.locataire)}</b> — ${esc(k.type_courrier)}
        <br><span class="petit">${esc(k.objet || "")} — ${esc(k.logement)} — du ${formatDate(k.date_courrier)}${k.date_effet ? ", effet le " + formatDate(k.date_effet) : ""} — ${envoi}</span></span>
      <span class="boutons">
        ${ibtn("pdf", "Voir / imprimer le courrier (PDF)", `window.open('/api/courriers/${k.id}/pdf', '_blank')`)}
        ${ibtn("partager", "Envoyer au locataire (e-mail ou WhatsApp)", `envoyerCourrier(${k.id})`, { classe: "wa" })}
        ${estAdmin() && k.type_courrier !== "Révision de loyer" ? ibtn("supprimer", "Supprimer (Admin)", `supprimerCourrier(${k.id})`) : ""}
      </span></div>`;
  }).join("")}</div>`;
  el("rechercheCourriers").dispatchEvent(new Event("input"));
}
CHARGEURS.courriers = chargerCourriers;
brancherRecherche(el("rechercheCourriers"), el("listeCourriers"));

async function chargerOptionsCourriers() {
  optionsCourriers = await api("/api/courriers/options");
  return optionsCourriers;
}

function remplirContrats(select, contratId) {
  remplirSelect(select, optionsCourriers.contrats, {
    valeur: c => c.id, texte: c => `${c.locataire} — ${c.logement} — ${formatMontant(c.montant_loyer)}/mois (N° ${c.numero_contrat})`,
    vide: optionsCourriers.contrats.length ? "— Choisir le contrat —" : "Aucun contrat en cours",
  });
  select.value = contratId ?? "";
}

// ---------- Révision de loyer ----------
function premierDuMoisSuivant() {
  const d = new Date();
  return `${d.getMonth() === 11 ? d.getFullYear() + 1 : d.getFullYear()}-${String((d.getMonth() + 1) % 12 + 1).padStart(2, "0")}-01`;
}

async function nouvelleRevision(contratId = null) {
  try { await chargerOptionsCourriers(); } catch (e) { toast(e.message); return; }
  remplirContrats(el("revContrat"), contratId);
  el("revLoyer").value = "";
  el("revMotif").value = "";
  fixerDate("revEffet", premierDuMoisSuivant());
  await afficher("formRevision");
  majRecapRevision();
}

function majRecapRevision() {
  const c = optionsCourriers?.contrats.find(x => String(x.id) === el("revContrat").value);
  const nouveau = lireMontant(el("revLoyer").value);
  const zone = el("revRecap");
  if (!c) { zone.innerHTML = "Choisissez le contrat."; return; }
  let html = `Loyer actuel : <b>${formatMontant(c.montant_loyer)}</b>`;
  if (c.derniere_revision) html += ` — dernière révision le ${formatDate(c.derniere_revision)}`;
  if (nouveau) {
    const ecart = nouveau - c.montant_loyer;
    const pct = (ecart / c.montant_loyer * 100).toFixed(1).replace(".", ",");
    html += `<br>Nouveau loyer : <b>${formatMontant(nouveau)}</b> (${ecart >= 0 ? "+" : ""}${formatMontant(ecart)}, ${ecart >= 0 ? "+" : ""}${pct} %)`;
    if (Math.abs(ecart / c.montant_loyer) > 0.2) html += '<br><span style="color:var(--warn)">Hausse ou baisse importante (plus de 20 %) : prévoyez d\'en discuter avec le locataire.</span>';
  }
  const effet = isoDepuisTexte(el("revEffet").value);
  if (effet) {
    const jours = Math.round((new Date(effet) - new Date(aujourdhui())) / 86400000);
    if (jours < 30) html += '<br><span style="color:var(--warn)">Conseil : prévenez le locataire au moins un mois avant la date d\'effet.</span>';
  }
  html += "<br>Les mois déjà réglés ne changent pas ; les mois suivants seront recalculés automatiquement.";
  zone.innerHTML = html;
}
["revContrat", "revLoyer", "revEffet"].forEach(id => { el(id).addEventListener("input", majRecapRevision); el(id).addEventListener("change", majRecapRevision); });

el("formulaireRevision").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (!el("revContrat").value) throw new Error("Choisissez le contrat.");
    const loyer = lireMontant(el("revLoyer").value);
    if (!loyer) throw new Error("Indiquez le nouveau loyer (ex : 80 000).");
    const effet = valeurDate("revEffet", "Date d'effet");
    if (!effet) throw new Error("Indiquez la date d'effet (jj/mm/aaaa).");
    const c = optionsCourriers.contrats.find(x => String(x.id) === el("revContrat").value);
    if (!confirm(`Confirmer : le loyer de ${c.locataire} passe de ${formatMontant(c.montant_loyer)} à ${formatMontant(loyer)} à compter du ${formatDate(effet.slice(0, 8) + "01")} ?`)) return;
    const rep = await api("/api/courriers/revision", { method: "POST", body: {
      contrat_id: c.id, nouveau_loyer: loyer, date_effet: effet, motif: el("revMotif").value } });
    toast(`Révision N° ${rep.numero} enregistrée : envoyez maintenant le courrier.`, 5000);
    await afficher("courriers");
    envoyerCourrier(rep.id);
  });
});

// ---------- Avenant ----------
async function nouvelAvenant(contratId = null) {
  try { await chargerOptionsCourriers(); } catch (e) { toast(e.message); return; }
  remplirContrats(el("aveContrat"), contratId);
  remplirSelect(el("aveObjet"), optionsCourriers.objets_avenant);
  fixerDate("aveEffet", aujourdhui());
  fixerDate("aveFin", null);
  el("aveClauses").value = MODELES_AVENANT[el("aveObjet").value] || "";
  await afficher("formAvenant");
  majAvenant();
}

function majAvenant() {
  const prolongation = el("aveObjet").value === "Prolongation de la durée du bail";
  el("champAveFin").style.display = prolongation ? "" : "none";
  const c = optionsCourriers?.contrats.find(x => String(x.id) === el("aveContrat").value);
  if (prolongation && c && !el("aveFin").value) {
    const base = c.date_fin ? new Date(c.date_fin) : new Date();
    base.setFullYear(base.getFullYear() + 1);
    fixerDate("aveFin", `${base.getFullYear()}-${String(base.getMonth() + 1).padStart(2, "0")}-${String(base.getDate()).padStart(2, "0")}`);
  }
}
el("aveObjet").addEventListener("change", () => {
  const texte = el("aveClauses").value.trim();
  if (!texte || Object.values(MODELES_AVENANT).includes(texte)) el("aveClauses").value = MODELES_AVENANT[el("aveObjet").value] || "";
  majAvenant();
});
el("aveContrat").addEventListener("change", majAvenant);

el("formulaireAvenant").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (!el("aveContrat").value) throw new Error("Choisissez le contrat.");
    const clauses = el("aveClauses").value.trim();
    if (clauses.length < 10) throw new Error("Rédigez les clauses de l'avenant.");
    if (/\[[^\]]+\]/.test(clauses)) throw new Error("Complétez les passages entre crochets [ ] dans les clauses.");
    const prolongation = el("aveObjet").value === "Prolongation de la durée du bail";
    const fin = prolongation ? valeurDate("aveFin", "Nouvelle date de fin") : null;
    if (prolongation && !fin) throw new Error("Indiquez la nouvelle date de fin du bail.");
    const rep = await api("/api/courriers/avenant", { method: "POST", body: {
      contrat_id: Number(el("aveContrat").value), objet: el("aveObjet").value, clauses,
      date_effet: valeurDate("aveEffet", "Date d'effet"), nouvelle_date_fin: fin } });
    toast(`Avenant N° ${rep.numero} enregistré : imprimez-le pour signature et envoyez-le.`, 5000);
    await afficher("courriers");
    envoyerCourrier(rep.id);
  });
});

// ---------- Envoi ----------
async function envoyerCourrier(id) {
  if (!courriersCache.some(k => k.id === id)) await chargerCourriers();
  const k = courriersCache.find(x => x.id === id);
  if (!k) return;
  envoyerDocument({
    titre: `Envoyer le courrier N° ${k.numero} (${k.type_courrier.toLowerCase()})`, nom: k.locataire,
    email: k.email || "", telephone: k.telephone || "", urlPdf: `/api/courriers/${id}/pdf`,
    urlEmail: `/api/courriers/${id}/envoyer-email`, urlWhatsApp: `/api/courriers/${id}/whatsapp`, apres: chargerCourriers,
  });
}

function supprimerCourrier(id) {
  const k = courriersCache.find(x => x.id === id);
  supprimerAvecConfirmation(`Supprimer le courrier N° ${k ? k.numero : ""} ? Entrez votre mot de passe Admin.`,
    `/api/courriers/${id}/supprimer`, chargerCourriers);
}
