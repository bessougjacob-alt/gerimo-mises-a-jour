// Dictionnaire intégré de la saisie intelligente.
// Complété au démarrage par les mots déjà saisis dans le logiciel (/api/vocabulaire).
// Pour ajouter un mot : l'ajouter dans la bonne liste ci-dessous.

const VOCABULAIRE = {
  villes: [
    "Abengourou", "Abidjan", "Aboisso", "Adiaké", "Adzopé", "Agboville", "Agnibilékrou", "Akoupé", "Alépé",
    "Anyama", "Arrah", "Bangolo", "Béoumi", "Bettié", "Biankouma", "Bingerville", "Bocanda", "Bondoukou",
    "Bongouanou", "Bouaflé", "Bouaké", "Bouna", "Boundiali", "Dabou", "Daloa", "Danané", "Daoukro",
    "Dimbokro", "Divo", "Duékoué", "Ferkessédougou", "Gagnoa", "Grand-Bassam", "Grand-Lahou", "Guiglo",
    "Issia", "Jacqueville", "Katiola", "Korhogo", "Koun-Fao", "Lakota", "M'Bahiakro", "Man", "Mankono",
    "Niablé", "Odienné", "Oumé", "Sakassou", "San-Pédro", "Sassandra", "Séguéla", "Sinfra", "Songon",
    "Soubré", "Tabou", "Tanda", "Tiassalé", "Touba", "Toulepleu", "Toumodi", "Transua", "Vavoua",
    "Yakassé-Attobrou", "Yamoussoukro", "Zuénoula",
  ],
  // Quartiers : seuls ceux connus avec certitude ; les adresses saisies s'ajoutent automatiquement
  adresses: [
    "Agnikro", "Agnikro Résidentiel",
  ],
  professions: [
    "Agent commercial", "Agent de banque", "Agent de sécurité", "Agent immobilier", "Agriculteur", "Agricultrice",
    "Architecte", "Artisan", "Avocat", "Avocate", "Boulanger", "Boutiquier", "Caissier", "Caissière",
    "Chauffeur", "Coiffeur", "Coiffeuse", "Commerçant", "Commerçante", "Comptable", "Couturier", "Couturière",
    "Cuisinier", "Cuisinière", "Électricien", "Employé de bureau", "Enseignant", "Enseignante", "Entrepreneur",
    "Étudiant", "Étudiante", "Fonctionnaire", "Gendarme", "Gérant", "Gérante", "Infirmier", "Infirmière",
    "Informaticien", "Ingénieur", "Instituteur", "Institutrice", "Journaliste", "Maçon", "Magistrat",
    "Mécanicien", "Médecin", "Menuisier", "Militaire", "Pasteur", "Peintre", "Pharmacien", "Pharmacienne",
    "Planteur", "Plombier", "Policier", "Professeur", "Restaurateur", "Restauratrice", "Retraité", "Retraitée",
    "Sage-femme", "Secrétaire", "Soudeur", "Technicien", "Transporteur", "Vendeur", "Vendeuse",
  ],
  // Documents fonciers usuels en Côte d'Ivoire
  documents: [
    "ACD (Arrêté de concession définitive)", "Arrêté de concession provisoire", "Attestation villageoise",
    "Certificat foncier", "Lettre d'attribution", "Titre foncier", "Plan de bornage", "Extrait topographique",
    "Attestation de cession", "Convention de vente", "Reçu d'achat",
  ],
  motifs_resiliation: [
    "Départ du locataire", "Fin de bail", "Impayés répétés", "Non-respect du contrat",
    "Reprise du logement par le propriétaire", "Vente du bien", "Travaux de rénovation",
    "Accord à l'amiable", "Sous-location non autorisée", "Décès du locataire",
  ],
  motifs_annulation: [
    "Erreur de saisie", "Mauvais contrat sélectionné", "Mode de paiement erroné", "Paiement en double",
    "Chèque sans provision", "Date erronée",
  ],
  motifs_depense: [
    "Réparation plomberie", "Réparation électricité", "Réparation toiture", "Peinture façade",
    "Peinture intérieure", "Remplacement serrure", "Remplacement porte", "Vidange fosse septique",
    "Débroussaillage", "Désinsectisation", "Facture CIE (électricité)", "Facture SODECI (eau)",
    "Salaire gardien", "Nettoyage des parties communes", "Impôt foncier",
  ],
  observations: [
    "Payé par un proche du locataire", "Payé par l'employeur", "Paiement reçu à l'agence",
    "Transfert Orange Money", "Transfert MTN MoMo", "Transfert Moov Money", "Transfert Wave",
    "Chèque à encaisser", "Virement bancaire reçu",
  ],
};

// Fautes de frappe fréquentes → correction proposée (soulignées en rouge)
const CORRECTIONS = {
  apartement: "appartement", appartemment: "appartement", appartment: "appartement",
  batiment: "bâtiment", batiments: "bâtiments", proprietaire: "propriétaire",
  locatiare: "locataire", locatair: "locataire", lcoataire: "locataire", reparation: "réparation",
  reparations: "réparations", electricite: "électricité", eletricité: "électricité",
  plomberi: "plomberie", peinure: "peinture", parcele: "parcelle", parcell: "parcelle",
  residence: "résidence", résidance: "résidence", quartie: "quartier", quarier: "quartier",
  ilot: "îlot", lotissment: "lotissement", lotisement: "lotissement",
  citee: "cité", magazin: "magasin", studion: "studio",
  loyé: "loyer", loyez: "loyer", cautio: "caution", cotion: "caution", avence: "avance",
  paiment: "paiement", payement: "paiement", paiemant: "paiement", recu: "reçu",
  cheque: "chèque", virment: "virement", espece: "espèce", especes: "espèces",
  depart: "départ", decés: "décès", deces: "décès", rénovaton: "rénovation",
  renovation: "rénovation", resiliation: "résiliation", résilation: "résiliation",
  erreure: "erreur", éronné: "erroné", errone: "erroné", sélectionée: "sélectionnée",
  abengouru: "Abengourou", abengoroun: "Abengourou", abengoruo: "Abengourou", abidjn: "Abidjan",
  bornag: "bornage", attestaion: "attestation", attestion: "attestation", certifcat: "certificat",
  concesion: "concession", definitive: "définitive", définitve: "définitive", foncié: "foncier",
};
