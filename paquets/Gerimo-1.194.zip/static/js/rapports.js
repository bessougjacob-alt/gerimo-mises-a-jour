// Étape 8 : aperçu du mois (accueil) et rapports.
// Le serveur calcule tout et respecte les droits (Gestionnaire : ses biens, sans commission).

// ---------- Accueil : aperçu du mois ----------

async function chargerAccueil() {
  if (!moi.modules.includes("rapports")) return;  // la Caisse n'a pas d'accueil chiffré
  try {
    const t = await api("/api/tableau-de-bord");
    el("kpiMois").textContent = `(${t.mois})`;
    el("kpiLoyers").textContent = formatMontant(t.loyers_encaisses);
    el("kpiImpayes").textContent = `${t.impayes_en_cours} contrat${t.impayes_en_cours > 1 ? "s" : ""}`;
    el("kpiRisque").textContent = t.contrats_a_risque;
    if (t.logements) {  // logements occupés / libres
      const o = t.logements;
      el("kpiOccupes").textContent = o.occupes;
      el("kpiLibres").textContent = o.libres;
      el("barreOccupes").style.width = `${o.taux_occupation}%`;
      el("kpiOccupation").textContent = `Taux d'occupation ${o.taux_occupation} % — ${o.total} logement(s)` +
        (o.reserves ? `, ${o.reserves} réservé(s)` : "") + (o.maintenance ? `, ${o.maintenance} en maintenance` : "");
    }
    if (t.commission_entreprise !== undefined) {
      el("kpiDernierLibelle").textContent = "Commission de gestion";
      el("kpiDernier").textContent = formatMontant(t.commission_entreprise);
    } else {  // Gestionnaire : pas de commission, on montre ses dépenses du mois
      el("kpiDernierLibelle").textContent = "Dépenses du mois";
      el("kpiDernier").textContent = formatMontant(t.depenses);
    }
  } catch { /* l'accueil reste affiché avec « — » */ }
}
CHARGEURS.accueil = chargerAccueil;

// ---------- Période ----------

function isoDe(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function appliquerPeriode() {
  const choix = el("rapPeriode").value;
  const a = new Date();
  let debut, fin;
  if (choix === "mois") { debut = new Date(a.getFullYear(), a.getMonth(), 1); fin = a; }
  else if (choix === "mois_dernier") { debut = new Date(a.getFullYear(), a.getMonth() - 1, 1); fin = new Date(a.getFullYear(), a.getMonth(), 0); }
  else if (choix === "annee") { debut = new Date(a.getFullYear(), 0, 1); fin = a; }
  else if (choix === "annee_derniere") { debut = new Date(a.getFullYear() - 1, 0, 1); fin = new Date(a.getFullYear() - 1, 11, 31); }
  else return;  // dates libres : on garde ce qui est saisi
  fixerDate("rapDebut", isoDe(debut));
  fixerDate("rapFin", isoDe(fin));
}
el("rapPeriode").addEventListener("change", () => {
  appliquerPeriode();
  if (el("rapPeriode").value !== "libre") chargerRapport();
});

function periodeChoisie() {
  const debut = valeurDate("rapDebut", "Du");
  const fin = valeurDate("rapFin", "Au");
  if (!debut || !fin) throw new Error("Indiquez la période (jj/mm/aaaa).");
  if (fin < debut) throw new Error("La date de fin doit être après la date de début.");
  return `debut=${debut}&fin=${fin}`;
}

// ---------- Rapport ----------

function carteKpi(classe, libelle, valeur, sous = "") {
  return `<div class="kpi ${classe}"><div class="label">${libelle}</div><div class="value">${valeur}</div>${sous ? `<div class="sous-valeur">${sous}</div>` : ""}</div>`;
}

async function chargerRapport() {
  const form = el("formulaireRapport");
  erreurFormulaire(form, "");
  let r;
  try {
    r = await api("/api/rapports?" + periodeChoisie());
  } catch (e) {
    erreurFormulaire(form, e.message);
    return;
  }
  const k = r.kpis;
  const admin = k.commission_entreprise !== undefined;
  let html = `<div class="kpis">
    ${carteKpi("ok", "Total encaissé", formatMontant(k.total_encaisse), `${k.nb_encaissements} encaissement(s)`)}
    ${carteKpi("ok", "Loyers encaissés", formatMontant(k.loyers), `dont cautions à part : ${formatMontant(k.cautions)}`)}
    ${admin ? carteKpi("info", "Commission de gestion", formatMontant(k.commission_entreprise)) : ""}
    ${admin ? carteKpi("info", "Net à reverser", formatMontant(k.net_a_reverser), "aux propriétaires") : ""}
    ${carteKpi("warn", "Dépenses", formatMontant(k.depenses), admin ? `dont propriétaires : ${formatMontant(k.depenses_proprietaires)}` : "")}
    ${carteKpi("warn", "Taux d'impayés", `${String(k.taux_impayes).replace(".", ",")} %`, `${formatMontant(k.montant_impayes_periode)} échus non payés`)}
    ${carteKpi("risk", "Contrats à risque", k.contrats_a_risque, `${k.contrats_en_retard} contrat(s) en retard`)}
    ${r.occupation ? carteKpi("info", "Occupés / libres", `${r.occupation.occupes} / ${r.occupation.libres}`,
        `Taux d'occupation ${r.occupation.taux_occupation} % — ${r.occupation.total} logement(s)`) : ""}
  </div>`;

  if (admin) {
    const lignes = r.reversements.map(p => `
      <div class="row"><span class="who"><b>${esc(p.proprietaire)}</b>${p.bien_entreprise ? ' <span class="pill info">Bien de l\'entreprise</span>' : ""}
        <br><span class="petit">${p.biens.map(b => `${esc(b.bien)} : ${formatMontant(b.net)}`).join(" — ")}</span></span>
        <span class="boutons petit" style="text-align:right">Loyers ${formatMontant(p.loyers)}<br>− Commission ${formatMontant(p.commission)}
          ${p.depenses ? `<br>− Dépenses ${formatMontant(p.depenses)}` : ""}</span>
        <span class="pill ok" style="font-size:.82rem">${formatMontant(p.net)}</span>
        ${p.proprietaire_id && !p.bien_entreprise ? ibtn("whatsapp", "Envoyer le relevé au propriétaire (WhatsApp, e-mail, PDF)",
            `envoyerReleve(${p.proprietaire_id})`) : ""}</div>`).join("");
    relevesAffiches = { periode: `debut=${r.debut}&fin=${r.fin}`, liste: r.reversements };
    html += `<div class="card"><h3>Reversements propriétaires vs commission de gestion</h3>
      ${lignes || '<div class="vide">Aucun encaissement sur la période.</div>'}
      <p class="petit">Net à reverser = loyers encaissés − commission de gestion − dépenses à la charge du propriétaire.
        Les cautions, conservées par l'entreprise, ne sont pas reversées. Le PDF contient un relevé par propriétaire ;
        le bouton WhatsApp à droite envoie son relevé à un propriétaire.</p></div>`;
  }

  html += `<div class="card"><h3>Situation par bien</h3>${r.par_bien.map(b => `
    <div class="row"><span class="who"><b>${esc(b.bien)}</b><br><span class="petit">Loyers ${formatMontant(b.loyers)} — Dépenses ${formatMontant(b.depenses)}</span></span>
      <span class="pill ${b.taux_occupation === null ? "info" : b.taux_occupation >= 80 ? "ok" : b.taux_occupation >= 50 ? "warn" : "danger"}">
        ${b.taux_occupation === null ? "Aucun logement" : `Occupation ${b.occupes}/${b.logements} (${b.taux_occupation} %)`}</span></div>`).join("")
    || '<div class="vide">Aucun bien.</div>'}</div>`;

  html += `<div class="card"><h3>Échéances proches (7 jours)</h3>${r.echeances_proches.map(e => `
    <div class="row"><span class="who">${esc(e.locataire)} — ${esc(e.logement)} — ${formatMontant(e.montant)}</span>
      <span class="pill warn">Échéance le ${formatDate(e.date_limite)}</span></div>`).join("")
    || '<div class="vide">Aucune échéance dans les 7 prochains jours.</div>'}</div>`;

  html += `<div class="card"><h3>Contrats en retard</h3>${r.a_risque.map(c => `
    <div class="row"><span class="who">${esc(c.locataire)} — ${esc(c.logement)} — N° ${esc(c.numero_contrat)}</span>
      <span class="pill ${c.a_risque ? "danger" : "warn"}">${c.nb_mois} mois — ${formatMontant(c.montant)}${c.a_risque ? " — à risque" : ""}</span></div>`).join("")
    || '<div class="vide">Aucun retard : tous les loyers échus sont réglés.</div>'}</div>`;

  html += `<div class="card"><h3>Encaissements par mode de paiement</h3>${r.par_mode.map(m => `
    <div class="row"><span class="who">${esc(m.mode)}</span><span>${formatMontant(m.montant)}</span></div>`).join("")
    || '<div class="vide">Aucun encaissement sur la période.</div>'}</div>`;

  if (r.achats_ventes) {
    const av = r.achats_ventes;
    html += `<div class="card"><h3>Achats / Ventes de biens</h3>
      <div class="row"><span class="who">Ventes</span><span>${formatMontant(av.ventes)}</span></div>
      <div class="row"><span class="who">Commissions d'intermédiation</span><span>${formatMontant(av.commissions_intermediation)}</span></div>
      <div class="row"><span class="who">Achats</span><span>${formatMontant(av.achats)}</span></div></div>`;
  }
  el("contenuRapport").innerHTML = html;
}

// ---------- Relevé envoyé au propriétaire ----------
let relevesAffiches = { periode: "", liste: [] };

function envoyerReleve(proprietaireId) {
  const p = relevesAffiches.liste.find(x => x.proprietaire_id === proprietaireId);
  if (!p) return;
  const base = `/api/rapports/releve/${proprietaireId}`, q = "?" + relevesAffiches.periode;
  envoyerDocument({
    titre: "Relevé de reversement", nom: p.proprietaire, telephone: p.telephone || "", email: p.email || "",
    urlPdf: `${base}/pdf${q}`, urlEmail: `${base}/envoyer-email${q}`, urlWhatsApp: `${base}/whatsapp${q}`,
  });
}

el("formulaireRapport").addEventListener("submit", e => {
  e.preventDefault();
  el("rapPeriode").value = "libre";
  chargerRapport();
});

function exporterRapport() {
  try {
    window.open("/api/rapports/pdf?" + periodeChoisie(), "_blank");
  } catch (e) {
    erreurFormulaire(el("formulaireRapport"), e.message);
  }
}

// Deux onglets : les graphiques (statistiques.js) et le rapport détaillé avec son PDF
let ongletRapports = "rapGraphiques";
function montrerOngletRapports(id) {
  const compta = moi.modules.includes("comptabilite");   // Admin, Caisse, Comptable
  el("ongletResultat").style.display = compta ? "" : "none";
  if (id === "rapResultat" && !compta) id = "rapGraphiques";
  ongletRapports = id;
  document.querySelectorAll("#ongletsRapports .onglet").forEach(b => b.classList.toggle("actif", b.dataset.onglet === id));
  el("rapGraphiques").style.display = id === "rapGraphiques" ? "" : "none";
  el("rapDetail").style.display = id === "rapDetail" ? "" : "none";
  el("rapBien").style.display = id === "rapBien" ? "" : "none";
  el("rapResultat").style.display = id === "rapResultat" ? "" : "none";
  if (id === "rapGraphiques") { chargerStatistiques(); return; }
  if (id === "rapResultat") { chargerResultat(); return; }
  if (id === "rapBien") { ouvrirRapportBien(); return; }
  if (!el("rapDebut").value) appliquerPeriode();  // première ouverture : ce mois
  chargerRapport();
}
el("ongletsRapports").addEventListener("click", e => {
  const b = e.target.closest(".onglet");
  if (b) montrerOngletRapports(b.dataset.onglet);
});
CHARGEURS.rapports = () => montrerOngletRapports(ongletRapports);
// Icône du bord droit : directement sur les graphiques
// Assistant, début de mois : rapport détaillé du mois dernier, pour envoyer les relevés
function ouvrirRelevesMoisDernier() {
  el("rapPeriode").value = "mois_dernier";
  appliquerPeriode();
  ongletRapports = "rapDetail";
  ouvrirModule("rapports");
}
function ouvrirStatistiques() { ongletRapports = "rapGraphiques"; ouvrirModule("rapports"); }

// ---------- Rapport mensuel par bien (à imprimer ou à exporter vers Excel) ----------

// Liste des mois (noms tirés de MOIS_NOMS, agenda.js) : ce mois, puis les 23 mois précédents, puis « Dates libres… »
function remplirMoisRapBien() {
  const a = new Date();
  let html = "";
  for (let i = 0; i < 24; i++) {
    const d = new Date(a.getFullYear(), a.getMonth() - i, 1);
    const valeur = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const nom = MOIS_NOMS[d.getMonth()];
    html += `<option value="${valeur}">${nom.charAt(0).toUpperCase() + nom.slice(1)} ${d.getFullYear()}${i === 0 ? " (en cours)" : ""}</option>`;
  }
  el("rbPeriode").innerHTML = html + '<option value="libre">Dates libres…</option>';
}

function appliquerMoisRapBien() {
  const choix = el("rbPeriode").value;
  const libre = choix === "libre";
  document.querySelectorAll("#formulaireRapBien .rb-libre").forEach(z => { z.style.display = libre ? "" : "none"; });
  if (libre) return;
  const [annee, mois] = choix.split("-").map(Number);
  const a = new Date();
  const dernier = new Date(annee, mois, 0);
  fixerDate("rbDebut", isoDe(new Date(annee, mois - 1, 1)));
  fixerDate("rbFin", isoDe(dernier > a ? a : dernier));  // mois en cours : jusqu'à aujourd'hui
}

function filtresRapBien() {
  const debut = valeurDate("rbDebut", "Du"), fin = valeurDate("rbFin", "Au");
  if (!debut || !fin) throw new Error("Indiquez la période (jj/mm/aaaa).");
  if (fin < debut) throw new Error("La date de fin doit être après la date de début.");
  const bien = el("rbBien").value;
  return `debut=${debut}&fin=${fin}` + (bien ? `&cite_id=${bien}` : "");
}

let rapBienPret = false;
async function ouvrirRapportBien() {
  if (!rapBienPret) {
    remplirMoisRapBien();
    el("rbPeriode").selectedIndex = 1;  // par défaut : le mois dernier (mois complet)
    appliquerMoisRapBien();
    try {
      const biens = await api("/api/rapports/par-bien/biens");
      el("rbBien").innerHTML = (biens.length > 1 ? '<option value="">Tous les biens</option>' : "") +
        biens.map(b => `<option value="${b.id}">${esc(b.nom)}</option>`).join("");
    } catch (e) { erreurFormulaire(el("formulaireRapBien"), e.message); return; }
    rapBienPret = true;
  }
  chargerRapportBien();
}

el("rbPeriode").addEventListener("change", () => {
  appliquerMoisRapBien();
  if (el("rbPeriode").value !== "libre") chargerRapportBien();
});
el("rbBien").addEventListener("change", () => chargerRapportBien());
el("formulaireRapBien").addEventListener("submit", e => { e.preventDefault(); chargerRapportBien(); });

async function chargerRapportBien() {
  const form = el("formulaireRapBien");
  erreurFormulaire(form, "");
  let r;
  try { r = await api("/api/rapports/par-bien?" + filtresRapBien()); }
  catch (e) { erreurFormulaire(form, e.message); return; }
  if (!r.biens.length) {
    el("contenuRapBien").innerHTML = '<div class="card"><div class="vide">Aucun bien avec des logements à présenter.</div></div>';
    return;
  }
  const fin = r.finances, m = formatMontant;
  const periode = r.periode.charAt(0).toUpperCase() + r.periode.slice(1);
  const tirets = v => (Number(v) ? m(v) : "—");
  el("contenuRapBien").innerHTML = r.biens.map(b => {
    const t = b.totaux;
    const fiche = [["Type de bien", b.type_bien], ["Adresse", b.adresse || "—"],
      ["Logements", `${b.nb_logements} dont ${b.occupes} occupé(s)`]];
    if (fin) fiche.unshift(["Propriétaire", b.proprietaire], ["Contact du propriétaire", b.proprietaire_telephone || "—"],
      ["Commission de gestion", b.pourcentage_commission !== null ? `${String(b.pourcentage_commission).replace(".", ",")} %` : "—"]);
    const lignes = b.lignes.map(l => `<tr${l.locataire.startsWith("—") ? ' style="color:var(--ink-soft)"' : ""}>
        <td><b>${esc(l.numero)}</b></td><td>${esc(l.type_logement)}</td>
        <td>${esc(l.locataire)}${l.numero_contrat ? `<br><span class="petit">${esc(l.numero_contrat)}</span>` : ""}</td>
        <td>${esc(l.telephone || "—")}</td>
        <td class="nombre">${m(l.loyer_mensuel)}</td><td class="nombre">${tirets(l.encaisse)}</td>
        ${fin ? `<td class="nombre">${tirets(l.commission)}</td><td class="nombre">${tirets(l.part_proprietaire)}</td>` : ""}
        <td class="nombre"${Number(l.impaye) ? ' style="color:var(--danger);font-weight:600"' : ""}
          title="${esc(l.mois_impayes.join(", "))}">${tirets(l.impaye)}</td>
        <td class="nombre">${tirets(l.depenses)}</td></tr>`).join("");
    const communes = Number(b.depenses_communes) ? `<tr style="color:var(--ink-soft)"><td></td><td></td>
        <td colspan="${fin ? 7 : 5}"><i>Dépenses communes du bien</i></td><td class="nombre">${m(b.depenses_communes)}</td></tr>` : "";
    const cartes = [carteKpi("ok", "Loyers encaissés", m(t.encaisse), Number(t.cautions) ? `cautions à part : ${m(t.cautions)}` : "")];
    if (fin) cartes.push(carteKpi("info", "Commission de l'agence", m(t.commission)),
      carteKpi("info", "Part du propriétaire", m(t.part_proprietaire)),
      carteKpi("ok", "Net à reverser", m(t.net_a_reverser), `après ${m(t.depenses_proprietaire)} de dépenses à sa charge`));
    cartes.push(carteKpi("risk", "Loyers impayés", m(t.impaye)), carteKpi("warn", "Dépenses", m(t.depenses)));
    const depenses = b.detail_depenses.map(d => `<tr><td>${formatDate(d.date)}</td><td>${esc(d.logement)}</td>
        <td>${esc(d.motif)}</td><td>${esc(d.categorie)}</td><td>${esc(d.a_la_charge_de)}</td><td class="nombre">${m(d.montant)}</td></tr>`).join("");
    return `<div class="card">
      <h3>${esc(b.bien)} <span class="petit">— ${esc(periode)}</span></h3>
      <div class="petit" style="display:flex;flex-wrap:wrap;gap:.3rem 1.4rem;margin-bottom:.9rem">
        ${fiche.map(([k, v]) => `<span>${k} : <b style="color:var(--ink)">${esc(v)}</b></span>`).join("")}</div>
      <div style="overflow-x:auto"><table class="tableau">
        <thead><tr><th>N°</th><th>Type</th><th>Locataire</th><th>Contact</th><th class="nombre">Loyer mensuel</th>
          <th class="nombre">Encaissé</th>${fin ? '<th class="nombre">Commission agence</th><th class="nombre">Part propriétaire</th>' : ""}
          <th class="nombre">Loyer impayé</th><th class="nombre">Dépenses</th></tr></thead>
        <tbody>${lignes}${communes}</tbody>
        <tfoot><tr style="font-weight:700;background:#eef5e8"><td colspan="4">TOTAL</td>
          <td class="nombre">${m(t.loyer_mensuel)}</td><td class="nombre">${m(t.encaisse)}</td>
          ${fin ? `<td class="nombre">${m(t.commission)}</td><td class="nombre">${m(t.part_proprietaire)}</td>` : ""}
          <td class="nombre">${m(t.impaye)}</td><td class="nombre">${m(t.depenses)}</td></tr></tfoot>
      </table></div>
      <div class="kpis" style="margin:1rem 0 .4rem">${cartes.join("")}</div>
      ${depenses ? `<details><summary class="petit" style="cursor:pointer">Détail des dépenses (${b.detail_depenses.length})</summary>
        <div style="overflow-x:auto"><table class="tableau"><thead><tr><th>Date</th><th>Logement</th><th>Motif</th><th>Catégorie</th>
        <th>À la charge de</th><th class="nombre">Montant</th></tr></thead><tbody>${depenses}</tbody></table></div></details>` : ""}
    </div>`;
  }).join("") + `<p class="petit">Loyer impayé : loyer des mois de la période dont la date limite (le 05) est passée et qui
    n'est pas réglé (passez la souris dessus pour voir les mois).${fin ? " Part du propriétaire = loyers encaissés − commission de l'agence ; net à reverser = part du propriétaire − dépenses à sa charge. Les cautions ne sont pas reversées." : ""}</p>`;
}

function imprimerRapportBien() {
  try { window.open("/api/rapports/par-bien/pdf?" + filtresRapBien(), "_blank"); }
  catch (e) { erreurFormulaire(el("formulaireRapBien"), e.message); }
}

async function excelRapportBien() {
  try {
    const f = await apiFichier("/api/rapports/par-bien/excel?" + filtresRapBien());
    telechargerBlob(f.blob, f.nom);
    toast(`« ${f.nom} » téléchargé : il s'ouvre avec Excel.`);
  } catch (e) { erreurFormulaire(el("formulaireRapBien"), e.message); }
}
