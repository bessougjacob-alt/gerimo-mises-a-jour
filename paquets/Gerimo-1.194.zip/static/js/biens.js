// Étape 2 : biens (cités, immeubles, lotissements…), logements, parcelles et propriétaires.
// Le serveur ne renvoie que ce que le profil a le droit de voir ;
// les boutons masqués ici sont de toute façon refusés par le serveur.

const el = id => document.getElementById(id);
const NOUVELLE_CITE = "__nouvelle__";
const PARCELLE = "Parcelle";
const CLASSE_STATUT = { "Libre": "ok", "Occupé": "warn", "Réservé": "info", "Maintenance": "danger" };
const CLASSE_APPROBATION = { "Approuvé": "ok", "En attente": "warn", "Non-approuvé": "danger" };

let citesCache = [];
let propriosCache = [];
let elementEnCours = null;   // { genre: "logement" | "parcelle", id } en modification, null = ajout
let citeEnCours = null;
let proprioEnCours = null;

function pluriel(n, mot) { return `${n} ${mot}${n > 1 ? "s" : ""}`; }
// 1500.5 → « 1 500,5 »
function formatNombre(n) { return Number(n).toLocaleString("fr-FR").replace(/[  ]/g, " "); }
// Champ facultatif : vide → null ; invalide → erreur
function lireMontantFacultatif(id, libelle) {
  const texte = el(id).value.trim();
  if (!texte) return null;
  const n = lireMontant(texte);
  if (n === null) throw new Error(`Vérifiez le champ « ${libelle} » (ex : 2 000 000).`);
  return n;
}
// Commission ISUP : obligatoire, entre 0 et 100 %
function lirePourcentage(id) {
  const texte = el(id).value.trim().replace("%", "").replace(",", ".").trim();
  const n = /^\d+(\.\d{1,2})?$/.test(texte) ? Number(texte) : null;
  if (n === null || n > 100) throw new Error("Indiquez la commission de gestion en % (entre 0 et 100 ; 0 si le bien appartient à l'entreprise).");
  return n;
}
function formatPourcentage(n) { return formatNombre(n) + " %"; }

function reformaterMontant(id) {
  el(id).addEventListener("blur", () => {
    const n = lireMontant(el(id).value);
    if (n !== null) el(id).value = formatNombre(n);
  });
}

// ---------- Liste des biens ----------

async function chargerBiens() {
  const zone = el("listeBiens");
  try {
    [citesCache] = await Promise.all([api("/api/biens"), chargerSignalementsCache()]);
  } catch (e) {
    zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`;
    return;
  }
  if (!citesCache.length) {
    zone.innerHTML = `<div class="card vide">${estAdmin()
      ? "Aucun bien enregistré. Cliquez sur « + Ajouter un bien »."
      : "Aucun bien ne vous est confié pour l'instant. Demandez à l'Admin."}</div>`;
    return;
  }
  zone.innerHTML = citesCache.map(c => {
    const contenu = [];
    if (c.logements.length || !c.parcelles.length) contenu.push(pluriel(c.logements.length, "logement"));
    if (c.parcelles.length) contenu.push(pluriel(c.parcelles.length, "parcelle"));
    let details = contenu.join(", ");
    if (c.adresse) details += ` — ${esc(c.adresse)}`;
    if (estAdmin()) {
      details += ` — Propriétaire : ${esc(c.proprietaire ? c.proprietaire.nom_complet : "non renseigné")}`;
      details += c.pourcentage_commission !== null
        ? ` — Commission : ${formatPourcentage(c.pourcentage_commission)}`
        : ' — <span class="pill warn">Commission à renseigner</span>';
      if (c.gestionnaires.length) details += ` — Gestionnaire : ${esc(c.gestionnaires.map(g => g.nom_complet).join(", "))}`;
    }
    const ouverts = problemesOuverts(c.id);
    const boutonsCite = ibtn("probleme", ouverts ? `${ouverts} problème(s) en cours — déclarer un problème` : "Déclarer un problème sur ce bien",
                             `declarerProbleme(${c.id})`) + (ouverts ? `<span class="pill danger" style="cursor:pointer" onclick="afficher('problemes')">${ouverts}</span>` : "") +
      (estAdmin() ? ibtn("modifier", "Modifier ce bien", `modifierCite(${c.id})`) +
                    ibtn("supprimer", "Supprimer ce bien (Admin)", `supprimerCite(${c.id})`) : "");
    const lignesLogements = c.logements.map(l => `
      <div class="row sous">
        <span class="who">Logement ${esc(l.numero_logement)} — ${esc(l.type_logement)} — Loyer ${formatMontant(l.loyer)}</span>
        <span class="boutons">
          <span class="pill ${CLASSE_STATUT[l.statut_logement]}">${esc(l.statut_logement)}</span>
          ${ibtn("probleme", "Déclarer un problème dans ce logement", `declarerProbleme(${c.id}, ${l.id})`)}
          ${ibtn("modifier", "Modifier ce logement", `modifierLogement(${l.id})`)}
          ${estAdmin() ? ibtn("supprimer", "Supprimer ce logement (Admin)", `supprimerLogement(${l.id})`) : ""}
        </span>
      </div>`).join("");
    const lignesParcelles = c.parcelles.map(p => {
      const prix = [];
      if (p.prix_entree !== null) prix.push(`Prix d'entrée ${formatMontant(p.prix_entree)}`);
      if (p.dernier_prix !== null) prix.push(`Dernier prix ${formatMontant(p.dernier_prix)}`);
      const plus = [p.situation_geographique, p.documents && "Documents : " + p.documents].filter(Boolean).map(esc).join(" — ");
      return `
      <div class="row sous">
        <span class="who">Parcelle ${esc(p.numero_parcelle)} — ${formatNombre(p.superficie)} m²${prix.length ? " — " + prix.join(" — ") : ""}
          ${plus ? `<br><span class="petit">${plus}</span>` : ""}</span>
        <span class="boutons">
          <span class="pill ${CLASSE_APPROBATION[p.approbation]}">${esc(p.approbation)}</span>
          <span class="pill ${p.disponible ? "ok" : "info"}">Disponible : ${p.disponible ? "Oui" : "Non"}</span>
          ${ibtn("modifier", "Modifier cette parcelle", `modifierParcelle(${p.id})`)}
          ${estAdmin() ? ibtn("supprimer", "Supprimer cette parcelle (Admin)", `supprimerParcelle(${p.id})`) : ""}
        </span>
      </div>`;
    }).join("");
    const vide = '<div class="row sous"><span class="who a-venir">Aucun logement ni parcelle pour l\'instant</span></div>';
    return `<div class="card">
      <div class="row"${motsCles({ textes: [c.description, c.proprietaire?.nom_complet] })}><span class="who"><b>${esc(c.nom)}</b> — ${details}</span><span class="boutons">${boutonsCite}</span></div>
      ${lignesLogements + lignesParcelles || vide}
    </div>`;
  }).join("");
  el("rechercheBiens").dispatchEvent(new Event("input"));  // garde le filtre en cours
}
CHARGEURS.biens = chargerBiens;

function trouverDans(cle, id) {
  for (const c of citesCache) {
    const x = c[cle].find(x => x.id === id);
    if (x) return x;
  }
  return null;
}

// ---------- Formulaire : logement ou parcelle (avec « + Nouveau bien… ») ----------

async function preparerFormBien(objet, genre) {
  const o = await api("/api/biens/options");
  elementEnCours = objet ? { genre, id: objet.id } : null;

  const selCite = el("bienCite");
  remplirSelect(selCite, o.cites, { valeur: c => c.id, texte: c => c.nom, vide: "— Choisir —" });
  if (o.peut_creer_cite) selCite.insertAdjacentHTML("beforeend", `<option value="${NOUVELLE_CITE}">+ Nouveau bien…</option>`);
  // En modification, on ne transforme pas un logement en parcelle (ni l'inverse)
  const types = genre === "logement" ? o.types_batiment.filter(t => t !== PARCELLE) : o.types_batiment;
  remplirSelect(el("bienTypeBat"), types);
  el("bienTypeBat").disabled = genre === "parcelle";
  remplirSelect(el("bienTypeLog"), o.types_logement);
  remplirSelect(el("bienStatut"), o.statuts_logement);
  remplirSelect(el("parcApprobation"), o.approbations);
  if (estAdmin()) {
    remplirSelect(el("bienProprio"), o.proprietaires, { valeur: p => p.id, texte: p => p.nom_complet, vide: "— Choisir —" });
  }
  document.querySelectorAll("#formBien .champ-admin").forEach(c => { c.style.display = estAdmin() ? "" : "none"; });

  // Logement
  const l = genre === "logement" ? objet : null;
  el("bienNumero").value = l ? l.numero_logement : "";
  el("bienLoyer").value = l ? formatNombre(l.loyer) : "";
  el("bienStatut").value = l ? l.statut_logement : "Libre";
  el("bienTypeLog").value = l ? l.type_logement : o.types_logement[0];
  // Parcelle
  const p = genre === "parcelle" ? objet : null;
  el("parcNumero").value = p ? p.numero_parcelle : "";
  el("parcSuperficie").value = p ? formatNombre(p.superficie) : "";
  el("parcSituation").value = p?.situation_geographique || "";
  el("parcDocuments").value = p?.documents || "";
  el("parcPrixEntree").value = p && p.prix_entree !== null ? formatNombre(p.prix_entree) : "";
  el("parcDernierPrix").value = p && p.dernier_prix !== null ? formatNombre(p.dernier_prix) : "";
  el("parcApprobation").value = p ? p.approbation : "En attente";
  el("parcDisponible").value = p && !p.disponible ? "non" : "oui";

  if (objet) {
    selCite.value = objet.cite_id;
  } else if (o.cites.length === 1) {
    selCite.value = o.cites[0].id;
  } else if (!o.cites.length && o.peut_creer_cite) {
    selCite.value = NOUVELLE_CITE;  // tout premier bien : on le crée en même temps
  }
  majChampsCite();
  if (l) el("bienTypeBat").value = l.type_batiment;
  if (p) el("bienTypeBat").value = PARCELLE;
  majSectionsType();
  erreurFormulaire(el("formulaireBien"), "");
}

// « Parcelle » : champs de la parcelle à la place de ceux du logement
function majSectionsType() {
  const parcelle = el("bienTypeBat").value === PARCELLE;
  el("sectionParcelle").style.display = parcelle ? "" : "none";
  el("sectionLogement").style.display = parcelle ? "none" : "";
}
el("bienTypeBat").addEventListener("change", majSectionsType);

// Champs du bien : modifiables seulement pour un nouveau bien
function majChampsCite() {
  const valeur = el("bienCite").value;
  const nouvelle = valeur === NOUVELLE_CITE;
  el("champNouvelleCite").style.display = nouvelle ? "" : "none";
  el("bienProprio").disabled = !nouvelle;
  el("bienAdresse").disabled = !nouvelle;
  el("bienCommission").disabled = !nouvelle;  // pour un bien existant : bouton « Modifier » du bien
  el("bienNomCite").value = "";
  if (nouvelle) {
    el("bienAdresse").value = "";
    el("bienProprio").value = "";
    el("bienCommission").value = "";
    return;
  }
  const cite = citesCache.find(c => String(c.id) === valeur);
  el("bienAdresse").value = cite?.adresse || "";
  if (estAdmin()) {
    el("bienProprio").value = cite?.proprietaire?.id ?? "";
    el("bienCommission").value = cite && cite.pourcentage_commission !== null ? formatNombre(cite.pourcentage_commission) : "";
  }
  // pour un ajout, on propose le même type que le reste du bien
  if (!elementEnCours && cite) {
    if (cite.logements.length) el("bienTypeBat").value = cite.logements[0].type_batiment;
    else if (cite.parcelles.length) el("bienTypeBat").value = PARCELLE;
    majSectionsType();
  }
}
el("bienCite").addEventListener("change", majChampsCite);
reformaterMontant("bienLoyer");
reformaterMontant("parcPrixEntree");
reformaterMontant("parcDernierPrix");
reformaterMontant("parcSuperficie");

async function nouveauBien() {
  if (!estAdmin() && !citesCache.length) { toast("Aucun bien ne vous est confié"); return; }
  await preparerFormBien(null, null);
  afficher("formBien");
}

async function modifierLogement(id) {
  const logement = trouverDans("logements", id);
  if (!logement) return;
  await preparerFormBien(logement, "logement");
  afficher("formBien");
}

async function modifierParcelle(id) {
  const parcelle = trouverDans("parcelles", id);
  if (!parcelle) return;
  await preparerFormBien(parcelle, "parcelle");
  afficher("formBien");
}

// Bien choisi ou nouveau bien : partie commune aux logements et aux parcelles
function lireChoixBien() {
  const choix = el("bienCite").value;
  if (!choix) throw new Error("Choisissez un bien.");
  if (choix !== NOUVELLE_CITE) return { cite_id: Number(choix) };
  if (!el("bienNomCite").value.trim()) throw new Error("Indiquez le nom du nouveau bien.");
  if (!el("bienProprio").value) throw new Error("Choisissez le propriétaire du bien (créez-le d'abord dans Propriétaires si besoin).");
  return {
    nouvelle_cite: {
      nom: el("bienNomCite").value,
      adresse: el("bienAdresse").value,
      proprietaire_id: Number(el("bienProprio").value),
      pourcentage_commission: lirePourcentage("bienCommission"),
    },
  };
}

function lireParcelle() {
  if (!el("parcNumero").value.trim()) throw new Error("Indiquez le numéro de la parcelle (lot).");
  const superficie = lireMontant(el("parcSuperficie").value);
  if (superficie === null || superficie <= 0) throw new Error("Indiquez une superficie valide en m² (ex : 500).");
  return {
    numero_parcelle: el("parcNumero").value,
    superficie,
    situation_geographique: el("parcSituation").value,
    documents: el("parcDocuments").value,
    prix_entree: lireMontantFacultatif("parcPrixEntree", "Prix d'entrée"),
    dernier_prix: lireMontantFacultatif("parcDernierPrix", "Dernier prix"),
    approbation: el("parcApprobation").value,
    disponible: el("parcDisponible").value === "oui",
  };
}

function lireLogement() {
  const loyer = lireMontant(el("bienLoyer").value);
  if (!el("bienNumero").value.trim()) throw new Error("Indiquez le numéro de logement.");
  if (loyer === null || loyer <= 0) throw new Error("Indiquez un loyer valide (ex : 75 000).");
  return {
    type_batiment: el("bienTypeBat").value,
    numero_logement: el("bienNumero").value,
    type_logement: el("bienTypeLog").value,
    loyer,
    statut_logement: el("bienStatut").value,
  };
}

el("formulaireBien").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    const estParcelle = el("bienTypeBat").value === PARCELLE;
    const corps = { ...lireChoixBien(), ...(estParcelle ? lireParcelle() : lireLogement()) };
    const chemin = estParcelle ? "/api/parcelles" : "/api/logements";
    if (elementEnCours) {
      await api(`${chemin}/${elementEnCours.id}`, { method: "PUT", body: corps });
    } else {
      await api(chemin, { method: "POST", body: corps });
    }
    toast(estParcelle ? "Parcelle enregistrée" : "Logement enregistré");
    goBack();
  });
});

function supprimerLogement(id) {
  const l = trouverDans("logements", id);
  supprimerAvecConfirmation(
    `Supprimer le logement ${l ? l.numero_logement : ""} ? Entrez votre mot de passe Admin pour confirmer.`,
    `/api/logements/${id}/supprimer`, chargerBiens);
}

function supprimerParcelle(id) {
  const p = trouverDans("parcelles", id);
  supprimerAvecConfirmation(
    `Supprimer la parcelle ${p ? p.numero_parcelle : ""} ? Entrez votre mot de passe Admin pour confirmer.`,
    `/api/parcelles/${id}/supprimer`, chargerBiens);
}

// ---------- Formulaire du bien lui-même (Admin) ----------

async function modifierCite(id) {
  const cite = citesCache.find(c => c.id === id);
  if (!cite) return;
  const o = await api("/api/biens/options");
  citeEnCours = id;
  remplirSelect(el("citeProprio"), o.proprietaires, { valeur: p => p.id, texte: p => p.nom_complet, vide: "— Choisir —" });
  el("citeNom").value = cite.nom;
  el("citeAdresse").value = cite.adresse || "";
  el("citeDescription").value = cite.description || "";
  el("citeProprio").value = cite.proprietaire?.id ?? "";
  el("citeCommission").value = cite.pourcentage_commission !== null ? formatNombre(cite.pourcentage_commission) : "";
  const choisis = new Set(cite.gestionnaires.map(g => g.id));
  el("citeGestionnaires").innerHTML = o.gestionnaires.length
    ? o.gestionnaires.map(g => `<label><input type="checkbox" value="${g.id}" ${choisis.has(g.id) ? "checked" : ""}> ${esc(g.nom_complet)}</label>`).join("")
    : '<span class="a-venir">Aucun compte Gestionnaire pour l\'instant.</span>';
  erreurFormulaire(el("formulaireCite"), "");
  afficher("formCite");
}

el("formulaireCite").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (!el("citeNom").value.trim()) throw new Error("Indiquez le nom du bien.");
    if (!el("citeProprio").value) throw new Error("Choisissez le propriétaire.");
    await api(`/api/cites/${citeEnCours}`, {
      method: "PUT",
      body: {
        nom: el("citeNom").value,
        adresse: el("citeAdresse").value,
        description: el("citeDescription").value,
        proprietaire_id: Number(el("citeProprio").value),
        pourcentage_commission: lirePourcentage("citeCommission"),
        gestionnaires_ids: [...el("citeGestionnaires").querySelectorAll("input:checked")].map(c => Number(c.value)),
      },
    });
    toast("Bien enregistré");
    goBack();
  });
});

function supprimerCite(id) {
  const c = citesCache.find(c => c.id === id);
  supprimerAvecConfirmation(
    `Supprimer le bien « ${c ? c.nom : ""} » ? Entrez votre mot de passe Admin pour confirmer.`,
    `/api/cites/${id}/supprimer`, chargerBiens);
}

// ---------- Propriétaires (Admin) ----------

async function chargerProprios() {
  const zone = el("listeProprios");
  try {
    propriosCache = await api("/api/proprietaires");
  } catch (e) {
    zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`;
    return;
  }
  if (!propriosCache.length) {
    zone.innerHTML = '<div class="card vide">Aucun propriétaire enregistré. Cliquez sur « + Ajouter un propriétaire ».</div>';
    return;
  }
  zone.innerHTML = `<div class="card">${propriosCache.map(p => {
    const infos = [];
    if (p.cni) infos.push(`CNI ${esc(p.cni)}`);
    if (p.telephone) infos.push(`Tél. ${esc(p.telephone)}`);
    if (p.ville) infos.push(esc(p.ville));
    infos.push(p.cites.length
      ? p.cites.map(c => {
          const contenu = [];
          if (c.nb_logements || !c.nb_parcelles) contenu.push(pluriel(c.nb_logements, "logement"));
          if (c.nb_parcelles) contenu.push(pluriel(c.nb_parcelles, "parcelle"));
          return `${esc(c.nom)} (${contenu.join(", ")})`;
        }).join(", ")
      : "Aucun bien");
    return `<div class="row"${motsCles({ tel: [p.telephone], textes: p.cites.map(c => c.adresse) })}>
      <span class="who"><b>${esc(p.nom_complet)}</b>${homonyme(p) ? ' <span class="pill warn" data-tip="Un autre propriétaire porte le même nom : le téléphone les distingue dans les listes">Même nom qu’un autre</span>' : ""} — ${infos.join(" — ")}</span>
      <span class="boutons">
        ${p.nb_pieces ? `<span class="pill info" data-tip="Pièces jointes (CNI…)">${svgIcone("trombone").replace("<svg", '<svg style="width:11px;height:11px;stroke:currentColor;fill:none;stroke-width:2;vertical-align:-1px"')} ${p.nb_pieces}</span>` : ""}
        ${p.telephone ? ibtn("whatsapp", "Écrire sur WhatsApp", `ouvrirWhatsAppTexte('${esc(p.telephone)}')`) : ""}
        ${ibtn("modifier", "Modifier ce propriétaire (et ses pièces jointes)", `modifierProprietaire(${p.id})`)}
        ${propriosCache.length > 1 ? ibtn("fusionner", "Fusionner avec une autre fiche (même personne enregistrée deux fois)", `fusionnerProprietaire(${p.id})`) : ""}
        ${ibtn("supprimer", "Supprimer ce propriétaire (Admin)", `supprimerProprietaire(${p.id})`)}
      </span>
    </div>`;
  }).join("")}</div>`;
  el("rechercheProprios").dispatchEvent(new Event("input"));
}
CHARGEURS.proprietaires = chargerProprios;

function remplirFormProprio(p) {
  proprioEnCours = p ? p.id : null;
  el("proprioNom").value = p ? p.nom_complet : "";
  el("proprioCni").value = p?.cni || "";
  el("proprioTel").value = p?.telephone || "";
  el("proprioVille").value = p ? (p.ville || "") : "";
  el("proprioEmail").value = p?.email || "";
  piecesProprio.ouvrir(p ? { proprietaire_id: p.id } : null);
  erreurFormulaire(el("formulaireProprio"), "");
}

function nouveauProprietaire() {
  remplirFormProprio(null);
  afficher("formProprio");
  el("proprioNom").focus();
}

function modifierProprietaire(id) {
  remplirFormProprio(propriosCache.find(p => p.id === id));
  afficher("formProprio");
}

el("formulaireProprio").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (!el("proprioNom").value.trim()) throw new Error("Indiquez le nom complet.");
    const corps = {
      nom_complet: el("proprioNom").value,
      cni: el("proprioCni").value,
      telephone: el("proprioTel").value,
      ville: el("proprioVille").value,
      email: el("proprioEmail").value,
    };
    const ancien = proprioEnCours && propriosCache.find(p => p.id === proprioEnCours);
    if (!ancien || cleNom(ancien.nom_complet) !== cleNom(corps.nom_complet)) {
      // Homonyme ? (demande de Boss du 11/11/2026) — le serveur revérifie de son côté
      const memes = await api(`/api/proprietaires/homonymes?nom=${encodeURIComponent(corps.nom_complet)}` +
                              (proprioEnCours ? `&sauf=${proprioEnCours}` : ""));
      if (memes.length) {
        const liste = memes.map(m => `<li><b>${esc(m.nom_complet)}</b> — ${esc(m.distinction)} — ` +
          `${m.biens.length ? esc(m.biens.join(", ")) : "aucun bien"}</li>`).join("");
        const choix = await demanderChoix("Un propriétaire porte déjà ce nom",
          `<p>Déjà enregistré :</p><ul>${liste}</ul><p>Est-ce la même personne ?</p>`,
          [{ cle: "meme", libelle: "Oui, la même personne" }, { cle: "autre", libelle: "Non, une autre personne", classe: "primary" }]);
        if (!choix) return;
        if (choix === "meme") {
          toast(ancien ? "Pour regrouper les deux fiches, utilisez le bouton « Fusionner »."
                       : "Rien n'a été créé : choisissez sa fiche existante dans la liste du bien.", 7000);
          goBack();
          return;
        }
        if (!corps.telephone.trim() && !corps.cni.trim())
          throw new Error("Indiquez son téléphone ou sa CNI : c'est ce qui le distinguera de l'autre dans les listes.");
      }
    }
    if (proprioEnCours) {
      await api(`/api/proprietaires/${proprioEnCours}`, { method: "PUT", body: corps });
    } else {
      const rep = await api("/api/proprietaires", { method: "POST", body: corps });
      await piecesProprio.envoyerEnAttente({ proprietaire_id: rep.id });
    }
    toast("Propriétaire enregistré");
    goBack();
  });
});

// « Adéyémi  Babatoundé » → « adeyemi babatounde » (comme cle_nom côté serveur)
function cleNom(nom) {
  return sansAccents(nom).replace(/[^a-z0-9]+/g, " ").trim();
}
function homonyme(p) {
  return propriosCache.some(a => a.id !== p.id && cleNom(a.nom_complet) === cleNom(p.nom_complet));
}

// Même personne enregistrée deux fois : tout passe sur la fiche choisie, puis la fiche vide est supprimée (Admin)
async function fusionnerProprietaire(id) {
  const p = propriosCache.find(x => x.id === id);
  if (!p) return;
  const autres = propriosCache.filter(x => x.id !== id)
    .sort((a, b) => (cleNom(b.nom_complet) === cleNom(p.nom_complet)) - (cleNom(a.nom_complet) === cleNom(p.nom_complet))
                    || a.nom_complet.localeCompare(b.nom_complet));
  const options = autres.map(a => `<option value="${a.id}">${esc(a.nom_complet)}${a.telephone ? " — tél. " + esc(a.telephone) : ""}` +
    ` (${a.cites.length} bien${a.cites.length > 1 ? "s" : ""})</option>`).join("");
  const choix = await demanderChoix("Fusionner deux fiches",
    `<p>Les biens, mandats, RIB, reversements et pièces jointes de <b>${esc(p.nom_complet)}</b>` +
    `${p.telephone ? " (tél. " + esc(p.telephone) + ")" : ""} passeront sur la fiche choisie ci-dessous, ` +
    `puis sa fiche, devenue vide, sera supprimée. À faire seulement s'il s'agit de la même personne.</p>` +
    `<div class="field"><label for="fusionCible">Garder la fiche de</label><select id="fusionCible">${options}</select></div>`,
    [{ cle: "ok", libelle: "Continuer", classe: "primary" }]);
  if (choix !== "ok") return;
  const cible = autres.find(a => a.id === Number(el("fusionCible").value));
  const mdp = await demanderMotDePasseAdmin(
    `« ${p.nom_complet} » (${pluriel(p.cites.length, "bien")}) sera regroupé avec « ${cible.nom_complet} ». ` +
    "Entrez votre mot de passe Admin pour confirmer.", { titre: "Fusionner deux fiches", bouton: "Fusionner" });
  if (mdp === null) return;
  try {
    const rep = await api(`/api/proprietaires/${id}/fusionner`, { method: "POST", body: { vers_id: cible.id, mot_de_passe_admin: mdp } });
    toast(`Fiches regroupées : ${pluriel(rep.biens, "bien")} rattaché${rep.biens > 1 ? "s" : ""} à ${rep.vers}`);
    chargerProprios();
  } catch (e) { toast(e.message); }
}

function supprimerProprietaire(id) {
  const p = propriosCache.find(p => p.id === id);
  supprimerAvecConfirmation(
    `Supprimer le propriétaire « ${p ? p.nom_complet : ""} » ? Entrez votre mot de passe Admin pour confirmer.`,
    `/api/proprietaires/${id}/supprimer`, chargerProprios);
}

brancherRecherche(el("rechercheBiens"), el("listeBiens"));
brancherRecherche(el("rechercheProprios"), el("listeProprios"));
