// Suivi à distance par l'éditeur (suivi.py) : erreurs d'écran notées sans données, bouton « Signaler un
// problème » (tous les profils) et réglage de l'Admin dans Paramètres → À propos.

const ecranCourant = () => (typeof screenHistory !== "undefined" && screenHistory.length ? String(screenHistory[screenHistory.length - 1]) : "accueil");

// ---------- Erreurs d'écran (au plus 5 par page ouverte ; le serveur retire le reste et limite aussi) ----------
let erreursEcranEnvoyees = 0;
function noterErreurEcran(message, source, ligne, colonne, pile) {
  if (!moi || erreursEcranEnvoyees >= 5) return;
  if (source && !source.includes(location.host)) return;  // extension du navigateur : pas Gérimo
  erreursEcranEnvoyees++;
  fetch("/api/suivi/erreur-ecran", { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message: String(message || "").slice(0, 2000), source: String(source || "").slice(0, 300),
                           ligne: ligne || 0, colonne: colonne || 0, pile: String(pile || "").slice(0, 6000), ecran: ecranCourant() }) })
    .catch(() => {});
}
window.addEventListener("error", e => {
  if (e.error || e.message) noterErreurEcran(e.message, e.filename, e.lineno, e.colno, e.error && e.error.stack);
});
window.addEventListener("unhandledrejection", e => {
  const r = e.reason;  // seules les vraies erreurs de programme (pas « Montant invalide »)
  if (r instanceof TypeError || r instanceof ReferenceError || r instanceof SyntaxError || r instanceof RangeError)
    noterErreurEcran(`${r.name}: ${r.message}`, (/(https?:\/\/[^\s)]+\.js)/.exec(r.stack || "") || [])[1] || "", 0, 0, r.stack);
});

// ---------- Signaler un problème ----------
function signalerProbleme() {
  if (typeof closeMenu === "function") closeMenu();
  const ecran = ecranCourant();
  const f = ouvrirFenetre(`<form id="formSignalerProbleme" novalidate>
    <div class="modal-tete"><h3>Signaler un problème</h3><button type="button" class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <p class="petit">Votre message part chez le maintenancier de Gérimo, avec la version du logiciel et votre profil.
      N'y écrivez pas les noms ou numéros de vos locataires et propriétaires : décrivez ce que vous faisiez et ce qui s'est passé.</p>
    <div class="field"><label for="suiviDescription">Que s'est-il passé ?</label>
      <textarea id="suiviDescription" rows="5" maxlength="3000" placeholder="Ex. : en encaissant un loyer de 3 mois, le reçu ne s'est pas ouvert."></textarea></div>
    <div class="fgrid">
      <div class="field"><label for="suiviNom">À rappeler (facultatif)</label><input id="suiviNom" maxlength="120" value="${esc(moi ? moi.nom_complet : "")}"></div>
      <div class="field"><label for="suiviTel">Téléphone (facultatif)</label><input id="suiviTel" maxlength="40" inputmode="tel"></div>
    </div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button type="button" class="btn" data-fermer>Annuler</button><button type="submit" class="btn primary">Envoyer</button></div>
  </form>`);
  setTimeout(() => el("suiviDescription").focus(), 50);
  f.querySelector("form").addEventListener("submit", async e => {
    e.preventDefault();
    const erreur = f.querySelector(".form-erreur");
    const description = el("suiviDescription").value.trim();
    if (description.length < 10) { erreur.textContent = "Décrivez le problème en quelques mots."; return; }
    const bouton = f.querySelector("button[type=submit]");
    bouton.disabled = true;
    try {
      const rep = await api("/api/suivi/signaler", { method: "POST", body: { description, ecran,
        rappel_nom: el("suiviNom").value.trim(), rappel_telephone: el("suiviTel").value.trim() } });
      f.fermer();
      toast(rep.message, 7000);
    } catch (err) { erreur.textContent = err.message; bouton.disabled = false; }
  });
}

// ---------- Paramètres → À propos : carte « Suivi par l'éditeur » (Admin) ----------
async function carteSuivi() {
  let s;
  try { s = await api("/api/suivi"); } catch { return ""; }
  const a = s.apercu;
  const profils = Object.entries(a.details.comptes_par_profil || {}).map(([p, n]) => `${esc(p)} : ${n}`).join(", ");
  return `<div class="card" id="carteSuivi">
    <h3>Suivi par l'éditeur</h3>
    <p class="petit">Une fois par jour, Gérimo envoie à son éditeur un court bilan, pour la maintenance et le suivi des licences.
      Aucune donnée de vos locataires, propriétaires, biens ou montants n'est envoyée.</p>
    <div class="row"><span class="who">Ce qui est envoyé : <b>${esc(a.entreprise || "(nom non saisi)")}</b>, ${esc(a.ville || "ville non saisie")}${a.details.telephone ? `, tél. ${esc(a.details.telephone)}` : ""},
      version ${esc(a.version)}, licence ${esc(a.licence)}, ${a.comptes} compte${a.comptes > 1 ? "s" : ""} (${profils || "aucun"}),
      ${a.actifs_jour} personne${a.actifs_jour > 1 ? "s" : ""} active${a.actifs_jour > 1 ? "s" : ""} aujourd'hui, ${a.actifs_30j} sur 30 jours.
      <br><span class="petit">${s.configure ? (s.dernier_envoi ? `Dernier envoi : ${esc(s.dernier_envoi)}.` : "Pas encore d'envoi.") : "Suivi pas encore mis en service par l'éditeur."}
      ${s.en_attente ? ` ${s.en_attente} envoi${s.en_attente > 1 ? "s" : ""} en attente d'Internet.` : ""}</span></span></div>
    <div class="row"><label class="who" style="display:flex;gap:10px;align-items:flex-start;cursor:pointer">
      <input type="checkbox" id="suiviBugsAuto" ${s.bugs_auto ? "checked" : ""} onchange="reglerBugsAuto(this.checked)" style="margin-top:4px">
      <span>Envoyer aussi les rapports d'erreurs automatiques<br><span class="petit">Quand le logiciel rencontre une erreur imprévue,
      l'endroit du programme concerné est envoyé à l'éditeur pour qu'il la corrige, sans les valeurs saisies.</span></span></label></div>
    <div class="pj-boutons"><button class="btn" onclick="signalerProbleme()">Signaler un problème</button></div>
  </div>`;
}

async function reglerBugsAuto(actif) {
  try {
    await api("/api/suivi/bugs-auto", { method: "PUT", body: { actif } });
    toast(actif ? "Les rapports d'erreurs seront envoyés à l'éditeur." : "Les rapports d'erreurs automatiques ne seront plus envoyés.");
  } catch (e) { toast(e.message); el("suiviBugsAuto").checked = !actif; }
}
