// Mode veille et mot de passe personnel (veille.py, utilisateurs.py) — 12/10/2026.
// - Veille : bouton de la barre du haut et du menu, Ctrl + L, ou tout seul après un temps sans activité (PC).
//   Écran : logo de l'entreprise, logo Gérimo animé, heure et date, nom de l'utilisateur ; aucune donnée.
//   Le serveur refuse tout (423) tant que le mot de passe n'est pas retapé : recharger la page ne sert à rien.
// - Mot de passe provisoire (donné par l'Admin) : l'employé choisit le sien avant toute autre chose.
// Hors réseau (copie sur l'appareil, déjà ouverte par le mot de passe) : ni veille ni contrôle du serveur.

const VEILLE_HORS_RESEAU = !!window.horsReseauPret;
const CLE_ACTIVITE = "gerimo_derniere_activite";   // partagée entre onglets : un onglet oublié ne verrouille pas l'autre
let veilleInfos = null;          // { nom, role } de la session en veille
let derniereActivite = Date.now();
let dernierSignal = 0;           // dernier « je suis là » envoyé au serveur
let horlogeVeille = null;

function lireActivite() {
  try { return Math.max(derniereActivite, Number(localStorage.getItem(CLE_ACTIVITE)) || 0); }
  catch { return derniereActivite; }
}

// ---------- Blocages renvoyés par le serveur ----------
function gererBlocage(detail) {
  if (detail.code === "veille") afficherVeille(detail);
  else if (detail.code === "mdp_a_changer") afficherChoixMotDePasse(detail);
}

// ---------- Écran de veille ----------
function ecranVeille() {
  let e = document.getElementById("ecranVeille");
  if (e) return e;
  e = document.createElement("div");
  e.id = "ecranVeille";
  e.className = "veille";
  e.setAttribute("role", "dialog");
  e.setAttribute("aria-modal", "true");
  e.setAttribute("aria-label", "Gérimo en veille");
  e.innerHTML = `
    <div class="veille-fond"></div><div class="veille-teinte"></div>
    <div class="veille-haut">
      <div class="veille-entreprise" role="img" aria-label="Logo de l'entreprise"></div>
      <div class="veille-qui"><span class="veille-initiale"></span><span><b class="veille-nom"></b><small class="veille-role"></small></span></div>
    </div>
    <div class="veille-centre">
      <div class="veille-gerimo" role="img" aria-label="Gérimo"></div>
      <div class="veille-heure"></div>
      <div class="veille-date"></div>
    </div>
    <form class="veille-reveil" autocomplete="off">
      <label for="veilleMdp">Mot de passe de <b class="veille-nom"></b></label>
      <input type="password" id="veilleMdp" autocomplete="current-password" required>
      <div class="veille-erreur" role="alert"></div>
      <button type="submit" class="btn primary">Reprendre</button>
      <button type="button" class="veille-pas-moi">Ce n'est pas moi : se déconnecter</button>
    </form>
    <div class="veille-aide">Touchez l'écran ou appuyez sur une touche pour reprendre</div>`;
  document.body.appendChild(e);
  const form = e.querySelector(".veille-reveil");
  const montrerFormulaire = () => {
    if (e.classList.contains("saisie")) return;
    e.classList.add("saisie");
    setTimeout(() => el("veilleMdp").focus(), 50);
  };
  e.addEventListener("pointerdown", ev => { if (!form.contains(ev.target)) montrerFormulaire(); });
  e.addEventListener("keydown", ev => {
    if (ev.key === "Escape") { e.classList.remove("saisie"); form.querySelector(".veille-erreur").textContent = ""; return; }
    if (!form.contains(ev.target)) montrerFormulaire();
  });
  form.addEventListener("submit", async ev => {
    ev.preventDefault();
    const erreur = form.querySelector(".veille-erreur");
    const bouton = form.querySelector("button[type=submit]");
    erreur.textContent = "";
    bouton.disabled = true;
    try {
      const rep = await fetch("/api/veille/reveiller", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mot_de_passe: el("veilleMdp").value }) });
      const d = await rep.json().catch(() => ({}));
      if (rep.status === 401) { window.location.replace("/connexion"); return; }
      if (!rep.ok) { erreur.textContent = typeof d.detail === "string" ? d.detail : "Mot de passe incorrect."; el("veilleMdp").select(); return; }
      cacherVeille();
    } catch { erreur.textContent = "Le serveur ne répond pas."; }
    finally { bouton.disabled = false; }
  });
  form.querySelector(".veille-pas-moi").addEventListener("click", async () => {
    try { await fetch("/api/deconnexion", { method: "POST" }); } finally { window.location.replace("/connexion"); }
  });
  return e;
}

function majHorlogeVeille() {
  const e = document.getElementById("ecranVeille");
  if (!e) return;
  const t = new Date();
  e.querySelector(".veille-heure").textContent = t.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  const jour = t.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  e.querySelector(".veille-date").textContent = jour.charAt(0).toUpperCase() + jour.slice(1);
}

function afficherVeille(infos = {}) {
  veilleInfos = { nom: infos.nom || (moi && moi.nom_complet) || "", role: infos.role || (moi && moi.role) || "" };
  const e = ecranVeille();
  e.querySelectorAll(".veille-nom").forEach(n => { n.textContent = veilleInfos.nom; });
  e.querySelector(".veille-role").textContent = veilleInfos.role ? `Profil ${veilleInfos.role}` : "";
  e.querySelector(".veille-initiale").textContent = (veilleInfos.nom || "?").trim().charAt(0).toUpperCase();
  e.querySelector(".veille-erreur").textContent = "";
  el("veilleMdp").value = "";
  e.classList.remove("saisie");
  if (typeof closeMenu === "function") closeMenu();
  majHorlogeVeille();
  clearInterval(horlogeVeille);
  horlogeVeille = setInterval(majHorlogeVeille, 10000);
  e.classList.add("show");
  document.body.classList.add("en-veille");
  e.tabIndex = -1;
  e.focus();
}

function cacherVeille() {
  const e = document.getElementById("ecranVeille");
  if (e) e.classList.remove("show", "saisie");
  document.body.classList.remove("en-veille");
  clearInterval(horlogeVeille);
  veilleInfos = null;
  noterActivite(true);
  if (!moi) window.location.reload();  // page ouverte pendant la veille : on la charge maintenant
}

async function mettreEnVeille() {
  if (VEILLE_HORS_RESEAU || veilleInfos) return;
  try { await fetch("/api/veille", { method: "POST" }); } catch { /* serveur muet : l'écran se verrouille quand même */ }
  afficherVeille();
}

// ---------- Activité : la veille automatique recule ----------
function noterActivite(forcer = false) {
  if (VEILLE_HORS_RESEAU || veilleInfos) return;
  derniereActivite = Date.now();
  try { localStorage.setItem(CLE_ACTIVITE, String(derniereActivite)); } catch { /* navigation privée */ }
  if (!forcer && derniereActivite - dernierSignal < 60000) return;
  dernierSignal = derniereActivite;
  fetch("/api/activite", { method: "POST" }).then(async r => {
    if (r.status === 423) { const d = await r.json().catch(() => ({})); if (d.detail && d.detail.code) gererBlocage(d.detail); }
  }).catch(() => {});
}

if (!VEILLE_HORS_RESEAU) {
  ["pointerdown", "keydown", "wheel", "touchstart"].forEach(t => document.addEventListener(t, () => noterActivite(), { passive: true, capture: true }));
  let dernierMouvement = 0;
  document.addEventListener("pointermove", () => {
    const n = Date.now();
    if (n - dernierMouvement > 5000) { dernierMouvement = n; noterActivite(); }
  }, { passive: true });
  // Ctrl + L : veille tout de suite
  document.addEventListener("keydown", e => {
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && e.key.toLowerCase() === "l") {
      e.preventDefault();
      mettreEnVeille();
    }
  });
  setInterval(() => {
    const minutes = moi && moi.veille_minutes;
    if (!minutes || veilleInfos) return;
    if (Date.now() - lireActivite() > minutes * 60000) mettreEnVeille();
  }, 20000);
}

// ---------- Choisir son mot de passe (provisoire donné par l'Admin) ----------
function afficherChoixMotDePasse(infos) {
  if (document.getElementById("ecranMdp")) return;
  const e = document.createElement("div");
  e.id = "ecranMdp";
  e.className = "veille show saisie mdp-perso";
  e.setAttribute("role", "dialog");
  e.setAttribute("aria-modal", "true");
  e.setAttribute("aria-label", "Choisissez votre mot de passe");
  e.innerHTML = `
    <div class="veille-fond"></div><div class="veille-teinte"></div>
    <div class="veille-haut"><div class="veille-entreprise" role="img" aria-label="Logo de l'entreprise"></div></div>
    <form class="veille-reveil" autocomplete="off">
      <div class="veille-gerimo petit" role="img" aria-label="Gérimo"></div>
      <h2>Bienvenue ${esc(infos.nom || "")}</h2>
      <p class="mdp-raison">${infos.redonne
        ? `Votre mot de passe a été réinitialisé par ${esc(infos.redonne.par)} le ${esc(infos.redonne.le)}.`
        : "Le mot de passe que l'Admin vous a donné ne sert qu'une fois."}
        Choisissez maintenant le vôtre : personne d'autre, pas même l'Admin, ne le connaîtra. C'est ce qui garantit
        que ce qui est fait sous votre nom vient bien de vous.</p>
      <label for="mdpPerso1">Nouveau mot de passe</label>
      <input type="password" id="mdpPerso1" autocomplete="new-password" required>
      <label for="mdpPerso2">Retapez-le</label>
      <input type="password" id="mdpPerso2" autocomplete="new-password" required>
      <small class="mdp-regle">8 caractères minimum, avec au moins une lettre et un chiffre.</small>
      <div class="veille-erreur" role="alert"></div>
      <button type="submit" class="btn primary">Enregistrer mon mot de passe</button>
      <button type="button" class="veille-pas-moi">Se déconnecter</button>
    </form>`;
  document.body.appendChild(e);
  document.body.classList.add("en-veille");
  const form = e.querySelector("form");
  setTimeout(() => el("mdpPerso1").focus(), 50);
  form.addEventListener("submit", async ev => {
    ev.preventDefault();
    const erreur = form.querySelector(".veille-erreur");
    const nouveau = el("mdpPerso1").value;
    erreur.textContent = "";
    if (nouveau !== el("mdpPerso2").value) { erreur.textContent = "Les deux mots de passe ne correspondent pas."; return; }
    if (nouveau.length < 8 || !/\d/.test(nouveau) || !/\p{L}/u.test(nouveau)) { erreur.textContent = "8 caractères minimum, avec au moins une lettre et un chiffre."; return; }
    const bouton = form.querySelector("button[type=submit]");
    bouton.disabled = true;
    try {
      const rep = await fetch("/api/moi/mot-de-passe", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ancien: "", nouveau }) });
      const d = await rep.json().catch(() => ({}));
      if (rep.status === 401) { window.location.replace("/connexion"); return; }
      if (!rep.ok) { erreur.textContent = typeof d.detail === "string" ? d.detail : "Mot de passe refusé."; return; }
      // hors réseau : la copie s'ouvrira avec le nouveau mot de passe
      const pont = (window.ISUPAndroid && window.ISUPAndroid.memoriserConnexion ? window.ISUPAndroid : null) || window.GerimoPont;
      if (pont && infos.identifiant) await Promise.resolve(pont.memoriserConnexion(infos.identifiant, nouveau)).catch(() => {});
      window.location.reload();
    } catch { erreur.textContent = "Le serveur ne répond pas."; }
    finally { bouton.disabled = false; }
  });
  form.querySelector(".veille-pas-moi").addEventListener("click", async () => {
    try { await fetch("/api/deconnexion", { method: "POST" }); } finally { window.location.replace("/connexion"); }
  });
}

// ---------- Après la connexion : dernière connexion, conseil pour un téléphone sans code ----------
document.addEventListener("DOMContentLoaded", () => {
  if (VEILLE_HORS_RESEAU) {
    document.querySelectorAll(".btn-veille").forEach(b => { b.style.display = "none"; });
    return;
  }
  let derniere = null;
  try {
    derniere = JSON.parse(sessionStorage.getItem("gerimo_derniere_connexion") || "null");
    sessionStorage.removeItem("gerimo_derniere_connexion");
  } catch { derniere = null; }
  if (derniere && derniere.quand) {
    setTimeout(() => toast(`Votre dernière connexion : le ${derniere.quand}${derniere.appareil ? " (" + derniere.appareil + ")" : ""}. `
      + "Si ce n'était pas vous, changez votre mot de passe.", 9000), 1500);
  }
  const android = window.ISUPAndroid;
  if (android && android.ecranSecurise) {
    let conseille = false;
    try { conseille = localStorage.getItem("gerimo_conseil_code") === "1"; } catch { conseille = true; }
    if (!conseille && !android.ecranSecurise()) {
      setTimeout(() => {
        alert("Conseil de sécurité : ce téléphone n'a pas de code de verrouillage.\n\nMettez un code, un schéma ou une "
          + "empreinte (Paramètres du téléphone → Sécurité) : Gérimo n'aura alors plus besoin de se mettre en veille "
          + "tout seul, et personne ne pourra l'ouvrir si vous perdez le téléphone.");
        try { localStorage.setItem("gerimo_conseil_code", "1"); } catch { /* rien */ }
      }, 2500);
    }
  }
});
