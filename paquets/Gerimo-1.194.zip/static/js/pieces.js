// Pièces jointes (CNI, passeport…) des propriétaires et locataires : fichier ou photo.
// Avant le premier enregistrement (nouveau locataire), les pièces attendent dans la page,
// puis sont envoyées dès que la fiche existe.

let TYPES_PIECE = ["CNI", "Passeport", "Attestation d'identité", "Autre"];
api("/api/pieces/types").then(t => { TYPES_PIECE = t; document.querySelectorAll(".pj-zone").forEach(remplirTypes); }).catch(() => {});

function remplirTypes(zone) {
  const sel = zone.querySelector(".pj-type");
  const valeur = sel.value;
  sel.innerHTML = TYPES_PIECE.map(t => `<option>${esc(t)}</option>`).join("");
  if (valeur) sel.value = valeur;
}

class ZonePieces {
  constructor(id) {
    this.zone = el(id);
    this.titulaire = null;     // { proprietaire_id } ou { locataire_id }
    this.enAttente = [];       // pièces pas encore envoyées
    this.pieces = [];          // pièces déjà enregistrées
    remplirTypes(this.zone);
    this.zone.querySelector('[data-pj="fichier"]').addEventListener("click", async () => {
      for (const f of await choisirFichiers()) await this.ajouter(f);
    });
    this.zone.querySelector('[data-pj="photo"]').addEventListener("click", async () => {
      const f = await prendrePhoto();
      if (f) await this.ajouter(f);
    });
  }

  async ouvrir(titulaire) {
    this.titulaire = titulaire;
    this.enAttente = [];
    this.pieces = [];
    this.zone.querySelector(".pj-type").value = "CNI";
    this.afficher();
    if (!titulaire) return;
    try {
      this.pieces = await api("/api/pieces?" + new URLSearchParams(titulaire));
    } catch (e) { toast(e.message); }
    this.afficher();
  }

  async ajouter(fichier) {
    const type_piece = this.zone.querySelector(".pj-type").value || "CNI";
    if (!this.titulaire) {
      this.enAttente.push({ ...fichier, type_piece });
      this.afficher();
      return;
    }
    try {
      const piece = await api("/api/pieces", { method: "POST", body: { ...this.titulaire, type_piece, nom_fichier: fichier.nom, contenu: fichier.contenu } });
      this.pieces.push(piece);
      this.afficher();
      toast(`${type_piece} ajoutée`);
    } catch (e) { toast(e.message); }
  }

  // Après la création de la fiche : envoi des pièces en attente
  async envoyerEnAttente(titulaire) {
    this.titulaire = titulaire;
    let erreurs = 0;
    for (const f of this.enAttente) {
      try {
        await api("/api/pieces", { method: "POST", body: { ...titulaire, type_piece: f.type_piece, nom_fichier: f.nom, contenu: f.contenu } });
      } catch { erreurs++; }
    }
    if (erreurs) toast(`${erreurs} pièce(s) jointe(s) non enregistrée(s) : réessayez depuis la fiche.`, 6000);
    this.enAttente = [];
  }

  afficher() {
    const vignette = (p, i, attente) => {
      const estPdf = attente ? p.estPdf : p.type_mime === "application/pdf";
      const url = attente ? p.apercu : p.url;
      const image = estPdf ? `<div class="pj-pdf" ${attente ? "" : `onclick="window.open('${url}','_blank')"`}>PDF</div>`
                           : `<img src="${esc(url)}" alt="" onclick="visionneuse('${esc(url)}', '${esc(p.type_piece)}')">`;
      const suppr = attente ? `<button type="button" class="pj-suppr" data-tip="Retirer" data-attente="${i}">✕</button>`
                            : (estAdmin() ? `<button type="button" class="pj-suppr" data-tip="Supprimer (Admin)" data-piece="${p.id}">✕</button>` : "");
      return `<div class="pj">${image}${suppr}<div class="pj-nom" title="${esc(p.nom_fichier || p.nom)}"><b>${esc(p.type_piece)}</b>${attente ? " — à enregistrer" : ""}</div></div>`;
    };
    const liste = this.zone.querySelector(".pj-liste");
    liste.innerHTML = this.pieces.map((p, i) => vignette(p, i, false)).join("") + this.enAttente.map((p, i) => vignette(p, i, true)).join("");
    liste.querySelectorAll("[data-attente]").forEach(b => b.onclick = () => { this.enAttente.splice(Number(b.dataset.attente), 1); this.afficher(); });
    liste.querySelectorAll("[data-piece]").forEach(b => b.onclick = () => {
      const piece = this.pieces.find(p => p.id === Number(b.dataset.piece));
      supprimerAvecConfirmation(`Supprimer la pièce « ${piece.type_piece} » ? Entrez votre mot de passe Admin pour confirmer.`,
        `/api/pieces/${piece.id}/supprimer`, () => this.ouvrir(this.titulaire));
    });
  }
}

const piecesProprio = new ZonePieces("pjProprio");
const piecesLocataire = new ZonePieces("pjLocataire");
const piecesContrat = new ZonePieces("pjContrat");
