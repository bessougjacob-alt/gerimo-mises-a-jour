// Précomptabilité, partie 1 : la trésorerie (Admin, Caisse, Comptable).
// Soldes des caisses, banques et comptes Mobile Money ; journal ; transferts ; arrêtés de caisse ; comptes (Admin).
// Les entrées et sorties viennent des encaissements, dépenses et achats/ventes : rien n'est ressaisi.
// Le serveur revérifie tous les droits.

let tresorerieCache = null;
let ongletTresorerie = "trSoldes";
let comptesActifsCache = [];

// ---------- Choix du compte dans les formulaires (encaissement, dépense, achat/vente) ----------

async function preparerChoixCompte(idMode, idCompte, valeur = null) {
  try { comptesActifsCache = await api("/api/tresorerie/comptes-actifs"); } catch { comptesActifsCache = []; }
  const select = el(idCompte);
  select.closest(".field").style.display = comptesActifsCache.length ? "" : "none";
  remplirSelect(select, comptesActifsCache, { valeur: c => c.id, texte: c => `${c.nom} (${c.type_compte})`, vide: "— Aucun compte —" });
  const selonMode = () => {
    const c = comptesActifsCache.find(x => x.modes_paiement.includes(el(idMode).value));
    select.value = c ? c.id : "";
  };
  if (!select.dataset.branche) {  // le compte suit le mode de paiement choisi
    el(idMode).addEventListener("change", selonMode);
    select.dataset.branche = "1";
  }
  if (valeur && comptesActifsCache.some(c => c.id === valeur)) select.value = valeur;
  else selonMode();
}
function compteChoisi(idCompte) {
  const v = el(idCompte).value;
  return v ? Number(v) : null;
}

// ---------- Onglets ----------

function montrerOngletTresorerie(id) {
  if (id === "trComptes" && !estAdmin()) id = "trSoldes";
  ongletTresorerie = id;
  document.querySelectorAll("#ongletsTresorerie .onglet").forEach(b => b.classList.toggle("actif", b.dataset.onglet === id));
  ["trSoldes", "trJournal", "trTransferts", "trArretes", "trReversements", "trCarnet", "trRapprochement", "trComptes"]
    .forEach(z => { el(z).style.display = z === id ? "" : "none"; });
  ({ trSoldes: chargerTresorerie, trJournal: chargerJournalTresorerie, trTransferts: chargerTransferts,
     trArretes: chargerArretes, trReversements: chargerReversements, trCarnet: chargerBeneficiaires,
     trRapprochement: chargerRapprochement,
     trComptes: chargerComptesTresorerie })[id]();
}
el("ongletsTresorerie").addEventListener("click", e => {
  const b = e.target.closest(".onglet");
  if (b) montrerOngletTresorerie(b.dataset.onglet);
});
CHARGEURS.tresorerie = () => montrerOngletTresorerie(ongletTresorerie);

async function donneesTresorerie() {
  tresorerieCache = await api("/api/tresorerie");
  return tresorerieCache;
}
const comptesOuverts = () => (tresorerieCache?.comptes || []).filter(c => c.actif);
const classeMontant = n => n < 0 ? ' style="color:var(--danger)"' : "";

// ---------- Soldes ----------

const ICONE_TYPE = { "Caisse": "argent", "Banque": "maison", "Mobile Money": "telephone" };

async function chargerTresorerie() {
  const zone = el("trSoldes");
  let t;
  try { t = await donneesTresorerie(); }
  catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  const ouverts = t.comptes.filter(c => c.actif);
  const nr = t.non_ranges;
  zone.innerHTML = `
    <div class="kpis">
      <div class="kpi ok"><div class="label">Trésorerie totale</div><div class="value"${classeMontant(t.total)}>${formatMontant(t.total)}</div></div>
      ${ouverts.map(c => `<div class="kpi info cliquable" onclick="voirJournalCompte(${c.id})" data-tip="Voir le journal de ce compte">
        <div class="label">${esc(c.nom)} <span class="petit">· ${esc(c.type_compte)}</span></div>
        <div class="value"${classeMontant(c.solde)}>${formatMontant(c.solde)}</div>
        <div class="sous-valeur">Aujourd'hui : +${formatMontant(c.entrees_jour)} / −${formatMontant(c.sorties_jour)}</div></div>`).join("")}
    </div>
    <div class="card"><h3>À qui appartient cet argent ?</h3>
      <div class="row"><span class="who">Dû aux propriétaires (loyers nets pas encore reversés)</span><b>${formatMontant(t.repartition.proprietaires)}</b></div>
      ${t.repartition.vendeurs ? `<div class="row"><span class="who">Dû aux vendeurs (ventes faites en intermédiaire)</span><b>${formatMontant(t.repartition.vendeurs)}</b></div>` : ""}
      <div class="row"><span class="who">Cautions des locataires (dépôts de garantie à rendre)</span><b>${formatMontant(t.repartition.cautions)}</b></div>
      <div class="row"><span class="who"><b>Reste à l'entreprise</b></span><b${classeMontant(t.repartition.entreprise)}>${formatMontant(t.repartition.entreprise)}</b></div>
      <div class="actions" style="justify-content:flex-start;margin-top:.4rem"><button class="btn" onclick="montrerOngletTresorerie('trReversements')">Voir les reversements à faire</button></div>
    </div>
    ${nr.nombre ? `<div class="card"><div class="row"><span class="who"><b>${nr.nombre} opération(s) rangée(s) dans aucun compte</b>
        <br><span class="petit">Entrées ${formatMontant(nr.entrees)} — sorties ${formatMontant(nr.sorties)}. Leur mode de paiement
        n'est associé à aucun compte${estAdmin() ? " : associez-le dans l'onglet « Comptes »" : " (à régler par l'Admin)"}.</span></span>
      <span class="boutons"><button class="btn" onclick="voirJournalCompte('non_ranges')">Voir</button></span></div></div>` : ""}
    <div class="card"><h3>Comptes</h3>${t.comptes.map(c => `
      <div class="row">
        <span class="who">${svgIcone(ICONE_TYPE[c.type_compte]).replace("<svg", '<svg class="ico-ligne"')} <b>${esc(c.nom)}</b>${c.numero ? ` — ${esc(c.numero)}` : ""}
          <br><span class="petit">${esc(c.type_compte)}${c.modes_paiement.length ? " — reçoit d'office : " + c.modes_paiement.map(esc).join(", ") : ""}
          — suivi depuis le ${formatDate(c.date_ouverture)}${c.dernier_arrete ? ` — dernier arrêté : ${formatDate(c.dernier_arrete.date)}
          (écart ${formatMontant(c.dernier_arrete.ecart)})` : ""}</span></span>
        <span class="boutons">${c.actif ? "" : '<span class="pill">Fermé</span>'}<b${classeMontant(c.solde)}>${formatMontant(c.solde)}</b></span>
      </div>`).join("") || '<div class="vide">Aucun compte.</div>'}</div>`;
}

function voirJournalCompte(compte) {
  montrerOngletTresorerie("trJournal");
  el("trjCompte").value = String(compte);
  chargerJournalTresorerie();
}

// ---------- Journal ----------

async function chargerJournalTresorerie() {
  const form = el("formulaireJournalTresorerie");
  if (!tresorerieCache) { try { await donneesTresorerie(); } catch (e) { erreurFormulaire(form, e.message); return; } }
  const choisi = el("trjCompte").value || "tous";
  el("trjCompte").innerHTML = `<option value="tous">Tous les comptes</option>` +
    tresorerieCache.comptes.map(c => `<option value="${c.id}">${esc(c.nom)}</option>`).join("") +
    `<option value="non_ranges">Opérations non rangées</option>`;
  el("trjCompte").value = choisi;
  if (!el("trjDebut").value) fixerDate("trjDebut", aujourdhui().slice(0, 8) + "01");
  if (!el("trjFin").value) fixerDate("trjFin", aujourdhui());
  let filtres;
  try {
    filtres = new URLSearchParams({ compte: el("trjCompte").value });
    const debut = valeurDate("trjDebut", "Du"), fin = valeurDate("trjFin", "Au");
    if (debut) filtres.set("debut", debut);
    if (fin) filtres.set("fin", fin);
  } catch (e) { erreurFormulaire(form, e.message); return; }
  erreurFormulaire(form, "");
  let j;
  try { j = await api(`/api/tresorerie/journal?${filtres}`); }
  catch (e) { el("listeJournalTresorerie").innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  const tous = el("trjCompte").value === "tous", nonRanges = el("trjCompte").value === "non_ranges";
  el("listeJournalTresorerie").innerHTML = `
    <div class="kpis">
      ${nonRanges ? "" : `<div class="kpi"><div class="label">Solde au ${formatDate(j.debut)} (début de journée)</div><div class="value">${formatMontant(j.solde_debut)}</div></div>`}
      <div class="kpi ok"><div class="label">Entrées</div><div class="value">${formatMontant(j.entrees)}</div></div>
      <div class="kpi warn"><div class="label">Sorties</div><div class="value">${formatMontant(j.sorties)}</div></div>
      ${nonRanges ? "" : `<div class="kpi info"><div class="label">Solde au ${formatDate(j.fin)} (fin de journée)</div><div class="value"${classeMontant(j.solde_fin)}>${formatMontant(j.solde_fin)}</div></div>`}
    </div>
    ${tous ? '<p class="petit">Vue de tous les comptes : les transferts d\'un compte à l\'autre sont listés mais ne comptent ni dans les entrées ni dans les sorties.</p>' : ""}
    ${j.lignes.length ? `<div class="card"><div style="overflow-x:auto"><table class="tableau">
      <tr><th>Date</th><th>Opération</th>${tous || nonRanges ? "<th>Compte</th>" : ""}<th style="text-align:right">Entrée</th><th style="text-align:right">Sortie</th>${nonRanges ? "" : '<th style="text-align:right">Solde</th>'}</tr>
      ${j.lignes.map(l => `<tr><td style="white-space:nowrap">${formatDate(l.date)}</td>
        <td>${esc(l.libelle)}${l.reference ? `<br><span class="petit">${esc(l.reference)}</span>` : ""}</td>
        ${tous || nonRanges ? `<td>${esc(l.compte)}</td>` : ""}
        <td style="text-align:right;white-space:nowrap">${l.sens === "entree" ? formatMontant(l.montant) : ""}</td>
        <td style="text-align:right;white-space:nowrap">${l.sens === "sortie" ? formatMontant(l.montant) : ""}</td>
        ${nonRanges ? "" : `<td style="text-align:right;white-space:nowrap"${classeMontant(l.solde)}>${formatMontant(l.solde)}</td>`}</tr>`).join("")}
    </table></div></div>` : '<div class="card vide">Aucun mouvement sur cette période.</div>'}`;
}
el("formulaireJournalTresorerie").addEventListener("submit", e => { e.preventDefault(); chargerJournalTresorerie(); });

// ---------- Transferts ----------

async function chargerTransferts() {
  const zone = el("listeTransferts");
  let liste;
  try { liste = await api("/api/tresorerie/transferts"); }
  catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  zone.innerHTML = liste.length ? `<div class="card">${liste.map(t => `
    <div class="row">
      <span class="who"><b>${esc(t.source)} → ${esc(t.cible)}</b> — ${formatMontant(t.montant)}${t.frais ? ` (frais ${formatMontant(t.frais)})` : ""}
        <br><span class="petit">${esc(t.numero)}${t.libelle ? " — " + esc(t.libelle) : ""}${t.reference ? " — Réf. " + esc(t.reference) : ""}${t.saisi_par ? " — Saisie : " + esc(t.saisi_par) : ""}</span></span>
      <span class="boutons"><span class="pill info">${formatDate(t.date)}</span>
        ${estAdmin() ? ibtn("supprimer", "Supprimer ce transfert", `supprimerTransfert(${t.id}, '${esc(t.numero)}')`) : ""}</span>
    </div>`).join("")}</div>` : '<div class="card vide">Aucun transfert. Exemple : la recette de la caisse versée à la banque.</div>';
}

async function nouveauTransfert() {
  try { await donneesTresorerie(); } catch (e) { toast(e.message); return; }
  const ouverts = comptesOuverts();
  if (ouverts.length < 2) { toast("Il faut au moins deux comptes ouverts (l'Admin les crée dans l'onglet « Comptes »)."); return; }
  const options = { valeur: c => c.id, texte: c => `${c.nom} (solde ${formatMontant(c.solde)})` };
  remplirSelect(el("trfSource"), ouverts, options);
  remplirSelect(el("trfCible"), ouverts, options);
  el("trfCible").value = ouverts[1].id;
  ["trfMontant", "trfFrais", "trfReference", "trfLibelle"].forEach(id => { el(id).value = ""; });
  fixerDate("trfDate", aujourdhui());
  reinitialiserSaisie(el("formTransfert"));
  erreurFormulaire(el("formTransfert"), "");
  ouvrirModal("modalTransfert");
}

["trfMontant", "trfFrais", "arrMontant", "tcSolde"].forEach(id => el(id).addEventListener("blur", () => {
  const n = lireMontant(el(id).value.replace(/^-/, ""));
  if (n !== null) el(id).value = (el(id).value.trim().startsWith("-") ? "-" : "") + formatNombre(n);
}));

el("formTransfert").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (el("trfSource").value === el("trfCible").value) throw new Error("Choisissez deux comptes différents.");
    const somme = lireMontant(el("trfMontant").value);
    if (somme === null || somme <= 0) throw new Error("Indiquez un montant valide (ex : 200 000).");
    const frais = el("trfFrais").value.trim() ? lireMontant(el("trfFrais").value) : 0;
    if (frais === null) throw new Error("Vérifiez le montant des frais (ex : 500).");
    const jour = valeurDate("trfDate", "Date");
    if (!jour) throw new Error("Indiquez la date (jj/mm/aaaa).");
    const rep = await api("/api/tresorerie/transferts", { method: "POST", body: {
      date_transfert: jour, compte_source: Number(el("trfSource").value), compte_cible: Number(el("trfCible").value),
      montant: somme, frais, reference: el("trfReference").value, libelle: el("trfLibelle").value,
    } });
    fermerModal("modalTransfert");
    toast(`Transfert ${rep.numero} enregistré`);
    chargerTransferts();
  });
});

function supprimerTransfert(id, numero) {
  supprimerAvecConfirmation(`Supprimer le transfert ${numero} ? Les soldes des deux comptes seront recalculés. Mot de passe Admin.`,
    `/api/tresorerie/transferts/${id}/supprimer`, chargerTransferts);
}

// ---------- Arrêtés de caisse ----------

async function chargerArretes() {
  const zone = el("listeArretes");
  let liste;
  try { liste = await api("/api/tresorerie/arretes"); }
  catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  zone.innerHTML = liste.length ? `<div class="card"><div style="overflow-x:auto"><table class="tableau">
    <tr><th>Journée</th><th>Compte</th><th style="text-align:right">Calculé</th><th style="text-align:right">Compté</th><th style="text-align:right">Écart</th><th>Par</th><th></th></tr>
    ${liste.map(a => `<tr><td style="white-space:nowrap">${formatDate(a.date)}</td><td>${esc(a.compte)}</td>
      <td style="text-align:right;white-space:nowrap">${formatMontant(a.solde_calcule)}</td>
      <td style="text-align:right;white-space:nowrap">${formatMontant(a.solde_compte)}</td>
      <td style="text-align:right"><span class="pill ${a.ecart === 0 ? "ok" : "danger"}">${a.ecart > 0 ? "+" : ""}${formatMontant(a.ecart)}</span></td>
      <td>${esc(a.saisi_par)}${a.observation ? `<br><span class="petit">${esc(a.observation)}</span>` : ""}
        ${a.modifie_depuis ? `<br><span class="pill warn" data-tip="Une opération de cette journée (ou d'avant) a été ajoutée, modifiée ou supprimée après l'arrêté">Modifié depuis : solde recalculé ${formatMontant(a.solde_recalcule)}</span>` : ""}</td>
      <td>${estAdmin() ? ibtn("supprimer", "Supprimer cet arrêté", `supprimerArrete(${a.id})`) : ""}</td></tr>`).join("")}
  </table></div></div>` : '<div class="card vide">Aucun arrêté pour le moment.</div>';
}

let arreteEnCours = null;

async function nouvelArrete() {
  try { await donneesTresorerie(); } catch (e) { toast(e.message); return; }
  const ouverts = comptesOuverts();
  if (!ouverts.length) { toast("Aucun compte ouvert."); return; }
  remplirSelect(el("arrCompte"), ouverts, { valeur: c => c.id, texte: c => c.nom });
  const caisse = ouverts.find(c => c.type_compte === "Caisse");
  if (caisse) el("arrCompte").value = caisse.id;
  fixerDate("arrDate", aujourdhui());
  el("arrMontant").value = "";
  el("arrObservation").value = "";
  reinitialiserSaisie(el("formArrete"));
  erreurFormulaire(el("formArrete"), "");
  ouvrirModal("modalArrete");
  await preparerArrete();
}

async function preparerArrete() {
  let jour;
  try { jour = valeurDate("arrDate", "Journée"); } catch (e) { erreurFormulaire(el("formArrete"), e.message); return; }
  if (!jour) return;
  try { arreteEnCours = await api(`/api/tresorerie/arretes/preparer?compte_id=${el("arrCompte").value}&date=${jour}`); }
  catch (e) { erreurFormulaire(el("formArrete"), e.message); return; }
  erreurFormulaire(el("formArrete"), arreteEnCours.deja_fait ? "Cette journée est déjà arrêtée pour ce compte." : "");
  const a = arreteEnCours;
  el("arrRecap").innerHTML = `Journée du <b>${formatDate(a.date)}</b> — ${esc(a.compte)} : entrées ${formatMontant(a.entrees)},
    sorties ${formatMontant(a.sorties)} (${a.mouvements.length} opération(s)).<br>Solde calculé par Gérimo en fin de journée :
    <b>${formatMontant(a.solde_calcule)}</b>`;
  const especes = a.type_compte === "Caisse";
  el("arrMontantLibelle").textContent = especes ? "Argent compté (F CFA)" : "Solde du relevé (F CFA)";
  el("arrBilletage").innerHTML = especes ? `<details class="card" style="margin:.6rem 0"><summary>Détailler les billets et pièces (facultatif)</summary>
    <div class="fgrid">${tresorerieCache.coupures.map(v => `<div class="field"><label for="bil${v}">${formatNombre(v)} F</label>
      <input id="bil${v}" class="coupure" data-valeur="${v}" inputmode="numeric" placeholder="0"></div>`).join("")}</div></details>` : "";
  el("arrBilletage").querySelectorAll(".coupure").forEach(i => i.addEventListener("input", () => {
    const total = billetage().total;
    el("arrMontant").readOnly = total > 0;
    if (total > 0) el("arrMontant").value = formatNombre(total);
    majEcart();
  }));
  el("arrMontant").readOnly = false;
  majEcart();
}

function billetage() {
  const detail = {};
  let total = 0;
  el("arrBilletage").querySelectorAll(".coupure").forEach(i => {
    const n = parseInt(i.value, 10);
    if (n > 0) { detail[i.dataset.valeur] = n; total += n * Number(i.dataset.valeur); }
  });
  return { detail, total };
}

function majEcart() {
  const compte = lireMontant(el("arrMontant").value);
  if (!arreteEnCours || compte === null) { el("arrEcart").innerHTML = ""; return; }
  const ecart = compte - arreteEnCours.solde_calcule;
  el("arrEcart").innerHTML = ecart === 0 ? "✅ Le compte est juste : aucun écart."
    : `Écart : <b style="color:var(--danger)">${ecart > 0 ? "+" : ""}${formatMontant(ecart)}</b> — ${ecart < 0 ? "il manque de l'argent" : "il y a plus d'argent que prévu"} (expliquez-le dans l'observation).`;
}
el("arrMontant").addEventListener("input", majEcart);
el("arrCompte").addEventListener("change", preparerArrete);
el("arrDate").addEventListener("change", preparerArrete);

el("formArrete").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    const jour = valeurDate("arrDate", "Journée");
    if (!jour) throw new Error("Indiquez la journée (jj/mm/aaaa).");
    const compte = lireMontant(el("arrMontant").value);
    if (compte === null) throw new Error("Indiquez l'argent compté (ex : 58 000).");
    const rep = await api("/api/tresorerie/arretes", { method: "POST", body: {
      compte_id: Number(el("arrCompte").value), date_arrete: jour, solde_compte: compte,
      billetage: billetage().detail, observation: el("arrObservation").value,
    } });
    fermerModal("modalArrete");
    toast(rep.ecart === 0 ? "Arrêté enregistré : la caisse est juste" : `Arrêté enregistré avec un écart de ${formatMontant(rep.ecart)}`, 5000);
    chargerArretes();
  });
});

function supprimerArrete(id) {
  supprimerAvecConfirmation("Supprimer cet arrêté de caisse ? Mot de passe Admin.", `/api/tresorerie/arretes/${id}/supprimer`, chargerArretes);
}

// ---------- Comptes (Admin) ----------

let compteTresorerieEnCours = null;

async function chargerComptesTresorerie() {
  const zone = el("listeComptesTresorerie");
  let t;
  try { t = await donneesTresorerie(); }
  catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  zone.innerHTML = `<div class="card">${t.comptes.map(c => `
    <div class="row">
      <span class="who">${svgIcone(ICONE_TYPE[c.type_compte]).replace("<svg", '<svg class="ico-ligne"')} <b>${esc(c.nom)}</b> — ${esc(c.type_compte)}${c.numero ? " — " + esc(c.numero) : ""}
        <br><span class="petit">Reçoit d'office : ${c.modes_paiement.length ? c.modes_paiement.map(esc).join(", ") : "rien (choix à la main)"}
        — solde de départ ${formatMontant(c.solde_initial)} le ${formatDate(c.date_ouverture)}</span></span>
      <span class="boutons">${c.actif ? '<span class="pill ok">Ouvert</span>' : '<span class="pill">Fermé</span>'}
        ${ibtn("modifier", "Modifier ce compte", `modifierCompteTresorerie(${c.id})`)}</span>
    </div>`).join("")}</div>`;
}

function remplirFormCompte(c) {
  compteTresorerieEnCours = c ? c.id : null;
  el("tcTitre").textContent = c ? `Modifier « ${c.nom} »` : "Nouveau compte";
  remplirSelect(el("tcType"), tresorerieCache.types_compte);
  el("tcNom").value = c?.nom || "";
  el("tcType").value = c?.type_compte || "Mobile Money";
  el("tcNumero").value = c?.numero || "";
  el("tcSolde").value = c ? formatNombre(c.solde_initial) : "0";
  fixerDate("tcDate", c?.date_ouverture || aujourdhui());
  el("tcActif").checked = c ? c.actif : true;
  el("tcComptable").value = c?.compte_comptable || "";
  el("tcModes").innerHTML = tresorerieCache.modes_paiement.map(m => `<label><input type="checkbox" value="${esc(m)}"
    ${c?.modes_paiement.includes(m) ? "checked" : ""}> ${esc(m)}</label>`).join("");
  reinitialiserSaisie(el("formCompteTresorerie"));
  erreurFormulaire(el("formCompteTresorerie"), "");
  ouvrirModal("modalCompteTresorerie");
}
async function nouveauCompteTresorerie() {
  try { await donneesTresorerie(); } catch (e) { toast(e.message); return; }
  remplirFormCompte(null);
}
function modifierCompteTresorerie(id) {
  const c = tresorerieCache?.comptes.find(x => x.id === id);
  if (c) remplirFormCompte(c);
}

el("formCompteTresorerie").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (el("tcNom").value.trim().length < 2) throw new Error("Indiquez le nom du compte (ex : Wave).");
    const negatif = el("tcSolde").value.trim().startsWith("-");
    const solde = lireMontant(el("tcSolde").value.replace(/^-/, "") || "0");
    if (solde === null) throw new Error("Vérifiez le solde de départ (ex : 150 000).");
    const jour = valeurDate("tcDate", "Début du suivi");
    if (!jour) throw new Error("Indiquez la date de début du suivi (jj/mm/aaaa).");
    const corps = {
      nom: el("tcNom").value, type_compte: el("tcType").value, numero: el("tcNumero").value,
      solde_initial: negatif ? -solde : solde, date_ouverture: jour, actif: el("tcActif").checked,
      compte_comptable: el("tcComptable").value,
      modes_paiement: [...el("tcModes").querySelectorAll("input:checked")].map(i => i.value),
    };
    if (compteTresorerieEnCours) await api(`/api/tresorerie/comptes/${compteTresorerieEnCours}`, { method: "PUT", body: corps });
    else await api("/api/tresorerie/comptes", { method: "POST", body: corps });
    fermerModal("modalCompteTresorerie");
    toast("Compte enregistré");
    chargerComptesTresorerie();
  });
});
