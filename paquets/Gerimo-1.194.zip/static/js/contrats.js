// Étape 3 : locataires et contrats de bail.
// Le serveur filtre selon le profil et refuse ce qui n'est pas autorisé ;
// les boutons masqués ici ne sont qu'un confort d'affichage.

const NOUVEAU_LOCATAIRE = "__nouveau__";
const STATUTS_EN_COURS = ["Actif", "Renouvelé", "Suspendu", "En attente"];
const CLASSE_STATUT_CONTRAT = {
  "Actif": "ok", "Renouvelé": "ok", "En attente": "warn", "Suspendu": "warn",
  "Expiré": "info", "Résilié": "danger",
};
// Usage proposé par défaut selon le type de contrat
const USAGE_PAR_TYPE = {
  "Bail habitation": "Habitation", "Bail commercial": "Commercial", "Location meublée": "Habitation",
  "Courte durée": "Courte durée", "Colocation": "Habitation",
};

let contratsCache = [];
let locatairesCache = [];
let optionsContrat = null;
let contratEnCours = null;   // contrat modifié (null = nouveau)
let locataireEnCours = null;

// Lien WhatsApp (wa.me) : numéro ivoirien à 10 chiffres → indicatif 225 ajouté
function lienWhatsApp(telephone, message) {
  let chiffres = String(telephone || "").replace(/\D/g, "");
  if (chiffres.length === 10) chiffres = "225" + chiffres;
  if (chiffres.length < 8) return null;
  return `https://wa.me/${chiffres}?text=${encodeURIComponent(message)}`;
}
function ouvrirWhatsApp(telephone, nom, message = `Bonjour, ceci est un message ${deEntreprise()} concernant votre location.`) {
  const lien = lienWhatsApp(telephone, message);
  if (!lien) { toast("Numéro de téléphone manquant ou invalide"); return; }
  toast("Ouverture de WhatsApp — " + nom);
  window.open(lien, "_blank", "noopener");
}

// ---------- Liste des contrats ----------

async function chargerContrats() {
  const zone = el("listeContrats");
  try {
    contratsCache = await api("/api/contrats");
  } catch (e) {
    zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`;
    return;
  }
  if (!contratsCache.length) {
    zone.innerHTML = '<div class="card vide">Aucun contrat enregistré. Cliquez sur « + Nouveau contrat ».</div>';
    return;
  }
  zone.innerHTML = `<div class="card">${contratsCache.map(c => {
    const enCours = STATUTS_EN_COURS.includes(c.statut_contrat);
    const pastille = c.a_risque && enCours
      ? '<span class="pill danger">À risque</span>'
      : `<span class="pill ${CLASSE_STATUT_CONTRAT[c.statut_contrat]}">${esc(c.statut_contrat)}</span>`;
    let infos = `Logement ${esc(c.logement.numero_logement)}, ${esc(c.logement.cite_nom)} — payé en ${esc(c.terme_loyer.toLowerCase())} — depuis le ${formatDate(c.date_debut)}`;
    if (c.statut_contrat === "Résilié") {
      infos = `Résilié le ${formatDate(c.date_resiliation)}${c.motif_resiliation ? " — " + esc(c.motif_resiliation) : ""} — ` + infos;
    } else if (enCours && c.date_depart) {
      infos = `<b>Départ prévu le ${formatDate(c.date_depart)}</b> (préavis du ${formatDate(c.date_preavis)}${c.motif_depart ? " — " + esc(c.motif_depart) : ""}) — ` + infos;
    }
    const depart = enCours && c.date_depart ? `<span class="pill warn">Départ le ${formatDate(c.date_depart)}</span>` : "";
    return `<div class="row"${motsCles({ tel: [c.locataire.telephone], textes: [c.logement.adresse, c.locataire.cni] })}>
      <span class="who">N° ${esc(c.numero_contrat)} — <b>${esc(c.locataire.nom_complet)}</b> — ${esc(c.type_contrat)} — ${formatMontant(c.montant_loyer)}/mois
        <br><span class="petit">${infos}</span></span>
      <span class="boutons">
        ${pastille}${depart}
        ${ibtn("pdf", "Contrat de bail en PDF (à imprimer et signer)", `ouvrirContratPdf(${c.id})`)}
        ${enCours ? ibtn("whatsapp", "Message de bienvenue WhatsApp", `envoyerWhatsApp('bienvenue', {contrat_id: ${c.id}})`,
                         { desactive: c.locataire.telephone ? null : "Pas de numéro de téléphone" }) : ""}
        ${enCours && peut("etats_des_lieux") ? ibtn("edl", "État des lieux", `nouvelEtatDesLieux(${c.id})`, { classe: "doc" }) : ""}
        ${c.statut_contrat !== "Résilié" ? ibtn("modifier", "Modifier ce contrat", `modifierContrat(${c.id})`) : ""}
        ${enCours ? `<button class="btn-sm" onclick="preavisContrat(${c.id})" data-tip="Le locataire annonce son départ (préavis)">${c.date_depart ? "Départ" : "Préavis"}</button>` : ""}
        ${estAdmin() && enCours ? `<button class="btn-sm resil" onclick="resilierContrat(${c.id})" data-tip="Résiliation manuelle (mot de passe Admin)">Résilier</button>` : ""}
        ${estAdmin() ? ibtn("supprimer", "Supprimer ce contrat (Admin)", `supprimerContrat(${c.id})`) : ""}
      </span>
    </div>`;
  }).join("")}</div>`;
  el("rechercheContrats").dispatchEvent(new Event("input"));
}
CHARGEURS.contrats = chargerContrats;

// Contrat de bail en PDF (texte : modeles/contrat_bail.txt), prêt à imprimer et signer
function ouvrirContratPdf(contratId) {
  window.open(`/api/contrats/${contratId}/pdf`, "_blank");
}

// ---------- Formulaire contrat ----------

async function preparerFormContrat(contrat) {
  optionsContrat = await api("/api/contrats/options");
  const o = optionsContrat;
  contratEnCours = contrat ? contrat.id : null;

  // Locataire : nouveau (par défaut) ou existant ; non modifiable après création
  const selLoc = el("ctLocataire");
  selLoc.innerHTML = `<option value="${NOUVEAU_LOCATAIRE}">+ Nouveau locataire…</option>` +
    o.locataires.map(l => `<option value="${l.id}">${esc(l.nom_complet)}${l.telephone ? " — " + esc(l.telephone) : ""}</option>`).join("");
  // Logement : seulement les logements libres (plus celui du contrat modifié)
  const logements = [...o.logements_disponibles];
  if (contrat) logements.unshift({ id: contrat.logement.id, libelle: `${contrat.logement.cite_nom} — Logement ${contrat.logement.numero_logement}` });
  remplirSelect(el("ctLogement"), logements, { valeur: l => l.id, texte: l => l.libelle, vide: logements.length ? "— Choisir —" : "Aucun logement libre" });
  remplirSelect(el("ctType"), o.types_contrat);
  remplirSelect(el("ctUsage"), o.usages_bien);
  remplirSelect(el("ctTerme"), o.termes_loyer);
  remplirSelect(el("ctStatut"), contrat ? o.statuts_modification : o.statuts_creation);

  ["ctLocNom", "ctLocCni", "ctLocTel", "ctLocProfession", "ctLocEmail"].forEach(id => { el(id).value = ""; });
  piecesContrat.ouvrir(contrat ? { locataire_id: contrat.locataire.id } : null);
  if (contrat) {
    if (!o.locataires.some(l => l.id === contrat.locataire.id)) {
      selLoc.insertAdjacentHTML("beforeend", `<option value="${contrat.locataire.id}">${esc(contrat.locataire.nom_complet)}</option>`);
    }
    selLoc.value = contrat.locataire.id;
    el("ctLogement").value = contrat.logement.id;
    el("ctType").value = contrat.type_contrat;
    el("ctUsage").value = contrat.usage_bien;
    el("ctTerme").value = contrat.terme_loyer;
    el("ctLoyer").value = formatMontant(contrat.montant_loyer).replace(" F", "");
    el("ctCaution").value = contrat.mois_caution;
    el("ctAvance").value = contrat.mois_avance;
    el("ctStatut").value = contrat.statut_contrat;
    fixerDate("ctDebut", contrat.date_debut);
    fixerDate("ctFin", contrat.date_fin);
    el("ctTitreContrat").textContent = `Contrat N° ${contrat.numero_contrat}`;
  } else {
    selLoc.value = NOUVEAU_LOCATAIRE;
    el("ctUsage").value = USAGE_PAR_TYPE[el("ctType").value] || o.usages_bien[0];
    el("ctLoyer").value = "";
    el("ctCaution").value = "2";
    el("ctAvance").value = "1";
    fixerDate("ctDebut", aujourdhui());
    fixerDate("ctFin", null);
    el("ctTitreContrat").textContent = "Contrat (numéro attribué à l'enregistrement)";
  }
  // Après création, on ne change ni le locataire ni le logement (résilier puis refaire un contrat)
  selLoc.disabled = !!contrat;
  el("ctLogement").disabled = !!contrat;
  majChampsLocataire();
  majRecap();
  erreurFormulaire(el("formulaireContrat"), "");
}

function majChampsLocataire() {
  const nouveau = el("ctLocataire").value === NOUVEAU_LOCATAIRE;
  el("champsNouveauLocataire").style.display = nouveau ? "" : "none";
  // pièces jointes : celles du locataire choisi, ou en attente pour un nouveau locataire
  if (!contratEnCours) piecesContrat.ouvrir(nouveau ? null : { locataire_id: Number(el("ctLocataire").value) });
}
el("ctLocataire").addEventListener("change", majChampsLocataire);

// Choisir un logement propose son loyer
el("ctLogement").addEventListener("change", () => {
  const l = optionsContrat?.logements_disponibles.find(l => String(l.id) === el("ctLogement").value);
  if (l) el("ctLoyer").value = formatMontant(l.loyer).replace(" F", "");
  majRecap();
});
el("ctType").addEventListener("change", () => {
  if (!contratEnCours && USAGE_PAR_TYPE[el("ctType").value]) el("ctUsage").value = USAGE_PAR_TYPE[el("ctType").value];
});
el("ctLoyer").addEventListener("blur", () => {
  const n = lireMontant(el("ctLoyer").value);
  if (n !== null) el("ctLoyer").value = formatMontant(n).replace(" F", "");
});
["ctLoyer", "ctCaution", "ctAvance"].forEach(id => el(id).addEventListener("input", majRecap));
["ctCaution", "ctAvance"].forEach(id => el(id).addEventListener("change", majRecap));

// Récapitulatif : ce que le locataire paie à l'entrée
function majRecap() {
  const loyer = lireMontant(el("ctLoyer").value);
  const zone = el("ctRecap");
  if (!loyer) { zone.innerHTML = "Saisissez le loyer pour voir le montant à payer à l'entrée."; return; }
  const caution = loyer * Number(el("ctCaution").value);
  const avance = loyer * Number(el("ctAvance").value);
  zone.innerHTML = `À payer à l'entrée : caution <b>${formatMontant(caution)}</b> + avance <b>${formatMontant(avance)}</b>
    = <b>${formatMontant(caution + avance)}</b>`;
}

async function nouveauContrat() {
  await preparerFormContrat(null);
  if (!optionsContrat.logements_disponibles.length) toast("Aucun logement libre : ajoutez d'abord un logement");
  afficher("formContrat");
}

async function modifierContrat(id) {
  const contrat = contratsCache.find(c => c.id === id);
  if (!contrat) return;
  await preparerFormContrat(contrat);
  afficher("formContrat");
}

el("formulaireContrat").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    const loyer = lireMontant(el("ctLoyer").value);
    if (!contratEnCours && !el("ctLogement").value) throw new Error("Choisissez le logement.");
    if (loyer === null || loyer <= 0) throw new Error("Indiquez un loyer valide (ex : 75 000).");
    const dateDebut = valeurDate("ctDebut", "Date de début");
    const dateFin = valeurDate("ctFin", "Date de fin");
    if (!dateDebut) throw new Error("Indiquez la date de début (jj/mm/aaaa).");
    if (dateFin && dateFin < dateDebut) throw new Error("La date de fin doit être après la date de début.");
    const corps = {
      type_contrat: el("ctType").value,
      usage_bien: el("ctUsage").value,
      terme_loyer: el("ctTerme").value,
      montant_loyer: loyer,
      mois_caution: Number(el("ctCaution").value),
      mois_avance: Number(el("ctAvance").value),
      date_debut: dateDebut,
      date_fin: dateFin,
      statut_contrat: el("ctStatut").value,
    };
    if (contratEnCours) {
      await api(`/api/contrats/${contratEnCours}`, { method: "PUT", body: corps });
      toast("Contrat enregistré");
    } else {
      corps.logement_id = Number(el("ctLogement").value);
      if (el("ctLocataire").value === NOUVEAU_LOCATAIRE) {
        if (!el("ctLocNom").value.trim()) throw new Error("Indiquez le nom complet du locataire.");
        corps.nouveau_locataire = {
          nom_complet: el("ctLocNom").value, cni: el("ctLocCni").value,
          telephone: el("ctLocTel").value, profession: el("ctLocProfession").value,
          email: el("ctLocEmail").value,
        };
      } else {
        corps.locataire_id = Number(el("ctLocataire").value);
      }
      const rep = await api("/api/contrats", { method: "POST", body: corps });
      await piecesContrat.envoyerEnAttente({ locataire_id: rep.locataire_id });
      toast(`Contrat N° ${rep.numero_contrat} enregistré`);
    }
    goBack();
  });
});

// ---------- Départ du locataire (préavis) ----------
// Les loyers s'arrêtent au mois du départ (mois complet). Ensuite : état des lieux de sortie,
// restitution de la caution, puis résiliation par l'Admin (jamais automatique).

const PREAVIS_JOURS = 30;

function majRecapPreavis() {
  const zone = el("preavisRecap");
  let recu, depart;
  try { recu = valeurDate("preavisDate", "Préavis reçu le"); depart = valeurDate("preavisDepart", "Date de départ"); }
  catch { recu = depart = null; }
  if (!depart) { zone.innerHTML = "Indiquez la date de départ : le dernier loyer sera celui de ce mois-là."; return; }
  const [a, m] = depart.split("-").map(Number);
  const mois = new Date(a, m - 1, 1).toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
  let texte = `Dernier loyer dû : <b>${esc(mois)}</b> (mois complet).`;
  if (recu) {
    const jours = Math.round((new Date(depart) - new Date(recu)) / 86400000);
    if (jours < 0) texte = "La date de départ doit être après la date du préavis.";
    else if (jours < PREAVIS_JOURS) texte += ` <br>⚠ Préavis de ${jours} jour${jours > 1 ? "s" : ""} seulement : le bail prévoit un mois.`;
  }
  zone.innerHTML = texte + "<br>Ensuite : état des lieux de sortie → restitution de la caution → résiliation par l'Admin.";
}
// sur la fenêtre entière : les champs date sont remplacés au chargement (initialiserChampsDate)
["input", "change"].forEach(t => el("formPreavis").addEventListener(t, majRecapPreavis));

function preavisContrat(id) {
  const c = contratsCache.find(c => c.id === id);
  if (!c) return;
  const fond = el("modalPreavis");
  const form = el("formPreavis");
  el("preavisTexte").textContent =
    `Contrat N° ${c.numero_contrat} — ${c.locataire.nom_complet}, logement ${c.logement.numero_logement} (${c.logement.cite_nom}).`;
  fixerDate("preavisDate", c.date_preavis || aujourdhui());
  if (c.date_depart) {
    fixerDate("preavisDepart", c.date_depart);
  } else {  // par défaut : un mois après le préavis
    const d = new Date(); d.setMonth(d.getMonth() + 1);
    fixerDate("preavisDepart", `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`);
  }
  el("preavisMotif").value = c.motif_depart || "";
  el("preavisRetirer").style.display = c.date_depart ? "" : "none";
  reinitialiserSaisie(form);
  erreurFormulaire(form, "");
  majRecapPreavis();
  fond.classList.add("show");

  const fermer = () => { fond.classList.remove("show"); form.onsubmit = null; };
  el("preavisFermer").onclick = fermer;
  el("preavisRetirer").onclick = () => soumettre(form, async () => {
    await api(`/api/contrats/${id}/preavis/annuler`, { method: "POST" });
    fermer();
    toast("Préavis retiré : le locataire reste, les loyers continuent");
    await chargerContrats();
  });
  form.onsubmit = ev => {
    ev.preventDefault();
    soumettre(form, async () => {
      const rep = await api(`/api/contrats/${id}/preavis`, {
        method: "POST",
        body: { date_preavis: valeurDate("preavisDate", "Préavis reçu le"),
                date_depart: valeurDate("preavisDepart", "Date de départ"),
                motif: el("preavisMotif").value },
      });
      fermer();
      toast(rep.preavis_court ? `Départ enregistré (préavis court : ${rep.jours} jours)` : "Départ enregistré");
      await chargerContrats();
    });
  };
}

// ---------- Résiliation (Admin) ----------

function resilierContrat(id) {
  const c = contratsCache.find(c => c.id === id);
  if (!c) return;
  const fond = el("modalResiliation");
  const form = el("formResiliation");
  el("resiliationTexte").textContent =
    `Contrat N° ${c.numero_contrat} — ${c.locataire.nom_complet}, logement ${c.logement.numero_logement} (${c.logement.cite_nom}). ` +
    "Cette action est définitive : le logement redeviendra libre.";
  fixerDate("resiliationDate", c.date_depart || aujourdhui());
  el("resiliationMotif").value = c.date_depart
    ? `Départ du locataire (préavis du ${formatDate(c.date_preavis)})${c.motif_depart ? " — " + c.motif_depart : ""}` : "";
  el("resiliationMdp").value = "";
  reinitialiserSaisie(form);
  erreurFormulaire(form, "");
  fond.classList.add("show");
  el("resiliationMotif").focus();

  const fermer = () => { fond.classList.remove("show"); form.onsubmit = null; };
  el("resiliationAnnuler").onclick = () => { fermer(); toast("Résiliation annulée"); };
  form.onsubmit = ev => {
    ev.preventDefault();
    soumettre(form, async () => {
      await api(`/api/contrats/${id}/resilier`, {
        method: "POST",
        body: { mot_de_passe_admin: el("resiliationMdp").value,
                date_resiliation: valeurDate("resiliationDate", "Date de résiliation"),
                motif: el("resiliationMotif").value },
      });
      fermer();
      toast("Contrat résilié");
      await chargerContrats();
    });
  };
}

function supprimerContrat(id) {
  const c = contratsCache.find(c => c.id === id);
  supprimerAvecConfirmation(
    `Supprimer le contrat N° ${c ? c.numero_contrat : ""} ? En général, mieux vaut le résilier pour garder l'historique. Entrez votre mot de passe Admin pour confirmer.`,
    `/api/contrats/${id}/supprimer`, chargerContrats);
}

// ---------- Locataires ----------

async function chargerLocataires() {
  const zone = el("listeLocataires");
  try {
    locatairesCache = await api("/api/locataires");
  } catch (e) {
    zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`;
    return;
  }
  if (!locatairesCache.length) {
    zone.innerHTML = '<div class="card vide">Aucun locataire. Les locataires s\'ajoutent avec leur contrat : « + Ajouter (via contrat) ».</div>';
    return;
  }
  zone.innerHTML = `<div class="card">${locatairesCache.map(l => {
    const enCours = l.contrats.filter(c => STATUTS_EN_COURS.includes(c.statut_contrat));
    const ou = enCours.length ? enCours.map(c => esc(c.logement)).join(" ; ") : '<span class="a-venir">Aucun contrat en cours</span>';
    const infos = [ou];
    if (l.telephone) infos.push(esc(l.telephone));
    if (l.profession) infos.push(esc(l.profession));
    return `<div class="row"${motsCles({ tel: [l.telephone],
                                         textes: [l.cni, ...l.contrats.flatMap(c => [c.adresse, c.numero_contrat])] })}>
      <span class="who"><b>${esc(l.nom_complet)}</b> — ${infos.join(" — ")}</span>
      <span class="boutons">
        ${l.nb_pieces ? `<span class="pill info" data-tip="Pièces jointes (CNI…)">${svgIcone("trombone").replace("<svg", '<svg style="width:11px;height:11px;stroke:currentColor;fill:none;stroke-width:2;vertical-align:-1px"')} ${l.nb_pieces}</span>` : ""}
        ${ibtn("whatsapp", "Écrire sur WhatsApp", `whatsAppLocataire(${l.id})`, { desactive: l.telephone ? null : "Pas de numéro de téléphone" })}
        ${ibtn("modifier", "Modifier ce locataire (et ses pièces jointes)", `modifierLocataire(${l.id})`)}
        ${estAdmin() ? ibtn("supprimer", "Supprimer ce locataire (Admin)", `supprimerLocataire(${l.id})`) : ""}
      </span>
    </div>`;
  }).join("")}</div>`;
  el("rechercheLocataires").dispatchEvent(new Event("input"));
}
CHARGEURS.locataires = chargerLocataires;

function whatsAppLocataire(id) {
  const l = locatairesCache.find(l => l.id === id);
  if (l) ouvrirWhatsApp(l.telephone, l.nom_complet);
}

function modifierLocataire(id) {
  const l = locatairesCache.find(l => l.id === id);
  if (!l) return;
  locataireEnCours = id;
  el("locNom").value = l.nom_complet;
  el("locCni").value = l.cni || "";
  el("locTel").value = l.telephone || "";
  el("locProfession").value = l.profession || "";
  el("locEmail").value = l.email || "";
  piecesLocataire.ouvrir({ locataire_id: l.id });
  erreurFormulaire(el("formulaireLocataire"), "");
  afficher("formLocataire");
}

el("formulaireLocataire").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (!el("locNom").value.trim()) throw new Error("Indiquez le nom complet.");
    await api(`/api/locataires/${locataireEnCours}`, {
      method: "PUT",
      body: { nom_complet: el("locNom").value, cni: el("locCni").value,
              telephone: el("locTel").value, profession: el("locProfession").value, email: el("locEmail").value },
    });
    toast("Locataire enregistré");
    goBack();
  });
});

function supprimerLocataire(id) {
  const l = locatairesCache.find(l => l.id === id);
  supprimerAvecConfirmation(
    `Supprimer le locataire « ${l ? l.nom_complet : ""} » ? Entrez votre mot de passe Admin pour confirmer.`,
    `/api/locataires/${id}/supprimer`, chargerLocataires);
}

brancherRecherche(el("rechercheContrats"), el("listeContrats"));
brancherRecherche(el("rechercheLocataires"), el("listeLocataires"));
