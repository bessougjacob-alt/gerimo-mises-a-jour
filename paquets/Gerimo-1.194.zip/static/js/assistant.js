// Gérimo, l'assistant d'ISUP : liste de ce qu'il y a à faire, rappels qui surgissent à l'écran (et à voix haute),
// conversation avec une vraie IA (Claude, via Internet ; voir ia.py), dictée au micro.
// Les tâches et rappels sont calculés par le serveur (sans Internet) ; sans clé ou sans Internet,
// la conversation revient à l'assistant simple « à règles ».

let assistant = { taches: [], rappels: [], resume: "" };
let assistantPret = false;  // après le message d'accueil : chaque nouveau message de Gérimo anime son bouton
let rappelsDejaVus = new Set(JSON.parse(sessionStorage.getItem("isup_rappels_vus") || "[]"));
const CLE_VOIX = "isup_voix";
const CLE_MASQUEES = "isup_taches_masquees";
const NIVEAUX = { urgent: "Urgent", attention: "À faire aujourd'hui", info: "Pour information" };

function lireStockage(cle, defaut) { try { return JSON.parse(localStorage.getItem(cle)) ?? defaut; } catch { return defaut; } }
function ecrireStockage(cle, valeur) { try { localStorage.setItem(cle, JSON.stringify(valeur)); } catch { /* navigation privée */ } }
const voixActive = () => lireStockage(CLE_VOIX, false);

// ---------- Démarrage et actualisation ----------
async function demarrerAssistant() {
  await chargerAssistant();
  el("apVoix").classList.toggle("actif", voixActive());
  setInterval(chargerAssistant, 5 * 60 * 1000);   // toutes les 5 minutes
  setInterval(verifierRappels, 30 * 1000);       // rappels à l'heure près
  verifierRappels();
  // Résumé du jour lu une fois par jour, au premier clic (les navigateurs exigent un geste de l'utilisateur)
  const cle = `isup_resume_${moi.identifiant}`;
  if (voixActive() && lireStockage(cle, "") !== aujourdhui()) {
    document.addEventListener("click", () => { ecrireStockage(cle, aujourdhui()); parler(assistant.resume); }, { once: true });
  }
  // Pas d'ouverture automatique du panneau (demande de Boss du 04/10/2026) : les urgences restent signalées
  // par les pastilles, le bandeau « Bonjour » et la carte Gérimo de l'accueil.
  enteteDiscussion();
  ajouterBulle("ia", `Bonjour ${assistant.prenom || ""} 👋 Je suis Gérimo, votre assistant. Posez-moi n'importe quelle question, en phrases normales. Par exemple :`, [
    { libelle: "Qu'est-ce que j'ai aujourd'hui ?", type: "dire", texte: "Qu'est-ce que j'ai aujourd'hui ?" },
    { libelle: "Impayés", type: "dire", texte: "Impayés" },
    { libelle: "Logements libres", type: "dire", texte: "Logements libres" },
    { libelle: "Rédiger un rappel de loyer", type: "remplir", texte: "Rédige un message WhatsApp poli pour rappeler à un locataire " },
    { libelle: "Rappelle-moi…", type: "remplir", texte: "Rappelle-moi d'appeler " },
    { libelle: "Nouveau client…", type: "remplir", texte: "Nouveau client " },
  ]);
  assistantPret = true;
}

let clesConnues = null;  // tâches déjà signalées (null = premier chargement)
async function chargerAssistant() {
  try { assistant = await api("/api/assistant"); } catch { return; }
  const masquees = tachesMasquees();
  const visibles = assistant.taches.filter(t => !masquees.has(t.cle));
  // Animation du bouton Gérimo : au démarrage s'il y a quelque chose à faire, puis à chaque nouvelle
  // notification, alerte ou tâche (pas pour les simples informations)
  const importantes = visibles.filter(t => t.niveau !== "info").map(t => t.cle);
  if (clesConnues === null ? importantes.length : importantes.some(c => !clesConnues.has(c))) signalerGerimo();
  clesConnues = new Set([...(clesConnues || []), ...importantes]);
  const urgents = visibles.filter(t => t.niveau === "urgent").length;
  const nb = visibles.filter(t => t.niveau !== "info").length;
  // pastille seulement sur la cloche (plus sur le bouton Gérimo, demande de Boss du 08/11/2026)
  el("pastilleNotifs").textContent = nb > 99 ? "99+" : nb;
  el("pastilleNotifs").classList.toggle("show", nb > 0);
  el("pastilleNotifs").classList.toggle("rouge", urgents > 0);
  const impayes = assistant.taches.filter(t => t.categorie === "Impayé").length;
  el("pastilleAlertes").textContent = impayes;
  el("pastilleAlertes").classList.toggle("show", impayes > 0);
  el("apDate").textContent = assistant.date;
  el("apNbTaches").textContent = nb ? `(${nb})` : "";
  el("assistantCompteur").textContent = nb ? `${nb} à faire` : "à jour";
  afficherTaches(visibles);
  afficherAccueilAssistant(visibles);
}

function tachesMasquees() {
  const m = lireStockage(CLE_MASQUEES, {});
  return new Set(Object.keys(m).filter(cle => m[cle] === aujourdhui()));
}
function masquerTache(cle) {
  const m = lireStockage(CLE_MASQUEES, {});
  for (const k of Object.keys(m)) if (m[k] !== aujourdhui()) delete m[k];
  m[cle] = aujourdhui();
  ecrireStockage(CLE_MASQUEES, m);
  chargerAssistant();
}

// ---------- Accueil : bandeau « Bonjour » et aperçu ----------
function afficherAccueilAssistant(taches) {
  if (!el("bonjourTitre")) return;
  const heure = new Date().getHours();
  el("bonjourTitre").textContent = heure < 18 ? "Bonjour" : "Bonsoir";
  el("bonjourDate").textContent = `${assistant.date} — Profil ${moi.role}`;
  const compte = cat => taches.filter(t => cat.includes(t.categorie)).length;
  const puces = [
    [taches.filter(t => t.niveau === "urgent").length, "urgent(s)"],
    [taches.filter(t => t.niveau === "attention").length, "à faire aujourd'hui"],
    [compte(["Rendez-vous", "Appel", "Visite", "Tâche", "Relance", "Courrier"]), "à l'agenda / à envoyer"],
    [compte(["Impayé"]), "impayé(s)"],
    [compte(["Client"]), "client(s) à recontacter"],
  ].filter(([n]) => n > 0);
  el("bonjourResume").innerHTML = puces.map(([n, t]) => `<span onclick="ouvrirAssistant()">${n} ${t}</span>`).join("")
    || '<span onclick="ouvrirAssistant()">Tout est à jour ✓</span>';
  afficherDefilement(taches);
  el("assistantApercu").innerHTML = taches.slice(0, 3).map(t =>
    `<div class="ligne-ia"><i class="${t.niveau}"></i><span>${esc(t.titre)}</span></div>`).join("")
    || '<div class="petit">Rien d\'urgent. Cliquez pour parler à l\'assistant.</div>';
}

// Notifications, rappels de rendez-vous et tâches qui défilent de droite à gauche dans le bandeau
const ICONES_DEFILEMENT = { "Rendez-vous": "📅", "Appel": "📞", "Visite": "🏠", "Tâche": "✔", "Relance": "🔔",
  "Courrier": "✉", "Impayé": "⚠", "Échéance": "💰", "Client": "👤", "Problème": "🔧", "État des lieux": "📋",
  "Annonce": "📣", "Sécurité": "🔒", "Compte": "👤", "Décision": "⚖", "Paramétrage": "⚙" };
let signatureDefilement = "";
function afficherDefilement(taches) {
  const zone = el("bonjourDefile");
  if (!zone) return;
  // Seulement les plus récentes : les N plus proches d'aujourd'hui (réglage « defilement_max » des Paramètres),
  // à égalité les plus urgentes d'abord ; la cloche et le panneau de Gérimo gardent toute la liste
  const ordre = { urgent: 0, attention: 1, info: 2 };
  const jour = new Date().toISOString().slice(0, 10);
  const ecart = t => Math.abs(Date.parse(t.le || jour) - Date.parse(jour));
  const elements = [...taches].sort((a, b) => ecart(a) - ecart(b) || ordre[a.niveau] - ordre[b.niveau])
    .slice(0, assistant.defilement_max || 15).map(t =>
    `<span class="defile-el ${t.niveau}" onclick="ouvrirAssistant()"><i>${ICONES_DEFILEMENT[t.categorie] || "•"}</i>${esc(t.titre)}</span>`);
  const signature = elements.join("");
  if (signature === signatureDefilement) return;  // rien de neuf : on ne relance pas l'animation
  signatureDefilement = signature;
  if (!elements.length) {
    zone.innerHTML = '<div class="defile-calme">Aucune notification, aucun rendez-vous en attente.</div>';
    return;
  }
  // deux copies à la suite : quand la première est sortie à gauche, la seconde a pris sa place (boucle sans à-coup)
  zone.innerHTML = `<div class="defile-piste"><div class="defile-lot">${signature}</div><div class="defile-lot" aria-hidden="true">${signature}</div></div>`;
  const piste = zone.firstElementChild;
  // Vitesse constante (~55 pixels par seconde), recalculée dès que la largeur change : mesurée quand le bandeau
  // était caché (largeur 0), la durée restait au minimum et une longue liste défilait à toute vitesse
  const regler = () => {
    const largeur = piste.firstElementChild.offsetWidth;
    if (largeur > 0) piste.style.animationDuration = `${Math.max(12, largeur / 55)}s`;
  };
  if (observateurDefilement) observateurDefilement.disconnect();
  if (window.ResizeObserver) {
    observateurDefilement = new ResizeObserver(regler);
    observateurDefilement.observe(piste.firstElementChild);
  }
  requestAnimationFrame(regler);
}
let observateurDefilement = null;

// Plus aucune animation : ni la cloche (06/10/2026) ni l'icône de Gérimo (11/11/2026) ne bougent ;
// la pastille de la cloche suffit à signaler un message, une alerte ou un rappel.
function signalerGerimo() {}

// ---------- Panneau ----------
function ouvrirAssistant() {
  el("panneauAssistant").classList.add("show");
  ["fabAssistant", "btnAssistantRail"].forEach(id => el(id) && el(id).classList.remove("signal"));
  chargerAssistant();
}
function fermerAssistant() { el("panneauAssistant").classList.remove("show"); }
function ongletAssistant(nom) {
  document.querySelectorAll(".ap-onglets button").forEach(b => b.classList.toggle("actif", b.dataset.ap === nom));
  el("apTaches").style.display = nom === "taches" ? "" : "none";
  el("apDiscussion").style.display = nom === "discussion" ? "" : "none";
  if (nom === "discussion") el("apSaisie").focus();
}

function boutonsAction(actions, cle) {
  return actions.map((a, i) => `<button class="btn-sm${a.type === "whatsapp" || a.type === "wa_type" ? " wa" : ""}" data-action='${esc(JSON.stringify(a))}'>${esc(a.libelle)}</button>`).join("")
    + (cle ? `<button class="btn-sm" data-masquer="${esc(cle)}" data-tip="Ne plus l'afficher aujourd'hui">Plus tard</button>` : "");
}

function afficherTaches(taches) {
  if (!taches.length) {
    el("apTaches").innerHTML = '<div class="ap-vide">🎉 Tout est à jour.<br>Aucune tâche en attente pour le moment.</div>';
    return;
  }
  let html = "";
  for (const [niveau, titre] of Object.entries(NIVEAUX)) {
    const groupe = taches.filter(t => t.niveau === niveau);
    if (!groupe.length) continue;
    html += `<div class="ap-section">${titre} (${groupe.length})</div>` + groupe.map(t => `
      <div class="tache ${t.niveau}"><div class="tache-corps"><b>${esc(t.titre)}</b><span>${esc(t.detail)}</span>
        <div class="tache-actions">${boutonsAction(t.actions, t.cle)}</div></div></div>`).join("");
  }
  el("apTaches").innerHTML = html;
}

// Clic sur un bouton d'action (tâches et réponses de l'assistant)
document.addEventListener("click", e => {
  const masquer = e.target.closest("[data-masquer]");
  if (masquer) { masquerTache(masquer.dataset.masquer); return; }
  const bouton = e.target.closest("[data-action]");
  if (!bouton || !bouton.closest("#panneauAssistant, .rappel-pop")) return;
  executerAction(JSON.parse(bouton.dataset.action));
});

async function executerAction(a) {
  const fermer = () => { if (innerWidth < 1200) fermerAssistant(); };
  switch (a.type) {
    case "dire": envoyerCommande(a.texte); break;
    case "remplir": el("apSaisie").value = a.texte; el("apSaisie").focus(); break;
    case "agenda_fait": await api(`/api/agenda/${a.id}/fait`, { method: "POST" }).catch(e => toast(e.message)); rafraichirAgendas(); break;
    case "whatsapp": ouvrirWhatsAppTexte(a.telephone, a.texte); break;
    case "wa_type": envoyerWhatsApp(a.message, { contrat_id: a.id }, chargerAssistant); break;
    case "encaisser": fermer(); await afficher("paiements"); encaisserPour(a.id); break;
    case "avenant": fermer(); nouvelAvenant(a.id); break;
    case "edl": fermer(); nouvelEtatDesLieux(a.contrat_id, a.type_edl); break;
    case "edl_ouvrir": fermer(); await afficher("etats_des_lieux"); ouvrirEdl(a.id); break;
    case "courrier": fermer(); await afficher("courriers"); envoyerCourrier(a.id); break;
    case "prospect": ouvrirProspect(a.id); break;
    case "prospect_nouveau": nouveauProspect(a.infos || {}); break;
    case "ouvrir": fermer(); afficher(a.cible); break;
    case "releves": fermer(); ouvrirRelevesMoisDernier(); break;
    case "utilisateurs": fermer(); ouvrirUtilisateurs(); break;
    case "sauvegarde": lancerSauvegarde(); break;
    case "sauvegardes": fermer(); ouvrirSauvegardes(); break;
    case "reglages": fermer(); ouvrirRubriqueParametres("parReglages"); break;
    case "journal": fermer(); ouvrirRubriqueParametres("parJournal"); break;
    case "a_propos": fermer(); ouvrirRubriqueParametres("parAPropos"); break;
  }
}

// ---------- Dialogue (vraie IA si la clé est saisie dans Paramètres ; sinon assistant simple) ----------
let conversationIA = [];   // fil de la conversation, renvoyé à chaque question pour que l'IA s'en souvienne
let iaOccupee = false;

// Mise en forme légère des réponses : **gras** (le reste est du texte simple, sécurisé par esc)
const miseEnForme = texte => esc(texte).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");

function ajouterBulle(qui, texte, actions = []) {
  if (qui === "ia" && assistantPret) signalerGerimo();
  const zone = el("apDiscussion");
  zone.insertAdjacentHTML("beforeend", `<div class="bulle ${qui}">${miseEnForme(texte)}${actions.length ? `<div class="bulle-actions">${boutonsAction(actions)}</div>` : ""}</div>`);
  zone.scrollTop = zone.scrollHeight;
}

function ajouterBulleDonnees(d, actions = []) {
  if (assistantPret) signalerGerimo();
  const zone = el("apDiscussion");
  zone.insertAdjacentHTML("beforeend", `<div class="bulle ia donnees">${d.titre ? `<b>${esc(d.titre)}</b>\n` : ""}${esc(d.texte)}`
    + `<small class="donnees-local">🔒 Affiché depuis le logiciel, non transmis à l'IA</small>`
    + `${actions.length ? `<div class="bulle-actions">${boutonsAction(actions)}</div>` : ""}</div>`);
  zone.scrollTop = zone.scrollHeight;
}

// Logo de Gérimo en tête de la discussion
function enteteDiscussion() {
  el("apDiscussion").innerHTML = '<div class="ap-entete-ia"><img src="/static/img/gerimo-logo.svg" alt="Gérimo"><span>Votre assistant</span></div>';
}

function nouvelleConversation() {
  conversationIA = [];
  enteteDiscussion();
  ajouterBulle("ia", `Nouvelle conversation. Que puis-je faire pour vous, ${assistant.prenom || ""} ?`);
  ongletAssistant("discussion");
}

async function envoyerCommande(texte) {
  texte = texte.trim();
  if (!texte || iaOccupee) return;
  ongletAssistant("discussion");
  ajouterBulle("moi", texte);
  el("apSaisie").value = "";
  conversationIA.push({ role: "user", texte: texte.slice(0, 8000) });
  iaOccupee = true;
  const zone = el("apDiscussion");
  zone.insertAdjacentHTML("beforeend", '<div class="bulle ia ecrit" id="apEcrit"><span></span><span></span><span></span></div>');
  zone.scrollTop = zone.scrollHeight;
  try {
    const rep = await api("/api/assistant/discuter", { method: "POST", body: { messages: conversationIA.slice(-40) } });
    el("apEcrit")?.remove();
    const donnees = rep.donnees || [];
    ajouterBulle("ia", rep.reponse, donnees.length ? [] : rep.actions || []);
    // Données de la base : affichées ici par le logiciel, jamais transmises à l'IA
    donnees.forEach((d, i) => ajouterBulleDonnees(d, i === donnees.length - 1 ? rep.actions || [] : []));
    // On ne garde dans la conversation que la réponse de l'IA, pas les données affichées
    conversationIA.push({ role: "assistant", texte: (rep.memoire || rep.reponse).slice(0, 8000) });
    if (voixActive()) parler(rep.reponse.split("\n")[0].replace(/\*\*/g, ""));
    if (rep.cree) { rafraichirAgendas(); if (document.querySelector("#agenda.active")) chargerProspects(); }
  } catch (e) {
    el("apEcrit")?.remove();
    conversationIA.pop();
    ajouterBulle("ia", e.message);
  } finally { iaOccupee = false; }
}
el("apFormulaire").addEventListener("submit", e => { e.preventDefault(); envoyerCommande(el("apSaisie").value); });

// ---------- Voix ----------
function voixFrancaise() {
  const voix = speechSynthesis.getVoices();
  return voix.find(v => v.lang === "fr-FR" && /Denise|Henri|Julie|Paul|Google/i.test(v.name)) || voix.find(v => v.lang.startsWith("fr")) || null;
}
function parler(texte) {
  if (!("speechSynthesis" in window) || !texte) return;
  speechSynthesis.cancel();
  const phrase = new SpeechSynthesisUtterance(texte.replace(/[•✅👍🎉👋]/g, ""));
  phrase.lang = "fr-FR";
  const v = voixFrancaise();
  if (v) phrase.voice = v;
  phrase.rate = 1;
  speechSynthesis.speak(phrase);
}
if ("speechSynthesis" in window) speechSynthesis.onvoiceschanged = () => {};

function basculerVoix() {
  const active = !voixActive();
  ecrireStockage(CLE_VOIX, active);
  el("apVoix").classList.toggle("actif", active);
  if (active) {
    parler("Rappels à voix haute activés. Je vous préviendrai de vos rendez-vous et de vos tâches.");
    if ("Notification" in window && Notification.permission === "default") Notification.requestPermission().catch(() => {});
  } else {
    speechSynthesis?.cancel();
    toast("Rappels à voix haute désactivés (les rappels à l'écran restent actifs).");
  }
}
function lireResume() { parler(assistant.resume); if (!voixActive()) toast("Astuce : activez le haut-parleur pour entendre vos rappels automatiquement."); }

// ---------- Dictée (micro) ----------
let reconnaissance = null;
// La première fois, Gérimo prévient : le son part chez Google (Chrome) ou Microsoft (Edge) pour être transcrit.
function dicteeAcceptee() {
  try { if (localStorage.getItem("gerimo_dictee_ok") === "1") return Promise.resolve(true); } catch (e) { /* stockage bloqué */ }
  const fond = el("modalDictee");
  fond.classList.add("show");
  return new Promise(resolve => {
    const fermer = ok => {
      fond.classList.remove("show");
      el("modalDicteeOk").onclick = el("modalDicteeAnnuler").onclick = null;
      if (ok) { try { localStorage.setItem("gerimo_dictee_ok", "1"); } catch (e) { /* stockage bloqué */ } }
      resolve(ok);
    };
    el("modalDicteeOk").onclick = () => fermer(true);
    el("modalDicteeAnnuler").onclick = () => fermer(false);
  });
}
async function dicter() {
  const Reco = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Reco) { toast("La dictée n'est pas disponible sur ce navigateur (utilisez Chrome ou Edge)."); return; }
  if (reconnaissance) { reconnaissance.stop(); return; }
  if (!(await dicteeAcceptee())) return;
  reconnaissance = new Reco();
  reconnaissance.lang = "fr-FR";
  reconnaissance.interimResults = true;
  el("apMicro").classList.add("ecoute");
  reconnaissance.onresult = e => {
    const texte = [...e.results].map(r => r[0].transcript).join("");
    el("apSaisie").value = texte;
    if (e.results[e.results.length - 1].isFinal) envoyerCommande(texte);
  };
  reconnaissance.onerror = e => { toast(e.error === "not-allowed" ? "Micro refusé : autorisez-le dans le navigateur." : "Dictée interrompue (Internet nécessaire)."); };
  reconnaissance.onend = () => { el("apMicro").classList.remove("ecoute"); reconnaissance = null; };
  reconnaissance.start();
}

// ---------- Rappels qui surgissent à l'heure ----------
function noterRappelVu(cle) {
  rappelsDejaVus.add(cle);
  sessionStorage.setItem("isup_rappels_vus", JSON.stringify([...rappelsDejaVus]));
}

// Rendez-vous, appels et visites : toujours rappelés 30 puis 15 minutes avant (règle de Boss), en plus du
// délai choisi dans l'agenda ; les autres événements suivent le délai choisi. Puis « C'est l'heure ».
const TYPES_RAPPEL_30_15 = ["Rendez-vous", "Appel", "Visite"];
function delaisRappel(r) {
  const delais = new Set(r.rappel_minutes > 0 ? [r.rappel_minutes] : []);
  if (TYPES_RAPPEL_30_15.includes(r.type)) { delais.add(30); delais.add(15); }
  return [...delais].sort((a, b) => b - a);  // du plus long au plus court
}
const cleRappel = (r, quand) => `${r.id}-${r.date || aujourdhui()}-${r.heure}-${quand}`;

function heureRappel(r) {
  const [h, m] = r.heure.split(":").map(Number);
  const d = r.date ? new Date(r.date + "T00:00:00") : new Date();
  d.setHours(h, m, 0, 0);
  return d;
}

function verifierRappels() {
  const maintenant = new Date();
  for (const r of assistant.rappels || []) {
    const heure = heureRappel(r);
    const delais = delaisRappel(r);
    if (maintenant >= heure) {
      if (maintenant - heure < 30 * 60000 && !rappelsDejaVus.has(cleRappel(r, "heure"))) {
        delais.forEach(d => noterRappelVu(cleRappel(r, d)));
        noterRappelVu(cleRappel(r, "heure"));
        afficherRappel(r, "C'est l'heure");
      }
      continue;
    }
    // le plus court délai déjà atteint (ex. 15 min) ; les plus longs sont alors considérés comme passés
    const atteint = delais.filter(d => maintenant >= heure - d * 60000).pop();
    if (atteint === undefined || rappelsDejaVus.has(cleRappel(r, atteint))) continue;
    delais.filter(d => d >= atteint).forEach(d => noterRappelVu(cleRappel(r, d)));
    const minutes = Math.max(1, Math.round((heure - maintenant) / 60000));
    afficherRappel(r, `Dans ${minutes >= 60 ? Math.round(minutes / 60) + " h" : minutes + " minutes"}`);
  }
}

function afficherRappel(r, quand) {
  signalerGerimo();
  const texte = `${quand} : ${r.type.toLowerCase()} — ${r.titre}${r.lieu ? ", " + r.lieu : ""}.`;
  document.querySelectorAll(".rappel-pop").forEach(p => p.remove());
  const pop = document.createElement("div");
  pop.className = "rappel-pop";
  pop.setAttribute("role", "alert");
  pop.innerHTML = `<b>⏰ ${esc(quand)} — ${esc(r.type)} à ${esc(r.heure)}</b><p>${esc(r.titre)}${r.lieu ? "<br>📍 " + esc(r.lieu) : ""}${r.telephone ? "<br>📞 " + esc(r.telephone) : ""}</p>
    <div class="actions">
      ${r.telephone ? `<button class="btn-sm wa" data-action='${esc(JSON.stringify({ type: "whatsapp", telephone: r.telephone, texte: "" }))}'>WhatsApp</button>` : ""}
      <button class="btn-sm" data-pop="fait">C'est fait</button>
      <button class="btn-sm" data-pop="reporter">Dans 15 min</button>
      <button class="btn-sm" data-pop="fermer">Fermer</button>
    </div>`;
  document.body.appendChild(pop);
  pop.addEventListener("click", async e => {
    const action = e.target.dataset.pop;
    if (!action) return;
    if (action === "fait") await api(`/api/agenda/${r.id}/fait`, { method: "POST" }).catch(() => {});
    if (action === "reporter") {
      const e = await api(`/api/agenda/${r.id}/reporter`, { method: "POST", body: { minutes: 15 } }).catch(() => null);
      if (e && e.heure) {  // rappel suivant : à la nouvelle heure (pas de « dans 15 minutes » immédiat)
        const nouveau = { ...r, date: e.date_evenement, heure: e.heure.slice(0, 5), rappel_minutes: 0 };
        delaisRappel(nouveau).forEach(d => noterRappelVu(cleRappel(nouveau, d)));
      }
    }
    pop.remove();
    if (action !== "fermer") { await chargerAssistant(); rafraichirAgendas(); }
  });
  setTimeout(() => pop.remove(), 10 * 60 * 1000);
  // son discret + voix + notification du système (si la page est en arrière-plan)
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination); o.frequency.value = 880; g.gain.value = 0.08;
    o.start(); o.stop(ctx.currentTime + 0.25);
  } catch { /* pas de son */ }
  if (voixActive()) parler(texte);
  if ("Notification" in window && Notification.permission === "granted" && document.hidden) {
    try { new Notification("Gérimo — " + quand, { body: `${r.type} : ${r.titre}`, icon: "/static/img/icone-192.png" }); } catch { /* rien */ }
  }
}
