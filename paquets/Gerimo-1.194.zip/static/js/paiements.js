// Étape 4 : paiements, encaissements et impayés.
// Le montant est toujours calculé (mois complets) ; le serveur le revérifie,
// applique la commission du bien et met à jour les impayés.

let paiementsCache = [];
let impayesCache = [];
let echeancesCache = [];
let envoisWhatsApp = {};   // { contrat_id: { rappel: "02/10/2026", retard: … } }
let optionsPaiement = null;

// Bouton WhatsApp (désactivé sans numéro) + date du dernier envoi de ce type
function boutonWhatsApp(libelle, action, telephone, classe = "wa") {
  if (classe === "wa") return ibtn("whatsapp", libelle, action, { desactive: telephone ? null : "Pas de numéro de téléphone" });
  return `<button class="btn-sm ${classe}" onclick="${action}" ${telephone ? "" : 'disabled title="Pas de numéro de téléphone"'}>${libelle}</button>`;
}
function dernierEnvoi(contratId, type, libelle) {
  const quand = envoisWhatsApp[contratId]?.[type];
  return quand ? ` — <span class="envoye">${libelle} le ${quand}</span>` : "";
}

// ---------- Écran Paiements & Impayés ----------

async function chargerPaiements() {
  const zone = el("listePaiements");
  try {
    [paiementsCache, impayesCache, echeancesCache, envoisWhatsApp] = await Promise.all([
      api("/api/paiements"), api("/api/impayes"), api("/api/echeances/a-venir"), api("/api/whatsapp/derniers-envois"),
    ]);
  } catch (e) {
    zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`;
    return;
  }

  const lignesPaiements = paiementsCache.map(p => {
    const annule = p.statut_paiement === "Annulé";
    const infos = [p.repris ? `Repris de l'ancien logiciel (${esc(p.numero_recu)})` : `N° ${esc(p.numero_recu)}`, esc(p.motif_paiement)];
    if (p.periode) infos.push(esc(p.periode));
    if (p.versement_partiel) infos.push("<b>Versement partiel</b>");
    infos.push(esc(p.logement));
    if (p.commission_entreprise !== undefined) {  // répartition visible par l'Admin seulement
      let repartition = `Commission ${formatNombre(p.pourcentage_commission ?? 0)} % : ${formatMontant(p.commission_entreprise)} — Reversé : ${formatMontant(p.montant_reverse)}`;
      if (p.montant_caution) repartition += ` — Caution gardée : ${formatMontant(p.montant_caution)}`;
      if (p.montant_penalite) repartition += ` — dont pénalité de retard : ${formatMontant(p.montant_penalite)}`;
      infos.push(repartition);
    }
    if (annule) infos.push(`Annulé${p.motif_annulation ? " : " + esc(p.motif_annulation) : ""}`);
    return `<div class="row"${motsCles({ tel: [p.telephone], textes: [p.adresse, p.numero_contrat] })}>
      <span class="who"><b>${esc(p.locataire)}</b> — ${formatMontant(p.montant)} — ${esc(p.mode_paiement)} — ${formatDate(p.date_paiement)}
        <br><span class="petit">${infos.join(" — ")}</span></span>
      <span class="boutons">
        <span class="pill ${annule ? "danger" : "ok"}">${esc(p.statut_paiement)}</span>
        ${annule || p.repris ? "" : ibtn("recu", "Reçu de paiement (PDF)", `ouvrirRecu(${p.id})`)}
        ${annule || !p.quittance_possible ? "" : ibtn("quittance", "Quittance de loyer (PDF)", `ouvrirQuittance(${p.id})`)}
        ${annule || p.repris ? "" : boutonWhatsApp("Confirmation de paiement WhatsApp", `envoyerWhatsApp('confirmation', {paiement_id: ${p.id}})`, p.telephone)}
        ${estAdmin() && !annule ? ibtn("annuler", "Annuler cet encaissement (Admin)", `annulerEncaissement(${p.id})`) : ""}
      </span>
    </div>`;
  }).join("");

  const lignesImpayes = impayesCache.map(i => `<div class="row"${motsCles({ tel: [i.locataire.telephone], textes: [i.adresse] })}>
      <span class="who"><b>${esc(i.locataire.nom_complet)}</b> — ${esc(i.logement)} — ${i.nb_mois} mois dû${i.nb_mois > 1 ? "s" : ""} — ${formatMontant(i.montant)}${i.deja_verse ? ` (${formatMontant(i.deja_verse)} déjà versés)` : ""}
        <br><span class="petit">${esc(i.mois.join(", "))} — N° ${esc(i.numero_contrat)}${dernierEnvoi(i.id, "retard", "Alerte envoyée")}${dernierEnvoi(i.id, "expulsion", "Avis d'expulsion envoyé")}</span></span>
      <span class="boutons">
        <span class="pill ${i.a_risque ? "danger" : "warn"}">${i.a_risque ? "À risque" : "Retard"}</span>
        <button class="btn-sm" onclick="encaisserPour(${i.id})">Encaisser</button>
        ${boutonWhatsApp("Alerte de retard WhatsApp", `envoyerWhatsApp('retard', {contrat_id: ${i.id}}, chargerPaiements)`, i.locataire.telephone)}
        ${estAdmin() && i.a_risque ? boutonWhatsApp("Avis d'expulsion", `avisExpulsion(${i.id})`, i.locataire.telephone, "resil") : ""}
      </span>
    </div>`).join("");

  const lignesEcheances = echeancesCache.map(e => `<div class="row"${motsCles({ tel: [e.locataire.telephone], textes: [e.adresse] })}>
      <span class="who"><b>${esc(e.locataire.nom_complet)}</b> — ${esc(e.logement)} — ${esc(e.mois)} — ${formatMontant(e.montant)}
        <br><span class="petit">À payer au plus tard le ${formatDate(e.date_limite)} (${e.jours_restants === 0 ? "aujourd'hui" : "dans " + e.jours_restants + " jour" + (e.jours_restants > 1 ? "s" : "")}) — N° ${esc(e.numero_contrat)}${dernierEnvoi(e.id, "rappel", "Rappel envoyé")}</span></span>
      <span class="boutons">
        <span class="pill info">À venir</span>
        <button class="btn-sm" onclick="encaisserPour(${e.id})">Encaisser</button>
        ${boutonWhatsApp("Rappel avant échéance WhatsApp", `envoyerWhatsApp('rappel', {contrat_id: ${e.id}}, chargerPaiements)`, e.locataire.telephone)}
      </span>
    </div>`).join("");

  zone.innerHTML = await carteHorsReseau() + `
    <div class="card"><h3>Encaissements récents</h3>
      ${lignesPaiements || '<div class="vide">Aucun encaissement pour l\'instant.</div>'}</div>
    <div class="card"><h3>Impayés &amp; retards</h3>
      ${lignesImpayes || '<div class="vide">Aucun impayé : tous les loyers échus sont réglés.</div>'}</div>
    <div class="card"><h3>Échéances à venir (7 jours)</h3>
      ${lignesEcheances || '<div class="vide">Aucune échéance dans les 7 prochains jours.</div>'}</div>`;
  el("recherchePaiements").dispatchEvent(new Event("input"));
}
CHARGEURS.paiements = chargerPaiements;

// ---------- Encaissements faits hors réseau (Caisse et Admin) ----------
// Au retour du serveur, chaque encaissement fait hors réseau devient un vrai reçu. Deux choses restent à la Caisse :
// décider quand le locataire avait AUSSI payé au bureau entre-temps, et confirmer que l'agent lui a remis l'argent.
async function carteHorsReseau() {
  if (!moi || !["Admin", "Caisse"].includes(moi.role)) return "";
  let e;
  try { e = await api("/api/hors-reseau/encaissements"); } catch { return ""; }
  const depenses = e.depenses_a_controler || [];
  if (!e.a_verifier.length && !e.a_remettre.length && !depenses.length) return "";
  const quand = iso => `${formatDate(iso.slice(0, 10))} à ${iso.slice(11, 16)}`;
  const verifier = e.a_verifier.map(o => `<div class="row">
      <span class="who"><b>${esc(o.resume)}</b><br><span class="petit">${esc(o.utilisateur)} · saisi le ${quand(o.saisi_le)}</span>
        <br><span class="petit" style="color:var(--danger)">${esc(o.detail || "")}</span></span>
      <span class="boutons"><button class="btn-sm" onclick="deciderHorsReseau(${o.id}, 'reessayer')">Enregistrer quand même</button>
        <button class="btn-sm del" onclick="deciderHorsReseau(${o.id}, 'abandonner')">Abandonner</button></span></div>`).join("");
  const remettre = e.a_remettre.map(o => `<div class="row">
      <span class="who"><b>${esc(o.locataire || "")}</b> — ${formatMontant(o.montant)} — ${esc(o.mode || "")}
        <br><span class="petit">Reçu N° ${esc(o.numero_recu || "?")} · encaissé hors réseau par <b>${esc(o.utilisateur)}</b> le ${quand(o.saisi_le)}</span></span>
      <span class="boutons"><button class="btn-sm wa" onclick="argentRecuHorsReseau(${o.id})">Argent reçu</button></span></div>`).join("");
  const controler = depenses.map(o => `<div class="row">
      <span class="who"><b>${esc(o.motif || o.resume)}</b> — ${formatMontant(o.montant)} — ${esc(o.mode || "")}
        <br><span class="petit">Dépense saisie hors réseau par <b>${esc(o.utilisateur)}</b> le ${quand(o.saisi_le)}</span></span>
      <span class="boutons"><button class="btn-sm" onclick="argentRecuHorsReseau(${o.id}, true)">Contrôlée</button></span></div>`).join("");
  return `<div class="card"><h3>Faits hors réseau : à vérifier par la caisse</h3>
    ${verifier ? `<p class="petit" style="margin-top:-.4rem">À vérifier : le locataire avait aussi payé pendant que l'agent était hors réseau.</p>${verifier}` : ""}
    ${remettre ? `<p class="petit"${verifier ? "" : ' style="margin-top:-.4rem"'}>Argent à remettre à la caisse : quand l'agent vous remet la somme, confirmez-le (rien à ressaisir).</p>${remettre}` : ""}
    ${controler ? `<p class="petit">Dépenses payées par un agent hors réseau : vérifiez le justificatif et la monnaie rendue.</p>${controler}` : ""}
  </div>`;
}

async function deciderHorsReseau(id, action) {
  if (action === "abandonner" && !confirm("Abandonner cet enregistrement fait hors réseau ? Il ne sera pas enregistré (pour un encaissement reçu deux fois, pensez à rembourser le locataire).")) return;
  if (action === "reessayer" && !confirm("L'enregistrer quand même ? (Un encaissement couvrira les mois suivants du contrat.)")) return;
  try {
    const o = await api(`/api/hors-reseau/a-verifier/${id}/${action}`, { method: "POST" });
    toast(o.statut === "Envoyée" ? "Enregistré ✅" : o.statut === "Abandonnée" ? "Écarté" : `Toujours refusé : ${o.detail}`, 6000);
    chargerPaiements();
  } catch (e) { toast(e.message); }
}

async function argentRecuHorsReseau(id, depense = false) {
  try {
    await api(`/api/hors-reseau/encaissements/${id}/argent-recu`, { method: "POST" });
    toast(depense ? "Dépense contrôlée ✅ (noté au journal)" : "Argent reçu ✅ (noté au journal)");
    chargerPaiements();
  } catch (e) { toast(e.message); }
}

// Le reçu PDF s'ouvre dans un nouvel onglet, prêt à imprimer (Ctrl + P)
function ouvrirRecu(paiementId) {
  window.open(`/api/paiements/${paiementId}/recu`, "_blank");
}

// Quittance : sans caution, avance ni reste (règle ISUP)
function ouvrirQuittance(paiementId) {
  window.open(`/api/paiements/${paiementId}/quittance`, "_blank");
}

// Avis d'expulsion : acte sérieux, on demande confirmation avant d'ouvrir WhatsApp
function avisExpulsion(contratId) {
  const i = impayesCache.find(x => x.id === contratId);
  if (!i) return;
  if (!confirm(`Préparer l'avis d'expulsion pour ${i.locataire.nom_complet} (${i.nb_mois} mois impayés, ${formatMontant(i.montant)}) ?\n\n` +
               "Ce message annonce une procédure de résiliation et d'expulsion.")) return;
  envoyerWhatsApp("expulsion", { contrat_id: contratId }, chargerPaiements);
}

// ---------- Formulaire d'encaissement ----------

function contratChoisi() {
  return optionsPaiement?.contrats.find(c => String(c.id) === el("payContrat").value) || null;
}

async function preparerFormPaiement(contratId) {
  optionsPaiement = await api("/api/paiements/options");
  const o = optionsPaiement;
  remplirSelect(el("payContrat"), o.contrats, {
    valeur: c => c.id,
    texte: c => `N° ${c.numero_contrat} — ${c.locataire.nom_complet} — ${c.logement}${c.impayes ? " (en retard)" : ""}`,
    vide: o.contrats.length ? "— Choisir —" : "Aucun contrat",
  });
  remplirSelect(el("payMode"), o.modes_paiement);
  await preparerChoixCompte("payMode", "payCompte");
  fixerDate("payDate", aujourdhui());
  el("payObservation").value = "";
  el("payRemise").checked = false;
  el("payPartiel").checked = false;
  if (contratId) el("payContrat").value = contratId;
  majMotifs();
  erreurFormulaire(el("formulairePaiement"), "");
}

// Motifs possibles selon le contrat, et motif proposé par défaut
function majMotifs() {
  const c = contratChoisi();
  const sel = el("payMotif");
  sel.innerHTML = optionsPaiement.motifs_paiement.map(m => {
    let desactive = !c;
    let texte = m;
    if (c && m === "Caution/avance" && (c.entree.payee || c.entree.total <= 0)) {
      desactive = true;
      texte += c.entree.payee ? " (déjà encaissée)" : " (rien à encaisser)";
    }
    if (c && m === "Règlement total" && !c.reglement_total.nb_mois) { desactive = true; texte += " (rien de dû)"; }
    if (c && m === "Loyer mensuel" && !c.prochains_mois.length) { desactive = true; texte += " (fin du bail)"; }
    return `<option value="${esc(m)}" ${desactive ? "disabled" : ""}>${esc(texte)}</option>`;
  }).join("");
  if (c) {
    const premierPossible = [...sel.options].find(o => !o.disabled);
    sel.value = !c.entree.payee && c.entree.total > 0 ? "Caution/avance"
      : (!sel.querySelector('option[value="Loyer mensuel"]').disabled ? "Loyer mensuel" : premierPossible?.value || "");
    const max = Math.min(c.prochains_mois.length, optionsPaiement.nb_mois_max);
    remplirSelect(el("payNbMois"), Array.from({ length: Math.max(max, 1) }, (_, k) => k + 1), {
      texte: n => `${n} mois`,
    });
  }
  majCalcul();
}

// Pénalité de retard d'un mois (même calcul que penalites.py ; le serveur revérifie)
function penaliteMois(loyer, limiteIso, jourIso) {
  const r = optionsPaiement.penalite;
  if (!r.active || !jourIso) return 0;
  const seuil = new Date(limiteIso + "T00:00:00");
  seuil.setDate(seuil.getDate() + r.tolerance);
  const jour = new Date(jourIso + "T00:00:00");
  if (jour <= seuil) return 0;
  let fois = 1;
  if (r.cumul === "par_mois") {
    const n = (jour.getFullYear() - seuil.getFullYear()) * 12 + jour.getMonth() - seuil.getMonth() - (jour.getDate() < seuil.getDate() ? 1 : 0);
    fois += Math.max(n, 0);
  }
  const unite = r.mode === "pourcentage" ? loyer * r.valeur / 100 : r.valeur;
  return Math.round(unite * fois);
}

function jourDuPaiement() {
  try { return valeurDate("payDate", "Date") || aujourdhui(); } catch { return aujourdhui(); }
}

// La pénalité se calcule sur le loyer entier du mois, même s'il n'en reste qu'une partie à payer
function penaliteDe(mois) {
  const jour = jourDuPaiement();
  return mois.reduce((s, m) => s + penaliteMois(m.loyer ?? m.montant, m.date_limite, jour), 0);
}

function modePartiel() {
  return el("payMotif").value === "Loyer mensuel" && el("payPartiel").checked;
}

// Versement partiel (arrangement) : le montant saisi solde d'abord les mois les plus anciens, le reste va sur le
// mois suivant, qui garde un « reste à payer ». Même répartition que le serveur, qui la revérifie.
function calculPartiel() {
  const c = contratChoisi();
  if (!c) return null;
  const jour = jourDuPaiement();
  const remiseVoulue = el("payRemise").checked;
  const saisi = lireMontant(el("payMontant").value);
  const calc = { partiel: true, montant: saisi || 0, lignes: [], penalite: 0, remise: 0,
                 penalitePossible: penaliteDe(c.reglement_total.mois) > 0 };
  if (!saisi) return { ...calc, erreur: "Saisissez le montant versé par le locataire." };
  let disponible = saisi;
  for (const m of c.reglement_total.mois) {
    if (disponible <= 0) break;
    const penalite = penaliteMois(m.loyer ?? m.montant, m.date_limite, jour);
    const due = remiseVoulue ? 0 : penalite;
    if (disponible >= m.montant + due) {  // le mois est soldé
      calc.lignes.push({ libelle: m.libelle, montant: m.montant, reste: 0 });
      calc.penalite += due;
      calc.remise += remiseVoulue ? penalite : 0;
      disponible -= m.montant + due;
    } else if (disponible >= m.montant) {  // de quoi payer le loyer, mais pas la pénalité réclamée quand le mois est soldé
      const deja = saisi - disponible;
      return { ...calc, erreur: `Avec la pénalité de retard (${formatMontant(due)}), il faut ${formatMontant(deja + m.montant + due)} pour solder ${m.libelle}. Saisissez ce montant, ou moins de ${formatMontant(deja + m.montant)}.` };
    } else {
      calc.lignes.push({ libelle: m.libelle, montant: disponible, reste: m.montant - disponible });
      disponible = 0;
    }
  }
  if (disponible > 0) {
    return { ...calc, erreur: `Ce montant dépasse ce qui est dû à ce jour (${formatMontant(saisi - disponible)}). Pour payer des mois d'avance, décochez « Versement partiel ».` };
  }
  return calc;
}

// Montant et période : des mois complets (plus la pénalité de retard éventuelle), sauf versement partiel
function calculEncaissement() {
  if (modePartiel()) return calculPartiel();
  const calc = calculSansPenalite();
  if (!calc || !calc.mois) return calc;
  const penalite = penaliteDe(calc.mois);
  const remise = penalite > 0 && el("payRemise").checked;
  return { ...calc, penalite: remise ? 0 : penalite, remise: remise ? penalite : 0,
           montant: calc.montant + (remise ? 0 : penalite) };
}

function calculSansPenalite() {
  const c = contratChoisi();
  if (!c) return null;
  const motif = el("payMotif").value;
  if (motif === "Caution/avance") {
    const e = c.entree;
    const detail = `caution ${formatMontant(e.montant_caution)} + avance ${formatMontant(e.montant_avance)}` +
      (e.mois_avance.length ? ` (${e.mois_avance.join(", ")})` : "");
    return { montant: e.total, periode: e.mois_avance.length ? e.mois_avance[0] + (e.mois_avance.length > 1 ? " à " + e.mois_avance.at(-1) : "") : "—", detail };
  }
  if (motif === "Règlement total") {
    const r = c.reglement_total;
    return { montant: r.montant, periode: r.periode, detail: `${r.nb_mois} mois dû${r.nb_mois > 1 ? "s" : ""} à ce jour`, mois: r.mois };
  }
  const n = Number(el("payNbMois").value) || 1;
  const mois = c.prochains_mois.slice(0, n);
  if (!mois.length) return null;
  const total = mois.reduce((s, m) => s + m.montant, 0);
  return {
    montant: total,
    periode: mois[0].libelle + (mois.length > 1 ? " à " + mois.at(-1).libelle : ""),
    // après un versement partiel, le premier mois peut n'être que le reste d'un mois entamé
    detail: mois.every(m => m.montant === mois[0].montant && m.montant === (m.loyer ?? m.montant))
      ? `${mois.length} mois × ${formatMontant(mois[0].montant)}`
      : mois.map(m => `${m.montant < (m.loyer ?? m.montant) ? "solde de " : ""}${m.libelle} : ${formatMontant(m.montant)}`).join(" + "),
    mois,
  };
}

// Ce qui est dû à ce jour, mois par mois (avec ce qui a déjà été versé sur un mois entamé)
function texteDu(c) {
  return c.reglement_total.mois.map(m => `${esc(m.libelle)} : ${formatMontant(m.montant)}` +
    (m.loyer > m.montant ? ` (${formatMontant(m.loyer - m.montant)} déjà versés)` : "")).join(", ");
}

function recapPartiel(c, calc) {
  let html = `Dû à ce jour : <b>${formatMontant(c.reglement_total.montant)}</b> — ${texteDu(c)}`;
  if (calc.penalitePossible) html += `<br>La pénalité de retard s'ajoute au versement qui solde un mois.`;
  if (calc.erreur) return html + `<br><b style="color:var(--danger)">${esc(calc.erreur)}</b>`;
  html += `<br>Répartition de <b>${formatMontant(calc.montant)}</b> :` + calc.lignes.map(l =>
    `<br>• ${esc(l.libelle)} : ${formatMontant(l.montant)} → ${l.reste ? `<b>reste ${formatMontant(l.reste)}</b>` : "soldé"}`).join("");
  if (calc.penalite) html += `<br>• pénalité de retard : ${formatMontant(calc.penalite)}`;
  if (calc.remise) html += `<br>Pénalité de retard de ${formatMontant(calc.remise)} remise : elle sera notée dans l'observation.`;
  if (!calc.lignes.some(l => l.reste)) html += `<br>Tout est soldé : ce sera un encaissement normal.`;
  return html;
}

function majCalcul() {
  const c = contratChoisi();
  const loyer = el("payMotif").value === "Loyer mensuel";
  // la case « Versement partiel » est proposée dès que le contrat a des loyers déjà dus, quel que soit le motif
  // affiché (la cocher choisit « Loyer mensuel »)
  const partielPossible = Boolean(c && c.reglement_total.nb_mois);
  el("champPartiel").style.display = partielPossible ? "" : "none";
  if (!partielPossible || !loyer) el("payPartiel").checked = false;
  const partiel = modePartiel();
  el("champNbMois").style.display = loyer && !partiel ? "" : "none";
  const champ = el("payMontant");
  if (champ.readOnly === partiel) {  // on change de mode : montant libre ou calculé
    champ.readOnly = !partiel;
    champ.title = partiel ? "Montant versé par le locataire" : "Calculé automatiquement : toujours des mois complets";
    champ.placeholder = partiel ? "ex : 80 000" : "";
    if (partiel) { champ.value = ""; champ.focus(); }
  }
  const calc = calculEncaissement();
  if (!partiel) champ.value = calc ? formatNombre(calc.montant) : "";
  if (!c || !calc) { el("payRecap").innerHTML = "Choisissez le contrat."; return; }
  el("champRemise").style.display = optionsPaiement.remise_penalite_possible
    && (calc.penalite || calc.remise || calc.penalitePossible) ? "" : "none";
  if (partiel) { el("payRecap").innerHTML = recapPartiel(c, calc); return; }
  let html = `Période couverte : <b>${esc(calc.periode)}</b><br>Montant à encaisser : <b>${formatMontant(calc.montant)}</b> — ${esc(calc.detail)}`;
  if (calc.penalite) html += `<br>dont <b>pénalité de retard : ${formatMontant(calc.penalite)}</b> (Paramètres → Réglages)`;
  if (calc.remise) html += `<br>Pénalité de retard de ${formatMontant(calc.remise)} remise : elle sera notée dans l'observation.`;
  if (c.impayes) html += `<br>Attention : ${c.impayes.nb_mois} mois en retard (${esc(c.impayes.mois.join(", "))}). Le loyer mensuel règle d'abord les mois les plus anciens.`;
  el("payRecap").innerHTML = html;
}
el("payContrat").addEventListener("change", majMotifs);
el("payMotif").addEventListener("change", majCalcul);
el("payNbMois").addEventListener("change", majCalcul);
el("payRemise").addEventListener("change", majCalcul);
el("payPartiel").addEventListener("change", () => {
  if (el("payPartiel").checked) el("payMotif").value = "Loyer mensuel";  // un versement partiel porte sur des loyers
  majCalcul();
});
el("payMontant").addEventListener("input", () => { if (modePartiel()) majCalcul(); });
// la pénalité dépend de la date du paiement (champ remplacé au chargement : on écoute le formulaire)
["input", "change"].forEach(t => el("formulairePaiement").addEventListener(t, ev => {
  if (ev.target.closest && ev.target.closest(".field")?.querySelector("#payDate")) majCalcul();
}));

async function nouvelEncaissement() {
  await preparerFormPaiement(null);
  afficher("formPaiement");
}

async function encaisserPour(contratId) {
  await preparerFormPaiement(contratId);
  afficher("formPaiement");
}

el("formulairePaiement").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    const c = contratChoisi();
    if (!c) throw new Error("Choisissez le contrat.");
    const calc = calculEncaissement();
    if (!calc || !el("payMotif").value) throw new Error("Rien à encaisser pour ce motif.");
    if (calc.erreur) throw new Error(calc.erreur);
    const datePaiement = valeurDate("payDate", "Date");
    if (datePaiement && datePaiement > aujourdhui()) throw new Error("La date du paiement ne peut pas être dans le futur.");
    const rep = await api("/api/paiements", {
      method: "POST",
      body: {
        contrat_id: c.id,
        motif_paiement: el("payMotif").value,
        nb_mois: Number(el("payNbMois").value) || 1,
        mode_paiement: el("payMode").value,
        date_paiement: datePaiement,
        montant: calc.montant,
        observation: el("payObservation").value,
        compte_id: compteChoisi("payCompte"),
        remise_penalite: Boolean(calc.remise),
        versement_partiel: Boolean(calc.partiel),
      },
    });
    toast(String(rep.numero_recu).startsWith("BP-")  // hors réseau : bon provisoire (static/hors_reseau/local.js)
      ? `Encaissé hors réseau — bon provisoire ${rep.numero_recu} : le reçu officiel sera créé au retour du serveur`
      : rep.versement_partiel
      ? `Versement partiel encaissé — Reçu N° ${rep.numero_recu} : il reste ${formatMontant(rep.reste)} à payer sur ${rep.repartition.at(-1).mois}`
      : `Encaissé — Reçu N° ${rep.numero_recu}${rep.periode ? " (" + rep.periode + ")" : ""} : bouton « Reçu » pour l'imprimer`, 6000);
    goBack();
  });
});

// ---------- Annulation (Admin) ----------

function annulerEncaissement(id) {
  const p = paiementsCache.find(x => x.id === id);
  if (!p) return;
  const fond = el("modalAnnulation");
  const form = el("formAnnulation");
  el("annulationTexte").textContent =
    `Reçu N° ${p.numero_recu} — ${p.locataire}, ${formatMontant(p.montant)}${p.periode ? " (" + p.periode + ")" : ""}. ` +
    "L'encaissement restera visible avec le statut « Annulé » et les mois redeviendront à payer.";
  el("annulationMotif").value = "";
  el("annulationMdp").value = "";
  reinitialiserSaisie(form);
  erreurFormulaire(form, "");
  fond.classList.add("show");
  el("annulationMotif").focus();

  const fermer = () => { fond.classList.remove("show"); form.onsubmit = null; };
  el("annulationFermer").onclick = fermer;
  form.onsubmit = ev => {
    ev.preventDefault();
    soumettre(form, async () => {
      await api(`/api/paiements/${id}/annuler`, {
        method: "POST",
        body: { mot_de_passe_admin: el("annulationMdp").value, motif: el("annulationMotif").value },
      });
      fermer();
      toast("Encaissement annulé");
      await chargerPaiements();
    });
  };
}

brancherRecherche(el("recherchePaiements"), el("listePaiements"));

// ---------- Historique des paiements (Finances) ----------

let historiqueCache = null;

function preparerHistorique() {
  if (!el("histMode").options.length) {
    remplirSelect(el("histMode"), ["Espèce", "Mobile Money", "Virement", "Chèque", "Autre"], { vide: "Tous les modes" });
    const d = new Date();
    fixerDate("histDebut", `${d.getFullYear()}-01-01`);
    fixerDate("histFin", aujourdhui());
  }
}

async function chargerHistorique() {
  preparerHistorique();
  const form = el("formulaireHistorique");
  erreurFormulaire(form, "");
  let parametres;
  try {
    parametres = new URLSearchParams();
    const debut = valeurDate("histDebut", "Du"), fin = valeurDate("histFin", "Au");
    if (debut) parametres.set("debut", debut);
    if (fin) parametres.set("fin", fin);
    if (el("histStatut").value) parametres.set("statut", el("histStatut").value);
    if (el("histMode").value) parametres.set("mode", el("histMode").value);
    historiqueCache = await api("/api/paiements/historique?" + parametres);
  } catch (e) { erreurFormulaire(form, e.message); return; }
  const t = historiqueCache.totaux;
  el("histTotaux").innerHTML = `
    <div class="kpi ok"><div class="label">Total encaissé</div><div class="value">${formatMontant(t.encaisse)}</div><div class="sous-valeur">${t.nombre} paiement(s)</div></div>
    ${t.commission_entreprise !== undefined ? `<div class="kpi info"><div class="label">Commission de gestion</div><div class="value">${formatMontant(t.commission_entreprise)}</div></div>` : ""}
    <div class="kpi warn"><div class="label">Annulés</div><div class="value">${t.annules}</div></div>`;
  const lignes = historiqueCache.paiements.map(p => {
    const annule = p.statut_paiement === "Annulé";
    return `<tr${motsCles({ tel: [p.telephone], textes: [p.numero_contrat, p.numero_recu] })}>
      <td>${formatDate(p.date_paiement)}</td><td>${esc(p.numero_recu)}</td><td><b>${esc(p.locataire)}</b><br><span class="petit">${esc(p.logement)}</span></td>
      <td>${esc(p.motif_paiement)}<br><span class="petit">${esc(p.periode || "")}</span></td><td>${esc(p.mode_paiement)}</td>
      <td class="nombre">${formatMontant(p.montant)}</td>
      ${p.commission_entreprise !== undefined ? `<td class="nombre">${formatMontant(p.commission_entreprise)}</td>` : ""}
      <td><span class="pill ${annule ? "danger" : "ok"}">${esc(p.statut_paiement)}</span></td>
      <td style="white-space:nowrap">${annule || p.repris ? "" : ibtn("recu", "Reçu (PDF)", `ouvrirRecu(${p.id})`)}
        ${annule || !p.quittance_possible ? "" : ibtn("quittance", "Quittance (PDF)", `ouvrirQuittance(${p.id})`)}</td></tr>`;
  }).join("");
  const admin = historiqueCache.totaux.commission_entreprise !== undefined;
  el("listeHistorique").innerHTML = lignes ? `<div class="card defilement"><table class="tableau"><thead><tr><th>Date</th><th>N° reçu</th><th>Locataire</th>
      <th>Motif / période</th><th>Mode</th><th class="nombre">Montant</th>${admin ? '<th class="nombre">Commission</th>' : ""}<th>Statut</th><th></th></tr></thead>
      <tbody>${lignes}</tbody></table></div>` : '<div class="card vide">Aucun paiement sur cette période.</div>';
  filtrerHistorique();
}
CHARGEURS.historique = chargerHistorique;
el("formulaireHistorique").addEventListener("submit", e => { e.preventDefault(); chargerHistorique(); });
["histStatut", "histMode"].forEach(id => el(id).addEventListener("change", chargerHistorique));

// Recherche dans le tableau (lignes <tr>)
function filtrerHistorique() {
  const recherche = preparerRecherche(el("rechercheHistorique").value);
  el("listeHistorique").querySelectorAll("tbody tr").forEach(tr => {
    tr.style.display = !recherche.mots.length || ligneTrouvee(tr, recherche) ? "" : "none";
  });
}
el("rechercheHistorique").addEventListener("input", filtrerHistorique);

function exporterHistorique() {
  const parametres = new URLSearchParams();
  try {
    const debut = valeurDate("histDebut", "Du"), fin = valeurDate("histFin", "Au");
    if (debut) parametres.set("debut", debut);
    if (fin) parametres.set("fin", fin);
  } catch (e) { toast(e.message); return; }
  exporter("paiements", parametres.toString());
}

// ---------- Chiffres clés en tête de l'écran Finances ----------
async function chargerKpisFinances() {
  const zone = el("financesKpis");
  if (!peut("rapports")) { zone.innerHTML = ""; return; }
  try {
    const t = await api("/api/tableau-de-bord");
    zone.innerHTML = `
      <div class="kpi ok cliquable" onclick="afficher('historique')"><div class="label">Encaissé ce mois</div><div class="value">${formatMontant(t.loyers_encaisses)}</div><div class="sous-valeur">Voir l'historique</div></div>
      <div class="kpi warn"><div class="label">Impayés en cours</div><div class="value">${t.impayes_en_cours}</div><div class="sous-valeur">contrat(s) en retard</div></div>
      <div class="kpi risk"><div class="label">Contrats à risque</div><div class="value">${t.contrats_a_risque}</div><div class="sous-valeur">2 mois ou plus</div></div>
      ${t.commission_entreprise !== undefined ? `<div class="kpi info"><div class="label">Commission de gestion du mois</div><div class="value">${formatMontant(t.commission_entreprise)}</div></div>` : ""}`;
  } catch { zone.innerHTML = ""; }
}
const _chargerPaiementsSimple = CHARGEURS.paiements;
CHARGEURS.paiements = () => { _chargerPaiementsSimple(); chargerKpisFinances(); };
