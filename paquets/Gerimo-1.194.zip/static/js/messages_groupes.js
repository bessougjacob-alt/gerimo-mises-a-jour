// ---------- Messages groupés (demande de Boss du 11/11/2026) ----------
// 1. Envoi en série : Gérimo ouvre WhatsApp pour chaque locataire coché, l'un après l'autre (message déjà écrit,
//    il suffit d'appuyer sur « Envoyer »). Les liens wa.me sont gratuits, mais WhatsApp exige un clic par message.
// 2. Liste de diffusion : fichier de contacts (.vcf) pour le téléphone de l'agence, et texte à copier.

let groupe = { lignes: [], faits: new Set() };

const EXPLICATIONS_GROUPE = {
  rappel: "Locataires dont le loyer arrive à échéance dans les 7 prochains jours (en début de mois : le loyer du mois, à payer avant le 05). Message « rappel » des modèles, avec le montant et la date limite de chacun.",
  retard: "Locataires qui ont des loyers impayés. Message « retard » des modèles, avec les mois et le montant dus par chacun. (L'avis d'expulsion reste à envoyer un par un, depuis Finances.)",
  annonce: "Tous les locataires en place (ou ceux d'un bien). Écrivez votre message ci-dessus : il est personnalisé pour chacun avec les zones entre accolades.",
};

async function chargerMessagesGroupes() {
  const type = el("mgType").value;
  el("mgZoneTexte").hidden = type !== "annonce";
  el("mgExplication").textContent = EXPLICATIONS_GROUPE[type];
  el("mgListe").innerHTML = '<div class="petit">Chargement…</div>';
  try {
    groupe = { lignes: await api(`/api/whatsapp/serie?type_message=${type}`), faits: new Set() };
  } catch (e) {
    el("mgListe").innerHTML = `<div class="card vide">${esc(e.message)}</div>`;
    return;
  }
  // Destinataires : tous, ou un bien (liste tirée des contrats visibles par l'utilisateur)
  const biens = [...new Map(groupe.lignes.map(l => [l.cite_id, l.bien])).entries()].sort((a, b) => a[1].localeCompare(b[1]));
  const avant = el("mgBien").value;
  el("mgBien").innerHTML = `<option value="">Tous les biens</option>` +
    biens.map(([id, nom]) => `<option value="${id}">${esc(nom)}</option>`).join("");
  if (biens.some(([id]) => String(id) === avant)) el("mgBien").value = avant;
  afficherMessagesGroupes();
}
CHARGEURS.messagesGroupes = chargerMessagesGroupes;

function lignesVisiblesGroupe() {
  const bien = el("mgBien").value;
  return groupe.lignes.filter(l => !bien || String(l.cite_id) === bien);
}

function afficherMessagesGroupes() {
  const lignes = lignesVisiblesGroupe();
  if (!lignes.length) {
    el("mgListe").innerHTML = '<div class="card vide">Aucun locataire concerné pour l\'instant.</div>';
    majResumeGroupe();
    return;
  }
  el("mgListe").innerHTML = lignes.map(l => {
    const fait = groupe.faits.has(l.contrat_id);
    const etat = fait ? '<span class="pill ok">Envoyé ✓</span>'
      : !l.numero_valide ? '<span class="pill danger" data-tip="Numéro à compléter dans la fiche du locataire">Sans numéro</span>'
      : l.deja ? `<span class="pill info">Déjà prévenu le ${esc(l.deja)}</span>` : "";
    const coche = !fait && l.numero_valide && !l.deja;
    return `<label class="row mg-ligne" data-id="${l.contrat_id}">
      <input type="checkbox" class="mg-coche" value="${l.contrat_id}"${coche ? " checked" : ""}${l.numero_valide ? "" : " disabled"} onchange="majResumeGroupe()">
      <span class="who"><b>${esc(l.locataire)}</b> — ${esc(l.logement)}, ${esc(l.bien)} — <span class="petit">${esc(l.detail)}</span></span>
      <span class="boutons">${etat}</span></label>`;
  }).join("");
  majResumeGroupe();
}

function cochesGroupe() {
  return [...document.querySelectorAll("#mgListe .mg-coche:checked")].map(c => Number(c.value));
}

function majResumeGroupe() {
  const lignes = lignesVisiblesGroupe();
  const restants = cochesGroupe();
  const sansNumero = lignes.filter(l => !l.numero_valide).length;
  el("mgResume").innerHTML = `<b>${restants.length}</b> message${restants.length > 1 ? "s" : ""} à envoyer` +
    ` sur ${lignes.length} locataire${lignes.length > 1 ? "s" : ""}` +
    (groupe.faits.size ? ` — ${groupe.faits.size} envoyé${groupe.faits.size > 1 ? "s" : ""}` : "") +
    (sansNumero ? ` — ${sansNumero} sans numéro` : "");
  const suivant = groupe.lignes.find(l => l.contrat_id === restants[0]);
  el("mgBouton").textContent = !suivant ? "Terminé"
    : groupe.faits.size ? `Suivant : ${suivant.locataire}` : `Commencer l'envoi (${suivant.locataire})`;
  el("mgBouton").disabled = !suivant;
}

function cocherGroupe(oui) {
  document.querySelectorAll("#mgListe .mg-coche:not(:disabled)").forEach(c => {
    c.checked = oui && !groupe.faits.has(Number(c.value));
  });
  majResumeGroupe();
}

async function envoyerSuivantGroupe() {
  const id = cochesGroupe()[0];
  if (!id) return;
  const type = el("mgType").value;
  const texte = el("mgTexte").value.trim();
  if (type === "annonce" && texte.length < 5) { toast("Écrivez d'abord votre message."); el("mgTexte").focus(); return; }
  const fenetre = window.open("", "_blank");  // ouverte tout de suite, sinon le navigateur la bloque
  try {
    const rep = type === "annonce"
      ? await api("/api/whatsapp/annonce", { method: "POST", body: { contrat_id: id, texte } })
      : await api("/api/whatsapp", { method: "POST", body: { type_message: type, contrat_id: id } });
    if (fenetre) fenetre.location.href = rep.lien; else window.location.href = rep.lien;
    groupe.faits.add(id);
    const ligne = document.querySelector(`#mgListe .mg-ligne[data-id="${id}"]`);
    if (ligne) {
      ligne.querySelector(".mg-coche").checked = false;
      ligne.querySelector(".boutons").innerHTML = '<span class="pill ok">Envoyé ✓</span>';
    }
    majResumeGroupe();
  } catch (e) {
    if (fenetre) fenetre.close();
    toast(e.message);
    // ce locataire ne peut pas recevoir ce message (plus d'impayé, numéro…) : on passe au suivant
    const coche = document.querySelector(`#mgListe .mg-coche[value="${id}"]`);
    if (coche) coche.checked = false;
    majResumeGroupe();
  }
}

async function telechargerContactsGroupe() {
  const bien = el("mgBien").value;
  try {
    const f = await apiFichier("/api/whatsapp/contacts" + (bien ? `?cite_id=${bien}` : ""));
    telechargerBlob(f.blob, f.nom || "locataires-whatsapp.vcf");
    toast("Contacts téléchargés : ouvrez le fichier sur le téléphone de l'agence pour les enregistrer.", 7000);
  } catch (e) { toast(e.message); }
}

async function copierMessageGroupe() {
  if (el("mgType").value !== "annonce") {
    el("mgType").value = "annonce";
    await chargerMessagesGroupes();
    toast("Écrivez votre annonce, puis cliquez de nouveau sur « Copier le message ».");
    el("mgTexte").focus();
    return;
  }
  const texte = el("mgTexte").value.trim();
  if (!texte) { toast("Écrivez d'abord votre message."); el("mgTexte").focus(); return; }
  if (/\{\w+\}/.test(texte)) toast("Attention : dans une diffusion, les zones {…} ne sont pas remplies. Retirez-les du message.", 7000);
  try { await navigator.clipboard.writeText(texte); }
  catch { el("mgTexte").select(); document.execCommand("copy"); }
  if (!/\{\w+\}/.test(texte)) toast("Message copié : collez-le dans la diffusion WhatsApp.");
}
