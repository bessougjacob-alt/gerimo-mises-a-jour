// Paramètres → Reprise de données (Admin) : importer les données d'un ancien fichier Excel ou d'un autre logiciel.
// 1. modèle ou fichier du client → 2. feuilles et colonnes reconnues (modifiables) → 3. vérification → 4. import.

let reprise = null;        // { jeton, fichier, feuilles: [...] } renvoyé par l'analyse
let champsReprise = null;  // champs de Gérimo pour chaque type
let verifiee = false;

async function chargerReprise() {
  const zone = el("parReprise");
  if (!champsReprise) {
    try { champsReprise = (await api("/api/import/champs")).types; }
    catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  }
  zone.innerHTML = `
    <div class="card">
      <h3>Reprendre les données d'un ancien fichier ou logiciel</h3>
      <p class="petit" style="margin-top:-.4rem">Pour une entreprise qui gérait ses biens sur Excel ou avec un autre logiciel : presque tous savent
        <b>exporter vers Excel</b>. Envoyez ce fichier (ou le modèle Gérimo rempli) : Gérimo reconnaît les feuilles et les colonnes,
        vérifie chaque ligne avec les mêmes règles que les formulaires, puis importe <b>tout ou rien</b>. Une sauvegarde est faite juste avant,
        et l'import peut être annulé ensuite. Le fichier n'est pas conservé.</p>
      <div class="pj-boutons">
        <button class="btn" onclick="telechargerModeleReprise()">Télécharger le modèle Excel</button>
        <input type="file" id="repFichier" accept=".xlsx,.xlsm,.csv" style="display:none" onchange="envoyerReprise(this)">
        <button class="btn primary" onclick="el('repFichier').click()">Choisir le fichier à importer…</button>
      </div>
    </div>
    <div class="card">
      <h3>Ou directement depuis la base d'un autre logiciel (le « pont »)</h3>
      <p class="petit" style="margin-top:-.4rem">Gérimo lit l'ancienne base <b>en lecture seule</b>, sur ce serveur uniquement (rien n'est envoyé sur Internet).
        Les colonnes confidentielles (mots de passe, codes, données bancaires) ne sont <b>jamais lues</b>, et les remarques sont exclues par défaut.
        Les identifiants de connexion ne sont pas enregistrés. Ensuite, mêmes étapes que pour un fichier Excel.</p>
      <div class="fgrid">
        <div class="field"><label for="pontType">Type de base</label><select id="pontType" onchange="majPont()"></select></div>
        <div class="field" id="pontChampFichier"><label>Fichier de la base</label>
          <input type="file" id="pontFichier" accept=".db,.sqlite,.sqlite3,.db3,.mdb,.accdb" style="display:none" onchange="envoyerBasePont(this)">
          <div class="pj-boutons"><button type="button" class="btn" onclick="el('pontFichier').click()">Choisir le fichier…</button><span class="petit" id="pontNomFichier"></span></div></div>
        <div class="field pont-serveur"><label for="pontHote">Adresse du serveur</label><input id="pontHote" placeholder="192.168.1.20" autocomplete="off"></div>
        <div class="field pont-serveur"><label for="pontPort">Port (vide = habituel)</label><input id="pontPort" inputmode="numeric" autocomplete="off"></div>
        <div class="field pont-serveur"><label for="pontBase">Nom de la base</label><input id="pontBase" autocomplete="off"></div>
        <div class="field pont-serveur"><label for="pontUtilisateur">Identifiant (de préférence en lecture seule)</label><input id="pontUtilisateur" autocomplete="off"></div>
        <div class="field pont-serveur"><label for="pontMdp">Mot de passe</label><input id="pontMdp" type="password" autocomplete="new-password"></div>
      </div>
      <label class="petit" style="display:flex;gap:.5rem;align-items:flex-start;margin:.6rem 0"><input type="checkbox" id="pontAccord">
        <span>Le client m'a autorisé <b>par écrit</b> à lire la base de son ancien logiciel, et la licence de ce logiciel le permet.</span></label>
      <div class="actions"><button class="btn primary" onclick="explorerPont()">Se connecter (lecture seule)</button></div>
      <div id="pontTables"></div>
    </div>
    <div id="repEtapes"></div>
    <div id="repHistorique"></div>`;
  if (reprise) afficherCorrespondances();
  chargerHistoriqueImports();
  chargerTypesPont();
}

// ---------- Le pont : base d'un ancien logiciel ----------
let pontTypes = [];
let pontFichier = null;

async function chargerTypesPont() {
  try { pontTypes = (await api("/api/pont/types")).types; } catch { return; }
  el("pontType").innerHTML = pontTypes.map(t => `<option value="${t.type}"${t.disponible ? "" : " disabled"}>${esc(t.libelle)}${t.disponible ? "" : " (pilote absent sur ce PC)"}</option>`).join("");
  majPont();
}

function majPont() {
  const type = pontTypes.find(t => t.type === el("pontType").value);
  el("pontChampFichier").style.display = type && type.fichier ? "" : "none";
  document.querySelectorAll(".pont-serveur").forEach(c => { c.style.display = type && !type.fichier ? "" : "none"; });
  el("pontTables").innerHTML = "";
}

function sourcePont() {
  const type = el("pontType").value;
  const port = el("pontPort").value.trim();
  return { type, fichier: pontFichier, hote: el("pontHote").value.trim() || null, port: port ? Number(port) : null,
           base: el("pontBase").value.trim() || null, utilisateur: el("pontUtilisateur").value.trim() || null,
           mot_de_passe: el("pontMdp").value || null, accord: el("pontAccord").checked };
}

async function envoyerBasePont(champ) {
  const fichier = champ.files[0];
  champ.value = "";
  if (!fichier) return;
  toast(`Envoi de « ${fichier.name} »…`, 60000);
  let rep;
  try { rep = await fetch(`/api/pont/fichier?nom=${encodeURIComponent(fichier.name)}`, { method: "POST", body: fichier }); }
  catch { toast("Le serveur ne répond pas."); return; }
  const d = await rep.json().catch(() => ({}));
  if (!rep.ok) { toast(typeof d.detail === "string" ? d.detail : "Erreur du serveur.", 8000); return; }
  pontFichier = d.fichier;
  el("pontType").value = d.type;
  majPont();
  el("pontNomFichier").textContent = fichier.name;
  toast("Fichier reçu : cochez l'accord du client, puis « Se connecter ».");
}

async function explorerPont() {
  toast("Connexion à l'ancienne base (lecture seule)…", 30000);
  let rep;
  try { rep = await api("/api/pont/explorer", { method: "POST", body: sourcePont() }); }
  catch (e) { toast(e.message, 9000); return; }
  toast(`${rep.tables.length} table(s) trouvée(s).`);
  el("pontTables").innerHTML = `<h3 style="margin-top:1rem">Tables à reprendre</h3>
    <p class="petit">Cochez les tables utiles (celles reconnues sont déjà cochées). En rouge : colonnes confidentielles, jamais lues.</p>
    <div style="overflow-x:auto"><table class="tableau"><tr><th></th><th>Table</th><th>Reconnue comme</th><th>Colonnes lues</th><th>Exclues</th></tr>
    ${rep.tables.map(t => `<tr><td><input type="checkbox" class="pont-table" value="${esc(t.table)}"${t.type ? " checked" : ""}></td>
      <td><b>${esc(t.table)}</b></td><td>${t.type ? esc(champsReprise.find(x => x.type === t.type).libelle) : "—"}</td>
      <td class="petit">${esc(t.colonnes.join(", "))}</td>
      <td class="petit">${t.confidentielles.map(c => `<span class="pill danger">${esc(c)}</span>`).join(" ")} ${t.remarques.map(c => `<span class="pill">${esc(c)}</span>`).join(" ")}</td></tr>`).join("")}
    </table></div>
    <label class="petit" style="display:flex;gap:.5rem;margin:.6rem 0"><input type="checkbox" id="pontRemarques"> Lire aussi les colonnes de remarques (en gris)</label>
    <div class="actions"><button class="btn primary" onclick="extrairePont()">Lire ces tables</button></div>`;
}

async function extrairePont() {
  const tables = [...document.querySelectorAll(".pont-table:checked")].map(c => c.value);
  if (!tables.length) { toast("Cochez au moins une table."); return; }
  toast("Lecture des tables…", 60000);
  let rep;
  try { rep = await api("/api/pont/extraire", { method: "POST", body: { ...sourcePont(), tables, avec_remarques: el("pontRemarques").checked } }); }
  catch (e) { toast(e.message, 9000); return; }
  el("pontMdp").value = "";
  pontFichier = null;
  el("pontNomFichier").textContent = "";
  el("pontTables").innerHTML = '<p class="petit">✅ Tables lues ; connexion fermée. Suite ci-dessous.</p>';
  reprise = rep;
  verifiee = false;
  toast("Vérifiez les correspondances : les liens (ex. locataire_id) sont remplacés par les noms.", 6000);
  afficherCorrespondances();
  el("repEtapes").scrollIntoView({ behavior: "smooth", block: "start" });
}

async function telechargerModeleReprise() {
  try {
    const f = await apiFichier("/api/import/modele");
    telechargerBlob(f.blob, f.nom);
    toast("Modèle téléchargé : remplissez les feuilles dans l'ordre, puis envoyez-le ici.", 6000);
  } catch (e) { toast(e.message); }
}

async function envoyerReprise(champ) {
  const fichier = champ.files[0];
  champ.value = "";
  if (!fichier) return;
  if (reprise) api(`/api/import/${reprise.jeton}`, { method: "DELETE" }).catch(() => {});
  toast(`Lecture de « ${fichier.name} »…`, 30000);
  let rep;
  try {
    rep = await fetch(`/api/import/analyser?nom=${encodeURIComponent(fichier.name)}`,
                      { method: "POST", body: fichier, headers: { "Content-Type": "application/octet-stream" } });
  } catch { toast("Le serveur ne répond pas. Vérifiez qu'il est bien démarré."); return; }
  const d = await rep.json().catch(() => ({}));
  if (!rep.ok) { toast(typeof d.detail === "string" ? d.detail : "Erreur du serveur.", 9000); return; }
  reprise = d;
  verifiee = false;
  toast(`${d.feuilles.length} feuille${d.feuilles.length > 1 ? "s" : ""} trouvée${d.feuilles.length > 1 ? "s" : ""} : vérifiez les correspondances.`, 5000);
  afficherCorrespondances();
}

function optionsColonnes(feuille, choisie) {
  return '<option value="">— aucune —</option>' +
    feuille.colonnes.map(c => `<option${c === choisie ? " selected" : ""}>${esc(c)}</option>`).join("");
}

function tableauChamps(i) {
  const f = reprise.feuilles[i];
  const type = champsReprise.find(t => t.type === f.type);
  if (!type) return '<p class="petit">Cette feuille ne sera pas importée.</p>';
  return `<div style="overflow-x:auto"><table class="tableau">
    <tr><th>Champ dans Gérimo</th><th>Colonne de votre fichier</th><th>Aide</th></tr>
    ${type.champs.map(c => `<tr><td>${esc(c.libelle)}${c.obligatoire ? ' <span class="pill warn">obligatoire</span>' : ""}</td>
      <td><select class="search" data-feuille="${i}" data-champ="${c.cle}" onchange="majCorrespondance(this)">${optionsColonnes(f, f.correspondances[c.cle])}</select></td>
      <td class="petit">${esc(c.aide || "")}</td></tr>`).join("")}
  </table></div>`;
}

function afficherCorrespondances() {
  el("repEtapes").innerHTML = `
    <div class="card"><h3>Fichier « ${esc(reprise.fichier)} » : feuilles et colonnes</h3>
      <p class="petit" style="margin-top:-.4rem">Gérimo a deviné à quoi correspond chaque feuille et chaque colonne. Corrigez si besoin, puis cliquez sur « Vérifier » (rien n'est encore enregistré).</p></div>
    ${reprise.feuilles.map((f, i) => `
      <div class="card">
        <div class="row"><span class="who"><b>Feuille « ${esc(f.feuille)} »</b> — ${f.nb_lignes} ligne${f.nb_lignes > 1 ? "s" : ""}${f.trop ? " (limitée à 20 000)" : ""}</span>
          <span class="boutons"><select class="search" onchange="majTypeFeuille(${i}, this.value)">
            <option value="">Ne pas importer</option>
            ${champsReprise.map(t => `<option value="${t.type}"${t.type === f.type ? " selected" : ""}>${esc(t.libelle)}</option>`).join("")}
          </select></span></div>
        <div id="repChamps${i}">${tableauChamps(i)}</div>
        ${f.apercu.length ? `<details><summary class="petit">Aperçu des premières lignes</summary><div style="overflow-x:auto"><table class="tableau">
          <tr>${f.colonnes.map(c => `<th>${esc(c)}</th>`).join("")}</tr>
          ${f.apercu.map(l => `<tr>${f.colonnes.map((_, j) => `<td>${esc(l[j] ?? "")}</td>`).join("")}</tr>`).join("")}
        </table></div></details>` : ""}
      </div>`).join("")}
    <div class="card"><div class="actions">
      <button class="btn" onclick="abandonnerReprise()">Abandonner</button>
      <button class="btn primary" onclick="verifierReprise()">Vérifier</button>
    </div></div>
    <div id="repResultat"></div>`;
}

function majTypeFeuille(i, type) {
  const f = reprise.feuilles[i];
  f.type = type || null;
  f.correspondances = type ? { ...(f.auto[type] || {}) } : {};
  el(`repChamps${i}`).innerHTML = tableauChamps(i);
  invaliderVerification();
}

function majCorrespondance(select) {
  const f = reprise.feuilles[Number(select.dataset.feuille)];
  if (select.value) f.correspondances[select.dataset.champ] = select.value;
  else delete f.correspondances[select.dataset.champ];
  invaliderVerification();
}

function invaliderVerification() {
  verifiee = false;
  if (el("repResultat")) el("repResultat").innerHTML = "";
}

function choixReprise() {
  return { feuilles: reprise.feuilles.filter(f => f.type).map(f => ({ feuille: f.feuille, type: f.type, colonnes: f.correspondances })) };
}

function resumeReprise(rep, fait) {
  const lignes = Object.keys(rep.libelles).filter(t => rep.crees[t] || rep.reutilises[t]).map(t =>
    `<tr><td>${esc(rep.libelles[t])}</td><td class="nombre"><b>${rep.crees[t]}</b></td><td class="nombre">${rep.reutilises[t]}</td></tr>`).join("");
  const tableau = (liste, titre, classe) => liste.length ? `<h3 style="margin-top:1rem">${titre} (${liste.length}${liste.length >= 500 ? "+" : ""})</h3>
    <div style="overflow-x:auto;max-height:420px"><table class="tableau"><tr><th>Feuille</th><th>Ligne</th><th>${classe === "danger" ? "Problème" : "Remarque"}</th></tr>
    ${liste.map(e => `<tr><td>${esc(e.feuille)}</td><td class="nombre">${e.ligne}</td><td>${esc(e.message)}</td></tr>`).join("")}</table></div>` : "";
  return `${lignes ? `<div style="overflow-x:auto"><table class="tableau"><tr><th></th><th class="nombre">${fait ? "Créés" : "À créer"}</th><th class="nombre">Déjà présents (gardés)</th></tr>${lignes}</table></div>` : '<p class="petit">Rien à importer.</p>'}
    ${tableau(rep.erreurs, "Lignes à corriger", "danger")}${tableau(rep.avertissements, "Remarques", "warn")}`;
}

async function verifierReprise() {
  toast("Vérification de chaque ligne…", 60000);
  let rep;
  try { rep = await api(`/api/import/${reprise.jeton}/verifier`, { method: "POST", body: choixReprise() }); }
  catch (e) { toast(e.message, 8000); return; }
  verifiee = !rep.erreurs.length;
  toast(rep.erreurs.length ? `${rep.erreurs.length} ligne(s) à corriger.` : "Tout est correct : vous pouvez importer.", 5000);
  el("repResultat").innerHTML = `<div class="card">
    <h3>${rep.erreurs.length ? "⚠️ Vérification : des lignes sont à corriger" : "✅ Vérification réussie"}</h3>
    ${rep.erreurs.length ? '<p class="petit">Corrigez ces lignes dans votre fichier (ou les correspondances ci-dessus), puis renvoyez le fichier. Rien n\'a été enregistré.</p>' : ""}
    ${resumeReprise(rep, false)}
    ${verifiee ? '<div class="actions"><button class="btn primary" onclick="lancerReprise()">Importer maintenant</button></div>' : ""}
  </div>`;
  el("repResultat").scrollIntoView({ behavior: "smooth", block: "start" });
}

async function lancerReprise() {
  if (!verifiee) return;
  if (!confirm("Importer ces données dans Gérimo ?\n\nUne sauvegarde est faite juste avant, et l'import pourra être annulé ensuite.")) return;
  toast("Sauvegarde puis import en cours… (ne fermez pas cette page)", 120000);
  let rep;
  try { rep = await api(`/api/import/${reprise.jeton}/importer`, { method: "POST", body: choixReprise() }); }
  catch (e) { toast(e.message, 8000); return; }
  if (!rep.ok) { toast("Des lignes sont à corriger : rien n'a été importé.", 8000); verifiee = false; return; }
  reprise = null;
  toast("Import terminé ✅", 6000);
  el("repEtapes").innerHTML = `<div class="card"><h3>✅ Import terminé</h3>${resumeReprise(rep, true)}
    <p class="petit">Les paiements passés sont marqués « repris » : ils règlent les mois concernés, sans nouveau reçu. Les impayés sont déjà calculés.</p></div>`;
  chargerHistoriqueImports();
}

async function abandonnerReprise() {
  if (reprise) await api(`/api/import/${reprise.jeton}`, { method: "DELETE" }).catch(() => {});
  reprise = null;
  el("repEtapes").innerHTML = "";
  toast("Abandonné : le fichier a été effacé du serveur.");
}

async function chargerHistoriqueImports() {
  let rep;
  try { rep = await api("/api/imports"); } catch { return; }
  if (!rep.imports.length) { el("repHistorique").innerHTML = ""; return; }
  el("repHistorique").innerHTML = `<div class="card"><h3>Imports précédents</h3>${rep.imports.map(i => {
    const detail = Object.entries(i.crees).filter(([, n]) => n).map(([t, n]) => `${n} ${rep.libelles[t].toLowerCase()}`).join(", ") || "rien de nouveau";
    return `<div class="row"><span class="who"><b>${esc(i.source)}</b> — le ${esc(i.quand)} par ${esc(i.qui || "?")}
      <br><span class="petit">${esc(detail)}${i.annule ? ` — annulé le ${esc(i.annule)} par ${esc(i.annule_qui || "?")}` : ""}</span></span>
      <span class="boutons">${i.annule ? '<span class="pill">Annulé</span>' : `<button class="btn-sm" onclick="annulerImport(${i.id})">Annuler cet import</button>`}</span></div>`;
  }).join("")}</div>`;
}

async function annulerImport(id) {
  const mdp = await demanderMotDePasseAdmin("Annuler cet import : tout ce qu'il a créé sera retiré. Confirmez avec votre mot de passe.",
                                         { titre: "Annuler l'import", bouton: "Annuler l'import" });
  if (!mdp) { toast("Annulation abandonnée"); return; }
  try {
    const rep = await api(`/api/imports/${id}/annuler`, { method: "POST", body: { mot_de_passe_admin: mdp } });
    toast(`Import annulé : ${rep.retires} élément(s) retiré(s).`, 6000);
  } catch (e) { toast(e.message, 9000); }
  chargerHistoriqueImports();
}
