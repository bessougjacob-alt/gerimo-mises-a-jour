// Étape 7 : achats et ventes de biens (Admin uniquement).
// Vente → Facture et Reçu ; Achat → Décharge. Pas de modification après coup :
// en cas d'erreur, supprimer l'opération (mot de passe Admin) et la ressaisir.

let operationsCache = [];
let optionsAV = null;

const HORS_GESTION = "hors:";

async function chargerOperations() {
  const zone = el("listeAV");
  try {
    operationsCache = await api("/api/achats-ventes");
  } catch (e) {
    zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`;
    return;
  }
  if (!operationsCache.length) {
    zone.innerHTML = '<div class="card vide">Aucune opération enregistrée. Cliquez sur « + Nouvelle opération ».</div>';
    return;
  }
  const somme = (filtre, champ = "montant") => operationsCache.filter(filtre).reduce((s, o) => s + o[champ], 0);
  const estVente = o => o.type_operation !== "Achat";
  zone.innerHTML = `<div class="kpis">
      <div class="kpi ok"><div class="label">Total des ventes</div><div class="value">${formatMontant(somme(estVente))}</div></div>
      <div class="kpi info"><div class="label">Commissions d'intermédiation</div><div class="value">${formatMontant(somme(o => o.type_operation === "Vente indirecte", "commission_montant"))}</div></div>
      <div class="kpi warn"><div class="label">Total des achats</div><div class="value">${formatMontant(somme(o => o.type_operation === "Achat"))}</div></div>
    </div>
    <div class="card"><h3>Opérations</h3>${operationsCache.map(o => {
      const indirecte = o.type_operation === "Vente indirecte";
      const details = [esc(o.designation || ""), formatDate(o.date_operation), esc(o.mode_paiement)];
      if (o.partie_telephone) details.push("Tél. " + esc(o.partie_telephone));
      if (indirecte) {
        details.push(`Pour le compte de ${esc(o.proprietaire_nom)}`);
        if (o.commission_montant) details.push(`Commission ${formatMontant(o.commission_montant)} (payée par ${esc((o.commission_payee_par || "").toLowerCase())})`);
        details.push(`Net propriétaire ${formatMontant(o.net_proprietaire)}`);
      }
      return `
    <div class="row"${motsCles({ tel: [o.partie_telephone, o.proprietaire_telephone], textes: [o.adresse, o.partie_cni, o.bien, o.proprietaire_nom] })}>
      <span class="who">N° ${esc(o.numero)} — <b>${esc(o.partie_nom)}</b> — ${formatMontant(o.montant)}
        <br><span class="petit">${details.join(" — ")}</span></span>
      <span class="boutons">
        <span class="pill ${o.type_operation === "Achat" ? "warn" : indirecte ? "info" : "ok"}">${esc(o.type_operation)}</span>
        ${o.documents.map(d => ibtn(d.type === "Reçu de paiement" ? "recu" : "pdf", `${d.type} (PDF)`, `ouvrirDocumentAV(${o.id}, '${d.code}')`)).join("")}
        ${ibtn("supprimer", "Supprimer cette opération (Admin)", `supprimerOperation(${o.id})`)}
      </span>
    </div>`;
    }).join("")}</div>`;
  el("rechercheAV").dispatchEvent(new Event("input"));
}
CHARGEURS.achats_ventes = chargerOperations;

function ouvrirDocumentAV(id, code) {
  window.open(`/api/achats-ventes/${id}/document/${code}`, "_blank");
}

// ---------- Formulaire ----------

function choixBien() {
  const v = el("avBien").value;
  if (v === HORS_GESTION) return { origine: "hors_gestion" };
  const [genre, id] = v.split(":");
  if (genre === "bien") return { origine: "bien", cite_id: Number(id) };
  if (genre === "parcelle") return { origine: "parcelle", parcelle_id: Number(id) };
  return null;
}

// Le libellé, les champs « vente indirecte » et les documents prévus suivent le type d'opération
function majTypeOperation() {
  const type = el("avType").value;
  const indirecte = type === "Vente indirecte";
  el("avPartieLibelle").textContent = type === "Achat" ? "Vendeur" : "Acheteur";
  el("sectionIndirecte").style.display = indirecte ? "" : "none";
  majRecapAV();
}
el("avType").addEventListener("change", majTypeOperation);

// Commission : le % calcule le montant, et inversement
function prixSaisi() { return lireMontant(el("avMontant").value) || 0; }
el("avCommissionPct").addEventListener("input", () => {
  const pct = Number(el("avCommissionPct").value.replace("%", "").replace(",", "."));
  if (Number.isFinite(pct) && prixSaisi()) el("avCommission").value = formatNombre(Math.round(prixSaisi() * pct / 100));
  majRecapAV();
});
el("avCommission").addEventListener("input", () => {
  const c = lireMontant(el("avCommission").value);
  if (c !== null && prixSaisi()) el("avCommissionPct").value = formatNombre(Math.round(c / prixSaisi() * 10000) / 100);
  majRecapAV();
});
["avMontant", "avPayeur"].forEach(id => el(id).addEventListener("input", majRecapAV));
el("avPayeur").addEventListener("change", majRecapAV);

// Récapitulatif : documents prévus et, en vente indirecte, ce qui revient au propriétaire
function majRecapAV() {
  const type = el("avType").value;
  if (type === "Achat") {
    el("avDocuments").innerHTML = `Document : <b>Décharge</b> signée par le vendeur, qui reconnaît avoir reçu la somme ${deEntreprise()}.`;
    return;
  }
  if (type === "Vente directe") {
    el("avDocuments").innerHTML = nomEntreprise() + " représente légalement le propriétaire. Documents remis à l'acheteur : " +
      "<b>Facture</b> et <b>Reçu de paiement</b>.";
    return;
  }
  const prix = prixSaisi();
  const commission = lireMontant(el("avCommission").value) || 0;
  const vendeurPaie = el("avPayeur").value === "Vendeur";
  const net = vendeurPaie ? prix - commission : prix;
  el("avDocuments").innerHTML = `${nomEntreprise()} est intermédiaire : le prix lui est versé, puis reversé au propriétaire.<br>
    Prix de vente : <b>${formatMontant(prix)}</b> — Commission : <b>${formatMontant(commission)}</b>
    ${commission ? `(payée par ${vendeurPaie ? "le vendeur" : "l'acheteur"})` : ""}<br>
    Net reversé au propriétaire : <b>${formatMontant(net)}</b>${commission > prix ? " — <b>la commission dépasse le prix !</b>" : ""}<br>
    Documents : <b>Reçu</b> (acheteur)${commission ? ", <b>Facture d'honoraires</b>" : ""} et <b>Décharge</b> (signée par le propriétaire).`;
}

// Désignation proposée selon le bien choisi (modifiable) ; prix de la parcelle proposé
el("avBien").addEventListener("change", () => {
  const v = el("avBien").value;
  const [genre, id] = v.split(":");
  const source = genre === "bien" ? optionsAV.biens : genre === "parcelle" ? optionsAV.parcelles : [];
  const choisi = source.find(x => String(x.id) === id);
  el("avDesignation").value = choisi ? choisi.designation : "";
  if (genre === "parcelle" && choisi?.dernier_prix && !el("avMontant").value) {
    el("avMontant").value = formatNombre(choisi.dernier_prix);
  }
  el("avDesignation").placeholder = v === HORS_GESTION ? "Décrivez le bien : ex. Terrain de 600 m² à Niablé, lot 14" : "";
  if (v === HORS_GESTION) el("avDesignation").focus();
});

async function nouvelleOperation() {
  optionsAV = await api("/api/achats-ventes/options");
  const o = optionsAV;
  remplirSelect(el("avType"), o.types_operation);
  el("avType").value = "Vente directe";
  remplirSelect(el("avPayeur"), o.payeurs);
  el("avPayeur").value = "Vendeur";
  ["avProprioNom", "avProprioTel", "avProprioCni", "avCommissionPct", "avCommission"].forEach(id => { el(id).value = ""; });
  const biens = o.biens.map(b => `<option value="bien:${b.id}">${esc(b.nom)}</option>`).join("");
  const parcelles = o.parcelles.map(p =>
    `<option value="parcelle:${p.id}">${esc(p.libelle)}${p.disponible ? "" : " (non disponible)"}</option>`).join("");
  el("avBien").innerHTML = '<option value="">— Choisir —</option>' +
    (biens ? `<optgroup label="Biens">${biens}</optgroup>` : "") +
    (parcelles ? `<optgroup label="Parcelles">${parcelles}</optgroup>` : "") +
    `<option value="${HORS_GESTION}">+ Bien hors gestion…</option>`;
  remplirSelect(el("avMode"), o.modes_paiement);
  await preparerChoixCompte("avMode", "avCompte");
  ["avDesignation", "avPartie", "avTel", "avCni", "avMontant", "avObservation"].forEach(id => { el(id).value = ""; });
  fixerDate("avDate", aujourdhui());
  majTypeOperation();
  erreurFormulaire(el("formulaireAV"), "");
  afficher("formAchatVente");
}

el("avMontant").addEventListener("blur", () => {
  const n = lireMontant(el("avMontant").value);
  if (n !== null) el("avMontant").value = formatNombre(n);
});

el("formulaireAV").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    const bien = choixBien();
    if (!bien) throw new Error("Choisissez le bien concerné (ou « + Bien hors gestion… »).");
    if (bien.origine === "hors_gestion" && !el("avDesignation").value.trim()) {
      throw new Error("Décrivez le bien hors gestion dans « Désignation du bien ».");
    }
    if (!el("avPartie").value.trim()) throw new Error(`Indiquez le nom de l'${el("avPartieLibelle").textContent.toLowerCase()}.`);
    const somme = lireMontant(el("avMontant").value);
    if (somme === null || somme <= 0) throw new Error("Indiquez un montant valide (ex : 15 000 000).");
    const dateOperation = valeurDate("avDate", "Date");
    if (!dateOperation) throw new Error("Indiquez la date (jj/mm/aaaa).");
    if (dateOperation > aujourdhui()) throw new Error("La date de l'opération ne peut pas être dans le futur.");
    const corps = {
      type_operation: el("avType").value, ...bien,
      designation: el("avDesignation").value || null,
      partie_nom: el("avPartie").value, partie_telephone: el("avTel").value, partie_cni: el("avCni").value,
      montant: somme, mode_paiement: el("avMode").value, date_operation: dateOperation,
      observation: el("avObservation").value,
      compte_id: compteChoisi("avCompte"),
    };
    if (corps.type_operation === "Vente indirecte") {
      if (!el("avProprioNom").value.trim()) throw new Error("Vente indirecte : indiquez le nom du propriétaire du bien.");
      const commission = el("avCommission").value.trim() ? lireMontant(el("avCommission").value) : 0;
      if (commission === null) throw new Error("Vérifiez le montant de la commission (ex : 175 000).");
      if (commission > somme) throw new Error("La commission ne peut pas dépasser le prix de vente.");
      Object.assign(corps, {
        proprietaire_nom: el("avProprioNom").value, proprietaire_telephone: el("avProprioTel").value,
        proprietaire_cni: el("avProprioCni").value, commission_montant: commission,
        commission_payee_par: commission ? el("avPayeur").value : null,
      });
    }
    const rep = await api("/api/achats-ventes", { method: "POST", body: corps });
    toast(`Opération N° ${rep.numero} enregistrée : documents disponibles dans la liste`);
    goBack();
  });
});

function supprimerOperation(id) {
  const o = operationsCache.find(x => x.id === id);
  supprimerAvecConfirmation(
    `Supprimer l'opération N° ${o ? o.numero : ""} (${o ? o.type_operation.toLowerCase() + ", " + formatMontant(o.montant) : ""}) ? ` +
    "Une parcelle vendue redeviendra disponible. Entrez votre mot de passe Admin pour confirmer.",
    `/api/achats-ventes/${id}/supprimer`, chargerOperations);
}

brancherRecherche(el("rechercheAV"), el("listeAV"));
