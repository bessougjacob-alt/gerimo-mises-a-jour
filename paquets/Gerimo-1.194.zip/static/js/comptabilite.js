// Précomptabilité, parties 3 et 4 : résultat, TVA, clôture des mois, export SYSCOHADA (Rapports & statistiques)
// et rapprochement bancaire (Trésorerie). Le serveur calcule et revérifie tout.

let resultatCache = null;

// ---------- Période ----------

function appliquerPeriodeResultat() {
  const choix = el("resPeriode").value;
  const a = new Date();
  let debut, fin;
  if (choix === "mois") { debut = new Date(a.getFullYear(), a.getMonth(), 1); fin = a; }
  else if (choix === "mois_dernier") { debut = new Date(a.getFullYear(), a.getMonth() - 1, 1); fin = new Date(a.getFullYear(), a.getMonth(), 0); }
  else if (choix === "annee") { debut = new Date(a.getFullYear(), 0, 1); fin = a; }
  else if (choix === "annee_derniere") { debut = new Date(a.getFullYear() - 1, 0, 1); fin = new Date(a.getFullYear() - 1, 11, 31); }
  else return;
  fixerDate("resDebut", isoDe(debut));
  fixerDate("resFin", isoDe(fin));
}
el("resPeriode").addEventListener("change", () => {
  appliquerPeriodeResultat();
  if (el("resPeriode").value !== "libre") chargerResultat();
});
function periodeResultat() {
  const debut = valeurDate("resDebut", "Du"), fin = valeurDate("resFin", "Au");
  if (!debut || !fin) throw new Error("Indiquez la période (jj/mm/aaaa).");
  if (fin < debut) throw new Error("La date de fin doit être après la date de début.");
  return `debut=${debut}&fin=${fin}`;
}

// ---------- Résultat et TVA ----------

const ligneMontant = (libelle, valeur, gras = false) =>
  `<div class="row"><span class="who">${gras ? `<b>${libelle}</b>` : libelle}</span><b${valeur < 0 ? ' style="color:var(--danger)"' : ""}>${formatMontant(valeur)}</b></div>`;

async function chargerResultat() {
  const form = el("formulaireResultat");
  if (!el("resDebut").value) appliquerPeriodeResultat();
  let filtres;
  try { filtres = periodeResultat(); } catch (e) { erreurFormulaire(form, e.message); return; }
  erreurFormulaire(form, "");
  const zone = el("contenuResultat");
  let r;
  try { r = resultatCache = await api(`/api/comptabilite/resultat?${filtres}`); }
  catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  const ht = r.tva.assujetti ? " (hors TVA)" : "";
  zone.innerHTML = `
    <div class="kpis">
      <div class="kpi ok"><div class="label">Produits${ht}</div><div class="value">${formatMontant(r.total_produits)}</div></div>
      <div class="kpi warn"><div class="label">Charges de l'entreprise${ht}</div><div class="value">${formatMontant(r.total_charges)}</div></div>
      <div class="kpi ${r.resultat >= 0 ? "info" : "risk"}"><div class="label">Résultat (${r.resultat >= 0 ? "bénéfice" : "perte"})</div><div class="value">${formatMontant(r.resultat)}</div></div>
      ${r.tva.assujetti ? `<div class="kpi"><div class="label">${r.tva.a_payer >= 0 ? "TVA à reverser à l'État" : "Crédit de TVA (à reporter)"}</div><div class="value">${formatMontant(Math.abs(r.tva.a_payer))}</div></div>` : ""}
    </div>
    <div class="card"><h3>Produits${ht}</h3>${r.produits.map(p => ligneMontant(esc(p.poste), p.montant)).join("") || '<div class="vide">Aucun produit sur la période.</div>'}
      ${ligneMontant("Total des produits", r.total_produits, true)}</div>
    <div class="card"><h3>Charges de l'entreprise${ht}</h3>${r.charges.map(c => ligneMontant(esc(c.poste), c.montant)).join("") || '<div class="vide">Aucune charge sur la période.</div>'}
      ${ligneMontant("Total des charges", r.total_charges, true)}
      <p class="petit">Les dépenses faites pour le compte des propriétaires ne sont pas des charges de l'entreprise : elles sont déduites de leurs reversements.</p></div>
    ${r.par_mois.length ? `<div class="card"><h3>Mois par mois</h3><div style="overflow-x:auto"><table class="tableau">
      <tr><th>Mois</th><th style="text-align:right">Produits</th><th style="text-align:right">Charges</th><th style="text-align:right">Résultat</th></tr>
      ${r.par_mois.map(m => `<tr><td>${formatDate(m.debut).slice(3)}</td><td style="text-align:right">${formatMontant(m.total_produits)}</td>
        <td style="text-align:right">${formatMontant(m.total_charges)}</td><td style="text-align:right"${m.resultat < 0 ? ' style="color:var(--danger)"' : ""}>${formatMontant(m.resultat)}</td></tr>`).join("")}
    </table></div></div>` : ""}
    <div class="card"><h3>TVA</h3>${r.tva.assujetti ? `
      ${ligneMontant(`TVA collectée sur les commissions (${String(r.tva.taux).replace(".", ",")} %)`, r.tva.collectee)}
      ${ligneMontant("TVA payée sur les dépenses (récupérable)", -r.tva.deductible)}
      ${r.tva.a_payer >= 0 ? ligneMontant("TVA à reverser à l'État", r.tva.a_payer, true)
        : ligneMontant("Crédit de TVA (à déduire de la TVA des mois suivants)", -r.tva.a_payer, true)}`
      : `<p class="petit">L'entreprise n'est pas indiquée comme assujettie à la TVA.${estAdmin() ? " Pour l'activer : Paramètres → Réglages → « TVA et clôture des comptes »." : ""}</p>`}</div>
    ${r.biens.achats || r.biens.ventes ? `<div class="card"><h3>Achats et ventes de biens (hors activité courante)</h3>
      ${ligneMontant("Achats de biens (investissements)", r.biens.achats)}${ligneMontant("Ventes de biens (cessions)", r.biens.ventes)}</div>` : ""}
    <div class="card"><h3>Trésorerie</h3>${r.tresorerie.map(t => `<div class="row"><span class="who">${esc(t.compte)}</span>
      <span class="petit">${formatMontant(t.debut)} → <b>${formatMontant(t.fin)}</b></span></div>`).join("") || '<div class="vide">Aucun compte.</div>'}</div>
    <div class="card"><h3>Clôture des comptes</h3>
      <p>${r.cloture_jusqu_au ? `Période clôturée jusqu'au <b>${formatDate(r.cloture_jusqu_au)}</b> : les opérations d'argent de cette période ne peuvent plus être ajoutées, modifiées ni supprimées.`
        : "Aucune période n'est clôturée."}</p>
      ${r.peut_cloturer ? `<div class="actions" style="justify-content:flex-start">
        <button class="btn primary" onclick="cloturerPeriode()">Clôturer jusqu'à la fin du mois dernier</button>
        ${r.cloture_jusqu_au ? '<button class="btn" onclick="rouvrirPeriode()">Rouvrir</button>' : ""}</div>
        <p class="petit">À faire une fois les chiffres du mois remis au comptable. Mot de passe Admin demandé.</p>` : ""}
    </div>`;
}
el("formulaireResultat").addEventListener("submit", e => { e.preventDefault(); chargerResultat(); });

function pdfResultat() {
  try { window.open(`/api/comptabilite/resultat/pdf?${periodeResultat()}`, "_blank"); }
  catch (e) { erreurFormulaire(el("formulaireResultat"), e.message); }
}
function exportSyscohada() {
  try {
    window.location.href = `/api/comptabilite/export-syscohada?${periodeResultat()}`;
    toast("Fichier Excel en cours de téléchargement : à remettre au comptable", 5000);
  } catch (e) { erreurFormulaire(el("formulaireResultat"), e.message); }
}

async function envoyerCloture(jusquAu, texte) {
  const mdp = await demanderMotDePasseAdmin(texte, { titre: "Clôturer la période", bouton: "Clôturer" });
  if (!mdp) { toast("Annulé"); return; }
  try {
    await api("/api/comptabilite/cloture", { method: "POST", body: { jusqu_au: jusquAu, mot_de_passe_admin: mdp } });
    toast(jusquAu ? `Période clôturée jusqu'au ${formatDate(jusquAu)}` : "Toutes les périodes sont rouvertes", 5000);
    chargerResultat();
  } catch (e) { toast(e.message, 6000); }
}
function cloturerPeriode() {
  const a = new Date();
  const fin = isoDe(new Date(a.getFullYear(), a.getMonth(), 0));
  envoyerCloture(fin, `Clôturer toutes les opérations d'argent jusqu'au ${formatDate(fin)} ? Elles ne pourront plus être modifiées (sauf réouverture). Mot de passe Admin.`);
}
function rouvrirPeriode() {
  envoyerCloture(null, "Rouvrir toutes les périodes clôturées ? Les anciennes opérations redeviendront modifiables. Mot de passe Admin.");
}

// ---------- Rapprochement bancaire (Trésorerie) ----------

async function chargerRapprochement() {
  try { await donneesTresorerie(); } catch (e) { toast(e.message); return; }
  const choix = el("rapCompte").value;
  const comptes = comptesOuverts().filter(c => c.type_compte !== "Caisse");
  remplirSelect(el("rapCompte"), comptes, { valeur: c => c.id, texte: c => c.nom, vide: comptes.length ? null : "Aucun compte bancaire ou Mobile Money" });
  if (choix) el("rapCompte").value = choix;
}

el("formulaireRapprochement").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    const fichier = el("rapFichier").files[0];
    if (!el("rapCompte").value) throw new Error("Choisissez le compte (banque ou Mobile Money).");
    if (!fichier) throw new Error("Choisissez le fichier du relevé (Excel ou CSV).");
    let rep;
    try {
      rep = await fetch(`/api/comptabilite/rapprochement?compte_id=${el("rapCompte").value}&nom=${encodeURIComponent(fichier.name)}`,
                        { method: "POST", body: fichier });
    } catch { throw new Error("Le serveur ne répond pas. Vérifiez qu'il est bien démarré."); }
    const r = await rep.json().catch(() => ({}));
    if (!rep.ok) throw new Error(typeof r.detail === "string" ? r.detail : "Relevé illisible.");
    const ligne = (l, ref = "") => `<tr><td style="white-space:nowrap">${formatDate(l.date)}</td><td>${esc(l.libelle)}${ref}</td>
      <td style="text-align:right;white-space:nowrap">${l.sens === "entree" ? formatMontant(l.montant) : ""}</td>
      <td style="text-align:right;white-space:nowrap">${l.sens === "sortie" ? formatMontant(l.montant) : ""}</td></tr>`;
    const tableau = lignes => `<div style="overflow-x:auto"><table class="tableau"><tr><th>Date</th><th>Opération</th>
      <th style="text-align:right">Entrée</th><th style="text-align:right">Sortie</th></tr>${lignes}</table></div>`;
    el("resultatRapprochement").innerHTML = `
      <div class="kpis">
        <div class="kpi ok"><div class="label">Opérations retrouvées</div><div class="value">${r.associes.length} / ${r.nb_releve}</div></div>
        <div class="kpi warn"><div class="label">Sur le relevé, pas dans Gérimo</div><div class="value">${r.releve_seul.length}</div></div>
        <div class="kpi risk"><div class="label">Dans Gérimo, pas sur le relevé</div><div class="value">${r.gerimo_seul.length}</div></div>
      </div>
      <p class="petit">Relevé ${esc(r.compte)} du ${formatDate(r.debut)} au ${formatDate(r.fin)}. Une opération est « retrouvée » quand le même montant, dans le même sens, figure des deux côtés à 5 jours près.</p>
      ${r.releve_seul.length ? `<div class="card"><h3>Sur le relevé mais pas dans Gérimo (à saisir : frais, virements reçus…)</h3>${tableau(r.releve_seul.map(l => ligne(l)).join(""))}</div>` : ""}
      ${r.gerimo_seul.length ? `<div class="card"><h3>Dans Gérimo mais pas sur le relevé (erreur de compte ou opération pas encore passée à la banque)</h3>${tableau(r.gerimo_seul.map(l => ligne(l, l.reference ? `<br><span class="petit">${esc(l.reference)}</span>` : "")).join(""))}</div>` : ""}
      ${r.associes.length ? `<details class="card"><summary>Opérations retrouvées (${r.associes.length})</summary>${tableau(r.associes.map(a => ligne(a.releve, `<br><span class="petit">Gérimo : ${esc(a.gerimo.libelle)}</span>`)).join(""))}</details>` : ""}
      ${!r.releve_seul.length && !r.gerimo_seul.length ? '<div class="card">✅ Tout concorde : le relevé et Gérimo sont identiques sur cette période.</div>' : ""}`;
  });
});
