// Précomptabilité, partie 2 : reversements aux propriétaires et aux vendeurs, carnet de RIB (Trésorerie).
// Le serveur calcule ce qui est dû et revérifie tout (montant, compte, droits).

let reversementsCache = null;
let beneficiairesCache = [];
let versementEnCours = null;
let beneficiaireEnCours = null;
// Mode de paiement proposé selon le compte choisi
const MODE_PAR_TYPE = { "Caisse": "Espèce", "Banque": "Virement", "Mobile Money": "Mobile Money" };

// ---------- Reversements ----------

async function chargerReversements() {
  const zone = el("listeReversements");
  let s, historique;
  try {
    [s, historique, beneficiairesCache] = await Promise.all([
      api("/api/reversements/a-verser"), api("/api/reversements"), api("/api/beneficiaires")]);
  } catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  reversementsCache = s;
  const aVerser = s.proprietaires.filter(p => !p.entreprise && p.reste > 0);
  const aJour = s.proprietaires.filter(p => !p.entreprise && p.reste <= 0);
  const propres = s.proprietaires.filter(p => p.entreprise);
  zone.innerHTML = `
    <div class="kpis">
      <div class="kpi warn"><div class="label">À reverser aux propriétaires</div><div class="value">${formatMontant(s.du_proprietaires)}</div></div>
      <div class="kpi info"><div class="label">À verser aux vendeurs</div><div class="value">${formatMontant(s.du_vendeurs)}</div></div>
      <div class="kpi"><div class="label">Cautions détenues (à rendre)</div><div class="value">${formatMontant(s.cautions)}</div></div>
    </div>
    <div class="card"><h3>Propriétaires à payer</h3>${aVerser.map(p => `
      <div class="row"${motsCles({ tel: [p.telephone], textes: p.biens.map(b => b.bien) })}>
        <span class="who"><b>${esc(p.nom)}</b> — reste <b>${formatMontant(p.reste)}</b>
          <br><span class="petit">Loyers nets ${formatMontant(p.loyers_nets)}${p.depenses ? ` − dépenses à sa charge ${formatMontant(p.depenses)}` : ""}
          − déjà versé ${formatMontant(p.verse)} — ${p.biens.map(b => esc(b.bien)).join(", ")}</span></span>
        <span class="boutons"><button class="btn primary" onclick="verserProprietaire(${p.id})">Verser</button></span>
      </div>`).join("") || '<div class="vide">Tous les propriétaires sont payés à jour.</div>'}</div>
    ${s.vendeurs_a_payer.length ? `<div class="card"><h3>Vendeurs à payer (ventes faites en intermédiaire)</h3>${s.vendeurs_a_payer.map(v => `
      <div class="row">
        <span class="who"><b>${esc(v.vendeur)}</b> — reste <b>${formatMontant(v.reste)}</b>
          <br><span class="petit">Vente ${esc(v.numero)} du ${formatDate(v.date)} à ${esc(v.acheteur)} — ${esc(v.designation)}
          — net vendeur ${formatMontant(v.net)}${v.verse ? `, déjà versé ${formatMontant(v.verse)}` : ""}</span></span>
        <span class="boutons"><button class="btn primary" onclick="verserVendeur(${v.id})">Verser</button></span>
      </div>`).join("")}</div>` : ""}
    ${s.cautions_detail.length ? `<div class="card"><h3>Cautions détenues (${s.cautions_detail.length})</h3>${s.cautions_detail.map(c => `
      <div class="row"${motsCles({ tel: [c.telephone], textes: [c.numero_contrat] })}>
        <span class="who"><b>${esc(c.locataire)}</b> — ${formatMontant(c.reste)}
          ${c.a_rendre ? '<span class="pill warn">Contrat terminé : à rendre</span>' : ""}
          <br><span class="petit">Contrat ${esc(c.numero_contrat)} (${esc(c.statut)}) — ${esc(c.logement)}
          ${c.retenue_edl ? ` — retenue prévue à l'état des lieux de sortie : ${formatMontant(c.retenue_edl)}` : ""}</span></span>
        <span class="boutons"><button class="btn${c.a_rendre ? " primary" : ""}" onclick="rendreCaution(${c.contrat_id})">Rendre</button></span>
      </div>`).join("")}</div>` : ""}
    ${aJour.length || propres.length ? `<details class="card"><summary>Propriétaires à jour et biens de l'entreprise (${aJour.length + propres.length})</summary>
      ${[...aJour, ...propres].map(p => `<div class="row"><span class="who">${esc(p.nom)}${p.entreprise ? ' <span class="pill info">Bien de l\'entreprise : rien à reverser</span>' : ""}</span>
        <span class="petit">Versé ${formatMontant(p.verse)} sur ${formatMontant(p.du)}</span></div>`).join("")}</details>` : ""}
    <div class="card"><h3>Versements faits</h3>${historique.map(r => `
      <div class="row">
        <span class="who"><b>${esc(r.beneficiaire)}</b> — ${formatMontant(r.montant)}
          <br><span class="petit">${esc(r.numero)} — ${r.type === "Loyers" ? "Loyers" : r.type === "Caution" ? `Caution du contrat ${esc(r.contrat || "")}${r.retenue ? ` (retenue ${formatMontant(r.retenue)})` : ""}` : "Vente " + esc(r.vente || "")} — ${esc(r.mode_paiement)} depuis ${esc(r.compte)}
          ${r.reference ? " — Réf. " + esc(r.reference) : ""} — reste après : ${formatMontant(r.reste_apres)}${r.saisi_par ? " — Saisie : " + esc(r.saisi_par) : ""}</span></span>
        <span class="boutons"><span class="pill info">${formatDate(r.date)}</span>
          ${ibtn("pdf", "Bordereau à faire signer (PDF)", `window.open('/api/reversements/${r.id}/bordereau', '_blank')`)}
          ${r.mode_paiement === "Virement" ? ibtn("imprimer", r.rib ? "Ordre de virement pour la banque (PDF)" : "Ordre de virement : aucun RIB choisi",
            `ouvrirOrdreVirement(${r.id})`, { desactive: r.rib ? null : "Ordre de virement : aucun RIB n'a été choisi pour ce versement" }) : ""}
          ${estAdmin() ? ibtn("supprimer", "Supprimer ce versement", `supprimerReversement(${r.id}, '${esc(r.numero)}')`) : ""}</span>
      </div>`).join("") || '<div class="vide">Aucun versement pour le moment.</div>'}</div>`;
}

// L'ordre de virement exige le RIB de l'entreprise : le serveur explique ce qui manque
async function ouvrirOrdreVirement(id) {
  const rep = await fetch(`/api/reversements/${id}/ordre-virement`);
  if (!rep.ok) { toast((await rep.json().catch(() => ({}))).detail || "Ordre de virement impossible.", 7000); return; }
  window.open(URL.createObjectURL(await rep.blob()), "_blank");
}

async function ouvrirVersement(cible) {
  try { await donneesTresorerie(); } catch (e) { toast(e.message); return; }
  const ouverts = comptesOuverts();
  if (!ouverts.length) { toast("Aucun compte ouvert : l'Admin doit en créer un (onglet « Comptes »)."); return; }
  versementEnCours = cible;
  el("vrsTitre").textContent = { Loyers: `Reverser à ${cible.nom}`, Vente: `Verser au vendeur ${cible.nom}`,
                                  Caution: `Rendre la caution de ${cible.nom}` }[cible.type];
  el("vrsRecap").innerHTML = `Reste à verser : <b>${formatMontant(cible.reste)}</b>${cible.detail ? `<br>${cible.detail}` : ""}`;
  el("vrsMontant").value = formatNombre(cible.reste - (cible.retenue || 0));
  const caution = cible.type === "Caution";
  document.querySelectorAll("#formReversement .champ-caution").forEach(c => { c.style.display = caution ? "" : "none"; });
  el("vrsRetenue").value = caution && cible.retenue ? formatNombre(cible.retenue) : "";
  el("vrsMotifRetenue").value = caution && cible.retenue ? "Réparations constatées à l'état des lieux de sortie" : "";
  fixerDate("vrsDate", aujourdhui());
  remplirSelect(el("vrsCompte"), ouverts, { valeur: c => c.id, texte: c => `${c.nom} (solde ${formatMontant(c.solde)})` });
  remplirSelect(el("vrsMode"), tresorerieCache.modes_paiement);
  // RIB du carnet : d'abord ceux du propriétaire, puis les autres
  const ribs = beneficiairesCache.filter(b => b.actif && b.virement_possible)
    .sort((a, b) => (b.proprietaire_id === cible.proprietaire_id) - (a.proprietaire_id === cible.proprietaire_id));
  remplirSelect(el("vrsRib"), ribs, { valeur: b => b.id, texte: b => `${b.nom} — ${b.banque_nom || "banque ?"} — ${b.iban_lisible || b.rib}`,
                                     vide: ribs.length ? "— Choisir le RIB —" : "Aucun RIB dans le carnet (onglet « Carnet de RIB »)" });
  const sien = ribs.find(b => cible.proprietaire_id && b.proprietaire_id === cible.proprietaire_id);
  el("vrsRib").value = sien ? sien.id : "";
  ["vrsReference", "vrsObservation"].forEach(id => { el(id).value = ""; });
  majModeVersement();
  reinitialiserSaisie(el("formReversement"));
  erreurFormulaire(el("formReversement"), "");
  ouvrirModal("modalReversement");
}
function majModeVersement() {
  const c = comptesOuverts().find(x => String(x.id) === el("vrsCompte").value);
  if (c) el("vrsMode").value = MODE_PAR_TYPE[c.type_compte] || "Espèce";
  el("champVrsRib").style.display = el("vrsMode").value === "Virement" ? "" : "none";
}
el("vrsCompte").addEventListener("change", majModeVersement);
el("vrsMode").addEventListener("change", () => { el("champVrsRib").style.display = el("vrsMode").value === "Virement" ? "" : "none"; });
el("vrsMontant").addEventListener("blur", () => {
  const n = lireMontant(el("vrsMontant").value);
  if (n !== null) el("vrsMontant").value = formatNombre(n);
});

function verserProprietaire(id) {
  const p = reversementsCache.proprietaires.find(x => x.id === id);
  if (p) ouvrirVersement({ type: "Loyers", id, proprietaire_id: id, nom: p.nom, reste: p.reste,
                           detail: `Biens : ${p.biens.map(b => esc(b.bien)).join(", ")}` });
}
function rendreCaution(contratId) {
  const c = reversementsCache.cautions_detail.find(x => x.contrat_id === contratId);
  if (c) ouvrirVersement({ type: "Caution", id: contratId, nom: c.locataire, reste: c.reste, retenue: c.retenue_edl,
                           detail: `Caution détenue — contrat ${esc(c.numero_contrat)}, ${esc(c.logement)}. Une retenue éventuelle revient au propriétaire.` });
}
el("vrsRetenue").addEventListener("blur", () => {
  const n = lireMontant(el("vrsRetenue").value);
  if (n !== null) el("vrsRetenue").value = formatNombre(n);
});
function verserVendeur(id) {
  const v = reversementsCache.vendeurs_a_payer.find(x => x.id === id);
  if (v) ouvrirVersement({ type: "Vente", id, nom: v.vendeur, reste: v.reste,
                           detail: `Vente ${esc(v.numero)} à ${esc(v.acheteur)} — ${esc(v.designation)}` });
}

el("formReversement").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    const caution = versementEnCours.type === "Caution";
    const somme = lireMontant(el("vrsMontant").value || "0");
    const retenue = caution ? lireMontant(el("vrsRetenue").value || "0") : 0;
    if (somme === null || retenue === null) throw new Error("Vérifiez les montants (ex : 50 000).");
    if (somme + retenue <= 0) throw new Error("Indiquez un montant valide.");
    if (somme + retenue > versementEnCours.reste) throw new Error(`Le montant dépasse ${caution ? "la caution détenue" : "le reste à verser"} (${formatMontant(versementEnCours.reste)}).`);
    if (retenue && !el("vrsMotifRetenue").value.trim()) throw new Error("Indiquez le motif de la retenue.");
    const jour = valeurDate("vrsDate", "Date");
    if (!jour) throw new Error("Indiquez la date (jj/mm/aaaa).");
    const virement = el("vrsMode").value === "Virement";
    const corps = {
      type_reversement: versementEnCours.type, montant: somme, date_reversement: jour,
      compte_id: Number(el("vrsCompte").value), mode_paiement: el("vrsMode").value,
      beneficiaire_id: virement && el("vrsRib").value ? Number(el("vrsRib").value) : null,
      reference: el("vrsReference").value, observation: el("vrsObservation").value,
    };
    if (versementEnCours.type === "Loyers") corps.proprietaire_id = versementEnCours.id;
    else if (caution) Object.assign(corps, { contrat_id: versementEnCours.id, retenue, motif_retenue: el("vrsMotifRetenue").value });
    else corps.achat_vente_id = versementEnCours.id;
    const rep = await api("/api/reversements", { method: "POST", body: corps });
    fermerModal("modalReversement");
    toast(`Versement ${rep.numero} enregistré : imprimez le bordereau et faites-le signer`, 6000);
    window.open(`/api/reversements/${rep.id}/bordereau`, "_blank");
    chargerReversements();
  });
});

function supprimerReversement(id, numero) {
  supprimerAvecConfirmation(`Supprimer le versement ${numero} ? La somme redeviendra « à verser ». Mot de passe Admin.`,
    `/api/reversements/${id}/supprimer`, chargerReversements);
}

// ---------- Carnet de RIB ----------

async function chargerBeneficiaires() {
  const zone = el("listeBeneficiaires");
  try { beneficiairesCache = await api("/api/beneficiaires"); }
  catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  zone.innerHTML = beneficiairesCache.length ? `<div class="card">${beneficiairesCache.map(b => `
    <div class="row"${motsCles({ tel: [b.mobile_money], textes: [b.iban, b.rib, b.proprietaire] })}>
      <span class="who"><b>${esc(b.nom)}</b> — ${esc(b.categorie)}${b.proprietaire && b.proprietaire !== b.nom ? ` (${esc(b.proprietaire)})` : ""}
        <br><span class="petit">${[b.banque_nom, b.rib && "RIB " + b.rib, b.iban_lisible && "IBAN " + b.iban_lisible, b.bic && "BIC " + b.bic,
          b.mobile_money && "Mobile Money " + b.mobile_money].filter(Boolean).map(esc).join(" — ")}</span></span>
      <span class="boutons">${b.actif ? "" : '<span class="pill">Inactif</span>'}${ibtn("modifier", "Modifier ce RIB", `modifierBeneficiaire(${b.id})`)}</span>
    </div>`).join("")}</div>` : '<div class="card vide">Aucun RIB enregistré. Cliquez sur « + Ajouter un RIB ».</div>';
}

async function remplirFormBeneficiaire(b) {
  if (!reversementsCache) {
    try { reversementsCache = await api("/api/reversements/a-verser"); } catch (e) { toast(e.message); return; }
  }
  beneficiaireEnCours = b ? b.id : null;
  el("benTitre").textContent = b ? `Modifier le RIB de ${b.nom}` : "Ajouter un RIB";
  remplirSelect(el("benCategorie"), ["Propriétaire", "Employé", "Fournisseur", "Autre"]);
  remplirSelect(el("benProprio"), reversementsCache.proprietaires_liste, { valeur: p => p.id, texte: p => p.nom, vide: "— Aucun —" });
  el("benNom").value = b?.nom || "";
  el("benCategorie").value = b?.categorie || "Propriétaire";
  el("benProprio").value = b?.proprietaire_id ?? "";
  const champs = { benBanque: "banque_nom", benTitulaire: "titulaire", benCode: "banque_code", benGuichet: "banque_guichet",
                   benCompte: "banque_compte", benCle: "banque_cle_rib", benIban: "iban_lisible", benBic: "bic", benMobile: "mobile_money" };
  for (const [id, cle] of Object.entries(champs)) el(id).value = b ? b[cle] : "";
  el("benActif").checked = b ? b.actif : true;
  el("benSupprimer").style.display = b && estAdmin() ? "" : "none";
  majCategorieBeneficiaire();
  reinitialiserSaisie(el("formBeneficiaire"));
  erreurFormulaire(el("formBeneficiaire"), "");
  ouvrirModal("modalBeneficiaire");
}
function majCategorieBeneficiaire() { el("champBenProprio").style.display = el("benCategorie").value === "Propriétaire" ? "" : "none"; }
el("benCategorie").addEventListener("change", majCategorieBeneficiaire);
// Choisir le propriétaire remplit le nom
el("benProprio").addEventListener("change", () => {
  const p = reversementsCache?.proprietaires_liste.find(x => String(x.id) === el("benProprio").value);
  if (p && !el("benNom").value.trim()) el("benNom").value = p.nom;
});
function nouveauBeneficiaire() { remplirFormBeneficiaire(null); }
function modifierBeneficiaire(id) {
  const b = beneficiairesCache.find(x => x.id === id);
  if (b) remplirFormBeneficiaire(b);
}

el("formBeneficiaire").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (el("benNom").value.trim().length < 2) throw new Error("Indiquez le nom du bénéficiaire.");
    const corps = {
      nom: el("benNom").value, categorie: el("benCategorie").value,
      proprietaire_id: el("benCategorie").value === "Propriétaire" && el("benProprio").value ? Number(el("benProprio").value) : null,
      banque_nom: el("benBanque").value, titulaire: el("benTitulaire").value, banque_code: el("benCode").value,
      banque_guichet: el("benGuichet").value, banque_compte: el("benCompte").value, banque_cle_rib: el("benCle").value,
      iban: el("benIban").value, bic: el("benBic").value, mobile_money: el("benMobile").value, actif: el("benActif").checked,
    };
    if (beneficiaireEnCours) await api(`/api/beneficiaires/${beneficiaireEnCours}`, { method: "PUT", body: corps });
    else await api("/api/beneficiaires", { method: "POST", body: corps });
    fermerModal("modalBeneficiaire");
    toast("RIB enregistré");
    chargerBeneficiaires();
  });
});

el("benSupprimer").addEventListener("click", () => {
  if (!beneficiaireEnCours) return;
  fermerModal("modalBeneficiaire");
  supprimerAvecConfirmation("Supprimer ce RIB du carnet ? Les versements déjà faits restent. Mot de passe Admin.",
    `/api/beneficiaires/${beneficiaireEnCours}/supprimer`, chargerBeneficiaires);
});
