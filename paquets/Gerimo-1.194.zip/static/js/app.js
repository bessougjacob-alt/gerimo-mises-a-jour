// Cadre de l'application après connexion.
// Le serveur indique (via /api/moi) les modules autorisés pour le rôle,
// et revérifie chaque ouverture de module (via /api/acces/...).

// Icônes « premium » (style Lucide, trait fin) ; couleur et teinte de chaque module ;
// groupe = rubrique du menu latéral.
const MODULES = [
  { id: "accueil", menu: "Accueil", desc: "Vue d'ensemble du jour", groupe: null, couleur: "#1d3b53", teinte: "#e3e9ef",
    svg: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5"/>' },
  // Ordre demandé : Propriétaires d'abord, puis les biens
  { id: "proprietaires", menu: "Propriétaires", desc: "Gestion des propriétaires", groupe: "Gestion", etape: 2, couleur: "#c1552d", teinte: "#fbeae2",
    svg: '<rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="9" cy="10" r="2.5"/><path d="M5.5 16.5a3.5 3.5 0 0 1 7 0"/><path d="M15 9h3M15 13h3"/>' },
  { id: "biens", menu: "Biens", carte: "Biens immobiliers", desc: "Gestion des biens, logements et parcelles", groupe: "Gestion", etape: 2, couleur: "#4c8a4a", teinte: "#e5f1e3",
    svg: '<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"/><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"/><path d="M10 6h4M10 10h4M10 14h4M10 18h4"/>' },
  { id: "locataires", menu: "Locataires", desc: "Gestion des locataires", groupe: "Gestion", etape: 3, couleur: "#2f6690", teinte: "#e4eef6",
    svg: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>' },
  { id: "contrats", menu: "Contrats", desc: "Gestion des contrats de bail", groupe: "Gestion", etape: 3, couleur: "#6b4fa0", teinte: "#ece7f6",
    svg: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h6"/><path d="M8 18c1.2-1.4 2.2-2.6 3-2.6s.6 1.6 1.6 1.6 1.4-.9 2.4-.9"/>' },
  { id: "sejours", menu: "Courte durée", carte: "Courte durée", desc: "Location meublée à la nuit : réservations, calendrier, acomptes", groupe: "Gestion", couleur: "#b7791f", teinte: "#f8eedb",
    svg: '<path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8"/><path d="M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4"/><path d="M12 4v6"/><path d="M2 18h20"/>' },
  { id: "paiements", menu: "Finances", desc: "Encaissements, impayés, relances et historique", groupe: "Finances", etape: 4, couleur: "#1f7a6d", teinte: "#dff1ee",
    svg: '<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>' },
  { id: "depenses", menu: "Dépenses", desc: "Dépenses des biens et du bureau", groupe: "Finances", etape: 7, couleur: "#b7791f", teinte: "#f8eedb",
    svg: '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 17.5v-11"/>' },
  { id: "achats_ventes", menu: "Achats / Ventes de biens", carte: "Achats / Ventes", desc: "Reçu, facture ou décharge", groupe: "Finances", etape: 7, couleur: "#b0392c", teinte: "#f8e3df",
    svg: '<path d="M12.6 2.6A2 2 0 0 0 11.2 2H4a2 2 0 0 0-2 2v7.2a2 2 0 0 0 .6 1.4l8.7 8.7a2.4 2.4 0 0 0 3.4 0l6.6-6.6a2.4 2.4 0 0 0 0-3.4z"/><circle cx="7.5" cy="7.5" r="1.5"/>' },
  { id: "tresorerie", menu: "Trésorerie", desc: "Caisse, banque, Mobile Money", groupe: "Finances", couleur: "#2f6690", teinte: "#e4eef6",
    svg: '<rect x="2" y="6" width="20" height="13" rx="2"/><path d="M2 10h20"/><path d="M6 15h3"/><path d="M16 3 12 6 8 3"/>' },
  { id: "rapports", menu: "Rapports &amp; statistiques", carte: "Rapports", desc: "Statistiques, KPI et reversements", groupe: "Finances", etape: 8, couleur: "#1d3b53", teinte: "#e3e9ef",
    svg: '<path d="M21 12a9 9 0 1 1-9-9v9z"/><path d="M15 3.5A9 9 0 0 1 20.5 9H15z"/>' },
  // Module isolé (carte orange à droite de l'accueil) et options du menu
  { id: "etats_des_lieux", menu: "État des lieux", titreDesc: "Entrée / sortie, photos, signature, envoi au locataire", groupe: "Outils", couleur: "#c1552d", teinte: "#fbeae2",
    svg: '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>' },
  { id: "courriers", menu: "Actions / courriers", titreDesc: "Révision de loyer et avenant au bail", groupe: "Outils", couleur: "#2f6690", teinte: "#e4eef6",
    svg: '<path d="M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/><path d="m16 19 2 2 4-4"/>' },
  { id: "agenda", menu: "Agenda &amp; clients", titreDesc: "Rendez-vous, appels, tâches et demandes de clients", groupe: "Outils", couleur: "#4c8a4a", teinte: "#e5f1e3",
    svg: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/><path d="M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01"/>' },
  { id: "reseaux_sociaux", menu: "Réseaux sociaux", titreDesc: "Annonces Facebook et WhatsApp, invitations", groupe: "Outils", couleur: "#1877f2", teinte: "#e3eefd",
    svg: '<path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>' },
  { id: "parametres", menu: "Paramètres", titre: "Paramètres", titreDesc: "Utilisateurs, réglages, sauvegardes, journal, corbeille, assistant, reprise de données, à propos", groupe: "Administration", etape: 9, couleur: "#5c655e", teinte: "#eceeea",
    svg: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>' },
];
// Titre affiché pour les sous-écrans
const TITRES_ECRANS = {
  historique: ["Historique des paiements", "Tous les encaissements, avec filtres et totaux"],
  messagesGroupes: ["Messages groupés", "Le même message à plusieurs locataires, sur WhatsApp"],
  problemes: ["Problèmes signalés", "Suivi des interventions sur les biens"],
  formEdl: ["État des lieux", "Grille, photos et signatures"],
  formRevision: ["Révision de loyer", "Nouveau montant à partir d'une date"],
  formAvenant: ["Avenant au bail", "Modification d'une clause du contrat"],
};
const svgModule = m => `<svg viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">${m.svg}</svg>`;

// Sous-écrans (formulaires) → module auquel ils appartiennent
const ECRANS = {
  formBien: "biens", formCite: "biens", formProprio: "proprietaires", problemes: "biens",
  formContrat: "contrats", formLocataire: "locataires", formPaiement: "paiements", formDepense: "depenses",
  formAchatVente: "achats_ventes", historique: "paiements", messagesGroupes: "paiements", formEdl: "etats_des_lieux",
  formRevision: "courriers", formAvenant: "courriers", formSejour: "sejours",
};
// Fonctions de chargement appelées à l'affichage d'un écran (remplies par biens.js…)
const CHARGEURS = {};

let moi = null;
let screenHistory = [];

function infosModule(id) { return MODULES.find(m => m.id === id); }
function estAdmin() { return moi && moi.role === "Admin"; }
// Nom de l'entreprise cliente (« Mon entreprise », Paramètres)
function nomEntreprise() { return (moi && moi.entreprise) || "l'entreprise"; }
// « d'ISUP SARL », « de Agence Horizon »
function deEntreprise() { const n = nomEntreprise(); return (/^[aeiouyéèêâîôh]/i.test(n) ? "d'" : "de ") + n; }
const FORMES_JURIDIQUES = ["SARLU", "SARL", "SASU", "SAS", "SA", "SCI", "SCS", "SNC", "GIE", "EURL", "ETS"];
function afficherNomEntreprise(nom) {
  const morceaux = String(nom || "").trim().split(/\s+/);
  const forme = morceaux.length > 1 && FORMES_JURIDIQUES.includes(morceaux[morceaux.length - 1].toUpperCase().replace(/\./g, ""))
    ? morceaux.pop().replace(/\./g, "") : "";
  const h = document.getElementById("nomEntreprise");
  if (!h || !nom) return;
  h.innerHTML = esc(morceaux.join(" ")) + (forme ? ` <span class="sarl">${esc(forme.charAt(0).toUpperCase() + forme.slice(1).toLowerCase())}</span>` : "");
}

// ---------- Outils communs ----------

// Échappe le texte saisi avant de l'insérer dans la page
function esc(valeur) {
  return String(valeur ?? "").replace(/[&<>"']/g, c =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// ---------- Dates : toujours jj/mm/aaaa ----------

// « 2026-10-02 » (format du serveur) → « 02/10/2026 »
function formatDate(iso) {
  if (!iso) return "";
  const [a, m, j] = iso.split("-");
  return `${j}/${m}/${a}`;
}
// Date du jour au format du serveur (aaaa-mm-jj)
function aujourdhui() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
// « 02/10/2026 » → « 2026-10-02 » ; null si vide ou date impossible
function isoDepuisTexte(texte) {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(String(texte).trim());
  if (!m) return null;
  const [, j, mo, a] = m.map(Number);
  const d = new Date(a, mo - 1, j);
  if (d.getFullYear() !== a || d.getMonth() !== mo - 1 || d.getDate() !== j) return null;
  return `${m[3]}-${m[2]}-${m[1]}`;
}
// Lecture d'un champ date : aaaa-mm-jj, null si vide ; erreur si mal saisi
function valeurDate(id, libelle) {
  const texte = el(id).value.trim();
  if (!texte) return null;
  const iso = isoDepuisTexte(texte);
  if (!iso) throw new Error(`« ${libelle} » : date invalide, utilisez le format jj/mm/aaaa (ex : 02/10/2026).`);
  return iso;
}
function fixerDate(id, iso) { el(id).value = formatDate(iso); }

// Remplace les champs <input type="date"> (dont le format dépend du navigateur)
// par un champ texte jj/mm/aaaa + un bouton calendrier.
// (rappelée pour une fenêtre créée à la demande : les champs déjà remplacés sont ignorés)
function initialiserChampsDate(racine = document) {
  racine.querySelectorAll('input[type="date"]:not(.date-cache)').forEach(calendrier => {
    const texte = document.createElement("input");
    texte.type = "text";
    texte.id = calendrier.id;
    texte.placeholder = "jj/mm/aaaa";
    texte.maxLength = 10;
    texte.inputMode = "numeric";
    texte.autocomplete = "off";
    texte.required = calendrier.required;
    calendrier.removeAttribute("id");
    calendrier.required = false;
    calendrier.tabIndex = -1;
    calendrier.className = "date-cache";
    calendrier.setAttribute("aria-hidden", "true");

    const bouton = document.createElement("button");
    bouton.type = "button";
    bouton.className = "date-bouton";
    bouton.title = "Choisir dans le calendrier";
    bouton.setAttribute("aria-label", "Calendrier");
    bouton.innerHTML = '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="8" y1="3" x2="8" y2="7"/><line x1="16" y1="3" x2="16" y2="7"/></svg>';

    const boite = document.createElement("div");
    boite.className = "champ-date";
    calendrier.replaceWith(boite);
    boite.append(texte, bouton, calendrier);

    // les « / » s'ajoutent en tapant : 02102026 → 02/10/2026
    texte.addEventListener("input", e => {
      if (e.inputType && e.inputType.startsWith("delete")) return;
      const chiffres = texte.value.replace(/\D/g, "").slice(0, 8);
      texte.value = [chiffres.slice(0, 2), chiffres.slice(2, 4), chiffres.slice(4)].filter(Boolean).join("/");
    });
    bouton.addEventListener("click", () => {
      calendrier.value = isoDepuisTexte(texte.value) || aujourdhui();
      try { calendrier.showPicker(); } catch { calendrier.focus(); }
    });
    calendrier.addEventListener("change", () => {
      texte.value = formatDate(calendrier.value);
      texte.dispatchEvent(new Event("change"));
    });
  });
}

// 75000 → « 75 000 F »
function formatMontant(n) {
  return Number(n).toLocaleString("fr-FR").replace(/[  ]/g, " ") + " F";
}
// « 75 000 » → 75000 (null si invalide)
function lireMontant(texte) {
  const propre = String(texte).replace(/[\s  F]/gi, "").replace(",", ".");
  return /^\d+(\.\d{1,2})?$/.test(propre) ? Number(propre) : null;
}

// Appel au serveur : renvoie le JSON, ou lève une erreur avec le message du serveur
async function api(url, options = {}) {
  const init = { ...options };
  if (options.body !== undefined) {
    init.headers = { "Content-Type": "application/json" };
    init.body = JSON.stringify(options.body);
  }
  let rep;
  try { rep = await fetch(url, init); }
  catch { throw new Error("Le serveur ne répond pas. Vérifiez qu'il est bien démarré."); }
  if (rep.status === 401) { window.location.replace("/connexion"); throw new Error("Session expirée."); }
  const donnees = await rep.json().catch(() => ({}));
  // Gérimo en veille, ou mot de passe provisoire à remplacer (veille.js)
  if (donnees.detail && donnees.detail.code) { gererBlocage(donnees.detail); throw new Error(donnees.detail.message); }
  if (!rep.ok) throw new Error(typeof donnees.detail === "string" ? donnees.detail : "Erreur du serveur.");
  return donnees;
}

// Remplit une liste déroulante
function remplirSelect(select, valeurs, { valeur = v => v, texte = v => v, vide = null } = {}) {
  select.innerHTML = (vide !== null ? `<option value="">${esc(vide)}</option>` : "") +
    valeurs.map(v => `<option value="${esc(valeur(v))}">${esc(texte(v))}</option>`).join("");
}

// ---------- Recherche (dans les listes et barre du haut) ----------

// « Séguéla » → « seguela » : on cherche sans tenir compte des accents ni des majuscules
function sansAccents(texte) {
  return String(texte ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
}
// « +225 07 49 62 25 66 » → « 0749622566 »
function chiffresTel(telephone) {
  const c = String(telephone ?? "").replace(/\D/g, "");
  return c.length > 10 && c.startsWith("225") ? c.slice(3) : c;
}
// Mots-clés cachés d'une ligne de liste : téléphones et textes non affichés (adresse, CNI…)
function motsCles({ tel = [], textes = [] } = {}) {
  const tels = tel.filter(Boolean).map(chiffresTel).join(" ");
  return ` data-tel="${esc(tels)}" data-cherche="${esc(textes.filter(Boolean).join(" "))}"`;
}
// La ligne correspond-elle à la recherche ? (tous les mots, ou le numéro de téléphone)
function ligneTrouvee(ligne, recherche) {
  if (recherche.tel && (ligne.dataset.tel || "").split(" ").some(t => t && t.includes(recherche.tel))) return true;
  const texte = sansAccents(ligne.textContent + " " + (ligne.dataset.cherche || ""));
  return recherche.mots.every(m => texte.includes(m));
}
function preparerRecherche(texte) {
  const brut = texte.trim();
  const estTel = /\d/.test(brut) && !/\p{L}/u.test(brut) && brut.replace(/\D/g, "").length >= 4;
  return { mots: sansAccents(brut).split(/\s+/).filter(Boolean), tel: estTel ? chiffresTel(brut) : null };
}

// Barre « Rechercher ici… » en haut : cherche partout (le serveur respecte les droits)
const CHAMP_RECHERCHE_MODULE = {
  biens: "rechercheBiens", proprietaires: "rechercheProprios", locataires: "rechercheLocataires",
  contrats: "rechercheContrats", paiements: "recherchePaiements", depenses: "rechercheDepenses",
  achats_ventes: "rechercheAV",
};
let resultatsGlobaux = [];
let choixGlobal = -1;
let numeroRecherche = 0;

function fermerRechercheGlobale() {
  el("resultatsRecherche").classList.remove("show");
  choixGlobal = -1;
}

async function lancerRechercheGlobale(q) {
  const numero = ++numeroRecherche;
  const boite = el("resultatsRecherche");
  let rep;
  try {
    rep = await api("/api/recherche?q=" + encodeURIComponent(q));
  } catch (e) {
    boite.innerHTML = `<div class="res-vide">${esc(e.message)}</div>`;
    boite.classList.add("show");
    return;
  }
  if (numero !== numeroRecherche) return;  // une frappe plus récente a déjà relancé la recherche
  resultatsGlobaux = [];
  let html = "";
  for (const g of rep.groupes) {
    html += `<div class="res-groupe">${esc(g.categorie)} <span>(${g.total})</span></div>`;
    for (const r of g.elements) {
      html += `<div class="res" data-i="${resultatsGlobaux.length}"><b>${esc(r.titre)}</b><span>${esc(r.detail)}</span></div>`;
      resultatsGlobaux.push(r);
    }
    if (g.total > g.elements.length) {  // trop de résultats : on ouvre le module filtré
      html += `<div class="res res-plus" data-i="${resultatsGlobaux.length}">Voir les ${g.total} résultats « ${esc(q)} »…</div>`;
      resultatsGlobaux.push({ cible: g.elements[0].cible, filtre: q });
    }
  }
  boite.innerHTML = html || `<div class="res-vide">Aucun résultat pour « ${esc(q)} ».<br>
    Essayez un nom, un téléphone, un quartier, une ville, un N° de contrat ou de reçu.</div>`;
  choixGlobal = -1;
  boite.classList.add("show");
}

function allerAuResultat(r) {
  const champModule = CHAMP_RECHERCHE_MODULE[r.cible];
  if (champModule) el(champModule).value = r.filtre;  // la liste du module s'ouvre déjà filtrée
  el("globalSearch").value = "";
  fermerRechercheGlobale();
  afficher(r.cible);
}

function brancherRechercheGlobale() {
  const champ = el("globalSearch");
  const boite = el("resultatsRecherche");
  let minuterie;
  champ.addEventListener("input", () => {
    clearTimeout(minuterie);
    const q = champ.value.trim();
    if (!q) { fermerRechercheGlobale(); return; }
    minuterie = setTimeout(() => lancerRechercheGlobale(q), 250);
  });
  champ.addEventListener("keydown", e => {
    const items = [...boite.querySelectorAll(".res")];
    if (e.key === "Escape") { e.preventDefault(); fermerRechercheGlobale(); champ.blur(); return; }
    if (!boite.classList.contains("show") || !items.length) return;
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      choixGlobal = (choixGlobal + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length;
      items.forEach((x, i) => x.classList.toggle("actif", i === choixGlobal));
      items[choixGlobal].scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter") {
      e.preventDefault();
      const item = items[Math.max(choixGlobal, 0)];
      allerAuResultat(resultatsGlobaux[Number(item.dataset.i)]);
    }
  });
  champ.addEventListener("focus", () => { if (champ.value.trim() && boite.innerHTML) boite.classList.add("show"); });
  // Bouton loupe : lance la recherche tout de suite (elle se fait aussi pendant la frappe)
  el("globalSearchBtn").addEventListener("click", () => {
    const q = champ.value.trim();
    if (!q) { champ.focus(); toast("Tapez un nom, un téléphone, un quartier, un N° de contrat…"); return; }
    clearTimeout(minuterie);
    lancerRechercheGlobale(q);
  });
  boite.addEventListener("mousedown", e => {
    const item = e.target.closest(".res");
    if (item) { e.preventDefault(); allerAuResultat(resultatsGlobaux[Number(item.dataset.i)]); }
  });
  document.addEventListener("mousedown", e => { if (!e.target.closest(".gsearch")) fermerRechercheGlobale(); });
}

// Filtre une liste au fur et à mesure de la saisie dans la barre de recherche
function brancherRecherche(champ, conteneur) {
  champ.addEventListener("input", () => {
    const recherche = preparerRecherche(champ.value);
    if (!recherche.mots.length) {  // recherche vide : tout réafficher (y compris les cartes sans ligne)
      conteneur.querySelectorAll(".card, .row").forEach(x => { x.style.display = ""; });
      return;
    }
    const trouve = ligne => ligneTrouvee(ligne, recherche);
    conteneur.querySelectorAll(".card").forEach(carte => {
      const sousLignes = [...carte.querySelectorAll(".row.sous")];
      if (!sousLignes.length) {
        // liste simple : une ligne = un élément
        let visibles = 0;
        carte.querySelectorAll(".row").forEach(ligne => {
          const ok = trouve(ligne);
          ligne.style.display = ok ? "" : "none";
          if (ok) visibles++;
        });
        carte.style.display = visibles ? "" : "none";
        return;
      }
      // groupe (cité + logements) : si la cité correspond, on montre tout le groupe ;
      // sinon seulement les logements trouvés, toujours sous le nom de leur cité
      const groupeEntier = trouve(carte.querySelector(".row:not(.sous)"));
      let visibles = 0;
      sousLignes.forEach(ligne => {
        const ok = groupeEntier || trouve(ligne);
        ligne.style.display = ok ? "" : "none";
        if (ok) visibles++;
      });
      carte.style.display = groupeEntier || visibles ? "" : "none";
    });
  });
}

// Formulaires : message d'erreur et bouton Enregistrer
function erreurFormulaire(form, message) {
  const zone = form.querySelector(".form-erreur");
  zone.textContent = message || "";
  zone.style.display = message ? "block" : "none";
}
async function soumettre(form, action) {
  const bouton = form.querySelector('button[type="submit"]');
  erreurFormulaire(form, "");
  bouton.disabled = true;
  try {
    verifierChamps(form);   // règles de saisie (saisie.js), revérifiées par le serveur
    await action();
    chargerVocabulaire();   // les mots saisis enrichissent les suggestions
  }
  catch (e) { erreurFormulaire(form, e.message); }
  finally { bouton.disabled = false; }
}
function effacerFormulaire(btn) {
  const form = btn.closest("form");
  form.querySelectorAll("input:not(:disabled), textarea").forEach(i => { i.value = ""; });
  reinitialiserSaisie(form);
  erreurFormulaire(form, "");
  toast("Champs réinitialisés");
}

// Mot de passe Admin redemandé : renvoie le mot de passe, ou null si annulé
// options : { titre, bouton, danger } — par défaut, une suppression (« Confirmer la suppression », bouton rouge)
function demanderMotDePasseAdmin(texte, { titre = "Confirmer la suppression", bouton = "Supprimer", danger = true } = {}) {
  const fond = document.getElementById("modalAdmin");
  document.getElementById("modalAdminTitre").textContent = titre;
  const valider = document.getElementById("modalAdminValider");
  valider.textContent = bouton;
  valider.className = "btn " + (danger ? "danger" : "primary");
  const form = document.getElementById("formModalAdmin");
  const champ = document.getElementById("modalAdminMdp");
  document.getElementById("modalAdminTexte").textContent = texte;
  champ.value = "";
  champ.placeholder = estAdmin() ? "Mot de passe Admin" : "Votre mot de passe";
  fond.classList.add("show");
  champ.focus();
  return new Promise(resolve => {
    const fermer = valeur => {
      fond.classList.remove("show");
      form.onsubmit = null;
      document.getElementById("modalAdminAnnuler").onclick = null;
      resolve(valeur);
    };
    form.onsubmit = e => { e.preventDefault(); fermer(champ.value); };
    document.getElementById("modalAdminAnnuler").onclick = () => fermer(null);
  });
}

// ---------- Écran : « Ajuster l'écran » (demande de Boss du 11/11/2026) ----------
// Sur un grand écran, tout l'affichage (textes, cartes, espacements) est agrandi d'un même facteur, calculé pour que
// Gérimo garde la place pour laquelle il est dessiné (environ 1600 × 760). Mémorisé sur chaque PC : un autre PC ou un
// nouvel écran démarre en taille normale. Les tailles « écran » du CSS sont divisées par --zoom-ecran.
const CLE_ZOOM_ECRAN = "gerimo_zoom_ecran";
function zoomEcran() { return parseFloat(document.documentElement.style.zoom) || 1; }
function appliquerZoomEcran(z) {
  const h = document.documentElement;
  h.style.zoom = z > 1 ? z : "";
  if (z > 1) h.style.setProperty("--zoom-ecran", z); else h.style.removeProperty("--zoom-ecran");
  try { if (z > 1) localStorage.setItem(CLE_ZOOM_ECRAN, z); else localStorage.removeItem(CLE_ZOOM_ECRAN); } catch { /* navigateur privé */ }
}
function zoomConseille() {
  const f = Math.min(innerWidth / 1600, innerHeight / 760);
  return Math.max(1, Math.min(1.75, Math.floor(f * 20) / 20));  // par pas de 5 %, entre 100 % et 175 %
}
function texteEcran() {
  const r = devicePixelRatio || 1, z = zoomEcran();
  return `Cet écran : ${Math.round(screen.width * r)} × ${Math.round(screen.height * r)} pixels, échelle ${Math.round(r * 100)} %, ` +
         `place pour Gérimo : ${innerWidth} × ${innerHeight}` + (z > 1 ? ` — affichage agrandi à ${Math.round(z * 100)} %` : " — taille normale");
}
async function reglerEcran() {
  if (typeof closeMenu === "function") closeMenu();
  const conseil = zoomConseille();
  const choix = await demanderChoix("Ajuster l'écran", `<p class="petit">${esc(texteEcran())}</p><p>` + (conseil > 1
    ? `Pour cet écran, Gérimo conseille un affichage agrandi à <b>${Math.round(conseil * 100)} %</b> (textes, cartes et espacements).`
    : "Cet écran n'a pas besoin d'agrandissement : la taille normale est la bonne.") +
    " Le réglage ne vaut que pour ce PC.</p>" +
    `<div class="field"><label for="zoomManuel">Ou choisissez vous-même</label><select id="zoomManuel">${
      [1, 1.1, 1.2, 1.25, 1.3, 1.4, 1.5, 1.6, 1.75].map(v => `<option value="${v}"${Math.abs(v - zoomEcran()) < .01 ? " selected" : ""}>${Math.round(v * 100)} %</option>`).join("")
    }</select></div>`,
    [{ cle: "manuel", libelle: "Appliquer mon choix" }, { cle: "normal", libelle: "Taille normale" },
     ...(conseil > 1 ? [{ cle: "ajuster", libelle: "Ajuster automatiquement", classe: "primary" }] : [])]);
  if (choix === "manuel") {
    const v = parseFloat(el("zoomManuel").value) || 1;
    appliquerZoomEcran(v);
    toast(v > 1 ? `Affichage agrandi à ${Math.round(v * 100)} % sur ce PC` : "Affichage en taille normale sur ce PC");
  }
  if (choix === "ajuster") { appliquerZoomEcran(conseil); toast(`Affichage agrandi à ${Math.round(conseil * 100)} % sur ce PC`); }
  if (choix === "normal") { appliquerZoomEcran(1); toast("Affichage en taille normale sur ce PC"); }
  if (choix && el("ligneEcran")) el("ligneEcran").textContent = texteEcran();
}

// Choix entre plusieurs réponses : renvoie la clé du bouton cliqué, ou null si « Annuler »
//   demanderChoix("Titre", "<p>Texte (HTML déjà échappé)</p>", [{ cle: "oui", libelle: "Oui", classe: "primary" }])
function demanderChoix(titre, html, boutons) {
  const fond = document.getElementById("modalChoix");
  document.getElementById("modalChoixTitre").textContent = titre;
  document.getElementById("modalChoixTexte").innerHTML = html;
  const zone = document.getElementById("modalChoixBoutons");
  zone.innerHTML = '<button type="button" class="btn" data-cle="">Annuler</button>' + boutons.map(b =>
    `<button type="button" class="btn ${b.classe || ""}" data-cle="${esc(b.cle)}">${esc(b.libelle)}</button>`).join("");
  fond.classList.add("show");
  return new Promise(resolve => {
    zone.querySelectorAll("button").forEach(bouton => {
      bouton.onclick = () => { fond.classList.remove("show"); resolve(bouton.dataset.cle || null); };
    });
  });
}

// Message WhatsApp type (bienvenue, rappel, confirmation, retard, expulsion) :
// le serveur prépare le texte (modeles/messages_whatsapp.txt) et le lien wa.me.
async function envoyerWhatsApp(type, ids, apres) {
  const fenetre = window.open("", "_blank");  // ouverte tout de suite, sinon le navigateur la bloque
  try {
    const rep = await api("/api/whatsapp", { method: "POST", body: { type_message: type, ...ids } });
    if (fenetre) fenetre.location.href = rep.lien;
    else window.location.href = rep.lien;
    toast(`WhatsApp ouvert pour ${rep.locataire} : vérifiez le message puis appuyez sur Envoyer`);
    if (apres) apres();
  } catch (e) {
    if (fenetre) fenetre.close();
    toast(e.message);
  }
}

// Suppression complète : confirmation par mot de passe, appel serveur, message
async function supprimerAvecConfirmation(texte, url, apres) {
  const mdp = await demanderMotDePasseAdmin(texte);
  if (!mdp) { toast("Suppression annulée"); return; }
  try {
    await api(url, { method: "POST", body: { mot_de_passe_admin: mdp } });
    toast("Élément supprimé : il reste récupérable dans Paramètres → Corbeille (Admin)", 5000);
    await apres();
  } catch (e) { toast(e.message); }
}

async function demarrer() {
  const rep = await fetch("/api/moi");
  if (rep.status === 401) { window.location.replace("/connexion"); return; }
  if (!rep.ok) {  // en veille, ou mot de passe provisoire à remplacer : l'écran correspondant s'affiche
    const d = await rep.json().catch(() => ({}));
    if (d.detail && d.detail.code) gererBlocage(d.detail);
    return;
  }
  moi = await rep.json();
  afficherNomEntreprise(moi.entreprise);
  // nouvelle installation : on reste sur l'accueil (demande de Boss du 19/10/2026), avec un simple rappel
  if (!moi.entreprise && moi.role === "Admin") setTimeout(() => {
    toast("Bienvenue ! Pensez à remplir « Mon entreprise » (Paramètres → Réglages) : son nom, sa ville et ses téléphones figurent sur tous vos reçus et documents.", 9000);
  }, 800);

  // on affiche le profil (Admin, Gestionnaire, Caisse) plutôt que le nom de la personne
  document.getElementById("whoNom").textContent = moi.role;
  document.getElementById("avatar").textContent = moi.role.charAt(0).toUpperCase();
  document.getElementById("avatar").setAttribute("data-tip", `Profil ${moi.role}${moi.fonction ? " — " + moi.fonction : ""} · cliquer pour changer le mot de passe`);
  document.querySelectorAll(".admin-only").forEach(el => {
    el.style.display = moi.role === "Admin" ? "" : "none";
  });

  const autorises = MODULES.filter(m => moi.modules.includes(m.id));
  // Menu latéral : rubriques (Gestion, Finances, Outils, Administration)
  let groupe;
  document.getElementById("menuItems").innerHTML = autorises.filter(m => m.menu).map(m => {
    const titre = m.groupe !== groupe && m.groupe ? `<div class="sm-groupe">${m.groupe}</div>` : "";
    groupe = m.groupe;
    return `${titre}<button class="mi" data-screen="${m.id}" onclick="navTo('${m.id}')"><span class="mi-ico">${svgModule(m)}</span><span>${m.menu}</span></button>`;
  }).join("") + (SUR_ORDINATEUR
    ? `<button class="mi" onclick="closeMenu(); raccourcisGerimo()"><span class="mi-ico"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="2"/><line x1="8" y1="20" x2="16" y2="20"/><line x1="12" y1="16" x2="12" y2="20"/></svg></span><span>Raccourci bureau et barre des tâches</span></button>` : "");
  api("/api/version").then(v => { el("smVersion").textContent = `Version ${v.version}`; }).catch(() => {});
  // Accueil : les 8 modules principaux, dans cet ordre (Rapports & statistiques : icône du bord droit)
  const ACCUEIL = ["proprietaires", "biens", "locataires", "contrats", "achats_ventes", "paiements", "depenses", "tresorerie"];
  document.getElementById("modgrid").innerHTML = ACCUEIL.map(infosModule).filter(m => moi.modules.includes(m.id)).map(m =>
    `<button class="modcard" onclick="ouvrirModule('${m.id}')" style="--couleur:${m.couleur};--teinte:${m.teinte}"><div class="icon">${svgModule(m)}</div><div><b>${m.carte || m.menu}</b><span>${m.desc}</span></div></button>`
  ).join("");
  if (!moi.modules.includes("etats_des_lieux")) el("carteEdl").style.display = "none";
  if (!moi.modules.includes("agenda")) el("widgetAgenda").style.display = "none";

  // La Caisse n'a pas d'accueil : elle arrive directement sur les Finances
  // le Comptable arrive sur la Trésorerie
  const premier = ["accueil", "paiements", "tresorerie"].find(m => moi.modules.includes(m)) || moi.modules[0];
  screenHistory = [premier];
  await afficher(premier, true);
  document.getElementById("app").style.visibility = "visible";
  if (typeof demarrerAssistant === "function") demarrerAssistant();
  verifierMiseAJourDiscrete();
  envoyerSaisiesHorsReseau();
}

// Retour du serveur : envoi des enregistrements faits hors réseau (file d'attente du téléphone, voir
// static/hors_reseau/local.js). Le serveur les rejoue avec ses règles ; un refus va dans « À vérifier » (Admin).
const CLE_FILE_HORS_RESEAU = "gerimo_file_attente";
const PONT_HORS_RESEAU = (window.ISUPAndroid && window.ISUPAndroid.garderCopie ? window.ISUPAndroid : null) || window.GerimoPont || null;
async function envoyerSaisiesHorsReseau() {
  if (window.horsReseauPret) return;  // on est hors réseau : rien à envoyer
  const tel = PONT_HORS_RESEAU && PONT_HORS_RESEAU.fileAttente ? PONT_HORS_RESEAU : null;
  const lire = async () => { try { return JSON.parse((tel ? await tel.fileAttente() : localStorage.getItem(CLE_FILE_HORS_RESEAU)) || "[]"); } catch { return []; } };
  const ecrire = async liste => {
    if (tel) await tel.enregistrerFile(JSON.stringify(liste));
    else if (liste.length) localStorage.setItem(CLE_FILE_HORS_RESEAU, JSON.stringify(liste));
    else localStorage.removeItem(CLE_FILE_HORS_RESEAU);
  };
  // aperçu dans un navigateur (?apercu=1) : sa file est dans localStorage, même si le navigateur a un pont
  let apercu = [];
  try { apercu = JSON.parse(localStorage.getItem(CLE_FILE_HORS_RESEAU) || "[]"); } catch { apercu = []; }
  if (tel && apercu.length) {
    await tel.enregistrerFile(JSON.stringify([...(await lire()), ...apercu]));
    localStorage.removeItem(CLE_FILE_HORS_RESEAU);
  }
  const miennes = (await lire()).filter(op => op.identifiant === moi.identifiant);
  if (!miennes.length) return;
  toast(`Envoi de ${miennes.length} enregistrement(s) fait(s) hors réseau…`, 4000);
  let r;
  try {
    const appareil = tel && tel.infosAppareil ? JSON.parse(await tel.infosAppareil()).nom : "Navigateur";
    r = await api("/api/hors-reseau/envoyer", { method: "POST", body: { appareil, operations: miennes } });
  } catch (e) { toast(`Envoi des enregistrements hors réseau reporté : ${e.message}`, 6000); return; }
  const traites = new Set(r.resultats.filter(x => x.statut !== "Autre utilisateur").map(x => x.uid));
  await ecrire((await lire()).filter(op => !traites.has(op.uid)));
  toast(r.a_verifier
    ? `${r.envoyees} enregistrement(s) hors réseau envoyé(s) ✅ — ${r.a_verifier} à vérifier par l'Admin (Paramètres → Réglages)`
    : `${r.envoyees} enregistrement(s) hors réseau envoyé(s) ✅`, 8000);
  if (screenHistory.length) afficher(screenHistory[screenHistory.length - 1]).catch(() => {});
}

// Accueil sur grand écran : le bandeau « Bonjour » monte dans la barre du haut (à côté du logo)
// et la recherche descend en face de « Modules principaux ». Ailleurs, la recherche reste en haut.
const GRAND_ECRAN = window.matchMedia("(min-width: 901px)");
function placerBandeauEtRecherche(surAccueil) {
  if (surAccueil === undefined) surAccueil = document.getElementById("accueil").classList.contains("active");
  const barre = document.querySelector(".topbar"), qui = barre.querySelector(".who");
  const recherche = document.querySelector(".gsearch"), bandeau = document.querySelector(".bonjour");
  const enHaut = surAccueil && GRAND_ECRAN.matches;
  if (enHaut) {
    barre.insertBefore(bandeau, qui);
    document.getElementById("placeRecherche").appendChild(recherche);
  } else {
    barre.insertBefore(recherche, qui);
    document.querySelector(".accueil-haut").prepend(bandeau);
  }
  document.body.classList.toggle("bandeau-en-haut", enHaut);
}
GRAND_ECRAN.addEventListener("change", () => placerBandeauEtRecherche());

async function afficher(id, isRoot) {
  const module = ECRANS[id] || id;
  if (module !== "accueil") {
    // contrôle serveur : même si quelqu'un trafique la page, le serveur refuse
    const rep = await fetch("/api/acces/" + encodeURIComponent(module));
    if (rep.status === 401) { window.location.replace("/connexion"); return false; }
    if (rep.status === 403) { toast("Accès refusé pour votre profil"); return false; }
  }
  fermerMenusFlottants();
  const section = document.getElementById(id);
  if (!section) {
    // module pas encore construit
    const m = infosModule(id);
    document.getElementById("moduleTitre").innerHTML = m.titre || m.carte || m.menu;
    document.getElementById("moduleTexte").textContent =
      `Ce module sera construit à l'étape ${m.etape} de la feuille de route.`;
  }
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  (section || document.getElementById("module")).classList.add("active");
  if (section) reinitialiserSaisie(section);  // pas de marques rouges d'une saisie précédente
  if (CHARGEURS[id]) CHARGEURS[id]();
  document.querySelectorAll(".mi[data-screen]").forEach(t => t.classList.toggle("active", t.dataset.screen === module));
  afficherEnteteEcran(id, module);
  placerBandeauEtRecherche(module === "accueil");
  if (!isRoot && screenHistory[screenHistory.length - 1] !== id) screenHistory.push(id);
  document.querySelectorAll(".backbtn").forEach(b => b.classList.toggle("show", screenHistory.length > 1));
  return true;
}

// Titre de l'écran (icône du module, nom, description) ; pas sur l'accueil
function afficherEnteteEcran(id, module) {
  const m = infosModule(module);
  const entete = el("enteteEcran");
  if (!m || module === "accueil") { entete.hidden = true; return; }
  const [titre, desc] = TITRES_ECRANS[id] || [(m.titre || m.carte || m.menu).replace("&amp;", "&"), m.desc || m.titreDesc || ""];
  entete.hidden = false;
  entete.style.setProperty("--couleur", m.couleur);
  entete.style.setProperty("--teinte", m.teinte);
  el("eeIco").innerHTML = svgModule(m);
  el("eeTitre").textContent = titre;
  el("eeDesc").textContent = desc;
}

function ouvrirModule(id) { afficher(id); }
// Paramètres, directement sur l'onglet des comptes (demandé à l'assistant Gérimo)
function ouvrirUtilisateurs() { ouvrirRubriqueParametres("parUtilisateursOnglet"); }
function ouvrirSauvegardes() { ouvrirRubriqueParametres("parSauvegardes"); }
function navTo(id) { afficher(id); closeMenu(); }
// Le logo et le nom en haut (et en tête du menu) ramènent à l'accueil
function allerAccueil() {
  closeMenu();
  screenHistory = ["accueil"];
  afficher("accueil", true);
}

function goBack() {
  if (typeof retourParametres === "function" && retourParametres()) return;  // téléphone : rubrique → liste
  if (screenHistory.length > 1) {
    screenHistory.pop();
    afficher(screenHistory[screenHistory.length - 1], true);
  }
}
document.addEventListener("keydown", e => {
  if (e.key !== "Backspace") return;
  const t = e.target;
  if (["INPUT", "SELECT", "TEXTAREA"].includes(t.tagName) || t.isContentEditable) return;
  e.preventDefault(); goBack();
});

function toggleMenu() {
  document.getElementById("sideMenu").classList.toggle("show");
  document.getElementById("menuOverlay").classList.toggle("show");
}
function closeMenu() {
  document.getElementById("sideMenu").classList.remove("show");
  document.getElementById("menuOverlay").classList.remove("show");
}

// Déconnexion : on demande d'abord confirmation (Oui → déconnecté ; Non → on reste)
function logout() {
  closeMenu();
  const fond = el("modalDeconnexion");
  fond.classList.add("show");
  el("decoNon").focus();
  el("decoNon").onclick = () => fond.classList.remove("show");
  el("decoOui").onclick = async () => {
    try { await fetch("/api/deconnexion", { method: "POST" }); } finally {
      window.location.replace("/connexion");
    }
  };
}

function aVenir() { toast("Disponible dans les prochaines étapes"); }

let toastTimer;
function toast(msg, duree) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.style.opacity = "1";
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.style.opacity = "0"; }, duree || Math.max(2200, msg.length * 55));
}

// ---------- Raccourcis Windows (bureau, barre des tâches) ----------
// Edge et Chrome savent « installer » Gérimo comme une application : leur fenêtre propose alors de cocher
// « Épingler à la barre des tâches » et « Créer un raccourci sur le Bureau ». Ils ne le permettent qu'en connexion
// sécurisée (https) ou sur le PC serveur lui-même ; sinon on explique les autres moyens.
const SUR_ORDINATEUR = /Windows|Macintosh|Linux x86_64/.test(navigator.userAgent) && !window.ISUPAndroid
  && !(navigator.maxTouchPoints > 1 && /Macintosh/.test(navigator.userAgent));
let invitationInstallation = null;
window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); invitationInstallation = e; });
window.addEventListener("appinstalled", () => {
  invitationInstallation = null;
  toast("Gérimo est installé ✅ : vous le retrouvez sur le bureau, dans le menu Démarrer et la barre des tâches si vous l'avez coché.", 8000);
});

async function raccourcisGerimo() {
  if (invitationInstallation) {
    toast("Dans la fenêtre qui s'ouvre, cochez « Épingler à la barre des tâches » et « Créer un raccourci sur le Bureau », puis « Installer ».", 9000);
    invitationInstallation.prompt();
    const choix = await invitationInstallation.userChoice.catch(() => null);
    if (choix && choix.outcome === "accepted") invitationInstallation = null;
    return;
  }
  const installe = window.matchMedia("(display-mode: standalone)").matches || window.matchMedia("(display-mode: window-controls-overlay)").matches;
  const etapes = [];
  if (installe) {
    etapes.push("<p>Gérimo est déjà ouvert comme une application.</p>",
      "<p><b>Barre des tâches :</b> en bas de l'écran, faites un <b>clic droit sur l'icône de Gérimo</b>, puis <b>« Épingler à la barre des tâches »</b>.</p>",
      "<p><b>Bureau :</b> ouvrez le menu Démarrer, cherchez « Gérimo », puis faites-le glisser sur le bureau.</p>");
  } else {
    etapes.push("<p><b>Avec le programme Gérimo des postes</b> (Gérimo Pro.exe, fourni avec le logiciel) : il crée tout seul le raccourci « Gérimo Pro » sur le bureau et dans le menu Démarrer. "
      + "Pour la barre des tâches : menu Démarrer → clic droit sur <b>Gérimo</b> → <b>« Épingler à la barre des tâches »</b>.</p>",
      "<p><b>Avec Microsoft Edge</b> : menu <b>⋯</b> (en haut à droite) → <b>Applications</b> → <b>Installer Gérimo</b>, puis cochez « Épingler à la barre des tâches » et « Créer un raccourci sur le Bureau ».</p>");
    if (!window.isSecureContext) {
      etapes.push(`<p class="petit">Ce choix n'apparaît dans Edge qu'en <b>connexion sécurisée</b> (adresse en https://) : voir la page <a href="/securiser" target="_blank" rel="noopener">Connexion sécurisée</a>. Le programme Gérimo.exe, lui, marche toujours.</p>`);
    }
  }
  el("raccourcisTexte").innerHTML = etapes.join("");
  ouvrirModal("modalRaccourcis");
}

// Hauteur réelle de la barre du haut (une ou deux lignes selon l'écran) : les onglets collés dessous s'y alignent.
// Posée sur <body> : l'application Android réécrit le style de <html> (marges des barres système).
if (window.ResizeObserver) {
  const barre = document.querySelector(".topbar");
  if (barre) new ResizeObserver(() => document.body.style.setProperty("--haut-barre", `${barre.offsetHeight}px`)).observe(barre);
}

// on attend que tous les scripts (biens.js…) soient chargés
// Application installable (téléphone, tablette) : service worker si le navigateur l'autorise
if ("serviceWorker" in navigator && window.isSecureContext) navigator.serviceWorker.register("/sw.js").catch(() => {});

document.addEventListener("DOMContentLoaded", () => {
  initialiserChampsDate();
  initialiserSaisie();     // contrôles et saisie intelligente (saisie.js)
  chargerVocabulaire();
  brancherRechercheGlobale();
  demarrer();
});

// Application Android : icônes de la barre d'état claires (blanches) quand le menu ou l'assistant,
// à fond sombre, couvre le haut de l'écran ; foncées sinon (en-tête blanc).
if (window.ISUPAndroid && window.ISUPAndroid.iconesClaires) {
  const panneaux = ["sideMenu", "panneauAssistant"].map(id => document.getElementById(id)).filter(Boolean);
  let claires = null;
  const majIcones = () => {
    const v = panneaux.some(p => p.classList.contains("show"));
    if (v !== claires) { claires = v; window.ISUPAndroid.iconesClaires(v); }
  };
  panneaux.forEach(p => new MutationObserver(majIcones).observe(p, { attributes: true, attributeFilter: ["class"] }));
  majIcones();
}

// Copie des données pour le travail hors réseau (hors_reseau.py), chiffrée par l'appareil : application Android
// (window.ISUPAndroid), ou navigateur en connexion sécurisée (window.GerimoPont, pont_web.js). Renouvelée toutes les
// 15 minutes tant que le serveur répond ; le téléphone Android la renouvelle aussi seul, application fermée.
if (PONT_HORS_RESEAU && PONT_HORS_RESEAU.garderCopie && !window.horsReseauPret) {
  const pont = PONT_HORS_RESEAU;
  if (pont.fermer) pont.fermer();  // en ligne : la copie ouverte hors réseau se referme
  // une clé pour cet appareil et cet utilisateur (téléphone Android : copie rafraîchie seul, application fermée)
  const autoriserTelephone = async () => {
    if (!pont.infosAppareil || typeof moi === "undefined" || !moi) return;
    const infos = JSON.parse(await pont.infosAppareil());
    if (infos.identifiant_cle === moi.identifiant) return;
    const r = await api("/api/hors-reseau/appareil", { method: "POST", body: { code_appareil: infos.code, nom: infos.nom } });
    await pont.garderCle(r.identifiant, r.jeton);
  };
  // navigateur : les écrans et la page « hors réseau » sont gardés par le navigateur (service worker, sw.js)
  const garderEcrans = async () => {
    if (!pont.web || !window.caches) return;
    const liste = await fetch("/api/hors-reseau/fichiers").then(r => r.json());
    const cache = await caches.open("isup-statique-v1");
    await Promise.all(liste.fichiers.map(f => cache.add(f.chemin).catch(() => {})));
  };
  const copieHorsReseau = async () => {
    try {
      await autoriserTelephone().catch(() => {});
      const rep = await fetch("/api/hors-reseau/copie");
      if (rep.ok) { await pont.garderCopie(await rep.text()); await garderEcrans().catch(() => {}); return; }
      const r = await rep.json().catch(() => ({}));
      if (rep.status === 403 && String(r.detail || "").includes("hors réseau")) await pont.effacerCopie();
    } catch { /* serveur momentanément injoignable : la copie précédente reste */ }
  };
  setTimeout(copieHorsReseau, 4000);
  setInterval(copieHorsReseau, 15 * 60 * 1000);
}
