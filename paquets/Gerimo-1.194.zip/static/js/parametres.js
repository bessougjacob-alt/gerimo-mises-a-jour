// Paramètres (Admin) : réseaux sociaux, e-mail, imprimeur, fonction de chaque utilisateur.

let parametresCache = null;

async function chargerParametres() {
  try { parametresCache = await api("/api/parametres"); }
  catch (e) { erreurFormulaire(el("formulaireParametres"), e.message); return; }
  document.querySelectorAll("#formulaireParametres [data-cle]").forEach(c => { c.value = parametresCache.valeurs[c.dataset.cle] ?? ""; });
  apercuRib();
  erreurFormulaire(el("formulaireParametres"), "");
  chargerAppareils();
  chargerAVerifier();
}

// Téléphones autorisés à travailler hors réseau (hors_reseau.py)
let appareilsCache = [];
async function chargerAppareils() {
  let appareils;
  try { appareils = appareilsCache = await api("/api/hors-reseau/appareils"); }
  catch (e) { el("parAppareils").innerHTML = `<p class="petit">${esc(e.message)}</p>`; return; }
  const quand = iso => iso ? `${formatDate(iso.slice(0, 10))} à ${iso.slice(11, 16)}` : "jamais";
  el("parAppareils").innerHTML = appareils.length ? appareils.map(a => `<div class="row">
      <div class="who"><b>${esc(a.nom)}</b> — ${esc(a.utilisateur)} (${esc(a.role)})
        <div class="petit">Copie à jour le ${quand(a.derniere_copie_le)}</div></div>
      <div class="boutons">${a.retire ? '<span class="pill danger">Retiré</span>'
        : `<button type="button" class="btn-sm del" onclick="retirerAppareil(${a.id})">Retirer</button>`}</div>
    </div>`).join("") : `<p class="petit">Aucun téléphone pour l'instant.</p>`;
}

// Enregistrements faits hors réseau que le serveur a refusés
async function chargerAVerifier() {
  let liste;
  try { liste = await api("/api/hors-reseau/a-verifier"); }
  catch (e) { el("parAVerifier").innerHTML = `<p class="petit">${esc(e.message)}</p>`; return; }
  const quand = iso => `${formatDate(iso.slice(0, 10))} à ${iso.slice(11, 16)}`;
  el("parAVerifier").innerHTML = liste.length ? liste.map(o => `<div class="row">
      <div class="who"><b>${esc(o.resume)}</b>
        <div class="petit">${esc(o.utilisateur)}${o.appareil ? ` · ${esc(o.appareil)}` : ""} · saisi le ${quand(o.saisi_le)}</div>
        <div class="petit" style="color:var(--danger)">${esc(o.detail || "")}</div></div>
      <div class="boutons"><button type="button" class="btn-sm" onclick="traiterAVerifier(${o.id}, 'reessayer')">Réessayer</button>
        <button type="button" class="btn-sm del" onclick="traiterAVerifier(${o.id}, 'abandonner')">Abandonner</button></div>
    </div>`).join("") : `<p class="petit">Rien à vérifier ✅</p>`;
}

async function traiterAVerifier(id, action) {
  if (action === "abandonner" && !confirm("Abandonner cet enregistrement ? Il ne sera pas ajouté à Gérimo (il reste noté au journal).")) return;
  try {
    const o = await api(`/api/hors-reseau/a-verifier/${id}/${action}`, { method: "POST" });
    toast(o.statut === "Envoyée" ? "Enregistré dans Gérimo ✅" : o.statut === "Abandonnée" ? "Abandonné" : `Toujours refusé : ${o.detail}`, 6000);
    chargerAVerifier();
  } catch (e) { toast(e.message); }
}

async function retirerAppareil(id) {
  const nom = (appareilsCache.find(a => a.id === id) || {}).nom || "";
  if (!confirm(`Retirer le téléphone « ${nom} » ? Sa copie des données sera effacée dès qu'il reviendra sur le réseau du bureau. `
    + "Il redeviendra autorisé si quelqu'un s'y reconnecte avec son mot de passe.")) return;
  try { await api(`/api/hors-reseau/appareils/${id}/retirer`, { method: "POST" }); toast("Téléphone retiré"); chargerAppareils(); }
  catch (e) { toast(e.message); }
}

// Coordonnées bancaires : aperçu du RIB tel qu'il sera imprimé (le serveur vérifie l'IBAN et la concordance)
const groupes4 = t => t.replace(/(.{4})/g, "$1 ").trim();
function apercuRib() {
  const v = id => el(id).value.replace(/[\s.\-]/g, "").toUpperCase();
  const rib = [v("parBanqueCode"), v("parBanqueGuichet"), v("parBanqueCompte"), v("parBanqueCle")];
  const iban = v("parBanqueIban");
  const lignes = [];
  if (el("parBanqueNom").value.trim() || el("parBanqueTitulaire").value.trim()) {
    lignes.push(`<b>${esc(el("parBanqueTitulaire").value.trim() || "Titulaire ?")}</b> — ${esc(el("parBanqueNom").value.trim() || "Banque ?")}`);
  }
  if (rib.some(Boolean)) lignes.push(`RIB : ${rib.map(p => esc(p || "…")).join(" ")}`);
  if (iban) lignes.push(`IBAN : ${esc(groupes4(iban))}`);
  if (v("parBanqueBic")) lignes.push(`BIC : ${esc(v("parBanqueBic"))}`);
  el("parRibApercu").innerHTML = lignes.length ? `Aperçu : <br>${lignes.join("<br>")}` : "Aucune coordonnée bancaire enregistrée.";
}
["parBanqueNom", "parBanqueTitulaire", "parBanqueCode", "parBanqueGuichet", "parBanqueCompte", "parBanqueCle",
 "parBanqueIban", "parBanqueBic"].forEach(id => el(id).addEventListener("input", apercuRib));
// (chargé par l'onglet « Réglages » : voir utilisateurs.js)

el("formulaireParametres").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    const valeurs = {};
    document.querySelectorAll("#formulaireParametres [data-cle]").forEach(c => { valeurs[c.dataset.cle] = c.value; });
    await api("/api/parametres", { method: "PUT", body: { valeurs } });
    await parametresPublics(true);
    moi.entreprise = el("entNom").value.trim() || moi.entreprise;
    afficherNomEntreprise(moi.entreprise);
    toast("Paramètres enregistrés");
    chargerParametres();
  });
});

// Logo de l'entreprise (PNG ou JPEG, 2 Mo au plus) : en-tête des documents, haut de l'écran, page de connexion
function choisirLogo() { el("entLogoFichier").click(); }
el("entLogoFichier").addEventListener("change", async () => {
  const fichier = el("entLogoFichier").files[0];
  el("entLogoFichier").value = "";
  if (!fichier) return;
  try {
    const rep = await fetch("/api/entreprise/logo", { method: "POST", body: fichier });
    const r = await rep.json().catch(() => ({}));
    if (!rep.ok) throw new Error(r.detail || "Logo refusé.");
    rafraichirLogos();
    toast("Logo enregistré : il apparaît sur les prochains documents");
  } catch (e) { toast(e.message, 6000); }
});
async function logoParDefaut() {
  try { await api("/api/entreprise/logo/supprimer", { method: "POST" }); rafraichirLogos(); toast("Logo d'origine remis"); }
  catch (e) { toast(e.message); }
}
function rafraichirLogos() {
  const v = Date.now();
  el("entLogo").src = `/entreprise/logo?v=${v}`;
  document.querySelectorAll(".logo").forEach(x => { x.style.backgroundImage = `url("/entreprise/logo?v=${v}")`; });
}

async function testerEmail() {
  const adresse = el("parTest").value.trim();
  if (!adresse) { toast("Indiquez l'adresse qui doit recevoir le test."); return; }
  toast("Envoi du test…", 8000);
  try {
    await api("/api/parametres/test-email", { method: "POST", body: { destinataire: adresse } });
    toast(`E-mail de test envoyé à ${adresse} ✅ (enregistrez d'abord les paramètres s'ils ont changé)`, 6000);
  } catch (e) { toast(e.message, 8000); }
}
