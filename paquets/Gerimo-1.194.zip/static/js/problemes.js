// « Déclarer un problème » sur un bien (icône triangle devant chaque bien et logement),
// et écran « Problèmes signalés » (Ouvert → En cours → Résolu).

let signalementsCache = [];
let optionsSignalement = null;
let photoSignalementEnCours = null;
const CLASSE_URGENCE = { "Urgente": "danger", "Normale": "warn", "Faible": "info" };
const CLASSE_STATUT_PB = { "Ouvert": "danger", "En cours": "warn", "Résolu": "ok" };

function ouvrirModal(id) { el(id).classList.add("show"); }
function fermerModal(id) { el(id).classList.remove("show"); }

async function chargerSignalementsCache() {
  try { signalementsCache = await api("/api/signalements"); } catch { signalementsCache = []; }
  return signalementsCache;
}
function problemesOuverts(citeId) {
  return signalementsCache.filter(s => s.cite_id === citeId && s.statut !== "Résolu").length;
}

async function declarerProbleme(citeId = null, logementId = null) {
  try {
    optionsSignalement = optionsSignalement || await api("/api/signalements/options");
    if (!citesCache.length) citesCache = await api("/api/biens");
  } catch (e) { toast(e.message); return; }
  remplirSelect(el("sigBien"), citesCache, { valeur: c => c.id, texte: c => c.nom, vide: "— Choisir le bien —" });
  remplirSelect(el("sigCategorie"), optionsSignalement.categories);
  remplirSelect(el("sigUrgence"), optionsSignalement.urgences);
  el("sigUrgence").value = "Normale";
  el("sigBien").value = citeId ?? "";
  majLogementsSignalement(logementId);
  el("sigDescription").value = "";
  el("sigPar").value = "";
  photoSignalementEnCours = null;
  el("sigPhoto").innerHTML = "";
  reinitialiserSaisie(el("formSignalement"));
  erreurFormulaire(el("formSignalement"), "");
  ouvrirModal("modalSignalement");
  el("sigDescription").focus();
}

function majLogementsSignalement(logementId = null) {
  const cite = citesCache.find(c => String(c.id) === el("sigBien").value);
  remplirSelect(el("sigLogement"), cite ? cite.logements : [], {
    valeur: l => l.id, texte: l => `Logement ${l.numero_logement} — ${l.type_logement}`, vide: "Tout le bien / parties communes",
  });
  el("sigLogement").value = logementId ?? "";
}
el("sigBien").addEventListener("change", () => majLogementsSignalement());

async function photoSignalement(source) {
  const f = source === "photo" ? await prendrePhoto() : (await choisirFichiers({ multiple: false, pdf: false }))[0];
  if (!f) return;
  photoSignalementEnCours = f;
  el("sigPhoto").innerHTML = `<div class="pj"><img src="${f.apercu}" alt=""><div class="pj-nom">Photo jointe</div></div>`;
}

el("formSignalement").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (!el("sigBien").value) throw new Error("Choisissez le bien concerné.");
    if (el("sigDescription").value.trim().length < 3) throw new Error("Décrivez le problème en quelques mots.");
    await api("/api/signalements", { method: "POST", body: {
      cite_id: Number(el("sigBien").value), logement_id: el("sigLogement").value ? Number(el("sigLogement").value) : null,
      categorie: el("sigCategorie").value, urgence: el("sigUrgence").value, description: el("sigDescription").value,
      signale_par: el("sigPar").value, photo: photoSignalementEnCours?.contenu || null,
    } });
    fermerModal("modalSignalement");
    toast("Problème déclaré : il apparaît dans « Problèmes signalés » et l'assistant vous le rappellera.", 5000);
    await chargerSignalementsCache();
    const actif = document.querySelector(".screen.active");
    if (actif && CHARGEURS[actif.id]) CHARGEURS[actif.id]();
  });
});

async function chargerProblemes() {
  const zone = el("listeProblemes");
  await chargerSignalementsCache();
  const filtre = el("filtreProblemes").value;
  const liste = signalementsCache.filter(s => filtre === "tous" || (filtre === "ouverts" ? s.statut !== "Résolu" : s.statut === filtre));
  if (!liste.length) {
    zone.innerHTML = `<div class="card vide">${filtre === "ouverts" ? "Aucun problème en cours. 👍" : "Aucun problème."}</div>`;
    return;
  }
  zone.innerHTML = `<div class="card">${liste.map(s => `
    <div class="row">
      <span class="who"><b>${esc(s.categorie)}</b> — ${esc(s.cite)}${s.logement ? ", logement " + esc(s.logement) : ""}
        <br><span class="petit">${esc(s.description)}</span>
        <br><span class="petit">Signalé le ${esc(s.date)}${s.signale_par ? " par " + esc(s.signale_par) : ""} — saisi par ${esc(s.auteur)}
        ${s.resolution ? " — Résolution : " + esc(s.resolution) : ""}${s.resolu_le ? " (" + esc(s.resolu_le) + ")" : ""}</span></span>
      <span class="boutons">
        <span class="pill ${CLASSE_URGENCE[s.urgence]}">${esc(s.urgence)}</span>
        <span class="pill ${CLASSE_STATUT_PB[s.statut]}">${esc(s.statut)}</span>
        ${s.photo ? ibtn("voir", "Voir la photo", `visionneuse('${s.photo}', 'Photo du problème')`) : ""}
        ${s.statut === "Ouvert" ? ibtn("outil", "Marquer « En cours » (intervention lancée)", `statutProbleme(${s.id}, 'En cours')`, { classe: "alerte" }) : ""}
        ${s.statut !== "Résolu" ? ibtn("coche", "Marquer comme résolu", `statutProbleme(${s.id}, 'Résolu')`, { classe: "modif" }) : ""}
        ${s.statut !== "Résolu" && peut("depenses") ? ibtn("recu", "Enregistrer la dépense de réparation", `depenseProbleme(${s.id})`) : ""}
      </span>
    </div>`).join("")}</div>`;
  el("rechercheProblemes").dispatchEvent(new Event("input"));
}
CHARGEURS.problemes = chargerProblemes;
el("filtreProblemes").addEventListener("change", chargerProblemes);
brancherRecherche(el("rechercheProblemes"), el("listeProblemes"));

async function statutProbleme(id, statut) {
  let resolution = "";
  if (statut === "Résolu") {
    resolution = prompt("Comment le problème a-t-il été résolu ? (facultatif)\nex : plombier passé, joint changé") ?? null;
    if (resolution === null) return;
  }
  try {
    await api(`/api/signalements/${id}/statut`, { method: "POST", body: { statut, resolution } });
    toast(statut === "Résolu" ? "Problème résolu ✅" : "Intervention en cours");
    chargerProblemes();
  } catch (e) { toast(e.message); }
}

// La réparation coûte : on ouvre le formulaire de dépense pré-rempli
async function depenseProbleme(id) {
  const s = signalementsCache.find(x => x.id === id);
  if (!s) return;
  await afficher("depenses");
  await nouvelleDepense();
  el("depBien").value = s.cite_id;
  el("depBien").dispatchEvent(new Event("change"));
  setTimeout(() => {
    if (s.logement_id) el("depLogement").value = s.logement_id;
    el("depMotif").value = `${s.categorie} — ${s.description}`.slice(0, 200);
  }, 150);
}
