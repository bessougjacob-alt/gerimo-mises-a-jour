// Service worker Gérimo : met en cache l'habillage (styles, polices, scripts, images) pour un démarrage rapide.
// Les données (/api) viennent toujours du serveur : jamais de données périmées.
// Hors réseau (navigateur en connexion sécurisée, voir hors_reseau.py et pont_web.js) : si le serveur ne répond pas,
// l'adresse de Gérimo ouvre la page « Continuer hors réseau », puis les écrans gardés par le navigateur
// (/api/hors-reseau/app, mis en cache par app.js à chaque copie).
const CACHE = "isup-statique-v1";
const PAGE_HORS_RESEAU = "/static/hors_reseau/index.html";
self.addEventListener("install", e => self.skipWaiting());
self.addEventListener("activate", e => e.waitUntil(
  caches.keys().then(cles => Promise.all(cles.filter(c => c !== CACHE).map(c => caches.delete(c)))).then(() => self.clients.claim())));

// réseau d'abord (toujours la dernière version), cache si le serveur ne répond pas
function reseauPuisCache(requete, secours) {
  return fetch(requete).then(rep => {
    if (rep.ok) {
      const copie = rep.clone();
      caches.open(CACHE).then(c => c.put(requete, copie));
    }
    return rep;
  }).catch(() => caches.match(requete).then(r => r || (secours ? caches.match(secours) : undefined))
    .then(r => r || new Response("Hors réseau", { status: 503 })));
}

self.addEventListener("fetch", e => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== location.origin) return;
  if (e.request.mode === "navigate" && ["/", "/app", "/connexion"].includes(url.pathname)) {
    // page normale du serveur ; s'il ne répond pas : « Continuer hors réseau »
    e.respondWith(fetch(e.request).catch(() => caches.match(PAGE_HORS_RESEAU)
      .then(r => r || new Response("Gérimo : serveur injoignable.", { status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" } }))));
    return;
  }
  if (url.pathname === "/api/hors-reseau/app") { e.respondWith(reseauPuisCache(e.request)); return; }
  if (!url.pathname.startsWith("/static/") && url.pathname !== "/entreprise/logo") return;
  e.respondWith(reseauPuisCache(e.request));
});
