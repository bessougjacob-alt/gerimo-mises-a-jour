"""Journal « qui a fait quoi » et corbeille (Admin).

Le journal est rempli par la base elle-même (migration 019) : chaque ajout, modification ou suppression,
avec l'utilisateur, la date et les valeurs avant / après. Il ne peut être ni modifié ni effacé.

Corbeille : chaque suppression (une action = une transaction, avec tout ce qui est parti avec elle)
peut être restaurée par l'Admin, mot de passe redemandé. Les lignes reviennent avec leurs numéros
d'origine ; les modifications faites par la même action (ex. statut du logement) sont annulées si
personne n'y a touché depuis ; les fichiers sortent de documents/.corbeille.
"""
import json
from datetime import date, datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.orm import Session as SessionDB

import fichiers
from models import Utilisateur
from securite import confirmer_mot_de_passe_admin, exiger_admin, get_db

router = APIRouter(prefix="/api")

# Nom affiché de chaque table, et comment décrire une ligne en quelques mots
TABLES = {
    "utilisateurs": ("Compte utilisateur", lambda l: l.get("nom_complet")),
    "gestionnaires_cites": ("Bien confié à un gestionnaire", lambda l: None),
    "proprietaires": ("Propriétaire", lambda l: l.get("nom_complet")),
    "cites": ("Bien", lambda l: l.get("nom")),
    "gestionnaires": ("Société de gestion", lambda l: l.get("nom")),
    "contrats_gestion": ("Commission de gestion", lambda l: f"{l.get('pourcentage_commission')} %"),
    "logements": ("Logement", lambda l: f"n° {l.get('numero_logement')}"),
    "parcelles": ("Parcelle", lambda l: f"n° {l.get('numero_parcelle')}"),
    "locataires": ("Locataire", lambda l: l.get("nom_complet")),
    "contrats": ("Contrat", lambda l: l.get("numero_contrat")),
    "paiements": ("Paiement", lambda l: l.get("numero_recu") or _fcfa(l.get("montant"))),
    "encaissements": ("Encaissement", lambda l: _fcfa(l.get("montant_encaisse"))),
    "documents": ("Document", lambda l: l.get("nom_fichier") or l.get("type_document")),
    "depenses": ("Dépense", lambda l: f"{l.get('motif')} ({_fcfa(l.get('montant'))})"),
    "achats_ventes": ("Achat / vente", lambda l: l.get("numero") or l.get("designation")),
    "pieces_jointes": ("Pièce jointe", lambda l: l.get("nom_fichier")),
    "etats_des_lieux": ("État des lieux", lambda l: l.get("numero")),
    "edl_photos": ("Photo d'état des lieux", lambda l: l.get("legende") or l.get("piece")),
    "prospects": ("Demande de client", lambda l: l.get("nom_complet")),
    "prospects_suivi": ("Suivi d'une demande", lambda l: _court(l.get("note"))),
    "agenda": ("Agenda", lambda l: l.get("titre")),
    "courriers": ("Courrier", lambda l: l.get("numero")),
    "signalements": ("Problème signalé", lambda l: l.get("categorie")),
    "parametres": ("Paramètre", lambda l: l.get("cle")),
    "publications": ("Publication", lambda l: l.get("titre")),
    "comptes_tresorerie": ("Compte de trésorerie", lambda l: l.get("nom")),
    "transferts_tresorerie": ("Transfert entre comptes", lambda l: f"{l.get('numero')} ({_fcfa(l.get('montant'))})"),
    "beneficiaires": ("RIB du carnet", lambda l: l.get("nom")),
    "appareils_hors_reseau": ("Téléphone autorisé hors réseau", lambda l: l.get("nom")),
    "operations_hors_reseau": ("Enregistrement", lambda l: " — ".join(filter(None, [
        l.get("resume"), f"saisi le {l.get('saisi_le', '')}" if l.get("saisi_le") else "",
        f"sur {l['appareil']}" if l.get("appareil") else "", l.get("statut"), l.get("detail")]))),
    "reversements": ("Reversement", lambda l: f"{l.get('numero')} ({_fcfa(l.get('montant'))})"),
    "arretes_caisse": ("Arrêté de caisse", lambda l: f"{l.get('date_arrete')} ({_fcfa(l.get('solde_compte'))})"),
}
OPERATIONS = {"INSERT": "Ajout", "UPDATE": "Modification", "DELETE": "Suppression",
              "CONNEXION": "Connexion", "ECHEC": "Connexion refusée", "HORSRESEAU": "Saisie hors réseau",
              "MDP_REDONNE": "Mot de passe redonné", "MDP_CHANGE": "Mot de passe changé"}
# Ordre d'affichage : l'élément « principal » d'une suppression est le premier trouvé dans cette liste
PRINCIPALES = ["proprietaires", "cites", "locataires", "contrats", "achats_ventes", "etats_des_lieux", "courriers",
               "depenses", "parcelles", "logements", "utilisateurs", "prospects", "agenda", "signalements",
               "pieces_jointes", "edl_photos", "publications", "paiements", "documents",
               "reversements", "transferts_tresorerie", "arretes_caisse", "comptes_tresorerie", "beneficiaires"]
NON_AFFICHES = {"id", "cree_le", "modifie_le", "mois_impayes_consecutifs"}
MASQUES = {"mot_de_passe": "(mot de passe changé)", "jeton_hache": "(nouvelle clé)", "signature_locataire": "(signature)",
           "signature_agent": "(signature)", "pieces": "(détail des pièces)", "compteurs": "(compteurs)"}
COLONNES_FICHIERS = ("chemin_fichier", "chemin_pdf", "photo_chemin")
LIBELLES = {
    "nom_complet": "Nom", "cni": "CNI", "telephone": "Téléphone", "email": "E-mail", "ville": "Ville",
    "nom": "Nom", "adresse": "Adresse", "proprietaire_id": "Propriétaire", "cite_id": "Bien",
    "numero_logement": "Numéro de logement", "type_logement": "Type de logement", "type_batiment": "Type de bien",
    "loyer": "Loyer", "statut_logement": "Statut du logement", "logement_id": "Logement",
    "locataire_id": "Locataire", "contrat_id": "Contrat", "type_contrat": "Type de contrat",
    "usage_bien": "Usage du bien", "statut_contrat": "Statut du contrat", "terme_loyer": "Loyer payé en",
    "montant_loyer": "Loyer", "mois_caution": "Mois de caution", "montant_caution": "Caution",
    "mois_avance": "Mois d'avance", "montant_avance": "Avance", "date_debut": "Début", "date_fin": "Fin",
    "date_resiliation": "Date de résiliation", "motif_resiliation": "Motif de résiliation",
    "montant": "Montant", "date_paiement": "Date du paiement", "statut_paiement": "Statut du paiement",
    "mode_paiement": "Mode de paiement", "motif_paiement": "Motif", "numero_recu": "N° de reçu",
    "date_annulation": "Annulé le", "motif_annulation": "Motif d'annulation", "motif": "Motif",
    "categorie": "Catégorie", "a_la_charge_de": "À la charge de", "date_depense": "Date",
    "pourcentage_commission": "Commission (%)", "role": "Profil", "actif": "Compte actif",
    "fonction": "Fonction", "identifiant": "Identifiant", "valeur": "Valeur", "statut": "Statut",
    "superficie": "Superficie", "prix_entree": "Prix d'entrée", "dernier_prix": "Dernier prix",
    "disponible": "Disponible", "approbation": "Approbation", "titre": "Titre", "notes": "Notes",
    "date_evenement": "Date", "heure": "Heure", "fait": "Fait", "observation": "Observation",
    "observations": "Observations", "designation": "Désignation", "partie_nom": "Acheteur / vendeur",
}


def _fcfa(valeur) -> str:
    try:
        return f"{float(valeur):,.0f} F CFA".replace(",", " ")
    except (TypeError, ValueError):
        return ""


def _court(texte, n: int = 60) -> str:
    texte = str(texte or "")
    return texte if len(texte) <= n else texte[: n - 1] + "…"


def _valeur(champ: str, valeur) -> str:
    if valeur is None or valeur == "":
        return "—"
    if isinstance(valeur, bool):
        return "oui" if valeur else "non"
    if isinstance(valeur, str) and len(valeur) >= 10 and valeur[4] == "-" and valeur[7] == "-":
        try:  # 2026-10-05 ou 2026-10-05T09:30:00 → jj/mm/aaaa
            return datetime.fromisoformat(valeur).strftime("%d/%m/%Y" if len(valeur) == 10 else "%d/%m/%Y %H:%M")
        except ValueError:
            pass
    return _court(valeur, 80)


def description(table: str, ligne: dict | None) -> str:
    libelle, decrire = TABLES.get(table, (table, lambda l: None))
    try:
        detail = decrire(ligne or {})
    except Exception:  # noqa: BLE001
        detail = None
    return f"{libelle} {detail}" if detail else libelle


def changements(avant: dict | None, apres: dict | None) -> list[dict]:
    if not avant or not apres:
        return []
    resultat = []
    for champ in apres:
        if champ in NON_AFFICHES or avant.get(champ) == apres.get(champ):
            continue
        libelle = LIBELLES.get(champ, champ.replace("_", " ").capitalize())
        if champ in MASQUES:
            resultat.append({"champ": libelle, "avant": "", "apres": MASQUES[champ]})
        else:
            resultat.append({"champ": libelle, "avant": _valeur(champ, avant.get(champ)),
                             "apres": _valeur(champ, apres.get(champ))})
    return resultat


def _entree(l) -> dict:
    ligne = l.apres if l.operation != "DELETE" else l.avant
    if l.operation in ("CONNEXION", "ECHEC"):
        details = l.apres or {}
        quoi = (f"Profil {details.get('profil', '')}, identifiant « {details.get('identifiant', '')} »"
                + (f", {details['appareil']}" if details.get("appareil") else "")
                + (f", depuis {details['adresse']}" if details.get("adresse") else "")
                + (f" — {details['motif']}" if details.get("motif") else ""))
    elif l.operation in ("MDP_REDONNE", "MDP_CHANGE"):
        quoi = (l.apres or {}).get("texte", "")
    else:
        quoi = description(l.table_nom, ligne)
    return {"id": l.id, "quand": l.quand.strftime("%d/%m/%Y %H:%M:%S"), "qui": l.utilisateur_nom or "Le logiciel",
            "operation": OPERATIONS.get(l.operation, l.operation), "code": l.operation, "quoi": quoi,
            "changements": changements(l.avant, l.apres) if l.operation == "UPDATE" else []}


# ---------- Journal ----------

@router.get("/journal")
def lire_journal(debut: date | None = None, fin: date | None = None, operation: str = "", qui: str = "",
                 page: int = Query(1, ge=1), admin: Utilisateur = Depends(exiger_admin),
                 db: SessionDB = Depends(get_db)):
    conditions, valeurs = ["1=1"], {}
    if debut:
        conditions.append("quand >= :debut")
        valeurs["debut"] = debut
    if fin:
        conditions.append("quand < CAST(:fin AS DATE) + 1")
        valeurs["fin"] = fin
    if operation in OPERATIONS:
        conditions.append("operation = :op")
        valeurs["op"] = operation
    if qui:
        conditions.append("utilisateur_nom ILIKE :qui")
        valeurs["qui"] = f"%{qui[:80]}%"
    par_page = 100
    lignes = db.execute(text(f"SELECT * FROM journal WHERE {' AND '.join(conditions)} "
                             f"ORDER BY id DESC LIMIT {par_page + 1} OFFSET {(page - 1) * par_page}"), valeurs).all()
    utilisateurs = [n for (n,) in db.execute(text("SELECT DISTINCT utilisateur_nom FROM journal "
                                                  "WHERE utilisateur_nom IS NOT NULL ORDER BY 1"))]
    return {"entrees": [_entree(l) for l in lignes[:par_page]], "suite": len(lignes) > par_page,
            "page": page, "utilisateurs": utilisateurs}


# ---------- Corbeille ----------

@router.get("/corbeille")
def lire_corbeille(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    lignes = db.execute(text(
        "SELECT j.* FROM journal j WHERE j.operation = 'DELETE' AND j.transaction_id IN ("
        "  SELECT transaction_id FROM journal WHERE operation = 'DELETE' "
        "  AND transaction_id NOT IN (SELECT transaction_id FROM corbeille_restaurations) "
        "  GROUP BY transaction_id ORDER BY MAX(id) DESC LIMIT 200) ORDER BY j.id")).all()
    groupes: dict[int, list] = {}
    for l in lignes:
        groupes.setdefault(l.transaction_id, []).append(l)
    resultat = []
    for tx, liste in groupes.items():
        def rang(l):
            return PRINCIPALES.index(l.table_nom) if l.table_nom in PRINCIPALES else len(PRINCIPALES)
        principale = min(liste, key=rang)
        autres = [description(l.table_nom, l.avant) for l in liste if l is not principale]
        resultat.append({"transaction": tx, "quand": liste[-1].quand.strftime("%d/%m/%Y %H:%M"),
                         "qui": liste[-1].utilisateur_nom or "Le logiciel",
                         "quoi": description(principale.table_nom, principale.avant),
                         "avec": autres[:8], "nb_avec": len(autres), "_tri": liste[-1].id})
    resultat.sort(key=lambda r: r.pop("_tri"), reverse=True)
    return {"elements": resultat}


class RestaurationIn(BaseModel):
    mot_de_passe_admin: str


def _identifiant(table: str, ligne: dict) -> tuple[str, dict]:
    """Condition SQL qui retrouve la ligne (id, ou clé pour les paramètres, ou couple pour les liaisons)."""
    if "id" in ligne:
        return "id = :id_ligne", {"id_ligne": ligne["id"]}
    if table == "parametres":
        return "cle = :id_ligne", {"id_ligne": ligne["cle"]}
    return ("utilisateur_id = :u AND cite_id = :c", {"u": ligne.get("utilisateur_id"), "c": ligne.get("cite_id")})


def annuler_modifications(db: SessionDB, modifications: list) -> None:
    """Remet chaque ligne modifiée dans son état d'avant, sauf si quelqu'un l'a retouchée depuis."""
    ignores = {"modifie_le", "mois_impayes_consecutifs"}
    for l in reversed(modifications):
        if l.table_nom not in TABLES:
            continue
        condition, valeurs = _identifiant(l.table_nom, l.avant)
        actuelle = db.execute(text(f'SELECT to_jsonb(t) AS ligne FROM "{l.table_nom}" t WHERE {condition}'),
                              valeurs).scalar()
        if actuelle is None or {k: v for k, v in actuelle.items() if k not in ignores} != \
                {k: v for k, v in (l.apres or {}).items() if k not in ignores}:
            continue
        colonnes = ", ".join(f'"{c}"' for c in l.avant if c != "id")
        anciennes = ", ".join(f'r."{c}"' for c in l.avant if c != "id")
        db.execute(text(f'UPDATE "{l.table_nom}" t SET ({colonnes}) = (SELECT {anciennes} FROM '
                        f'jsonb_populate_record(NULL::"{l.table_nom}", CAST(:ligne AS JSONB)) r) WHERE {condition}'),
                   {"ligne": json.dumps(l.avant), **valeurs})


@router.post("/corbeille/{transaction_id}/restaurer")
def restaurer(transaction_id: int, donnees: RestaurationIn, admin: Utilisateur = Depends(exiger_admin),
              db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    if db.execute(text("SELECT 1 FROM corbeille_restaurations WHERE transaction_id = :t"),
                  {"t": transaction_id}).first():
        raise HTTPException(status_code=409, detail="Cet élément a déjà été restauré.")
    lignes = db.execute(text("SELECT * FROM journal WHERE transaction_id = :t AND operation IN ('DELETE', 'UPDATE') "
                             "ORDER BY id"), {"t": transaction_id}).all()
    suppressions = [l for l in lignes if l.operation == "DELETE"]
    if not suppressions:
        raise HTTPException(status_code=404, detail="Élément introuvable dans la corbeille.")
    if any(l.table_nom not in TABLES for l in suppressions):
        raise HTTPException(status_code=400, detail="Cet élément ne peut pas être restauré.")

    # 1. Remettre les lignes supprimées : parents d'abord (on réessaie tant que ça avance)
    a_remettre = list(suppressions)
    while a_remettre:
        restantes, derniere_erreur = [], ""
        for l in a_remettre:
            point = db.begin_nested()
            try:
                db.execute(text(f'INSERT INTO "{l.table_nom}" SELECT * FROM '
                                f'jsonb_populate_record(NULL::"{l.table_nom}", CAST(:ligne AS JSONB))'),
                           {"ligne": json.dumps(l.avant)})
                point.commit()
            except DBAPIError as e:
                point.rollback()
                restantes.append(l)
                derniere_erreur = str(e.orig).split("\n")[0]
        if len(restantes) == len(a_remettre):
            db.rollback()
            if "duplicate key" in derniere_erreur or "unique" in derniere_erreur.lower():
                raise HTTPException(status_code=409, detail="Restauration impossible : un élément identique "
                                    "(même numéro ou même nom) a été recréé depuis. Rien n'a été modifié.")
            raise HTTPException(status_code=409, detail="Restauration impossible : un élément dont il dépend "
                                "n'existe plus (restaurez-le d'abord). Rien n'a été modifié.")
        a_remettre = restantes

    # 2. Annuler les modifications faites par la même action, si personne n'y a touché depuis
    annuler_modifications(db, [l for l in lignes if l.operation == "UPDATE"])

    db.execute(text("INSERT INTO corbeille_restaurations (transaction_id, restaure_par) VALUES (:t, :u)"),
               {"t": transaction_id, "u": admin.id})
    db.commit()

    # 3. Les fichiers reviennent de documents/.corbeille
    for l in suppressions:
        for colonne in COLONNES_FICHIERS:
            fichiers.sortir_de_la_corbeille((l.avant or {}).get(colonne))
    principale = min(suppressions, key=lambda l: PRINCIPALES.index(l.table_nom)
                     if l.table_nom in PRINCIPALES else len(PRINCIPALES))
    return {"ok": True, "quoi": description(principale.table_nom, principale.avant), "nb": len(suppressions)}
