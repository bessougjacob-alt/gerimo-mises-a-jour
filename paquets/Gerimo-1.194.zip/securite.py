"""Sécurité : mots de passe, sessions de connexion et droits par rôle.

Tous les contrôles d'accès se font ici, côté serveur. L'interface ne fait
que masquer ce que le serveur refuserait de toute façon.
"""
import hashlib
import secrets
import time
from datetime import datetime, timedelta

import bcrypt
from fastapi import Depends, HTTPException, Request
from sqlalchemy import event, text
from sqlalchemy.orm import Session as SessionDB

from database import SessionLocal
from models import Session, Utilisateur

# ---------- Mots de passe ----------

# bcrypt ne prend en compte que les 72 premiers octets d'un mot de passe
LONGUEUR_MAX_OCTETS = 72


def hacher_mot_de_passe(mot_de_passe: str) -> str:
    octets = mot_de_passe.encode("utf-8")
    if len(octets) > LONGUEUR_MAX_OCTETS:
        raise ValueError("Mot de passe trop long (72 caractères maximum).")
    return bcrypt.hashpw(octets, bcrypt.gensalt()).decode("utf-8")


def verifier_mot_de_passe(mot_de_passe: str, hache: str) -> bool:
    octets = mot_de_passe.encode("utf-8")
    if len(octets) > LONGUEUR_MAX_OCTETS:
        return False
    try:
        return bcrypt.checkpw(octets, hache.encode("utf-8"))
    except ValueError:
        # hachage en base invalide ou illisible
        return False


# Hachage factice : on vérifie quand même un mot de passe quand l'identifiant
# n'existe pas, pour que le temps de réponse ne trahisse pas les comptes existants.
_HACHE_FACTICE = hacher_mot_de_passe("isup-compte-inexistant")


def verifier_identifiants(db: SessionDB, identifiant: str, mot_de_passe: str, role: str):
    """Renvoie l'utilisateur si tout est correct, sinon None (sans dire pourquoi)."""
    utilisateur = db.query(Utilisateur).filter_by(identifiant=identifiant).first()
    if utilisateur is None:
        verifier_mot_de_passe(mot_de_passe, _HACHE_FACTICE)
        return None
    if not verifier_mot_de_passe(mot_de_passe, utilisateur.mot_de_passe):
        return None
    if not utilisateur.actif or utilisateur.role.value != role:
        return None
    return utilisateur


# ---------- Limitation des essais (anti-devinette de mot de passe) ----------

# Par compte : 5 erreurs → 5 minutes d'attente, puis l'attente double à chaque nouvelle erreur (10, 20, 40 min,
# 1 h au plus) ; les erreurs s'oublient après 24 h ou à la bonne connexion. Par appareil (adresse) : 20 erreurs en
# 15 minutes, tous comptes confondus → l'appareil attend 15 minutes (quelqu'un essaie les comptes un par un).
ESSAIS_MAX = 5
DUREE_BLOCAGE = 5 * 60  # secondes
BLOCAGE_MAX = 60 * 60
MEMOIRE_ECHECS = 24 * 3600
ESSAIS_MAX_ADRESSE = 20
FENETRE_ADRESSE = 15 * 60
_echecs: dict[str, list[float]] = {}
_echecs_adresse: dict[str, list[float]] = {}


def attente_restante(identifiant: str, adresse: str = "", maintenant: float | None = None) -> int:
    """Secondes à attendre avant un nouvel essai (0 : essai permis)."""
    maintenant = time.time() if maintenant is None else maintenant
    cle = identifiant.lower()
    recents = [t for t in _echecs.get(cle, []) if maintenant - t < MEMOIRE_ECHECS]
    _echecs[cle] = recents
    attente = 0.0
    if len(recents) >= ESSAIS_MAX:
        duree = min(DUREE_BLOCAGE * 2 ** (len(recents) - ESSAIS_MAX), BLOCAGE_MAX)
        attente = recents[-1] + duree - maintenant
    if adresse:
        par_adresse = [t for t in _echecs_adresse.get(adresse, []) if maintenant - t < FENETRE_ADRESSE]
        _echecs_adresse[adresse] = par_adresse
        if len(par_adresse) >= ESSAIS_MAX_ADRESSE:
            attente = max(attente, par_adresse[-1] + FENETRE_ADRESSE - maintenant)
    return max(0, int(attente + 0.999))


def est_bloque(identifiant: str, adresse: str = "") -> bool:
    return attente_restante(identifiant, adresse) > 0


def message_blocage(secondes: int) -> str:
    minutes = max(1, (secondes + 59) // 60)
    return f"Trop d'essais incorrects. Réessayez dans {minutes} minute{'s' if minutes > 1 else ''}."


def noter_echec(identifiant: str, adresse: str = "") -> None:
    _echecs.setdefault(identifiant.lower(), []).append(time.time())
    if adresse:
        _echecs_adresse.setdefault(adresse, []).append(time.time())


def effacer_echecs(identifiant: str) -> None:
    _echecs.pop(identifiant.lower(), None)


# ---------- Sessions ----------

NOM_COOKIE = "isup_session"
DUREE_SESSION = timedelta(hours=10)  # une journée de travail


def _hacher_jeton(jeton: str) -> str:
    return hashlib.sha256(jeton.encode("utf-8")).hexdigest()


def ouvrir_session(db: SessionDB, utilisateur: Utilisateur, veille_minutes: int = 0, appareil: str = "") -> str:
    """Crée une session en base et renvoie le jeton à placer dans le cookie.
    veille_minutes : mise en veille après ce temps sans activité (0 : jamais, téléphone déjà verrouillé)."""
    jeton = secrets.token_urlsafe(32)
    maintenant = datetime.now()
    # ménage : sessions expirées de tout le monde
    db.query(Session).filter(Session.expire_le < maintenant).delete()
    db.add(Session(
        jeton_hache=_hacher_jeton(jeton),
        utilisateur_id=utilisateur.id,
        cree_le=maintenant,
        expire_le=maintenant + DUREE_SESSION,
        derniere_activite=maintenant,
        veille_minutes=max(0, veille_minutes),
        appareil=appareil[:40] or None,
    ))
    db.commit()
    return jeton


def fermer_session(db: SessionDB, jeton: str | None) -> None:
    if jeton:
        db.query(Session).filter_by(jeton_hache=_hacher_jeton(jeton)).delete()
        db.commit()


def session_de_la_requete(db: SessionDB, request: Request) -> Session | None:
    """La session du cookie, si elle est valable (même en veille)."""
    jeton = request.cookies.get(NOM_COOKIE)
    if not jeton:
        return None
    session = db.query(Session).filter_by(jeton_hache=_hacher_jeton(jeton)).first()
    if session is None or session.expire_le < datetime.now():
        return None
    # un compte désactivé par l'Admin perd l'accès immédiatement
    if not session.utilisateur.actif:
        return None
    return session


def utilisateur_de_la_requete(db: SessionDB, request: Request) -> Utilisateur | None:
    session = session_de_la_requete(db, request)
    if session is None:
        return None
    marquer_utilisateur(db, session.utilisateur)
    return session.utilisateur


# ---------- Mode veille (veille.py) ----------
# Une session en veille ne fait plus rien (423) tant que son utilisateur n'a pas retapé son mot de passe :
# recharger la page ou ouvrir un autre onglet ne permet pas de passer derrière l'écran de veille.

ACTIVITE_A_NOTER = timedelta(seconds=30)  # on n'écrit pas en base à chaque clic


def inactive_trop_longtemps(session: Session, maintenant: datetime | None = None) -> bool:
    if not session.veille_minutes or session.derniere_activite is None:
        return False
    return (maintenant or datetime.now()) - session.derniere_activite > timedelta(minutes=session.veille_minutes)


def refus_veille(session: Session) -> HTTPException:
    u = session.utilisateur
    return HTTPException(status_code=423, detail={
        "code": "veille", "message": "Gérimo est en veille : retapez votre mot de passe.",
        "nom": u.nom_complet, "identifiant": u.identifiant, "role": u.role.value})


def verifier_veille(db: SessionDB, session: Session) -> None:
    """Session en veille, ou inactive depuis trop longtemps (elle passe alors en veille) : refus 423."""
    if not session.veille and inactive_trop_longtemps(session):
        session.veille = True
        db.commit()
    if session.veille:
        raise refus_veille(session)


def noter_activite(db: SessionDB, session: Session) -> None:
    maintenant = datetime.now()
    if session.derniere_activite is None or maintenant - session.derniere_activite > ACTIVITE_A_NOTER:
        session.derniere_activite = maintenant
        db.commit()


# Seuls chemins permis tant que le mot de passe provisoire (donné par l'Admin) n'est pas remplacé
LIBRES_MDP_PROVISOIRE = ("/api/moi/mot-de-passe",)


def libelle_appareil(user_agent: str) -> str:
    """« téléphone Android », « iPhone », « PC Windows »… (journal, dernière connexion)."""
    ua = user_agent or ""
    for motif, libelle in (("iPhone", "iPhone"), ("iPad", "iPad"), ("Android", "téléphone Android"),
                           ("Windows", "PC Windows"), ("Macintosh", "Mac"), ("Linux", "PC Linux")):
        if motif in ua:
            return libelle
    return "navigateur"


# ---------- Journal des actions (migration 019) ----------
# La base note elle-même chaque ajout, modification et suppression ; le logiciel lui dit seulement
# QUI agit, au début de chaque transaction (réglage local : il disparaît à la fin de la transaction).

def _transmettre_utilisateur(connexion, qui: tuple[str, str]) -> None:
    connexion.execute(text("SELECT set_config('gerimo.utilisateur_id', :id, true), "
                           "set_config('gerimo.utilisateur_nom', :nom, true)"), {"id": qui[0], "nom": qui[1]})


def marquer_utilisateur(db: SessionDB, utilisateur: Utilisateur) -> None:
    db.info["journal_utilisateur"] = (str(utilisateur.id), utilisateur.nom_complet)
    _transmettre_utilisateur(db.connection(), db.info["journal_utilisateur"])


@event.listens_for(SessionDB, "after_begin")
def _apres_debut_transaction(session, transaction, connexion):
    qui = session.info.get("journal_utilisateur")
    if qui:
        _transmettre_utilisateur(connexion, qui)


def noter_evenement(db: SessionDB, operation: str, utilisateur: Utilisateur | None, details: dict) -> None:
    """Connexions réussies ou refusées : notées dans le journal (avec l'adresse du poste)."""
    import json
    db.execute(text("INSERT INTO journal (utilisateur_id, utilisateur_nom, operation, table_nom, ligne_id, apres) "
                    "VALUES (:uid, :nom, :op, 'utilisateurs', :lid, CAST(:details AS JSONB))"),
               {"uid": utilisateur.id if utilisateur else None,
                "nom": utilisateur.nom_complet if utilisateur else details.get("identifiant"),
                "op": operation, "lid": str(utilisateur.id) if utilisateur else None,
                "details": json.dumps(details, ensure_ascii=False)})
    db.commit()


# ---------- Droits par rôle ----------

# Modules accessibles pour chaque rôle (règles de CLAUDE.md)
MODULES_PAR_ROLE = {
    "Admin": {
        "accueil", "biens", "proprietaires", "locataires", "contrats", "paiements",
        "depenses", "achats_ventes", "rapports", "tresorerie", "comptabilite", "parametres", "utilisateurs",
        "etats_des_lieux", "courriers", "reseaux_sociaux", "agenda", "prospects", "sejours",
    },
    "Gestionnaire": {
        "accueil", "biens", "locataires", "contrats", "paiements", "depenses", "rapports",
        "etats_des_lieux", "courriers", "reseaux_sociaux", "agenda", "prospects", "sejours",
    },
    # La Caisse : tout ce qui touche à l'argent (encaissements, dépenses, achats/ventes, rapports),
    # et son agenda (décision de Boss du 03/10/2026)
    "Caisse": {"paiements", "depenses", "achats_ventes", "rapports", "tresorerie", "comptabilite", "agenda",
               "sejours"},  # séjours en courte durée : la Caisse encaisse acomptes et soldes
    # Le Comptable (précomptabilité, 06/10/2026) : trésorerie, dépenses et rapports financiers
    "Comptable": {"tresorerie", "comptabilite", "depenses", "rapports", "agenda"},
}

# Actions sensibles réservées à l'Admin
ACTIONS_ADMIN = {"supprimer", "resilier_contrat", "gerer_utilisateurs", "modifier_parametres"}


def peut_acceder(role: str, module: str) -> bool:
    return module in MODULES_PAR_ROLE.get(role, set())


def peut_faire(role: str, action: str) -> bool:
    return role == "Admin" and action in ACTIONS_ADMIN


# ---------- Dépendances FastAPI ----------

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def utilisateur_connecte(request: Request, db: SessionDB = Depends(get_db)) -> Utilisateur:
    """À utiliser sur toute route protégée : 401 si personne n'est connecté, 423 si Gérimo est en veille,
    403 « mdp_a_changer » tant que le mot de passe provisoire donné par l'Admin n'est pas remplacé."""
    session = session_de_la_requete(db, request)
    if session is None:
        raise HTTPException(status_code=401, detail="Veuillez vous connecter.")
    verifier_veille(db, session)
    utilisateur = session.utilisateur
    if utilisateur.mdp_provisoire and request.url.path not in LIBRES_MDP_PROVISOIRE:
        par = db.get(Utilisateur, utilisateur.mdp_redonne_par) if utilisateur.mdp_redonne_par else None
        raise HTTPException(status_code=403, detail={
            "code": "mdp_a_changer", "message": "Choisissez d'abord votre propre mot de passe.",
            "nom": utilisateur.nom_complet, "identifiant": utilisateur.identifiant,
            "redonne": ({"le": utilisateur.mdp_redonne_le.strftime("%d/%m/%Y à %H:%M"),
                         "par": par.nom_complet if par else "l'Admin"} if utilisateur.mdp_redonne_le else None)})
    if request.method != "GET":  # une action de l'utilisateur : il est bien devant l'écran
        noter_activite(db, session)
    marquer_utilisateur(db, utilisateur)
    return utilisateur


def exiger_module(module: str):
    """Dépendance : refuse (403) si le rôle n'a pas accès au module."""
    def verification(utilisateur: Utilisateur = Depends(utilisateur_connecte)) -> Utilisateur:
        if not peut_acceder(utilisateur.role.value, module):
            raise HTTPException(status_code=403, detail="Accès refusé pour votre profil.")
        return utilisateur
    return verification


def exiger_admin(utilisateur: Utilisateur = Depends(utilisateur_connecte)) -> Utilisateur:
    """Dépendance : refuse (403) si l'utilisateur n'est pas Admin."""
    if utilisateur.role.value != "Admin":
        raise HTTPException(status_code=403, detail="Action réservée à l'administrateur.")
    return utilisateur


def confirmer_mot_de_passe_admin(admin: Utilisateur, mot_de_passe: str) -> None:
    """Suppression : l'Admin connecté doit retaper son propre mot de passe."""
    if not verifier_mot_de_passe(mot_de_passe or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe Admin incorrect. Rien n'a été supprimé.")


# ---------- Périmètre des cités ----------

def cites_autorisees(utilisateur: Utilisateur) -> set[int] | None:
    """None = tous les biens ; sinon l'ensemble des biens confiés (Gestionnaire).

    La Caisse encaisse pour tous les biens : son seul module (Paiements) est,
    lui, limité par MODULES_PAR_ROLE.
    """
    if utilisateur.role.value == "Gestionnaire":
        return {c.id for c in utilisateur.cites_gerees}
    return None


def verifier_cite_autorisee(utilisateur: Utilisateur, cite_id: int) -> None:
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None and cite_id not in autorisees:
        # 404 plutôt que 403 : on ne révèle pas l'existence des cités des autres
        raise HTTPException(status_code=404, detail="Cité introuvable.")
