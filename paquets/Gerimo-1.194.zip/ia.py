"""Gérimo, l'assistant « intelligent » d'ISUP : une vraie IA (Claude, d'Anthropic) qui converse librement.

RÈGLE STRICTE (décision de Boss du 04/10/2026) : aucune donnée de la base d'ISUP n'est envoyée à Anthropic
ni à personne. Concrètement :
- Claude ne reçoit que la conversation (les questions tapées et ses propres réponses), jamais le contenu
  de la base. Les consignes ne contiennent ni le nom de l'utilisateur ni aucune donnée de la base.
- Quand il faut des données (impayés, recherche, chiffres…), Claude choisit un « outil » ; le logiciel
  l'exécute ici, sur le serveur d'ISUP, et affiche le résultat directement à l'utilisateur. Claude reçoit
  seulement « résultat affiché à l'utilisateur », jamais le résultat lui-même.
- Avant l'envoi, les noms de personnes et de biens connus de la base, les téléphones, les e-mails et les
  numéros de contrat tapés dans la conversation sont remplacés par des codes ([PERSONNE_1], [TEL_1]…) ;
  ils sont remis en clair à l'arrivée, sur le serveur d'ISUP (classe Masque).
- Sans clé ou sans Internet, on revient à l'assistant « à règles » (assistant.py), entièrement local.

Il faut Internet et une clé de l'API Anthropic (Paramètres → Réglages → Intelligence artificielle, ou
ANTHROPIC_API_KEY dans .env).
"""
import re
import unicodedata
from datetime import date, datetime, time, timedelta

import anthropic
from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session as SessionDB

import parametres
from assistant import f, interpreter, jour_fr, taches
from models import (BESOINS_PROSPECT, Cite, Contrat, Locataire, Logement, Proprietaire, Prospect, Utilisateur,
                    TYPES_EVENEMENT, TYPES_LOGEMENT)
from securite import cites_autorisees, get_db, peut_acceder, utilisateur_connecte

router = APIRouter(prefix="/api")

# Choix de l'Admin dans Paramètres, selon le budget. Haiku 4.5 n'accepte ni « effort » ni le repli automatique
# en cas de refus ; les deux autres, oui.
MODELES = {
    "economique": {"model": "claude-haiku-4-5"},
    "equilibre": {"model": "claude-sonnet-5-5", "output_config": {"effort": "low"},
                  "betas": ["server-side-fallback-2026-07-01"], "fallbacks": "default"},
    "intelligent": {"model": "claude-opus-5-5", "output_config": {"effort": "low"},
                    "betas": ["server-side-fallback-2026-07-01"], "fallbacks": "default"},
}
TOURS_MAX = 6  # appels d'outils enchaînés au plus, pour une même question

MODULES = {"accueil": "Accueil", "biens": "Biens", "proprietaires": "Propriétaires", "locataires": "Locataires",
           "contrats": "Contrats", "paiements": "Finances", "depenses": "Dépenses", "achats_ventes": "Achats/Ventes",
           "rapports": "Rapports", "etats_des_lieux": "États des lieux", "courriers": "Courriers",
           "reseaux_sociaux": "Réseaux sociaux", "agenda": "Agenda"}

CONSIGNES = """Tu t'appelles Gérimo : tu es l'assistant intelligent du logiciel de gestion locative de {nom} \
({activite}), à {ville}, en Côte d'Ivoire. Tu parles avec un membre de l'équipe.

Ton nom : écris-le toujours « Gérimo ». Les utilisateurs peuvent l'écrire ou le prononcer « Gérimo » ou \
« Gerimo » (et la dictée peut donner « Jérimo », « Gérémo »…) : c'est le même nom, le tien ; ne corrige jamais \
personne là-dessus. Quand on te demande qui tu es, réponds que tu es Gérimo, l'assistant {d_nom}.

Confidentialité (règle absolue) : tu ne vois jamais les données de la base. Quand tu utilises un outil, \
le logiciel affiche lui-même le résultat à l'utilisateur, juste sous ta réponse ; toi, tu reçois seulement \
« résultat affiché ». Donc :
- N'invente jamais et ne devine jamais un nom, un montant, une date ou un chiffre de l'entreprise. Ne commente pas un \
résultat que tu n'as pas vu ; dis simplement que le résultat est affiché (ex. « Voici la liste : »).
- Ne demande jamais à l'utilisateur de te recopier des données de la base pour les analyser.
- Dans la conversation, des codes comme [PERSONNE_1], [BIEN_1], [TEL_1], [EMAIL_1], [CONTRAT_1] remplacent des \
informations confidentielles. Réutilise-les tels quels (dans tes réponses et dans les outils) : le logiciel les \
remet en clair pour l'utilisateur. N'essaie jamais de deviner ce qu'ils cachent.

Ta façon de répondre :
- Toujours en français, chaleureux, clair et naturel, comme un collègue compétent. Vouvoie toujours.
- Va droit au but. Réponses courtes pour les questions simples ; plus détaillées quand on te demande un texte, \
une explication ou un conseil.
- Texte simple, sans tableaux ni titres Markdown. Pour une liste, une ligne par élément commençant par « • ». \
Tu peux mettre quelques mots importants en **gras**.
- Montants en francs CFA écrits « 60 000 F ». Dates au format jj/mm/aaaa.
- Tu peux tout faire d'un assistant : rédiger un message WhatsApp ou une lettre (avec les codes ci-dessus à la \
place des noms), expliquer une règle, conseiller, calculer, répondre à des questions générales.
- Pour afficher des données de l'entreprise (programme du jour, recherche, logements libres, impayés, chiffres, rapport), \
utilise l'outil adapté. Si l'outil répond que le profil n'y a pas accès, explique-le poliment.
- Avant de créer un rendez-vous ou une demande de client, assure-toi d'avoir les informations essentielles \
(au minimum le titre et la date pour un rendez-vous ; le nom pour un client) ; sinon, demande-les.
- Quand c'est utile, propose d'ouvrir le bon écran du logiciel avec l'outil ouvrir_ecran.
- Ne suppose rien : si tu ne sais pas, ou si aucun outil ne donne l'information, dis-le simplement et indique à \
qui s'adresser, au lieu de deviner.
- Questions sensibles de la compétence du comptable (TVA à déclarer, résultat, impôts, écritures, clôture, conseil \
fiscal ou comptable) : ne réponds pas sur le fond, oriente vers le comptable de l'agence, sauf si ton interlocuteur \
a lui-même le profil Comptable. Même règle pour l'argent de la caisse (montants en caisse, écarts, arrêtés, \
reversements faits) : oriente vers la Caisse, sauf si ton interlocuteur a le profil Caisse. Tu peux toujours \
expliquer comment le logiciel fonctionne (où trouver un écran, à quoi sert un bouton).

Règles de la maison (gestion locative) :
- {nom} est propriétaire de certains biens et gestionnaire mandataire d'autres, avec un % de commission par bien.
- La commission est déduite à chaque encaissement, sur les loyers et l'avance, jamais sur la caution (dépôt de \
garantie). Montant reversé au propriétaire = loyer encaissé − commission (− dépenses à sa charge).
- On encaisse toujours des mois complets, jamais de paiement partiel ; plusieurs mois peuvent être payés en une \
fois avec un seul reçu. Les mois d'avance (1 à 3) couvrent les premiers mois du bail. Caution : 3 mois au plus.
- Le loyer est dû le 05 du mois concerné. Rappel avant l'échéance, puis alerte en cas de retard.
- Après 2 mois d'impayés consécutifs, le contrat passe « à risque ». La résiliation n'est jamais automatique : \
seul l'Admin la fait.
- La quittance n'affiche jamais caution, avance ni reste ; le reçu de paiement, lui, les affiche.
- Profils : Admin (tout), Gestionnaire (ses cités seulement, ni propriétaires ni achats/ventes ni suppression), \
Caisse (paiements, dépenses, achats/ventes, rapports, son agenda).
- Messages WhatsApp : liens wa.me pré-remplis (bienvenue, rappel, confirmation de paiement, alerte de retard, \
avis d'expulsion), depuis les écrans Contrats et Finances.
- Coordonnées de l'entreprise : {adresse}. Tél. {telephones}. {email}."""


# ---------- Masque : codes à la place des informations confidentielles ----------

def _plat(texte: str) -> str:
    """Minuscules sans accents, MÊME LONGUEUR que le texte (pour retrouver les positions)."""
    return "".join((unicodedata.normalize("NFD", c)[0] if c.isalpha() else c).lower()[:1] or c for c in texte)


MOTS_COURANTS = {"les", "des", "une", "pour", "avec", "dans", "sur", "chez", "monsieur", "madame", "mademoiselle",
                 "cite", "residence", "villa", "immeuble", "logement", "bien", "appartement", "maison", "cour",
                 "commune", "duplex", "magasin", "studio", "isup", "sarl", "gerimo", "test", "client", "cliente",
                 "locataire", "proprietaire", "bonjour", "merci", "demain", "lundi", "mardi", "mercredi", "jeudi",
                 "vendredi", "samedi", "dimanche", "loyer", "rappel", "contrat", "bail", "admin", "caisse",
                 "gestionnaire"}
TELEPHONE = re.compile(r"(?<!\d)(?:\+?225[\s.-]?)?0\d(?:[\s.-]?\d{2}){4}(?!\d)")
EMAIL = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")
CONTRAT = re.compile(r"\b[A-Z]{2,5}-\d{4}-\d{3,6}\b")
CODE = re.compile(r"\[?\b(PERSONNE|BIEN|TEL|EMAIL|CONTRAT)_(\d+)\b\]?")


class Masque:
    """Remplace les informations confidentielles par des codes, et les remet en clair au retour."""

    def __init__(self, db: SessionDB):
        personnes: set[str] = set()
        for modele in (Locataire, Proprietaire, Prospect, Utilisateur):
            personnes.update(n for (n,) in db.query(modele.nom_complet) if n)
        termes: dict[str, str] = {}  # terme (aplati) → catégorie
        for nom in personnes:
            plat = _plat(nom.strip())
            if len(plat) >= 3:
                termes[plat] = "PERSONNE"
            for mot in re.findall(r"[^\W\d_]{3,}", plat):  # « Koffi » seul suffit à masquer
                if mot not in MOTS_COURANTS:
                    termes.setdefault(mot, "PERSONNE")
        for (nom,) in db.query(Cite.nom):
            if nom and len(nom.strip()) >= 3:
                termes.setdefault(_plat(nom.strip()), "BIEN")
        self.termes = termes
        motifs = sorted(termes, key=len, reverse=True)
        self.regex = (re.compile(r"(?<!\w)(?:" + "|".join(re.escape(t) for t in motifs) + r")(?!\w)")
                      if motifs else None)
        self.codes: dict[str, str] = {}     # (catégorie, terme aplati) → code
        self.originaux: dict[str, str] = {}  # code → texte d'origine

    def _code(self, categorie: str, original: str) -> str:
        cle = categorie + "|" + _plat(original)
        if cle not in self.codes:
            numero = sum(1 for c in self.codes if c.startswith(categorie + "|")) + 1
            self.codes[cle] = f"[{categorie}_{numero}]"
            self.originaux[self.codes[cle]] = original
        return self.codes[cle]

    def masquer(self, texte: str) -> str:
        for regex, categorie in ((EMAIL, "EMAIL"), (TELEPHONE, "TEL"), (CONTRAT, "CONTRAT")):
            texte = regex.sub(lambda m, c=categorie: self._code(c, m.group(0)), texte)
        if self.regex:
            plat, morceaux, fin = _plat(texte), [], 0
            for m in self.regex.finditer(plat):
                original = texte[m.start():m.end()]
                morceaux += [texte[fin:m.start()], self._code(self.termes[m.group(0)], original)]
                fin = m.end()
            texte = "".join(morceaux) + texte[fin:]
        return texte

    def demasquer(self, valeur):
        """Remet en clair les codes (texte, ou valeurs d'un outil)."""
        if isinstance(valeur, str):
            return CODE.sub(lambda m: self.originaux.get(f"[{m.group(1)}_{m.group(2)}]", m.group(0)), valeur)
        if isinstance(valeur, dict):
            return {k: self.demasquer(v) for k, v in valeur.items()}
        if isinstance(valeur, list):
            return [self.demasquer(v) for v in valeur]
        return valeur


# ---------- Outils : Claude les choisit, le logiciel les exécute ici et affiche le résultat ----------

def _outil(nom, description, proprietes=None, requis=()):
    return {"name": nom, "description": description,
            "input_schema": {"type": "object", "properties": proprietes or {}, "required": list(requis)}}


def outils_pour(u: Utilisateur) -> list[dict]:
    """Seuls les outils permis au profil sont proposés (et chacun revérifie les droits)."""
    role = u.role.value
    affiche = " Le résultat est affiché directement à l'utilisateur (tu ne le vois pas)."
    liste = [
        _outil("programme_du_jour", "Affiche ce qu'il y a à faire aujourd'hui pour l'utilisateur : rendez-vous, "
               "appels, loyers à échéance, impayés, contrats à risque, états des lieux, clients à rappeler…" + affiche),
        _outil("rechercher", "Affiche les fiches du logiciel (biens, logements, propriétaires, locataires, "
               "contrats…) qui correspondent à un nom, un numéro, un téléphone, un quartier." + affiche,
               {"texte": {"type": "string", "description": "Mot(s) à chercher (un code comme [PERSONNE_1] est "
                                                           "accepté)"}}, ["texte"]),
        _outil("ouvrir_ecran", "Affiche sous ta réponse un bouton qui ouvre un écran du logiciel.",
               {"ecran": {"type": "string", "enum": [m for m in MODULES if peut_acceder(role, m) or m == "accueil"]}},
               ["ecran"]),
    ]
    if peut_acceder(role, "biens"):
        liste.append(_outil("logements_libres", "Affiche les logements libres (à louer)." + affiche))
    if peut_acceder(role, "paiements"):
        liste.append(_outil("impayes", "Affiche les contrats dont des loyers échus ne sont pas payés." + affiche))
    if peut_acceder(role, "rapports"):
        liste.append(_outil("tableau_de_bord", "Affiche les chiffres du mois en cours : loyers encaissés, impayés, "
                                               "contrats à risque, dépenses, occupation." + affiche))
        liste.append(_outil("rapport_periode", "Affiche le résumé chiffré d'une période (encaissements, "
                                               "dépenses, impayés, commission…)." + affiche,
                            {"debut": {"type": "string", "description": "Date de début AAAA-MM-JJ"},
                             "fin": {"type": "string", "description": "Date de fin AAAA-MM-JJ"}}, ["debut", "fin"]))
    if peut_acceder(role, "agenda"):
        liste.append(_outil("noter_agenda", "Ajoute un rendez-vous, un appel, une visite, une tâche… à l'agenda de "
                                            "l'utilisateur (rappel automatique avant l'heure).",
                            {"titre": {"type": "string"},
                             "type_evenement": {"type": "string", "enum": list(TYPES_EVENEMENT)},
                             "date": {"type": "string", "description": "AAAA-MM-JJ"},
                             "heure": {"type": "string", "description": "HH:MM (facultatif)"},
                             "lieu": {"type": "string"}, "telephone": {"type": "string"},
                             "notes": {"type": "string"}}, ["titre", "type_evenement", "date"]))
    if peut_acceder(role, "prospects"):
        liste.append(_outil("nouveau_client", "Enregistre la demande d'un client qui cherche un logement (ou veut "
                                              "acheter, vendre, confier un bien) ; les logements libres qui "
                                              "correspondent sont affichés à l'utilisateur.",
                            {"nom_complet": {"type": "string"}, "telephone": {"type": "string"},
                             "besoin": {"type": "string", "enum": list(BESOINS_PROSPECT)},
                             "type_logement": {"type": "string", "enum": list(TYPES_LOGEMENT)},
                             "quartier": {"type": "string"}, "budget_max": {"type": "number"},
                             "details": {"type": "string"}}, ["nom_complet"]))
    return liste


REFUS = "Votre profil n'a pas accès à cette information."


def _lignes(elements, vide):
    return "\n".join(elements) if elements else vide


def executer_outil(db: SessionDB, u: Utilisateur, nom: str, e: dict, actions: list, cree: dict) -> tuple[str, str]:
    """Exécute un outil ICI. Renvoie (titre, texte à afficher à l'utilisateur) — jamais transmis à l'IA.
    Les droits sont revérifiés pour chaque outil."""
    role = u.role.value
    if nom == "programme_du_jour":
        liste, _ = taches(db, u)
        return "Programme du jour", _lignes([f"• {t['titre']}" + (f" — {t['detail']}" if t["detail"] else "")
                                             for t in liste[:25]], "Tout est à jour, rien à faire. 👍")
    if nom == "rechercher":
        from recherche import recherche
        q = str(e.get("texte", "")).strip()[:100]
        groupes = recherche(q, u, db)["groupes"] if q else []
        lignes = [f"{g['categorie']} ({g['total']}) :\n" + "\n".join(
            f"• {x['titre']}" + (f" — {x['detail']}" if x.get("detail") else "") for x in g["elements"][:8])
            for g in groupes]
        actions.extend({"libelle": f"Ouvrir {MODULES[c]}", "type": "ouvrir", "cible": c}
                       for c in dict.fromkeys(x["cible"] for g in groupes for x in g["elements"])
                       if c in MODULES and peut_acceder(role, c))
        return f"Recherche « {q} »", "\n\n".join(lignes) or "Aucun résultat."
    if nom == "ouvrir_ecran":
        ecran = e.get("ecran")
        if ecran not in MODULES or not (ecran == "accueil" or peut_acceder(role, ecran)):
            return "", "Écran non accessible pour ce profil."
        actions.append({"libelle": f"Ouvrir {MODULES[ecran]}", "type": "ouvrir", "cible": ecran})
        return "", ""
    if nom == "logements_libres" and peut_acceder(role, "biens"):
        requete = db.query(Logement).join(Cite).filter(Logement.statut_logement == "Libre")
        autorisees = cites_autorisees(u)
        if autorisees is not None:
            requete = requete.filter(Logement.cite_id.in_(autorisees))
        return "Logements libres", _lignes([f"• Logement {l.numero_logement} — {l.type_logement} — {l.cite.nom} — "
                                            f"{f(l.loyer)}" for l in requete.order_by(Logement.loyer)[:40]],
                                           "Aucun logement libre en ce moment.")
    if nom == "impayes" and peut_acceder(role, "paiements"):
        liste, _ = taches(db, u)
        return "Impayés", _lignes([f"• {t['titre']} — {t['detail']}" for t in liste if t["categorie"] == "Impayé"],
                                  "Aucun impayé : tous les loyers échus sont réglés. 👍")
    if nom == "tableau_de_bord" and peut_acceder(role, "rapports"):
        from rapports import tableau_de_bord
        t = tableau_de_bord(u, db)
        lignes = [f"• Loyers encaissés : {f(t['loyers_encaisses'])}", f"• Contrats en impayé : {t['impayes_en_cours']}",
                  f"• Contrats à risque : {t['contrats_a_risque']}", f"• Dépenses : {f(t['depenses'])}",
                  f"• Logements : {t['logements']['occupes']} occupés, {t['logements']['libres']} libres "
                  f"({t['logements']['taux_occupation']} % d'occupation)"]
        if "commission_entreprise" in t:
            lignes.insert(1, f"• Commission de gestion : {f(t['commission_entreprise'])}")
        return f"Tableau de bord {t['mois']}", "\n".join(lignes)
    if nom == "rapport_periode" and peut_acceder(role, "rapports"):
        from rapports import construire_rapport
        debut, fin = date.fromisoformat(e["debut"]), date.fromisoformat(e["fin"])
        if fin < debut:
            return "", "La date de fin est avant la date de début."
        k = construire_rapport(db, u, debut, fin)["kpis"]
        lignes = [f"• Total encaissé : {f(k['total_encaisse'])} ({k['nb_encaissements']} encaissement(s))",
                  f"• dont loyers : {f(k['loyers'])}, cautions : {f(k['cautions'])}", f"• Dépenses : {f(k['depenses'])}",
                  f"• Impayés de la période : {f(k['montant_impayes_periode'])} ({k['taux_impayes']} %)",
                  f"• Contrats en retard : {k['contrats_en_retard']}, dont à risque : {k['contrats_a_risque']}"]
        if "commission_entreprise" in k:
            lignes += [f"• Commission de gestion : {f(k['commission_entreprise'])}", f"• Net à reverser : {f(k['net_a_reverser'])}"]
        actions.append({"libelle": "Ouvrir Rapports", "type": "ouvrir", "cible": "rapports"})
        return f"Rapport du {debut.strftime('%d/%m/%Y')} au {fin.strftime('%d/%m/%Y')}", "\n".join(lignes)
    if nom == "noter_agenda" and peut_acceder(role, "agenda"):
        from agenda import EvenementIn, creer_evenement
        heure = time.fromisoformat(e["heure"]) if e.get("heure") else None
        evt = creer_evenement(EvenementIn(
            titre=e["titre"], type_evenement=e.get("type_evenement", "Tâche"), date_evenement=date.fromisoformat(e["date"]),
            heure=heure, lieu=e.get("lieu", ""), telephone=e.get("telephone") or None, notes=e.get("notes", ""),
            rappel_minutes=15 if heure else 0), u, db)
        cree["evenement_id"] = evt["id"]
        jour = date.fromisoformat(e["date"])
        return "Agenda", (f"✅ Noté : {e.get('type_evenement', 'Tâche').lower()} « {evt['titre']} » — {jour_fr(jour)}"
                          + (f" à {heure.strftime('%H:%M')} (rappel 15 minutes avant)" if heure else ""))
    if nom == "nouveau_client" and peut_acceder(role, "prospects"):
        from agenda import ProspectIn, creer_prospect
        infos = {k: v for k, v in e.items() if v not in (None, "")}
        fiche = creer_prospect(ProspectIn(**infos, source="Passage au bureau"), u, db)
        cree["prospect_id"] = fiche["id"]
        actions.append({"libelle": "Voir la fiche", "type": "prospect", "id": fiche["id"]})
        texte = f"✅ Demande enregistrée pour {fiche['nom_complet']}. Rappel prévu demain."
        if fiche["correspondances"]:
            texte += "\nLogements libres qui correspondent :\n" + "\n".join(
                f"• {c['logement']} — {f(c['loyer'])}" for c in fiche["correspondances"])
        return "Nouveau client", texte
    return "", REFUS


def _executer(db, u, masque: Masque, bloc, actions, cree, donnees) -> dict:
    """Exécute l'outil, garde le résultat pour l'écran ; l'IA ne reçoit qu'un accusé de réception."""
    try:
        titre, texte = executer_outil(db, u, bloc.name, masque.demasquer(dict(bloc.input or {})), actions, cree)
    except Exception as erreur:  # données refusées par le contrôle des saisies, date invalide…
        db.rollback()
        detail = getattr(erreur, "detail", None) or str(erreur)
        donnees.append({"titre": "Action impossible", "texte": str(detail)[:500]})
        return {"type": "tool_result", "tool_use_id": bloc.id, "is_error": True,
                "content": "Échec : les informations ne sont pas valables (le détail est affiché à l'utilisateur)."}
    if texte == REFUS or texte.startswith(("Écran non accessible", "La date de fin")):
        return {"type": "tool_result", "tool_use_id": bloc.id, "content": texte}  # message fixe, sans donnée
    if texte:
        donnees.append({"titre": titre, "texte": texte})
    return {"type": "tool_result", "tool_use_id": bloc.id,
            "content": "Fait. Résultat affiché à l'utilisateur sous ta réponse (contenu confidentiel, non transmis)."}


# ---------- Conversation ----------

class MessageIA(BaseModel):
    role: str = Field(pattern="^(user|assistant)$")
    texte: str = Field(min_length=1, max_length=8000)


class Discussion(BaseModel):
    messages: list[MessageIA] = Field(min_length=1, max_length=60)


def _consignes(u: Utilisateur) -> str:
    """Pas de nom ni de donnée de la base : seulement le profil, la date et l'heure."""
    aujourdhui = date.today()
    import recus
    e = recus.ENTETE
    consignes = (CONSIGNES.replace("{", "{{").replace("}", "}}")
                 .replace("{{nom}}", "{nom}").replace("{{activite}}", "{activite}").replace("{{ville}}", "{ville}")
                 .replace("{{adresse}}", "{adresse}").replace("{{telephones}}", "{telephones}")
                 .replace("{{email}}", "{email}").replace("{{d_nom}}", "{d_nom}")
                 .format(nom=e["nom"], activite=e["activite"], ville=e["ville"], adresse=e["adresse"],
                         telephones=e["telephones"], email=e["email"], d_nom=recus.d_entreprise()))
    return (consignes + f"\n\nTon interlocuteur a le profil {u.role.value}. Nous sommes le {jour_fr(aujourdhui)} "
            f"{aujourdhui.year} ({aujourdhui.strftime('%d/%m/%Y')}), il est {datetime.now().strftime('%H:%M')}. "
            f"Demain = {(aujourdhui + timedelta(days=1)).isoformat()}.")


def _historique(messages: list[MessageIA], masque: Masque) -> list[dict]:
    """Conversation envoyée à l'IA, masquée : commence par l'utilisateur, rôles alternés."""
    resultat: list[dict] = []
    for m in messages[-30:]:
        if not resultat and m.role != "user":
            continue
        texte = masque.masquer(m.texte)
        if resultat and resultat[-1]["role"] == m.role:
            resultat[-1]["content"] += "\n\n" + texte
        else:
            resultat.append({"role": m.role, "content": texte})
    return resultat


def _repli(db, u, texte: str, raison: str = "") -> dict:
    """Assistant à règles (local), quand l'IA n'est pas disponible."""
    rep = interpreter(db, u, texte[:500])
    if raison:
        rep["reponse"] = f"({raison})\n\n" + rep["reponse"]
    rep["mode"] = "regles"
    # ce qu'on garde dans la conversation : pas les données affichées
    rep["memoire"] = "(Réponse de l'assistant simple affichée à l'écran.)"
    return rep


@router.post("/assistant/discuter")
def discuter(d: Discussion, u: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    question = next((m.texte for m in reversed(d.messages) if m.role == "user"), "")
    cle = parametres.cle_ia(db)
    if not cle:  # pas d'IA réglée : l'assistant simple (avec son lexique) répond, sans avertissement à chaque fois
        return _repli(db, u, question)
    masque = Masque(db)
    messages = _historique(d.messages, masque)
    if not messages or messages[-1]["role"] != "user":
        return {"reponse": "Posez-moi votre question.", "actions": [], "memoire": ""}

    client = anthropic.Anthropic(api_key=cle, timeout=90.0, max_retries=1)
    outils = outils_pour(u)
    modele = MODELES.get(parametres.lire(db, "ia_modele"), MODELES["intelligent"])
    actions: list[dict] = []
    donnees: list[dict] = []
    cree: dict = {}
    textes: list[str] = []
    try:
        for _ in range(TOURS_MAX):
            reponse = client.beta.messages.create(
                **modele, max_tokens=16000, system=_consignes(u), tools=outils, messages=messages,
                cache_control={"type": "ephemeral"})
            if reponse.stop_reason == "refusal":
                textes = ["Je ne peux pas répondre à cette demande. Essayez de la formuler autrement."]
                break
            textes += [b.text for b in reponse.content if b.type == "text" and b.text.strip()]
            if reponse.stop_reason != "tool_use":
                break
            messages.append({"role": "assistant", "content": reponse.content})
            messages.append({"role": "user", "content": [_executer(db, u, masque, b, actions, cree, donnees)
                                                         for b in reponse.content if b.type == "tool_use"]})
    except anthropic.AuthenticationError:
        return _repli(db, u, question, "La clé de l'IA est refusée : l'Admin doit la vérifier dans Paramètres")
    except anthropic.PermissionDeniedError:
        return _repli(db, u, question, "La clé de l'IA n'a pas les droits nécessaires (Paramètres)")
    except anthropic.RateLimitError:
        return _repli(db, u, question, "L'IA est très sollicitée ou le crédit du compte Anthropic est épuisé")
    except anthropic.APIConnectionError:
        return _repli(db, u, question, "Pas de connexion Internet : l'IA est indisponible")
    except anthropic.APIStatusError as erreur:
        if "credit" in str(erreur).lower():
            return _repli(db, u, question, "Le crédit du compte Anthropic est épuisé : l'Admin doit le recharger "
                                           "sur console.anthropic.com")
        return _repli(db, u, question, f"L'IA est momentanément indisponible (erreur {erreur.status_code})")
    texte = masque.demasquer("\n\n".join(textes).strip())
    # Mémoire de la conversation : la réponse de l'IA + le TITRE de ce qui a été affiché (jamais son contenu)
    memoire = "\n".join([texte] + [f"(Affiché à l'écran : {x['titre'].lower()}.)" for x in donnees if x["titre"]]).strip()
    return {"reponse": texte or ("Voici :" if donnees else "…"), "donnees": donnees, "actions": actions,
            "cree": cree or None, "mode": "ia", "memoire": memoire or "…"}
