"""Reprise de données (Admin) : un fichier Excel (ou CSV) d'un client qui passe à Gérimo.

Étapes, toutes vérifiées ici côté serveur :
1. Modèle Excel à télécharger (une feuille par type : Propriétaires, Biens, Logements, Locataires,
   Contrats, Paiements) — ou n'importe quel fichier du client.
2. Analyse : chaque feuille est reconnue, et chaque colonne rapprochée d'un champ de Gérimo
   (« Nom bailleur » → Propriétaire…). L'Admin corrige si besoin.
3. Vérification : l'import est fait « pour de faux » (puis annulé) avec les MÊMES règles de contrôle que les
   formulaires ; chaque erreur est donnée avec sa feuille et sa ligne.
4. Import : tout ou rien. Une sauvegarde est faite juste avant. Les doublons sont réutilisés, pas recréés.
5. Annulation possible ensuite (tant qu'aucune opération n'a été faite sur ces données).

Paiements passés : enregistrés comme « repris » (REP-AAAA-NNNNN) : ils règlent les mois et comptent dans
les rapports, mais Gérimo n'en fait ni reçu ni quittance.
Confidentialité : le fichier du client n'est gardé que le temps de l'import (dossier imports_en_cours/,
effacé ensuite, et au plus tard après 24 h) ; seul un résumé chiffré est conservé.
"""
import csv
import io
import json
import re
import secrets
import time
import unicodedata
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field, ValidationError
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.orm import Session as SessionDB

import journal
import paiements
import sauvegarde
from biens import LogementIn, NouvelleCite, ProprietaireIn, definir_commission, synchroniser_statut_logement
from commun import Code, numero_suivant
from contrats import ContratModifiable, LocataireIn, appliquer_conditions, prochain_numero
from models import (STATUTS_CONTRAT, STATUTS_EN_COURS, STATUTS_LOGEMENT, TERMES_LOYER, TYPES_BATIMENT_LOGEMENT,
                    TYPES_CONTRAT, TYPES_LOGEMENT_FICHE, USAGES_BIEN, MODES_PAIEMENT, Cite, Contrat, Echeance, Encaissement,
                    Locataire, Logement, Paiement, Proprietaire, Utilisateur, VersementEcheance)
from securite import confirmer_mot_de_passe_admin, exiger_admin, get_db

router = APIRouter(prefix="/api")
DOSSIER_TEMP = Path(__file__).parent / "imports_en_cours"
TAILLE_MAX = 30 * 1024 * 1024
LIGNES_MAX = 20000
DUREE_TEMP = 24 * 3600


# ---------- Ce que Gérimo sait importer ----------

@dataclass
class Champ:
    cle: str
    libelle: str
    obligatoire: bool = False
    synonymes: tuple = ()
    aide: str = ""


TYPES = {
    "proprietaires": ("Propriétaires", [
        Champ("nom_complet", "Nom complet", True, ("nom", "nom et prenoms", "nom prenoms", "proprietaire", "bailleur",
                                                   "nom du proprietaire", "nom proprietaire")),
        Champ("telephone", "Téléphone", False, ("tel", "telephone", "contact", "cel", "cellulaire", "portable",
                                                "numero de telephone", "mobile")),
        Champ("cni", "CNI", False, ("cni", "piece", "piece d identite", "numero cni", "n cni", "identite")),
        Champ("email", "E-mail", False, ("email", "e mail", "mail", "courriel", "adresse mail")),
        Champ("ville", "Ville", False, ("ville", "localite", "commune")),
    ]),
    "biens": ("Biens (cités, immeubles…)", [
        Champ("nom", "Nom du bien", True, ("nom du bien", "bien", "cite", "immeuble", "residence", "batiment",
                                           "nom de la cite", "propriete", "nom")),
        Champ("proprietaire", "Propriétaire", True, ("proprietaire", "bailleur", "nom du proprietaire",
                                                     "nom proprietaire"), "Nom écrit comme dans la feuille Propriétaires"),
        Champ("commission", "Commission de gestion (%)", True, ("commission", "commission isup", "taux", "pourcentage",
                                                          "taux de commission", "honoraires", "commission %"),
              "0 pour un bien appartenant à l'entreprise"),
        Champ("adresse", "Adresse / Situation", False, ("adresse", "situation", "quartier", "localisation", "lieu")),
        Champ("description", "Description", False, ("description", "observation", "remarque", "notes")),
    ]),
    "logements": ("Logements", [
        Champ("bien", "Bien", True, ("bien", "cite", "immeuble", "residence", "batiment", "nom du bien")),
        Champ("numero", "Numéro du logement", True, ("numero", "n", "no", "logement", "porte", "appartement",
                                                    "numero logement", "n logement", "numero de porte", "local")),
        Champ("type_batiment", "Type de bien", False, ("type de bien", "type batiment", "type de batiment", "categorie"),
              "Par défaut : Appartement/Immeuble"),
        Champ("type_logement", "Type de logement", True, ("type de logement", "type", "pieces", "nombre de pieces",
                                                          "typologie", "type logement")),
        Champ("loyer", "Loyer mensuel", True, ("loyer", "loyer mensuel", "montant du loyer", "montant loyer", "prix")),
        Champ("statut", "Statut", False, ("statut", "etat", "situation du logement", "disponibilite"),
              "Libre, Occupé, Réservé ou Maintenance (par défaut : Libre)"),
    ]),
    "locataires": ("Locataires", [
        Champ("nom_complet", "Nom complet", True, ("nom", "nom et prenoms", "nom prenoms", "locataire", "preneur",
                                                   "nom du locataire", "nom locataire", "client")),
        Champ("telephone", "Téléphone", False, ("tel", "telephone", "contact", "cel", "cellulaire", "portable",
                                                "mobile", "numero de telephone")),
        Champ("cni", "CNI", False, ("cni", "piece", "piece d identite", "numero cni", "identite")),
        Champ("profession", "Profession", False, ("profession", "metier", "emploi", "fonction")),
        Champ("email", "E-mail", False, ("email", "e mail", "mail", "courriel")),
    ]),
    "contrats": ("Contrats de bail", [
        Champ("numero", "N° de contrat", False, ("numero contrat", "n contrat", "contrat", "reference", "ref",
                                                 "numero du contrat", "n bail", "numero bail"),
              "Gardé tel quel ; vide = numéro automatique BAIL-AAAA-NNNN"),
        Champ("bien", "Bien", True, ("bien", "cite", "immeuble", "residence", "batiment", "nom du bien")),
        Champ("logement", "Numéro du logement", True, ("logement", "numero logement", "n logement", "porte",
                                                       "appartement", "numero", "local")),
        Champ("locataire", "Locataire", True, ("locataire", "nom du locataire", "nom locataire", "preneur", "client",
                                               "nom")),
        Champ("telephone", "Téléphone du locataire", False, ("telephone", "tel", "contact", "telephone locataire",
                                                             "cel", "mobile")),
        Champ("date_debut", "Date de début", True, ("date de debut", "debut", "date debut", "date d entree", "entree",
                                                    "date entree", "date du bail", "date de signature")),
        Champ("date_fin", "Date de fin", False, ("date de fin", "fin", "date fin", "echeance du bail", "expiration")),
        Champ("loyer", "Loyer mensuel", False, ("loyer", "loyer mensuel", "montant du loyer", "montant loyer"),
              "Vide = loyer du logement"),
        Champ("mois_caution", "Mois de caution", False, ("caution", "mois de caution", "nombre de mois de caution",
                                                         "caution mois"), "0 à 3 (par défaut : 0)"),
        Champ("mois_avance", "Mois d'avance", False, ("avance", "mois d avance", "nombre de mois d avance",
                                                      "avance mois"), "0 à 3 (par défaut : 1)"),
        Champ("type_contrat", "Type de contrat", False, ("type de contrat", "type contrat", "type de bail", "nature"),
              "Par défaut : Bail habitation"),
        Champ("usage_bien", "Usage du bien", False, ("usage", "usage du bien", "destination"),
              "Par défaut : Habitation"),
        Champ("terme_loyer", "Loyer payé en", False, ("terme", "loyer paye en", "paiement", "echeance", "terme du loyer"),
              "Début de mois ou Fin de mois (par défaut : Début de mois)"),
        Champ("statut", "Statut du contrat", False, ("statut", "etat", "statut du contrat"), "Par défaut : Actif"),
        Champ("date_resiliation", "Date de résiliation", False, ("date de resiliation", "resiliation", "date de sortie",
                                                                 "sortie", "depart")),
        Champ("caution_versee", "Caution et avance déjà versées", False,
              ("caution versee", "caution et avance versees", "caution payee", "entree payee", "caution avance payee"),
              "Oui ou Non (par défaut : Oui)"),
        Champ("suivi_depuis", "Suivi dans Gérimo à partir de", False,
              ("suivi dans gerimo a partir de", "suivi depuis", "debut du suivi", "suivi a partir de"),
              "Mois à partir duquel Gérimo compte les loyers (ex : 10/2026) ; les mois d'avant sont considérés "
              "réglés. Vide = depuis le début du bail"),
    ]),
    "paiements": ("Paiements passés", [
        Champ("numero_contrat", "N° de contrat", False, ("numero contrat", "n contrat", "contrat", "reference", "ref",
                                                         "n bail")),
        Champ("bien", "Bien", False, ("bien", "cite", "immeuble", "residence", "nom du bien")),
        Champ("logement", "Numéro du logement", False, ("logement", "numero logement", "n logement", "porte",
                                                        "appartement", "local")),
        Champ("locataire", "Locataire", False, ("locataire", "nom du locataire", "nom locataire", "client", "nom")),
        Champ("mois_debut", "Mois payé (ou premier mois)", True, ("mois", "mois paye", "periode", "du", "de",
                                                                  "mois debut", "periode du", "premier mois",
                                                                  "mois concerne"), "Ex : 10/2026 ou octobre 2026"),
        Champ("mois_fin", "Dernier mois payé", False, ("au", "jusqu au", "mois fin", "periode au", "dernier mois",
                                                       "a"), "Vide = un seul mois"),
        Champ("montant", "Montant", True, ("montant", "somme", "montant paye", "montant verse", "versement",
                                           "total"),
              "Moins que le loyer = versement partiel : le mois garde son reste à payer"),
        Champ("date_paiement", "Date du paiement", True, ("date", "date de paiement", "date paiement",
                                                          "date du paiement", "date versement", "paye le")),
        Champ("mode_paiement", "Mode de paiement", False, ("mode", "mode de paiement", "moyen de paiement",
                                                           "moyen", "reglement"), "Par défaut : Espèce"),
    ]),
}
ORDRE = list(TYPES)
NOMS_FEUILLES = {"proprietaires": "Propriétaires", "biens": "Biens", "logements": "Logements",
                 "locataires": "Locataires", "contrats": "Contrats", "paiements": "Paiements"}


# ---------- Outils de lecture tolérants ----------

def norm(texte) -> str:
    """« N° Téléphone » → « n telephone » : pour comparer sans accents, majuscules ni ponctuation."""
    t = unicodedata.normalize("NFD", str(texte or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", t).strip()


def _texte(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).strip()


def _telephone(v) -> str:
    t = _texte(v)
    chiffres = re.sub(r"\D", "", t)
    if len(chiffres) == 9 and t == chiffres:  # Excel a mangé le 0 du début (0707… → 707…)
        return "0" + chiffres
    return t


def _montant(v, libelle: str) -> Decimal | None:
    if v in (None, ""):
        return None
    if isinstance(v, (int, float)):
        return Decimal(str(v))
    propre = re.sub(r"[\s  %]|f\s*cfa|fcfa|f$|xof|francs?", "", str(v).lower()).replace(",", ".")
    try:
        return Decimal(propre)
    except InvalidOperation:
        raise ValueError(f"« {libelle} » : montant illisible ({v}).")


def _entier(v, libelle: str) -> int | None:
    m = _montant(v, libelle)
    if m is None:
        return None
    if m != m.to_integral_value():
        raise ValueError(f"« {libelle} » : nombre entier attendu ({v}).")
    return int(m)


MOIS = {"janvier": 1, "janv": 1, "fevrier": 2, "fevr": 2, "fev": 2, "mars": 3, "avril": 4, "avr": 4, "mai": 5,
        "juin": 6, "juillet": 7, "juil": 7, "aout": 8, "septembre": 9, "sept": 9, "octobre": 10, "oct": 10,
        "novembre": 11, "nov": 11, "decembre": 12, "dec": 12}


def _date(v, libelle: str) -> date | None:
    if v in (None, ""):
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    if isinstance(v, (int, float)) and 20000 < v < 80000:  # date Excel non formatée (nombre de jours)
        return date(1899, 12, 30) + timedelta(days=int(v))
    t = str(v).strip()
    for motif, ordre in ((r"(\d{4})-(\d{1,2})-(\d{1,2})", "amj"), (r"(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})", "jma"),
                         (r"(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2})", "jma")):
        m = re.fullmatch(motif + r"(?:[ T].*)?", t)
        if m:
            a, b, c = (int(x) for x in m.groups())
            annee, mois, jour = (a, b, c) if ordre == "amj" else (c if c > 99 else 2000 + c, b, a)
            try:
                return date(annee, mois, jour)
            except ValueError:
                break
    raise ValueError(f"« {libelle} » : date illisible ({t}) — écrivez-la jj/mm/aaaa.")


def _mois(v, libelle: str) -> date | None:
    """« 10/2026 », « octobre 2026 », « oct-26 » ou une date → 1er du mois."""
    if v in (None, ""):
        return None
    if isinstance(v, (date, datetime)) or (isinstance(v, (int, float)) and 20000 < v < 80000):
        return _date(v, libelle).replace(day=1)
    t = norm(v)
    m = re.fullmatch(r"(\d{1,2}) (\d{4})", t)
    if m and 1 <= int(m.group(1)) <= 12:
        return date(int(m.group(2)), int(m.group(1)), 1)
    m = re.fullmatch(r"([a-z]+) (\d{2,4})", t)
    if m and m.group(1) in MOIS:
        annee = int(m.group(2))
        return date(annee if annee > 99 else 2000 + annee, MOIS[m.group(1)], 1)
    m = re.fullmatch(r"(\d{4}) (\d{1,2})", t)
    if m and 1 <= int(m.group(2)) <= 12:
        return date(int(m.group(1)), int(m.group(2)), 1)
    try:
        return _date(v, libelle).replace(day=1)
    except ValueError:
        raise ValueError(f"« {libelle} » : mois illisible ({v}) — écrivez par exemple 10/2026 ou octobre 2026.")


SYNONYMES_CHOIX = {
    "studio": "Studio", "chambre": "Studio", "chambre salon": "2 pièces", "f1": "Studio", "1 piece": "Studio",
    "magasin": "Magasin", "boutique": "Magasin", "local commercial": "Magasin", "villa": "Villa de plus de 8 pièces",
    "espece": "Espèce", "especes": "Espèce", "cash": "Espèce", "liquide": "Espèce",
    "orange money": "Mobile Money", "om": "Mobile Money", "mtn": "Mobile Money", "mtn money": "Mobile Money",
    "momo": "Mobile Money", "moov": "Mobile Money", "moov money": "Mobile Money", "wave": "Mobile Money",
    "flooz": "Mobile Money", "mobile": "Mobile Money", "virement bancaire": "Virement", "banque": "Virement",
    "cheque": "Chèque", "appartement": "Appartement/Immeuble", "immeuble": "Appartement/Immeuble",
    "debut": "Début de mois", "fin": "Fin de mois", "habitation": "Bail habitation", "commercial": "Bail commercial",
    "meuble": "Location meublée", "en cours": "Actif", "actif": "Actif", "resilie": "Résilié", "termine": "Expiré",
    "occupe": "Occupé", "libre": "Libre", "vacant": "Libre", "disponible": "Libre", "reserve": "Réservé",
    "travaux": "Maintenance",
}


def _choix(v, valeurs: tuple, libelle: str, defaut: str | None = None) -> str | None:
    if v in (None, ""):
        return defaut
    n = norm(v)
    for valeur in valeurs:
        if norm(valeur) == n:
            return valeur
    m = re.fullmatch(r"(?:f|t|p)?\s*(\d)\s*(?:p|pieces?|pcs)?", n)  # F2, T3, 4P, « 3 pièces »
    if m and f"{m.group(1)} pièces" in valeurs:
        return f"{m.group(1)} pièces"
    if n in SYNONYMES_CHOIX and SYNONYMES_CHOIX[n] in valeurs:
        return SYNONYMES_CHOIX[n]
    candidats = [valeur for valeur in valeurs if n and (n in norm(valeur) or norm(valeur) in n)]
    if len(candidats) == 1:
        return candidats[0]
    raise ValueError(f"« {libelle} » : « {v} » n'est pas reconnu (choix : {', '.join(valeurs)}).")


def _oui_non(v, libelle: str, defaut: bool) -> bool:
    if v in (None, ""):
        return defaut
    n = norm(v)
    if n in ("oui", "o", "yes", "y", "1", "vrai", "x", "ok", "paye", "payee", "versee", "verse"):
        return True
    if n in ("non", "n", "no", "0", "faux", "impaye", "non paye", "non versee"):
        return False
    raise ValueError(f"« {libelle} » : répondez Oui ou Non ({v}).")


# ---------- Lecture du fichier ----------

def _valeur_json(v):
    if isinstance(v, datetime):
        return v.date().isoformat() if v.time() == datetime.min.time() else v.isoformat()
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, (int, float, str)) or v is None:
        return v
    return str(v)


def _feuille(nom: str, lignes: list[list]) -> dict | None:
    """Repère la ligne des titres (la 1re avec au moins 2 textes) et garde les lignes suivantes non vides."""
    for i, ligne in enumerate(lignes[:15]):
        textes = [c for c in ligne if isinstance(c, str) and c.strip()]
        if len(textes) >= 2:
            colonnes, vues = [], {}
            for j, c in enumerate(ligne):
                titre = _texte(c) or f"Colonne {j + 1}"
                vues[titre] = vues.get(titre, 0) + 1
                colonnes.append(titre if vues[titre] == 1 else f"{titre} ({vues[titre]})")
            donnees = [{"ligne": i + 2 + k, "valeurs": [_valeur_json(x) for x in l[:len(colonnes)]]}
                       for k, l in enumerate(lignes[i + 1:]) if any(_texte(x) for x in l)]
            return {"nom": nom, "colonnes": colonnes, "lignes": donnees[:LIGNES_MAX], "trop": len(donnees) > LIGNES_MAX}
    return None


class PointVirgule(csv.excel):
    delimiter = ";"  # CSV d'Excel en français


def lire_fichier(nom: str, contenu: bytes) -> list[dict]:
    extension = Path(nom).suffix.lower()
    feuilles = []
    if extension in (".xlsx", ".xlsm"):
        import openpyxl
        try:
            classeur = openpyxl.load_workbook(io.BytesIO(contenu), read_only=True, data_only=True)
        except Exception:  # noqa: BLE001 — fichier abîmé, protégé par mot de passe…
            raise HTTPException(status_code=400, detail="Ce fichier Excel est illisible (abîmé ou protégé par un mot "
                                                        "de passe ?). Ouvrez-le dans Excel et réenregistrez-le.")
        for ws in classeur.worksheets:
            lignes = [list(l) for _, l in zip(range(LIGNES_MAX + 20), ws.iter_rows(values_only=True))]
            f = _feuille(ws.title, lignes)
            if f:
                feuilles.append(f)
        classeur.close()
    elif extension in (".csv", ".txt"):
        for encodage in ("utf-8-sig", "cp1252"):
            try:
                texte = contenu.decode(encodage)
                break
            except UnicodeDecodeError:
                continue
        try:
            dialecte = csv.Sniffer().sniff(texte[:5000], delimiters=";,\t")
        except csv.Error:
            dialecte = PointVirgule
        lignes = [l for _, l in zip(range(LIGNES_MAX + 20), csv.reader(io.StringIO(texte), dialecte))]
        f = _feuille(Path(nom).stem, lignes)
        if f:
            feuilles.append(f)
    elif extension == ".xls":
        raise HTTPException(status_code=400, detail="Ancien format Excel (.xls) : ouvrez le fichier dans Excel, puis "
                                                    "Fichier → Enregistrer sous → « Classeur Excel (.xlsx) ».")
    else:
        raise HTTPException(status_code=400, detail="Fichier non pris en charge : envoyez un fichier Excel (.xlsx) "
                                                    "ou CSV.")
    if not feuilles:
        raise HTTPException(status_code=400, detail="Aucun tableau trouvé : la première ligne doit contenir les titres "
                                                    "des colonnes (Nom, Téléphone…).")
    return feuilles


def deviner_type(feuille: dict) -> str | None:
    n = norm(feuille["nom"])
    for mots, type_ in ((("proprio", "bailleur"), "proprietaires"), (("paiement", "encaiss", "versement", "recette",
                        "quittance", "recu"), "paiements"), (("contrat", "bail", "baux"), "contrats"),
                        (("locataire", "preneur", "client"), "locataires"), (("logement", "appart", "porte", "local"),
                        "logements"), (("bien", "cite", "immeuble", "residence", "patrimoine"), "biens")):
        if any(m in n for m in mots):
            return type_
    scores = {t: sum(1 for c in champs if c.obligatoire and correspondance_auto(feuille["colonnes"], [c]).get(c.cle))
              for t, (_, champs) in TYPES.items()}
    meilleur = max(scores, key=scores.get)
    return meilleur if scores[meilleur] else None


def correspondance_auto(colonnes: list[str], champs: list[Champ]) -> dict[str, str]:
    """Pour chaque champ, la colonne du fichier qui lui ressemble le plus (chaque colonne ne sert qu'une fois)."""
    resultat, prises = {}, set()
    normes = {c: norm(c) for c in colonnes}
    for passe in ("exact", "contient"):
        for champ in champs:
            if champ.cle in resultat:
                continue
            cibles = [norm(champ.libelle), *champ.synonymes]
            for colonne, n in normes.items():
                if colonne in prises or not n or n in ("id", "uuid", "rowid"):  # identifiants techniques
                    continue
                if (passe == "exact" and n in cibles) or (passe == "contient" and any(
                        len(s) > 3 and len(n) > 3 and (s in n or n in s) for s in cibles)):
                    resultat[champ.cle] = colonne
                    prises.add(colonne)
                    break
    return resultat


# ---------- Fichiers temporaires (jamais conservés) ----------

def _menage() -> None:
    if DOSSIER_TEMP.exists():
        for f in DOSSIER_TEMP.glob("*"):  # données lues et copies de bases d'anciens logiciels
            if time.time() - f.stat().st_mtime > DUREE_TEMP:
                f.unlink(missing_ok=True)


def _chemin_temp(jeton: str) -> Path:
    if not re.fullmatch(r"[A-Za-z0-9_\-]{10,60}", jeton):
        raise HTTPException(status_code=404, detail="Import introuvable.")
    chemin = DOSSIER_TEMP / f"{jeton}.json"
    if not chemin.exists():
        raise HTTPException(status_code=404, detail="Ce fichier n'est plus disponible (plus de 24 h ?) : renvoyez-le.")
    return chemin


# ---------- L'import lui-même (même code pour la vérification et pour l'import réel) ----------

class ContratRepris(ContratModifiable):
    """Comme un contrat saisi à l'écran, avec les cas d'une reprise : contrats terminés, sans avance…"""
    mois_avance: int = Field(ge=0, le=3)
    statut_contrat: Literal[STATUTS_CONTRAT] = "Actif"


@dataclass
class Rapport:
    crees: dict = field(default_factory=lambda: {t: 0 for t in ORDRE})
    reutilises: dict = field(default_factory=lambda: {t: 0 for t in ORDRE})
    erreurs: list = field(default_factory=list)
    avertissements: list = field(default_factory=list)

    def erreur(self, feuille: str, ligne: int, message: str) -> None:
        if len(self.erreurs) < 500:
            self.erreurs.append({"feuille": feuille, "ligne": ligne, "message": message})

    def avertir(self, feuille: str, ligne: int, message: str) -> None:
        if len(self.avertissements) < 500:
            self.avertissements.append({"feuille": feuille, "ligne": ligne, "message": message})


def _message_validation(e: ValidationError, libelles: dict) -> str:
    morceaux = []
    for err in e.errors()[:3]:
        cle = next((str(p) for p in reversed(err["loc"]) if isinstance(p, str)), "")
        libelle = libelles.get(cle, cle)
        if err["type"] == "missing" or (err["type"] == "string_too_short" and not err.get("input")):
            morceaux.append(f"« {libelle} » est obligatoire")
        elif err["type"] == "value_error":
            morceaux.append(f"« {libelle} » : {err.get('ctx', {}).get('error', 'valeur invalide')}")
        elif err["type"] == "string_too_long":
            morceaux.append(f"« {libelle} » : trop long")
        elif err["type"] in ("greater_than", "greater_than_equal", "less_than_equal", "less_than"):
            morceaux.append(f"« {libelle} » : valeur hors limites ({err.get('input')})")
        else:
            morceaux.append(f"« {libelle} » : valeur invalide ({err.get('input')})")
    return " ; ".join(morceaux) + "."


class Importeur:
    def __init__(self, db: SessionDB, admin: Utilisateur, rapport: Rapport):
        self.db, self.admin, self.r = db, admin, rapport
        self.proprietaires = {norm(p.nom_complet): p for p in db.query(Proprietaire)}
        # noms portés par plusieurs fiches dans Gérimo (homonymes) : un bien du fichier ne peut pas s'y rattacher
        noms = [norm(p.nom_complet) for p in db.query(Proprietaire)]
        self.homonymes = {n for n in noms if noms.count(n) > 1}
        self.biens = {norm(c.nom): c for c in db.query(Cite)}
        self.logements = {(l.cite_id, norm(l.numero_logement)): l for l in db.query(Logement)}
        self.locataires_tel, self.locataires_nom = {}, {}
        for loc in db.query(Locataire):
            self._indexer_locataire(loc)
        self.contrats_touches: dict[int, Contrat] = {}

    def _indexer_locataire(self, loc: Locataire) -> None:
        chiffres = re.sub(r"\D", "", loc.telephone or "")[-10:]
        if chiffres:
            self.locataires_tel[chiffres] = loc
        self.locataires_nom.setdefault(norm(loc.nom_complet), loc)

    def trouver_locataire(self, nom: str, telephone: str) -> Locataire | None:
        chiffres = re.sub(r"\D", "", telephone or "")[-10:]
        if chiffres and chiffres in self.locataires_tel:
            return self.locataires_tel[chiffres]
        return self.locataires_nom.get(norm(nom)) if nom else None

    def trouver_bien(self, nom: str, feuille: str, ligne: int) -> Cite:
        if not nom:
            raise ValueError("« Bien » est obligatoire")
        cite = self.biens.get(norm(nom))
        if cite is None:
            raise ValueError(f"bien « {nom} » introuvable : ajoutez-le dans la feuille des biens "
                             "(ou écrivez son nom exactement comme dans Gérimo)")
        return cite

    # --- une ligne par type ---

    def proprietaire(self, v: dict, feuille: str, ligne: int) -> None:
        libelles = {c.cle: c.libelle for c in TYPES["proprietaires"][1]}
        try:
            d = ProprietaireIn(nom_complet=_texte(v.get("nom_complet")), telephone=_telephone(v.get("telephone")) or None,
                               cni=_texte(v.get("cni")) or None, email=_texte(v.get("email")) or None,
                               ville=_texte(v.get("ville")) or None)
        except ValidationError as e:
            raise ValueError(_message_validation(e, libelles))
        if norm(d.nom_complet) in self.homonymes:
            raise ValueError(f"plusieurs propriétaires portent déjà le nom « {d.nom_complet} » dans Gérimo : écrivez-le "
                             "autrement dans le fichier (par exemple avec sa ville entre parenthèses)")
        deja = self.proprietaires.get(norm(d.nom_complet))
        if deja is not None:
            chiffres = lambda t: re.sub(r"\D", "", t or "")[-10:]  # noqa: E731 — « +225 07… » = « 07… »
            if (d.telephone and deja.telephone and chiffres(d.telephone) != chiffres(deja.telephone)) \
                    or (d.cni and deja.cni and norm(d.cni) != norm(deja.cni)):
                # même nom, téléphone ou CNI différents : deux personnes, jamais fusionnées en silence
                raise ValueError(f"deux propriétaires différents portent le nom « {d.nom_complet} » "
                                 f"({deja.telephone or deja.cni} et {d.telephone or d.cni}) : distinguez-les dans le "
                                 "fichier, par exemple « " + d.nom_complet + " (Abengourou) »")
            self.r.reutilises["proprietaires"] += 1
            return
        p = Proprietaire(nom_complet=d.nom_complet, telephone=d.telephone or None, cni=d.cni or None,
                         email=d.email or None, ville=d.ville or None)
        self.db.add(p)
        self.db.flush()
        self.proprietaires[norm(p.nom_complet)] = p
        self.r.crees["proprietaires"] += 1

    def bien(self, v: dict, feuille: str, ligne: int) -> None:
        libelles = {c.cle: c.libelle for c in TYPES["biens"][1]} | {"pourcentage_commission": "Commission de gestion (%)"}
        nom_proprio = _texte(v.get("proprietaire"))
        if norm(nom_proprio) in self.homonymes:
            raise ValueError(f"plusieurs propriétaires portent le nom « {nom_proprio} » dans Gérimo : impossible de "
                             "savoir lequel ; rattachez ce bien à la main (Biens → Modifier)")
        proprio = self.proprietaires.get(norm(nom_proprio))
        if proprio is None:
            raise ValueError(f"propriétaire « {nom_proprio} » introuvable : ajoutez-le dans la feuille des propriétaires"
                             if nom_proprio else "« Propriétaire » est obligatoire")
        commission = _montant(v.get("commission"), "Commission de gestion (%)")
        if isinstance(v.get("commission"), float) and commission is not None and 0 < commission < 1:
            commission *= 100  # cellule Excel au format « % » : 0,1 = 10 %
        if commission is None:
            raise ValueError("« Commission de gestion (%) » est obligatoire (0 pour un bien de l'entreprise)")
        try:
            d = NouvelleCite(nom=_texte(v.get("nom")), adresse=_texte(v.get("adresse")) or None,
                             proprietaire_id=proprio.id, pourcentage_commission=commission.quantize(Decimal("0.01")))
        except ValidationError as e:
            raise ValueError(_message_validation(e, libelles))
        if norm(d.nom) in self.biens:
            self.r.reutilises["biens"] += 1
            return
        cite = Cite(nom=d.nom, adresse=d.adresse or None, proprietaire_id=proprio.id,
                    description=_texte(v.get("description"))[:2000] or None)
        definir_commission(self.db, cite, d.pourcentage_commission)
        self.db.add(cite)
        self.db.flush()
        self.biens[norm(cite.nom)] = cite
        self.r.crees["biens"] += 1

    def logement(self, v: dict, feuille: str, ligne: int) -> None:
        libelles = {c.cle: c.libelle for c in TYPES["logements"][1]} | {
            "numero_logement": "Numéro du logement", "statut_logement": "Statut"}
        cite = self.trouver_bien(_texte(v.get("bien")), feuille, ligne)
        try:
            d = LogementIn(
                cite_id=cite.id, numero_logement=_texte(v.get("numero")),
                type_batiment=_choix(v.get("type_batiment"), TYPES_BATIMENT_LOGEMENT, "Type de bien", "Appartement/Immeuble"),
                type_logement=_choix(v.get("type_logement"), TYPES_LOGEMENT_FICHE, "Type de logement"),
                loyer=_montant(v.get("loyer"), "Loyer mensuel"),
                statut_logement=_choix(v.get("statut"), STATUTS_LOGEMENT, "Statut", "Libre"))
        except ValidationError as e:
            raise ValueError(_message_validation(e, libelles))
        cle = (cite.id, norm(d.numero_logement))
        if cle in self.logements:
            self.r.reutilises["logements"] += 1
            return
        logement = Logement(cite_id=cite.id, type_batiment=d.type_batiment, numero_logement=d.numero_logement,
                            type_logement=d.type_logement, loyer=d.loyer, statut_logement=d.statut_logement)
        self.db.add(logement)
        self.db.flush()
        self.logements[cle] = logement
        self.r.crees["logements"] += 1

    def _nouveau_locataire(self, nom: str, telephone: str, autres: dict | None = None) -> Locataire:
        libelles = {c.cle: c.libelle for c in TYPES["locataires"][1]}
        autres = autres or {}
        try:
            d = LocataireIn(nom_complet=nom, telephone=telephone or None, cni=_texte(autres.get("cni")) or None,
                            profession=_texte(autres.get("profession")) or None,
                            email=_texte(autres.get("email")) or None)
        except ValidationError as e:
            raise ValueError(_message_validation(e, libelles))
        loc = Locataire(nom_complet=d.nom_complet, telephone=d.telephone or None, cni=d.cni or None,
                        profession=d.profession or None, email=d.email or None)
        self.db.add(loc)
        self.db.flush()
        self._indexer_locataire(loc)
        self.r.crees["locataires"] += 1
        return loc

    def locataire(self, v: dict, feuille: str, ligne: int) -> None:
        nom, telephone = _texte(v.get("nom_complet")), _telephone(v.get("telephone"))
        if self.trouver_locataire(nom, telephone) is not None:
            self.r.reutilises["locataires"] += 1
            return
        self._nouveau_locataire(nom, telephone, v)

    def contrat(self, v: dict, feuille: str, ligne: int) -> None:
        libelles = {c.cle: c.libelle for c in TYPES["contrats"][1]} | {
            "montant_loyer": "Loyer mensuel", "statut_contrat": "Statut du contrat"}
        cite = self.trouver_bien(_texte(v.get("bien")), feuille, ligne)
        numero_logement = _texte(v.get("logement"))
        logement = self.logements.get((cite.id, norm(numero_logement)))
        if logement is None:
            raise ValueError(f"logement « {numero_logement} » introuvable dans le bien « {cite.nom} » : "
                             "ajoutez-le dans la feuille des logements")
        nom, telephone = _texte(v.get("locataire")), _telephone(v.get("telephone"))
        if not nom:
            raise ValueError("« Locataire » est obligatoire")
        try:
            d = ContratRepris(
                type_contrat=_choix(v.get("type_contrat"), TYPES_CONTRAT, "Type de contrat", "Bail habitation"),
                usage_bien=_choix(v.get("usage_bien"), USAGES_BIEN, "Usage du bien", "Habitation"),
                terme_loyer=_choix(v.get("terme_loyer"), TERMES_LOYER, "Loyer payé en", "Début de mois"),
                montant_loyer=_montant(v.get("loyer"), "Loyer mensuel") or logement.loyer,
                mois_caution=_entier(v.get("mois_caution"), "Mois de caution") or 0,
                mois_avance=1 if v.get("mois_avance") in (None, "") else _entier(v.get("mois_avance"), "Mois d'avance"),
                date_debut=_date(v.get("date_debut"), "Date de début"), date_fin=_date(v.get("date_fin"), "Date de fin"),
                statut_contrat=_choix(v.get("statut"), STATUTS_CONTRAT, "Statut du contrat", "Actif"))
        except ValidationError as e:
            raise ValueError(_message_validation(e, libelles))
        resiliation = _date(v.get("date_resiliation"), "Date de résiliation")
        if d.statut_contrat == "Résilié" and resiliation is None:
            raise ValueError("contrat « Résilié » : indiquez la « Date de résiliation »")
        numero = _texte(v.get("numero"))
        if numero:
            try:
                numero = BaseModelCode(numero=numero).numero
            except ValidationError as e:
                raise ValueError(_message_validation(e, {"numero": "N° de contrat"}))
            if numero.upper().startswith("BAIL-") and not re.fullmatch(r"BAIL-\d{4}-\d{4}", numero.upper()):
                raise ValueError("« N° de contrat » : les numéros « BAIL-… » sont réservés à Gérimo ; "
                                 "laissez vide pour un numéro automatique")
            existant = self.db.query(Contrat).filter(Contrat.numero_contrat == numero).first()
            if existant is not None:
                if existant.logement_id == logement.id:
                    self.r.reutilises["contrats"] += 1
                    return
                raise ValueError(f"le contrat n° {numero} existe déjà (pour un autre logement)")
        locataire = self.trouver_locataire(nom, telephone) or self._nouveau_locataire(nom, telephone)
        doublon = next((c for c in logement.contrats if c.locataire_id == locataire.id and c.date_debut == d.date_debut),
                       None)
        if doublon is not None:
            self.r.reutilises["contrats"] += 1
            return
        if d.statut_contrat in STATUTS_EN_COURS and any(c.statut_contrat in STATUTS_EN_COURS for c in logement.contrats):
            raise ValueError(f"le logement « {numero_logement} » de « {cite.nom} » a déjà un contrat en cours")
        if d.mois_avance == 0 and v.get("suivi_depuis") in (None, ""):  # une reprise n'a pas d'avance à suivre
            self.r.avertir(feuille, ligne, "contrat sans mois d'avance (la règle habituelle est 1 à 3 mois)")
        contrat = Contrat(numero_contrat=numero or prochain_numero(self.db), logement=logement, locataire=locataire,
                          mois_impayes_consecutifs=0)
        try:
            appliquer_conditions(contrat, d)
        except HTTPException as e:
            raise ValueError(e.detail)
        if d.statut_contrat == "Résilié":
            contrat.date_resiliation = resiliation
            contrat.motif_resiliation = "Reprise des données de l'ancien logiciel"
        suivi = _mois(v.get("suivi_depuis"), "Suivi dans Gérimo à partir de")
        if suivi is not None:
            if suivi < paiements.premier_du_mois(d.date_debut):
                raise ValueError("« Suivi dans Gérimo à partir de » est avant le début du bail")
            if suivi > paiements.ajouter_mois(paiements.premier_du_mois(date.today()), 1):
                raise ValueError("« Suivi dans Gérimo à partir de » est trop loin dans le futur")
            contrat.suivi_depuis = suivi
        self.db.add(contrat)
        synchroniser_statut_logement(logement)
        self.db.flush()
        self.r.crees["contrats"] += 1
        self.contrats_touches[contrat.id] = contrat
        if _oui_non(v.get("caution_versee"), "Caution et avance déjà versées", True) and d.statut_contrat != "En attente":
            self._caution_avance_reprise(contrat)

    def _commission(self, c: Contrat):
        mandat = c.logement.cite.mandat_actuel
        if mandat is None:
            raise ValueError(f"la commission de gestion du bien « {c.logement.cite.nom} » n'est pas renseignée")
        return mandat.pourcentage_commission

    def _paiement_repris(self, c: Contrat, parts: list[tuple[date, Decimal, Decimal]], montant_total: Decimal,
                         caution: Decimal, date_paiement: date, mode: str, motif: str) -> Paiement:
        """parts : (mois, part versée sur ce mois, reste du mois après). Un mois est soldé quand son reste est nul ;
        sinon c'est un versement partiel (paiements.py), et le mois garde son reste à payer."""
        pourcentage = self._commission(c)
        loyers = montant_total - caution
        commission = (loyers * pourcentage / 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        p = Paiement(contrat=c, montant=montant_total, date_paiement=date_paiement, statut_paiement="Payé",
                     mode_paiement=mode, motif_paiement=motif,
                     numero_recu=numero_suivant(self.db, Paiement.numero_recu,
                                                f"{paiements.PREFIXE_REPRISE}{date.today().year}", 5),
                     periode_debut=parts[0][0] if parts else None, periode_fin=parts[-1][0] if parts else None,
                     nb_mois=sum(1 for _, _, reste in parts if reste == 0), encaisse_par=self.admin.id,
                     versement_partiel=any(reste > 0 for _, _, reste in parts))
        self.db.add(p)
        if parts:
            paiements.generer_echeances(c, parts[-1][0])
            self.db.flush()
            par_mois = {e.mois_echeance: e for e in c.echeances}
            for m, part, reste in parts:
                e = par_mois[m]
                e.montant_verse = (e.montant_verse or Decimal(0)) + part
                if part > 0:
                    self.db.add(VersementEcheance(echeance=e, paiement=p, montant=part, reste_apres=reste))
                if reste == 0:
                    e.paiement = p
        self.db.add(Encaissement(paiement=p, date_encaissement=date_paiement, montant_encaisse=montant_total,
                                 montant_caution=caution, pourcentage_commission=pourcentage,
                                 commission_entreprise=commission, montant_reverse=loyers - commission,
                                 observation="Reprise de l'ancien logiciel"))
        self.db.flush()
        self.contrats_touches[c.id] = c
        self.r.crees["paiements"] += 1
        return p

    def _caution_avance_reprise(self, c: Contrat) -> None:
        parts = [(m, v, Decimal(0)) for m, v in paiements.prochains_mois_avance(c)]
        total = (c.montant_caution or Decimal(0)) + sum((v for _, v, _ in parts), Decimal(0))
        if total > 0:
            self._paiement_repris(c, parts, total, c.montant_caution or Decimal(0), c.date_debut, "Espèce",
                                  "Caution/avance")

    def paiement(self, v: dict, feuille: str, ligne: int) -> None:
        numero = _texte(v.get("numero_contrat"))
        if numero:
            c = self.db.query(Contrat).filter(Contrat.numero_contrat == numero).first()
            if c is None:
                raise ValueError(f"contrat n° {numero} introuvable")
        else:
            cite = self.trouver_bien(_texte(v.get("bien")), feuille, ligne)
            logement = self.logements.get((cite.id, norm(_texte(v.get("logement")))))
            if logement is None:
                raise ValueError(f"logement « {_texte(v.get('logement'))} » introuvable dans « {cite.nom} » "
                                 "(ou indiquez le N° de contrat)")
            nom = _texte(v.get("locataire"))
            contrats = [c for c in logement.contrats if not nom or norm(c.locataire.nom_complet) == norm(nom)]
            if not contrats:
                raise ValueError(f"aucun contrat pour « {nom or 'ce logement'} » : ajoutez-le dans la feuille des contrats")
            c = max(contrats, key=lambda x: x.date_debut)
        debut = _mois(v.get("mois_debut"), "Mois payé")
        if debut is None:
            raise ValueError("« Mois payé » est obligatoire")
        fin = _mois(v.get("mois_fin"), "Dernier mois payé") or debut
        if fin < debut:
            raise ValueError("le dernier mois payé est avant le premier")
        montant_paye = _montant(v.get("montant"), "Montant")
        if montant_paye is None or montant_paye <= 0:
            raise ValueError("« Montant » est obligatoire et doit être positif")
        date_paiement = _date(v.get("date_paiement"), "Date du paiement")
        if date_paiement is None:
            raise ValueError("« Date du paiement » est obligatoire")
        if date_paiement > date.today():
            raise ValueError("la date du paiement est dans le futur")
        mode = _choix(v.get("mode_paiement"), MODES_PAIEMENT, "Mode de paiement", "Espèce")
        if debut < paiements.premier_du_mois(c.date_debut):
            raise ValueError(f"mois avant le début du contrat ({c.date_debut:%d/%m/%Y})")
        if debut < paiements.debut_suivi(c):
            raise ValueError(f"mois avant le début du suivi dans Gérimo ({paiements.libelle_mois(paiements.debut_suivi(c))}) : "
                             "il est déjà réglé dans l'ancien fichier")
        dernier = paiements.dernier_mois_facturable(c)
        if dernier is not None and fin > dernier:
            raise ValueError("mois après la fin du contrat")
        mois, m = [], debut
        while m <= fin:
            mois.append(m)
            m = paiements.ajouter_mois(m, 1)
        if len(mois) > 60:
            raise ValueError("plus de 60 mois dans un seul paiement : vérifiez les mois")
        paiements.generer_echeances(c, fin)
        self.db.flush()
        par_mois = {e.mois_echeance: e for e in c.echeances}
        deja = [paiements.libelle_mois(x) for x in mois if par_mois[x].paiement is not None]
        if deja:
            raise ValueError(f"déjà payé : {', '.join(deja)} (paiement en double, ou mois couverts par l'avance)")
        # Un versement partiel ne solde pas le mois : le même fichier importé deux fois le compterait deux fois
        for x in mois:
            if any(paiements.est_repris(v.paiement) and v.paiement.date_paiement == date_paiement
                   and v.paiement.montant == montant_paye for v in par_mois[x].versements):
                raise ValueError(f"versement déjà importé sur {paiements.libelle_mois(x)} (même date, même montant)")
        # Le montant solde les mois dans l'ordre ; s'il ne suffit pas, c'est un versement partiel : le dernier mois
        # atteint garde son reste à payer (un mois déjà entamé par un versement précédent ne doit plus que son reste)
        attendu = sum((par_mois[x].reste for x in mois), Decimal(0))
        parts, disponible = [], montant_paye
        for x in mois:
            if disponible <= 0:
                break
            reste = par_mois[x].reste
            part = min(disponible, reste)
            parts.append((x, part, reste - part))
            disponible -= part
        if disponible > 0:
            self.r.avertir(feuille, ligne, f"montant {paiements.francs(montant_paye)} supérieur au loyer attendu "
                                           f"({paiements.francs(attendu)}) : gardé tel quel")
        elif montant_paye < attendu:
            dernier_mois, _, reste = parts[-1]
            suite = (f"reste {paiements.francs(reste)} sur {paiements.libelle_mois(dernier_mois)}" if reste
                     else f"{paiements.libelle_mois(dernier_mois)} soldé")
            non_atteints = len(mois) - len(parts)
            if non_atteints:
                suite += f", {non_atteints} mois non réglé{'s' if non_atteints > 1 else ''}"
            self.r.avertir(feuille, ligne, f"montant {paiements.francs(montant_paye)} inférieur au loyer attendu "
                                           f"({paiements.francs(attendu)}) : versement partiel, {suite}")
        self._paiement_repris(c, parts, montant_paye, Decimal(0), date_paiement, mode, "Loyer mensuel")


class BaseModelCode(BaseModel):
    numero: Code = Field(min_length=1, max_length=40)


def executer(db: SessionDB, admin: Utilisateur, donnees: dict, choix: list[dict]) -> Rapport:
    """Importe les feuilles choisies, dans l'ordre logique (propriétaires d'abord, paiements à la fin).
    Chaque ligne a son point de reprise : une ligne en erreur n'empêche pas de vérifier les suivantes."""
    rapport = Rapport()
    imp = Importeur(db, admin, rapport)
    feuilles = {f["nom"]: f for f in donnees["feuilles"]}
    actions = {"proprietaires": imp.proprietaire, "biens": imp.bien, "logements": imp.logement,
               "locataires": imp.locataire, "contrats": imp.contrat, "paiements": imp.paiement}
    for type_ in ORDRE:
        for c in choix:
            if c.get("type") != type_ or c.get("feuille") not in feuilles:
                continue
            feuille = feuilles[c["feuille"]]
            index = {col: i for i, col in enumerate(feuille["colonnes"])}
            correspondances = {cle: index[col] for cle, col in (c.get("colonnes") or {}).items() if col in index}
            manquants = [ch.libelle for ch in TYPES[type_][1] if ch.obligatoire and ch.cle not in correspondances
                         and not (type_ == "paiements" and ch.cle in ("numero_contrat", "bien", "logement", "locataire"))]
            if manquants:
                rapport.erreur(feuille["nom"], 1, f"colonne à choisir pour : {', '.join(manquants)}")
                continue
            for l in feuille["lignes"]:
                valeurs = {cle: (l["valeurs"][i] if i < len(l["valeurs"]) else None) for cle, i in correspondances.items()}
                point = db.begin_nested()
                try:
                    actions[type_](valeurs, feuille["nom"], l["ligne"])
                    point.commit()
                except ValueError as e:
                    point.rollback()
                    rapport.erreur(feuille["nom"], l["ligne"], str(e).rstrip(".") + ".")
                except DBAPIError as e:
                    point.rollback()
                    rapport.erreur(feuille["nom"], l["ligne"], "refusé par la base de données ("
                                   + str(e.orig).split("\n")[0][:150] + ").")
    aujourdhui = date.today()
    for c in imp.contrats_touches.values():
        paiements.recalculer_contrat(db, c, aujourdhui)
    db.flush()
    return rapport


# ---------- API (Admin) ----------

def _resume(rapport: Rapport) -> dict:
    return {"crees": rapport.crees, "reutilises": rapport.reutilises, "erreurs": rapport.erreurs,
            "avertissements": rapport.avertissements,
            "libelles": {t: TYPES[t][0] for t in ORDRE}}


@router.get("/import/modele")
def modele(admin: Utilisateur = Depends(exiger_admin)):
    """Classeur Excel à remplir : une feuille par type, titres en couleur, listes de choix."""
    import openpyxl
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation
    classeur = openpyxl.Workbook()
    aide = classeur.active
    aide.title = "À lire d'abord"
    lignes = [
        ("Reprise de vos données dans Gérimo", True),
        ("", False),
        ("1. Remplissez les feuilles dans l'ordre : Propriétaires, Biens, Logements, Locataires, Contrats, Paiements.", False),
        ("2. Copiez-collez depuis vos anciens fichiers. Les colonnes en orange sont obligatoires.", False),
        ("3. Les noms doivent être écrits de la même façon d'une feuille à l'autre (ex. le nom du bien).", False),
        ("4. Dates au format jj/mm/aaaa ; mois payés au format mm/aaaa (ex. 10/2026).", False),
        ("5. Une feuille inutile peut rester vide. Un élément déjà présent dans Gérimo n'est pas recréé.", False),
        ("6. Dans Gérimo : Paramètres → Reprise de données → envoyez ce fichier, vérifiez, puis importez.", False),
        ("", False),
        ("Paiements passés : une ligne par paiement (un ou plusieurs mois complets). Ils seront marqués « repris » :", False),
        ("ils règlent les mois concernés, mais Gérimo n'en refait pas les reçus.", False),
    ]
    for i, (texte_ligne, gras) in enumerate(lignes, start=1):
        aide.cell(row=i, column=1, value=texte_ligne).font = Font(bold=gras, size=14 if gras else 11,
                                                                   color="1D3B53" if gras else "000000")
    aide.column_dimensions["A"].width = 120
    orange, marine = PatternFill("solid", fgColor="C1552D"), PatternFill("solid", fgColor="1D3B53")
    listes = {"type_batiment": TYPES_BATIMENT_LOGEMENT, "type_logement": TYPES_LOGEMENT_FICHE, "statut": None,
              "type_contrat": TYPES_CONTRAT, "usage_bien": USAGES_BIEN, "terme_loyer": TERMES_LOYER,
              "mode_paiement": MODES_PAIEMENT, "caution_versee": ("Oui", "Non")}
    for type_ in ORDRE:
        ws = classeur.create_sheet(NOMS_FEUILLES[type_])
        for j, champ in enumerate(TYPES[type_][1], start=1):
            cellule = ws.cell(row=1, column=j, value=champ.libelle)
            cellule.font = Font(bold=True, color="FFFFFF")
            cellule.fill = orange if champ.obligatoire else marine
            cellule.alignment = Alignment(wrap_text=True, vertical="center")
            if champ.aide:
                ws.cell(row=2, column=j, value=None)
            ws.column_dimensions[cellule.column_letter].width = max(16, len(champ.libelle) + 4)
            valeurs = listes.get(champ.cle)
            if champ.cle == "statut":
                valeurs = STATUTS_LOGEMENT if type_ == "logements" else STATUTS_CONTRAT
            if valeurs and type_ != "proprietaires":
                dv = DataValidation(type="list", formula1='"' + ",".join(valeurs) + '"', allow_blank=True,
                                    showErrorMessage=False)
                ws.add_data_validation(dv)
                dv.add(f"{cellule.column_letter}2:{cellule.column_letter}2000")
        ws.freeze_panes = "A2"
        ws.row_dimensions[1].height = 32
    tampon = io.BytesIO()
    classeur.save(tampon)
    return Response(tampon.getvalue(), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": 'attachment; filename="Gerimo_modele_reprise.xlsx"'})


@router.get("/import/champs")
def champs(admin: Utilisateur = Depends(exiger_admin)):
    return {"types": [{"type": t, "libelle": TYPES[t][0],
                       "champs": [{"cle": c.cle, "libelle": c.libelle, "obligatoire": c.obligatoire, "aide": c.aide}
                                  for c in TYPES[t][1]]} for t in ORDRE]}


@router.post("/import/analyser")
async def analyser(request: Request, nom: str = "fichier.xlsx", admin: Utilisateur = Depends(exiger_admin)):
    contenu = b""
    async for morceau in request.stream():
        contenu += morceau
        if len(contenu) > TAILLE_MAX:
            raise HTTPException(status_code=413, detail="Fichier trop gros (30 Mo maximum).")
    nom = Path(nom).name[:200]
    return preparer_assistant(nom, lire_fichier(nom, contenu))


def preparer_assistant(source: str, feuilles: list[dict]) -> dict:
    """Garde les données lues le temps de l'import (fichier Excel ou base d'un ancien logiciel, voir pont.py)
    et devine à quoi correspond chaque feuille et chaque colonne."""
    _menage()
    DOSSIER_TEMP.mkdir(exist_ok=True)
    jeton = secrets.token_urlsafe(18)
    (DOSSIER_TEMP / f"{jeton}.json").write_text(json.dumps({"nom": source, "feuilles": feuilles}, ensure_ascii=False),
                                                encoding="utf-8")
    resultat = []
    for f in feuilles:
        type_ = deviner_type(f)
        resultat.append({
            "feuille": f["nom"], "colonnes": f["colonnes"], "nb_lignes": len(f["lignes"]), "trop": f["trop"],
            "apercu": [l["valeurs"] for l in f["lignes"][:5]], "type": type_,
            "correspondances": correspondance_auto(f["colonnes"], TYPES[type_][1]) if type_ else {},
            "auto": {t: correspondance_auto(f["colonnes"], TYPES[t][1]) for t in ORDRE},
        })
    return {"jeton": jeton, "fichier": source, "feuilles": resultat}


class ChoixImport(BaseModel):
    feuilles: list[dict]  # [{feuille, type, colonnes: {champ: colonne}}]


def _valider_choix(donnees: ChoixImport) -> list[dict]:
    choix = []
    for c in donnees.feuilles:
        if c.get("type") in TYPES and isinstance(c.get("colonnes"), dict):
            choix.append({"feuille": str(c.get("feuille")), "type": c["type"],
                          "colonnes": {str(k): str(v) for k, v in c["colonnes"].items() if v}})
    if not choix:
        raise HTTPException(status_code=400, detail="Choisissez au moins une feuille à importer.")
    return choix


@router.post("/import/{jeton}/verifier")
def verifier(jeton: str, donnees: ChoixImport, admin: Utilisateur = Depends(exiger_admin),
             db: SessionDB = Depends(get_db)):
    """Import « pour de faux » : tout est contrôlé puis annulé ; rien n'est enregistré."""
    contenu = json.loads(_chemin_temp(jeton).read_text(encoding="utf-8"))
    try:
        rapport = executer(db, admin, contenu, _valider_choix(donnees))
    finally:
        db.rollback()
    return _resume(rapport)


@router.post("/import/{jeton}/importer")
def importer(jeton: str, donnees: ChoixImport, admin: Utilisateur = Depends(exiger_admin),
             db: SessionDB = Depends(get_db)):
    chemin = _chemin_temp(jeton)
    contenu = json.loads(chemin.read_text(encoding="utf-8"))
    choix = _valider_choix(donnees)
    db.rollback()
    sauvegarde.creer_sauvegarde("avant-import")  # on peut toujours revenir en arrière
    rapport = executer(db, admin, contenu, choix)
    if rapport.erreurs:
        db.rollback()
        return {"ok": False, **_resume(rapport)}
    transaction = db.execute(text("SELECT txid_current()")).scalar()
    resume = {"crees": rapport.crees, "reutilises": rapport.reutilises,
              "avertissements": len(rapport.avertissements)}
    db.execute(text("INSERT INTO imports (par, source, resume, transaction_id) VALUES (:par, :src, "
                    "CAST(:resume AS JSONB), :tx)"),
               {"par": admin.id, "src": contenu["nom"], "resume": json.dumps(resume), "tx": transaction})
    db.commit()
    chemin.unlink(missing_ok=True)  # le fichier du client n'est pas conservé
    return {"ok": True, **_resume(rapport)}


@router.delete("/import/{jeton}")
def abandonner(jeton: str, admin: Utilisateur = Depends(exiger_admin)):
    try:
        _chemin_temp(jeton).unlink(missing_ok=True)
    except HTTPException:
        pass
    return {"ok": True}


@router.get("/imports")
def historique(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    lignes = db.execute(text("SELECT i.*, u.nom_complet AS qui, a.nom_complet AS annule_qui FROM imports i "
                             "LEFT JOIN utilisateurs u ON u.id = i.par LEFT JOIN utilisateurs a ON a.id = i.annule_par "
                             "ORDER BY i.id DESC LIMIT 50")).all()
    return {"imports": [{"id": l.id, "quand": l.quand.strftime("%d/%m/%Y %H:%M"), "qui": l.qui, "source": l.source,
                         "crees": l.resume.get("crees", {}), "annule": l.annule_le.strftime("%d/%m/%Y %H:%M")
                         if l.annule_le else None, "annule_qui": l.annule_qui} for l in lignes],
            "libelles": {t: TYPES[t][0] for t in ORDRE}}


class AnnulationImport(BaseModel):
    mot_de_passe_admin: str


@router.post("/imports/{import_id}/annuler")
def annuler_import(import_id: int, donnees: AnnulationImport, admin: Utilisateur = Depends(exiger_admin),
                   db: SessionDB = Depends(get_db)):
    """Retire tout ce que l'import a créé (retrouvé dans le journal), si rien n'en dépend depuis."""
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    imp = db.execute(text("SELECT * FROM imports WHERE id = :i"), {"i": import_id}).first()
    if imp is None:
        raise HTTPException(status_code=404, detail="Import introuvable.")
    if imp.annule_le:
        raise HTTPException(status_code=409, detail="Cet import est déjà annulé.")
    lignes = db.execute(text("SELECT * FROM journal WHERE transaction_id = :t AND operation IN ('INSERT', 'UPDATE') "
                             "ORDER BY id"), {"t": imp.transaction_id}).all()
    ajouts = [l for l in lignes if l.operation == "INSERT"]
    contrats_crees = [int(l.ligne_id) for l in ajouts if l.table_nom == "contrats"]
    paiements_crees = [int(l.ligne_id) for l in ajouts if l.table_nom == "paiements"]
    # échéances et impayés (tables techniques, non journalisées) des contrats et paiements importés
    contrats_existants = set()
    if paiements_crees:
        contrats_existants = {c for (c,) in db.execute(text("SELECT DISTINCT contrat_id FROM paiements WHERE id = ANY(:p)"),
                                                       {"p": paiements_crees})} - set(contrats_crees)
        # mois touchés par ces paiements (soldés ou entamés par un versement partiel)
        touchees = [e for (e,) in db.execute(text(
            "SELECT id FROM echeances WHERE paiement_id = ANY(:p) "
            "UNION SELECT echeance_id FROM versements_echeances WHERE paiement_id = ANY(:p)"), {"p": paiements_crees})]
        if db.execute(text("SELECT 1 FROM versements_echeances WHERE echeance_id = ANY(:e) AND paiement_id <> ALL(:p) "
                           "LIMIT 1"), {"e": touchees, "p": paiements_crees}).first():
            raise HTTPException(status_code=409, detail="Annulation impossible : des versements ont été encaissés depuis "
                                                        "sur des mois repris par cet import. Rien n'a été modifié.")
        db.execute(text("DELETE FROM versements_echeances WHERE paiement_id = ANY(:p)"), {"p": paiements_crees})
        db.execute(text("UPDATE echeances SET paiement_id = NULL, montant_verse = 0 WHERE id = ANY(:e)"), {"e": touchees})
    if contrats_crees:
        db.execute(text("DELETE FROM impayes WHERE contrat_id = ANY(:c)"), {"c": contrats_crees})
        db.execute(text("DELETE FROM echeances WHERE contrat_id = ANY(:c)"), {"c": contrats_crees})
    for l in reversed(ajouts):
        condition, valeurs = journal._identifiant(l.table_nom, l.apres)
        point = db.begin_nested()
        try:
            db.execute(text(f'DELETE FROM "{l.table_nom}" WHERE {condition}'), valeurs)
            point.commit()
        except DBAPIError:
            point.rollback()
            db.rollback()
            raise HTTPException(status_code=409, detail="Annulation impossible : des opérations ont été faites depuis "
                                                        "sur ces données (encaissement, document…). Rien n'a été modifié.")
    journal.annuler_modifications(db, [l for l in lignes if l.operation == "UPDATE"])
    db.execute(text("UPDATE imports SET annule_le = LOCALTIMESTAMP, annule_par = :a WHERE id = :i"),
               {"a": admin.id, "i": import_id})
    db.flush()
    for c in db.query(Contrat).filter(Contrat.id.in_(contrats_existants)) if contrats_existants else []:
        paiements.recalculer_contrat(db, c, date.today())
    db.commit()
    return {"ok": True, "retires": len(ajouts)}
