"""Connexion sécurisée (HTTPS) sur le réseau du bureau, sans Internet ni abonnement.

Au premier démarrage, le serveur crée sa propre « autorité de certification Gérimo » (valable 20 ans)
et, avec elle, le certificat du serveur (valable 800 jours, refait tout seul avant expiration ou si
l'adresse du PC serveur change). Chaque poste fait confiance UNE fois à l'autorité Gérimo :
- les PC du bureau : le programme « Gérimo Pro.exe » l'installe lui-même (Windows demande de confirmer) ;
- téléphones et tablettes : page /securiser (fichier à installer, explications pas à pas).
Ensuite tout est chiffré (mots de passe, données) et l'appareil photo fonctionne sur tous les appareils.

Les clés sont dans le dossier certificats/ (hors Git) ; la clé de l'autorité ne quitte jamais le serveur.
"""
import ipaddress
import os
import socket
from datetime import datetime, timedelta, timezone
from pathlib import Path

DOSSIER = Path(__file__).parent / "certificats"
CA_CERT, CA_CLE = DOSSIER / "autorite-gerimo.crt", DOSSIER / "autorite-gerimo.key"
SRV_CERT, SRV_CLE = DOSSIER / "serveur.crt", DOSSIER / "serveur.key"
PORT_HTTPS = int(os.getenv("ISUP_PORT_HTTPS", "8443"))
DUREE_SERVEUR = timedelta(days=800)  # iPhone : 825 jours maximum


def adresses_locales() -> set[str]:
    adresses = {"127.0.0.1"}
    try:
        adresses |= set(socket.gethostbyname_ex(socket.gethostname())[2])
    except OSError:
        pass
    try:  # adresse utilisée vers le réseau (même sans Internet, aucun paquet n'est envoyé)
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            adresses.add(s.getsockname()[0])
    except OSError:
        pass
    return {a for a in adresses if not a.startswith("169.254.")}


def _ecrire(chemin: Path, contenu: bytes) -> None:
    provisoire = chemin.with_suffix(chemin.suffix + ".tmp")
    provisoire.write_bytes(contenu)
    provisoire.replace(chemin)


def _creer_autorite():
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID
    cle = ec.generate_private_key(ec.SECP256R1())
    nom = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, f"Autorité Gérimo ({socket.gethostname()})"),
                     x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Gérimo")])
    maintenant = datetime.now(timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(nom).issuer_name(nom).public_key(cle.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(maintenant - timedelta(days=1)).not_valid_after(maintenant + timedelta(days=365 * 20))
            .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
            .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=True, crl_sign=True,
                                         content_commitment=False, key_encipherment=False, data_encipherment=False,
                                         key_agreement=False, encipher_only=False, decipher_only=False), critical=True)
            .add_extension(x509.SubjectKeyIdentifier.from_public_key(cle.public_key()), critical=False)
            .sign(cle, hashes.SHA256()))
    _ecrire(CA_CLE, cle.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                      serialization.NoEncryption()))
    _ecrire(CA_CERT, cert.public_bytes(serialization.Encoding.PEM))


def _serveur_a_refaire(adresses: set[str]) -> bool:
    if not SRV_CERT.exists() or not SRV_CLE.exists():
        return True
    from cryptography import x509
    cert = x509.load_pem_x509_certificate(SRV_CERT.read_bytes())
    if cert.not_valid_after_utc - datetime.now(timezone.utc) < timedelta(days=60):
        return True
    ca = x509.load_pem_x509_certificate(CA_CERT.read_bytes())
    if cert.issuer != ca.subject:
        return True
    noms = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    return not adresses <= {str(ip) for ip in noms.get_values_for_type(x509.IPAddress)}


def _creer_certificat_serveur(adresses: set[str]) -> None:
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID
    ca_cle = serialization.load_pem_private_key(CA_CLE.read_bytes(), password=None)
    ca = x509.load_pem_x509_certificate(CA_CERT.read_bytes())
    cle = ec.generate_private_key(ec.SECP256R1())
    hote = socket.gethostname()
    noms = [x509.DNSName("localhost"), x509.DNSName(hote)] + \
           [x509.IPAddress(ipaddress.ip_address(a)) for a in sorted(adresses)]
    maintenant = datetime.now(timezone.utc)
    cert = (x509.CertificateBuilder()
            .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, f"Serveur Gérimo {hote}")]))
            .issuer_name(ca.subject).public_key(cle.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(maintenant - timedelta(days=1)).not_valid_after(maintenant + DUREE_SERVEUR)
            .add_extension(x509.SubjectAlternativeName(noms), critical=False)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
            .add_extension(x509.KeyUsage(digital_signature=True, key_encipherment=False, key_cert_sign=False,
                                         crl_sign=False, content_commitment=False, data_encipherment=False,
                                         key_agreement=True, encipher_only=False, decipher_only=False), critical=True)
            .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_cle.public_key()), critical=False)
            .sign(ca_cle, hashes.SHA256()))
    _ecrire(SRV_CLE, cle.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                       serialization.NoEncryption()))
    _ecrire(SRV_CERT, cert.public_bytes(serialization.Encoding.PEM))


def preparer() -> tuple[Path, Path]:
    """Crée ou renouvelle ce qu'il faut ; renvoie (certificat, clé) du serveur pour uvicorn."""
    DOSSIER.mkdir(exist_ok=True)
    if not CA_CERT.exists() or not CA_CLE.exists():
        _creer_autorite()
        SRV_CERT.unlink(missing_ok=True)
    adresses = adresses_locales()
    if _serveur_a_refaire(adresses):
        _creer_certificat_serveur(adresses)
    return SRV_CERT, SRV_CLE


def empreinte_autorite() -> str | None:
    """Empreinte SHA-256 de l'autorité (pour vérifier qu'on installe bien la bonne)."""
    if not CA_CERT.exists():
        return None
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes
    brut = x509.load_pem_x509_certificate(CA_CERT.read_bytes()).fingerprint(hashes.SHA256()).hex().upper()
    return " ".join(brut[i:i + 4] for i in range(0, len(brut), 4))


def disponible() -> bool:
    return CA_CERT.exists() and SRV_CERT.exists()


def prouver_identite(defi: str) -> dict | None:
    """Signe un défi avec la clé de l'autorité : l'application Android vérifie ainsi, même en http, qu'elle parle
    au serveur de SON agence (un autre appareil du Wi-Fi ne possède pas cette clé). None si pas d'autorité."""
    if not (CA_CERT.exists() and CA_CLE.exists()):
        return None
    import base64
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    cle = serialization.load_pem_private_key(CA_CLE.read_bytes(), password=None)
    signature = cle.sign(f"gerimo/identite/v1\n{defi}".encode(), ec.ECDSA(hashes.SHA256()))
    return {"autorite": CA_CERT.read_text(encoding="ascii"), "signature": base64.b64encode(signature).decode()}
