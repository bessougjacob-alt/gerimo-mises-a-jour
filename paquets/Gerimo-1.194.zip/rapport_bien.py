"""Rapport mensuel par bien (cité, immeuble, maison, cour…) : à imprimer ou à exporter vers Excel.

Pour chaque logement du bien : type et numéro, locataire et son contact, loyer mensuel, loyers encaissés,
commission de gestion, part du propriétaire, loyer impayé et dépenses ; puis les dépenses communes du bien,
le détail des dépenses et le net à reverser au propriétaire.
Mêmes calculs que le rapport détaillé (rapports.py) : un encaissement compte à sa date de paiement ;
la caution n'entre ni dans la commission ni dans la part du propriétaire ; un loyer est impayé quand son mois
est dans la période, qu'il n'est pas réglé et que sa date limite (le 05) est passée.
Droits : Admin, Caisse, Comptable = tout ; Gestionnaire = ses biens, sans propriétaire ni commission.
"""
import io
import re
import unicodedata
from datetime import date, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy.orm import Session as SessionDB, selectinload

import recus
from commun import montant, voit_finances
from models import Cite, Contrat, Echeance, Logement, Utilisateur
from paiements import libelle_mois, premier_du_mois, recalculer_tout
from rapports import _dans_perimetre, _depenses, _encaissements, _periode, _repartition, acces_rapports
from securite import get_db

router = APIRouter(prefix="/api")
ZERO = Decimal(0)


def libelle_de_periode(debut: date, fin: date) -> str:
    """« Octobre 2026 » pour un mois entier (ou le mois en cours jusqu'à aujourd'hui), sinon « du … au … »."""
    lendemain = fin + timedelta(days=1)
    if debut.day == 1 and (debut.year, debut.month) == (fin.year, fin.month) \
            and (lendemain.day == 1 or fin == date.today()):
        return libelle_mois(debut).capitalize()
    return f"du {debut.strftime('%d/%m/%Y')} au {fin.strftime('%d/%m/%Y')}"


def _fin_contrat(c: Contrat) -> date | None:
    fin = c.date_resiliation if c.statut_contrat == "Résilié" else c.date_fin
    if c.date_depart and c.statut_contrat != "Résilié" and (fin is None or c.date_depart < fin):
        fin = c.date_depart
    return fin


def _type_bien(cite: Cite) -> str:
    types = sorted({l.type_batiment for l in cite.logements if l.type_batiment})
    return ", ".join(types) or "—"


def _cle_numero(numero: str):
    """Tri naturel des numéros de logement : A2 avant A10."""
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r"(\d+)", numero or "")]


def construire(db: SessionDB, utilisateur: Utilisateur, debut: date, fin: date, cite_id: int | None) -> dict:
    finances = voit_finances(utilisateur)
    perimetre = _dans_perimetre(utilisateur)
    aujourdhui = date.today()
    requete = db.query(Cite).options(selectinload(Cite.logements), selectinload(Cite.proprietaire),
                                     selectinload(Cite.mandats))
    if cite_id is not None:
        cite = requete.filter(Cite.id == cite_id).first()
        if cite is None or not perimetre(cite.id):
            raise HTTPException(status_code=404, detail="Bien introuvable (ou hors de vos biens).")
        cites = [cite]
    else:
        cites = [c for c in requete.order_by(Cite.nom) if perimetre(c.id) and c.logements]
    ids = {c.id for c in cites}

    # contrats des logements de ces biens, avec leurs échéances (mises à jour avant lecture)
    contrats = db.query(Contrat).join(Logement).options(
        selectinload(Contrat.echeances).selectinload(Echeance.paiement), selectinload(Contrat.locataire),
        selectinload(Contrat.logement)).filter(Logement.cite_id.in_(ids)).all() if ids else []
    recalculer_tout(db, contrats)

    paiements = [p for p in _encaissements(db, debut, fin, utilisateur) if p.contrat.logement.cite_id in ids]
    depenses = [d for d in _depenses(db, debut, fin, utilisateur) if d.cite_id in ids]
    mois_debut = premier_du_mois(debut)

    # Lignes : un contrat qui couvre la période (ou qui a payé pendant la période) = une ligne
    lignes: dict = {}

    def ligne(logement: Logement, contrat: Contrat | None, sejours: bool = False) -> dict:
        cle = ("contrat", contrat.id) if contrat else ("sejours" if sejours else "libre", logement.id)
        if cle not in lignes:
            lignes[cle] = {
                "logement_id": logement.id, "cite_id": logement.cite_id, "numero": logement.numero_logement,
                "type_logement": logement.type_logement,
                "locataire": contrat.locataire.nom_complet if contrat else
                ("Séjours courte durée" if sejours else f"— ({logement.statut_logement})"),
                "telephone": (contrat.locataire.telephone or "") if contrat else "",
                "numero_contrat": contrat.numero_contrat if contrat else "",
                "loyer_mensuel": contrat.montant_loyer if contrat else logement.loyer,
                "encaisse": ZERO, "cautions": ZERO, "commission": ZERO, "impaye": ZERO, "mois_impayes": [],
                "depenses": ZERO, "_debut": contrat.date_debut if contrat else date.min,
            }
        return lignes[cle]

    for c in contrats:
        fin_c = _fin_contrat(c)
        if c.date_debut <= fin and (fin_c is None or fin_c >= debut):
            ligne(c.logement, c)
        for e in c.echeances:  # loyers du mois (ou des mois) de la période, échus et non réglés
            if mois_debut <= e.mois_echeance <= fin and e.paiement is None and e.date_limite < aujourdhui:
                l = ligne(c.logement, c)
                l["impaye"] += e.reste
                l["mois_impayes"].append(libelle_mois(e.mois_echeance))
    for p in paiements:
        loyers, caution, commission = _repartition(p)
        contrat = p.contrat if isinstance(p.contrat, Contrat) else None
        l = ligne(p.contrat.logement, contrat, sejours=contrat is None)
        l["encaisse"] += loyers
        l["cautions"] += caution
        l["commission"] += commission
    for d in depenses:
        if d.logement_id:
            occupees = [l for l in lignes.values() if l["logement_id"] == d.logement_id]
            (max(occupees, key=lambda l: l["_debut"]) if occupees else ligne(d.logement, None))["depenses"] += d.montant
    # logements sans locataire ni mouvement : une ligne quand même (le rapport montre tout le bien)
    for c in cites:
        for lg in c.logements:
            if not any(l["logement_id"] == lg.id for l in lignes.values()):
                ligne(lg, None)

    biens = []
    for c in cites:
        rangs = sorted((l for l in lignes.values() if l["cite_id"] == c.id),
                       key=lambda l: (_cle_numero(l["numero"]), l["_debut"]))
        deps = sorted((d for d in depenses if d.cite_id == c.id), key=lambda d: (d.date_depense, d.id))
        communes = sum((d.montant for d in deps if not d.logement_id), ZERO)
        dep_proprio = sum((d.montant for d in deps if d.a_la_charge_de == "Propriétaire"), ZERO)
        t = {k: sum((l[k] for l in rangs), ZERO) for k in ("encaisse", "cautions", "commission", "impaye", "depenses")}
        t["depenses"] += communes
        bien = {
            "cite_id": c.id, "bien": c.nom, "type_bien": _type_bien(c), "adresse": c.adresse or "",
            "nb_logements": len(c.logements),
            "occupes": sum(1 for l in c.logements if l.statut_logement == "Occupé"),
            "lignes": [{
                "numero": l["numero"], "type_logement": l["type_logement"], "locataire": l["locataire"],
                "telephone": l["telephone"], "numero_contrat": l["numero_contrat"],
                "loyer_mensuel": montant(l["loyer_mensuel"]), "encaisse": montant(l["encaisse"]),
                "impaye": montant(l["impaye"]), "mois_impayes": l["mois_impayes"], "depenses": montant(l["depenses"]),
                **({"commission": montant(l["commission"]),
                    "part_proprietaire": montant(l["encaisse"] - l["commission"])} if finances else {}),
            } for l in rangs],
            "depenses_communes": montant(communes),
            "detail_depenses": [{
                "date": d.date_depense.isoformat(), "logement": d.logement.numero_logement if d.logement else "Commune",
                "motif": d.motif, "categorie": d.categorie, "a_la_charge_de": d.a_la_charge_de,
                "montant": montant(d.montant)} for d in deps],
            "totaux": {"loyer_mensuel": montant(sum((l["loyer_mensuel"] for l in rangs), ZERO)),
                       "encaisse": montant(t["encaisse"]), "cautions": montant(t["cautions"]),
                       "impaye": montant(t["impaye"]), "depenses": montant(t["depenses"])},
        }
        if finances:
            mandat = c.mandat_actuel
            bien["proprietaire"] = c.proprietaire.nom_complet if c.proprietaire else "Non renseigné"
            bien["proprietaire_telephone"] = (c.proprietaire.telephone or "") if c.proprietaire else ""
            bien["pourcentage_commission"] = montant(mandat.pourcentage_commission) if mandat else None
            bien["totaux"].update(
                commission=montant(t["commission"]), part_proprietaire=montant(t["encaisse"] - t["commission"]),
                depenses_proprietaire=montant(dep_proprio),
                net_a_reverser=montant(t["encaisse"] - t["commission"] - dep_proprio))
        biens.append(bien)
    return {"debut": debut.isoformat(), "fin": fin.isoformat(), "periode": libelle_de_periode(debut, fin),
            "finances": finances, "biens": biens}


def _nom_fichier(rapport: dict, extension: str) -> str:
    sujet = rapport["biens"][0]["bien"] if len(rapport["biens"]) == 1 else "tous_les_biens"
    ascii_ = unicodedata.normalize("NFKD", sujet).encode("ascii", "ignore").decode()
    sujet = "".join(ch if ch.isalnum() else "_" for ch in ascii_).strip("_")[:40] or "bien"
    return f"rapport_{sujet}_{rapport['debut'][:7]}.{extension}"


def _charger(db, utilisateur, debut, fin, cite_id) -> dict:
    rapport = construire(db, utilisateur, *_periode(debut, fin), cite_id)
    if not rapport["biens"]:
        raise HTTPException(status_code=404, detail="Aucun bien avec des logements à présenter.")
    return rapport


@router.get("/rapports/par-bien/biens")
def liste_biens(utilisateur: Utilisateur = Depends(acces_rapports), db: SessionDB = Depends(get_db)):
    """Biens proposés dans la liste (la Caisse et le Comptable n'ont pas accès au module Biens)."""
    perimetre = _dans_perimetre(utilisateur)
    return [{"id": c.id, "nom": c.nom} for c in db.query(Cite).options(selectinload(Cite.logements)).order_by(Cite.nom)
            if perimetre(c.id) and c.logements]


@router.get("/rapports/par-bien")
def rapport_par_bien(cite_id: int | None = Query(None), debut: date | None = Query(None),
                     fin: date | None = Query(None), utilisateur: Utilisateur = Depends(acces_rapports),
                     db: SessionDB = Depends(get_db)):
    return construire(db, utilisateur, *_periode(debut, fin), cite_id)


@router.get("/rapports/par-bien/pdf")
def rapport_par_bien_pdf(cite_id: int | None = Query(None), debut: date | None = Query(None),
                         fin: date | None = Query(None), utilisateur: Utilisateur = Depends(acces_rapports),
                         db: SessionDB = Depends(get_db)):
    rapport = _charger(db, utilisateur, debut, fin, cite_id)
    contenu = recus.rapport_par_bien_pdf(rapport)
    return Response(contenu, media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="{_nom_fichier(rapport, "pdf")}"'})


# ---------- Excel (.xlsx mis en forme) ----------

def classeur_excel(rapport: dict) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

    finances = rapport["finances"]
    marine, vert_clair = "1D3B53", "EEF5E8"
    titre_police = Font(bold=True, size=14, color="C1552D")
    gras = Font(bold=True)
    entete_police = Font(bold=True, color="FFFFFF")
    entete_fond = PatternFill("solid", fgColor=marine)
    total_fond = PatternFill("solid", fgColor=vert_clair)
    trait = Side(style="thin", color="D5DBD3")
    cadre = Border(left=trait, right=trait, top=trait, bottom=trait)
    format_f = '#,##0" F"'

    colonnes = [("N°", 8), ("Type de logement", 18), ("Locataire", 28), ("Contact", 16), ("Loyer mensuel", 15),
                ("Loyer encaissé", 15)]
    if finances:
        colonnes += [("Commission agence", 16), ("Part propriétaire", 17)]
    colonnes += [("Loyer impayé", 14), ("Mois impayés", 22), ("Dépenses", 13)]
    cles = ["numero", "type_logement", "locataire", "telephone", "loyer_mensuel", "encaisse"] + \
           (["commission", "part_proprietaire"] if finances else []) + ["impaye", "mois_impayes", "depenses"]
    nombres = {"loyer_mensuel", "encaisse", "commission", "part_proprietaire", "impaye", "depenses"}

    classeur = Workbook()
    classeur.remove(classeur.active)
    noms_pris = set()
    for b in rapport["biens"]:
        nom = re.sub(r"[\\/*?:\[\]]", " ", b["bien"])[:28].strip() or "Bien"
        base, n = nom, 2
        while nom.lower() in noms_pris:
            nom = f"{base[:25]} ({n})"
            n += 1
        noms_pris.add(nom.lower())
        f = classeur.create_sheet(nom)
        f.sheet_view.showGridLines = False
        f.page_setup.orientation = "landscape"
        f.page_setup.fitToWidth = 1
        f.page_setup.fitToHeight = 0
        f.sheet_properties.pageSetUpPr.fitToPage = True

        f["A1"] = f"Rapport mensuel — {b['bien']}"
        f["A1"].font = titre_police
        infos = [("Entreprise", recus.ENTETE["nom"]), ("Période", rapport["periode"]),
                 ("Type de bien", b["type_bien"]), ("Adresse", b["adresse"]),
                 ("Logements", f"{b['nb_logements']} dont {b['occupes']} occupé(s)")]
        if finances:
            infos[2:2] = [("Propriétaire", b["proprietaire"]), ("Contact du propriétaire", b["proprietaire_telephone"])]
            if b["pourcentage_commission"] is not None:
                infos.append(("Commission de gestion", f"{str(b['pourcentage_commission']).replace('.', ',')} %"))
        for i, (libelle, valeur) in enumerate(infos, start=3):
            f.cell(i, 1, libelle).font = Font(color="5C655E")
            f.cell(i, 3, valeur).font = gras
        ligne = 4 + len(infos)
        for j, (titre, largeur) in enumerate(colonnes, start=1):
            c = f.cell(ligne, j, titre)
            c.font, c.fill, c.border = entete_police, entete_fond, cadre
            c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            f.column_dimensions[c.column_letter].width = largeur
        f.row_dimensions[ligne].height = 30
        premiere = ligne + 1
        for r in b["lignes"]:
            ligne += 1
            for j, cle in enumerate(cles, start=1):
                v = r[cle]
                v = ", ".join(v) if isinstance(v, list) else v
                c = f.cell(ligne, j, float(v) if cle in nombres else v)
                c.border = cadre
                if cle in nombres:
                    c.number_format = format_f
        if b["depenses_communes"]:
            ligne += 1
            f.cell(ligne, 3, "Dépenses communes du bien").font = Font(italic=True)
            c = f.cell(ligne, cles.index("depenses") + 1, float(b["depenses_communes"]))
            c.number_format = format_f
            for j in range(1, len(cles) + 1):
                f.cell(ligne, j).border = cadre
        ligne += 1
        f.cell(ligne, 1, "TOTAL")
        for j, cle in enumerate(cles, start=1):
            c = f.cell(ligne, j)
            c.font, c.fill, c.border = gras, total_fond, cadre
            if cle in nombres:
                lettre = c.column_letter
                c.value = f"=SUM({lettre}{premiere}:{lettre}{ligne - 1})"
                c.number_format = format_f
        f.freeze_panes = f.cell(premiere, 1)

        # récapitulatif
        t = b["totaux"]
        recap = [("Loyers encaissés", t["encaisse"]), ("Cautions perçues (non reversées)", t["cautions"])]
        if finances:
            recap += [("Commission de l'agence", t["commission"]), ("Part du propriétaire", t["part_proprietaire"]),
                      ("Dépenses à la charge du propriétaire", t["depenses_proprietaire"]),
                      ("Net à reverser au propriétaire", t["net_a_reverser"])]
        recap += [("Loyers impayés", t["impaye"]), ("Total des dépenses", t["depenses"])]
        ligne += 2
        f.cell(ligne, 1, "Récapitulatif").font = Font(bold=True, color=marine, size=12)
        for libelle, valeur in recap:
            ligne += 1
            f.cell(ligne, 1, libelle)
            c = f.cell(ligne, 5, float(valeur))
            c.number_format = format_f
            if libelle.startswith("Net"):
                f.cell(ligne, 1).font = c.font = gras

        # détail des dépenses
        ligne += 2
        f.cell(ligne, 1, "Détail des dépenses").font = Font(bold=True, color=marine, size=12)
        ligne += 1
        for j, titre in enumerate(("Date", "Logement", "Motif", "Catégorie", "À la charge de", "Montant"), start=1):
            c = f.cell(ligne, j, titre)
            c.font, c.fill, c.border = entete_police, entete_fond, cadre
        for d in b["detail_depenses"]:
            ligne += 1
            valeurs = ("/".join(reversed(d["date"].split("-"))), d["logement"], d["motif"], d["categorie"],
                       d["a_la_charge_de"], float(d["montant"]))
            for j, v in enumerate(valeurs, start=1):
                c = f.cell(ligne, j, v)
                c.border = cadre
            c.number_format = format_f
        if not b["detail_depenses"]:
            f.cell(ligne + 1, 1, "Aucune dépense sur la période.").font = Font(italic=True, color="5C655E")
    tampon = io.BytesIO()
    classeur.save(tampon)
    return tampon.getvalue()


@router.get("/rapports/par-bien/excel")
def rapport_par_bien_excel(cite_id: int | None = Query(None), debut: date | None = Query(None),
                           fin: date | None = Query(None), utilisateur: Utilisateur = Depends(acces_rapports),
                           db: SessionDB = Depends(get_db)):
    rapport = _charger(db, utilisateur, debut, fin, cite_id)
    return Response(classeur_excel(rapport),
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{_nom_fichier(rapport, "xlsx")}"'})

