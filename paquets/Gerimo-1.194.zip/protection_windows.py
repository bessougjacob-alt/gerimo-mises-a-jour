"""Protection de Windows contre les ransomware (« Dispositif d'accès contrôlé aux dossiers ») : Gérimo s'y fait autoriser.

Quand cette protection est active, Windows interdit aux programmes qu'il ne connaît pas d'écrire dans Documents,
Bureau, Images… Gérimo Serveur (installé dans Documents) ne peut alors plus écrire ses journaux, et pg_dump ne peut
plus faire les sauvegardes (vécu chez ISUP du 09 au 12/10/2026 : plus aucune sauvegarde, serveur planté).

Au démarrage, Gérimo Serveur regarde si la protection bloque (réglage 1 ; 2 = simple audit, 3 et 4 = disques seulement).
Si oui, et si ses programmes n'ont pas encore été autorisés, il demande à Windows de les autoriser : Windows affiche
sa fenêtre « Voulez-vous autoriser… » (droits Admin), une seule fois. Le choix est noté dans
journaux/protection_windows.txt (programmes autorisés) pour ne plus redemander.
Programmes autorisés : Gérimo Serveur.exe, et pg_dump, psql, pg_restore de PostgreSQL (sauvegardes et restaurations).

Au même moment, le pare-feu de Windows est réglé pour n'ouvrir Gérimo Serveur qu'au réseau local (pare_feu.py).

Ce fichier est mis à jour en ligne avec le reste du logiciel.
"""
import base64
import subprocess
from datetime import datetime
from pathlib import Path

FICHIER = "protection_windows.txt"   # dans journaux/ : programmes déjà autorisés, un par ligne
SANS_FENETRE = 0x08000000            # CREATE_NO_WINDOW
BLOQUE = "1"                          # EnableControlledFolderAccess : 1 = protection active (bloque)


def _powershell(script: str, delai: int = 30) -> subprocess.CompletedProcess:
    return subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], capture_output=True,
                          text=True, timeout=delai, creationflags=SANS_FENETRE, stdin=subprocess.DEVNULL)


def protection_active() -> bool:
    """True si la protection des dossiers bloque les programmes inconnus (lecture possible sans droits Admin)."""
    try:
        r = _powershell("(Get-MpPreference).EnableControlledFolderAccess")
        return r.stdout.strip() == BLOQUE
    except (OSError, subprocess.SubprocessError):
        return False


def programmes(executable: str) -> list[str]:
    """Programmes de Gérimo qui écrivent dans le dossier du logiciel."""
    liste = [str(Path(executable))]
    try:
        import sauvegarde
        for outil in ("pg_dump", "psql", "pg_restore"):
            try:
                liste.append(str(Path(sauvegarde.outil_postgres(outil))))
            except Exception:  # noqa: BLE001 — outil absent : rien à autoriser
                pass
    except Exception:  # noqa: BLE001
        pass
    return liste


def deja_autorises(dossier: Path) -> set[str]:
    try:
        return {ligne.strip().lower() for ligne in (dossier / "journaux" / FICHIER).read_text(encoding="utf-8").splitlines()
                if ligne.strip() and not ligne.startswith("#")}
    except OSError:
        return set()


def a_autoriser(dossier: Path, executable: str) -> list[str]:
    connus = deja_autorises(dossier)
    return [p for p in programmes(executable) if p.lower() not in connus]


def script_autorisation(liste: list[str]) -> str:
    """Script exécuté avec les droits Admin : ajoute chaque programme aux applications autorisées."""
    lignes = [f"Add-MpPreference -ControlledFolderAccessAllowedApplications '{p.replace(chr(39), chr(39) * 2)}'"
              for p in liste]
    return "try { " + "; ".join(lignes) + "; exit 0 } catch { exit 1 }"


def demander_autorisation(liste: list[str]) -> bool:
    """Fenêtre de Windows « Voulez-vous autoriser… » (UAC), puis ajout des programmes. True si c'est fait."""
    code = base64.b64encode(script_autorisation(liste).encode("utf-16-le")).decode()
    externe = ("try { $p = Start-Process powershell -Verb RunAs -Wait -PassThru -WindowStyle Hidden "
               f"-ArgumentList '-NoProfile','-NonInteractive','-EncodedCommand','{code}'; exit $p.ExitCode }} "
               "catch { exit 2 }")  # 2 : l'utilisateur a répondu Non
    try:
        return _powershell(externe, delai=600).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def noter_autorises(dossier: Path, liste: list[str]) -> None:
    fichier = dossier / "journaux" / FICHIER
    try:
        existants = fichier.read_text(encoding="utf-8") if fichier.exists() else \
            "# Programmes autorisés par la protection de Windows contre les ransomware (protection_windows.py)\n"
        fichier.write_text(existants + f"# {datetime.now():%d/%m/%Y %H:%M}\n" + "".join(p + "\n" for p in liste),
                           encoding="utf-8")
    except OSError:
        pass


def verifier(dossier: Path, executable: str) -> str | None:
    """Appelé au démarrage de Gérimo Serveur. Renvoie un message pour sa fenêtre, ou None si rien à signaler."""
    messages = [m for m in (verifier_dossiers(dossier, executable), _pare_feu(dossier, executable)) if m]
    return "\n".join(messages) or None


def _pare_feu(dossier: Path, executable: str) -> str | None:
    try:
        import pare_feu
        return pare_feu.verifier(dossier, executable)
    except Exception:  # noqa: BLE001 — le pare-feu est un plus : le serveur démarre quoi qu'il arrive
        return None


def verifier_dossiers(dossier: Path, executable: str) -> str | None:
    if not protection_active():
        return None
    liste = a_autoriser(dossier, executable)
    if not liste:
        return None
    if demander_autorisation(liste):
        noter_autorises(dossier, liste)
        return "✅ Protection de Windows contre les ransomware : Gérimo et ses sauvegardes sont maintenant autorisés."
    return ("⚠ La protection de Windows contre les ransomware empêche Gérimo d'écrire dans ce dossier (sauvegardes "
            "comprises). Relancez Gérimo Serveur et répondez « Oui » à Windows, ou autorisez-le dans Sécurité Windows "
            "→ Protection contre les ransomware → Autoriser une application via l'accès contrôlé aux dossiers.")
