"""Exports des listes vers Excel (fichier CSV lisible directement par Excel en français).

Chaque export respecte les droits : mêmes modules et même périmètre (Gestionnaire : ses biens)
que l'écran correspondant ; les commissions ne sont exportées que pour l'Admin.
Format : séparateur « ; », encodage UTF-8 avec BOM (accents corrects dans Excel), dates jj/mm/aaaa.
"""
import csv
import io
import re
import unicodedata
from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy.orm import Session as SessionDB, selectinload

import recus
from commun import est_admin, montant
from models import (AchatVente, Cite, Contrat, Depense, Locataire, Logement, Paiement, Prospect, Proprietaire,
                    Signalement, Utilisateur)
from paiements import contrats_du_perimetre, libelle_periode, recalculer_tout, resume_impayes
from securite import cites_autorisees, get_db, peut_acceder, utilisateur_connecte

router = APIRouter(prefix="/api")

# export → module dont il faut avoir l'accès
MODULE_EXPORT = {
    "proprietaires": "proprietaires", "biens": "biens", "locataires": "locataires", "contrats": "contrats",
    "paiements": "paiements", "impayes": "paiements", "depenses": "depenses", "achats_ventes": "achats_ventes",
    "prospects": "prospects", "signalements": "biens",
}


def d(valeur: date | None) -> str:
    return valeur.strftime("%d/%m/%Y") if valeur else ""


def n(valeur) -> str:
    """Nombre au format français pour Excel : 75000,5."""
    if valeur is None:
        return ""
    return str(montant(valeur)).replace(".", ",")


def _perimetre(u: Utilisateur):
    autorisees = cites_autorisees(u)
    return lambda cite_id: autorisees is None or cite_id in autorisees


def lignes_export(db: SessionDB, u: Utilisateur, quoi: str, debut: date | None, fin: date | None):
    ok = _perimetre(u)
    admin = est_admin(u)
    if quoi == "proprietaires":
        yield ["Nom complet", "CNI", "Téléphone", "E-mail", "Ville", "Biens"]
        for p in db.query(Proprietaire).options(selectinload(Proprietaire.cites)).order_by(Proprietaire.nom_complet):
            yield [p.nom_complet, p.cni, p.telephone, p.email, p.ville, ", ".join(c.nom for c in p.cites)]
    elif quoi == "biens":
        entete = ["Bien", "Adresse", "Type de bien", "Logement", "Type de logement", "Loyer (F CFA)", "Statut"]
        yield entete + (["Propriétaire", "Commission de gestion (%)"] if admin else [])
        for c in db.query(Cite).options(selectinload(Cite.logements), selectinload(Cite.proprietaire),
                                        selectinload(Cite.mandats)).order_by(Cite.nom):
            if not ok(c.id):
                continue
            plus = ([c.proprietaire.nom_complet if c.proprietaire else "",
                     n(c.mandat_actuel.pourcentage_commission) if c.mandat_actuel else ""] if admin else [])
            for l in c.logements:
                yield [c.nom, c.adresse, l.type_batiment, l.numero_logement, l.type_logement, n(l.loyer),
                       l.statut_logement] + plus
    elif quoi == "locataires":
        yield ["Nom complet", "CNI", "Téléphone", "E-mail", "Profession", "Contrats"]
        for l in db.query(Locataire).options(selectinload(Locataire.contrats).selectinload(Contrat.logement)
                                             .selectinload(Logement.cite)).order_by(Locataire.nom_complet):
            contrats = [c for c in l.contrats if ok(c.logement.cite_id)]
            if contrats or cites_autorisees(u) is None:
                yield [l.nom_complet, l.cni, l.telephone, l.email, l.profession,
                       " ; ".join(f"{c.numero_contrat} ({c.statut_contrat})" for c in contrats)]
    elif quoi == "contrats":
        yield ["N° contrat", "Locataire", "Téléphone", "Bien", "Logement", "Type de contrat", "Usage", "Loyer (F CFA)",
               "Terme", "Caution (mois)", "Avance (mois)", "Début", "Fin", "Statut", "Mois impayés consécutifs"]
        for c in contrats_du_perimetre(db, u):
            yield [c.numero_contrat, c.locataire.nom_complet, c.locataire.telephone, c.logement.cite.nom,
                   c.logement.numero_logement, c.type_contrat, c.usage_bien, n(c.montant_loyer), c.terme_loyer,
                   c.mois_caution, c.mois_avance, d(c.date_debut), d(c.date_fin), c.statut_contrat,
                   c.mois_impayes_consecutifs]
    elif quoi == "paiements":
        entete = ["N° reçu", "Date", "Locataire", "Contrat", "Logement", "Motif", "Période", "Mode", "Montant (F CFA)",
                  "Statut", "Encaissé par"]
        yield entete + (["Caution", "Commission de gestion", "Reversé au propriétaire"] if admin else [])
        requete = db.query(Paiement).options(selectinload(Paiement.encaissement), selectinload(Paiement.caissier),
                                             selectinload(Paiement.contrat).selectinload(Contrat.locataire),
                                             selectinload(Paiement.contrat).selectinload(Contrat.logement)
                                             .selectinload(Logement.cite))
        if debut:
            requete = requete.filter(Paiement.date_paiement >= debut)
        if fin:
            requete = requete.filter(Paiement.date_paiement <= fin)
        for p in requete.order_by(Paiement.date_paiement, Paiement.id):
            c = p.contrat
            if not ok(c.logement.cite_id):
                continue
            ligne = [p.numero_recu, d(p.date_paiement), c.locataire.nom_complet, c.numero_contrat,
                     f"{c.logement.numero_logement}, {c.logement.cite.nom}", p.motif_paiement,
                     libelle_periode(p.periode_debut, p.periode_fin), p.mode_paiement, n(p.montant), p.statut_paiement,
                     p.caissier.nom_complet if p.caissier else ""]
            if admin:
                e = p.encaissement
                ligne += [n(e.montant_caution) if e else "", n(e.commission_entreprise) if e else "",
                          n(e.montant_reverse) if e else ""]
            yield ligne
    elif quoi == "impayes":
        yield ["Locataire", "Téléphone", "Contrat", "Logement", "Mois dus", "Montant dû (F CFA)", "Détail", "À risque"]
        contrats = contrats_du_perimetre(db, u)
        recalculer_tout(db, contrats)
        for c in contrats:
            r = resume_impayes(c, date.today())
            if r:
                yield [c.locataire.nom_complet, c.locataire.telephone, c.numero_contrat,
                       f"{c.logement.numero_logement}, {c.logement.cite.nom}", r["nb_mois"], n(r["montant"]),
                       ", ".join(r["mois"]), "Oui" if r["a_risque"] else "Non"]
    elif quoi == "depenses":
        yield ["Date", "Bien", "Logement", "Catégorie", "Motif", "Montant (F CFA)", "À la charge de", "Mode", "Saisi par"]
        requete = db.query(Depense).options(selectinload(Depense.cite), selectinload(Depense.logement),
                                            selectinload(Depense.auteur))
        if debut:
            requete = requete.filter(Depense.date_depense >= debut)
        if fin:
            requete = requete.filter(Depense.date_depense <= fin)
        for x in requete.order_by(Depense.date_depense):
            if ok(x.cite_id):
                yield [d(x.date_depense), x.cite.nom if x.cite else "Fonctionnement de l'entreprise", x.logement.numero_logement if x.logement else "", x.categorie,
                       x.motif, n(x.montant), recus.ENTETE["nom"] if x.a_la_charge_de == "Entreprise" else x.a_la_charge_de,
                       x.mode_paiement, x.auteur.nom_complet if x.auteur else ""]
    elif quoi == "achats_ventes":
        yield ["N°", "Date", "Opération", "Désignation", "Acheteur / vendeur", "Téléphone", "Montant (F CFA)",
               "Commission (F CFA)", "Mode"]
        for o in db.query(AchatVente).order_by(AchatVente.date_operation):
            yield [o.numero, d(o.date_operation), o.type_operation, o.designation, o.partie_nom, o.partie_telephone,
                   n(o.montant), n(o.commission_montant), o.mode_paiement]
    elif quoi == "prospects":
        yield ["Date", "Nom", "Téléphone", "E-mail", "Besoin", "Type de logement", "Quartier", "Budget (F CFA)",
               "Source", "Statut", "Prochaine action", "Détails"]
        for p in db.query(Prospect).order_by(Prospect.cree_le):
            yield [d(p.cree_le.date() if p.cree_le else None), p.nom_complet, p.telephone, p.email, p.besoin,
                   p.type_logement, p.quartier, n(p.budget_max), p.source, p.statut, d(p.prochaine_action), p.details]
    elif quoi == "signalements":
        yield ["Date", "Bien", "Logement", "Catégorie", "Urgence", "Description", "Signalé par", "Statut", "Résolution"]
        for s in db.query(Signalement).options(selectinload(Signalement.cite), selectinload(Signalement.logement)) \
                .order_by(Signalement.cree_le):
            if ok(s.cite_id):
                yield [d(s.cree_le.date() if s.cree_le else None), s.cite.nom,
                       s.logement.numero_logement if s.logement else "", s.categorie, s.urgence, s.description,
                       s.signale_par, s.statut, s.resolution]


@router.get("/export/{quoi}")
def exporter(quoi: str, debut: date | None = Query(None), fin: date | None = Query(None),
             u: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    module = MODULE_EXPORT.get(quoi)
    if module is None:
        raise HTTPException(status_code=404, detail="Export inconnu.")
    if not peut_acceder(u.role.value, module):
        raise HTTPException(status_code=403, detail="Accès refusé pour votre profil.")
    tampon = io.StringIO()
    ecrivain = csv.writer(tampon, delimiter=";", lineterminator="\r\n")
    for ligne in lignes_export(db, u, quoi, debut, fin):
        # « = » « + » « - » « @ » en début de cellule : Excel le prendrait pour une formule
        ecrivain.writerow(["'" + str(v) if isinstance(v, str) and v[:1] in "=+-@" else ("" if v is None else v)
                           for v in ligne])
    prefixe = re.sub(r"[^A-Za-z0-9]+", "_", unicodedata.normalize("NFD", recus.ENTETE["nom"])
                     .encode("ascii", "ignore").decode()).strip("_") or "Gerimo"
    nom = f"{prefixe}_{quoi}_{date.today().strftime('%d-%m-%Y')}.csv"
    return Response(("﻿" + tampon.getvalue()).encode("utf-8"), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{nom}"'})
