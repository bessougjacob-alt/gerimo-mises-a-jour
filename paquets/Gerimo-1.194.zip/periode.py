"""Clôture des périodes comptables (précomptabilité, 06/10/2026).

Quand l'Admin clôture un mois, plus aucune opération d'argent datée de ce mois (ou d'avant) ne peut être
ajoutée, modifiée, annulée ou supprimée : les chiffres remis au comptable ne bougent plus.
La date limite est gardée dans les Paramètres (« cloture_jusqu_au », vide = rien de clôturé).
"""
from datetime import date

from fastapi import HTTPException
from sqlalchemy.orm import Session as SessionDB

CLE = "cloture_jusqu_au"


def cloture_jusqu_au(db: SessionDB) -> date | None:
    from models import Parametre
    p = db.get(Parametre, CLE)
    try:
        return date.fromisoformat(p.valeur) if p and p.valeur else None
    except ValueError:
        return None


def verifier_ouverte(db: SessionDB, *jours: date | None) -> None:
    """409 si l'une des dates tombe dans une période clôturée."""
    limite = cloture_jusqu_au(db)
    if limite is None:
        return
    for jour in jours:
        if jour is not None and jour <= limite:
            raise HTTPException(status_code=409, detail=f"La période jusqu'au {limite:%d/%m/%Y} est clôturée : "
                                                        "cette opération ne peut plus être ajoutée, modifiée ni "
                                                        "supprimée (l'Admin peut rouvrir la période).")
