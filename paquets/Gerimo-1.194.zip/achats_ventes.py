"""Étape 7 : achats et ventes de biens (Admin et Caisse ; suppression : Admin uniquement).

Trois types d'opération :
- Achat           : ISUP achète. Document : Décharge signée par le vendeur.
- Vente directe   : ISUP représente légalement le propriétaire (pas de mention du propriétaire).
                    Documents : Facture et Reçu remis à l'acheteur.
- Vente indirecte : ISUP est intermédiaire. On renseigne le propriétaire vendeur, la commission
                    d'intermédiation et qui la paie (acheteur ou vendeur). Le prix transite par ISUP.
                    Documents : Reçu (à l'acheteur, « pour le compte de » du propriétaire),
                    Facture d'honoraires (à celui qui paie la commission),
                    Décharge (signée par le propriétaire à la remise du produit net de la vente).

Autres règles : numéro AV-AAAA-NNNN ; parcelle vendue → « Disponibilité : Non » ;
documents créés à la 1re ouverture puis réimprimés à l'identique ; pas de modification
après coup (suppression avec mot de passe Admin, puis nouvelle saisie).
"""
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from pydantic import Field
from sqlalchemy.orm import Session as SessionDB, selectinload

import paiements
import recus
import periode
import tresorerie
from commun import (Cni, Formulaire, NomPersonne, Paragraphe, Suppression, Telephone, Texte, charger, montant,
                    numero_suivant)
from models import (MODES_PAIEMENT, PAYEURS_COMMISSION, TYPES_OPERATION, AchatVente, Cite, Document, Parcelle,
                    Utilisateur)
from securite import confirmer_mot_de_passe_admin, exiger_admin, exiger_module, get_db

router = APIRouter(prefix="/api")
acces = exiger_module("achats_ventes")  # Admin et Caisse (MODULES_PAR_ROLE)

# Adresse courte de chaque document → type en base et préfixe du numéro
DOCUMENTS = {
    "facture": ("Facture", "FAC"),
    "recu": ("Reçu de paiement", "RAV"),
    "decharge": ("Décharge", "DEC"),
}


def est_vente(o) -> bool:
    return o.type_operation in ("Vente", "Vente directe", "Vente indirecte")


def documents_possibles(o: AchatVente) -> list[str]:
    """Documents prévus pour l'opération."""
    if o.type_operation == "Achat":
        return ["Décharge"]
    if o.type_operation == "Vente indirecte":
        docs = ["Reçu de paiement", "Décharge"]
        if o.commission_montant and o.commission_montant > 0:
            docs.insert(1, "Facture")  # facture d'honoraires
        return docs
    return ["Facture", "Reçu de paiement"]  # vente directe


def net_proprietaire(o) -> Decimal:
    """Vente indirecte : ce qui revient au propriétaire (commission déduite si c'est lui qui la paie)."""
    commission = o.commission_montant or Decimal(0)
    return o.montant - commission if o.commission_payee_par == "Vendeur" else o.montant


class OperationIn(Formulaire):
    type_operation: Literal[TYPES_OPERATION]
    origine: Literal["bien", "parcelle", "hors_gestion"]
    cite_id: int | None = None
    parcelle_id: int | None = None
    designation: Paragraphe | None = Field(None, max_length=500)
    partie_nom: NomPersonne = Field(min_length=1, max_length=150)
    partie_telephone: Telephone | None = Field(None, max_length=30)
    partie_cni: Cni | None = Field(None, max_length=50)
    # vente indirecte
    proprietaire_nom: NomPersonne | None = Field(None, max_length=150)
    proprietaire_telephone: Telephone | None = Field(None, max_length=30)
    proprietaire_cni: Cni | None = Field(None, max_length=50)
    commission_montant: Decimal = Field(Decimal(0), ge=0, max_digits=14, decimal_places=2)
    commission_payee_par: Literal[PAYEURS_COMMISSION] | None = None
    montant: Decimal = Field(gt=0, max_digits=14, decimal_places=2)
    mode_paiement: Literal[MODES_PAIEMENT]
    date_operation: date
    observation: Texte | None = Field(None, max_length=500)
    compte_id: int | None = None   # trésorerie : vide = compte du mode de paiement


def designation_bien(c: Cite) -> str:
    return f"Bien « {c.nom} »" + (f", {c.adresse}" if c.adresse else "")


def designation_parcelle(p: Parcelle) -> str:
    texte = f"Parcelle {p.numero_parcelle} ({montant(p.superficie)} m²), « {p.cite.nom} »"
    if p.situation_geographique:
        texte += f", {p.situation_geographique}"
    return texte


def operation_json(o: AchatVente, documents: set) -> dict:
    codes = {type_doc: code for code, (type_doc, _) in DOCUMENTS.items()}
    return {
        "id": o.id, "numero": o.numero, "type_operation": o.type_operation,
        "bien": o.cite.nom if o.cite else None, "adresse": o.cite.adresse if o.cite else None,
        "parcelle": o.parcelle.numero_parcelle if o.parcelle else None,
        "designation": o.designation, "partie_nom": o.partie_nom, "partie_telephone": o.partie_telephone,
        "partie_cni": o.partie_cni, "montant": montant(o.montant), "mode_paiement": o.mode_paiement,
        "proprietaire_nom": o.proprietaire_nom, "proprietaire_telephone": o.proprietaire_telephone,
        "commission_montant": montant(o.commission_montant), "commission_payee_par": o.commission_payee_par,
        "net_proprietaire": montant(net_proprietaire(o)) if o.type_operation == "Vente indirecte" else None,
        "date_operation": o.date_operation.isoformat(), "observation": o.observation,
        "saisi_par": o.auteur.nom_complet if o.auteur else None,
        "documents": [{"code": codes[t], "type": t, "cree": (o.id, t) in documents} for t in documents_possibles(o)],
    }


@router.get("/achats-ventes/options")
def options(admin: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    cites = db.query(Cite).options(selectinload(Cite.parcelles)).order_by(Cite.nom).all()
    return {
        "types_operation": TYPES_OPERATION, "modes_paiement": MODES_PAIEMENT, "payeurs": PAYEURS_COMMISSION,
        "biens": [{"id": c.id, "nom": c.nom, "designation": designation_bien(c)} for c in cites],
        "parcelles": [{"id": p.id, "libelle": f"Parcelle {p.numero_parcelle} — {c.nom}",
                       "designation": designation_parcelle(p), "disponible": p.disponible,
                       "dernier_prix": montant(p.dernier_prix) if p.dernier_prix is not None else None}
                      for c in cites for p in c.parcelles],
    }


@router.get("/achats-ventes")
def liste(admin: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    operations = db.query(AchatVente).options(
        selectinload(AchatVente.cite), selectinload(AchatVente.parcelle), selectinload(AchatVente.auteur)
    ).order_by(AchatVente.date_operation.desc(), AchatVente.id.desc()).all()
    documents = {(d.achat_vente_id, d.type_document)
                 for d in db.query(Document).filter(Document.achat_vente_id.isnot(None))}
    return [operation_json(o, documents) for o in operations]


@router.post("/achats-ventes")
def creer(donnees: OperationIn, admin: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    if donnees.date_operation > date.today():
        raise HTTPException(status_code=400, detail="La date de l'opération ne peut pas être dans le futur.")
    periode.verifier_ouverte(db, donnees.date_operation)
    o = AchatVente(type_operation=donnees.type_operation, partie_nom=donnees.partie_nom,
                   partie_telephone=donnees.partie_telephone or None, partie_cni=donnees.partie_cni or None,
                   montant=donnees.montant, mode_paiement=donnees.mode_paiement,
                   date_operation=donnees.date_operation, observation=donnees.observation or None,
                   saisi_par=admin.id, commission_montant=Decimal(0),
                   compte_id=tresorerie.verifier_compte_choisi(db, donnees.compte_id, donnees.mode_paiement))

    # Vente indirecte : propriétaire vendeur et commission d'intermédiation
    if donnees.type_operation == "Vente indirecte":
        if not donnees.proprietaire_nom:
            raise HTTPException(status_code=400, detail="Vente indirecte : renseignez le propriétaire du bien (vendeur).")
        if donnees.commission_montant > donnees.montant:
            raise HTTPException(status_code=400, detail="La commission ne peut pas dépasser le prix de vente.")
        if donnees.commission_montant > 0 and donnees.commission_payee_par is None:
            raise HTTPException(status_code=400, detail="Indiquez qui paie la commission (acheteur ou vendeur).")
        o.proprietaire_nom = donnees.proprietaire_nom
        o.proprietaire_telephone = donnees.proprietaire_telephone or None
        o.proprietaire_cni = donnees.proprietaire_cni or None
        o.commission_montant = donnees.commission_montant
        o.commission_payee_par = donnees.commission_payee_par if donnees.commission_montant > 0 else None

    if donnees.origine == "bien":
        if donnees.cite_id is None:
            raise HTTPException(status_code=400, detail="Choisissez le bien concerné.")
        cite = charger(db, Cite, donnees.cite_id, "Bien introuvable.")
        o.cite_id = cite.id
        o.designation = donnees.designation or designation_bien(cite)
    elif donnees.origine == "parcelle":
        if donnees.parcelle_id is None:
            raise HTTPException(status_code=400, detail="Choisissez la parcelle concernée.")
        parcelle = charger(db, Parcelle, donnees.parcelle_id, "Parcelle introuvable.")
        if est_vente(o) and not parcelle.disponible:
            raise HTTPException(status_code=409, detail="Cette parcelle est indiquée « Disponibilité : Non » "
                                                        "(déjà vendue ?). Vérifiez sa fiche dans Biens.")
        o.parcelle_id, o.cite_id = parcelle.id, parcelle.cite_id
        o.designation = donnees.designation or designation_parcelle(parcelle)
        if est_vente(o):
            parcelle.disponible = False             # vendue
            parcelle.dernier_prix = donnees.montant
        elif parcelle.prix_entree is None:
            parcelle.prix_entree = donnees.montant  # prix d'achat
    else:  # bien hors gestion
        if not donnees.designation:
            raise HTTPException(status_code=400, detail="Décrivez le bien hors gestion (ex : terrain de 600 m² à Niablé).")
        o.designation = donnees.designation

    o.numero = numero_suivant(db, AchatVente.numero, f"AV-{date.today().year}", 4)
    db.add(o)
    db.commit()
    return {"id": o.id, "numero": o.numero}


@router.post("/achats-ventes/{operation_id}/supprimer")
def supprimer(operation_id: int, donnees: Suppression, admin: Utilisateur = Depends(exiger_admin),
              db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    o = charger(db, AchatVente, operation_id, "Opération introuvable.")
    periode.verifier_ouverte(db, o.date_operation)
    if est_vente(o) and o.parcelle is not None:
        o.parcelle.disponible = True  # vente annulée : la parcelle redevient disponible
    db.query(Document).filter_by(achat_vente_id=o.id).delete()  # les fichiers PDF restent archivés
    db.delete(o)
    db.commit()
    return {"ok": True}


# ---------- Documents PDF ----------

def _identite(nom, cni, telephone) -> str:
    return nom + (f", titulaire de la CNI n° {cni}" if cni else "") + (f", joignable au {telephone}" if telephone else "")


def _coordonnees(telephone, cni) -> str:
    return " — ".join(filter(None, [telephone and f"Tél. {telephone}", cni and f"CNI n° {cni}"]))


def _en_lettres_minuscule(valeur) -> str:
    lettres = recus.en_lettres(valeur)
    return lettres[0].lower() + lettres[1:]


def rib_entreprise(db: SessionDB) -> str:
    """« Banque — IBAN … — BIC … » d'après les Paramètres (vide si rien n'est renseigné)."""
    import banque
    import parametres
    p = parametres.tous(db)
    rib = banque.rib_lisible(p["banque_code"], p["banque_guichet"], p["banque_compte"], p["banque_cle_rib"])
    morceaux = [p["banque_nom"], rib and f"RIB {rib}", p["banque_iban"] and f"IBAN {banque.iban_lisible(p['banque_iban'])}",
                p["banque_bic"] and f"BIC {p['banque_bic']}"]
    return " — ".join(m for m in morceaux if m) if (rib or p["banque_iban"]) else ""


def donnees_document(o: AchatVente, type_document: str, prefixe: str) -> dict:
    date_txt = o.date_operation.strftime("%d/%m/%Y")
    indirecte = o.type_operation == "Vente indirecte"
    d = {
        "numero": o.numero, "numero_document": o.numero.replace("AV-", f"{prefixe}-", 1), "date": date_txt,
        "designation": o.designation or "", "mode": o.mode_paiement,
        "saisi_par": o.auteur.nom_complet if o.auteur else "",
        "libelle_operation": f"{o.type_operation} — N° {o.numero}",
        "montant": o.montant, "montant_lettres": recus.en_lettres(o.montant),
    }

    if type_document == "Facture":
        if indirecte:  # facture d'honoraires d'intermédiation, à celui qui paie la commission
            vendeur_paie = o.commission_payee_par == "Vendeur"
            d.update(titre="FACTURE D'HONORAIRES",
                     client=o.proprietaire_nom if vendeur_paie else o.partie_nom,
                     client_coordonnees=_coordonnees(*((o.proprietaire_telephone, o.proprietaire_cni) if vendeur_paie
                                                       else (o.partie_telephone, o.partie_cni))),
                     designation=f"Honoraires d'intermédiation — vente de : {o.designation} "
                                 f"(prix de vente : {recus.francs(o.montant)})",
                     montant=o.commission_montant, montant_lettres=recus.en_lettres(o.commission_montant))
        else:
            d.update(titre="FACTURE", client=o.partie_nom,
                     client_coordonnees=_coordonnees(o.partie_telephone, o.partie_cni))
    elif type_document == "Reçu de paiement":
        d.update(partie=o.partie_nom, motif=f"{o.type_operation} — {o.designation}")
        if indirecte:
            d["pour_compte"] = (f"{recus.ENTETE['nom']} reçoit cette somme en qualité d'intermédiaire, pour le compte de "
                                f"{o.proprietaire_nom}, propriétaire vendeur.")
    else:  # Décharge
        if indirecte:  # le propriétaire reconnaît avoir reçu d'ISUP le produit net de la vente
            net = net_proprietaire(o)
            retenue = (f", déduction faite de la commission d'intermédiation de {recus.francs(o.commission_montant)}"
                       if o.commission_payee_par == "Vendeur" and o.commission_montant else "")
            d.update(partie=o.proprietaire_nom, montant=net, montant_lettres=recus.en_lettres(net),
                     declaration=(f"Je soussigné(e) {_identite(o.proprietaire_nom, o.proprietaire_cni, o.proprietaire_telephone)}, "
                                  f"propriétaire du bien désigné ci-dessous, reconnais avoir reçu {recus.d_entreprise()} la somme de "
                                  f"{_en_lettres_minuscule(net)} ({recus.francs(net)}), par {o.mode_paiement}, au titre du "
                                  f"produit de la vente de mon bien à {o.partie_nom}, conclue par l'intermédiaire {recus.d_entreprise()} "
                                  f"au prix de {recus.francs(o.montant)}{retenue}. En conséquence, je donne bonne "
                                  f"et valable décharge à {recus.ENTETE['nom']} pour ladite somme."))
        else:  # achat : le vendeur reconnaît avoir été payé par ISUP
            d.update(partie=o.partie_nom,
                     declaration=(f"Je soussigné(e) {_identite(o.partie_nom, o.partie_cni, o.partie_telephone)}, "
                                  f"reconnais avoir reçu {recus.d_entreprise()} la somme de {_en_lettres_minuscule(o.montant)} "
                                  f"({recus.francs(o.montant)}), par {o.mode_paiement}, le {date_txt}, au titre de la "
                                  f"vente à {recus.ENTETE['nom']} de : {o.designation}. En conséquence, je donne bonne et valable "
                                  f"décharge à {recus.ENTETE['nom']} pour ladite somme."))
    return d


@router.get("/achats-ventes/{operation_id}/document/{code}")
def document(operation_id: int, code: str, admin: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    if code not in DOCUMENTS:
        raise HTTPException(status_code=404, detail="Document inconnu.")
    type_document, prefixe = DOCUMENTS[code]
    o = charger(db, AchatVente, operation_id, "Opération introuvable.")
    if type_document not in documents_possibles(o):
        raise HTTPException(status_code=409, detail=f"Pas de « {type_document} » pour cette opération "
                                                    f"({o.type_operation.lower()}).")

    doc = db.query(Document).filter_by(achat_vente_id=o.id, type_document=type_document).first()
    chemin = paiements.DOSSIER_DOCUMENTS / doc.chemin_fichier if doc and doc.chemin_fichier else None
    if chemin is None or not chemin.exists():  # 1re ouverture : création, puis conservé tel quel
        d = donnees_document(o, type_document, prefixe)
        d["rib_entreprise"] = rib_entreprise(db)
        relatif = Path("achats_ventes") / str(o.date_operation.year) / f"{d['numero_document']}.pdf"
        chemin = paiements.DOSSIER_DOCUMENTS / relatif
        chemin.parent.mkdir(parents=True, exist_ok=True)
        chemin.write_bytes(recus.document_operation_pdf(type_document, d))
        if doc is None:
            doc = Document(achat_vente_id=o.id, type_document=type_document)
            db.add(doc)
        doc.chemin_fichier, doc.nom_fichier = relatif.as_posix(), relatif.name
        doc.genere_par, doc.date_generation = admin.id, datetime.now()
        db.commit()
    return FileResponse(chemin, media_type="application/pdf", filename=chemin.name, content_disposition_type="inline")
