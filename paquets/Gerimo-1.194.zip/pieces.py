"""Pièces jointes des propriétaires et des locataires (CNI, passeport, attestation…).

Droits (vérifiés ici) :
- pièces d'un propriétaire : Admin seulement (module Propriétaires) ;
- pièces d'un locataire : Admin, ou Gestionnaire si le locataire a un contrat dans ses biens ;
- suppression : Admin uniquement, mot de passe redemandé.
"""
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session as SessionDB

import fichiers
from commun import Suppression, charger
from contrats import locataire_visible
from models import Locataire, PieceJointe, Proprietaire, Utilisateur, TYPES_PIECE
from securite import confirmer_mot_de_passe_admin, exiger_admin, get_db, peut_acceder, utilisateur_connecte

router = APIRouter(prefix="/api")


class PieceIn(BaseModel):
    proprietaire_id: int | None = None
    locataire_id: int | None = None
    type_piece: Literal[TYPES_PIECE] = "CNI"
    nom_fichier: str | None = Field(None, max_length=200)
    contenu: str  # data URL (photo ou PDF)


def verifier_titulaire(db: SessionDB, utilisateur: Utilisateur, proprietaire_id: int | None,
                       locataire_id: int | None) -> None:
    role = utilisateur.role.value
    if (proprietaire_id is None) == (locataire_id is None):
        raise HTTPException(status_code=400, detail="Indiquez un propriétaire ou un locataire.")
    if proprietaire_id is not None:
        if not peut_acceder(role, "proprietaires"):
            raise HTTPException(status_code=403, detail="Accès refusé pour votre profil.")
        charger(db, Proprietaire, proprietaire_id, "Propriétaire introuvable.")
        return
    if not (peut_acceder(role, "locataires") or peut_acceder(role, "contrats")):
        raise HTTPException(status_code=403, detail="Accès refusé pour votre profil.")
    locataire = charger(db, Locataire, locataire_id, "Locataire introuvable.")
    if not locataire_visible(utilisateur, locataire):
        raise HTTPException(status_code=404, detail="Locataire introuvable.")


def piece_json(p: PieceJointe) -> dict:
    return {"id": p.id, "type_piece": p.type_piece, "nom_fichier": p.nom_fichier, "type_mime": p.type_mime,
            "taille": p.taille, "date": p.cree_le.date().isoformat() if p.cree_le else None,
            "url": f"/api/pieces/{p.id}/fichier"}


@router.get("/pieces/types")
def types_pieces(utilisateur: Utilisateur = Depends(utilisateur_connecte)):
    return TYPES_PIECE


@router.get("/pieces")
def liste_pieces(proprietaire_id: int | None = None, locataire_id: int | None = None,
                 utilisateur: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    verifier_titulaire(db, utilisateur, proprietaire_id, locataire_id)
    requete = db.query(PieceJointe)
    requete = (requete.filter_by(proprietaire_id=proprietaire_id) if proprietaire_id is not None
               else requete.filter_by(locataire_id=locataire_id))
    return [piece_json(p) for p in requete.order_by(PieceJointe.id)]


@router.post("/pieces")
def ajouter_piece(donnees: PieceIn, utilisateur: Utilisateur = Depends(utilisateur_connecte),
                  db: SessionDB = Depends(get_db)):
    verifier_titulaire(db, utilisateur, donnees.proprietaire_id, donnees.locataire_id)
    sous_dossier = "pieces/proprietaires" if donnees.proprietaire_id else "pieces/locataires"
    relatif, type_mime, taille = fichiers.enregistrer_fichier(donnees.contenu, sous_dossier)
    extension = ".pdf" if type_mime == "application/pdf" else ".jpg"
    nom = fichiers.nom_propre(donnees.nom_fichier, donnees.type_piece)
    if not nom.lower().endswith(extension):
        nom = nom.rsplit(".", 1)[0] + extension
    piece = PieceJointe(proprietaire_id=donnees.proprietaire_id, locataire_id=donnees.locataire_id,
                        type_piece=donnees.type_piece, chemin_fichier=relatif, nom_fichier=nom,
                        type_mime=type_mime, taille=taille, ajoute_par=utilisateur.id)
    db.add(piece)
    db.commit()
    return piece_json(piece)


@router.get("/pieces/{piece_id}/fichier")
def fichier_piece(piece_id: int, utilisateur: Utilisateur = Depends(utilisateur_connecte),
                  db: SessionDB = Depends(get_db)):
    piece = charger(db, PieceJointe, piece_id, "Pièce introuvable.")
    try:
        verifier_titulaire(db, utilisateur, piece.proprietaire_id, piece.locataire_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Pièce introuvable.")
    return fichiers.servir(piece.chemin_fichier, piece.nom_fichier, piece.type_mime)


@router.post("/pieces/{piece_id}/supprimer")
def supprimer_piece(piece_id: int, donnees: Suppression, admin: Utilisateur = Depends(exiger_admin),
                    db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    piece = charger(db, PieceJointe, piece_id, "Pièce introuvable.")
    chemin = piece.chemin_fichier
    db.delete(piece)
    db.commit()
    fichiers.effacer(chemin)
    return {"ok": True}
