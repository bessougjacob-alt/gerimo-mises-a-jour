"""Pénalités de retard sur les loyers.

Les choix appartiennent à l'entreprise : ils se font dans Paramètres → Réglages (Admin), et les pénalités
sont désactivées tant que l'Admin ne les a pas mises en marche.
- montant : un % du loyer du mois, ou un montant fixe par mois payé en retard ;
- tolérance : nombre de jours de grâce après la date limite (le 05) ;
- cumul : une seule pénalité par mois en retard, ou une de plus pour chaque mois entier de retard ;
- bénéficiaire : toute la pénalité revient à l'entreprise, ou elle suit le loyer (propriétaire − commission).
La pénalité s'ajoute au loyer du mois payé en retard, sur le même reçu. Seul l'Admin peut la remettre.
Jamais de pénalité sur la caution ni sur l'avance.
"""
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import ROUND_HALF_UP, Decimal

from sqlalchemy.orm import Session as SessionDB

import parametres

ZERO = Decimal(0)


@dataclass
class Regle:
    active: bool
    mode: str          # « pourcentage » ou « fixe »
    valeur: Decimal
    tolerance: int     # jours de grâce après la date limite
    cumul: str         # « une_fois » ou « par_mois »
    beneficiaire: str  # « entreprise » ou « proprietaire »

    def json(self) -> dict:
        return {"active": self.active, "mode": self.mode, "valeur": float(self.valeur), "tolerance": self.tolerance,
                "cumul": self.cumul, "beneficiaire": self.beneficiaire}


def regle(db: SessionDB) -> Regle:
    lire = lambda cle: parametres.lire(db, cle)  # noqa: E731
    try:
        valeur = Decimal(lire("penalite_valeur").replace(",", ".") or "0")
    except ArithmeticError:
        valeur = ZERO
    try:
        tolerance = int(lire("penalite_tolerance") or "0")
    except ValueError:
        tolerance = 0
    return Regle(active=lire("penalite_active") == "oui" and valeur > 0, mode=lire("penalite_mode"),
                 valeur=valeur, tolerance=max(tolerance, 0), cumul=lire("penalite_cumul"),
                 beneficiaire=lire("penalite_beneficiaire"))


def mois_entiers(debut: date, fin: date) -> int:
    """Nombre de mois entiers écoulés entre deux dates (du 10/10 au 09/11 : 0 ; au 10/11 : 1)."""
    n = (fin.year - debut.year) * 12 + fin.month - debut.month - (1 if fin.day < debut.day else 0)
    return max(n, 0)


def penalite_mois(r: Regle, loyer: Decimal, limite: date, jour_paiement: date) -> Decimal:
    """Pénalité due pour un mois de loyer réglé le `jour_paiement` (0 si payé à temps)."""
    if not r.active:
        return ZERO
    seuil = limite + timedelta(days=r.tolerance)
    if jour_paiement <= seuil:
        return ZERO
    fois = 1 + (mois_entiers(seuil, jour_paiement) if r.cumul == "par_mois" else 0)
    unite = (loyer * r.valeur / 100) if r.mode == "pourcentage" else r.valeur
    return (unite * fois).quantize(Decimal("1"), rounding=ROUND_HALF_UP)


def repartir(r: Regle, penalite: Decimal, pourcentage: Decimal) -> Decimal:
    """Part de la pénalité gardée par l'entreprise (le reste revient au propriétaire)."""
    if r.beneficiaire == "proprietaire":
        return (penalite * pourcentage / 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return penalite
