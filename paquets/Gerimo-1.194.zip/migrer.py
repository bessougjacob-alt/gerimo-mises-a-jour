"""Applique les migrations du dossier migrations/ dans l'ordre.

Lancement, dans le terminal :  python migrer.py
Chaque migration peut être rejouée sans risque (IF NOT EXISTS).
"""
from pathlib import Path

from database import engine
from compte_base import ROLE, confier_la_base

for fichier in sorted((Path(__file__).parent / "migrations").glob("*.sql")):
    with engine.begin() as connexion:
        # curseur brut : le SQL est envoyé tel quel (les « % » ne sont pas interprétés)
        connexion.connection.cursor().execute(fichier.read_text(encoding="utf-8"))
    print(f"✅ {fichier.name}")

# Lancées avec « postgres », les migrations lui donnent les nouvelles tables : Gérimo Serveur, qui utilise le
# compte limité, ne pourrait plus les lire (ni les sauvegarder). On les lui rend.
with engine.begin() as connexion:
    curseur = connexion.connection.cursor()
    curseur.execute("SELECT rolsuper FROM pg_roles WHERE rolname = current_user")
    super_admin = curseur.fetchone()[0]
    curseur.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (ROLE,))
    if super_admin and curseur.fetchone():
        confier_la_base(curseur, ROLE, connexion.engine.url.database)
        print(f"✅ base confiée au compte {ROLE}")
