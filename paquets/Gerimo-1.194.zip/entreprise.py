"""Identité de l'entreprise cliente (« Mon entreprise », Paramètres) : nom, activité, adresse, ville, contacts,
RCCM, NCC et logo. Gérimo étant vendu à d'autres entreprises, rien de tout cela n'est écrit en dur : les documents
(reçus, contrats, courriers…), les messages et l'écran de connexion lisent ces réglages.
Toute installation démarre VIDE (l'assistant d'installation de Gérimo Serveur demande le nom, la ville et
les téléphones) : aucune identité de société n'est livrée avec le logiciel (13/10/2026, migration 032).
"""
import re
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session as SessionDB

from models import Utilisateur
from securite import exiger_admin, get_db

router = APIRouter()
DOSSIER = Path(__file__).parent / "documents" / "entreprise"
LOGO_DEFAUT = Path(__file__).parent / "static" / "img" / "icone-512.png"   # Gérimo, tant qu'aucun logo n'est envoyé
# Empreinte (SHA-256) de l'ancien logo livré avec le logiciel jusqu'au 13/10/2026 : recopié alors comme logo de
# l'entreprise sur les premières installations, il est retiré pour que chacune envoie le sien
EMPREINTE_ANCIEN_LOGO = "2e29cc83163ad5082f508af4ad3b3ed0e74e18b3c0f4f3cef953280cfb7a29e8"

DEFAUTS = {
    "entreprise_nom": "",
    "entreprise_activite": "",
    "entreprise_adresse": "",
    "entreprise_ville": "",
    "entreprise_telephones": "",
    "entreprise_telephones_gerant": "",  # sous la signature du contrat de bail
    "entreprise_email": "",
    "entreprise_rccm": "",
    "entreprise_ncc": "",
    "entreprise_slogan": "",
}
# Formes juridiques écrites à part (« Agence Sarl » : « Sarl » en Medium)
FORMES = ("SARLU", "SARL", "SASU", "SAS", "SA", "SCI", "SCS", "SNC", "GIE", "EURL", "ETS")


def nom_et_forme(nom: str) -> tuple[str, str]:
    """« Agence Horizon SARL » → (« Agence Horizon », « Sarl ») ; sans forme juridique → (nom, « »)."""
    morceaux = nom.strip().rsplit(" ", 1)
    if len(morceaux) == 2 and morceaux[1].upper().strip(".") in FORMES:
        return morceaux[0], morceaux[1].strip(".").capitalize()
    return nom.strip(), ""


def appliquer(valeurs: dict) -> None:
    """Recopie l'identité dans l'en-tête commun des documents PDF (recus.ENTETE, modifié sur place)."""
    import recus
    v = {k: (valeurs.get(k) or d) for k, d in DEFAUTS.items()}
    contacts = " — ".join(x for x in (v["entreprise_telephones"] and f"Tél. {v['entreprise_telephones']}",
                                     v["entreprise_email"]) if x)
    recus.ENTETE.update({
        "nom": v["entreprise_nom"], "activite": v["entreprise_activite"], "adresse": v["entreprise_adresse"],
        "contact": contacts, "rccm": f"RCCM {v['entreprise_rccm']}" if v["entreprise_rccm"] else "",
        "ncc": f"NCC : {v['entreprise_ncc']}" if v["entreprise_ncc"] else "", "ville": v["entreprise_ville"],
        "telephones": v["entreprise_telephones"], "telephones_gerant": v["entreprise_telephones_gerant"], "email": v["entreprise_email"],
    })
    recus.LOGO = logo()


def est_entreprise(nom: str | None) -> bool:
    """Le propriétaire est-il l'entreprise elle-même (biens propres : loyers à elle, rien à reverser) ?"""
    import recus
    return (nom or "").strip().upper() == recus.ENTETE["nom"].strip().upper()


def charger(db: SessionDB) -> None:
    import parametres
    garder_logo_historique(db)
    appliquer(parametres.tous(db))


def garder_logo_historique(db: SessionDB) -> None:
    """L'ancien logo par défaut, recopié comme logo de l'entreprise sur les premières installations, est retiré :
    chaque entreprise envoie le sien (Paramètres → Réglages → « Mon entreprise »)."""
    import hashlib
    for chemin in DOSSIER.glob("logo.*"):
        try:
            if hashlib.sha256(chemin.read_bytes()).hexdigest() == EMPREINTE_ANCIEN_LOGO:
                chemin.unlink()
        except OSError:
            pass


def identite_renseignee() -> bool:
    import recus
    return bool(recus.ENTETE["nom"].strip())


def logo() -> Path:
    for nom in ("logo.png", "logo.jpg"):
        if (DOSSIER / nom).exists():
            return DOSSIER / nom
    return LOGO_DEFAUT


def verifier(cle: str, valeur: str) -> str:
    if cle == "entreprise_nom" and len(valeur) < 2:
        raise HTTPException(status_code=400, detail="Indiquez le nom de l'entreprise.")
    if cle == "entreprise_email" and valeur and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[a-zA-Z]{2,}", valeur):
        raise HTTPException(status_code=400, detail="Adresse e-mail de l'entreprise invalide.")
    return valeur


# ---------- Pages publiques : nom et logo (écran de connexion) ----------

@router.get("/api/entreprise")
def identite(db: SessionDB = Depends(get_db)):
    import parametres
    v = parametres.tous(db)
    nom, forme = nom_et_forme(v["entreprise_nom"] or DEFAUTS["entreprise_nom"])
    return {"nom_complet": v["entreprise_nom"] or DEFAUTS["entreprise_nom"], "nom": nom, "forme": forme,
            "ville": v["entreprise_ville"], "slogan": v["entreprise_slogan"], "logo_personnalise": logo() != LOGO_DEFAUT}


@router.get("/entreprise/logo")
def image_logo():
    chemin = logo()
    return FileResponse(chemin, headers={"Cache-Control": "no-cache"},
                        media_type="image/jpeg" if chemin.suffix == ".jpg" else "image/png")


@router.post("/api/entreprise/logo")
async def envoyer_logo(request: Request, admin: Utilisateur = Depends(exiger_admin)):
    contenu = b""
    async for morceau in request.stream():
        contenu += morceau
        if len(contenu) > 2_000_000:
            raise HTTPException(status_code=413, detail="Logo trop lourd (2 Mo maximum).")
    if contenu.startswith(b"\x89PNG\r\n\x1a\n"):
        extension = "png"
    elif contenu.startswith(b"\xff\xd8\xff"):
        extension = "jpg"
    else:
        raise HTTPException(status_code=400, detail="Le logo doit être une image PNG ou JPEG.")
    DOSSIER.mkdir(parents=True, exist_ok=True)
    for ancien in DOSSIER.glob("logo.*"):
        ancien.unlink()
    (DOSSIER / f"logo.{extension}").write_bytes(contenu)
    import recus
    recus.LOGO = logo()
    return {"ok": True}


@router.post("/api/entreprise/logo/supprimer")
def logo_par_defaut(admin: Utilisateur = Depends(exiger_admin)):
    for ancien in DOSSIER.glob("logo.*"):
        ancien.unlink()
    import recus
    recus.LOGO = logo()
    return {"ok": True}
