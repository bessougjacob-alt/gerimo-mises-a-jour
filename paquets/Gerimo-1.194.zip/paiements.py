"""Étape 4 : paiements, encaissements, échéances et impayés.

Règles (décisions de Boss, vérifiées ici côté serveur) :
- Chaque mois de bail est une échéance, payable jusqu'au 05 :
  du mois même (« Début de mois ») ou du mois suivant (« Fin de mois »).
- Les mois d'avance couvrent les PREMIERS mois du bail ; ils sont réglés par
  l'encaissement « Caution/avance » (caution + avance, en une fois).
- On encaisse des mois COMPLETS : 1 à 12 mois d'un coup (un seul reçu,
  avec la période couverte), ou « Règlement total » de tout ce qui est dû.
- Exception, le VERSEMENT PARTIEL (arrangement accordé à un locataire, décision de Boss du 10/11/2026) : sur les
  mois déjà dus seulement, le locataire verse ce qu'il peut. Le versement solde d'abord les mois les plus anciens ;
  le reste va sur le mois suivant, qui garde un « reste à payer » (loyer 50 000 F, 2 mois dus, 80 000 F versés →
  1 mois soldé + 30 000 F sur l'autre, reste 20 000 F). Un mois n'est « réglé » (quittance, fin du retard) que soldé.
- Commission ISUP = % du bien × loyers encaissés (jamais sur la caution) ;
  montant reversé au propriétaire = loyers − commission.
- Impayé = mois non réglé après sa date limite. 2 mois consécutifs → « À risque ».
  La résiliation n'est jamais automatique.
- Annulation d'un encaissement : Admin uniquement, mot de passe redemandé ; rien n'est effacé.
- Pénalités de retard (penalites.py, réglées par l'Admin) : ajoutées au loyer du mois payé en retard ;
  seul l'Admin peut les remettre. Avec des versements partiels, elles sont réclamées au versement qui solde le mois.
"""
import logging
from datetime import date, datetime
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session as SessionDB, selectinload

import penalites
import recus
from entreprise import est_entreprise
import periode
import tresorerie
from commun import Formulaire, Texte, charger, est_admin, montant, numero_suivant
from models import (Cite, Contrat, Document, Echeance, Encaissement, Impaye, Logement, Paiement, Utilisateur,
                    VersementEcheance,
                    MODES_PAIEMENT, MOTIFS_PAIEMENT, STATUTS_EN_COURS, STATUTS_PAIEMENT)
from securite import (cites_autorisees, confirmer_mot_de_passe_admin, exiger_admin,
                      exiger_module, get_db, verifier_cite_autorisee)

router = APIRouter(prefix="/api")
acces_paiements = exiger_module("paiements")
journal = logging.getLogger("isup.paiements")

# Dossier des PDF générés (exclu de Git, à inclure dans les sauvegardes)
DOSSIER_DOCUMENTS = Path(__file__).parent / "documents"

NB_MOIS_MAX = 12
# Paiements repris d'un ancien fichier ou logiciel (reprise de données) : numérotés REP-AAAA-NNNNN,
# ils règlent les mois concernés et comptent dans les rapports, mais Gérimo n'en fait ni reçu ni quittance.
PREFIXE_REPRISE = "REP-"


def est_repris(p: Paiement) -> bool:
    return (p.numero_recu or "").startswith(PREFIXE_REPRISE)
# Contrats qui produisent des échéances (un contrat « En attente » n'a pas encore commencé ;
# un contrat « Suspendu » garde ses dettes mais n'en crée pas de nouvelles)
STATUTS_FACTURES = ("Actif", "Renouvelé", "Expiré", "Résilié")
MOIS_FR = ("janvier", "février", "mars", "avril", "mai", "juin", "juillet",
           "août", "septembre", "octobre", "novembre", "décembre")


# ---------- Calendrier ----------

def premier_du_mois(d: date) -> date:
    return d.replace(day=1)


def ajouter_mois(d: date, n: int) -> date:
    annees, mois = divmod(d.month - 1 + n, 12)
    return date(d.year + annees, mois + 1, 1)


def libelle_mois(d: date) -> str:
    return f"{MOIS_FR[d.month - 1]} {d.year}"


def libelle_periode(debut: date | None, fin: date | None) -> str:
    if debut is None:
        return ""
    return libelle_mois(debut) if debut == fin else f"{libelle_mois(debut)} à {libelle_mois(fin)}"


def date_limite(mois: date, terme: str) -> date:
    """Le 05 du mois (début de mois) ou du mois suivant (fin de mois)."""
    base = mois if terme == "Début de mois" else ajouter_mois(mois, 1)
    return base.replace(day=5)


def francs(valeur: Decimal) -> str:
    return f"{valeur:,.0f}".replace(",", " ") + " F"


# ---------- Échéances d'un contrat ----------

def dernier_mois_facturable(c: Contrat) -> date | None:
    fin = c.date_resiliation if c.statut_contrat == "Résilié" else c.date_fin
    if c.date_depart and c.statut_contrat != "Résilié" and (fin is None or c.date_depart < fin):
        fin = c.date_depart  # départ annoncé : le mois du départ est le dernier loyer (mois complet)
    return premier_du_mois(fin) if fin else None


def debut_suivi(c: Contrat) -> date:
    """Premier mois de loyer compté par Gérimo : le début du bail, ou le début du suivi pour un locataire repris
    d'un ancien fichier (les mois d'avant y sont réglés, sauf l'arriéré repris)."""
    debut = premier_du_mois(c.date_debut)
    return max(debut, premier_du_mois(c.suivi_depuis)) if c.suivi_depuis else debut


def mois_avance(c: Contrat) -> list[date]:
    """Les premiers mois du bail, couverts par l'avance (seulement ceux que Gérimo suit)."""
    debut = premier_du_mois(c.date_debut)
    return [m for m in (ajouter_mois(debut, i) for i in range(c.mois_avance or 0)) if m >= debut_suivi(c)]


def loyer_du_mois(c: Contrat, mois: date) -> Decimal:
    """Loyer d'un mois, en tenant compte des révisions de loyer (courriers.py) :
    avant la 1re révision, l'ancien loyer ; entre deux révisions, celui de la révision en vigueur ;
    après la dernière, le loyer actuel du contrat."""
    revisions = sorted((r for r in c.courriers if r.type_courrier == "Révision de loyer" and r.date_effet),
                       key=lambda r: (r.date_effet, r.id))
    if not revisions:
        return c.montant_loyer
    applicables = [r for r in revisions if r.date_effet <= mois]
    if not applicables:
        return revisions[0].ancien_loyer
    return c.montant_loyer if applicables[-1] is revisions[-1] else applicables[-1].nouveau_loyer


def generer_echeances(c: Contrat, jusqu_au: date) -> None:
    """Crée les échéances manquantes, du début du bail jusqu'au mois donné (inclus)."""
    fin = dernier_mois_facturable(c)
    if fin is not None and fin < jusqu_au:
        jusqu_au = fin
    existants = {e.mois_echeance for e in c.echeances}
    mois = debut_suivi(c)
    while mois <= jusqu_au:
        if mois not in existants:
            c.echeances.append(Echeance(mois_echeance=mois, montant_loyer=loyer_du_mois(c, mois), montant_charges=0,
                                        date_limite=date_limite(mois, c.terme_loyer)))
        mois = ajouter_mois(mois, 1)


def mois_a_payer(c: Contrat, nombre: int, jusqu_au: date | None = None) -> list[tuple[date, Decimal, Decimal]]:
    """Les prochains mois de loyer à payer (hors avance), du plus ancien au plus récent :
    (mois, reste à payer, loyer du mois). Le reste est inférieur au loyer après un versement partiel.

    Comprend les mois futurs pas encore créés en base (paiement d'avance).
    """
    avance = set(mois_avance(c))
    fin = dernier_mois_facturable(c)
    if jusqu_au is not None and (fin is None or jusqu_au < fin):
        fin = jusqu_au
    par_mois = {e.mois_echeance: e for e in c.echeances}
    resultat = []
    mois = debut_suivi(c)
    for _ in range(600):  # garde-fou : 50 ans
        if len(resultat) >= nombre or (fin is not None and mois > fin):
            break
        e = par_mois.get(mois)
        if mois not in avance and (e is None or e.paiement is None):
            loyer = e.montant_loyer if e else loyer_du_mois(c, mois)
            resultat.append((mois, e.reste if e else loyer, loyer))
        mois = ajouter_mois(mois, 1)
    return resultat


def prochains_mois(c: Contrat, nombre: int, jusqu_au: date | None = None) -> list[tuple[date, Decimal]]:
    """Comme mois_a_payer, sans le loyer : (mois, reste à payer)."""
    return [(mois, reste) for mois, reste, _ in mois_a_payer(c, nombre, jusqu_au)]


def entree_payee(c: Contrat) -> bool:
    """La caution et l'avance ont-elles été encaissées (et non annulées) ?"""
    return any(p.motif_paiement == "Caution/avance" and p.statut_paiement == "Payé" for p in c.paiements)


def reinitialiser_echeances_impayees(db: SessionDB, c: Contrat) -> None:
    """Après modification d'un contrat : les mois non réglés seront recréés
    avec les nouvelles conditions (loyer, terme). Les mois réglés, même en partie, ne bougent pas."""
    for e in [e for e in c.echeances if e.paiement is None and not e.montant_verse]:
        db.query(Impaye).filter_by(echeance_id=e.id).delete()
        c.echeances.remove(e)
        db.delete(e)


# ---------- Impayés ----------

def recalculer_contrat(db: SessionDB, c: Contrat, aujourdhui: date) -> None:
    """Met à jour échéances, mois impayés consécutifs et table impayes d'un contrat."""
    if c.statut_contrat in STATUTS_FACTURES:
        generer_echeances(c, premier_du_mois(aujourdhui))
        db.flush()  # les nouvelles échéances reçoivent leur id
    en_retard = [e for e in sorted(c.echeances, key=lambda e: e.mois_echeance)
                 if e.paiement is None and e.date_limite < aujourdhui]

    # série la plus récente de mois impayés qui se suivent
    consecutifs, precedent = 0, None
    for e in reversed(en_retard):
        if precedent is not None and e.mois_echeance != ajouter_mois(precedent, -1):
            break
        consecutifs += 1
        precedent = e.mois_echeance
    c.mois_impayes_consecutifs = consecutifs

    statut = "À risque" if consecutifs >= 2 else "En retard"
    existants = {i.echeance_id: i for i in db.query(Impaye).filter_by(contrat_id=c.id)}
    for e in en_retard:
        impaye = existants.pop(e.id, None)
        if impaye is None:
            db.add(Impaye(contrat_id=c.id, echeance_id=e.id, locataire_id=c.locataire_id,
                          logement_id=c.logement_id, cite_id=c.logement.cite_id, mois=e.mois_echeance,
                          montant_du=e.reste, statut_impayes=statut))
        else:
            impaye.statut_impayes = statut
            impaye.montant_du = e.reste  # diminue après un versement partiel
    for impaye in existants.values():  # mois réglés depuis
        impaye.statut_impayes = "Régularisé"


def contrats_du_perimetre(db: SessionDB, utilisateur: Utilisateur):
    requete = db.query(Contrat).join(Logement).options(
        selectinload(Contrat.echeances).selectinload(Echeance.paiement),
        selectinload(Contrat.locataire), selectinload(Contrat.logement).selectinload(Logement.cite),
    )
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None:
        requete = requete.filter(Logement.cite_id.in_(autorisees))
    return requete.order_by(Contrat.numero_contrat).all()


def recalculer_tout(db: SessionDB, contrats: list[Contrat]) -> None:
    aujourdhui = date.today()
    for c in contrats:
        recalculer_contrat(db, c, aujourdhui)
    db.commit()


def resume_impayes(c: Contrat, aujourdhui: date) -> dict | None:
    dus = [e for e in sorted(c.echeances, key=lambda e: e.mois_echeance)
           if e.paiement is None and e.date_limite < aujourdhui]
    if not dus:
        return None
    return {
        "nb_mois": len(dus),
        "montant": montant(sum((e.reste for e in dus), Decimal(0))),
        "deja_verse": montant(sum((e.montant_verse or Decimal(0) for e in dus), Decimal(0))),  # versements partiels
        "mois": [libelle_mois(e.mois_echeance) for e in dus],
        "a_risque": c.mois_impayes_consecutifs >= 2,
        "derniere_limite": dus[-1].date_limite,  # le mois impayé le plus récent
    }


# ---------- Listes et formulaire ----------

def contrat_resume(c: Contrat) -> dict:
    return {
        "id": c.id, "numero_contrat": c.numero_contrat, "statut_contrat": c.statut_contrat,
        "locataire": {"id": c.locataire.id, "nom_complet": c.locataire.nom_complet,
                      "telephone": c.locataire.telephone},
        "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}",
        "adresse": c.logement.cite.adresse,
        "montant_loyer": montant(c.montant_loyer), "terme_loyer": c.terme_loyer,
    }


@router.get("/paiements/options")
def options(utilisateur: Utilisateur = Depends(acces_paiements), db: SessionDB = Depends(get_db)):
    contrats = contrats_du_perimetre(db, utilisateur)
    recalculer_tout(db, contrats)
    aujourdhui = date.today()
    resultat = []
    for c in contrats:
        a_venir = mois_a_payer(c, NB_MOIS_MAX)
        dus = mois_a_payer(c, 600, jusqu_au=premier_du_mois(aujourdhui))
        payee = entree_payee(c)
        # on propose les contrats en cours, et les anciens qui ont encore des dettes
        if c.statut_contrat not in STATUTS_EN_COURS and not dus and payee:
            continue
        avance = mois_avance(c)
        montant_avance = sum((m for _, m in prochains_mois_avance(c)), Decimal(0))
        # « montant » : ce qui reste à payer sur le mois (moins que « loyer » après un versement partiel)
        mois_json = lambda liste: [{"mois": m.isoformat(), "libelle": libelle_mois(m), "montant": montant(v),  # noqa: E731
                                    "loyer": montant(loyer), "date_limite": date_limite(m, c.terme_loyer).isoformat()}
                                   for m, v, loyer in liste]
        resultat.append({
            **contrat_resume(c),
            "entree": {
                "payee": payee,
                "montant_caution": montant(c.montant_caution),
                "mois_avance": [libelle_mois(m) for m in avance],
                "montant_avance": montant(montant_avance),
                "total": montant(c.montant_caution + montant_avance),
            },
            "prochains_mois": mois_json(a_venir),
            "reglement_total": {"nb_mois": len(dus), "montant": montant(sum((v for _, v, _ in dus), Decimal(0))),
                                "periode": libelle_periode(dus[0][0], dus[-1][0]) if dus else "",
                                "mois": mois_json(dus)},
            "impayes": resume_impayes(c, aujourdhui),
        })
    return {"modes_paiement": MODES_PAIEMENT, "motifs_paiement": MOTIFS_PAIEMENT,
            "nb_mois_max": NB_MOIS_MAX, "contrats": resultat,
            # règle des pénalités : l'écran calcule le montant avec la date choisie (le serveur revérifie)
            "penalite": penalites.regle(db).json(), "remise_penalite_possible": est_admin(utilisateur)}


def prochains_mois_avance(c: Contrat) -> list[tuple[date, Decimal]]:
    par_mois = {e.mois_echeance: e for e in c.echeances}
    return [(m, par_mois[m].montant_loyer if m in par_mois else loyer_du_mois(c, m)) for m in mois_avance(c)]


@router.get("/impayes")
def impayes(utilisateur: Utilisateur = Depends(acces_paiements), db: SessionDB = Depends(get_db)):
    contrats = contrats_du_perimetre(db, utilisateur)
    recalculer_tout(db, contrats)
    aujourdhui = date.today()
    lignes = []
    for c in contrats:
        resume = resume_impayes(c, aujourdhui)
        if resume:
            lignes.append({**contrat_resume(c), **resume})
    # les plus graves d'abord
    return sorted(lignes, key=lambda l: (not l["a_risque"], -l["nb_mois"], l["locataire"]["nom_complet"]))


def paiement_json(p: Paiement, admin: bool) -> dict:
    c = p.contrat
    donnees = {
        "id": p.id, "numero_recu": p.numero_recu, "statut_paiement": p.statut_paiement,
        "date_paiement": p.date_paiement.isoformat(), "montant": montant(p.montant),
        "mode_paiement": p.mode_paiement, "motif_paiement": p.motif_paiement,
        "nb_mois": p.nb_mois, "periode": libelle_periode(p.periode_debut, p.periode_fin),
        "numero_contrat": c.numero_contrat, "locataire": c.locataire.nom_complet,
        "telephone": c.locataire.telephone,
        "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}",
        "adresse": c.logement.cite.adresse,
        "encaisse_par": p.caissier.nom_complet if p.caissier else None,
        "motif_annulation": p.motif_annulation,
        "repris": est_repris(p),
        "versement_partiel": bool(p.versement_partiel),
        # une quittance n'existe que s'il y a du loyer (pas pour une caution seule) et au moins un mois soldé
        "quittance_possible": not est_repris(p) and p.periode_debut is not None and (
            p.montant - (p.encaissement.montant_caution if p.encaissement else 0)) > 0
            and not (p.versement_partiel and not p.nb_mois),
    }
    if admin and p.encaissement:  # la répartition financière n'est montrée qu'à l'Admin
        e = p.encaissement
        donnees.update({
            "montant_caution": montant(e.montant_caution),
            "pourcentage_commission": montant(e.pourcentage_commission) if e.pourcentage_commission is not None else None,
            "commission_entreprise": montant(e.commission_entreprise), "montant_reverse": montant(e.montant_reverse),
            "montant_penalite": montant(e.montant_penalite or Decimal(0)),
        })
    return donnees


@router.get("/paiements")
def liste_paiements(utilisateur: Utilisateur = Depends(acces_paiements), db: SessionDB = Depends(get_db)):
    requete = db.query(Paiement).join(Contrat).join(Logement).options(
        selectinload(Paiement.contrat).selectinload(Contrat.locataire),
        selectinload(Paiement.contrat).selectinload(Contrat.logement).selectinload(Logement.cite),
        selectinload(Paiement.encaissement), selectinload(Paiement.caissier),
    )
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None:
        requete = requete.filter(Logement.cite_id.in_(autorisees))
    paiements = requete.order_by(Paiement.date_paiement.desc(), Paiement.id.desc()).limit(200).all()
    return [paiement_json(p, est_admin(utilisateur)) for p in paiements]


@router.get("/paiements/historique")
def historique(debut: date | None = None, fin: date | None = None, statut: Literal[STATUTS_PAIEMENT] | None = None,
               mode: Literal[MODES_PAIEMENT] | None = None, utilisateur: Utilisateur = Depends(acces_paiements),
               db: SessionDB = Depends(get_db)):
    """Historique complet des paiements sur une période, avec les totaux."""
    if debut and fin and fin < debut:
        raise HTTPException(status_code=400, detail="La date de fin doit être après la date de début.")
    requete = db.query(Paiement).join(Contrat).join(Logement).options(
        selectinload(Paiement.contrat).selectinload(Contrat.locataire),
        selectinload(Paiement.contrat).selectinload(Contrat.logement).selectinload(Logement.cite),
        selectinload(Paiement.encaissement), selectinload(Paiement.caissier),
    )
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None:
        requete = requete.filter(Logement.cite_id.in_(autorisees))
    if debut:
        requete = requete.filter(Paiement.date_paiement >= debut)
    if fin:
        requete = requete.filter(Paiement.date_paiement <= fin)
    if statut:
        requete = requete.filter(Paiement.statut_paiement == statut)
    if mode:
        requete = requete.filter(Paiement.mode_paiement == mode)
    paiements = requete.order_by(Paiement.date_paiement.desc(), Paiement.id.desc()).limit(5000).all()
    admin = est_admin(utilisateur)
    payes = [p for p in paiements if p.statut_paiement == "Payé"]
    totaux = {"nombre": len(paiements), "encaisse": montant(sum((p.montant for p in payes), Decimal(0))),
              "annules": sum(1 for p in paiements if p.statut_paiement == "Annulé")}
    if admin:
        totaux["commission_entreprise"] = montant(sum((p.encaissement.commission_entreprise or 0 for p in payes if p.encaissement),
                                                Decimal(0)))
    return {"paiements": [paiement_json(p, admin) for p in paiements], "totaux": totaux,
            "modes_paiement": MODES_PAIEMENT}


# ---------- Encaisser ----------

class PaiementIn(Formulaire):
    contrat_id: int
    motif_paiement: Literal[MOTIFS_PAIEMENT]
    nb_mois: int = Field(1, ge=1, le=NB_MOIS_MAX)          # pour « Loyer mensuel »
    mode_paiement: Literal[MODES_PAIEMENT]
    date_paiement: date | None = None
    montant: Decimal = Field(gt=0, max_digits=12, decimal_places=2)  # confirmé par la caisse
    observation: Texte | None = Field(None, max_length=500)
    compte_id: int | None = None   # trésorerie : vide = compte du mode de paiement
    remise_penalite: bool = False  # l'Admin renonce à la pénalité de retard
    versement_partiel: bool = False  # arrangement : le montant est libre, réparti sur les mois déjà dus


@router.post("/paiements")
def encaisser(donnees: PaiementIn, utilisateur: Utilisateur = Depends(acces_paiements),
              db: SessionDB = Depends(get_db)):
    aujourdhui = date.today()
    date_paiement = donnees.date_paiement or aujourdhui
    if date_paiement > aujourdhui:
        raise HTTPException(status_code=400, detail="La date du paiement ne peut pas être dans le futur.")
    periode.verifier_ouverte(db, date_paiement)

    c = charger(db, Contrat, donnees.contrat_id, "Contrat introuvable.")
    try:
        verifier_cite_autorisee(utilisateur, c.logement.cite_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Contrat introuvable.")
    if c.statut_contrat == "Résilié" and donnees.motif_paiement == "Caution/avance":
        raise HTTPException(status_code=409, detail="Ce contrat est résilié.")

    mandat = c.logement.cite.mandat_actuel
    if mandat is None:
        raise HTTPException(status_code=409, detail="La commission de gestion de ce bien n'est pas renseignée : "
                                                    "l'Admin doit la saisir (Bien → Modifier) avant l'encaissement.")

    # Mois couverts et montant exigé : des mois complets, sauf versement partiel (arrangement)
    partiel = donnees.versement_partiel
    if partiel and donnees.motif_paiement != "Loyer mensuel":
        raise HTTPException(status_code=400, detail="Un versement partiel se fait avec le motif « Loyer mensuel ».")
    caution = Decimal(0)
    if donnees.motif_paiement == "Caution/avance":
        if entree_payee(c):
            raise HTTPException(status_code=409, detail="La caution et l'avance de ce contrat sont déjà encaissées.")
        mois = [(m, v, v) for m, v in prochains_mois_avance(c)]
        par_mois = {e.mois_echeance: e for e in c.echeances}
        if any(par_mois.get(m) is not None and par_mois[m].paiement is not None for m, _, _ in mois):
            raise HTTPException(status_code=409, detail="Les mois d'avance de ce contrat sont déjà réglés.")
        caution = c.montant_caution or Decimal(0)
    elif partiel:  # seulement sur ce qui est déjà dû : jamais un mois futur
        mois = mois_a_payer(c, 600, jusqu_au=premier_du_mois(aujourdhui))
        if not mois:
            raise HTTPException(status_code=409, detail="Aucun loyer n'est dû à ce jour sur ce contrat : un versement "
                                                        "partiel ne se fait que sur un mois déjà dû.")
    elif donnees.motif_paiement == "Loyer mensuel":
        mois = mois_a_payer(c, donnees.nb_mois)
        if len(mois) < donnees.nb_mois:
            raise HTTPException(status_code=409, detail=f"Il ne reste que {len(mois)} mois à payer sur ce contrat "
                                                        "(fin du bail).")
    else:  # Règlement total : tout ce qui est dû jusqu'au mois en cours
        mois = mois_a_payer(c, 600, jusqu_au=premier_du_mois(aujourdhui))
        if not mois:
            raise HTTPException(status_code=409, detail="Aucun loyer n'est dû à ce jour sur ce contrat.")

    # Pénalités de retard : jamais sur l'entrée (caution et avance) ; calculées sur le loyer entier du mois
    regle = penalites.regle(db)

    def penalite_du(m: date, loyer: Decimal) -> Decimal:
        if donnees.motif_paiement == "Caution/avance":
            return Decimal(0)
        return penalites.penalite_mois(regle, loyer, date_limite(m, c.terme_loyer), date_paiement)

    # Répartition, du mois le plus ancien au plus récent : (mois, part versée, reste du mois après, pénalité)
    parts, remise = [], Decimal(0)
    disponible = donnees.montant
    for m, reste, loyer in mois:
        due = remise_mois = penalite_du(m, loyer)
        if donnees.remise_penalite:
            due = Decimal(0)
        else:
            remise_mois = Decimal(0)
        if not partiel or disponible >= reste + due:  # le mois est soldé
            parts.append((m, reste, Decimal(0), due))
            remise += remise_mois
            disponible -= reste + due
        elif disponible >= reste:  # de quoi payer le loyer, mais pas la pénalité réclamée quand le mois est soldé
            deja = donnees.montant - disponible
            raise HTTPException(status_code=400, detail=(
                f"Avec la pénalité de retard ({francs(due)}), il faut {francs(deja + reste + due)} pour solder "
                f"{libelle_mois(m)}. Encaissez ce montant, ou un versement inférieur à {francs(deja + reste)}."))
        else:
            if disponible > 0:  # versement partiel : le mois garde un reste à payer
                parts.append((m, disponible, reste - disponible, Decimal(0)))
            disponible = Decimal(0)
        if partiel and disponible <= 0:
            break
    if remise and not est_admin(utilisateur):
        raise HTTPException(status_code=403, detail="Seul l'Admin peut remettre une pénalité de retard.")
    loyers = sum((part for _, part, _, _ in parts), Decimal(0))
    penalite = sum((due for _, _, _, due in parts), Decimal(0))
    attendu = loyers + caution + penalite
    if attendu <= 0:
        raise HTTPException(status_code=409, detail="Rien à encaisser à l'entrée pour ce contrat (ni caution ni avance).")
    debut, fin = (parts[0][0], parts[-1][0]) if parts else (None, None)
    if partiel and disponible > 0:
        raise HTTPException(status_code=400, detail=f"Ce montant dépasse ce qui est dû à ce jour ({francs(attendu)}). "
                                                    "Pour payer des mois d'avance, décochez « Versement partiel ».")
    if donnees.montant != attendu:
        raise HTTPException(status_code=400, detail=f"Le montant doit être exactement {francs(attendu)} "
                                                    f"(mois complets : {libelle_periode(debut, fin) or 'caution'}"
                                                    + (f", dont pénalité de retard {francs(penalite)}" if penalite else "")
                                                    + ").")
    soldes = [m for m, _, reste_apres, _ in parts if reste_apres == 0]
    reste_partiel = sum((reste_apres for _, _, reste_apres, _ in parts), Decimal(0))

    paiement = Paiement(
        contrat=c, montant=attendu, date_paiement=date_paiement, statut_paiement="Payé",
        mode_paiement=donnees.mode_paiement, motif_paiement=donnees.motif_paiement,
        numero_recu=numero_suivant(db, Paiement.numero_recu, f"REC-{aujourdhui.year}", 5),
        periode_debut=debut, periode_fin=fin, nb_mois=len(soldes), encaisse_par=utilisateur.id,
        compte_id=tresorerie.verifier_compte_choisi(db, donnees.compte_id, donnees.mode_paiement),
        versement_partiel=reste_partiel > 0,
    )
    db.add(paiement)
    if fin is not None:
        generer_echeances(c, fin)
        par_mois = {e.mois_echeance: e for e in c.echeances}
        for m, part, reste_apres, _ in parts:
            e = par_mois[m]
            e.montant_verse = (e.montant_verse or Decimal(0)) + part
            if part > 0:
                db.add(VersementEcheance(echeance=e, paiement=paiement, montant=part, reste_apres=reste_apres))
            if reste_apres == 0:
                e.paiement = paiement

    # Commission sur ce qui est réellement encaissé (un versement partiel en porte sa part)
    pourcentage = mandat.pourcentage_commission
    commission = (loyers * pourcentage / 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    commission += penalites.repartir(regle, penalite, pourcentage)
    observation = donnees.observation or ""
    if remise:
        observation = ((observation + " — ") if observation else "") + (
            f"Pénalité de retard de {francs(remise)} remise par {utilisateur.nom_complet}")
    db.add(Encaissement(
        paiement=paiement, date_encaissement=date_paiement, montant_encaisse=attendu,
        montant_caution=caution, pourcentage_commission=pourcentage,
        commission_entreprise=commission, montant_reverse=loyers + penalite - commission,
        montant_penalite=penalite, observation=observation or None,
    ))
    db.flush()
    recalculer_contrat(db, c, aujourdhui)
    db.commit()
    # Reçu PDF créé tout de suite ; en cas de souci, il sera créé à la première ouverture
    try:
        generer_recu(db, paiement, utilisateur)
    except Exception:
        db.rollback()
        journal.exception("Reçu %s non généré à l'encaissement", paiement.numero_recu)
    return {"id": paiement.id, "numero_recu": paiement.numero_recu, "montant": montant(attendu),
            "periode": libelle_periode(debut, fin), "penalite": montant(penalite),
            "versement_partiel": reste_partiel > 0, "reste": montant(reste_partiel),
            "repartition": [{"mois": libelle_mois(m), "montant": montant(part), "reste": montant(reste_apres)}
                            for m, part, reste_apres, _ in parts]}


# ---------- Reçu de paiement (PDF) ----------

def donnees_recu(p: Paiement) -> dict:
    """Ce qui figure sur le reçu (caution, avance et reste compris)."""
    c = p.contrat
    aujourdhui = date.today()
    reste = sum((e.reste for e in c.echeances if e.paiement is None and e.date_limite < aujourdhui), Decimal(0))
    avance = prochains_mois_avance(c)
    montant_avance = sum((v for _, v in avance), Decimal(0))
    caution_versee = entree_payee(c)
    # Versements qui ne sont pas un mois entier : part d'un mois (il garde un reste) ou solde d'un mois déjà entamé
    entames = [v for v in p.versements if v.reste_apres > 0 or v.montant < v.echeance.montant_loyer]
    detail = ""
    if p.motif_paiement == "Caution/avance" and p.encaissement:
        detail = (f"dont caution {recus.francs(p.encaissement.montant_caution)} "
                  f"et avance {recus.francs(p.montant - p.encaissement.montant_caution)}")
    elif entames:
        complets = len(p.versements) - len(entames)
        morceaux = [f"{complets} mois complet{'s' if complets > 1 else ''}"] if complets else []
        for v in entames:
            mois = libelle_mois(v.echeance.mois_echeance)
            morceaux.append(f"versement partiel sur {mois} : {recus.francs(v.montant)}, reste {recus.francs(v.reste_apres)}"
                            if v.reste_apres > 0 else f"solde de {mois} : {recus.francs(v.montant)}")
        detail = ", ".join(morceaux)
    elif p.nb_mois and p.nb_mois > 1:
        detail = f"{p.nb_mois} mois complets"
    penalite = p.encaissement.montant_penalite if p.encaissement else 0
    if penalite:
        detail = (detail + ", " if detail else "") + f"dont pénalité de retard {recus.francs(penalite)}"
    return {
        "numero_recu": p.numero_recu,
        "date": p.date_paiement.strftime("%d/%m/%Y"),
        "locataire": c.locataire.nom_complet,
        "montant": p.montant,
        "montant_lettres": recus.en_lettres(p.montant),
        "motif": p.motif_paiement,
        "periode": libelle_periode(p.periode_debut, p.periode_fin),
        "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}",
        "numero_contrat": c.numero_contrat,
        "mode": p.mode_paiement,
        "detail": detail,
        "caution": f"{recus.francs(c.montant_caution or 0)}" + (" (versée)" if caution_versee else " (non versée)"),
        "avance": (f"{c.mois_avance} mois — {recus.francs(montant_avance)}" if avance else "Aucune"),
        "reste": recus.francs(reste),
        # reçu d'un versement partiel : pas de cadre caution / avance / reste (le détail donne le reste du mois)
        "sans_situation": bool(p.versement_partiel),
        "caissier": p.caissier.nom_complet if p.caissier else "",
    }


def enregistrer_document(db: SessionDB, p: Paiement, utilisateur: Utilisateur, type_document: str,
                         relatif: Path, contenu: bytes) -> Path:
    """Écrit le PDF dans documents/ et le note dans la table documents."""
    chemin = DOSSIER_DOCUMENTS / relatif
    chemin.parent.mkdir(parents=True, exist_ok=True)
    chemin.write_bytes(contenu)
    document = db.query(Document).filter_by(paiement_id=p.id, type_document=type_document).first()
    if document is None:
        document = Document(paiement_id=p.id, contrat_id=p.contrat_id, type_document=type_document)
        db.add(document)
    document.chemin_fichier = relatif.as_posix()
    document.nom_fichier = relatif.name
    document.genere_par = utilisateur.id
    document.date_generation = datetime.now()
    db.commit()
    return chemin


def generer_recu(db: SessionDB, p: Paiement, utilisateur: Utilisateur) -> Path:
    relatif = Path("recus") / str(p.date_paiement.year) / f"{p.numero_recu}.pdf"
    return enregistrer_document(db, p, utilisateur, "Reçu de paiement", relatif, recus.recu_pdf(donnees_recu(p)))


def servir_document(db: SessionDB, paiement_id: int, utilisateur: Utilisateur, type_document: str, fabriquer):
    """Renvoie le PDF conservé ; le fabrique à la 1re ouverture (jamais pour un paiement annulé)."""
    paiement = charger(db, Paiement, paiement_id, "Paiement introuvable.")
    try:
        verifier_cite_autorisee(utilisateur, paiement.contrat.logement.cite_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Paiement introuvable.")
    if est_repris(paiement):
        raise HTTPException(status_code=409, detail="Paiement repris de l'ancien logiciel : Gérimo n'en fait ni reçu "
                                                    "ni quittance (le locataire a reçu les siens à l'époque).")
    document = db.query(Document).filter_by(paiement_id=paiement.id, type_document=type_document).first()
    chemin = DOSSIER_DOCUMENTS / document.chemin_fichier if document and document.chemin_fichier else None
    if chemin is None or not chemin.exists():
        if paiement.statut_paiement != "Payé":
            raise HTTPException(status_code=409, detail=f"Ce paiement est annulé : pas de {type_document.lower()}.")
        chemin = fabriquer(db, paiement, utilisateur)
    return FileResponse(chemin, media_type="application/pdf", filename=chemin.name,
                        content_disposition_type="inline")


@router.get("/paiements/{paiement_id}/recu")
def recu(paiement_id: int, utilisateur: Utilisateur = Depends(acces_paiements), db: SessionDB = Depends(get_db)):
    return servir_document(db, paiement_id, utilisateur, "Reçu de paiement", generer_recu)


# ---------- Quittance de loyer (PDF) ----------
# Règle : une quittance n'affiche JAMAIS la caution, l'avance ni le reste à payer.

def _de(texte: str) -> str:
    """« de » ou « d' » devant un mois : d'octobre, d'août, de novembre."""
    return "d'" if texte[:1].lower() in "aeiouyéèêâîôûh" else "de "


def donnees_quittance(p: Paiement) -> dict:
    c = p.contrat
    caution = p.encaissement.montant_caution if p.encaissement else Decimal(0)
    penalite = (p.encaissement.montant_penalite or Decimal(0)) if p.encaissement else Decimal(0)
    loyers = p.montant - caution - penalite  # entrée : seulement l'avance ; jamais la pénalité de retard
    if loyers <= 0 or p.periode_debut is None:
        raise HTTPException(status_code=409, detail="Ce paiement ne contient pas de loyer : pas de quittance.")
    debut, fin = p.periode_debut, p.periode_fin
    nb_mois = p.nb_mois or len(p.echeances) or 1
    en_plusieurs_fois = ""
    if any(v.reste_apres > 0 or v.montant < v.echeance.montant_loyer for v in p.versements):
        # Versements partiels : la quittance ne porte que sur les mois que CE paiement a soldés, pour leur loyer entier
        soldes = list(p.echeances)
        if not soldes:
            raise HTTPException(status_code=409, detail="Versement partiel : la quittance sera délivrée quand le mois "
                                                        "sera entièrement payé. Le reçu, lui, est disponible.")
        loyers = sum((e.montant_loyer for e in soldes), Decimal(0))
        debut, fin, nb_mois = soldes[0].mois_echeance, soldes[-1].mois_echeance, len(soldes)
        if any(v.reste_apres == 0 and v.montant < v.echeance.montant_loyer for v in p.versements):
            en_plusieurs_fois = ", réglé en plusieurs versements"
    montants = {e.montant_loyer for e in p.echeances}
    loyer_mensuel = (f"{recus.francs(next(iter(montants)))} × {nb_mois} mois" if len(montants) == 1
                     else f"{recus.francs(loyers)} pour {nb_mois} mois")
    periode = libelle_periode(debut, fin)
    if debut == fin:
        pour = f"pour le mois {_de(periode)}{periode}{en_plusieurs_fois}"
    else:
        pour = f"pour la période {_de(periode)}{periode}{en_plusieurs_fois}"
    proprietaire = c.logement.cite.proprietaire
    if proprietaire is None or est_entreprise(proprietaire.nom_complet):
        qui = f"{recus.ENTETE['nom']}, propriétaire du bien « {c.logement.cite.nom} »"
    else:
        qui = f"{recus.ENTETE['nom']}, gestionnaire du bien « {c.logement.cite.nom} » pour le compte de {proprietaire.nom_complet}"
    lettres = recus.en_lettres(loyers)
    declaration = (f"{qui}, déclare avoir reçu de {c.locataire.nom_complet} la somme de "
                   f"{lettres[0].lower() + lettres[1:]} ({recus.francs(loyers)}) au titre du loyer du logement "
                   f"{c.logement.numero_logement}, {pour}, et lui en donne quittance, sous réserve de tous droits.")
    return {
        "numero": p.numero_recu.replace("REC-", "QUI-", 1),
        "date": p.date_paiement.strftime("%d/%m/%Y"),
        "locataire": c.locataire.nom_complet,
        "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}",
        "numero_contrat": c.numero_contrat,
        "periode": periode,
        "loyer_mensuel": loyer_mensuel,
        "montant": loyers,
        "montant_lettres": recus.en_lettres(loyers),
        "mode": p.mode_paiement,
        "declaration": declaration,
    }


def generer_quittance(db: SessionDB, p: Paiement, utilisateur: Utilisateur) -> Path:
    d = donnees_quittance(p)
    relatif = Path("quittances") / str(p.date_paiement.year) / f"{d['numero']}.pdf"
    return enregistrer_document(db, p, utilisateur, "Quittance", relatif, recus.quittance_pdf(d))


@router.get("/paiements/{paiement_id}/quittance")
def quittance(paiement_id: int, utilisateur: Utilisateur = Depends(acces_paiements),
              db: SessionDB = Depends(get_db)):
    return servir_document(db, paiement_id, utilisateur, "Quittance", generer_quittance)


# ---------- Annuler un encaissement (Admin) ----------

class Annulation(BaseModel):  # pas Formulaire : le mot de passe ne doit pas être retouché
    mot_de_passe_admin: str
    motif: Texte | None = Field(None, max_length=500)


@router.post("/paiements/{paiement_id}/annuler")
def annuler(paiement_id: int, donnees: Annulation, admin: Utilisateur = Depends(exiger_admin),
            db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    paiement = charger(db, Paiement, paiement_id, "Paiement introuvable.")
    if paiement.statut_paiement != "Payé":
        raise HTTPException(status_code=409, detail=f"Ce paiement est déjà « {paiement.statut_paiement} ».")
    periode.verifier_ouverte(db, paiement.date_paiement)
    # Un mois payé en plusieurs versements : on annule le plus récent d'abord
    for v in paiement.versements:
        suivant = next((a for a in v.echeance.versements if a.paiement_id != paiement.id and a.id > v.id), None)
        if suivant is not None:
            raise HTTPException(status_code=409, detail=(
                f"Un versement plus récent a été fait sur {libelle_mois(v.echeance.mois_echeance)} "
                f"(reçu {suivant.paiement.numero_recu}) : annulez d'abord celui-là."))
    paiement.statut_paiement = "Annulé"
    paiement.date_annulation = datetime.now()
    paiement.motif_annulation = (donnees.motif or "").strip() or None
    # Les mois redeviennent à payer, pour ce que ce paiement leur avait apporté
    touchees = {e.id: e for e in list(paiement.echeances) + [v.echeance for v in paiement.versements]}
    for v in list(paiement.versements):
        db.delete(v)
    db.flush()
    for e in touchees.values():
        db.expire(e, ["versements"])
        e.paiement = None
        e.montant_verse = sum((v.montant for v in e.versements), Decimal(0))
    db.expire(paiement, ["versements"])
    db.flush()
    recalculer_contrat(db, paiement.contrat, date.today())
    db.commit()
    return {"ok": True}
