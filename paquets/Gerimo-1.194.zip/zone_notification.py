"""Icône de Gérimo Serveur dans la zone de notification de Windows (près de l'horloge).

Demande de Boss (19/10/2026) : au lancement, le serveur se range près de l'horloge, comme d'autres logiciels
de gestion, au lieu d'occuper la barre des tâches. Clic sur l'icône : fenêtre du serveur ; clic droit : menu. L'icône reste derrière la flèche « ^ » (garder_visible).
Écrit avec les fonctions de Windows (ctypes) : aucune bibliothèque à ajouter. Le fichier est à la racine
du logiciel, donc amélioré par les mises à jour en ligne.

Les actions du menu ne sont jamais lancées depuis le fil de l'icône : elles sont mises dans une file que la
fenêtre (tkinter) vide elle-même (tkinter n'aime pas être appelé depuis un autre fil).
"""
import ctypes
import queue
import sys
import threading
from ctypes import wintypes

WM_USER = 0x0400
WM_ICONE = WM_USER + 20
NIN_BALLOONUSERCLICK = WM_USER + 5
WM_DESTROY, WM_COMMAND, WM_CLOSE = 0x0002, 0x0111, 0x0010
WM_LBUTTONUP, WM_LBUTTONDBLCLK, WM_RBUTTONUP, WM_CONTEXTMENU = 0x0202, 0x0203, 0x0205, 0x007B
NIM_ADD, NIM_MODIFY, NIM_DELETE, NIM_SETVERSION = 0, 1, 2, 4
NIF_MESSAGE, NIF_ICON, NIF_TIP, NIF_INFO, NIF_SHOWTIP = 0x01, 0x02, 0x04, 0x10, 0x80
NIIF_INFO, NIIF_NOSOUND = 0x01, 0x10
MF_STRING, MF_SEPARATOR, MF_DEFAULT = 0x0000, 0x0800, 0x1000
TPM_RIGHTBUTTON, TPM_RETURNCMD, TPM_BOTTOMALIGN = 0x0002, 0x0100, 0x0020
IMAGE_ICON, LR_LOADFROMFILE, LR_DEFAULTSIZE = 1, 0x0010, 0x0040
LRESULT = ctypes.c_ssize_t
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)


class GUID(ctypes.Structure):
    _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD), ("Data3", wintypes.WORD),
                ("Data4", ctypes.c_ubyte * 8)]


class NOTIFYICONDATAW(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("hWnd", wintypes.HWND), ("uID", wintypes.UINT),
                ("uFlags", wintypes.UINT), ("uCallbackMessage", wintypes.UINT), ("hIcon", wintypes.HICON),
                ("szTip", wintypes.WCHAR * 128), ("dwState", wintypes.DWORD), ("dwStateMask", wintypes.DWORD),
                ("szInfo", wintypes.WCHAR * 256), ("uVersion", wintypes.UINT), ("szInfoTitle", wintypes.WCHAR * 64),
                ("dwInfoFlags", wintypes.DWORD), ("guidItem", GUID), ("hBalloonIcon", wintypes.HICON)]


class WNDCLASSW(ctypes.Structure):
    _fields_ = [("style", wintypes.UINT), ("lpfnWndProc", WNDPROC), ("cbClsExtra", ctypes.c_int),
                ("cbWndExtra", ctypes.c_int), ("hInstance", wintypes.HINSTANCE), ("hIcon", wintypes.HICON),
                ("hCursor", wintypes.HANDLE), ("hbrBackground", wintypes.HBRUSH), ("lpszMenuName", wintypes.LPCWSTR),
                ("lpszClassName", wintypes.LPCWSTR)]


def _api():
    u32, s32, k32 = ctypes.windll.user32, ctypes.windll.shell32, ctypes.windll.kernel32
    u32.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    u32.DefWindowProcW.restype = LRESULT
    u32.CreateWindowExW.argtypes = [wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD, ctypes.c_int,
                                    ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.HWND, wintypes.HMENU,
                                    wintypes.HINSTANCE, wintypes.LPVOID]
    u32.CreateWindowExW.restype = wintypes.HWND
    u32.RegisterClassW.argtypes = [ctypes.POINTER(WNDCLASSW)]
    u32.LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT, ctypes.c_int, ctypes.c_int, wintypes.UINT]
    u32.LoadImageW.restype = wintypes.HANDLE
    u32.AppendMenuW.argtypes = [wintypes.HMENU, wintypes.UINT, ctypes.c_size_t, wintypes.LPCWSTR]
    u32.CreatePopupMenu.restype = wintypes.HMENU
    u32.TrackPopupMenu.argtypes = [wintypes.HMENU, wintypes.UINT, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                   wintypes.HWND, wintypes.LPVOID]
    u32.SetMenuDefaultItem.argtypes = [wintypes.HMENU, wintypes.UINT, wintypes.UINT]
    u32.DestroyMenu.argtypes = [wintypes.HMENU]
    u32.SetForegroundWindow.argtypes = [wintypes.HWND]
    u32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    u32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
    u32.TranslateMessage.argtypes = [ctypes.POINTER(wintypes.MSG)]
    u32.DispatchMessageW.argtypes = [ctypes.POINTER(wintypes.MSG)]
    u32.DestroyWindow.argtypes = [wintypes.HWND]
    u32.RegisterWindowMessageW.argtypes = [wintypes.LPCWSTR]
    s32.Shell_NotifyIconW.argtypes = [wintypes.DWORD, ctypes.POINTER(NOTIFYICONDATAW)]
    s32.Shell_NotifyIconW.restype = wintypes.BOOL
    k32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    k32.GetModuleHandleW.restype = wintypes.HMODULE
    return u32, s32, k32


def garder_visible(executable: str, info: str = "") -> bool:
    """Demande de Boss (19/10/2026) : les icônes de Gérimo restent CACHÉES derrière la petite flèche « ^ » de la
    barre des tâches (et non à côté de l'horloge). Réglé UNE fois par icône (repère GerimoRange) : si l'utilisateur
    la sort ensuite lui-même, on ne la recache pas. (Nom gardé : Gérimo Serveur 1.143 l'appelle déjà.)
    info : début du texte de l'icône, pour distinguer deux programmes lancés par le même exécutable (pythonw.exe)."""
    try:
        import winreg
    except ImportError:
        return False
    nom = "\\" + executable.replace("/", "\\").rsplit("\\", 1)[-1].lower()
    regle = False
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Control Panel\NotifyIconSettings") as racine:
            i = 0
            while True:
                try:
                    sous = winreg.EnumKey(racine, i)
                except OSError:
                    break
                i += 1
                with winreg.OpenKey(racine, sous, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE) as cle:
                    try:
                        chemin = str(winreg.QueryValueEx(cle, "ExecutablePath")[0]).lower()
                    except OSError:
                        continue
                    if not chemin.endswith(nom):
                        continue
                    if info:
                        try:
                            texte = str(winreg.QueryValueEx(cle, "InitialTooltip")[0])
                        except OSError:
                            texte = ""
                        if not texte.startswith(info):
                            continue
                    try:
                        winreg.QueryValueEx(cle, "GerimoRange")
                        continue  # déjà rangée une fois
                    except OSError:
                        pass
                    winreg.SetValueEx(cle, "IsPromoted", 0, winreg.REG_DWORD, 0)
                    winreg.SetValueEx(cle, "GerimoRange", 0, winreg.REG_DWORD, 1)
                    regle = True
    except OSError:
        pass
    return regle


class IconeHorloge:
    """icone = IconeHorloge("Gérimo Pro — Serveur", "gerimo.ico", [("Ouvrir…", fonction), None, …], fonction_double_clic)
    icone.demarrer() → True si l'icône est en place. Dans la fenêtre tkinter, appeler icone.traiter() souvent
    (fenetre.after) : c'est là que les actions sont lancées."""

    def __init__(self, titre: str, fichier_ico: str, menu: list, double_clic=None, clic_bulle=None, numero: int = 1):
        self.titre, self.fichier_ico, self.menu, self.double_clic = titre[:127], str(fichier_ico), menu, double_clic
        self.numero = numero  # deux programmes lancés par le même pythonw.exe : numéros différents, réglages séparés
        self.clic_bulle = clic_bulle  # clic sur la notification (sinon : comme un clic sur l'icône)
        self.file: queue.Queue = queue.Queue()
        self.hwnd = None
        self._pret = threading.Event()
        self._ok = False
        self._proc = WNDPROC(self._fenetre)  # gardé : sinon le ramasse-miettes l'efface et Windows plante

    # --- appelé par la fenêtre tkinter ---
    def demarrer(self, attente: float = 5.0) -> bool:
        if sys.platform != "win32":
            return False
        threading.Thread(target=self._boucle, daemon=True, name="icone-horloge").start()
        self._pret.wait(attente)
        return self._ok

    def traiter(self) -> None:
        while True:
            try:
                action = self.file.get_nowait()
            except queue.Empty:
                return
            try:
                action()
            except Exception as e:  # noqa: BLE001 — une action ratée ne doit pas arrêter le serveur
                print(f"Icône près de l'horloge : action impossible ({e})", flush=True)

    def bulle(self, titre: str, texte: str) -> None:
        """Petit message qui sort de l'icône (notification de Windows)."""
        if not self._ok:
            return
        d = self._donnees(NIF_INFO)
        d.szInfoTitle, d.szInfo, d.dwInfoFlags = titre[:63], texte[:255], NIIF_INFO | NIIF_NOSOUND
        self.s32.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(d))

    def changer_info(self, texte: str) -> None:
        """Texte qui s'affiche quand la souris passe sur l'icône."""
        self.titre = texte[:127]
        if self._ok:
            self.s32.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(self._donnees(NIF_TIP | NIF_SHOWTIP)))

    def arreter(self) -> None:
        if self.hwnd:
            self.u32.PostMessageW(self.hwnd, WM_CLOSE, 0, 0)

    # --- fil de l'icône ---
    def _donnees(self, drapeaux: int) -> NOTIFYICONDATAW:
        d = NOTIFYICONDATAW()
        d.cbSize = ctypes.sizeof(NOTIFYICONDATAW)
        d.hWnd, d.uID, d.uFlags = self.hwnd, self.numero, drapeaux
        d.uCallbackMessage, d.hIcon, d.szTip = WM_ICONE, self.hicon, self.titre
        return d

    def _ajouter(self) -> bool:
        return bool(self.s32.Shell_NotifyIconW(NIM_ADD, ctypes.byref(
            self._donnees(NIF_MESSAGE | NIF_ICON | NIF_TIP | NIF_SHOWTIP))))

    def _boucle(self) -> None:
        try:
            self.u32, self.s32, k32 = _api()
            instance = k32.GetModuleHandleW(None)
            classe = WNDCLASSW()
            classe.lpfnWndProc, classe.hInstance, classe.lpszClassName = self._proc, instance, "GerimoIconeHorloge"
            self.u32.RegisterClassW(ctypes.byref(classe))
            self.hwnd = self.u32.CreateWindowExW(0, "GerimoIconeHorloge", self.titre, 0, 0, 0, 0, 0, None, None, instance, None)
            self.hicon = self.u32.LoadImageW(None, self.fichier_ico, IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE)
            # l'Explorateur de Windows redémarré (plantage, mise à jour) : il faut remettre l'icône
            self.msg_barre = self.u32.RegisterWindowMessageW("TaskbarCreated")
            self._ok = bool(self.hwnd and self.hicon and self._ajouter())
        except Exception as e:  # noqa: BLE001
            print(f"Icône près de l'horloge impossible : {e}", flush=True)
            self._ok = False
        self._pret.set()
        if not self._ok:
            return
        msg = wintypes.MSG()
        while self.u32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            self.u32.TranslateMessage(ctypes.byref(msg))
            self.u32.DispatchMessageW(ctypes.byref(msg))

    def _afficher_menu(self) -> None:
        menu = self.u32.CreatePopupMenu()
        actions = {}
        for i, element in enumerate(self.menu, start=1):
            if element is None:
                self.u32.AppendMenuW(menu, MF_SEPARATOR, 0, None)
            else:
                self.u32.AppendMenuW(menu, MF_STRING, i, element[0])
                actions[i] = element[1]
        if self.menu and self.menu[0]:
            self.u32.SetMenuDefaultItem(menu, 1, 0)
        point = wintypes.POINT()
        self.u32.GetCursorPos(ctypes.byref(point))
        self.u32.SetForegroundWindow(self.hwnd)  # sinon le menu ne se ferme pas quand on clique ailleurs
        choix = self.u32.TrackPopupMenu(menu, TPM_RIGHTBUTTON | TPM_RETURNCMD | TPM_BOTTOMALIGN, point.x, point.y, 0,
                                        self.hwnd, None)
        self.u32.PostMessageW(self.hwnd, 0, 0, 0)
        self.u32.DestroyMenu(menu)
        if choix in actions:
            self.file.put(actions[choix])

    def _fenetre(self, hwnd, message, wparam, lparam):
        if message == WM_ICONE:
            evenement = lparam & 0xFFFF
            if evenement in (WM_RBUTTONUP, WM_CONTEXTMENU):
                self._afficher_menu()
            elif evenement == WM_LBUTTONUP and self.double_clic:  # un clic suffit (le double-clic aussi)
                self.file.put(self.double_clic)
            elif evenement == NIN_BALLOONUSERCLICK and (self.clic_bulle or self.double_clic):
                self.file.put(self.clic_bulle or self.double_clic)
            return 0
        if message == getattr(self, "msg_barre", -1):
            self._ajouter()
            return 0
        if message == WM_CLOSE:
            self.s32.Shell_NotifyIconW(NIM_DELETE, ctypes.byref(self._donnees(0)))
            self.u32.DestroyWindow(hwnd)
            return 0
        if message == WM_DESTROY:
            self.u32.PostQuitMessage(0)
            return 0
        return self.u32.DefWindowProcW(hwnd, message, wparam, lparam)
