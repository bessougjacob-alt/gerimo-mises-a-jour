"""Continuité du service : Gérimo Serveur démarre avec Windows et se relance tout seul s'il plante.

- Démarrage avec Windows : une ligne dans le registre de l'utilisateur (HKCU\\...\\Run), sans droits Admin.
  Gérimo démarre donc à l'ouverture de la session Windows (conseil : session qui s'ouvre toute seule sur le PC serveur).
- Gardien : petit programme invisible lancé à côté du serveur. Il le relance si :
    * le programme s'est fermé sans qu'on l'ait arrêté (plantage, processus tué) ;
    * le serveur, après avoir bien répondu, ne répond plus du tout pendant 3 minutes (bloqué) : il est alors arrêté
      puis relancé.
  Un arrêt volontaire (bouton « Arrêter », mise à jour en ligne) est noté dans un fichier : le gardien s'arrête aussi.
  Garde-fou : pas plus de 5 relances par heure (sinon le problème est ailleurs : le gardien s'arrête et le note).
- Au démarrage de Windows, PostgreSQL peut mettre un moment à être prêt : Gérimo l'attend (2 minutes au plus).

Ce fichier est mis à jour en ligne avec le reste du logiciel (le programme Gérimo Serveur.exe ne fait que l'appeler).
"""
import os
import subprocess
import sys
import time
import urllib.request
from datetime import datetime
from pathlib import Path

NOM_REGISTRE = "Gérimo Serveur"
CLE_RUN = r"Software\Microsoft\Windows\CurrentVersion\Run"
ARGUMENT_WINDOWS = "--demarrage-windows"   # lancé par Windows : pas de navigateur, fenêtre réduite
ARGUMENT_GARDIEN = "--gardien"
FICHIER_ARRET = "arret_volontaire.txt"      # dans journaux/ : PID du serveur arrêté volontairement
FICHIER_PROPOSE = "demarrage_auto_regle.txt"  # le démarrage avec Windows a été réglé une première fois

INTERVALLE = 20          # secondes entre deux vérifications du gardien
ECHECS_BLOQUE = 9        # 9 × 20 s = 3 minutes sans réponse → serveur bloqué
RELANCES_MAX_HEURE = 5
DELAI_PREMIERE_REPONSE = 600  # le serveur a 10 minutes pour répondre la première fois (migrations, sauvegarde)
CREATION_DETACHEE = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP


def noter(dossier: Path, message: str) -> None:
    try:
        with open(dossier / "journaux" / "gardien.log", "a", encoding="utf-8") as f:
            f.write(f"{datetime.now():%d/%m/%Y %H:%M:%S} {message}\n")
    except OSError:
        pass


# ---------- Démarrage avec Windows ----------

def commande_demarrage(executable: str) -> str:
    return f'"{executable}" {ARGUMENT_WINDOWS}'


def demarrage_windows_actif(nom: str = NOM_REGISTRE) -> bool:
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, CLE_RUN) as cle:
            winreg.QueryValueEx(cle, nom)
            return True
    except OSError:
        return False


def regler_demarrage_windows(actif: bool, executable: str, nom: str = NOM_REGISTRE) -> None:
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, CLE_RUN, 0, winreg.KEY_SET_VALUE) as cle:
        if actif:
            winreg.SetValueEx(cle, nom, 0, winreg.REG_SZ, commande_demarrage(executable))
        else:
            try:
                winreg.DeleteValue(cle, nom)
            except FileNotFoundError:
                pass


def premier_reglage(dossier: Path, executable: str) -> bool:
    """La toute première fois : Gérimo Serveur démarrera avec Windows (l'Admin peut le décocher ensuite).
    Renvoie True si le réglage vient d'être fait."""
    marque = dossier / "journaux" / FICHIER_PROPOSE
    if marque.exists():
        return False
    try:
        regler_demarrage_windows(True, executable)
        marque.write_text(datetime.now().isoformat(), encoding="utf-8")
        noter(dossier, "Démarrage avec Windows activé (premier lancement).")
        return True
    except OSError as e:
        noter(dossier, f"Démarrage avec Windows impossible à activer : {e}")
        return False


# ---------- Attente de PostgreSQL au démarrage de Windows ----------

def attendre_base(secondes: int = 120) -> bool:
    """Attend que la base réponde (service PostgreSQL encore en train de démarrer). True si elle répond."""
    from sqlalchemy import text
    from database import engine
    fin = time.time() + secondes
    while True:
        try:
            with engine.connect() as c:
                c.execute(text("SELECT 1"))
            return True
        except Exception:  # noqa: BLE001
            if time.time() > fin:
                return False
            time.sleep(3)


# ---------- Arrêt volontaire ----------

def noter_arret_volontaire(dossier: Path, pid: int | None = None) -> None:
    try:
        (dossier / "journaux" / FICHIER_ARRET).write_text(str(pid or os.getpid()), encoding="utf-8")
    except OSError:
        pass


def arret_volontaire(dossier: Path, pid: int) -> bool:
    try:
        return (dossier / "journaux" / FICHIER_ARRET).read_text(encoding="utf-8").strip() == str(pid)
    except OSError:
        return False


# ---------- Gardien ----------

def processus_vivant(pid: int) -> bool:
    """Le processus existe-t-il encore ? (Windows : OpenProcess + code de sortie)"""
    if sys.platform != "win32":
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    import ctypes
    noyau = ctypes.windll.kernel32
    poignee = noyau.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not poignee:
        return False
    code = ctypes.c_ulong()
    try:
        return bool(noyau.GetExitCodeProcess(poignee, ctypes.byref(code))) and code.value == 259  # STILL_ACTIVE
    finally:
        noyau.CloseHandle(poignee)


def windows_s_arrete() -> bool:
    """Arrêt ou redémarrage de Windows en cours : surtout ne rien relancer."""
    if sys.platform != "win32":
        return False
    import ctypes
    return bool(ctypes.windll.user32.GetSystemMetrics(0x2000))  # SM_SHUTTINGDOWN


def arreter_processus(pid: int) -> None:
    subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True)


def serveur_repond(port: int, delai: float = 8) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/connexion", timeout=delai) as r:
            return r.status == 200
    except Exception:  # noqa: BLE001
        return False


def commande_serveur(dossier: Path) -> list[str]:
    """Commande qui lance Gérimo Serveur (exécutable, ou script en développement)."""
    if getattr(sys, "frozen", False):
        return [sys.executable]
    return [sys.executable, str(dossier / "installation" / "lanceur_serveur.py")]


def lancer_gardien(dossier: Path, port: int) -> None:
    """Appelé par le serveur une fois démarré : le gardien le surveille depuis un processus séparé."""
    if os.environ.get("ISUP_SANS_GARDIEN"):
        return
    commande = commande_serveur(dossier) + [ARGUMENT_GARDIEN, str(os.getpid()), str(port)]
    subprocess.Popen(commande, cwd=dossier, close_fds=True, creationflags=CREATION_DETACHEE if sys.platform == "win32" else 0,
                     env={**{k: v for k, v in os.environ.items() if k != "ISUP_GARDIEN_INDEPENDANT"},
                          "ISUP_SANS_GARDIEN": "1"})


def relancer_serveur(dossier: Path, raison: str) -> int:
    env = {k: v for k, v in os.environ.items()
           if k not in ("ISUP_SANS_GARDIEN", "ISUP_APRES_MAJ", "ISUP_MESSAGE_MAJ", "ISUP_GARDIEN_INDEPENDANT")}
    env.update(ISUP_SANS_NAVIGATEUR="1", ISUP_RELANCE=raison)
    p = subprocess.Popen(commande_serveur(dossier), cwd=dossier, close_fds=True,
                         creationflags=CREATION_DETACHEE if sys.platform == "win32" else 0, env=env)
    return p.pid


class Surveillance:
    """Décisions du gardien, séparées des actions (pour les tests)."""

    def __init__(self, maintenant: float):
        self.debut = maintenant
        self.a_repondu = False
        self.echecs = 0

    def observer(self, repond: bool, maintenant: float) -> str:
        """« ok », « attendre » ou « bloque » (le serveur ne répond plus : à arrêter puis relancer)."""
        if repond:
            self.a_repondu, self.echecs = True, 0
            return "ok"
        if not self.a_repondu:
            # jamais répondu : démarrage lent, ou port déjà pris par un autre Gérimo → on ne force rien
            return "attendre" if maintenant - self.debut < DELAI_PREMIERE_REPONSE else "abandon"
        self.echecs += 1
        return "bloque" if self.echecs >= ECHECS_BLOQUE else "attendre"


def relances_permises(historique: list[float], maintenant: float) -> bool:
    return sum(1 for t in historique if maintenant - t < 3600) < RELANCES_MAX_HEURE


def detacher_du_serveur(pid: int) -> bool:
    """Le gardien, lancé par le serveur, est son « enfant » : le Gestionnaire des tâches (« Fin de tâche ») ou un
    plantage qui emporte toute la famille de programmes l'arrêterait avec lui. Il se relance donc une fois de
    lui-même, puis s'arrête : le nouveau gardien n'a plus de parent, il est vraiment indépendant du serveur.
    Renvoie True si ce gardien-ci doit s'arrêter (son remplaçant indépendant est lancé)."""
    if os.environ.get("ISUP_GARDIEN_INDEPENDANT") or ARGUMENT_GARDIEN not in sys.argv:
        return False  # déjà indépendant, ou appelé autrement que comme programme gardien
    subprocess.Popen(sys.argv if getattr(sys, "frozen", False) else [sys.executable, *sys.argv], close_fds=True,
                     creationflags=CREATION_DETACHEE if sys.platform == "win32" else 0,
                     env=dict(os.environ, ISUP_GARDIEN_INDEPENDANT="1"))
    return True


def gardien(dossier: Path, pid: int, port: int) -> None:
    """Boucle du gardien : surveille le serveur `pid` ; le relance s'il disparaît ou se bloque."""
    if detacher_du_serveur(pid):
        return
    noter(dossier, f"Gardien en marche (serveur {pid}, port {port}).")
    historique: list[float] = []
    surveillance = Surveillance(time.time())
    while True:
        time.sleep(INTERVALLE)
        if windows_s_arrete():
            noter(dossier, "Windows s'arrête : le gardien aussi.")
            return
        if not processus_vivant(pid):
            if arret_volontaire(dossier, pid):
                noter(dossier, "Serveur arrêté volontairement : le gardien s'arrête.")
                return
            raison = "arrêt imprévu"
        else:
            etat = surveillance.observer(serveur_repond(port), time.time())
            if etat in ("ok", "attendre"):
                continue
            if etat == "abandon":
                noter(dossier, "Le serveur n'a jamais répondu (port déjà utilisé ?) : le gardien s'arrête.")
                return
            raison = "serveur bloqué"
            noter(dossier, "Le serveur ne répond plus depuis 3 minutes : arrêt forcé.")
            arreter_processus(pid)
            time.sleep(5)
        if not relances_permises(historique, time.time()):
            noter(dossier, f"Trop de relances en une heure ({RELANCES_MAX_HEURE}) : le gardien s'arrête. "
                           "Regardez journaux/serveur.log.")
            return
        historique.append(time.time())
        nouveau = relancer_serveur(dossier, f"{raison} à {datetime.now():%H:%M}")
        noter(dossier, f"Serveur relancé ({raison}) : nouveau programme {nouveau}.")
        # le nouveau serveur lance son propre gardien une fois démarré : celui-ci s'arrête
        return
