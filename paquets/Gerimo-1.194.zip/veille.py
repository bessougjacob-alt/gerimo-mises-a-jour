"""Mode veille : Gérimo se verrouille quand on s'éloigne, sans fermer la session (12/10/2026, demande de Boss).

- Mise en veille : bouton « Mode veille » (barre du haut, menu), Ctrl + L, ou tout seul après un temps sans
  activité (Paramètres → Réglages, 20 minutes par défaut sur PC). Pas de veille automatique sur un téléphone
  verrouillé par un code, un schéma ou une empreinte (le téléphone protège déjà l'application), ni sur iPhone/iPad.
- Écran de veille : logo de l'entreprise, logo Gérimo animé, date et heure, nom de l'utilisateur ; aucune donnée.
- Le verrou est dans le serveur (securite.verifier_veille) : une session en veille ne fait plus rien (423),
  même si l'on recharge la page ou ouvre un autre onglet.
- Réveil : le mot de passe de l'utilisateur de la session, et lui seul ; 5 erreurs → session fermée.
  « Ce n'est pas moi » : déconnexion, pour qu'un collègue se connecte avec son propre compte.
"""
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session as SessionDB

import securite
from securite import get_db

router = APIRouter(prefix="/api")
ESSAIS_REVEIL = 5


def _session(db: SessionDB, request: Request):
    session = securite.session_de_la_requete(db, request)
    if session is None:
        raise HTTPException(status_code=401, detail="Veuillez vous connecter.")
    return session


@router.post("/veille")
def mettre_en_veille(request: Request, db: SessionDB = Depends(get_db)):
    session = _session(db, request)
    session.veille = True
    db.commit()
    return {"ok": True}


@router.post("/activite")
def activite(request: Request, db: SessionDB = Depends(get_db)):
    """L'écran signale que l'utilisateur est là (souris, clavier, toucher) : la veille automatique recule."""
    session = _session(db, request)
    securite.verifier_veille(db, session)
    securite.noter_activite(db, session)
    return {"ok": True, "veille_minutes": session.veille_minutes}


class ReveilIn(BaseModel):
    mot_de_passe: str = Field(min_length=1, max_length=200)


@router.post("/veille/reveiller")
def reveiller(d: ReveilIn, request: Request, db: SessionDB = Depends(get_db)):
    session = _session(db, request)
    utilisateur = session.utilisateur
    if not securite.verifier_mot_de_passe(d.mot_de_passe, utilisateur.mot_de_passe):
        session.essais_reveil += 1
        if session.essais_reveil >= ESSAIS_REVEIL:
            securite.noter_evenement(db, "ECHEC", None, {"identifiant": utilisateur.identifiant,
                                                         "motif": "5 mots de passe faux en sortie de veille",
                                                         "adresse": request.client.host if request.client else ""})
            db.delete(session)
            db.commit()
            raise HTTPException(status_code=401, detail="Trop d'essais : la session est fermée, reconnectez-vous.")
        db.commit()
        reste = ESSAIS_REVEIL - session.essais_reveil
        raise HTTPException(status_code=403, detail=f"Mot de passe incorrect ({reste} essai{'s' if reste > 1 else ''} "
                                                    "avant la fermeture de la session).")
    session.veille, session.essais_reveil, session.derniere_activite = False, 0, datetime.now()
    db.commit()
    return {"ok": True}
