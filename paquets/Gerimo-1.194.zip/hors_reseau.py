"""Mode « hors réseau » (idée de Boss du 08/10/2026) : continuer à travailler quand le serveur est injoignable.

Quand le serveur ne répond pas (agent sur le terrain, coupure de courant au bureau, panne du PC), l'application
Android propose « Continuer hors réseau » et rouvre LES ÉCRANS HABITUELS de Gérimo, nourris par une COPIE prise à
la dernière connexion :
- la copie contient les réponses exactes des routes de lecture (/api/biens, /api/contrats…), obtenues en appelant
  ces routes de l'intérieur avec l'identité de l'utilisateur : mêmes droits et mêmes calculs qu'à l'écran ;
- elle est valable un nombre de jours réglé par l'Admin (Paramètres → Réglages ; 7 par défaut), puis refusée ;
- elle est chiffrée sur le téléphone et ne s'ouvre qu'avec le mot de passe de l'utilisateur.
Sur le téléphone, static/hors_reseau/local.js répond aux écrans avec cette copie. Les enregistrements faits hors
réseau vont dans une file d'attente du téléphone, envoyée au serveur à son retour (étapes suivantes).

Téléphones autorisés (migration 027) : à la connexion, chaque téléphone reçoit une clé qui lui sert UNIQUEMENT à
rafraîchir sa copie en arrière-plan (toutes les 15 minutes, même application fermée) : au moment d'une coupure, ses
données n'ont que quelques minutes. L'Admin voit la liste et peut retirer un téléphone : sa copie est effacée au
prochain contact (réponse 410). Un compte désactivé a le même effet.

La page hors réseau (static/hors_reseau/) est copiée sur le téléphone par l'application : /api/hors-reseau/fichiers
donne la liste des fichiers et leur empreinte, pour ne retélécharger que ce qui a changé (mise à jour en ligne).
"""
import hashlib
import json
import re
import secrets
from datetime import date, datetime, timedelta
from pathlib import Path

import anyio.from_thread
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session as SessionDB

import entreprise
import parametres
import recus
from commun import montant
from models import AppareilHorsReseau, OperationHorsReseau, Paiement, Utilisateur
from securite import (NOM_COOKIE, _hacher_jeton, exiger_admin, fermer_session, get_db, marquer_utilisateur, peut_acceder,
                      ouvrir_session, utilisateur_connecte)

router = APIRouter(prefix="/api")

DOSSIER_STATIC = Path(__file__).parent / "static"
JOURS_MAX = 30
VERSION_COPIE = 2  # à augmenter si la forme de la copie change (local.js sait alors la lire)
EN_TETE_APPAREIL = "X-Gerimo-Appareil"


def actif(db: SessionDB) -> bool:
    return parametres.lire(db, "hors_reseau_actif") == "oui"


def exiger_actif(db: SessionDB) -> None:
    if not actif(db):
        raise HTTPException(status_code=403, detail="Le mode hors réseau est désactivé (Paramètres → Réglages).")


def jours_autorises(db: SessionDB) -> int:
    try:
        return max(1, min(JOURS_MAX, int(parametres.lire(db, "hors_reseau_jours") or 7)))
    except ValueError:
        return 7


# ---------- Téléphones autorisés ----------

class AppareilIn(BaseModel):
    code_appareil: str = Field(pattern=r"^[A-Za-z0-9-]{16,64}$")
    nom: str = Field(min_length=1, max_length=120)


@router.post("/hors-reseau/appareil")
def autoriser_appareil(donnees: AppareilIn, utilisateur: Utilisateur = Depends(utilisateur_connecte),
                       db: SessionDB = Depends(get_db)):
    """Appelé par l'application Android après la connexion : nouvelle clé pour ce téléphone et cet utilisateur.
    Un téléphone retiré redevient autorisé si quelqu'un s'y reconnecte avec un mot de passe valable."""
    exiger_actif(db)
    jeton = secrets.token_urlsafe(32)
    nom = "".join(c for c in donnees.nom if c.isprintable() and c not in "<>`").strip()[:120] or "Téléphone"
    appareil = db.query(AppareilHorsReseau).filter_by(code_appareil=donnees.code_appareil).first()
    if appareil is None:
        appareil = AppareilHorsReseau(code_appareil=donnees.code_appareil, cree_le=datetime.now())
        db.add(appareil)
    appareil.nom, appareil.utilisateur_id, appareil.jeton_hache = nom, utilisateur.id, _hacher_jeton(jeton)
    appareil.retire_le = appareil.retire_par = None
    db.commit()
    return {"jeton": jeton, "identifiant": utilisateur.identifiant}


def utilisateur_de_la_copie(request: Request, db: SessionDB = Depends(get_db)) -> Utilisateur:
    """Le téléphone (clé d'appareil, en arrière-plan) ou l'utilisateur connecté (session)."""
    jeton = request.headers.get(EN_TETE_APPAREIL)
    if not jeton:
        return utilisateur_connecte(request, db)
    appareil = db.query(AppareilHorsReseau).filter_by(jeton_hache=_hacher_jeton(jeton)).first()
    if appareil is None:  # clé inconnue (base restaurée…) : le téléphone en redemandera une à la prochaine connexion
        raise HTTPException(status_code=401, detail="Clé de téléphone inconnue.")
    if appareil.retire_le is not None or not appareil.utilisateur.actif:
        raise HTTPException(status_code=410, detail="Téléphone retiré du travail hors réseau : copie à effacer.")
    appareil.derniere_copie_le = datetime.now()
    marquer_utilisateur(db, appareil.utilisateur)
    return appareil.utilisateur


@router.get("/hors-reseau/appareils")
def liste_appareils(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    appareils = db.query(AppareilHorsReseau).order_by(AppareilHorsReseau.retire_le.isnot(None),
                                                      AppareilHorsReseau.derniere_copie_le.desc().nulls_last()).all()
    return [{"id": a.id, "nom": a.nom, "utilisateur": a.utilisateur.nom_complet, "role": a.utilisateur.role.value,
             "autorise_le": a.cree_le.isoformat(timespec="minutes") if a.cree_le else None,
             "derniere_copie_le": a.derniere_copie_le.isoformat(timespec="minutes") if a.derniere_copie_le else None,
             "retire": a.retire_le is not None} for a in appareils]


@router.post("/hors-reseau/appareils/{appareil_id}/retirer")
def retirer_appareil(appareil_id: int, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    appareil = db.get(AppareilHorsReseau, appareil_id)
    if appareil is None:
        raise HTTPException(status_code=404, detail="Téléphone introuvable.")
    if appareil.retire_le is None:
        appareil.retire_le, appareil.retire_par = datetime.now(), admin.id
        db.commit()
    return {"ok": True}


# ---------- Copie des données ----------

# Routes de lecture dont les écrans ont besoin. Celles que le profil n'a pas le droit de lire répondent 403 :
# elles sont simplement absentes de sa copie (hors réseau, l'écran affiche alors « au retour du serveur »).
LECTURES = (
    "/api/moi", "/api/version", "/api/entreprise", "/api/parametres/publics", "/api/vocabulaire",
    "/api/tableau-de-bord", "/api/statistiques", "/api/assistant", "/api/echeances/a-venir",
    "/api/biens", "/api/biens/options", "/api/proprietaires",
    "/api/contrats", "/api/contrats/options", "/api/locataires",
    "/api/paiements", "/api/paiements/options", "/api/impayes",
    "/api/depenses", "/api/depenses/options", "/api/achats-ventes", "/api/achats-ventes/options",
    "/api/prospects", "/api/prospects/options", "/api/signalements", "/api/signalements/options",
    "/api/etats-des-lieux", "/api/etats-des-lieux/options", "/api/courriers", "/api/courriers/options",
    "/api/sejours", "/api/sejours/options",
    "/api/tresorerie", "/api/tresorerie/comptes", "/api/tresorerie/comptes-actifs",
    "/api/reversements", "/api/reversements/a-verser",
    "/api/pieces/types", "/api/reseaux", "/api/whatsapp/derniers-envois", "/api/carte-visite",
)


async def _appel_interne(methode: str, chemin: str, corps: bytes, jeton: str) -> tuple[int | None, bytes]:
    """Une requête au logiciel lui-même, avec la session donnée : mêmes droits, mêmes règles qu'un écran."""
    import main  # chargé depuis longtemps : main importe ce module
    route, _, requete = chemin.partition("?")
    scope = {"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1", "method": methode,
             "scheme": "http", "path": route, "raw_path": route.encode(), "root_path": "",
             "query_string": requete.encode(), "client": ("127.0.0.1", 0), "server": ("127.0.0.1", 8000),
             "headers": [(b"host", b"127.0.0.1"), (b"cookie", f"{NOM_COOKIE}={jeton}".encode()),
                         (b"content-type", b"application/json"), (b"content-length", str(len(corps)).encode())]}
    etat, morceaux = {}, []

    async def recevoir():
        return {"type": "http.request", "body": corps, "more_body": False}

    async def envoyer(message):
        if message["type"] == "http.response.start":
            etat["code"] = message["status"]
        elif message["type"] == "http.response.body":
            morceaux.append(message.get("body", b""))

    await main.app(scope, recevoir, envoyer)
    return etat.get("code"), b"".join(morceaux)


def appel_interne(methode: str, chemin: str, corps: dict | None, jeton: str) -> tuple[int | None, dict]:
    """Version utilisable depuis une route ordinaire (fil de travail de FastAPI)."""
    code, contenu = anyio.from_thread.run(_appel_interne, methode, chemin,
                                          json.dumps(corps or {}).encode() if methode != "GET" else b"", jeton)
    try:
        return code, json.loads(contenu or b"{}")
    except ValueError:
        return code, {}


def lire_en_interne(db: SessionDB, utilisateur: Utilisateur, chemins: list[str]) -> dict:
    """Les routes de lecture, comme les appellerait l'écran de cet utilisateur (session temporaire, fermée à la
    fin). Renvoie {chemin: réponse JSON} pour celles qui ont répondu 200 ; puis le détail de chaque demande de
    client (prospect) et de chaque brouillon d'état des lieux, que l'écran ouvre un par un."""
    jeton = ouvrir_session(db, utilisateur)
    try:
        resultats = {}
        for chemin in chemins:
            code, reponse = appel_interne("GET", chemin, None, jeton)
            if code == 200:
                resultats[chemin] = reponse
        details = [f"/api/prospects/{p['id']}" for p in resultats.get("/api/prospects", [])[:300]]
        # brouillons d'états des lieux : on peut les reprendre hors réseau
        details += [f"/api/etats-des-lieux/{e['id']}" for e in (resultats.get("/api/etats-des-lieux") or {}).get("etats", [])
                    if e["statut"] == "Brouillon"][:50]
        for chemin in details:
            code, reponse = appel_interne("GET", chemin, None, jeton)
            if code == 200:
                resultats[chemin] = reponse
        return resultats
    finally:
        fermer_session(db, jeton)


def modeles_edl(db: SessionDB, utilisateur: Utilisateur) -> dict | None:
    """De quoi préparer un état des lieux hors réseau, comme /api/etats-des-lieux/modele : la grille de pièces de
    chaque type de logement, l'état d'entrée de chaque contrat (pour une sortie) et la caution."""
    if not peut_acceder(utilisateur.role.value, "etats_des_lieux"):
        return None
    import etats_des_lieux as edl
    from models import EtatDesLieux
    contrats = edl.contrats_visibles(db, utilisateur)
    ids = [c.id for c in contrats]
    entrees = db.query(EtatDesLieux).filter(EtatDesLieux.type_edl == "Entrée", EtatDesLieux.contrat_id.in_(ids)).all() if ids else []
    return {
        "grilles": {t: edl.grille(t) for t in {c.logement.type_logement for c in contrats}},
        "entrees": {str(e.contrat_id): {"pieces": e.pieces, "nb_cles": e.nb_cles} for e in entrees},
        "cautions": {str(c.id): montant(c.montant_caution) for c in contrats},
    }


@router.get("/hors-reseau/copie")
def copie(utilisateur: Utilisateur = Depends(utilisateur_de_la_copie), db: SessionDB = Depends(get_db)):
    """Tout ce que l'utilisateur peut consulter hors réseau (mêmes droits qu'à l'écran)."""
    exiger_actif(db)
    maintenant = datetime.now()
    jours = jours_autorises(db)
    donnees = {
        "version": VERSION_COPIE,
        "cree_le": maintenant.isoformat(timespec="seconds"),
        "valable_jusqu_au": (maintenant + timedelta(days=jours)).isoformat(timespec="seconds"),
        "jours": jours,
        "utilisateur": {"id": utilisateur.id, "identifiant": utilisateur.identifiant,
                        "nom_complet": utilisateur.nom_complet, "role": utilisateur.role.value},
        "entreprise": entreprise.identite(db),
    }
    aujourdhui = date.today()
    agenda_du, agenda_au = aujourdhui - timedelta(days=62), aujourdhui + timedelta(days=125)
    chemins = list(LECTURES) + [f"/api/agenda?debut={agenda_du}&fin={agenda_au}"]
    reponses = lire_en_interne(db, utilisateur, chemins)
    donnees["agenda"] = {"du": agenda_du.isoformat(), "au": agenda_au.isoformat(),
                         "reponse": reponses.pop(chemins[-1], None)}
    donnees["reponses"] = reponses
    donnees["edl"] = modeles_edl(db, utilisateur)
    db.commit()  # date de la dernière copie du téléphone
    return donnees


# ---------- Envoi des enregistrements faits hors réseau ----------

# Enregistrements acceptés hors réseau : les mêmes que static/hors_reseau/local.js (tout le reste y est refusé).
PERMISES = [re.compile(m) for m in (
    r"^POST /api/agenda$", r"^PUT /api/agenda/-?\d+$", r"^POST /api/agenda/-?\d+/(fait|reporter)$",
    r"^POST /api/prospects$", r"^PUT /api/prospects/-?\d+$", r"^POST /api/prospects/-?\d+/suivi$",
    r"^POST /api/signalements$",
    r"^POST /api/etats-des-lieux$", r"^PUT /api/etats-des-lieux/-?\d+$", r"^POST /api/etats-des-lieux/-?\d+/(photos|signer)$",
    r"^POST /api/etats-des-lieux/photos/-?\d+/retirer$",
    r"^POST /api/paiements$",
    r"^POST /api/depenses$", r"^PUT /api/depenses/-?\d+$",
    r"^POST /api/contrats$", r"^PUT /api/locataires/-?\d+$", r"^POST /api/pieces$",
)]
CONTRAT = "/api/contrats"  # un contrat fait hors réseau est toujours « En attente » : l'Admin le valide au bureau
ENCAISSEMENT, DEPENSE = "/api/paiements", "/api/depenses"
ARGENT = (ENCAISSEMENT, DEPENSE)  # ce que la Caisse décide et contrôle
# Gros contenus (photos, signatures) : gardés tant que l'enregistrement est à vérifier, allégés une fois envoyé
CHAMPS_LOURDS = ("contenu", "photo", "signature_locataire", "signature_agent")


class OperationIn(BaseModel):
    uid: str = Field(pattern=r"^[A-Za-z0-9.-]{8,64}$")
    methode: str = Field(pattern=r"^(POST|PUT)$")
    chemin: str = Field(pattern=r"^/api/[A-Za-z0-9/_-]{1,290}$")
    corps: dict = {}
    saisi_le: datetime
    resume: str = Field("", max_length=300)
    identifiant: str = Field("", max_length=80)
    id_local: int | None = None
    copie_du: datetime | None = None  # date de la copie du téléphone au moment de la saisie
    autres_ids: dict[str, int] = {}   # autres numéros provisoires, ex. {"locataire_id": -12} d'un nouveau contrat


class EnvoiIn(BaseModel):
    appareil: str = Field("", max_length=120)
    operations: list[OperationIn] = Field(max_length=500)


def _remplacer_ids(chemin: str, corps: dict, correspondances: dict[int, int]) -> tuple[str, dict, list[int]]:
    """Numéros provisoires du téléphone (négatifs) → numéros donnés par le serveur. Renvoie aussi ceux qui
    restent inconnus (l'enregistrement dont ils dépendent a été refusé)."""
    inconnus = []

    def segment(m):
        n = int(m.group(1))
        if n in correspondances:
            return f"/{correspondances[n]}"
        inconnus.append(n)
        return m.group(0)
    chemin = re.sub(r"/(-\d+)(?=/|$)", segment, chemin)
    corps = dict(corps)
    for cle, valeur in corps.items():
        if cle.endswith("_id") and isinstance(valeur, int) and valeur < 0:
            if valeur in correspondances:
                corps[cle] = correspondances[valeur]
            else:
                inconnus.append(valeur)
    return chemin, corps, inconnus


def _noter_au_journal(db: SessionDB, o: OperationHorsReseau, utilisateur: Utilisateur) -> None:
    details = {"resume": o.resume, "appareil": o.appareil_nom, "statut": o.statut, "detail": o.detail,
               "saisi_le": o.saisi_le.strftime("%d/%m/%Y à %H:%M")}
    db.execute(text("INSERT INTO journal (utilisateur_id, utilisateur_nom, operation, table_nom, ligne_id, apres) "
                    "VALUES (:uid, :nom, 'HORSRESEAU', 'operations_hors_reseau', :lid, CAST(:details AS JSONB))"),
               {"uid": utilisateur.id, "nom": utilisateur.nom_complet, "lid": str(o.id),
                "details": json.dumps(details, ensure_ascii=False)})


def _paye_entre_temps(db: SessionDB, o: OperationHorsReseau, copie_du: datetime) -> Paiement | None:
    """Encaissement hors réseau : le locataire a-t-il AUSSI payé (au bureau…) depuis la copie du téléphone ?
    Les encaissements hors réseau de la même personne ne comptent pas (plusieurs bons pour un même contrat)."""
    contrat_id = (o.corps or {}).get("contrat_id")
    if not isinstance(contrat_id, int) or contrat_id < 0:
        return None
    venus_hors_reseau = db.query(OperationHorsReseau.id_reel).filter(
        OperationHorsReseau.chemin == ENCAISSEMENT, OperationHorsReseau.id_reel.isnot(None))
    return db.query(Paiement).filter(
        # l'heure de la copie est arrondie à la seconde : ce qui date de cette seconde-là y figure déjà
        Paiement.contrat_id == contrat_id, Paiement.cree_le >= copie_du.replace(tzinfo=None) + timedelta(seconds=1),
        Paiement.statut_paiement != "Annulé", Paiement.id.not_in(venus_hors_reseau)
    ).order_by(Paiement.cree_le).first()


def _rejouer(o: OperationHorsReseau, jeton: str, correspondances: dict[int, int], db: SessionDB | None = None,
             copie_du: datetime | None = None) -> None:
    """Rejoue l'enregistrement sur le serveur ; statut « Envoyée » ou « À vérifier » avec la raison.
    copie_du (premier envoi) : un encaissement est mis « à vérifier » si le locataire a payé entre-temps."""
    chemin, corps, inconnus = _remplacer_ids(o.chemin, o.corps or {}, correspondances)
    if not any(m.match(f"{o.methode} {o.chemin}") for m in PERMISES):
        o.statut, o.detail = "À vérifier", "Cette action n'est pas permise hors réseau."
        return
    if inconnus:
        o.statut, o.detail = "À vérifier", "Dépend d'un autre enregistrement hors réseau qui a été refusé."
        return
    if o.chemin == ENCAISSEMENT and db is not None and copie_du is not None:
        autre = _paye_entre_temps(db, o, copie_du)
        if autre is not None:
            o.statut = "À vérifier"
            o.detail = (f"Pendant ce temps, ce locataire a aussi payé : reçu {autre.numero_recu} du "
                        f"{autre.date_paiement.strftime('%d/%m/%Y')} ({recus.francs(autre.montant)}, {autre.mode_paiement}). "
                        "Même argent compté deux fois ? « Enregistrer quand même » l'ajoute (mois suivants), "
                        "« Abandonner » l'écarte (à rembourser si besoin).")
            return
    if o.chemin == CONTRAT:
        corps["statut_contrat"] = "En attente"
    for champ in ("proprietaire_id", "locataire_id"):  # pièce jointe d'une fiche créée hors réseau
        if isinstance(corps.get(champ), int) and corps[champ] < 0:
            if corps[champ] in correspondances:
                corps[champ] = correspondances[corps[champ]]
            else:
                o.statut, o.detail = "À vérifier", "Dépend d'une fiche créée hors réseau qui a été refusée."
                return
    code, reponse = appel_interne(o.methode, chemin, corps, jeton)
    if code is not None and 200 <= code < 300:
        o.statut, o.detail = "Envoyée", None
        if any(c in (o.corps or {}) for c in CHAMPS_LOURDS):
            o.corps = {k: ("(fichier envoyé)" if k in CHAMPS_LOURDS and v else v) for k, v in o.corps.items()}
        o.id_reel = reponse.get("id") if isinstance(reponse.get("id"), int) else None
        if o.id_local is not None and o.id_reel is not None:
            correspondances[int(o.id_local)] = o.id_reel
        for champ, provisoire in (getattr(o, "autres_ids", None) or {}).items():  # ex. le locataire du contrat
            if isinstance(reponse.get(champ), int):
                correspondances[int(provisoire)] = reponse[champ]
    else:
        detail = reponse.get("detail")
        if isinstance(detail, list):  # erreur de saisie (422) : premier message lisible
            detail = "; ".join(str(d.get("msg", d)) for d in detail[:3])
        o.statut, o.detail = "À vérifier", str(detail or f"Refusé par le serveur (code {code}).")[:1000]


@router.post("/hors-reseau/envoyer")
def envoyer(donnees: EnvoiIn, request: Request, utilisateur: Utilisateur = Depends(utilisateur_connecte),
            db: SessionDB = Depends(get_db)):
    """File d'attente d'un téléphone, dans l'ordre où elle a été saisie. Chaque enregistrement n'est traité qu'une
    fois (uid) : si la connexion coupe pendant l'envoi, le téléphone renvoie tout sans créer de doublon."""
    jeton = request.cookies.get(NOM_COOKIE)
    correspondances: dict[int, int] = {}
    resultats = []
    for op in donnees.operations:
        if op.identifiant and op.identifiant != utilisateur.identifiant:
            resultats.append({"uid": op.uid, "statut": "Autre utilisateur"})  # restera sur le téléphone
            continue
        o = db.query(OperationHorsReseau).filter_by(uid=op.uid).first()
        if o is None:
            o = OperationHorsReseau(uid=op.uid, utilisateur_id=utilisateur.id, appareil_nom=donnees.appareil[:120] or None,
                                    methode=op.methode, chemin=op.chemin, corps=op.corps, resume=op.resume[:300],
                                    id_local=op.id_local, saisi_le=op.saisi_le.replace(tzinfo=None),
                                    recu_le=datetime.now(), statut="À vérifier")
            o.autres_ids = op.autres_ids
            _rejouer(o, jeton, correspondances, db, op.copie_du)
            if o.chemin in ARGENT and o.statut == "Envoyée" and utilisateur.role.value == "Caisse":
                o.argent_recu_le, o.argent_recu_par = datetime.now(), utilisateur.id  # rien à se remettre à soi-même
            db.add(o)
            db.flush()
            _noter_au_journal(db, o, utilisateur)
            db.commit()
        elif o.id_local is not None and o.id_reel is not None:
            correspondances[int(o.id_local)] = o.id_reel
        resultats.append({"uid": o.uid, "statut": o.statut, "detail": o.detail, "id_reel": o.id_reel})
    return {"resultats": resultats,
            "envoyees": sum(r["statut"] == "Envoyée" for r in resultats),
            "a_verifier": sum(r["statut"] == "À vérifier" for r in resultats)}


def _operation_json(o: OperationHorsReseau) -> dict:
    return {"id": o.id, "resume": o.resume, "utilisateur": o.utilisateur.nom_complet, "appareil": o.appareil_nom,
            "saisi_le": o.saisi_le.isoformat(timespec="minutes"), "recu_le": o.recu_le.isoformat(timespec="minutes"),
            "statut": o.statut, "detail": o.detail, "corps": o.corps}


@router.get("/hors-reseau/a-verifier")
def a_verifier(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    """Enregistrements hors réseau que le serveur a refusés : l'Admin réessaie (après correction) ou abandonne."""
    return [_operation_json(o) for o in db.query(OperationHorsReseau).filter_by(statut="À vérifier")
            .order_by(OperationHorsReseau.saisi_le).all()]


def _charger_a_verifier(db: SessionDB, operation_id: int) -> OperationHorsReseau:
    o = db.get(OperationHorsReseau, operation_id)
    if o is None or o.statut != "À vérifier":
        raise HTTPException(status_code=404, detail="Enregistrement introuvable ou déjà traité.")
    return o


def _peut_traiter(utilisateur: Utilisateur, o: OperationHorsReseau) -> None:
    """L'Admin traite tout ; la Caisse, les encaissements et les dépenses (c'est elle qui décide pour l'argent)."""
    role = utilisateur.role.value
    if role != "Admin" and not (role == "Caisse" and o.chemin.startswith(ARGENT)):
        raise HTTPException(status_code=403, detail="Réservé à l'administrateur.")


@router.post("/hors-reseau/a-verifier/{operation_id}/reessayer")
def reessayer(operation_id: int, request: Request, utilisateur: Utilisateur = Depends(utilisateur_connecte),
              db: SessionDB = Depends(get_db)):
    """Rejoue l'enregistrement maintenant, par exemple après avoir libéré un logement ; pour un encaissement mis de
    côté (le locataire avait aussi payé au bureau) : « Enregistrer quand même ». Un encaissement garde son auteur
    (l'agent qui a reçu l'argent) ; les autres enregistrements passent avec les droits de l'Admin."""
    o = _charger_a_verifier(db, operation_id)
    _peut_traiter(utilisateur, o)
    correspondances = {int(x.id_local): x.id_reel for x in db.query(OperationHorsReseau).filter(
        OperationHorsReseau.utilisateur_id == o.utilisateur_id, OperationHorsReseau.id_reel.isnot(None),
        OperationHorsReseau.id_local.isnot(None))}
    if o.chemin == ENCAISSEMENT and o.utilisateur.actif:
        jeton = ouvrir_session(db, o.utilisateur)
        try:
            _rejouer(o, jeton, correspondances)
        finally:
            fermer_session(db, jeton)
    else:
        _rejouer(o, request.cookies.get(NOM_COOKIE), correspondances)
    if o.statut == "Envoyée":
        o.traite_par, o.traite_le = utilisateur.id, datetime.now()
    _noter_au_journal(db, o, utilisateur)
    db.commit()
    return _operation_json(o)


@router.post("/hors-reseau/a-verifier/{operation_id}/abandonner")
def abandonner(operation_id: int, utilisateur: Utilisateur = Depends(utilisateur_connecte),
               db: SessionDB = Depends(get_db)):
    o = _charger_a_verifier(db, operation_id)
    _peut_traiter(utilisateur, o)
    o.statut, o.traite_par, o.traite_le = "Abandonnée", utilisateur.id, datetime.now()
    _noter_au_journal(db, o, utilisateur)
    db.commit()
    return _operation_json(o)


# ---------- Encaissements hors réseau : décision de la Caisse et argent remis ----------

def exiger_caisse(utilisateur: Utilisateur = Depends(utilisateur_connecte)) -> Utilisateur:
    if utilisateur.role.value not in ("Admin", "Caisse"):
        raise HTTPException(status_code=403, detail="Réservé à la Caisse et à l'Admin.")
    return utilisateur


def _encaissement_json(db: SessionDB, o: OperationHorsReseau) -> dict:
    c = o.corps or {}
    paiement = db.get(Paiement, o.id_reel) if o.id_reel and o.chemin == ENCAISSEMENT else None
    return {**_operation_json(o), "montant": c.get("montant"), "mode": c.get("mode_paiement"), "motif": c.get("motif"),
            "numero_recu": paiement.numero_recu if paiement else None,
            "locataire": paiement.contrat.locataire.nom_complet if paiement else None,
            "argent_recu_le": o.argent_recu_le.isoformat(timespec="minutes") if o.argent_recu_le else None}


@router.get("/hors-reseau/encaissements")
def encaissements(utilisateur: Utilisateur = Depends(exiger_caisse), db: SessionDB = Depends(get_db)):
    """Pour l'écran Finances : encaissements et dépenses hors réseau à vérifier, argent encore à remettre à la
    caisse, et dépenses faites par les agents à contrôler (justificatif)."""
    ops = db.query(OperationHorsReseau).filter(
        (OperationHorsReseau.chemin == ENCAISSEMENT) | OperationHorsReseau.chemin.startswith(DEPENSE),
        OperationHorsReseau.statut.in_(("À vérifier", "Envoyée"))).order_by(OperationHorsReseau.saisi_le).all()
    envoyees = [o for o in ops if o.statut == "Envoyée" and o.argent_recu_le is None]
    return {"a_verifier": [_encaissement_json(db, o) for o in ops if o.statut == "À vérifier"],
            "a_remettre": [_encaissement_json(db, o) for o in envoyees if o.chemin == ENCAISSEMENT],
            "depenses_a_controler": [_encaissement_json(db, o) for o in envoyees if o.chemin == DEPENSE]}


@router.post("/hors-reseau/encaissements/{operation_id}/argent-recu")
def argent_recu(operation_id: int, utilisateur: Utilisateur = Depends(exiger_caisse), db: SessionDB = Depends(get_db)):
    """La Caisse confirme que l'agent lui a remis l'argent encaissé hors réseau (rien n'est ressaisi), ou qu'elle a
    contrôlé une dépense faite hors réseau (justificatif, monnaie rendue)."""
    o = db.get(OperationHorsReseau, operation_id)
    if o is None or o.chemin not in ARGENT or o.statut != "Envoyée":
        raise HTTPException(status_code=404, detail="Enregistrement hors réseau introuvable.")
    if o.argent_recu_le is None:
        o.argent_recu_le, o.argent_recu_par = datetime.now(), utilisateur.id
        o.detail = (f"Argent remis à {utilisateur.nom_complet}" if o.chemin == ENCAISSEMENT
                    else f"Dépense contrôlée par {utilisateur.nom_complet}")
        _noter_au_journal(db, o, utilisateur)
        db.commit()
    return _encaissement_json(db, o)


# ---------- Fichiers de la page hors réseau (copiés sur le téléphone) ----------

def _fichiers_statiques() -> list[Path]:
    """La page d'entrée hors réseau, et tout ce qu'il faut aux écrans habituels (scripts, styles, polices, images)."""
    fichiers = sorted((DOSSIER_STATIC / "hors_reseau").glob("*.*"))
    fichiers += [DOSSIER_STATIC / "app.html"]
    fichiers += sorted((DOSSIER_STATIC / "js").glob("*.js"))
    fichiers += sorted((DOSSIER_STATIC / "css").glob("*.css"))
    fichiers += sorted((DOSSIER_STATIC / "fonts").glob("*.woff2"))
    fichiers += sorted(f for f in (DOSSIER_STATIC / "img").glob("*.*") if f.suffix in (".svg", ".png", ".jpg"))
    return [f for f in fichiers if f.is_file()]


_empreintes: dict[Path, tuple[float, str]] = {}


def _empreinte(chemin: Path) -> str:
    """Empreinte du contenu, recalculée seulement si le fichier a changé."""
    modifie = chemin.stat().st_mtime
    connue = _empreintes.get(chemin)
    if connue is None or connue[0] != modifie:
        connue = (modifie, hashlib.sha256(chemin.read_bytes()).hexdigest()[:16])
        _empreintes[chemin] = connue
    return connue[1]


@router.get("/hors-reseau/fichiers")
def fichiers():
    """Liste publique (ce sont des fichiers publics) : chemin à demander au serveur + empreinte."""
    liste = [{"chemin": "/static/" + f.relative_to(DOSSIER_STATIC).as_posix(), "empreinte": _empreinte(f)}
             for f in _fichiers_statiques()]
    liste.append({"chemin": "/entreprise/logo", "empreinte": _empreinte(entreprise.logo())})
    liste.append({"chemin": "/api/hors-reseau/app", "empreinte": _empreinte(DOSSIER_STATIC / "app.html")
                  + _empreinte(DOSSIER_STATIC / "hors_reseau" / "local.js")})
    return {"page": "/static/hors_reseau/index.html", "fichiers": liste}


@router.get("/hors-reseau/app", include_in_schema=False)
def ecrans_hors_reseau():
    """Les écrans habituels (app.html), précédés de local.js qui leur répond avec la copie du téléphone."""
    html = (DOSSIER_STATIC / "app.html").read_text(encoding="utf-8")
    html = html.replace('<link rel="stylesheet" href="/static/css/style.css">',
                        '<script src="/static/hors_reseau/local.js"></script>\n'
                        '<link rel="stylesheet" href="/static/css/style.css">', 1)
    return HTMLResponse(html)
