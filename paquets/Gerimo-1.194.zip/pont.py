"""Le « pont » (Admin) : reprendre les données directement dans la base d'un ancien logiciel du client.

Garanties, vérifiées ici :
- Accord écrit : l'Admin confirme que le client a donné son accord et que la licence de l'ancien logiciel le permet.
- LECTURE SEULE : connexion ouverte en lecture seule quand la base le permet (SQLite, Access, PostgreSQL, MySQL),
  et seules des requêtes SELECT construites ici sont envoyées (noms de tables et de colonnes vérifiés dans le
  catalogue de la base, jamais tapés à la main).
- Colonnes CONFIDENTIELLES jamais lues : mots de passe, codes, clés, données bancaires… (liste noire par nom),
  et les champs de remarques sont exclus par défaut (on ne sait pas ce qu'on y a écrit).
- Rien n'est envoyé ailleurs : tout se passe sur le serveur Gérimo du client. Les identifiants de connexion ne sont
  utilisés que le temps de la lecture, jamais enregistrés. Les données lues vont dans le même assistant que pour
  Excel (fichier temporaire effacé après l'import, ou au plus tard après 24 h).
- Les liens de l'ancienne base (ex. contrats.locataire_id → locataires) sont remplacés par le nom lisible
  (ex. « Koné Ibrahim »), pour que l'assistant puisse rapprocher les éléments.

Bases prises en charge : SQLite (fichier), Microsoft Access (fichier .mdb/.accdb, pilote Windows), PostgreSQL,
MySQL / MariaDB, SQL Server (pilote Windows).
"""
import json
import re
import secrets
import sqlite3
import tempfile
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

import import_donnees
from models import Utilisateur
from securite import exiger_admin

router = APIRouter(prefix="/api")
LIGNES_MAX = import_donnees.LIGNES_MAX
TAILLE_MAX_FICHIER = 500 * 1024 * 1024

# Colonnes jamais lues (le nom suffit à les écarter, avant toute lecture)
CONFIDENTIELLES = re.compile(
    r"pass|pwd|mdp|mot.?de.?passe|hash|salt|secret|token|jeton|api.?key|cle.?api|\bpin\b|code.?pin|otp|"
    r"iban|rib|bic|swift|carte|card|cvv|cvc|bancaire|bank|compte.?banc|numero.?compte|credential|session|cookie",
    re.I)
REMARQUES = re.compile(r"note|remarque|comment|observation|memo|commentaire", re.I)
NOMS_LISIBLES = ("nom_complet", "nom", "name", "libelle", "designation", "intitule", "raison_sociale", "numero",
                 "reference", "code", "titre")
TYPES_BASES = {"sqlite": "SQLite (fichier .db, .sqlite)", "access": "Microsoft Access (fichier .mdb, .accdb)",
               "postgresql": "PostgreSQL", "mysql": "MySQL / MariaDB", "sqlserver": "SQL Server"}
DOSSIER_FICHIERS = import_donnees.DOSSIER_TEMP


# ---------- Connexions (lecture seule) ----------

class Source(BaseModel):
    type: str
    fichier: str | None = None                 # jeton du fichier envoyé (SQLite, Access)
    hote: str | None = Field(None, max_length=200)
    port: int | None = Field(None, ge=1, le=65535)
    base: str | None = Field(None, max_length=200)
    utilisateur: str | None = Field(None, max_length=200)
    mot_de_passe: str | None = Field(None, max_length=500)
    accord: bool = False


class Connexion:
    """Connexion à l'ancienne base ; seules les méthodes ci-dessous l'interrogent."""

    def __init__(self, source: Source):
        if not source.accord:
            raise HTTPException(status_code=400, detail="Cochez la case d'accord : le client autorise la lecture de "
                                                        "sa base, et la licence de son ancien logiciel le permet.")
        if source.type not in TYPES_BASES:
            raise HTTPException(status_code=400, detail="Type de base non pris en charge.")
        self.type, self.source = source.type, source
        self.guillemet = {"mysql": "`", "access": "[", "sqlserver": "["}.get(source.type, '"')
        try:
            self.cnx = self._ouvrir(source)
        except HTTPException:
            raise
        except Exception as e:  # noqa: BLE001 — message du pilote, sans le mot de passe
            message = str(e).replace(source.mot_de_passe or "\0", "****")[:300]
            raise HTTPException(status_code=400, detail=f"Connexion impossible à l'ancienne base : {message}")

    def _fichier(self) -> Path:
        if not self.source.fichier or not re.fullmatch(r"[A-Za-z0-9_\-]{10,60}", self.source.fichier):
            raise HTTPException(status_code=400, detail="Envoyez d'abord le fichier de la base.")
        trouves = list(DOSSIER_FICHIERS.glob(f"base_{self.source.fichier}.*"))
        if not trouves:
            raise HTTPException(status_code=404, detail="Fichier de base introuvable (plus de 24 h ?) : renvoyez-le.")
        return trouves[0]

    def _ouvrir(self, s: Source):
        if s.type == "sqlite":
            cnx = sqlite3.connect(f"file:{self._fichier().as_posix()}?mode=ro", uri=True)
            cnx.execute("PRAGMA query_only = ON")
            return cnx
        if s.type == "access":
            import pyodbc
            return pyodbc.connect(f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={self._fichier()};"
                                  "ReadOnly=1;Exclusive=0;", readonly=True, timeout=15)
        if not s.hote or not s.base:
            raise HTTPException(status_code=400, detail="Indiquez l'adresse du serveur et le nom de la base.")
        if s.type == "postgresql":
            import psycopg2
            cnx = psycopg2.connect(host=s.hote, port=s.port or 5432, dbname=s.base, user=s.utilisateur,
                                   password=s.mot_de_passe, connect_timeout=10,
                                   options="-c default_transaction_read_only=on")
            cnx.set_session(readonly=True, autocommit=False)
            return cnx
        if s.type == "mysql":
            import pymysql
            cnx = pymysql.connect(host=s.hote, port=s.port or 3306, database=s.base, user=s.utilisateur,
                                  password=s.mot_de_passe or "", connect_timeout=10, charset="utf8mb4")
            with cnx.cursor() as c:
                c.execute("SET SESSION TRANSACTION READ ONLY")
            return cnx
        import pyodbc  # sqlserver
        pilote = next((d for d in reversed(pyodbc.drivers()) if "SQL Server" in d), None)
        if pilote is None:
            raise HTTPException(status_code=400, detail="Aucun pilote SQL Server sur ce PC.")
        return pyodbc.connect(f"DRIVER={{{pilote}}};SERVER={s.hote}{',' + str(s.port) if s.port else ''};"
                              f"DATABASE={s.base};UID={s.utilisateur};PWD={s.mot_de_passe};"
                              "ApplicationIntent=ReadOnly;TrustServerCertificate=yes", readonly=True, timeout=15)

    def fermer(self) -> None:
        try:
            self.cnx.close()
        except Exception:  # noqa: BLE001
            pass

    def q(self, nom: str) -> str:
        fin = "]" if self.guillemet == "[" else self.guillemet
        return f"{self.guillemet}{nom.replace(fin, fin + fin)}{fin}"

    def _executer(self, sql: str, params: tuple = ()) -> list[tuple]:
        assert sql.lstrip().upper().startswith("SELECT"), "le pont n'envoie que des lectures"
        c = self.cnx.cursor()
        try:
            c.execute(sql, params) if params else c.execute(sql)
            return [tuple(l) for l in c.fetchmany(LIGNES_MAX + 1)]
        finally:
            c.close()

    # --- catalogue : tables, colonnes, liens ---

    def tables(self) -> dict[str, list[str]]:
        t = self.type
        if t == "sqlite":
            noms = [n for (n,) in self._executer("SELECT name FROM sqlite_master WHERE type = 'table' "
                                                 "AND name NOT LIKE 'sqlite_%' ORDER BY name")]
            return {n: [l[1] for l in self.cnx.execute(f"PRAGMA table_info({self.q(n)})")] for n in noms}
        if t in ("access", "sqlserver"):
            c = self.cnx.cursor()
            noms = [r.table_name for r in c.tables(tableType="TABLE")
                    if not r.table_name.startswith(("MSys", "~", "sys"))]
            resultat = {n: [col.column_name for col in self.cnx.cursor().columns(table=n)] for n in noms}
            c.close()
            return resultat
        schema = "public" if t == "postgresql" else self.source.base
        lignes = self._executer("SELECT table_name, column_name FROM information_schema.columns WHERE table_schema = %s "
                                "ORDER BY table_name, ordinal_position", (schema,))
        resultat: dict[str, list[str]] = {}
        for table, colonne in lignes:
            resultat.setdefault(table, []).append(colonne)
        return resultat

    def liens(self, table: str) -> dict[str, tuple[str, str]]:
        """Clés étrangères déclarées : colonne → (table liée, colonne liée)."""
        try:
            if self.type == "sqlite":
                return {l[3]: (l[2], l[4] or "id") for l in self.cnx.execute(f"PRAGMA foreign_key_list({self.q(table)})")}
            if self.type in ("access", "sqlserver"):
                return {r.fkcolumn_name: (r.pktable_name, r.pkcolumn_name)
                        for r in self.cnx.cursor().foreignKeys(foreignTable=table)}
            schema = "public" if self.type == "postgresql" else self.source.base
            lignes = self._executer(
                "SELECT kcu.column_name, ccu.table_name, ccu.column_name FROM information_schema.table_constraints tc "
                "JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name "
                "AND tc.table_schema = kcu.table_schema "
                "JOIN information_schema.constraint_column_usage ccu ON tc.constraint_name = ccu.constraint_name "
                "WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_name = %s AND tc.table_schema = %s",
                (table, schema)) if self.type == "postgresql" else self._executer(
                "SELECT column_name, referenced_table_name, referenced_column_name FROM "
                "information_schema.key_column_usage WHERE table_schema = %s AND table_name = %s "
                "AND referenced_table_name IS NOT NULL", (schema, table))
            return {col: (ref, refcol) for col, ref, refcol in lignes}
        except Exception:  # noqa: BLE001 — pilote sans catalogue des liens : on devinera par le nom
            return {}

    def lire(self, table: str, colonnes: list[str]) -> list[tuple]:
        if not colonnes:
            return []
        haut = f"TOP {LIGNES_MAX + 1} " if self.type in ("access", "sqlserver") else ""
        bas = "" if haut else f" LIMIT {LIGNES_MAX + 1}"
        return self._executer(f"SELECT {haut}{', '.join(self.q(c) for c in colonnes)} FROM {self.q(table)}{bas}")


# ---------- Préparation des données pour l'assistant ----------

def colonnes_autorisees(colonnes: list[str], avec_remarques: bool) -> tuple[list[str], list[str]]:
    gardees, exclues = [], []
    for c in colonnes:
        if CONFIDENTIELLES.search(c) or (not avec_remarques and REMARQUES.search(c)):
            exclues.append(c)
        else:
            gardees.append(c)
    return gardees, exclues


def _valeur(v):
    if isinstance(v, datetime):
        return v.date().isoformat() if v.time() == datetime.min.time() else v.isoformat()
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, Decimal):
        return int(v) if v == v.to_integral_value() else float(v)
    if isinstance(v, bool):
        return "Oui" if v else "Non"
    if isinstance(v, (int, float, str)) or v is None:
        return v
    if isinstance(v, (bytes, bytearray, memoryview)):
        return None  # pièces binaires (images…) : non reprises
    return str(v)


def _colonne_lisible(colonnes: list[str]) -> str | None:
    normes = {import_donnees.norm(c).replace(" ", "_"): c for c in colonnes}
    for nom in NOMS_LISIBLES:
        if nom in normes:
            return normes[nom]
    return next((c for c in colonnes if "nom" in c.lower() or "name" in c.lower()), None)


def _table_liee(colonne: str, tables: dict[str, list[str]]) -> str | None:
    """« locataire_id » → table « locataires » (lien non déclaré dans la base)."""
    m = re.fullmatch(r"(?:id_?)?([a-z]+?)(?:_?id)?", colonne.lower())
    if not m or m.group(1) == colonne.lower():
        return None
    racine = m.group(1)
    for t in tables:
        if t.lower() in (racine, racine + "s", racine + "x", racine + "es"):
            return t
    return None


def extraire(cnx: Connexion, choix: list[str], avec_remarques: bool) -> list[dict]:
    """Lit les tables choisies (colonnes autorisées seulement) et remplace les liens par des noms lisibles."""
    tables = cnx.tables()
    feuilles = []
    cache_lisibles: dict[str, dict] = {}

    def lisibles(table: str, cle: str) -> dict:
        if (table, cle) not in cache_lisibles:
            gardees, _ = colonnes_autorisees(tables.get(table, []), False)
            affichee = _colonne_lisible([c for c in gardees if c != cle])
            cache_lisibles[(table, cle)] = (
                {k: v for k, v in cnx.lire(table, [cle, affichee])} if affichee and cle in tables.get(table, []) else {})
        return cache_lisibles[(table, cle)]

    for table in choix:
        if table not in tables:
            raise HTTPException(status_code=400, detail=f"Table « {table} » introuvable dans l'ancienne base.")
        gardees, _ = colonnes_autorisees(tables[table], avec_remarques)
        lignes = cnx.lire(table, gardees)
        liens = cnx.liens(table)
        colonnes = list(gardees)
        remplacements = {}
        for i, col in enumerate(gardees):
            ref = liens.get(col) or ((_table_liee(col, tables), "id") if _table_liee(col, tables) else None)
            if ref and ref[0] != table:
                correspondance = lisibles(ref[0], ref[1] if ref[1] in tables.get(ref[0], []) else "id")
                if correspondance:
                    remplacements[i] = correspondance
                    colonnes[i] = f"{col} ({ref[0]})"
        donnees = []
        for k, l in enumerate(lignes[:LIGNES_MAX]):
            valeurs = [_valeur(remplacements[i].get(v, v) if i in remplacements else v) for i, v in enumerate(l)]
            if any(v not in (None, "") for v in valeurs):
                donnees.append({"ligne": k + 1, "valeurs": valeurs})
        feuilles.append({"nom": table, "colonnes": colonnes, "lignes": donnees, "trop": len(lignes) > LIGNES_MAX})
    return feuilles


# ---------- API (Admin) ----------

@router.get("/pont/types")
def types_bases(admin: Utilisateur = Depends(exiger_admin)):
    try:
        import pyodbc
        pilotes = pyodbc.drivers()
    except Exception:  # noqa: BLE001
        pilotes = []
    disponibles = {"sqlite": True, "postgresql": True, "mysql": True,
                   "access": any("Access Driver" in p for p in pilotes), "sqlserver": any("SQL Server" in p for p in pilotes)}
    return {"types": [{"type": t, "libelle": l, "disponible": disponibles[t],
                       "fichier": t in ("sqlite", "access")} for t, l in TYPES_BASES.items()]}


@router.post("/pont/fichier")
async def envoyer_fichier(request: Request, nom: str = "base.db", admin: Utilisateur = Depends(exiger_admin)):
    """Fichier de base (SQLite, Access) : copié le temps de la lecture, effacé ensuite (24 h au plus)."""
    extension = Path(nom).suffix.lower()
    if extension not in (".db", ".sqlite", ".sqlite3", ".db3", ".mdb", ".accdb"):
        raise HTTPException(status_code=400, detail="Fichier de base attendu : .db, .sqlite, .mdb ou .accdb.")
    import_donnees._menage()
    for ancien in DOSSIER_FICHIERS.glob("base_*") if DOSSIER_FICHIERS.exists() else []:
        if ancien.stat().st_mtime < (datetime.now().timestamp() - import_donnees.DUREE_TEMP):
            ancien.unlink(missing_ok=True)
    DOSSIER_FICHIERS.mkdir(exist_ok=True)
    jeton = secrets.token_urlsafe(18)
    chemin = DOSSIER_FICHIERS / f"base_{jeton}{extension}"
    taille = 0
    with open(chemin, "wb") as f:
        async for morceau in request.stream():
            taille += len(morceau)
            if taille > TAILLE_MAX_FICHIER:
                f.close()
                chemin.unlink(missing_ok=True)
                raise HTTPException(status_code=413, detail="Fichier trop gros (500 Mo maximum).")
            f.write(morceau)
    return {"fichier": jeton, "type": "access" if extension in (".mdb", ".accdb") else "sqlite"}


@router.post("/pont/explorer")
def explorer(source: Source, admin: Utilisateur = Depends(exiger_admin)):
    """Liste les tables de l'ancienne base, avec les colonnes qui seront lues et celles exclues d'office."""
    cnx = Connexion(source)
    try:
        resultat = []
        for table, colonnes in cnx.tables().items():
            gardees, exclues = colonnes_autorisees(colonnes, False)
            confidentielles = [c for c in exclues if CONFIDENTIELLES.search(c)]
            resultat.append({"table": table, "colonnes": gardees, "confidentielles": confidentielles,
                             "remarques": [c for c in exclues if c not in confidentielles],
                             "type": import_donnees.deviner_type({"nom": table, "colonnes": gardees})})
    finally:
        cnx.fermer()
    return {"tables": resultat}


class Extraction(Source):
    tables: list[str]
    avec_remarques: bool = False


@router.post("/pont/extraire")
def extraire_vers_assistant(donnees: Extraction, admin: Utilisateur = Depends(exiger_admin)):
    """Lit les tables choisies et les confie à l'assistant de reprise (mêmes étapes que pour un fichier Excel)."""
    if not donnees.tables:
        raise HTTPException(status_code=400, detail="Choisissez au moins une table.")
    cnx = Connexion(donnees)
    try:
        feuilles = extraire(cnx, donnees.tables[:30], donnees.avec_remarques)
    finally:
        cnx.fermer()
        if donnees.fichier:  # la copie du fichier de base n'est plus utile : effacée tout de suite
            for f in DOSSIER_FICHIERS.glob(f"base_{donnees.fichier}.*"):
                f.unlink(missing_ok=True)
    if donnees.type in ("sqlite", "access"):
        source = f"Base {TYPES_BASES[donnees.type].split(' (')[0]}"
    else:
        source = f"Base {TYPES_BASES[donnees.type]} « {donnees.base} » ({donnees.hote})"
    return import_donnees.preparer_assistant(source, feuilles)
