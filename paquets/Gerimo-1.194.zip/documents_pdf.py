"""Mise en page des nouveaux documents PDF : état des lieux, courriers (révision de loyer,
avenant au bail). Même en-tête ISUP et mêmes couleurs que les reçus (recus.py).
"""
import base64
import io
from decimal import Decimal

from entreprise import est_entreprise
from recus import (ENCRE, ENTETE, FOND_VERT, GRIS, MARINE, ORANGE, PDF, VERT, _entete, francs)

ROUGE = (176, 57, 44)
COULEUR_ETAT = {
    "Neuf": (76, 138, 74), "Bon état": (76, 138, 74), "État d'usage": (183, 121, 31),
    "Mauvais état": ROUGE, "Hors service": ROUGE, "Absent / sans objet": GRIS,
}


class _PDFPages(PDF):
    """A4 sur plusieurs pages avec un pied de page « titre — page x/y »."""

    def __init__(self, pied: str, brouillon: bool = False):
        super().__init__()
        self.pied = pied
        self.brouillon = brouillon
        self.set_margins(14, 12, 14)
        self.set_auto_page_break(True, margin=20)

    def header(self):
        if self.brouillon:  # filigrane : un brouillon ne vaut pas document signé
            self.set_font("Montserrat", "B", 60)
            self.set_text_color(245, 222, 214)
            with self.rotation(35, 105, 160):
                self.text(30, 175, "BROUILLON")

    def footer(self):
        self.set_draw_color(*VERT)
        self.set_line_width(0.3)
        self.line(14, 284, 196, 284)
        self.texte(14, 286, self.pied, taille=7, couleur=GRIS)
        self.texte(14, 286, f"Page {self.page_no()}/{{nb}}", taille=7, couleur=GRIS, largeur=182, align="R")


def _section(pdf: PDF, texte: str, marge_bas: float = 40) -> None:
    if pdf.get_y() > 297 - marge_bas:
        pdf.add_page()
    pdf.ln(2.5)
    pdf.set_font("Montserrat", "B", 10.5)
    pdf.set_text_color(*MARINE)
    pdf.cell(0, 6, texte, new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(*VERT)
    pdf.set_line_width(0.5)
    pdf.line(14, pdf.get_y(), 54, pdf.get_y())
    pdf.ln(2)


def _infos(pdf: PDF, couples: list[tuple[str, str]], colonnes: int = 2) -> None:
    """Grille « libellé / valeur »."""
    largeur = 182 / colonnes
    y0 = pdf.get_y()
    for i, (libelle, valeur) in enumerate(couples):
        if not libelle:  # case vide (alignement)
            continue
        x = 14 + (i % colonnes) * largeur
        y = y0 + (i // colonnes) * 10
        pdf.texte(x, y, libelle, taille=7, couleur=GRIS)
        pdf.set_font("MontserratSemi", "", 9)
        pdf.set_text_color(*ENCRE)
        pdf.set_xy(x, y + 3.3)
        pdf.cell(largeur - 3, 4.5, valeur or "—")
    pdf.set_y(y0 + ((len(couples) + colonnes - 1) // colonnes) * 10 + 1)


def _image_data_url(data_url: str):
    """Signature (data URL PNG) → flux lisible par fpdf."""
    if not data_url or "," not in data_url:
        return None
    return io.BytesIO(base64.b64decode(data_url.split(",", 1)[1]))


def _signatures(pdf: PDF, gauche: tuple[str, str, str | None], droite: tuple[str, str, str | None],
                mention: str = "") -> None:
    if pdf.get_y() > 228:
        pdf.add_page()
    y = pdf.get_y() + 3
    for x, (qui, nom, signature) in ((14, gauche), (108, droite)):
        pdf.set_draw_color(*GRIS)
        pdf.set_line_width(0.2)
        pdf.rect(x, y, 88, 40)
        pdf.texte(x, y + 2.5, qui, taille=9.5, couleur=MARINE, style="B", largeur=88, align="C")
        texte_mention = "Signature et cachet" if x == 14 else mention  # côté ISUP : cachet de l'entreprise
        if texte_mention:
            pdf.texte(x, y + 7.5, texte_mention, taille=6.8, couleur=GRIS, largeur=88, align="C")
        image = _image_data_url(signature)
        if image is not None:
            pdf.image(image, x=x + 14, y=y + 11, h=20, keep_aspect_ratio=True, w=60)
        pdf.texte(x, y + 34, nom, taille=7.5, couleur=GRIS, largeur=88, align="C")
    pdf.set_y(y + 43)


# ---------- État des lieux ----------

def etat_des_lieux_pdf(d: dict) -> bytes:
    brouillon = d["statut"] != "Signé"
    pdf = _PDFPages(f"État des lieux N° {d['numero']} — {ENTETE['nom']}", brouillon=brouillon)
    pdf.set_title(f"État des lieux {d['numero']} — {ENTETE['nom']}")
    pdf.add_page()
    titre = f"ÉTAT DES LIEUX D'{'ENTRÉE' if d['type_edl'] == 'Entrée' else 'SORTIE'}"
    y = _entete(pdf, 8, titre, d["numero"], d["date"],
                "Signé par les deux parties" if not brouillon else "Brouillon — non signé")
    pdf.set_y(y)

    _section(pdf, "Parties et logement")
    _infos(pdf, [
        ("Bailleur / mandataire", f"{ENTETE['nom']}" + (f", pour le compte de {d['proprietaire']}"
                                                  if d["proprietaire"] and not est_entreprise(d["proprietaire"]) else "")),
        ("Locataire", d["locataire"]),
        ("Logement", d["logement"]), ("Adresse", d["adresse"]),
        ("Contrat de bail", f"N° {d['numero_contrat']} (début le {d['date_debut']})"),
        ("Téléphone / CNI du locataire", " — ".join(x for x in (d["telephone"], d["cni"]) if x)),
    ])
    pdf.set_font("Montserrat", "", 8.3)
    pdf.set_text_color(*GRIS)
    pdf.multi_cell(0, 4.2, "État des lieux établi contradictoirement entre les parties, qui reconnaissent son exactitude. "
                           "Il est annexé au contrat de bail" + (" et servira de référence à la sortie du locataire."
                           if d["type_edl"] == "Entrée" else " et sera comparé à l'état des lieux d'entrée."), new_x="LMARGIN", new_y="NEXT")

    # Compteurs et clés
    _section(pdf, "Compteurs et clés")
    elec = d["compteurs"].get("electricite") or {}
    eau = d["compteurs"].get("eau") or {}
    _infos(pdf, [
        ("Électricité (CIE) — N° compteur", elec.get("numero", "")), ("Index / crédit relevé", elec.get("index", "")),
        ("Eau (SODECI) — N° compteur", eau.get("numero", "")), ("Index relevé (m³)", eau.get("index", "")),
        ("Nombre de clés remises", str(d["nb_cles"])), ("", ""),
    ])

    # Pièces
    _section(pdf, "Description pièce par pièce")
    sortie = d["type_edl"] == "Sortie"
    colonnes = ([("Élément", 52), ("État à l'entrée", 30), ("État à la sortie", 30), ("Observations", 70)] if sortie
                else [("Élément", 62), ("État", 34), ("Observations", 86)])
    for piece in d["pieces"]:
        if pdf.get_y() > 255:
            pdf.add_page()
        pdf.set_fill_color(*FOND_VERT)
        pdf.set_text_color(*MARINE)
        pdf.set_font("Montserrat", "B", 9)
        pdf.cell(182, 6.5, piece["piece"], fill=True, new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Montserrat", "B", 7)
        pdf.set_text_color(*GRIS)
        for titre_col, largeur in colonnes:
            pdf.cell(largeur, 5, titre_col)
        pdf.ln()
        for e in piece.get("elements", []):
            if pdf.get_y() > 272:
                pdf.add_page()
            y_ligne = pdf.get_y()
            valeurs = ([e["element"], e.get("etat_entree") or "—", e["etat"], e.get("observation", "")] if sortie
                       else [e["element"], e["etat"], e.get("observation", "")])
            x = 14
            hauteur = 5.2
            for (titre_col, largeur), valeur in zip(colonnes, valeurs):
                pdf.set_xy(x, y_ligne)
                est_etat = titre_col.startswith("État")
                pdf.set_font("MontserratSemi" if est_etat else "Montserrat", "", 8)
                pdf.set_text_color(*(COULEUR_ETAT.get(valeur, ENCRE) if est_etat else ENCRE))
                pdf.multi_cell(largeur - 1.5, 4.2, str(valeur))
                hauteur = max(hauteur, pdf.get_y() - y_ligne)
                x += largeur
            pdf.set_draw_color(226, 230, 223)
            pdf.set_line_width(0.15)
            pdf.line(14, y_ligne + hauteur + 0.4, 196, y_ligne + hauteur + 0.4)
            pdf.set_y(y_ligne + hauteur + 0.9)
        pdf.ln(1.5)

    if d["observations"]:
        _section(pdf, "Observations générales")
        pdf.set_font("Montserrat", "", 8.8)
        pdf.set_text_color(*ENCRE)
        pdf.multi_cell(0, 4.6, d["observations"], new_x="LMARGIN", new_y="NEXT")

    if sortie:
        _section(pdf, "Comparaison avec l'entrée et caution")
        if d["degradations"]:
            pdf.set_font("Montserrat", "", 8.5)
            pdf.set_text_color(*ROUGE)
            for g in d["degradations"]:
                pdf.multi_cell(0, 4.5, f"• {g['piece']} — {g['element']} : {g['entree']} → {g['sortie']}"
                                       + (f" ({g['observation']})" if g["observation"] else ""), new_x="LMARGIN", new_y="NEXT")
        else:
            pdf.set_font("Montserrat", "", 8.5)
            pdf.set_text_color(76, 138, 74)
            pdf.multi_cell(0, 4.5, "Aucune dégradation constatée par rapport à l'état des lieux d'entrée.", new_x="LMARGIN", new_y="NEXT")
        caution, retenues = Decimal(d["caution"]), Decimal(d["retenues"])
        pdf.ln(1)
        _infos(pdf, [("Caution versée", francs(caution)), ("Retenues (réparations, dégradations)", francs(retenues)),
                     ("Montant à restituer au locataire", francs(max(caution - retenues, Decimal(0)))), ("", "")])

    # Photos (annexe)
    if d["photos"]:
        _section(pdf, f"Photos ({len(d['photos'])})", marge_bas=80)
        largeur, hauteur, ecart = 57, 43, 5.5
        x0, n = 14, 0
        for piece, legende, chemin in d["photos"]:
            if not chemin.exists():
                continue
            if n % 3 == 0:
                if pdf.get_y() > 297 - 20 - hauteur - 10:
                    pdf.add_page()
                y = pdf.get_y()
            x = x0 + (n % 3) * (largeur + ecart)
            pdf.image(str(chemin), x=x, y=y, w=largeur, h=hauteur, keep_aspect_ratio=True)
            pdf.set_draw_color(226, 230, 223)
            pdf.rect(x, y, largeur, hauteur)
            pdf.texte(x, y + hauteur + 1, " — ".join(t for t in (piece, legende) if t)[:60], taille=6.5,
                      couleur=GRIS, largeur=largeur)
            n += 1
            if n % 3 == 0:
                pdf.set_y(y + hauteur + 6)
        if n % 3:
            pdf.set_y(y + hauteur + 6)

    _section(pdf, "Signatures", marge_bas=70)
    if d["signe_le"]:
        pdf.texte(14, pdf.get_y(), f"Fait à {ENTETE['ville']}, signé le {d['signe_le']}, en deux exemplaires.", taille=8.5)
        pdf.ln(5)
    _signatures(pdf, (f"Pour {ENTETE['nom']}", d["agent"], d["signature_agent"]),
                ("Le Locataire", d["locataire"], d["signature_locataire"]), mention="Lu et approuvé")
    return bytes(pdf.output())


# ---------- Courriers : révision de loyer, avenant au bail ----------

def _lettre_entete(pdf: PDF, d: dict, titre: str) -> None:
    y = _entete(pdf, 8, titre, d["numero"], d["date"], d.get("mention", "Courrier"))
    # Destinataire, à droite comme dans une lettre
    pdf.set_y(y + 2)
    pdf.set_x(112)
    pdf.set_font("MontserratSemi", "", 9.5)
    pdf.set_text_color(*ENCRE)
    pdf.multi_cell(84, 5, "\n".join(x for x in (d["destinataire"], d.get("destinataire_adresse", ""),
                                                d.get("destinataire_tel", "")) if x), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)
    pdf.set_font("Montserrat", "", 8.5)
    pdf.set_text_color(*GRIS)
    pdf.cell(0, 5, f"{ENTETE['ville']}, le {d['date']}", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(2)
    pdf.set_font("Montserrat", "B", 9.5)
    pdf.set_text_color(*MARINE)
    pdf.multi_cell(0, 5, f"Objet : {d['objet']}", new_x="LMARGIN", new_y="NEXT")
    if d.get("references"):
        pdf.set_font("Montserrat", "", 8.3)
        pdf.set_text_color(*GRIS)
        pdf.multi_cell(0, 4.5, f"Réf. : {d['references']}", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)


def _paragraphes(pdf: PDF, texte: str) -> None:
    pdf.set_font("Montserrat", "", 9.5)
    pdf.set_text_color(*ENCRE)
    for bloc in texte.split("\n\n"):
        bloc = bloc.strip()
        if not bloc:
            continue
        if bloc.startswith("- "):
            for ligne in bloc.splitlines():
                pdf.set_x(20)
                pdf.cell(5, 5, "•")
                pdf.multi_cell(0, 5, ligne.lstrip("- ").strip(), new_x="LMARGIN", new_y="NEXT")
            pdf.ln(1.5)
            continue
        pdf.multi_cell(0, 5.1, bloc.replace("\n", " "), align="J", new_x="LMARGIN", new_y="NEXT")
        pdf.ln(2.4)


def revision_loyer_pdf(d: dict) -> bytes:
    pdf = _PDFPages(f"Révision de loyer N° {d['numero']} — {ENTETE['nom']}")
    pdf.set_title(f"Révision de loyer {d['numero']} — {ENTETE['nom']}")
    pdf.add_page()
    _lettre_entete(pdf, d, "RÉVISION DE LOYER")
    _paragraphes(pdf, d["corps_debut"])
    # Tableau ancien / nouveau loyer
    y = pdf.get_y() + 1
    for i, (libelle, valeur, couleur) in enumerate((("Loyer actuel", d["ancien_loyer"], GRIS),
                                                     ("Nouveau loyer", d["nouveau_loyer"], ORANGE),
                                                     ("À compter du", d["date_effet"], MARINE))):
        x = 14 + i * 61
        pdf.set_fill_color(*FOND_VERT)
        pdf.rect(x, y, 58, 17, style="F")
        pdf.texte(x + 3, y + 2.5, libelle, taille=7.5, couleur=GRIS)
        pdf.texte(x + 3, y + 8.5, valeur, taille=11.5, couleur=couleur, style="B")
    pdf.set_y(y + 22)
    _paragraphes(pdf, d["corps_fin"])
    _signatures(pdf, (f"Pour {ENTETE['nom']}", d["signataire"], None), ("Le Locataire", d["destinataire"], None),
                mention="Bon pour accord (date et signature)")
    return bytes(pdf.output())


def avenant_pdf(d: dict) -> bytes:
    pdf = _PDFPages(f"Avenant N° {d['numero']} — {ENTETE['nom']}")
    pdf.set_title(f"Avenant au bail {d['numero']} — {ENTETE['nom']}")
    pdf.add_page()
    y = _entete(pdf, 8, "AVENANT AU CONTRAT DE BAIL", d["numero"], d["date"], f"Contrat N° {d['numero_contrat']}")
    pdf.set_y(y + 1)
    _section(pdf, "Entre les soussignés")
    _paragraphes(pdf, d["parties"])
    _section(pdf, "Objet de l'avenant")
    _paragraphes(pdf, d["objet"])
    _section(pdf, "Il a été convenu ce qui suit")
    _paragraphes(pdf, d["clauses"])
    _paragraphes(pdf, "Toutes les autres clauses et conditions du contrat de bail initial non modifiées par le présent "
                      "avenant demeurent inchangées et continuent de produire leurs effets. Le présent avenant fait "
                      "partie intégrante du contrat de bail.")
    pdf.texte(14, pdf.get_y() + 1, f"Fait à {ENTETE['ville']}, le {d['date']}, en deux exemplaires originaux.", taille=9)
    pdf.ln(7)
    _signatures(pdf, (f"Le Bailleur ({ENTETE['nom']})", d["signataire"], None), ("Le Locataire", d["locataire"], None),
                mention="« Lu et approuvé »")
    return bytes(pdf.output())
