"""Étape 3 : locataires et contrats de bail.

Règles (vérifiées ici, côté serveur) :
- Admin et Gestionnaire (dans ses cités) créent et modifient les contrats.
- Un locataire est créé « via contrat » ; le Gestionnaire ne voit que ceux de ses cités.
- Un seul contrat en cours par logement ; le statut du logement suit le contrat.
- Un même locataire peut avoir plusieurs contrats en cours (ex. maison + magasin) :
  choix de la direction, contraire au cahier des charges initial.
- Numéro automatique BAIL-AAAA-NNNN, qui repart à 0001 chaque année.
- Caution 0 à 3 mois, avance 1 à 3 mois ; montants calculés à partir du loyer.
- Résiliation et suppression : Admin uniquement, mot de passe redemandé.
  La résiliation n'est jamais automatique.
- Départ annoncé (préavis) : Admin et Gestionnaire l'enregistrent ; les loyers s'arrêtent au mois du départ
  (inclus, mois complet). Ensuite : état des lieux de sortie, restitution de la caution, résiliation par l'Admin.
"""
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func
from sqlalchemy.orm import Session as SessionDB, selectinload

from biens import synchroniser_statut_logement
from commun import (Cni, Email, Formulaire, Mots, NomPersonne, Suppression, Telephone, Texte,
                    charger, enregistrer, montant, numero_suivant, supprimer)
import paiements
import recus
from entreprise import est_entreprise
from models import (Cite, Contrat, Document, Impaye, Locataire, Logement, PieceJointe, Utilisateur, STATUTS_EN_COURS,
                    TERMES_LOYER, TYPES_CONTRAT, USAGES_BIEN)
from paiements import libelle_mois, mois_avance, recalculer_tout, reinitialiser_echeances_impayees
from securite import (cites_autorisees, confirmer_mot_de_passe_admin, exiger_admin,
                      exiger_module, get_db, verifier_cite_autorisee)

router = APIRouter(prefix="/api")

acces_contrats = exiger_module("contrats")
acces_locataires = exiger_module("locataires")

# Statuts qu'on peut choisir dans le formulaire (« Résilié » passe par le bouton Résilier)
STATUTS_A_LA_CREATION = ("Actif", "En attente")
STATUTS_MODIFIABLES = ("Actif", "En attente", "Suspendu", "Renouvelé", "Expiré")
DEJA_UN_CONTRAT = "Ce logement a déjà un contrat en cours (actif, en attente, suspendu ou renouvelé)."
# Un logement « Occupé » (même sans contrat saisi) ou en maintenance n'est pas proposé
STATUTS_NON_ATTRIBUABLES = ("Occupé", "Maintenance")


# ---------- Données reçues des formulaires ----------

class LocataireIn(Formulaire):
    nom_complet: NomPersonne = Field(min_length=1, max_length=150)
    cni: Cni | None = Field(None, max_length=50)
    telephone: Telephone | None = Field(None, max_length=30)
    profession: Mots | None = Field(None, max_length=100)
    email: Email | None = Field(None, max_length=150)


class ContratModifiable(Formulaire):
    type_contrat: Literal[TYPES_CONTRAT]
    usage_bien: Literal[USAGES_BIEN]
    terme_loyer: Literal[TERMES_LOYER]
    montant_loyer: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    mois_caution: int = Field(ge=0, le=3)
    mois_avance: int = Field(ge=1, le=3)
    date_debut: date
    date_fin: date | None = None
    statut_contrat: Literal[STATUTS_MODIFIABLES] = "Actif"


class ContratIn(ContratModifiable):
    logement_id: int
    locataire_id: int | None = None           # locataire existant…
    nouveau_locataire: LocataireIn | None = None  # … ou nouveau


class PreavisIn(Formulaire):
    date_preavis: date
    date_depart: date
    motif: Texte | None = Field(None, max_length=500)


class Resiliation(BaseModel):  # pas Formulaire : le mot de passe ne doit pas être retouché
    mot_de_passe_admin: str
    date_resiliation: date | None = None
    motif: Texte | None = Field(None, max_length=500)


# ---------- Périmètre (Gestionnaire : seulement ses cités) ----------

def filtrer_par_cites(requete, utilisateur: Utilisateur):
    """Limite une requête jointe à Logement aux cités autorisées."""
    autorisees = cites_autorisees(utilisateur)
    if autorisees is not None:
        requete = requete.filter(Logement.cite_id.in_(autorisees))
    return requete


def charger_contrat(db: SessionDB, utilisateur: Utilisateur, contrat_id: int) -> Contrat:
    contrat = charger(db, Contrat, contrat_id, "Contrat introuvable.")
    try:
        verifier_cite_autorisee(utilisateur, contrat.logement.cite_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Contrat introuvable.")
    return contrat


def locataire_visible(utilisateur: Utilisateur, locataire: Locataire) -> bool:
    autorisees = cites_autorisees(utilisateur)
    return autorisees is None or any(c.logement.cite_id in autorisees for c in locataire.contrats)


# ---------- Mise en forme des réponses ----------

def contrat_json(c: Contrat) -> dict:
    return {
        "id": c.id, "numero_contrat": c.numero_contrat, "statut_contrat": c.statut_contrat,
        "a_risque": c.mois_impayes_consecutifs >= 2,
        "type_contrat": c.type_contrat, "usage_bien": c.usage_bien, "terme_loyer": c.terme_loyer,
        "montant_loyer": montant(c.montant_loyer),
        "mois_caution": c.mois_caution, "montant_caution": montant(c.montant_caution),
        "mois_avance": c.mois_avance, "montant_avance": montant(c.montant_avance),
        "date_debut": c.date_debut.isoformat(),
        "suivi_depuis": c.suivi_depuis.isoformat() if c.suivi_depuis else None,
        "date_fin": c.date_fin.isoformat() if c.date_fin else None,
        "date_resiliation": c.date_resiliation.isoformat() if c.date_resiliation else None,
        "motif_resiliation": c.motif_resiliation,
        "date_preavis": c.date_preavis.isoformat() if c.date_preavis else None,
        "date_depart": c.date_depart.isoformat() if c.date_depart else None,
        "motif_depart": c.motif_depart,
        "locataire": {"id": c.locataire.id, "nom_complet": c.locataire.nom_complet,
                      "telephone": c.locataire.telephone, "cni": c.locataire.cni, "email": c.locataire.email},
        "logement": {"id": c.logement.id, "numero_logement": c.logement.numero_logement,
                     "cite_id": c.logement.cite_id, "cite_nom": c.logement.cite.nom,
                     "adresse": c.logement.cite.adresse},
    }


# ---------- Numérotation automatique ----------

def prochain_numero(db: SessionDB) -> str:
    """BAIL-AAAA-NNNN : l'année du jour, numéro qui repart à 0001 au 1er janvier."""
    return numero_suivant(db, Contrat.numero_contrat, f"BAIL-{date.today().year}", 4)


# ---------- Listes déroulantes ----------

@router.get("/contrats/options")
def options(utilisateur: Utilisateur = Depends(acces_contrats), db: SessionDB = Depends(get_db)):
    logements = filtrer_par_cites(
        db.query(Logement).join(Cite).options(selectinload(Logement.contrats)), utilisateur
    ).order_by(Cite.nom, Logement.numero_logement).all()
    disponibles = [l for l in logements if l.statut_logement not in STATUTS_NON_ATTRIBUABLES
                   and not any(c.statut_contrat in STATUTS_EN_COURS for c in l.contrats)]
    locataires = db.query(Locataire).options(
        selectinload(Locataire.contrats).selectinload(Contrat.logement)
    ).order_by(Locataire.nom_complet).all()
    return {
        "types_contrat": TYPES_CONTRAT, "usages_bien": USAGES_BIEN, "termes_loyer": TERMES_LOYER,
        "statuts_creation": STATUTS_A_LA_CREATION, "statuts_modification": STATUTS_MODIFIABLES,
        "logements_disponibles": [{
            "id": l.id, "libelle": f"{l.cite.nom} — Logement {l.numero_logement}",
            "loyer": montant(l.loyer), "type_logement": l.type_logement,
        } for l in disponibles],
        "locataires": [{"id": l.id, "nom_complet": l.nom_complet, "telephone": l.telephone}
                       for l in locataires if locataire_visible(utilisateur, l)],
    }


# ---------- Contrats ----------

@router.get("/contrats")
def liste_contrats(utilisateur: Utilisateur = Depends(acces_contrats), db: SessionDB = Depends(get_db)):
    contrats = filtrer_par_cites(
        db.query(Contrat).join(Logement).options(
            selectinload(Contrat.locataire), selectinload(Contrat.logement).selectinload(Logement.cite)
        ), utilisateur
    ).order_by(Contrat.cree_le.desc()).all()
    recalculer_tout(db, contrats)  # pastille « À risque » à jour
    return [contrat_json(c) for c in contrats]


def appliquer_conditions(contrat: Contrat, donnees: ContratModifiable) -> None:
    if donnees.date_fin and donnees.date_fin < donnees.date_debut:
        raise HTTPException(status_code=400, detail="La date de fin doit être après la date de début.")
    contrat.type_contrat = donnees.type_contrat
    contrat.usage_bien = donnees.usage_bien
    contrat.terme_loyer = donnees.terme_loyer
    contrat.montant_loyer = donnees.montant_loyer
    contrat.mois_caution = donnees.mois_caution
    contrat.montant_caution = donnees.montant_loyer * donnees.mois_caution
    contrat.mois_avance = donnees.mois_avance
    contrat.montant_avance = donnees.montant_loyer * donnees.mois_avance
    contrat.date_debut = donnees.date_debut
    contrat.date_fin = donnees.date_fin
    contrat.statut_contrat = donnees.statut_contrat


def enregistrer_contrat(db: SessionDB) -> None:
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail=DEJA_UN_CONTRAT)


@router.post("/contrats")
def creer_contrat(donnees: ContratIn, utilisateur: Utilisateur = Depends(acces_contrats),
                  db: SessionDB = Depends(get_db)):
    if donnees.statut_contrat not in STATUTS_A_LA_CREATION:
        raise HTTPException(status_code=400, detail="Un nouveau contrat est « Actif » ou « En attente ».")

    logement = charger(db, Logement, donnees.logement_id, "Logement introuvable.")
    try:
        verifier_cite_autorisee(utilisateur, logement.cite_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Logement introuvable.")
    if any(c.statut_contrat in STATUTS_EN_COURS for c in logement.contrats):
        raise HTTPException(status_code=409, detail=DEJA_UN_CONTRAT)
    if logement.statut_logement == "Occupé":
        raise HTTPException(status_code=409,
                            detail="Ce logement est « Occupé » : il ne peut pas être attribué à un autre locataire.")
    if logement.statut_logement == "Maintenance":
        raise HTTPException(status_code=409, detail="Ce logement est en maintenance.")

    if donnees.nouveau_locataire is not None:
        nl = donnees.nouveau_locataire
        locataire = Locataire(nom_complet=nl.nom_complet, cni=nl.cni or None, telephone=nl.telephone or None,
                              profession=nl.profession or None, email=nl.email or None)
        db.add(locataire)
    elif donnees.locataire_id is not None:
        locataire = charger(db, Locataire, donnees.locataire_id, "Locataire introuvable.")
        if not locataire_visible(utilisateur, locataire):
            raise HTTPException(status_code=404, detail="Locataire introuvable.")
    else:
        raise HTTPException(status_code=400, detail="Choisissez un locataire ou saisissez un nouveau locataire.")

    contrat = Contrat(numero_contrat=prochain_numero(db), logement=logement, locataire=locataire,
                      mois_impayes_consecutifs=0)
    appliquer_conditions(contrat, donnees)
    db.add(contrat)
    synchroniser_statut_logement(logement)
    enregistrer_contrat(db)
    return {"id": contrat.id, "numero_contrat": contrat.numero_contrat, "locataire_id": locataire.id}


@router.put("/contrats/{contrat_id}")
def modifier_contrat(contrat_id: int, donnees: ContratModifiable, utilisateur: Utilisateur = Depends(acces_contrats),
                     db: SessionDB = Depends(get_db)):
    contrat = charger_contrat(db, utilisateur, contrat_id)
    if contrat.statut_contrat == "Résilié":
        raise HTTPException(status_code=409, detail="Ce contrat est résilié : il ne peut plus être modifié.")
    if contrat.paiements and donnees.date_debut != contrat.date_debut:
        raise HTTPException(status_code=409,
                            detail="Ce contrat a déjà des paiements : sa date de début ne peut plus changer.")
    appliquer_conditions(contrat, donnees)
    reinitialiser_echeances_impayees(db, contrat)  # mois non réglés recalculés (loyer, terme)
    synchroniser_statut_logement(contrat.logement)
    enregistrer_contrat(db)
    return {"id": contrat.id}


# ---------- Départ du locataire (préavis) ----------

PREAVIS_JOURS = 30  # le contrat de bail prévoit un préavis d'un mois


@router.post("/contrats/{contrat_id}/preavis")
def enregistrer_preavis(contrat_id: int, donnees: PreavisIn, utilisateur: Utilisateur = Depends(acces_contrats),
                        db: SessionDB = Depends(get_db)):
    contrat = charger_contrat(db, utilisateur, contrat_id)
    if contrat.statut_contrat not in STATUTS_EN_COURS:
        raise HTTPException(status_code=409, detail=f"Ce contrat est « {contrat.statut_contrat} » : pas de préavis.")
    if donnees.date_preavis > date.today():
        raise HTTPException(status_code=400, detail="La date du préavis ne peut pas être dans le futur.")
    if donnees.date_depart < donnees.date_preavis:
        raise HTTPException(status_code=400, detail="La date de départ doit être après la date du préavis.")
    if donnees.date_depart < contrat.date_debut:
        raise HTTPException(status_code=400, detail="La date de départ doit être après le début du bail.")
    contrat.date_preavis = donnees.date_preavis
    contrat.date_depart = donnees.date_depart
    contrat.motif_depart = (donnees.motif or "").strip() or None
    reinitialiser_echeances_impayees(db, contrat)  # plus de loyer après le mois du départ
    db.flush()
    paiements.recalculer_contrat(db, contrat, date.today())
    db.commit()
    jours = (donnees.date_depart - donnees.date_preavis).days
    return {"ok": True, "preavis_court": jours < PREAVIS_JOURS, "jours": jours}


@router.post("/contrats/{contrat_id}/preavis/annuler")
def annuler_preavis(contrat_id: int, utilisateur: Utilisateur = Depends(acces_contrats),
                    db: SessionDB = Depends(get_db)):
    """Le locataire change d'avis : il reste, les loyers reprennent normalement."""
    contrat = charger_contrat(db, utilisateur, contrat_id)
    if contrat.statut_contrat not in STATUTS_EN_COURS:
        raise HTTPException(status_code=409, detail=f"Ce contrat est « {contrat.statut_contrat} ».")
    contrat.date_preavis = contrat.date_depart = contrat.motif_depart = None
    db.flush()
    paiements.recalculer_contrat(db, contrat, date.today())
    db.commit()
    return {"ok": True}


@router.post("/contrats/{contrat_id}/resilier")
def resilier_contrat(contrat_id: int, donnees: Resiliation, admin: Utilisateur = Depends(exiger_admin),
                     db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    contrat = charger(db, Contrat, contrat_id, "Contrat introuvable.")
    if contrat.statut_contrat not in STATUTS_EN_COURS:
        raise HTTPException(status_code=409, detail=f"Ce contrat est déjà « {contrat.statut_contrat} ».")
    contrat.statut_contrat = "Résilié"
    contrat.date_resiliation = donnees.date_resiliation or date.today()
    contrat.motif_resiliation = (donnees.motif or "").strip() or None
    synchroniser_statut_logement(contrat.logement)
    db.commit()
    return {"ok": True}


@router.post("/contrats/{contrat_id}/supprimer")
def supprimer_contrat(contrat_id: int, donnees: Suppression, admin: Utilisateur = Depends(exiger_admin),
                      db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    contrat = charger(db, Contrat, contrat_id, "Contrat introuvable.")
    if contrat.paiements:
        raise HTTPException(status_code=409, detail="Ce contrat a des paiements : suppression impossible. "
                                                    "Résiliez-le plutôt.")
    # échéances créées automatiquement : elles partent avec le contrat
    reinitialiser_echeances_impayees(db, contrat)
    db.query(Impaye).filter_by(contrat_id=contrat.id).delete()
    synchroniser_statut_logement(contrat.logement, sans=contrat)
    return supprimer(db, contrat, "Ce contrat a des documents : suppression impossible. Résiliez-le plutôt.")


# ---------- Contrat de bail en PDF (texte : modeles/contrat_bail.txt) ----------

MODELE_CONTRAT = Path(__file__).parent / "modeles" / "contrat_bail.txt"


def _minuscule(texte: str) -> str:
    return texte[0].lower() + texte[1:] if texte else texte


def donnees_contrat(c: Contrat) -> dict:
    """Valeurs des zones {…} du modèle de contrat."""
    cite = c.logement.cite
    proprietaire = cite.proprietaire
    isup = (f"{recus.ENTETE['nom']}, {recus.ENTETE['rccm']}, {recus.ENTETE['ncc']}, dont le siège est à "
            f"{recus.ENTETE['adresse']}, représentée par son Gérant")
    if proprietaire is None or est_entreprise(proprietaire.nom_complet):
        bailleur, signataire = isup, recus.ENTETE["nom"]
    else:
        ou = f", demeurant à {proprietaire.ville}" if proprietaire.ville else ""
        bailleur = (f"{proprietaire.nom_complet}, propriétaire{ou}, représenté(e) par {isup}, "
                    "agissant en qualité de gestionnaire mandataire")
        signataire = f"{recus.ENTETE['nom']}, pour {proprietaire.nom_complet}"

    l = c.locataire
    identite = l.nom_complet
    if l.profession:
        identite += f", {l.profession}"
    if l.cni:
        identite += f", titulaire de la CNI n° {l.cni}"
    if l.telephone:
        identite += f", joignable au {l.telephone}"

    if c.terme_loyer == "Début de mois":
        terme = "d'avance, au début de chaque mois, au plus tard le 05 du mois concerné"
    else:
        terme = "à la fin de chaque mois, au plus tard le 05 du mois suivant"
    duree = (f"Il est conclu jusqu'au {c.date_fin.strftime('%d/%m/%Y')} et pourra être renouvelé "
             "par accord écrit des parties." if c.date_fin else "Il est conclu pour une durée indéterminée.")

    caution = c.montant_caution or Decimal(0)
    if c.mois_caution:
        clause_caution = (f"À la signature, le Locataire verse une caution de {c.mois_caution} mois de loyer, soit "
                          f"{_minuscule(recus.en_lettres(caution))} ({recus.francs(caution)}). Elle garantit "
                          "l'exécution de ses obligations et lui sera restituée à la fin du bail, après l'état des "
                          "lieux de sortie, déduction faite des sommes restant dues (loyers impayés, réparations "
                          "locatives). Elle ne peut en aucun cas tenir lieu de paiement de loyer.")
    else:
        clause_caution = "Aucune caution n'est exigée pour le présent bail."

    avance = c.montant_avance or Decimal(0)
    if c.mois_avance:
        mois = [libelle_mois(m) for m in mois_avance(c)]
        couverts = "le premier mois" if c.mois_avance == 1 else f"les {c.mois_avance} premiers mois"
        clause_avance = (f"À la signature, le Locataire verse une avance de {c.mois_avance} mois de loyer, soit "
                         f"{_minuscule(recus.en_lettres(avance))} ({recus.francs(avance)}), qui couvre {couverts} "
                         f"du bail ({', '.join(mois)}).")
    else:
        clause_avance = "Aucune avance sur loyer n'est exigée."

    return {
        "numero_contrat": c.numero_contrat, "type_contrat": c.type_contrat, "usage_bien": c.usage_bien,
        "bailleur": bailleur, "signataire_bailleur": signataire,
        "locataire": l.nom_complet, "locataire_identite": identite,
        "logement": c.logement.numero_logement, "type_logement": c.logement.type_logement,
        "bien": cite.nom, "adresse_bien": cite.adresse or f"{recus.ENTETE['ville']}",
        "date_debut": c.date_debut.strftime("%d/%m/%Y"), "clause_duree": duree,
        "loyer": recus.francs(c.montant_loyer), "loyer_lettres": _minuscule(recus.en_lettres(c.montant_loyer)),
        "terme_phrase": terme, "clause_caution": clause_caution, "clause_avance": clause_avance,
        # date de rédaction : celle de l'enregistrement du contrat (stable d'une impression à l'autre)
        "date_du_jour": (c.cree_le or datetime.now()).strftime("%d/%m/%Y"),
        **zones_contrat_agence(c, proprietaire),
    }


# Zones du modèle repris du contrat papier d'une agence cliente (11/11/2026)
TITRES_CONTRAT = {"Bail habitation": "D’HABITATION", "Bail commercial": "COMMERCIAL",
                  "Location meublée": "DE LOCATION MEUBLÉE", "Courte durée": "DE COURTE DURÉE",
                  "Colocation": "DE COLOCATION", "Gestion immobilière": "DE GESTION IMMOBILIÈRE"}
USAGES_CONTRAT = {"Habitation": "d’habitation", "Commercial": "à usage commercial",
                  "Professionnel": "à usage professionnel", "Industriel": "à usage industriel",
                  "Stockage": "de lieu de stockage", "Mixte (habitation + activités)": "d’habitation et d’activités",
                  "Courte durée": "d’habitation de courte durée"}


def _points(valeur) -> str:
    """100000 → « 100.000 » (écriture du contrat papier)."""
    return f"{Decimal(valeur or 0):,.0f}".replace(",", ".")


def _duree(c: Contrat) -> str:
    if c.date_fin is None:
        return "d’une (01) année"
    mois = max(round(((c.date_fin - c.date_debut).days + 1) / 30.44), 1)  # du 01/11/2026 au 31/10/2027 : 12
    if mois == 12:
        return "d’une (01) année"
    if mois % 12 == 0:
        return f"de {mois // 12} ({mois // 12:02d}) années"
    return f"de {mois} ({mois:02d}) mois"


def zones_contrat_agence(c: Contrat, proprietaire) -> dict:
    import penalites
    from sqlalchemy.orm import object_session

    l = c.locataire
    # Comme sur le contrat papier de l'agence : elle signe en « Propriétaire », même pour un bien qu'elle gère
    # pour le compte d'un propriétaire (choix de Boss du 11/11/2026)
    qualite = "Propriétaire"
    if c.terme_loyer == "Début de mois":
        terme = "au début de chaque mois et au plus tard le 05 du mois"
    else:
        terme = "à la fin de chaque mois et au plus tard le 05 du mois suivant"
    penalite = ""
    session = object_session(c)
    if session is not None:
        r = penalites.regle(session)
        if r.active:
            penalite = f"{r.valeur:g}%" if r.mode == "pourcentage" else f"{_points(r.valeur)} FCFA"
    caution = c.montant_caution or Decimal(0)
    avance = c.montant_avance or Decimal(0)
    mois = [libelle_mois(m).capitalize() for m in mois_avance(c)] if c.mois_avance and avance else []
    if len(mois) > 1:
        mois_texte = "des mois de " + ", ".join(mois[:-1]) + " et " + mois[-1]
    else:
        mois_texte = f"du mois de {mois[0]}" if mois else ""
    usage = c.usage_bien or "Habitation"
    return {
        "titre_contrat": TITRES_CONTRAT.get(c.type_contrat, "D’HABITATION"),
        "entreprise": recus.ENTETE["nom"], "rccm_numero": recus.ENTETE["rccm"].removeprefix("RCCM "),
        "ncc_numero": recus.ENTETE["ncc"].removeprefix("NCC : "), "adresse_entreprise": recus.ENTETE["adresse"],
        "telephones_entreprise": recus.ENTETE["telephones"], "qualite_bailleur": qualite,
        "cni": l.cni or "", "telephone": l.telephone or "", "telephone_locataire": l.telephone or "",
        "ville": recus.ENTETE["ville"],
        "usage_local": USAGES_CONTRAT.get(usage, "d’habitation"),
        "objet_location": "l’habitation" if USAGES_CONTRAT.get(usage, "d’").startswith("d’") else "le local",
        "quartier": c.logement.cite.adresse or c.logement.cite.nom,
        "duree": _duree(c), "mois_debut": libelle_mois(c.date_debut).capitalize(),
        "loyer_points": _points(c.montant_loyer), "terme_paiement": terme, "penalite": penalite,
        "caution": _points(caution) if c.mois_caution and caution else "", "caution_points": _points(caution),
        "caution_lettres": recus.en_lettres(caution).upper(),
        "avance": _points(avance) if mois else "", "avance_points": _points(avance), "mois_avance_texte": mois_texte,
    }


@router.get("/contrats/{contrat_id}/pdf")
def contrat_pdf(contrat_id: int, utilisateur: Utilisateur = Depends(acces_contrats), db: SessionDB = Depends(get_db)):
    contrat = charger_contrat(db, utilisateur, contrat_id)
    contenu = recus.contrat_pdf(donnees_contrat(contrat), MODELE_CONTRAT.read_text(encoding="utf-8"))
    relatif = Path("contrats") / str(contrat.date_debut.year) / f"{contrat.numero_contrat}.pdf"
    chemin = paiements.DOSSIER_DOCUMENTS / relatif
    chemin.parent.mkdir(parents=True, exist_ok=True)
    chemin.write_bytes(contenu)  # dernière version conservée
    document = db.query(Document).filter_by(contrat_id=contrat.id, type_document="Contrat de bail",
                                            paiement_id=None).first()
    if document is None:
        document = Document(contrat_id=contrat.id, type_document="Contrat de bail")
        db.add(document)
    document.chemin_fichier = relatif.as_posix()
    document.nom_fichier = relatif.name
    document.genere_par = utilisateur.id
    document.date_generation = datetime.now()
    db.commit()
    return FileResponse(chemin, media_type="application/pdf", filename=chemin.name,
                        content_disposition_type="inline")


# ---------- Locataires ----------

@router.get("/locataires")
def liste_locataires(utilisateur: Utilisateur = Depends(acces_locataires), db: SessionDB = Depends(get_db)):
    autorisees = cites_autorisees(utilisateur)
    locataires = db.query(Locataire).options(
        selectinload(Locataire.contrats).selectinload(Contrat.logement).selectinload(Logement.cite)
    ).order_by(Locataire.nom_complet).all()
    nb_pieces = dict(db.query(PieceJointe.locataire_id, func.count(PieceJointe.id))
                     .filter(PieceJointe.locataire_id.isnot(None)).group_by(PieceJointe.locataire_id).all())
    resultat = []
    for l in locataires:
        contrats = [c for c in l.contrats if autorisees is None or c.logement.cite_id in autorisees]
        if autorisees is not None and not contrats:
            continue
        resultat.append({
            "id": l.id, "nom_complet": l.nom_complet, "cni": l.cni,
            "telephone": l.telephone, "profession": l.profession, "email": l.email,
            "nb_pieces": nb_pieces.get(l.id, 0),
            "contrats": [{"id": c.id, "numero_contrat": c.numero_contrat, "statut_contrat": c.statut_contrat,
                          "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}",
                          "adresse": c.logement.cite.adresse}
                         for c in contrats],
        })
    return resultat


@router.put("/locataires/{locataire_id}")
def modifier_locataire(locataire_id: int, donnees: LocataireIn, utilisateur: Utilisateur = Depends(acces_locataires),
                       db: SessionDB = Depends(get_db)):
    locataire = charger(db, Locataire, locataire_id, "Locataire introuvable.")
    if not locataire_visible(utilisateur, locataire):
        raise HTTPException(status_code=404, detail="Locataire introuvable.")
    locataire.nom_complet = donnees.nom_complet
    locataire.cni = donnees.cni or None
    locataire.telephone = donnees.telephone or None
    locataire.profession = donnees.profession or None
    locataire.email = donnees.email or None
    enregistrer(db, "Enregistrement impossible.")
    return {"id": locataire.id}


@router.post("/locataires/{locataire_id}/supprimer")
def supprimer_locataire(locataire_id: int, donnees: Suppression, admin: Utilisateur = Depends(exiger_admin),
                        db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    locataire = charger(db, Locataire, locataire_id, "Locataire introuvable.")
    if locataire.contrats:
        raise HTTPException(status_code=409,
                            detail="Ce locataire a des contrats : supprimez-les d'abord (ou gardez-le pour l'historique).")
    return supprimer(db, locataire, "Ce locataire est encore utilisé : suppression impossible.")
