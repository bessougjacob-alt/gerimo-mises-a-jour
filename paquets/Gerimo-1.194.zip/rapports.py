"""Étape 8 : tableau de bord (accueil) et rapports.

- Accueil « Aperçu du mois » : loyers encaissés, impayés, contrats à risque, commission ISUP (Admin).
- Rapport sur une période : chiffres clés, reversements par propriétaire (loyers − commission ISUP
  − dépenses à sa charge = net à reverser), situation par bien (taux d'occupation), modes de paiement,
  échéances proches et contrats à risque. Export PDF avec un relevé par propriétaire.
- Droits : Admin et Caisse = tout (commission, reversements, achats/ventes) ;
  Gestionnaire = ses biens, sans propriétaires ni commissions.
"""
import unicodedata
from collections import defaultdict
from datetime import date, timedelta
from types import SimpleNamespace
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from urllib.parse import quote
from sqlalchemy.orm import Session as SessionDB, selectinload

import parametres
import recus
import sejours
from entreprise import est_entreprise
from pydantic import Field

from commun import Email, Formulaire, montant, voit_finances
from models import AchatVente, Cite, Contrat, Depense, Logement, Paiement, Utilisateur
from paiements import contrats_du_perimetre, recalculer_tout, resume_impayes
from securite import cites_autorisees, exiger_module, get_db
from whatsapp import lire_modeles, numero_whatsapp, prochaine_echeance

router = APIRouter(prefix="/api")
acces_rapports = exiger_module("rapports")
ZERO = Decimal(0)


def _dans_perimetre(utilisateur: Utilisateur):
    autorisees = cites_autorisees(utilisateur)
    return (lambda cite_id: True) if autorisees is None else (lambda cite_id: cite_id in autorisees)


def _encaissements(db: SessionDB, debut: date, fin: date, utilisateur: Utilisateur) -> list[Paiement]:
    """Paiements « Payé » de la période (avec leur répartition), dans le périmètre."""
    perimetre = _dans_perimetre(utilisateur)
    paiements = db.query(Paiement).options(
        selectinload(Paiement.encaissement),
        selectinload(Paiement.contrat).selectinload(Contrat.logement).selectinload(Logement.cite)
        .selectinload(Cite.proprietaire),
        selectinload(Paiement.contrat).selectinload(Contrat.locataire),
    ).filter(Paiement.statut_paiement == "Payé", Paiement.date_paiement >= debut, Paiement.date_paiement <= fin).all()
    # séjours en courte durée : présentés comme des encaissements sans caution (même partage que les loyers)
    paiements += [SimpleNamespace(montant=v.montant, date_paiement=v.date_paiement, mode_paiement=v.mode_paiement,
                                  encaissement=SimpleNamespace(montant_caution=ZERO, commission_entreprise=v.commission),
                                  contrat=SimpleNamespace(logement=v.reservation.logement))
                  for v in sejours.versements(db, debut, fin)]
    return [p for p in paiements if perimetre(p.contrat.logement.cite_id)]


def _depenses(db: SessionDB, debut: date, fin: date, utilisateur: Utilisateur) -> list[Depense]:
    perimetre = _dans_perimetre(utilisateur)
    depenses = db.query(Depense).options(selectinload(Depense.cite).selectinload(Cite.proprietaire)) \
        .filter(Depense.date_depense >= debut, Depense.date_depense <= fin).all()
    return [d for d in depenses if perimetre(d.cite_id)]


def _repartition(p: Paiement) -> tuple[Decimal, Decimal, Decimal]:
    """(loyers, caution, commission) d'un paiement."""
    e = p.encaissement
    caution = e.montant_caution if e else ZERO
    return p.montant - caution, caution, (e.commission_entreprise if e else ZERO) or ZERO


# ---------- Accueil : aperçu du mois ----------

def occupation(db: SessionDB, utilisateur: Utilisateur) -> dict:
    """Logements occupés / libres (et réservés, en maintenance) dans le périmètre."""
    perimetre = _dans_perimetre(utilisateur)
    compte = defaultdict(int)
    for cite_id, statut in db.query(Logement.cite_id, Logement.statut_logement):
        if perimetre(cite_id):
            compte[statut] += 1
    total = sum(compte.values())
    return {"total": total, "occupes": compte["Occupé"], "libres": compte["Libre"], "reserves": compte["Réservé"],
            "maintenance": compte["Maintenance"],
            "taux_occupation": round(compte["Occupé"] / total * 100) if total else 0}


@router.get("/tableau-de-bord")
def tableau_de_bord(utilisateur: Utilisateur = Depends(acces_rapports), db: SessionDB = Depends(get_db)):
    aujourdhui = date.today()
    debut = aujourdhui.replace(day=1)
    loyers = commission = ZERO
    for p in _encaissements(db, debut, aujourdhui, utilisateur):
        l, _, c = _repartition(p)
        loyers += l
        commission += c
    contrats = contrats_du_perimetre(db, utilisateur)
    recalculer_tout(db, contrats)
    en_retard = [c for c in contrats if resume_impayes(c, aujourdhui)]
    donnees = {
        "mois": debut.strftime("%m/%Y"),
        "loyers_encaisses": montant(loyers),
        "impayes_en_cours": len(en_retard),
        "contrats_a_risque": sum(1 for c in en_retard if c.mois_impayes_consecutifs >= 2),
        "depenses": montant(sum((d.montant for d in _depenses(db, debut, aujourdhui, utilisateur)), ZERO)),
        "logements": occupation(db, utilisateur),
    }
    if voit_finances(utilisateur):
        donnees["commission_entreprise"] = montant(commission)
    return donnees


# ---------- Rapport sur une période ----------

def construire_rapport(db: SessionDB, utilisateur: Utilisateur, debut: date, fin: date) -> dict:
    admin = voit_finances(utilisateur)
    aujourdhui = date.today()
    paiements = _encaissements(db, debut, fin, utilisateur)
    depenses = _depenses(db, debut, fin, utilisateur)

    # Chiffres clés
    total = loyers = cautions = commission = ZERO
    par_mode: dict[str, Decimal] = defaultdict(Decimal)
    for p in paiements:
        l, ca, co = _repartition(p)
        total += p.montant
        loyers += l
        cautions += ca
        commission += co
        par_mode[p.mode_paiement] += p.montant
    depenses_total = sum((d.montant for d in depenses), ZERO)
    depenses_proprio = sum((d.montant for d in depenses if d.a_la_charge_de == "Propriétaire"), ZERO)

    # Taux d'impayés : loyers échus dans la période (date limite passée) restés impayés
    contrats = contrats_du_perimetre(db, utilisateur)
    recalculer_tout(db, contrats)
    du = impaye = ZERO
    for c in contrats:
        for e in c.echeances:
            if debut <= e.date_limite <= min(fin, aujourdhui - timedelta(days=1)):
                du += e.montant_loyer
                if e.paiement is None:
                    impaye += e.reste  # un mois payé en partie ne compte que pour son reste
    en_retard = [(c, resume_impayes(c, aujourdhui)) for c in contrats]
    en_retard = [(c, r) for c, r in en_retard if r]

    rapport = {
        "debut": debut.isoformat(), "fin": fin.isoformat(),
        "kpis": {
            "total_encaisse": montant(total), "loyers": montant(loyers), "cautions": montant(cautions),
            "depenses": montant(depenses_total), "nb_encaissements": len(paiements),
            "taux_impayes": round(float(impaye / du * 100), 1) if du else 0.0,
            "montant_impayes_periode": montant(impaye),
            "contrats_en_retard": len(en_retard),
            "contrats_a_risque": sum(1 for c, _ in en_retard if c.mois_impayes_consecutifs >= 2),
        },
        "par_mode": [{"mode": m, "montant": montant(v)} for m, v in sorted(par_mode.items(), key=lambda x: -x[1])],
        "a_risque": [{"numero_contrat": c.numero_contrat, "locataire": c.locataire.nom_complet,
                      "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}",
                      "nb_mois": r["nb_mois"], "montant": r["montant"], "a_risque": r["a_risque"]}
                     for c, r in sorted(en_retard, key=lambda x: (-x[1]["nb_mois"], x[0].numero_contrat))],
        "echeances_proches": [],
        "occupation": occupation(db, utilisateur),
    }
    for c in contrats:
        prochaine = prochaine_echeance(c, aujourdhui)
        if prochaine:
            mois, m, limite = prochaine
            rapport["echeances_proches"].append({
                "locataire": c.locataire.nom_complet, "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}",
                "montant": montant(m), "date_limite": limite.isoformat()})
    rapport["echeances_proches"].sort(key=lambda e: e["date_limite"])

    # Situation par bien : loyers, dépenses, occupation
    perimetre = _dans_perimetre(utilisateur)
    cites = [c for c in db.query(Cite).options(selectinload(Cite.logements), selectinload(Cite.proprietaire))
             .order_by(Cite.nom) if perimetre(c.id)]
    loyers_bien: dict[int, Decimal] = defaultdict(Decimal)
    commission_bien: dict[int, Decimal] = defaultdict(Decimal)
    cautions_bien: dict[int, Decimal] = defaultdict(Decimal)
    for p in paiements:
        l, ca, co = _repartition(p)
        cid = p.contrat.logement.cite_id
        loyers_bien[cid] += l
        cautions_bien[cid] += ca
        commission_bien[cid] += co
    depenses_bien: dict[int, Decimal] = defaultdict(Decimal)
    depenses_bien_proprio: dict[int, Decimal] = defaultdict(Decimal)
    for d in depenses:
        depenses_bien[d.cite_id] += d.montant
        if d.a_la_charge_de == "Propriétaire":
            depenses_bien_proprio[d.cite_id] += d.montant
    rapport["par_bien"] = []
    for c in cites:
        nb = len(c.logements)
        occupes = sum(1 for l in c.logements if l.statut_logement == "Occupé")
        rapport["par_bien"].append({
            "bien": c.nom, "loyers": montant(loyers_bien[c.id]), "depenses": montant(depenses_bien[c.id]),
            "logements": nb, "occupes": occupes, "taux_occupation": round(occupes / nb * 100) if nb else None})

    # Admin uniquement : commission et reversements par propriétaire
    if admin:
        rapport["kpis"].update(
            commission_entreprise=montant(commission), depenses_proprietaires=montant(depenses_proprio),
            net_a_reverser=montant(loyers - commission - depenses_proprio))
        proprietaires: dict = {}
        for c in cites:
            if not (loyers_bien[c.id] or depenses_bien_proprio[c.id] or cautions_bien[c.id]):
                continue
            nom = c.proprietaire.nom_complet if c.proprietaire else "Propriétaire non renseigné"
            p = proprietaires.setdefault(c.proprietaire_id or 0, {
                "proprietaire_id": c.proprietaire_id, "proprietaire": nom,
                "telephone": c.proprietaire.telephone if c.proprietaire else None,
                "email": c.proprietaire.email if c.proprietaire else None,
                "bien_entreprise": est_entreprise(nom), "biens": [],
                "loyers": ZERO, "commission": ZERO, "depenses": ZERO, "cautions": ZERO})
            net = loyers_bien[c.id] - commission_bien[c.id] - depenses_bien_proprio[c.id]
            p["biens"].append({"bien": c.nom, "loyers": montant(loyers_bien[c.id]),
                               "commission": montant(commission_bien[c.id]),
                               "depenses": montant(depenses_bien_proprio[c.id]),
                               "cautions": montant(cautions_bien[c.id]), "net": montant(net)})
            p["loyers"] += loyers_bien[c.id]
            p["commission"] += commission_bien[c.id]
            p["depenses"] += depenses_bien_proprio[c.id]
            p["cautions"] += cautions_bien[c.id]
        rapport["reversements"] = [{
            **p, "loyers": montant(p["loyers"]), "commission": montant(p["commission"]),
            "depenses": montant(p["depenses"]), "cautions": montant(p["cautions"]),
            "net": montant(p["loyers"] - p["commission"] - p["depenses"])}
            for p in sorted(proprietaires.values(), key=lambda x: x["proprietaire"])]
        # Achats / ventes de la période (Admin)
        operations = db.query(AchatVente).filter(AchatVente.date_operation >= debut,
                                                 AchatVente.date_operation <= fin).all()
        rapport["achats_ventes"] = {
            "ventes": montant(sum((o.montant for o in operations if o.type_operation != "Achat"), ZERO)),
            "achats": montant(sum((o.montant for o in operations if o.type_operation == "Achat"), ZERO)),
            "commissions_intermediation": montant(sum((o.commission_montant or ZERO for o in operations
                                                       if o.type_operation == "Vente indirecte"), ZERO)),
        }
    return rapport


# ---------- Statistiques en graphiques (icône du bord droit) ----------

def _mois_glissants(fin: date, nombre: int = 12) -> list[date]:
    """Premiers jours des `nombre` derniers mois, du plus ancien au mois de `fin`."""
    a, m = fin.year, fin.month
    mois = []
    for _ in range(nombre):
        mois.append(date(a, m, 1))
        a, m = (a, m - 1) if m > 1 else (a - 1, 12)
    return mois[::-1]


@router.get("/statistiques")
def statistiques(utilisateur: Utilisateur = Depends(acces_rapports), db: SessionDB = Depends(get_db)):
    """12 derniers mois : loyers encaissés, commission ISUP (Admin/Caisse), dépenses et loyers échus impayés ;
    plus la répartition du mois en cours (rapport habituel) pour les autres graphiques."""
    aujourdhui = date.today()
    mois = _mois_glissants(aujourdhui)
    cle = lambda d: (d.year, d.month)  # noqa: E731
    series = {cle(m): {"loyers": ZERO, "commission": ZERO, "depenses": ZERO, "impayes": ZERO} for m in mois}
    for p in _encaissements(db, mois[0], aujourdhui, utilisateur):
        l, _, co = _repartition(p)
        series[cle(p.date_paiement)]["loyers"] += l
        series[cle(p.date_paiement)]["commission"] += co
    for d in _depenses(db, mois[0], aujourdhui, utilisateur):
        series[cle(d.date_depense)]["depenses"] += d.montant
    contrats = contrats_du_perimetre(db, utilisateur)
    recalculer_tout(db, contrats)
    for c in contrats:
        for e in c.echeances:
            if mois[0] <= e.date_limite < aujourdhui and e.paiement is None:
                series[cle(e.date_limite)]["impayes"] += e.reste
    admin = voit_finances(utilisateur)
    evolution = []
    for m in mois:
        s = series[cle(m)]
        ligne = {"mois": m.strftime("%m/%Y"), "loyers": montant(s["loyers"]), "depenses": montant(s["depenses"]),
                 "impayes": montant(s["impayes"])}
        if admin:
            ligne["commission"] = montant(s["commission"])
        evolution.append(ligne)
    annee = construire_rapport(db, utilisateur, mois[0], aujourdhui)
    return {"evolution": evolution, "periode": {"debut": mois[0].isoformat(), "fin": aujourdhui.isoformat()},
            "rapport": annee, "mois_en_cours": tableau_de_bord(utilisateur, db)}


def _periode(debut: date | None, fin: date | None) -> tuple[date, date]:
    aujourdhui = date.today()
    debut = debut or aujourdhui.replace(day=1)
    fin = fin or aujourdhui
    if fin < debut:
        raise HTTPException(status_code=400, detail="La date de fin doit être après la date de début.")
    if (fin - debut).days > 3660:
        raise HTTPException(status_code=400, detail="Période trop longue (10 ans maximum).")
    return debut, fin


@router.get("/rapports")
def rapport(debut: date | None = Query(None), fin: date | None = Query(None),
            utilisateur: Utilisateur = Depends(acces_rapports), db: SessionDB = Depends(get_db)):
    return construire_rapport(db, utilisateur, *_periode(debut, fin))


@router.get("/rapports/pdf")
def rapport_pdf(debut: date | None = Query(None), fin: date | None = Query(None),
                utilisateur: Utilisateur = Depends(acces_rapports), db: SessionDB = Depends(get_db)):
    debut, fin = _periode(debut, fin)
    donnees = construire_rapport(db, utilisateur, debut, fin)
    contenu = recus.rapport_pdf(donnees, admin=voit_finances(utilisateur))
    nom = f"rapport_{debut.isoformat()}_{fin.isoformat()}.pdf"
    return Response(contenu, media_type="application/pdf", headers={"Content-Disposition": f'inline; filename="{nom}"'})


# ---------- Relevé mensuel envoyé au propriétaire (WhatsApp, e-mail, PDF) ----------

class EnvoiEmail(Formulaire):
    destinataire: Email = Field(min_length=3, max_length=150)


def _releve(db: SessionDB, utilisateur: Utilisateur, proprietaire_id: int, debut: date | None,
            fin: date | None) -> tuple[dict, str, date, date]:
    """Relevé d'un seul propriétaire sur la période (Admin et Caisse : ceux qui voient les reversements)."""
    if not voit_finances(utilisateur):
        raise HTTPException(status_code=403, detail="Relevés des propriétaires réservés à l'Admin et à la Caisse.")
    debut, fin = _periode(debut, fin)
    donnees = construire_rapport(db, utilisateur, debut, fin)
    releve = next((p for p in donnees["reversements"] if p["proprietaire_id"] == proprietaire_id), None)
    if releve is None:
        raise HTTPException(status_code=404, detail="Aucun mouvement pour ce propriétaire sur la période.")
    periode = f"{debut.strftime('%d/%m/%Y')} au {fin.strftime('%d/%m/%Y')}"
    return releve, periode, debut, fin


def _nom_fichier(releve: dict, debut: date) -> str:
    ascii_ = unicodedata.normalize("NFKD", releve["proprietaire"]).encode("ascii", "ignore").decode()
    nom = "".join(ch if ch.isalnum() else "_" for ch in ascii_).strip("_")[:40] or "proprietaire"
    return f"releve_{nom}_{debut.strftime('%Y-%m')}.pdf"


def message_releve(releve: dict, periode: str) -> str:
    detail = "\n".join(f"- {b['bien']} : loyers {recus.francs(Decimal(str(b['loyers'])))}, net "
                       f"{recus.francs(Decimal(str(b['net'])))}" for b in releve["biens"])
    valeurs = {"proprietaire": releve["proprietaire"], "periode": periode,
               "loyers": recus.francs(Decimal(str(releve["loyers"]))),
               "commission": recus.francs(Decimal(str(releve["commission"]))),
               "depenses": recus.francs(Decimal(str(releve["depenses"]))),
               "net": recus.francs(Decimal(str(releve["net"]))), "detail_biens": detail,
               "entreprise": recus.ENTETE["nom"]}
    return lire_modeles()["releve"].format_map(recus._ValeursModele(valeurs))


@router.get("/rapports/releve/{proprietaire_id}/pdf")
def releve_pdf(proprietaire_id: int, debut: date | None = Query(None), fin: date | None = Query(None),
               utilisateur: Utilisateur = Depends(acces_rapports), db: SessionDB = Depends(get_db)):
    releve, periode, debut, _ = _releve(db, utilisateur, proprietaire_id, debut, fin)
    return Response(recus.releve_proprietaire_pdf(releve, periode), media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="{_nom_fichier(releve, debut)}"'})


@router.post("/rapports/releve/{proprietaire_id}/whatsapp")
def releve_whatsapp(proprietaire_id: int, debut: date | None = Query(None), fin: date | None = Query(None),
                    utilisateur: Utilisateur = Depends(acces_rapports), db: SessionDB = Depends(get_db)):
    releve, periode, debut, _ = _releve(db, utilisateur, proprietaire_id, debut, fin)
    numero = numero_whatsapp(releve["telephone"])
    texte = quote(message_releve(releve, periode))
    return {"lien": f"https://wa.me/{numero}?text={texte}" if numero else f"https://wa.me/?text={texte}",
            "nom_fichier": _nom_fichier(releve, debut), "a_numero": bool(numero)}


@router.post("/rapports/releve/{proprietaire_id}/envoyer-email")
def releve_email(proprietaire_id: int, d: EnvoiEmail, debut: date | None = Query(None), fin: date | None = Query(None),
                 utilisateur: Utilisateur = Depends(acces_rapports), db: SessionDB = Depends(get_db)):
    releve, periode, debut, _ = _releve(db, utilisateur, proprietaire_id, debut, fin)
    parametres.envoyer_email(db, d.destinataire, f"Relevé de reversement du {periode} — {recus.ENTETE['nom']}",
                             message_releve(releve, periode),
                             [(_nom_fichier(releve, debut), recus.releve_proprietaire_pdf(releve, periode),
                               "application/pdf")])
    if releve["proprietaire_id"]:  # on garde l'adresse pour la prochaine fois
        from models import Proprietaire
        proprio = db.get(Proprietaire, releve["proprietaire_id"])
        if proprio and not proprio.email:
            proprio.email = d.destinataire
            db.commit()
    return {"ok": True}
