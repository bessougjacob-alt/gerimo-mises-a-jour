"""Commerce, étape 5 (14/11/2026) : bilan de la boutique (écran « Bilan de la boutique » et PDF).

Pour une période (le mois en cours par défaut) : chiffre d'affaires, nombre de ventes, panier moyen, coût des
marchandises vendues, bénéfice, remises, pertes (sorties de stock), et à date : ce que les clients doivent, ce que la
boutique doit à ses fournisseurs, valeur du stock. Puis : ventes jour par jour, meilleurs articles, articles qui ne se
vendent pas, ventes par vendeur, encaissements par mode de paiement.
Droits : Admin, Caisse et Comptable (module « bilan_commerce ») ; le Gestionnaire n'y a pas accès (bénéfices).
"""
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session as SessionDB, selectinload

from commun import montant
from models import (Arrivage, Article, LigneVente, MouvementStock, ReglementVente, Utilisateur, Vente,
                    VersementFournisseur)
from securite import exiger_module, get_db

router = APIRouter(prefix="/api")
acces = exiger_module("bilan_commerce")
ZERO = Decimal(0)


def _periode(debut: date | None, fin: date | None) -> tuple[date, date]:
    aujourdhui = date.today()
    debut = debut or aujourdhui.replace(day=1)
    fin = fin or aujourdhui
    if fin < debut:
        raise HTTPException(status_code=400, detail="La date de fin est avant la date de début.")
    if (fin - debut).days > 3700:
        raise HTTPException(status_code=400, detail="Période trop longue (10 ans au plus).")
    return debut, fin


def calculer(db: SessionDB, debut: date, fin: date) -> dict:
    import arrivages
    import ventes as module_ventes
    vts = (db.query(Vente).options(selectinload(Vente.lignes), selectinload(Vente.vendeur))
           .filter(Vente.statut == "Validée", Vente.date_vente >= debut, Vente.date_vente <= fin).all())
    ca = sum((v.total for v in vts), ZERO)
    cout = sum((l.cout for v in vts for l in v.lignes), ZERO)
    remises = sum((v.remise for v in vts), ZERO)
    pertes = -sum((m.valeur or ZERO for m in db.query(MouvementStock).filter(
        MouvementStock.genre == "Sortie", MouvementStock.date_mouvement >= debut, MouvementStock.date_mouvement <= fin)), ZERO)
    pertes = abs(pertes)
    # à date (aujourd'hui) : crédits clients, dettes fournisseurs, valeur du stock
    credits = sum((m for m in module_ventes.doit(db).values() if m > 0), ZERO)
    dettes = ZERO
    for a in db.query(Arrivage).options(selectinload(Arrivage.versements)).filter(
            Arrivage.annule.is_(False), Arrivage.prix_complets.is_(True)):
        dettes += max(a.montant_total - sum((x.montant for x in a.versements), ZERO), ZERO)
    stock = arrivages.stocks(db)
    articles = db.query(Article).filter(Article.actif).all()
    valeur_stock = sum((max(stock.get(a.id, ZERO), ZERO) * a.prix_achat for a in articles), ZERO)

    par_jour = defaultdict(lambda: ZERO)
    par_article = defaultdict(lambda: {"quantite": ZERO, "ca": ZERO, "cout": ZERO})
    par_vendeur = defaultdict(lambda: {"nombre": 0, "ca": ZERO})
    vendus = set()
    for v in vts:
        par_jour[v.date_vente] += v.total
        nom = v.vendeur.nom_complet if v.vendeur else "—"
        par_vendeur[nom]["nombre"] += 1
        par_vendeur[nom]["ca"] += v.total
        # la remise est répartie sur les lignes au prorata (bénéfice par article juste)
        part = (v.total / v.sous_total) if v.sous_total else Decimal(1)
        for l in v.lignes:
            a = par_article[(l.article_id, l.article_nom)]
            a["quantite"] += l.quantite_base
            a["ca"] += l.total * part
            a["cout"] += l.cout
            vendus.add(l.article_id)
    jours = []
    j = debut
    while j <= fin and len(jours) < 400:
        jours.append({"date": j.isoformat(), "total": montant(par_jour.get(j, ZERO))})
        j += timedelta(days=1)
    unites = {a.id: a.unite_base for a in articles}
    meilleurs = sorted(par_article.items(), key=lambda x: -x[1]["ca"])
    modes = defaultdict(lambda: ZERO)
    for r in db.query(ReglementVente).filter(ReglementVente.date_reglement >= debut, ReglementVente.date_reglement <= fin):
        modes[r.mode_paiement] += r.montant
    paye_fournisseurs = sum((x.montant for x in db.query(VersementFournisseur).filter(
        VersementFournisseur.date_versement >= debut, VersementFournisseur.date_versement <= fin)), ZERO)
    return {
        "debut": debut.isoformat(), "fin": fin.isoformat(),
        "kpis": {"chiffre_affaires": montant(ca), "nombre_ventes": len(vts),
                 "panier_moyen": montant((ca / len(vts)).quantize(Decimal("1"))) if vts else 0,
                 "cout_ventes": montant(cout), "benefice": montant(ca - cout),
                 "taux_benefice": round(float((ca - cout) / ca * 100), 1) if ca else 0,
                 "remises": montant(remises), "pertes": montant(pertes), "benefice_net": montant(ca - cout - pertes),
                 "credits_clients": montant(credits), "dettes_fournisseurs": montant(dettes),
                 "valeur_stock": montant(valeur_stock.quantize(Decimal("1"))),
                 "encaisse": montant(sum(modes.values(), ZERO)), "paye_fournisseurs": montant(paye_fournisseurs)},
        "par_jour": jours,
        "meilleurs_articles": [{"article": nom, "quantite": montant(d["quantite"]), "unite": unites.get(aid, ""),
                                "chiffre_affaires": montant(d["ca"].quantize(Decimal("1"))),
                                "benefice": montant((d["ca"] - d["cout"]).quantize(Decimal("1")))}
                               for (aid, nom), d in meilleurs[:15]],
        "sans_vente": [{"article": a.nom, "stock": montant(stock.get(a.id, ZERO)), "unite": a.unite_base,
                        "valeur": montant((max(stock.get(a.id, ZERO), ZERO) * a.prix_achat).quantize(Decimal("1")))}
                       for a in sorted(articles, key=lambda x: -(stock.get(x.id, ZERO) * x.prix_achat))
                       if a.id not in vendus and stock.get(a.id, ZERO) > 0][:15],
        "par_vendeur": [{"vendeur": n, "nombre": d["nombre"], "chiffre_affaires": montant(d["ca"])}
                        for n, d in sorted(par_vendeur.items(), key=lambda x: -x[1]["ca"])],
        "par_mode": [{"mode": m, "montant": montant(v)} for m, v in sorted(modes.items(), key=lambda x: -x[1])],
    }


@router.get("/bilan-commerce")
def bilan(debut: date | None = Query(None), fin: date | None = Query(None), u: Utilisateur = Depends(acces),
          db: SessionDB = Depends(get_db)):
    d, f = _periode(debut, fin)
    return calculer(db, d, f)


@router.get("/bilan-commerce/pdf")
def bilan_pdf(debut: date | None = Query(None), fin: date | None = Query(None), u: Utilisateur = Depends(acces),
              db: SessionDB = Depends(get_db)):
    import recus
    from fastapi.responses import Response
    d, f = _periode(debut, fin)
    r = calculer(db, d, f)
    periode = f"{d:%d/%m/%Y} au {f:%d/%m/%Y}"
    pdf = recus._PDFRapport(periode)
    pdf.set_title(f"Bilan de la boutique — {periode}")
    pdf.alias_nb_pages()
    pdf.add_page()
    y = recus._entete(pdf, 6, "BILAN DE LA BOUTIQUE", "", date.today().strftime("%d/%m/%Y"), "", ligne_numero=f"Du {periode}")
    pdf.set_y(y)
    k = r["kpis"]
    F = recus._f
    recus._cartes(pdf, [("Chiffre d'affaires", F(k["chiffre_affaires"])), ("Nombre de ventes", str(k["nombre_ventes"])),
                        ("Panier moyen", F(k["panier_moyen"])), ("Bénéfice", F(k["benefice"])),
                        ("Pertes (casse, périmés…)", F(k["pertes"])), ("Remises accordées", F(k["remises"])),
                        ("Clients : à encaisser", F(k["credits_clients"])), ("Fournisseurs : à payer", F(k["dettes_fournisseurs"])),
                        ("Valeur du stock", F(k["valeur_stock"])), ("Bénéfice après pertes", F(k["benefice_net"]))])
    recus._titre_section(pdf, "Meilleurs articles")
    recus._tableau(pdf, [("Article", 80, "L"), ("Quantité vendue", 36, "R"), ("Chiffre d'affaires", 34, "R"), ("Bénéfice", 32, "R")],
                   [[a["article"][:45], f"{a['quantite']} {a['unite']}", F(a["chiffre_affaires"]), F(a["benefice"])]
                    for a in r["meilleurs_articles"]])
    recus._titre_section(pdf, "Ventes par vendeur")
    recus._tableau(pdf, [("Vendeur", 100, "L"), ("Ventes", 30, "R"), ("Chiffre d'affaires", 52, "R")],
                   [[v["vendeur"], str(v["nombre"]), F(v["chiffre_affaires"])] for v in r["par_vendeur"]])
    recus._titre_section(pdf, "Encaissements par mode de paiement")
    recus._tableau(pdf, [("Mode", 130, "L"), ("Montant", 52, "R")],
                   [[m["mode"], F(m["montant"])] for m in r["par_mode"]], total=["Total encaissé", F(k["encaisse"])])
    if r["sans_vente"]:
        recus._titre_section(pdf, "Articles en stock qui ne se sont pas vendus")
        recus._tableau(pdf, [("Article", 100, "L"), ("En stock", 40, "R"), ("Valeur", 42, "R")],
                       [[a["article"][:55], f"{a['stock']} {a['unite']}", F(a["valeur"])] for a in r["sans_vente"]])
    return Response(bytes(pdf.output()), media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="Bilan boutique {d:%Y-%m-%d} {f:%Y-%m-%d}.pdf"'})
