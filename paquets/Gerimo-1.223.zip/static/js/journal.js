let journalCache = [], corbeilleCache = [];
// Paramètres → Journal (qui a fait quoi) et Corbeille (éléments supprimés, restaurables) — Admin.

let pageJournal = 1;
const COULEUR_OPERATION = { INSERT: "ok", UPDATE: "info", DELETE: "danger", CONNEXION: "", ECHEC: "warn" };

async function chargerJournal(page = 1) {
  const form = el("formulaireJournal");
  let filtres;
  try {
    filtres = new URLSearchParams({ page, operation: el("jrOperation").value, qui: el("jrQui").value });
    const debut = valeurDate("jrDebut", "Du"), fin = valeurDate("jrFin", "Au");
    if (debut) filtres.set("debut", debut);
    if (fin) filtres.set("fin", fin);
  } catch (e) { erreurFormulaire(form, e.message); return; }
  erreurFormulaire(form, "");
  let rep;
  try { rep = await api(`/api/journal?${filtres}`); journalCache = rep.entrees; }
  catch (e) { el("listeJournal").innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  pageJournal = page;
  const choisi = el("jrQui").value;
  el("jrQui").innerHTML = '<option value="">Tous les utilisateurs</option>' +
    rep.utilisateurs.map(n => `<option${n === choisi ? " selected" : ""}>${esc(n)}</option>`).join("");
  el("listeJournal").innerHTML = rep.entrees.length ? `<div class="card"><div style="overflow-x:auto"><table class="tableau">
      <tr><th>Date</th><th>Qui</th><th>Action</th><th>Quoi</th></tr>
      ${rep.entrees.map((e, i) => `<tr class="ligne-cliquable" data-fiche="journal:${i}"><td style="white-space:nowrap">${esc(e.quand)}</td><td>${esc(e.qui)}</td>
        <td><span class="pill ${COULEUR_OPERATION[e.code] || ""}">${esc(e.operation)}</span></td>
        <td>${esc(e.quoi)}${e.changements.length ? `<div class="petit">${e.changements.map(c =>
          `${esc(c.champ)} : ${c.avant ? `<s>${esc(c.avant)}</s> → ` : ""}<b>${esc(c.apres)}</b>`).join("<br>")}</div>` : ""}</td></tr>`).join("")}
    </table></div>
    <div class="actions">${page > 1 ? `<button class="btn" onclick="chargerJournal(${page - 1})">← Plus récents</button>` : ""}
      ${rep.suite ? `<button class="btn" onclick="chargerJournal(${page + 1})">Plus anciens →</button>` : ""}</div></div>`
    : '<div class="card vide">Aucune action pour ces critères.</div>';
}
el("formulaireJournal").addEventListener("submit", e => { e.preventDefault(); chargerJournal(1); });

async function chargerCorbeille() {
  const zone = el("parCorbeille");
  let rep;
  try { rep = await api("/api/corbeille"); corbeilleCache = rep.elements; }
  catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  zone.innerHTML = `<p class="petit">Les éléments supprimés restent ici : vous pouvez les remettre exactement comme avant (avec leurs fichiers). Une suppression emporte parfois des éléments liés : ils reviennent ensemble.</p>
    ${rep.elements.length ? `<div class="card">${rep.elements.map((x, i) => `
      <div class="row row-fiche etat-termine" data-fiche="corbeille:${i}" tabindex="0"><span class="who"><b>${esc(x.quoi)}</b>
        <br><span class="petit">Supprimé le ${esc(x.quand)} par ${esc(x.qui)}${x.nb_avec ? ` — avec : ${esc(x.avec.join(", "))}${x.nb_avec > x.avec.length ? "…" : ""}` : ""}</span></span>
        <span class="boutons"><button class="btn-sm" onclick="restaurerCorbeille(${x.transaction}, '${esc(x.quoi).replace(/'/g, "&#39;")}')">Restaurer</button></span></div>`).join("")}</div>`
      : '<div class="card vide">La corbeille est vide.</div>'}`;
}

async function restaurerCorbeille(transaction, quoi) {
  const mdp = await demanderMotDePasseAdmin(`Restaurer « ${quoi} » : confirmez avec votre mot de passe.`,
                                         { titre: "Restaurer", bouton: "Restaurer", danger: false });
  if (!mdp) { toast("Restauration annulée"); return; }
  try {
    const rep = await api(`/api/corbeille/${transaction}/restaurer`, { method: "POST", body: { mot_de_passe_admin: mdp } });
    toast(`« ${rep.quoi} » est de retour${rep.nb > 1 ? ` (avec ${rep.nb - 1} élément${rep.nb > 2 ? "s" : ""} lié${rep.nb > 2 ? "s" : ""})` : ""}.`, 6000);
  } catch (e) { toast(e.message, 8000); }
  chargerCorbeille();
}
