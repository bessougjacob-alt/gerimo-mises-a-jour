// Métier Commerce / boutique, partie 1 (13/11/2026) : articles et fournisseurs.
// Le serveur revérifie tout ; il ne renvoie jamais le prix d'achat ni la marge au Gestionnaire.

let articlesCache = [];
let fournisseursCache = [];
let optionsCommerce = null;
let articleEnCours = null;
let fournisseurEnCours = null;
let ongletStock = "stArticles";

TITRES_ECRANS.formArticle = ["Article", "Nom, prix, vente par lot (carton, sac…), code-barres"];
TITRES_ECRANS.formFournisseur = ["Fournisseur", "Coordonnées du fournisseur"];

const nombre = n => Number(n).toLocaleString("fr-FR", { maximumFractionDigits: 3 }).replace(/[  ]/g, " ");
function lireQuantite(texte) {  // « 1,5 » → 1.5 (null si invalide)
  const propre = String(texte).replace(/\s/g, "").replace(",", ".");
  return /^\d+(\.\d{1,3})?$/.test(propre) ? Number(propre) : null;
}
const texteMarge = m => m && m.montant !== null ? `${formatMontant(m.montant)} (${m.pourcentage} %)` : "—";

// ---------- Onglets ----------

const ONGLETS_STOCK = { stArticles: () => chargerArticles(), stArrivages: () => chargerArrivages(),
                        stSorties: () => chargerSorties(), stDettes: () => chargerDettes(),
                        stFournisseurs: () => chargerFournisseurs() };
function montrerOngletStock(id) {
  if (id === "stDettes" && optionsCommerce && !optionsCommerce.voit_achats) id = "stArticles";
  if (id === "stSorties" && optionsCommerce && !optionsCommerce.gere_stock) id = "stArticles";
  ongletStock = id;
  document.querySelectorAll("#ongletsStock .onglet").forEach(b => b.classList.toggle("actif", b.dataset.onglet === id));
  Object.keys(ONGLETS_STOCK).forEach(z => { el(z).style.display = z === id ? "" : "none"; });
  ONGLETS_STOCK[id]();
}
el("ongletsStock").addEventListener("click", e => {
  const b = e.target.closest(".onglet");
  if (b) montrerOngletStock(b.dataset.onglet);
});
CHARGEURS.stock = async () => {
  await chargerOptionsCommerce().catch(() => {});
  // « Ce que je dois » : seulement pour ceux qui voient l'argent (Admin, Caisse)
  document.querySelectorAll("#ongletsStock .onglet-argent").forEach(b => {
    b.style.display = optionsCommerce && optionsCommerce.voit_achats ? "" : "none";
  });
  // « Sorties et inventaire » : Admin et magasinier
  document.querySelectorAll("#ongletsStock .onglet-stock").forEach(b => {
    b.style.display = optionsCommerce && optionsCommerce.gere_stock ? "" : "none";
  });
  montrerOngletStock(ongletStock);
};

async function chargerOptionsCommerce() {
  optionsCommerce = await api("/api/commerce/options");
  return optionsCommerce;
}

// ---------- Articles : l'essentiel en grand, le détail dans une fenêtre ----------

let filtreStock = "tous";
const ETAT_STOCK = a => !a.actif ? "retire" : a.stock <= 0 ? "vide" : a.stock_bas ? "bas" : "ok";
const LIBELLE_ETAT = { ok: "En stock", bas: "Presque plus", vide: "Plus en stock", retire: "Retiré de la vente" };
const joursAvant = iso => Math.round((new Date(iso + "T00:00:00") - new Date(aujourdhui() + "T00:00:00")) / 86400000);
function texteDateLimite(iso) {
  const j = joursAvant(iso);
  return j < 0 ? `périmé depuis le ${formatDate(iso)}` : j === 0 ? "se périme aujourd'hui"
    : j <= 30 ? `se périme dans ${j} jour${j > 1 ? "s" : ""}` : `date limite ${formatDate(iso)}`;
}

async function chargerArticles() {
  const zone = el("listeArticles");
  try {
    [articlesCache] = await Promise.all([api("/api/articles"), chargerOptionsCommerce()]);
  } catch (e) {
    zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`;
    return;
  }
  el("btnNouvelArticle").style.display = optionsCommerce.modifie_articles ? "" : "none";
  afficherResumeStock();
  afficherArticles();
}

// Chiffres clés : cliquables, ils filtrent la liste
function afficherResumeStock() {
  const actifs = articlesCache.filter(a => a.actif);
  const bas = actifs.filter(a => a.stock_bas).length;
  const dates = actifs.filter(a => a.date_limite_proche).length;
  const valeur = actifs.reduce((s, a) => s + (a.valeur_stock || 0), 0);
  const tuile = (filtre, classe, chiffre, libelle, aide) => `<button class="chiffre-cle ${classe}${filtreStock === filtre ? " choisi" : ""}"
      onclick="choisirFiltreStock('${filtre}')"><span class="cc-chiffre">${chiffre}</span><span class="cc-libelle">${libelle}</span>
      <span class="cc-aide">${aide}</span></button>`;
  el("resumeStock").innerHTML = [
    tuile("tous", "neutre", actifs.length, "Articles en vente", "tout voir"),
    tuile("bas", bas ? "alerte" : "calme", bas, "Presque plus en stock", bas ? "à racheter" : "rien à racheter"),
    tuile("dates", dates ? "alerte-orange" : "calme", dates, "Date limite proche", dates ? "dans 30 jours ou moins" : "rien à surveiller"),
    optionsCommerce.voit_achats ? `<div class="chiffre-cle neutre statique"><span class="cc-chiffre">${formatMontant(valeur)}</span>
      <span class="cc-libelle">Valeur du stock</span><span class="cc-aide">au prix d'achat</span></div>` : "",
  ].join("");
  const nbRetires = articlesCache.length - actifs.length;
  el("filtresStock").innerHTML = nbRetires ? `<button class="puce-filtre${filtreStock === "retires" ? " choisi" : ""}" onclick="choisirFiltreStock('retires')">Retirés de la vente (${nbRetires})</button>` : "";
}
function choisirFiltreStock(filtre) {
  filtreStock = filtreStock === filtre && filtre !== "tous" ? "tous" : filtre;
  afficherResumeStock();
  afficherArticles();
}

function afficherArticles() {
  const zone = el("listeArticles");
  const o = optionsCommerce;
  if (!articlesCache.length) {
    zone.innerHTML = `<div class="card vide">Aucun article pour l'instant.${o.modifie_articles ? " Cliquez sur « + Nouvel article »." : ""}</div>`;
    return;
  }
  const mots = normaliser(el("rechercheArticles").value).split(/\s+/).filter(Boolean);
  const liste = articlesCache.filter(a => {
    if (filtreStock === "retires" ? a.actif : (!a.actif && !mots.length)) return false;
    if (filtreStock === "bas" && !a.stock_bas) return false;
    if (filtreStock === "dates" && !a.date_limite_proche) return false;
    if (!mots.length) return true;
    const texte = normaliser([a.nom, a.categorie, a.code_barres, a.fournisseur, ...a.unites.map(u => `${u.nom} ${u.code_barres}`)].join(" "));
    return mots.every(m => texte.includes(m));
  });
  if (!liste.length) {
    zone.innerHTML = '<div class="card vide">Aucun article ne correspond.</div>';
    return;
  }
  // Les plus urgents d'abord : plus en stock, presque plus, date limite proche
  const rang = a => ({ vide: 0, bas: 1, ok: a.date_limite_proche ? 2 : 3, retire: 4 })[ETAT_STOCK(a)];
  liste.sort((x, y) => rang(x) - rang(y) || x.nom.localeCompare(y.nom));
  zone.innerHTML = `<div class="tuiles-articles">${liste.map(a => {
    const etat = ETAT_STOCK(a);
    return `<button class="tuile-article etat-${etat}" onclick="ouvrirFicheArticle(${a.id})">
      <span class="ta-haut"><span class="ta-nom">${esc(a.nom)}</span>${a.categorie ? `<span class="ta-categorie">${esc(a.categorie)}</span>` : ""}</span>
      <span class="ta-stock"><span class="ta-quantite">${esc(a.stock_texte)}</span><span class="ta-etat">${LIBELLE_ETAT[etat]}</span></span>
      <span class="ta-prix"><span><small>Détail</small><b>${formatMontant(a.prix_detail)}</b></span><span><small>Gros</small><b>${formatMontant(a.prix_gros)}</b></span>
        <span><small>par</small><b class="ta-unite">${esc(a.unite_base)}</b></span></span>
      ${a.date_limite ? `<span class="ta-date${a.date_limite_proche ? " proche" : ""}">⏳ ${esc(texteDateLimite(a.date_limite))}</span>` : ""}
    </button>`;
  }).join("")}</div>`;
}
el("rechercheArticles").addEventListener("input", () => { if (articlesCache.length) afficherArticles(); });

// Fenêtre de détail d'un article
async function ouvrirFicheArticle(id) {
  let a;
  try { a = await api(`/api/articles/${id}/fiche`); } catch (e) { toast(e.message); return; }
  const o = optionsCommerce || await chargerOptionsCommerce();
  const etat = ETAT_STOCK(a);
  const stat = (libelle, valeur, aide = "", classe = "") => `<div class="fiche-stat ${classe}"><small>${libelle}</small><b>${valeur}</b>${aide ? `<span>${aide}</span>` : ""}</div>`;
  const lignesPrix = [{ nom: a.unite_base, contenance: 1, prix_detail: a.prix_detail, prix_gros: a.prix_gros,
                        marge_gros: a.marge_gros }, ...a.unites];
  const md = a.marge_detail || {};
  const fen = ouvrirFenetre(`
    <div class="fiche-article">
      <div class="fa-tete">
        <div><h2>${esc(a.nom)}</h2><p>${[a.categorie, a.fournisseur ? "Fournisseur : " + a.fournisseur : "", a.code_barres ? "Code-barres " + a.code_barres : ""].filter(Boolean).map(esc).join(" · ") || "&nbsp;"}</p></div>
        <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button>
      </div>
      <div class="fa-stock etat-${etat}">
        <span class="fa-etat">${LIBELLE_ETAT[etat]}</span>
        <span class="fa-quantite">${esc(a.stock_texte)}</span>
        <span class="fa-aide">${a.unites.length ? `soit ${nombre(a.stock)} ${esc(a.unite_base)} au total · ` : ""}Gérimo prévient à ${nombre(a.seuil_alerte)} ${esc(a.unite_base)}</span>
      </div>
      <div class="fiche-stats">
        ${stat("Prix détail", formatMontant(a.prix_detail), `1 ${esc(a.unite_base)}`)}
        ${stat("Prix gros", formatMontant(a.prix_gros), `1 ${esc(a.unite_base)}`)}
        ${o.voit_achats ? stat("Prix d'achat", formatMontant(a.prix_achat), "coût moyen") : ""}
        ${o.voit_achats ? stat("Bénéfice au détail", md.montant != null ? formatMontant(md.montant) : "—",
                               md.pourcentage != null ? `${md.pourcentage} % du prix` : "prix d'achat inconnu",
                               md.montant > 0 ? "positif" : md.montant < 0 ? "negatif" : "") : ""}
        ${o.voit_achats ? stat("Valeur du stock", formatMontant(a.valeur_stock || 0), "au prix d'achat") : ""}
      </div>
      ${a.unites.length ? `<h4>Prix par lot</h4><div class="fa-tableau"><table><thead><tr><th>Vendu par</th><th>Contient</th><th>Détail</th><th>Gros</th>${o.voit_achats ? "<th>Bénéfice (gros)</th>" : ""}</tr></thead><tbody>
        ${lignesPrix.map(u => `<tr><td><b>${esc(u.nom)}</b></td><td>${nombre(u.contenance)} ${esc(a.unite_base)}</td><td>${formatMontant(u.prix_detail)}</td><td>${formatMontant(u.prix_gros)}</td>${
          o.voit_achats ? `<td>${texteMarge(u.marge_gros)}</td>` : ""}</tr>`).join("")}</tbody></table></div>` : ""}
      ${a.lots.some(l => l.date_limite) ? `<h4>Dates limites de ce qui est en stock</h4><div class="fa-liste">${a.lots.filter(l => l.date_limite).map(l => `
        <div class="fa-ligne"><span><b>${esc(l.reste_texte)}</b> <small>(arrivage ${esc(l.numero)} du ${formatDate(l.date_arrivage)})</small></span>
          <span class="pill ${l.jours < 0 ? "danger" : l.jours <= 30 ? "warn" : "ok"}">${esc(texteDateLimite(l.date_limite))}</span></div>`).join("")}</div>` : ""}
      ${a.mouvements.length ? `<h4>Derniers mouvements</h4><div class="fa-liste">${a.mouvements.map(m => `
        <div class="fa-ligne"><span>${formatDate(m.date)} — ${esc(m.motif || m.genre)}</span>
          <b class="${m.quantite > 0 ? "plus" : "moins"}">${m.quantite > 0 ? "+" : "−"} ${nombre(Math.abs(m.quantite))} ${esc(a.unite_base)}</b></div>`).join("")}</div>`
        : `<p class="petit">Aucun mouvement pour l'instant : le stock augmentera au premier arrivage.</p>`}
      <div class="actions">
        ${o.supprime ? `<button class="btn ghost" data-action="supprimer">Supprimer</button>` : ""}
        ${o.gere_stock && a.stock > 0 ? `<button class="btn" data-action="sortie">− Sortie de stock</button>` : ""}
        <button class="btn" data-fermer>Fermer</button>
        ${o.modifie_articles ? `<button class="btn primary" data-action="modifier">Modifier l'article</button>` : ""}
      </div>
    </div>`, { taille: "large" });
  fen.querySelector('[data-action="modifier"]')?.addEventListener("click", () => { fen.fermer(); modifierArticle(a.id, a); });
  fen.querySelector('[data-action="supprimer"]')?.addEventListener("click", () => { fen.fermer(); supprimerArticle(a.id, a); });
  fen.querySelector('[data-action="sortie"]')?.addEventListener("click", () => { fen.fermer(); nouvelleSortie(a.id); });
}

// Appareil photo du téléphone : le code lu ouvre la fiche de l'article
function scannerStock() {
  scannerCodeBarres(async code => {
    try { ouvrirFicheArticle((await api(`/api/articles/code/${encodeURIComponent(code)}`)).article.id); }
    catch (e) { toast(e.message, 6000); }
  });
}

// Douchette : elle tape le code puis « Entrée » → on ouvre la fiche de l'article
el("rechercheArticles").addEventListener("keydown", async e => {
  if (e.key !== "Enter") return;
  const code = el("rechercheArticles").value.trim();
  if (!/^\d{6,}$/.test(code)) return;
  e.preventDefault();
  try {
    const r = await api(`/api/articles/code/${encodeURIComponent(code)}`);
    el("rechercheArticles").value = "";
    afficherArticles();
    ouvrirFicheArticle(r.article.id);
  } catch (err) {
    toast(err.message, 6000);
  }
});

// --- Formulaire article ---

function ligneUnite(u = {}) {
  const div = document.createElement("div");
  div.className = "fgrid unite-article";
  div.innerHTML = `
    <div class="field"><label>Nom du lot</label><input class="uNom" maxlength="30" list="listeUnitesArticles" placeholder="ex : Carton" value="${esc(u.nom || "")}"></div>
    <div class="field"><label class="uLblContenance">Combien dedans ?</label><input class="uContenance" inputmode="decimal" placeholder="ex : 24" value="${u.contenance ? nombre(u.contenance) : ""}"></div>
    <div class="field"><label>Prix détail (F CFA)</label><input class="uDetail" inputmode="numeric" value="${u.prix_detail ? formatNombre(u.prix_detail) : ""}"></div>
    <div class="field"><label>Prix gros (F CFA)</label><input class="uGros" inputmode="numeric" value="${u.prix_gros ? formatNombre(u.prix_gros) : ""}"></div>
    <div class="field"><label>Code-barres (facultatif)</label><input class="uCode" maxlength="40" autocomplete="off" value="${esc(u.code_barres || "")}"></div>
    <div class="field" style="align-self:end"><button type="button" class="btn ghost" onclick="this.closest('.unite-article').remove(); majAideUnites()">Retirer</button></div>`;
  return div;
}
function ajouterUniteArticle(u) {
  el("artUnites").appendChild(ligneUnite(u));
  majAideUnites();
}
function majAideUnites() {  // « Combien de bouteille(s) dedans ? »
  const base = (el("artUnite").value.trim() || "unité").toLowerCase();
  el("artUnites").querySelectorAll(".uLblContenance").forEach(l => { l.textContent = `Combien de ${base}(s) dedans ?`; });
  el("lblArtDetail").textContent = `Prix détail, prix normal (1 ${base})`;
  el("lblArtGros").textContent = `Prix gros, pour les revendeurs (1 ${base})`;
  el("lblArtAchat").textContent = `Prix d'achat, ce qu'il vous coûte (1 ${base})`;
  majMargeArticle();
}
el("artUnite").addEventListener("input", majAideUnites);
function majMargeArticle() {
  if (!optionsCommerce || !optionsCommerce.voit_achats) return;
  const achat = lireMontant(el("artAchat").value), detail = lireMontant(el("artDetail").value), gros = lireMontant(el("artGros").value);
  const marge = v => v && achat ? `${formatMontant(v - achat)} (${Math.round((v - achat) / v * 1000) / 10} %)` : "—";
  el("artMarge").textContent = achat ? `Bénéfice sur 1 ${(el("artUnite").value.trim() || "unité").toLowerCase()} : au détail ${marge(detail)} · en gros ${marge(gros)}` : "";
}
["artAchat", "artDetail", "artGros"].forEach(id => {
  el(id).addEventListener("input", majMargeArticle);
  el(id).addEventListener("blur", () => { const n = lireMontant(el(id).value); if (n !== null) el(id).value = formatNombre(n); });
});

async function preparerFormArticle(a) {
  const o = await chargerOptionsCommerce();
  articleEnCours = a ? a.id : null;
  el("titreArticle").textContent = a ? "Modifier l'article" : "Nouvel article";
  el("listeCategoriesArticles").innerHTML = o.categories.map(c => `<option value="${esc(c)}">`).join("");
  el("listeUnitesArticles").innerHTML = o.unites.map(u => `<option value="${esc(u)}">`).join("");
  remplirSelect(el("artFournisseur"), o.fournisseurs, { valeur: f => f.id, texte: f => f.nom, vide: "— Aucun —" });
  document.querySelectorAll("#formulaireArticle .champ-achat").forEach(x => { x.style.display = o.voit_achats ? "" : "none"; });
  el("artNom").value = a ? a.nom : "";
  el("artCategorie").value = a ? a.categorie : "";
  el("artCode").value = a ? a.code_barres : "";
  el("artUnite").value = a ? a.unite_base : "Pièce";
  el("artFournisseur").value = a && a.fournisseur_id ? a.fournisseur_id : "";
  el("artDetail").value = a && a.prix_detail ? formatNombre(a.prix_detail) : "";
  el("artGros").value = a && a.prix_gros ? formatNombre(a.prix_gros) : "";
  el("artAchat").value = a && a.prix_achat ? formatNombre(a.prix_achat) : "";
  el("artSeuil").value = a && a.seuil_alerte ? nombre(a.seuil_alerte) : "";
  el("artPeremption").checked = !!(a && a.suit_peremption);
  el("artActif").checked = a ? a.actif : true;
  el("artUnites").innerHTML = "";
  (a ? a.unites : []).forEach(u => el("artUnites").appendChild(ligneUnite(u)));
  majAideUnites();
  erreurFormulaire(el("formulaireArticle"), "");
}

async function nouvelArticle() {
  await preparerFormArticle(null);
  afficher("formArticle");
}
async function modifierArticle(id, article = null) {
  const a = article || articlesCache.find(x => x.id === id);
  if (!a) return;
  await preparerFormArticle(a);
  afficher("formArticle");
}

el("formulaireArticle").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    const nom = el("artNom").value.trim();
    if (nom.length < 2) throw new Error("Indiquez le nom de l'article.");
    const base = el("artUnite").value.trim();
    if (!base) throw new Error("Indiquez la plus petite unité vendue (ex : bouteille, pièce, kg).");
    const prix = (id, libelle) => {
      const v = el(id).value.trim();
      if (!v) return 0;
      const n = lireMontant(v);
      if (n === null) throw new Error(`${libelle} : montant invalide (ex : 400).`);
      return n;
    };
    const seuil = el("artSeuil").value.trim() ? lireQuantite(el("artSeuil").value) : 0;
    if (seuil === null) throw new Error("Seuil d'alerte : nombre invalide (ex : 48).");
    const unites = [...el("artUnites").querySelectorAll(".unite-article")].map((ligne, i) => {
      const nomU = ligne.querySelector(".uNom").value.trim();
      const contenance = lireQuantite(ligne.querySelector(".uContenance").value);
      if (!nomU) throw new Error(`Lot n° ${i + 1} : indiquez son nom (ex : Carton).`);
      if (!contenance) throw new Error(`Lot « ${nomU} » : indiquez combien de ${base} il contient (ex : 24).`);
      const lire = (classe, libelle) => {
        const v = ligne.querySelector(classe).value.trim();
        const n = v ? lireMontant(v) : 0;
        if (n === null) throw new Error(`Lot « ${nomU} », ${libelle} : montant invalide.`);
        return n;
      };
      return { nom: nomU, contenance, prix_detail: lire(".uDetail", "prix détail"), prix_gros: lire(".uGros", "prix gros"),
               code_barres: ligne.querySelector(".uCode").value.trim() || null };
    });
    const corps = {
      nom, categorie: el("artCategorie").value.trim() || null, code_barres: el("artCode").value.trim() || null,
      unite_base: base, prix_detail: prix("artDetail", "Prix détail"), prix_gros: prix("artGros", "Prix gros"),
      prix_achat: optionsCommerce.voit_achats ? prix("artAchat", "Prix d'achat") : null,
      seuil_alerte: seuil, suit_peremption: el("artPeremption").checked, actif: el("artActif").checked,
      fournisseur_id: el("artFournisseur").value ? Number(el("artFournisseur").value) : null, unites,
    };
    if (articleEnCours) await api(`/api/articles/${articleEnCours}`, { method: "PUT", body: corps });
    else await api("/api/articles", { method: "POST", body: corps });
    toast("Article enregistré");
    goBack();
  });
});

function supprimerArticle(id, article = null) {
  const a = article || articlesCache.find(x => x.id === id);
  supprimerAvecConfirmation(`Supprimer l'article « ${a ? a.nom : ""} » ? Entrez votre mot de passe Admin pour confirmer.`,
    `/api/articles/${id}/supprimer`, chargerArticles);
}

// ---------- Fournisseurs ----------

async function chargerFournisseurs() {
  const zone = el("listeFournisseurs");
  try {
    [fournisseursCache] = await Promise.all([api("/api/fournisseurs"), optionsCommerce ? null : chargerOptionsCommerce()]);
  } catch (e) {
    zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`;
    return;
  }
  if (!fournisseursCache.length) {
    zone.innerHTML = '<div class="card vide">Aucun fournisseur pour l\'instant. Cliquez sur « + Nouveau fournisseur ».</div>';
    return;
  }
  zone.innerHTML = `<div class="card"><h3>Fournisseurs</h3>${fournisseursCache.map(f => `
    <div class="row row-fiche etat-${f.actif ? "a_jour" : "termine"}" data-fiche="fournisseur:${f.id}" tabindex="0"${motsCles({ tel: [f.telephone], textes: [f.contact, f.adresse, f.note] })}>
      <span class="who"><b>${esc(f.nom)}</b>${f.actif ? "" : ' <span class="pill">Inactif</span>'}
        <br><span class="petit">${[f.telephone, f.contact, f.adresse].filter(Boolean).map(esc).join(" · ") || "—"}${
          f.nb_articles ? ` · ${f.nb_articles} article${f.nb_articles > 1 ? "s" : ""}` : ""}${f.note ? `<br>${esc(f.note)}` : ""}</span></span>
      <span class="boutons">
        ${ibtn("modifier", "Modifier ce fournisseur", `modifierFournisseur(${f.id})`)}
        ${optionsCommerce && optionsCommerce.supprime ? ibtn("supprimer", "Supprimer ce fournisseur", `supprimerFournisseur(${f.id})`) : ""}
      </span>
    </div>`).join("")}</div>`;
  el("rechercheFournisseurs").dispatchEvent(new Event("input"));
}
brancherRecherche(el("rechercheFournisseurs"), el("listeFournisseurs"));

function preparerFormFournisseur(f) {
  fournisseurEnCours = f ? f.id : null;
  el("titreFournisseur").textContent = f ? "Modifier le fournisseur" : "Nouveau fournisseur";
  el("fouNom").value = f ? f.nom : "";
  el("fouTel").value = f ? f.telephone : "";
  el("fouContact").value = f ? f.contact : "";
  el("fouAdresse").value = f ? f.adresse : "";
  el("fouNote").value = f ? f.note : "";
  el("fouActif").checked = f ? f.actif : true;
  erreurFormulaire(el("formulaireFournisseur"), "");
}
function nouveauFournisseur() {
  preparerFormFournisseur(null);
  afficher("formFournisseur");
}
function modifierFournisseur(id) {
  const f = fournisseursCache.find(x => x.id === id);
  if (!f) return;
  preparerFormFournisseur(f);
  afficher("formFournisseur");
}

el("formulaireFournisseur").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (el("fouNom").value.trim().length < 2) throw new Error("Indiquez le nom du fournisseur.");
    const corps = { nom: el("fouNom").value, telephone: el("fouTel").value.trim() || null,
                    contact: el("fouContact").value.trim() || null, adresse: el("fouAdresse").value.trim() || null,
                    note: el("fouNote").value.trim() || null, actif: el("fouActif").checked };
    if (fournisseurEnCours) await api(`/api/fournisseurs/${fournisseurEnCours}`, { method: "PUT", body: corps });
    else await api("/api/fournisseurs", { method: "POST", body: corps });
    toast("Fournisseur enregistré");
    goBack();
  });
});

function supprimerFournisseur(id) {
  const f = fournisseursCache.find(x => x.id === id);
  supprimerAvecConfirmation(`Supprimer le fournisseur « ${f ? f.nom : ""} » ? Entrez votre mot de passe Admin pour confirmer.`,
    `/api/fournisseurs/${id}/supprimer`, chargerFournisseurs);
}
