// État des lieux d'entrée / de sortie : grille pièce par pièce, compteurs, clés, photos,
// signatures à l'écran (doigt ou souris), PDF signé verrouillé, envoi au locataire.

let edlCache = { etats: [], a_faire: [] };
let edlOptions = null;
let edlEnCours = null;      // { id, statut, numero, caution, … } ; null = nouveau
let edlPieces = [];         // [{ piece, elements: [{ element, etat, observation, etat_entree }] }]
let edlPhotos = [];
const RANG_ETAT_EDL = { "Neuf": 0, "Bon état": 1, "État d'usage": 2, "Mauvais état": 3, "Hors service": 4 };
const CLASSE_ETAT_EDL = { "Neuf": "ok", "Bon état": "ok", "État d'usage": "warn", "Mauvais état": "danger", "Hors service": "danger" };

// ---------- Carte de l'accueil ----------
async function chargerCarteEdl() {
  if (!peut("etats_des_lieux")) return;
  try {
    edlCache = await api("/api/etats-des-lieux");
    const bouts = [];
    if (edlCache.a_faire.length) bouts.push(`${edlCache.a_faire.length} à faire`);
    if (edlCache.brouillons) bouts.push(`${edlCache.brouillons} à faire signer`);
    bouts.push(`${edlCache.etats.filter(e => e.statut === "Signé").length} signé(s)`);
    el("edlChiffres").innerHTML = bouts.map(b => `<span>${esc(b)}</span>`).join("");
  } catch { el("edlChiffres").innerHTML = ""; }
}
const _accueilAvantEdl = CHARGEURS.accueil;
CHARGEURS.accueil = () => { if (_accueilAvantEdl) _accueilAvantEdl(); chargerCarteEdl(); };

// ---------- Liste ----------
async function chargerEdl() {
  const zone = el("listeEdl");
  try { edlCache = await api("/api/etats-des-lieux"); }
  catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  const aFaire = edlCache.a_faire.map(a => `<div class="row row-fiche etat-retard" data-fiche="contrat:${a.contrat_id}" tabindex="0">
      <span class="who"><b>${esc(a.locataire)}</b> — ${esc(a.logement)}<br><span class="petit">${esc(a.raison)} — N° ${esc(a.numero_contrat)}</span></span>
      <span class="boutons"><span class="pill ${a.type_edl === "Sortie" ? "warn" : "info"}">${esc(a.type_edl)}</span>
        <button class="btn-sm" onclick="nouvelEtatDesLieux(${a.contrat_id}, '${a.type_edl}')">Commencer</button></span></div>`).join("");
  const faits = edlCache.etats.map(e => `<div class="row row-fiche etat-${e.statut === "Signé" ? "a_jour" : "retard"}" data-fiche="edl:${e.id}" tabindex="0">
      <span class="who">N° ${esc(e.numero)} — <b>${esc(e.locataire)}</b> — ${esc(e.logement)}
        <br><span class="petit">${esc(e.type_edl)} du ${formatDate(e.date_edl)} — ${e.nb_photos} photo(s)${e.signe_le ? " — signé le " + esc(e.signe_le) : ""}${e.envoye_le ? ' — <span class="envoye">envoyé au locataire le ' + esc(e.envoye_le) + "</span>" : ""}</span></span>
      <span class="boutons">
        <span class="pill ${e.statut === "Signé" ? "ok" : "warn"}">${esc(e.statut)}</span>
        ${ibtn(e.statut === "Signé" ? "voir" : "modifier", e.statut === "Signé" ? "Ouvrir (lecture seule)" : "Continuer / faire signer", `ouvrirEdl(${e.id})`)}
        ${ibtn("pdf", e.statut === "Signé" ? "PDF signé" : "Aperçu PDF (brouillon)", `window.open('/api/etats-des-lieux/${e.id}/pdf', '_blank')`)}
        ${e.statut === "Signé" ? ibtn("partager", "Envoyer la copie signée au locataire", `envoyerEdl(${e.id})`, { classe: "wa" }) : ""}
        ${estAdmin() ? ibtn("supprimer", "Supprimer (Admin)", `supprimerEdl(${e.id})`) : ""}
      </span></div>`).join("");
  zone.innerHTML = (aFaire ? `<div class="card"><h3>À faire</h3>${aFaire}</div>` : "") +
    `<div class="card"><h3>États des lieux</h3>${faits || '<div class="vide">Aucun état des lieux pour l\'instant.</div>'}</div>`;
  el("rechercheEdl").dispatchEvent(new Event("input"));
}
CHARGEURS.etats_des_lieux = chargerEdl;
brancherRecherche(el("rechercheEdl"), el("listeEdl"));

// ---------- Formulaire ----------
async function chargerOptionsEdl() {
  edlOptions = edlOptions || await api("/api/etats-des-lieux/options");
  return edlOptions;
}

function verrouillerEdl(verrou) {
  el("formulaireEdl").querySelectorAll("input, select, textarea").forEach(c => { c.disabled = verrou; });
  el("edlBtnEnregistrer").style.display = verrou ? "none" : "";
  el("edlBtnSigner").style.display = verrou ? "none" : "";
  el("edlSectionSignature").style.display = "none";
  document.querySelectorAll("#edlPieces .ibtn, #edlPieces .btn-sm, #edlPhotos .pj-suppr").forEach(b => { b.style.display = verrou ? "none" : ""; });
  document.querySelectorAll("#edlSectionPhotos .pj-boutons, #formEdl .toolbar").forEach(b => { b.style.display = verrou ? "none" : ""; });
  let envoi = el("edlBtnEnvoyer");
  if (verrou && !envoi) {
    el("edlActions").insertAdjacentHTML("beforeend", '<button type="button" class="btn primary" id="edlBtnEnvoyer">Envoyer au locataire</button>');
    envoi = el("edlBtnEnvoyer");
  }
  if (envoi) { envoi.style.display = verrou ? "" : "none"; envoi.onclick = () => envoyerEdl(edlEnCours.id); }
}

async function nouvelEtatDesLieux(contratId = null, type = null) {
  edlOptions = null;   // liste des contrats à jour
  try { await chargerOptionsEdl(); } catch (e) { toast(e.message); return; }
  edlEnCours = null;
  edlPhotos = [];
  remplirSelect(el("edlContrat"), edlOptions.contrats, {
    valeur: c => c.id, texte: c => `${c.locataire} — ${c.logement} — N° ${c.numero_contrat} (${c.statut_contrat})`,
    vide: edlOptions.contrats.length ? "— Choisir le contrat —" : "Aucun contrat",
  });
  if (contratId && !edlOptions.contrats.some(c => c.id === Number(contratId))) contratId = null;
  el("edlContrat").value = contratId ?? "";
  el("edlType").value = type || typeProposeEdl(contratId);
  fixerDate("edlDate", aujourdhui());
  ["edlElecNum", "edlElecIndex", "edlEauNum", "edlEauIndex", "edlObservations", "edlRetenues"].forEach(id => { el(id).value = ""; });
  el("edlCles").value = "2";
  el("edlTitre").textContent = "Nouvel état des lieux";
  edlPieces = [];
  el("edlContrat").disabled = false;
  el("edlType").disabled = false;
  await afficher("formEdl");
  verrouillerEdl(false);
  el("edlContrat").disabled = false;
  el("edlType").disabled = false;
  if (contratId) await chargerModeleEdl(); else afficherPiecesEdl();
  afficherPhotosEdl();
  majAideEdl();
}

function typeProposeEdl(contratId) {
  const c = edlOptions?.contrats.find(x => x.id === Number(contratId));
  return c && ["Résilié", "Expiré"].includes(c.statut_contrat) ? "Sortie" : "Entrée";
}

async function chargerModeleEdl() {
  const contrat = el("edlContrat").value;
  if (!contrat) { edlPieces = []; afficherPiecesEdl(); return; }
  try {
    const m = await api(`/api/etats-des-lieux/modele?contrat_id=${contrat}&type_edl=${encodeURIComponent(el("edlType").value)}`);
    edlPieces = m.pieces;
    edlEnCours = { caution: m.caution };
    el("edlCles").value = m.nb_cles;
    if (m.depuis_entree) toast("Grille reprise de l'état des lieux d'entrée : comparez élément par élément.", 5000);
  } catch (e) { toast(e.message); }
  afficherPiecesEdl();
  majAideEdl();
}
el("edlContrat").addEventListener("change", () => {
  if (edlEnCours?.id) return;
  el("edlType").value = typeProposeEdl(el("edlContrat").value);
  chargerModeleEdl();
});
el("edlType").addEventListener("change", () => { if (!edlEnCours?.id) chargerModeleEdl(); });

function majAideEdl() {
  const sortie = el("edlType").value === "Sortie";
  el("champRetenues").style.display = sortie ? "" : "none";
  el("edlAide").innerHTML = sortie
    ? "<b>Sortie</b> : l'état noté à l'entrée est rappelé en gris ; toute dégradation apparaît en rouge et peut justifier une retenue sur la caution (hors usure normale)."
    : "<b>Entrée</b> : soyez précis (photos à l'appui) — c'est la référence qui protège le propriétaire comme le locataire au moment de la sortie.";
  majComparaisonEdl();
}

function afficherPiecesEdl() {
  const etats = edlOptions?.etats || ["Neuf", "Bon état", "État d'usage", "Mauvais état", "Hors service", "Absent / sans objet"];
  const sortie = el("edlType").value === "Sortie";
  el("edlPieces").innerHTML = edlPieces.map((p, i) => `
    <div class="card" style="padding:.8rem;margin-bottom:.7rem">
      <div class="row" style="border:none;padding-top:0"><span class="who"><b>${esc(p.piece)}</b> <span class="petit">(${p.elements.length} élément(s))</span></span>
        <span class="boutons">
          <button type="button" class="btn-sm" onclick="toutBonEdl(${i})" data-tip="Tous les éléments en « Bon état »">Tout en bon état</button>
          ${ibtn("ajouter", "Ajouter un élément", `ajouterElementEdl(${i})`, { classe: "modif" })}
          ${ibtn("appareil", "Photo de cette pièce", `photoEdl('photo', ${i})`, { classe: "doc" })}
          ${ibtn("supprimer", "Retirer cette pièce", `retirerPieceEdl(${i})`)}
        </span></div>
      <div class="defilement"><table class="tableau"><thead><tr><th>Élément</th>${sortie ? "<th>À l'entrée</th>" : ""}<th>État</th><th>Observation</th><th></th></tr></thead><tbody>
      ${p.elements.map((e, j) => {
        const degrade = sortie && e.etat_entree in RANG_ETAT_EDL && e.etat in RANG_ETAT_EDL && RANG_ETAT_EDL[e.etat] > RANG_ETAT_EDL[e.etat_entree];
        return `<tr${degrade ? ' style="background:#fdf0ed"' : ""}>
          <td>${esc(e.element)}</td>
          ${sortie ? `<td><span class="pill ${CLASSE_ETAT_EDL[e.etat_entree] || "info"}">${esc(e.etat_entree || "—")}</span></td>` : ""}
          <td><select data-p="${i}" data-e="${j}" data-champ="etat" class="search" style="min-width:140px">${etats.map(x => `<option${x === e.etat ? " selected" : ""}>${esc(x)}</option>`).join("")}</select></td>
          <td style="width:45%"><input data-p="${i}" data-e="${j}" data-champ="observation" class="search" style="width:100%" maxlength="300" value="${esc(e.observation || "")}" placeholder="${degrade ? "Décrivez la dégradation" : "RAS"}"></td>
          <td>${ibtn("supprimer", "Retirer l'élément", `retirerElementEdl(${i}, ${j})`)}</td></tr>`;
      }).join("")}
      </tbody></table></div>
    </div>`).join("") || '<div class="vide">Choisissez le contrat : la grille des pièces se remplit selon le type de logement.</div>';
  // pièces que l'on peut ajouter
  const types = edlOptions?.pieces_types || [];
  el("edlNouvellePiece").innerHTML = types.map(t => `<option>${esc(t)}</option>`).join("") + '<option value="__autre">Autre pièce…</option>';
  remplirSelect(el("edlPhotoPiece"), edlPieces.map(p => p.piece), { vide: "Photo générale" });
  majComparaisonEdl();
}

el("edlPieces").addEventListener("change", e => {
  const c = e.target;
  if (!c.dataset.champ) return;
  edlPieces[c.dataset.p].elements[c.dataset.e][c.dataset.champ] = c.value;
  if (c.dataset.champ === "etat") afficherPiecesEdl();
});
el("edlPieces").addEventListener("input", e => {
  const c = e.target;
  if (c.dataset.champ === "observation") edlPieces[c.dataset.p].elements[c.dataset.e].observation = c.value;
});

function toutBonEdl(i) { edlPieces[i].elements.forEach(e => { if (e.etat !== "Absent / sans objet") e.etat = "Bon état"; }); afficherPiecesEdl(); }
function retirerPieceEdl(i) { if (confirm(`Retirer la pièce « ${edlPieces[i].piece} » ?`)) { edlPieces.splice(i, 1); afficherPiecesEdl(); } }
function retirerElementEdl(i, j) { edlPieces[i].elements.splice(j, 1); afficherPiecesEdl(); }
function ajouterElementEdl(i) {
  const nom = prompt("Nom de l'élément (ex : Climatiseur, Chauffe-eau, Moustiquaire…)");
  if (nom && nom.trim()) { edlPieces[i].elements.push({ element: nom.trim().slice(0, 80), etat: "Bon état", observation: "" }); afficherPiecesEdl(); }
}
function ajouterPieceEdl() {
  let nom = el("edlNouvellePiece").value;
  if (nom === "__autre") nom = (prompt("Nom de la pièce (ex : Bureau, Buanderie, Garage…)") || "").trim();
  if (!nom) return;
  const deja = edlPieces.filter(p => p.piece === nom || p.piece.startsWith(nom + " ")).length;
  const elements = (edlOptions.elements_communs || []).map(x => ({ element: x, etat: "Bon état", observation: "" }));
  edlPieces.push({ piece: deja ? `${nom} ${deja + 1}` : nom, elements });
  afficherPiecesEdl();
}

function majComparaisonEdl() {
  const zone = el("edlComparaison");
  if (el("edlType").value !== "Sortie") { zone.style.display = "none"; return; }
  const degradations = edlPieces.flatMap(p => p.elements.filter(e => e.etat_entree in RANG_ETAT_EDL && e.etat in RANG_ETAT_EDL &&
    RANG_ETAT_EDL[e.etat] > RANG_ETAT_EDL[e.etat_entree]).map(e => `${p.piece} — ${e.element}`));
  const caution = edlEnCours?.caution ?? 0;
  const retenues = lireMontant(el("edlRetenues").value) || 0;
  zone.style.display = "";
  zone.innerHTML = `${degradations.length ? `<b>${degradations.length} dégradation(s)</b> : ${esc(degradations.slice(0, 6).join(" ; "))}${degradations.length > 6 ? "…" : ""}` : "Aucune dégradation par rapport à l'entrée."}
    <br>Caution versée : <b>${formatMontant(caution)}</b> — Retenues : <b>${formatMontant(retenues)}</b> — À restituer : <b>${formatMontant(Math.max(caution - retenues, 0))}</b>`;
}
el("edlRetenues").addEventListener("input", majComparaisonEdl);

function corpsEdl() {
  const cles = Number(el("edlCles").value || 0);
  if (!Number.isInteger(cles) || cles < 0 || cles > 50) throw new Error("Nombre de clés invalide.");
  const retenues = el("edlRetenues").value.trim() ? lireMontant(el("edlRetenues").value) : 0;
  if (retenues === null) throw new Error("Montant des retenues invalide (ex : 25 000).");
  return {
    contrat_id: Number(el("edlContrat").value), type_edl: el("edlType").value,
    date_edl: valeurDate("edlDate", "Date"), pieces: edlPieces,
    compteur_electricite: { numero: el("edlElecNum").value, index: el("edlElecIndex").value },
    compteur_eau: { numero: el("edlEauNum").value, index: el("edlEauIndex").value },
    nb_cles: cles, observations: el("edlObservations").value, retenues,
  };
}

async function enregistrerEdl(silencieux = false) {
  if (!el("edlContrat").value) throw new Error("Choisissez le contrat.");
  if (!edlPieces.length) throw new Error("Ajoutez au moins une pièce.");
  const corps = corpsEdl();
  if (edlEnCours?.id) {
    await api(`/api/etats-des-lieux/${edlEnCours.id}`, { method: "PUT", body: corps });
  } else {
    const rep = await api("/api/etats-des-lieux", { method: "POST", body: corps });
    edlEnCours = { ...(edlEnCours || {}), id: rep.id, numero: rep.numero, statut: "Brouillon" };
    el("edlTitre").textContent = `État des lieux N° ${rep.numero} (brouillon)`;
    el("edlContrat").disabled = true;
    el("edlType").disabled = true;
  }
  if (!silencieux) toast("Brouillon enregistré : vous pourrez le reprendre plus tard.");
}

el("formulaireEdl").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, () => enregistrerEdl());
});

async function ouvrirEdl(id) {
  let d;
  try { await chargerOptionsEdl(); d = await api(`/api/etats-des-lieux/${id}`); } catch (e) { toast(e.message); return; }
  edlEnCours = d;
  edlPieces = d.pieces;
  edlPhotos = d.photos;
  if (!edlOptions.contrats.some(c => c.id === d.contrat_id)) edlOptions.contrats.push({ id: d.contrat_id, locataire: d.locataire, logement: d.logement, numero_contrat: d.numero_contrat, statut_contrat: "" });
  remplirSelect(el("edlContrat"), edlOptions.contrats, { valeur: c => c.id, texte: c => `${c.locataire} — ${c.logement} — N° ${c.numero_contrat}` });
  el("edlContrat").value = d.contrat_id;
  el("edlType").value = d.type_edl;
  fixerDate("edlDate", d.date_edl);
  el("edlElecNum").value = d.compteurs.electricite?.numero || "";
  el("edlElecIndex").value = d.compteurs.electricite?.index || "";
  el("edlEauNum").value = d.compteurs.eau?.numero || "";
  el("edlEauIndex").value = d.compteurs.eau?.index || "";
  el("edlCles").value = d.nb_cles;
  el("edlObservations").value = d.observations;
  el("edlRetenues").value = d.retenues ? formatNombre(d.retenues) : "";
  el("edlTitre").textContent = `État des lieux N° ${d.numero} — ${d.statut === "Signé" ? "signé le " + d.signe_le + " (verrouillé)" : "brouillon"}`;
  await afficher("formEdl");
  afficherPiecesEdl();
  afficherPhotosEdl();
  majAideEdl();
  verrouillerEdl(d.statut === "Signé");
  el("edlContrat").disabled = true;
  el("edlType").disabled = true;
}

// ---------- Photos ----------
async function photoEdl(source, indexPiece = null) {
  try {
    if (!edlEnCours?.id) await enregistrerEdl(true);   // il faut un brouillon pour ranger les photos
  } catch (e) { erreurFormulaire(el("formulaireEdl"), e.message); return; }
  const piece = indexPiece !== null ? edlPieces[indexPiece]?.piece : el("edlPhotoPiece").value;
  const fichiers = source === "photo" ? [await prendrePhoto()].filter(Boolean) : await choisirFichiers({ pdf: false });
  for (const f of fichiers) {
    try {
      const photo = await api(`/api/etats-des-lieux/${edlEnCours.id}/photos`, { method: "POST", body: { piece: piece || null, legende: "", contenu: f.contenu } });
      edlPhotos.push(photo);
    } catch (e) { toast(e.message); }
  }
  afficherPhotosEdl();
  if (fichiers.length) toast(`${fichiers.length} photo(s) ajoutée(s)${piece ? " — " + piece : ""}`);
}

function afficherPhotosEdl() {
  el("edlPhotos").innerHTML = edlPhotos.map(p => `<div class="pj"><img src="${p.url}" alt="" onclick="visionneuse('${p.url}', '${esc(p.piece || "Photo")}')">
    <button type="button" class="pj-suppr" data-tip="Retirer la photo" onclick="retirerPhotoEdl(${p.id})">✕</button>
    <div class="pj-nom">${esc(p.piece || "Générale")}</div></div>`).join("");
  el("edlPhotosAide").textContent = edlPhotos.length ? `${edlPhotos.length} photo(s) — elles figureront dans le PDF.`
    : "Conseil : une photo par pièce au minimum, et une photo de chaque défaut.";
  if (edlEnCours?.statut === "Signé") el("edlPhotos").querySelectorAll(".pj-suppr").forEach(b => b.remove());
}

async function retirerPhotoEdl(id) {
  if (!confirm("Retirer cette photo de l'état des lieux ?")) return;
  try {
    await api(`/api/etats-des-lieux/photos/${id}/retirer`, { method: "POST" });
    edlPhotos = edlPhotos.filter(p => p.id !== id);
    afficherPhotosEdl();
  } catch (e) { toast(e.message); }
}

async function apercuEdl() {
  try {
    if (edlEnCours?.statut !== "Signé") await enregistrerEdl(true);
    window.open(`/api/etats-des-lieux/${edlEnCours.id}/pdf`, "_blank");
  } catch (e) { erreurFormulaire(el("formulaireEdl"), e.message); }
}

// ---------- Signatures ----------
function preparerSignature(id) {
  const toile = el(id);
  const ratio = window.devicePixelRatio || 1;
  toile.width = toile.offsetWidth * ratio;
  toile.height = toile.offsetHeight * ratio;
  const ctx = toile.getContext("2d");
  ctx.scale(ratio, ratio);
  ctx.lineWidth = 2.4;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = "#1d3b53";
  toile.dataset.vide = "1";
  let dessine = false;
  const pos = e => {  // « Ajuster l'écran » : position à l'écran ramenée à la taille du dessin
    const r = toile.getBoundingClientRect(), z = zoomEcran();
    return [(e.clientX - r.left) / z, (e.clientY - r.top) / z];
  };
  toile.onpointerdown = e => { dessine = true; toile.setPointerCapture(e.pointerId); ctx.beginPath(); ctx.moveTo(...pos(e)); };
  toile.onpointermove = e => { if (!dessine) return; ctx.lineTo(...pos(e)); ctx.stroke(); toile.dataset.vide = "0"; };
  toile.onpointerup = toile.onpointercancel = () => { dessine = false; };
}
function effacerSignature(id) {
  const toile = el(id);
  toile.getContext("2d").clearRect(0, 0, toile.width, toile.height);
  toile.dataset.vide = "1";
}

async function passerALaSignature() {
  const form = el("formulaireEdl");
  erreurFormulaire(form, "");
  const section = el("edlSectionSignature");
  if (section.style.display === "none") {
    try { verifierChamps(form); await enregistrerEdl(true); } catch (e) { erreurFormulaire(form, e.message); return; }
    section.style.display = "";
    preparerSignature("sigLocataire");
    preparerSignature("sigAgent");
    el("edlBtnSigner").textContent = "Valider les signatures";
    section.scrollIntoView({ behavior: "smooth", block: "center" });
    return;
  }
  if (el("sigLocataire").dataset.vide === "1" || el("sigAgent").dataset.vide === "1") {
    erreurFormulaire(form, "Les deux parties doivent signer dans leur cadre."); return;
  }
  if (!confirm("Une fois signé, l'état des lieux ne pourra plus être modifié. Valider ?")) return;
  try {
    await enregistrerEdl(true);
    await api(`/api/etats-des-lieux/${edlEnCours.id}/signer`, { method: "POST", body: {
      signature_locataire: el("sigLocataire").toDataURL("image/png"), signature_agent: el("sigAgent").toDataURL("image/png"),
    } });
    el("edlBtnSigner").textContent = "Faire signer";
    toast("État des lieux signé et verrouillé ✅ Envoyez maintenant la copie au locataire.", 5000);
    await ouvrirEdl(edlEnCours.id);
    envoyerEdl(edlEnCours.id);
  } catch (e) { erreurFormulaire(form, e.message); }
}

// ---------- Envoi, suppression ----------
async function envoyerEdl(id) {
  let d;
  try { d = await api(`/api/etats-des-lieux/${id}`); } catch (e) { toast(e.message); return; }
  envoyerDocument({
    titre: `Envoyer l'état des lieux N° ${d.numero}`, nom: d.locataire, email: d.email || "", telephone: d.telephone || "",
    urlPdf: `/api/etats-des-lieux/${id}/pdf`, urlEmail: `/api/etats-des-lieux/${id}/envoyer-email`,
    urlWhatsApp: `/api/etats-des-lieux/${id}/whatsapp`, apres: () => { if (document.querySelector("#etats_des_lieux.active")) chargerEdl(); },
  });
}

function supprimerEdl(id) {
  const e = edlCache.etats.find(x => x.id === id);
  supprimerAvecConfirmation(`Supprimer l'état des lieux N° ${e ? e.numero : ""} (photos comprises) ? Entrez votre mot de passe Admin.`,
    `/api/etats-des-lieux/${id}/supprimer`, chargerEdl);
}
