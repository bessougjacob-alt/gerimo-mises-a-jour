// Outils communs aux nouveaux écrans : icônes avec infobulle, fenêtres, photos (appareil photo
// ou fichier), téléchargements, envoi d'un document par e-mail / WhatsApp, actions rapides.

// ---------- Icônes modernes (style « trait ») ----------
const ICONES = {
  fusionner: '<circle cx="6" cy="6" r="2.5"/><circle cx="6" cy="18" r="2.5"/><circle cx="18" cy="12" r="2.5"/><path d="M6 8.5v7"/><path d="M8 7.5c2.5 1.5 4.5 3.5 7.6 4.3"/>',
  modifier: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
  supprimer: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>',
  whatsapp: '<path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38a9.9 9.9 0 0 0 4.74 1.21h.01c5.46 0 9.9-4.45 9.9-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2Zm5.8 14.13c-.24.68-1.42 1.3-1.95 1.34-.5.05-.97.23-3.27-.68-2.77-1.09-4.52-3.93-4.66-4.11-.13-.18-1.11-1.48-1.11-2.82 0-1.34.7-2 .95-2.27.25-.27.54-.34.72-.34h.52c.17 0 .39-.06.6.46.23.54.77 1.88.84 2.02.07.14.11.3.02.48-.09.18-.14.3-.27.46-.14.16-.29.36-.41.48-.14.14-.28.29-.12.56.16.27.7 1.16 1.51 1.88 1.04.93 1.91 1.21 2.18 1.35.27.14.43.11.59-.07.16-.18.68-.79.86-1.07.18-.27.36-.23.61-.14.25.09 1.59.75 1.86.89.27.14.45.2.52.32.07.11.07.66-.17 1.33Z"/>',
  pdf: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="13" y2="17"/>',
  recu: '<path d="M6 2h12v20l-3-2-3 2-3-2-3 2z"/><line x1="9" y1="7" x2="15" y2="7"/><line x1="9" y1="11" x2="15" y2="11"/><line x1="9" y1="15" x2="13" y2="15"/>',
  quittance: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/><polyline points="9 15 11 17 15 13"/>',
  annuler: '<circle cx="12" cy="12" r="9"/><line x1="5.6" y1="5.6" x2="18.4" y2="18.4"/>',
  probleme: '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  trombone: '<path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48"/>',
  appareil: '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3z"/><circle cx="12" cy="13" r="3.5"/>',
  email: '<rect x="3" y="5" width="18" height="14" rx="2"/><polyline points="3 7 12 13 21 7"/>',
  partager: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.6" y1="13.5" x2="15.4" y2="17.5"/><line x1="15.4" y1="6.5" x2="8.6" y2="10.5"/>',
  telecharger: '<path d="M12 3v12"/><polyline points="7 10 12 15 17 10"/><path d="M5 19h14"/>',
  imprimer: '<polyline points="6 9 6 3 18 3 18 9"/><rect x="6" y="13" width="12" height="8"/><path d="M4 17H2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5h-2"/>',
  voir: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
  ajouter: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  coche: '<polyline points="20 6 9 17 4 12"/>',
  edl: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 3h6v3H9z"/><polyline points="9 13 11 15 15 11"/>',
  courrier: '<rect x="3" y="5" width="18" height="14" rx="2"/><polyline points="3 7 12 13 21 7"/>',
  calendrier: '<rect x="3" y="5" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="8" y1="3" x2="8" y2="7"/><line x1="16" y1="3" x2="16" y2="7"/>',
  personne: '<circle cx="12" cy="8" r="3.4"/><path d="M5 20c1.2-4 4-6 7-6s5.8 2 7 6"/>',
  maison: '<path d="M4 11 12 4l8 7"/><path d="M6 10v9h12v-9"/>',
  argent: '<rect x="3" y="6" width="18" height="13" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/>',
  carte: '<rect x="2" y="5" width="20" height="14" rx="2"/><circle cx="8" cy="12" r="2.5"/><line x1="13" y1="10" x2="18" y2="10"/><line x1="13" y1="14" x2="17" y2="14"/>',
  rapport: '<line x1="5" y1="20" x2="5" y2="11"/><line x1="12" y1="20" x2="12" y2="5"/><line x1="19" y1="20" x2="19" y2="14"/>',
  outil: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-2.4z"/>',
  horloge: '<circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/>',
  telephone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2Z"/>',
};

function svgIcone(nom) { return `<svg viewBox="0 0 24 24" aria-hidden="true">${ICONES[nom] || ""}</svg>`; }

// Bouton-icône avec courte description au survol
//   ibtn("modifier", "Modifier ce bien", "modifierCite(3)")
const CLASSE_ICONE = { modifier: "modif", supprimer: "del", whatsapp: "wa", pdf: "doc", recu: "doc", quittance: "doc",
                       annuler: "del", probleme: "alerte", trombone: "doc" };
function ibtn(icone, infobulle, action, { classe = null, desactive = null } = {}) {
  const tip = desactive || infobulle;
  return `<button type="button" class="ibtn ${classe ?? CLASSE_ICONE[icone] ?? ""}" data-tip="${esc(tip)}" aria-label="${esc(infobulle)}"` +
    (desactive ? " disabled" : ` onclick="${action}"`) + `>${svgIcone(icone)}</button>`;
}

// ---------- Fenêtres (modales) créées à la demande ----------
function ouvrirFenetre(html, { taille = "large", fermable = true } = {}) {
  const fond = document.createElement("div");
  fond.className = "modal-overlay show";
  fond.innerHTML = `<div class="modal-box ${taille}" role="dialog">${html}</div>`;
  document.body.appendChild(fond);
  const fermer = () => { fond.remove(); document.removeEventListener("keydown", echap); fond.dispatchEvent(new Event("fermee")); };
  const echap = e => { if (e.key === "Escape" && fermable) fermer(); };
  document.addEventListener("keydown", echap);
  if (fermable) fond.addEventListener("mousedown", e => { if (e.target === fond) fermer(); });
  fond.querySelectorAll("[data-fermer]").forEach(b => b.addEventListener("click", fermer));
  fond.fermer = fermer;
  return fond;
}

function visionneuse(url, titre = "") {
  ouvrirFenetre(`<div class="modal-tete"><h3>${esc(titre)}</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <div class="visionneuse"><img src="${esc(url)}" alt="${esc(titre)}"></div>`, { taille: "tres-large" });
}

// ---------- Photos et fichiers ----------

// Image → JPEG réduit (≈ 300 Ko) avant l'envoi : rapide même sur un réseau lent
function compresserImage(fichier, coteMax = 1800, qualite = 0.82) {
  return new Promise((resolve, reject) => {
    const lecteur = new FileReader();
    lecteur.onerror = () => reject(new Error("Fichier illisible."));
    lecteur.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("Cette image n'est pas lisible (formats acceptés : JPEG, PNG)."));
      img.onload = () => {
        const echelle = Math.min(1, coteMax / Math.max(img.width, img.height));
        const toile = document.createElement("canvas");
        toile.width = Math.round(img.width * echelle);
        toile.height = Math.round(img.height * echelle);
        toile.getContext("2d").drawImage(img, 0, 0, toile.width, toile.height);
        resolve(toile.toDataURL("image/jpeg", qualite));
      };
      img.src = lecteur.result;
    };
    lecteur.readAsDataURL(fichier);
  });
}

function lireDataURL(fichier) {
  return new Promise((resolve, reject) => {
    const lecteur = new FileReader();
    lecteur.onerror = () => reject(new Error("Fichier illisible."));
    lecteur.onload = () => resolve(lecteur.result);
    lecteur.readAsDataURL(fichier);
  });
}

// Fichier choisi → { nom, contenu (data URL), apercu, estPdf }
async function preparerFichier(fichier) {
  if (fichier.size > 12 * 1024 * 1024) throw new Error(`« ${fichier.name} » est trop lourd (12 Mo maximum).`);
  if (fichier.type === "application/pdf") {
    return { nom: fichier.name, contenu: await lireDataURL(fichier), apercu: null, estPdf: true };
  }
  if (!fichier.type.startsWith("image/")) throw new Error(`« ${fichier.name} » : seules les photos et les PDF sont acceptés.`);
  const contenu = await compresserImage(fichier);
  return { nom: fichier.name.replace(/\.[^.]+$/, "") + ".jpg", contenu, apercu: contenu, estPdf: false };
}

// Ouvre le sélecteur de fichiers ; renvoie la liste des fichiers préparés
function choisirFichiers({ multiple = true, pdf = true } = {}) {
  return new Promise(resolve => {
    const champ = document.createElement("input");
    champ.type = "file";
    champ.accept = pdf ? "image/*,application/pdf" : "image/*";
    champ.multiple = multiple;
    champ.onchange = async () => {
      const resultats = [];
      for (const f of champ.files) {
        try { resultats.push(await preparerFichier(f)); } catch (e) { toast(e.message); }
      }
      resolve(resultats);
    };
    champ.click();
  });
}

// Appareil photo : webcam du PC ou caméra de la tablette/téléphone.
// (Le navigateur n'autorise la caméra que sur http://localhost ou en https ; sinon on bascule
// sur la prise de photo du téléphone, ou le choix d'un fichier.)
async function prendrePhoto() {
  if (!navigator.mediaDevices?.getUserMedia || !window.isSecureContext) {
    const champ = document.createElement("input");
    champ.type = "file";
    champ.accept = "image/*";
    champ.capture = "environment";   // téléphone / tablette : ouvre directement l'appareil photo
    return new Promise(resolve => {
      champ.onchange = async () => {
        try { resolve(champ.files[0] ? await preparerFichier(champ.files[0]) : null); }
        catch (e) { toast(e.message); resolve(null); }
      };
      champ.click();
    });
  }
  let flux;
  try {
    flux = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment", width: { ideal: 1920 } }, audio: false });
  } catch {
    toast("Caméra indisponible ou refusée : choisissez plutôt un fichier.");
    const fichiers = await choisirFichiers({ multiple: false, pdf: false });
    return fichiers[0] || null;
  }
  return new Promise(resolve => {
    const f = ouvrirFenetre(`<div class="modal-tete"><h3>Prendre une photo</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
      <video class="camera-video" autoplay playsinline></video>
      <p class="petit">Cadrez le document ou la pièce, puis cliquez sur « Capturer ».</p>
      <div class="actions"><button class="btn" data-fermer>Annuler</button><button class="btn primary" id="btnCapturer">${svgIcone("appareil").replace("<svg", '<svg class="btn-icone"')}Capturer</button></div>`);
    const video = f.querySelector("video");
    video.srcObject = flux;
    let resultat = null;
    f.addEventListener("fermee", () => { flux.getTracks().forEach(t => t.stop()); resolve(resultat); });
    f.querySelector("#btnCapturer").onclick = () => {
      const toile = document.createElement("canvas");
      const echelle = Math.min(1, 1800 / Math.max(video.videoWidth, video.videoHeight));
      toile.width = video.videoWidth * echelle;
      toile.height = video.videoHeight * echelle;
      toile.getContext("2d").drawImage(video, 0, 0, toile.width, toile.height);
      const contenu = toile.toDataURL("image/jpeg", 0.85);
      const d = new Date();
      resultat = { nom: `photo_${d.toISOString().slice(0, 19).replace(/[:T]/g, "-")}.jpg`, contenu, apercu: contenu, estPdf: false };
      f.fermer();
    };
  });
}

// ---------- Téléchargement / partage d'un PDF ----------

// POST ou GET qui renvoie un fichier : { blob, nom }
async function apiFichier(url, options = {}) {
  const init = { ...options };
  if (options.body !== undefined) {
    init.method = init.method || "POST";
    init.headers = { "Content-Type": "application/json" };
    init.body = JSON.stringify(options.body);
  }
  let rep;
  try { rep = await fetch(url, init); }
  catch { throw new Error("Le serveur ne répond pas. Vérifiez qu'il est bien démarré."); }
  if (rep.status === 401) { window.location.replace("/connexion"); throw new Error("Session expirée."); }
  if (!rep.ok) {
    const d = await rep.json().catch(() => ({}));
    throw new Error(typeof d.detail === "string" ? d.detail : "Erreur du serveur.");
  }
  const dispo = rep.headers.get("Content-Disposition") || "";
  const nom = (/filename="?([^";]+)"?/.exec(dispo) || [])[1] || "document.pdf";
  return { blob: await rep.blob(), nom };
}

// Application Android ISUP : les fichiers sont confiés au téléphone (dossier Téléchargements)
async function envoyerAuTelephone(blob, nom, ouvrir) {
  const donnees = await lireDataURL(blob);
  window.ISUPAndroid.enregistrerFichier(donnees.split(",")[1], nom, blob.type || "application/octet-stream", !!ouvrir);
}

function telechargerBlob(blob, nom) {
  if (window.ISUPAndroid) { envoyerAuTelephone(blob, nom, false); return; }
  const lien = document.createElement("a");
  lien.href = URL.createObjectURL(blob);
  lien.download = nom;
  document.body.appendChild(lien);
  lien.click();
  setTimeout(() => { URL.revokeObjectURL(lien.href); lien.remove(); }, 2000);
}

function ouvrirBlob(blob, nom = "document.pdf") {
  if (window.ISUPAndroid) { envoyerAuTelephone(blob, nom, true); return; }
  const url = URL.createObjectURL(blob);
  window.open(url, "_blank");
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

// Partage natif (Windows / Android : WhatsApp, e-mail… avec le fichier joint), sinon téléchargement
async function partagerFichier(blob, nom, texte) {
  const fichier = new File([blob], nom, { type: blob.type || "application/pdf" });
  if (navigator.canShare && navigator.canShare({ files: [fichier] })) {
    try { await navigator.share({ files: [fichier], title: nom, text: texte }); return true; }
    catch (e) { if (e.name === "AbortError") return false; }
  }
  telechargerBlob(blob, nom);
  toast("PDF téléchargé : joignez-le à votre message (glisser-déposer).");
  return false;
}

// Fenêtre « Envoyer le document » : e-mail (pièce jointe), WhatsApp, partage, téléchargement
//   urlPdf : adresse du PDF ; urlEmail / urlWhatsApp : routes d'envoi du serveur
async function envoyerDocument({ titre, urlPdf, urlEmail, urlWhatsApp, email = "", telephone = "", nom = "", apres }) {
  const publics = await parametresPublics();
  const f = ouvrirFenetre(`<div class="modal-tete"><h3>${esc(titre)}</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <p class="petit">Destinataire : <b>${esc(nom)}</b>${telephone ? " — " + esc(telephone) : ""}</p>
    <div class="form-section"><h3>Par e-mail (PDF en pièce jointe)</h3>
      <div class="field"><input id="envoiEmail" type="email" value="${esc(email)}" placeholder="adresse e-mail du destinataire"></div>
      ${publics.email_configure ? "" : '<p class="petit" style="color:var(--warn)">L\'envoi d\'e-mails n\'est pas encore configuré (Paramètres → E-mail, Admin).</p>'}
      <div class="actions" style="justify-content:flex-start;margin-top:0"><button class="btn primary" id="envoiBtnEmail">${svgIcone("email").replace("<svg", '<svg class="btn-icone"')}Envoyer l'e-mail</button></div>
    </div>
    <div class="form-section"><h3>Par WhatsApp</h3>
      <p class="petit">WhatsApp s'ouvre avec le message prêt ; le PDF est téléchargé en même temps : glissez-le dans la conversation.
      Sur tablette / téléphone, « Partager » joint directement le PDF.</p>
      <div class="actions" style="justify-content:flex-start;margin-top:0">
        <button class="btn" id="envoiBtnWa" style="border-color:#25d366;color:#1da851">${svgIcone("whatsapp").replace("<svg", '<svg class="btn-icone" style="fill:currentColor;stroke:none"')}Ouvrir WhatsApp</button>
        <button class="btn" id="envoiBtnPartager">${svgIcone("partager").replace("<svg", '<svg class="btn-icone"')}Partager…</button>
        <button class="btn ghost" id="envoiBtnTelecharger">${svgIcone("telecharger").replace("<svg", '<svg class="btn-icone"')}Télécharger</button>
      </div>
    </div>
    <div class="form-erreur" role="alert"></div>`);
  const erreur = m => { const z = f.querySelector(".form-erreur"); z.textContent = m || ""; z.style.display = m ? "block" : "none"; };
  const pdf = () => apiFichier(urlPdf);
  f.querySelector("#envoiBtnEmail").onclick = async ev => {
    erreur("");
    const adresse = f.querySelector("#envoiEmail").value.trim();
    if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(adresse)) { erreur("Indiquez une adresse e-mail valable."); return; }
    ev.target.disabled = true;
    try {
      await api(urlEmail, { method: "POST", body: { destinataire: adresse } });
      toast(`E-mail envoyé à ${adresse} ✅`);
      f.fermer();
      if (apres) apres();
    } catch (e) { erreur(e.message); }
    finally { ev.target.disabled = false; }
  };
  f.querySelector("#envoiBtnWa").onclick = async () => {
    erreur("");
    const fenetre = window.open("", "_blank");
    try {
      const [rep, fichier] = await Promise.all([api(urlWhatsApp, { method: "POST" }), pdf()]);
      telechargerBlob(fichier.blob, fichier.nom);
      if (fenetre) fenetre.location.href = rep.lien; else window.location.href = rep.lien;
      toast(rep.a_numero ? "WhatsApp ouvert : joignez le PDF téléchargé, puis Envoyer." : "Pas de numéro : choisissez le contact dans WhatsApp.", 6000);
      f.fermer();
      if (apres) apres();
    } catch (e) { if (fenetre) fenetre.close(); erreur(e.message); }
  };
  f.querySelector("#envoiBtnPartager").onclick = async () => {
    try { const fichier = await pdf(); if (await partagerFichier(fichier.blob, fichier.nom, titre)) { f.fermer(); if (apres) apres(); } }
    catch (e) { erreur(e.message); }
  };
  f.querySelector("#envoiBtnTelecharger").onclick = async () => {
    try { const fichier = await pdf(); telechargerBlob(fichier.blob, fichier.nom); } catch (e) { erreur(e.message); }
  };
}

let _publics = null;
async function parametresPublics(forcer = false) {
  if (!_publics || forcer) {
    try { _publics = await api("/api/parametres/publics"); } catch { _publics = {}; }
  }
  return _publics;
}

// Ouvre WhatsApp vers un numéro avec un texte (sans passer par le serveur)
function ouvrirWhatsAppTexte(telephone, texte = "") {
  let chiffres = String(telephone || "").replace(/\D/g, "");
  if (chiffres.length === 10) chiffres = "225" + chiffres;
  window.open(`https://wa.me/${chiffres}${texte ? "?text=" + encodeURIComponent(texte) : ""}`, "_blank");
}

// ---------- Menus flottants (actions rapides) ----------
function fermerMenusFlottants() {
  document.querySelectorAll(".menu-flottant, .voile-focus").forEach(m => m.remove());
  document.querySelectorAll(".qbtn.ouvert").forEach(b => b.classList.remove("ouvert"));
}
document.addEventListener("mousedown", e => { if (!e.target.closest(".menu-flottant, .qbtn, .voile-focus")) fermerMenusFlottants(); });

function menuFlottant(ancre, titre, choix) {
  fermerMenusFlottants();
  // voile léger : l'arrière-plan s'efface pour faciliter la lecture du menu
  const voile = document.createElement("div");
  voile.className = "voile-focus";
  voile.addEventListener("mousedown", fermerMenusFlottants);
  document.body.appendChild(voile);
  ancre.classList.add("ouvert");
  const menu = document.createElement("div");
  menu.className = "menu-flottant show";
  menu.innerHTML = `<div class="mf-titre">${esc(titre)}</div>` + choix.map((c, i) => c.rubrique
    ? `<div class="mf-rubrique">${esc(c.rubrique)}</div>`
    : `<button data-i="${i}">${svgIcone(c.icone)}${esc(c.libelle)}</button>`).join("");
  document.body.appendChild(menu);
  const r = ancre.getBoundingClientRect();
  const z = zoomEcran();  // « Ajuster l'écran » : mesures à l'écran, positions à diviser par l'agrandissement
  const largeur = menu.offsetWidth * z, hauteur = menu.offsetHeight * z;
  menu.style.left = Math.max(8, Math.min(r.left, innerWidth - largeur - 60)) / z + "px";
  menu.style.top = (r.bottom + hauteur + 8 < innerHeight ? r.bottom + 6 : Math.max(8, r.top - hauteur - 6)) / z + "px";
  menu.addEventListener("click", e => {
    const b = e.target.closest("button[data-i]");
    if (!b) return;
    fermerMenusFlottants();
    choix[Number(b.dataset.i)].action();
  });
}

const peut = module => moi && moi.modules.includes(module);

// Liste à ouvrir pour « Modifier » / « Supprimer » (l'icône crayon ou corbeille se trouve sur chaque ligne)
function listesModifiables() {
  return [
    ["proprietaires", "Un propriétaire", "personne"], ["biens", "Un bien ou un logement", "maison"],
    ["locataires", "Un locataire", "personne"], ["contrats", "Un contrat", "pdf"],
    ["depenses", "Une dépense", "recu"], ["achats_ventes", "Un achat / une vente", "argent"],
    ["etats_des_lieux", "Un état des lieux", "edl"], ["agenda", "Un rendez-vous / un client", "calendrier"],
  ].filter(([m]) => peut(m));
}

// Rubriques d'un menu : on ne garde que celles qui ont au moins un choix permis (licence, profil)
function rubriques(liste) {
  const resultat = [];
  for (const [titre, choix] of liste) {
    const permis = choix.filter(Boolean);
    if (permis.length) resultat.push({ rubrique: titre }, ...permis);
  }
  return resultat;
}

function menuRapide(bouton, type) {
  const vers = (ecran, apres) => async () => { if (await afficher(ecran) !== false && apres) apres(); };
  const boutique = (onglet, apres) => async () => { ongletStock = onglet; await afficher("stock"); if (apres) apres(); };
  if (type === "ajouter") {
    menuFlottant(bouton, "Ajouter", rubriques([
      ["Immobilier", [
        peut("proprietaires") && { libelle: "Un propriétaire", icone: "personne", action: vers("proprietaires", nouveauProprietaire) },
        peut("biens") && { libelle: "Un bien / un logement", icone: "maison", action: vers("biens", nouveauBien) },
        peut("contrats") && { libelle: "Un locataire et son contrat", icone: "pdf", action: vers("contrats", nouveauContrat) },
        peut("etats_des_lieux") && { libelle: "Un état des lieux", icone: "edl", action: () => nouvelEtatDesLieux() },
        peut("biens") && { libelle: "Un problème sur un bien", icone: "probleme", action: () => declarerProbleme() },
        peut("prospects") && { libelle: "Une demande de client", icone: "personne", action: () => nouveauProspect() }]],
      ["Boutique", [
        peut("stock") && moi.role !== "Caisse" && { libelle: "Un article", icone: "maison", action: boutique("stArticles", nouvelArticle) },
        peut("stock") && { libelle: "Un arrivage de marchandises", icone: "telecharger", action: boutique("stArrivages", nouvelArrivage) },
        peut("ventes") && { libelle: "Un client", icone: "personne", action: () => { ongletVentes = "veClients"; afficher("ventes").then(() => nouveauClientCommerce(false)); } },
        peut("stock") && moi.role !== "Caisse" && { libelle: "Une sortie de stock (casse, périmé…)", icone: "probleme", action: boutique("stSorties", () => nouvelleSortie()) },
        peut("stock") && moi.role !== "Caisse" && { libelle: "Un inventaire", icone: "rapport", action: boutique("stSorties", nouvelInventaire) }]],
      ["Mobile Money", [
        peut("mobile_money") && moi.role !== "Comptable" && { libelle: "Un apport d'espèces, un rechargement…", icone: "argent", action: () => { saisieMM.type = "Apport d'espèces"; ouvrirEspace("mobile_money"); } }]],
      ["Pour tous", [
        peut("depenses") && { libelle: "Une dépense", icone: "recu", action: vers("depenses", nouvelleDepense) },
        peut("agenda") && { libelle: "Un rendez-vous / un appel", icone: "calendrier", action: () => nouvelEvenement() }]],
    ]));
  } else if (type === "imprimer") {
    menuFlottant(bouton, "Imprimer", rubriques([
      ["Immobilier", [
        peut("paiements") && { libelle: "Un reçu ou une quittance", icone: "recu", action: () => { afficher("historique"); toast("Cliquez sur l'icône reçu ou quittance du paiement."); } },
        peut("contrats") && { libelle: "Un contrat de bail", icone: "pdf", action: () => { afficher("contrats"); toast("Cliquez sur l'icône PDF du contrat."); } },
        peut("etats_des_lieux") && { libelle: "Un état des lieux", icone: "edl", action: () => afficher("etats_des_lieux") },
        peut("courriers") && { libelle: "Un courrier (révision, avenant)", icone: "courrier", action: () => afficher("courriers") },
        peut("rapports") && { libelle: "Le rapport du mois", icone: "rapport", action: () => window.open("/api/rapports/pdf", "_blank") }]],
      ["Boutique", [
        peut("ventes") && { libelle: "Le ticket ou la facture d'une vente", icone: "recu", action: () => { ongletVentes = "veHistorique"; afficher("ventes"); toast("Cliquez sur la vente : Ticket ou Facture."); } },
        peut("bilan_commerce") && { libelle: "Le bilan de la boutique", icone: "rapport", action: () => window.open("/api/bilan-commerce/pdf", "_blank") }]],
      ["Mobile Money", [
        peut("mobile_money") && { libelle: "Les commissions du mois", icone: "rapport", action: () => { ongletMM = "mmCommissions"; ouvrirEspace("mobile_money"); } }]],
      ["Pour tous", [{ libelle: "Ma carte de visite (vCard)", icone: "carte", action: () => ouvrirCarteVisite() }]],
    ]));
  } else if (type === "exporter") {
    const ex = (quoi, libelle, module) => peut(module) && { libelle, icone: "telecharger", action: () => exporter(quoi) };
    menuFlottant(bouton, "Exporter vers Excel", rubriques([
      ["Immobilier", [ex("proprietaires", "Propriétaires", "proprietaires"), ex("biens", "Biens et logements", "biens"),
        ex("locataires", "Locataires", "locataires"), ex("contrats", "Contrats", "contrats"), ex("paiements", "Paiements", "paiements"),
        ex("impayes", "Impayés", "paiements"), ex("achats_ventes", "Achats / ventes de biens", "achats_ventes"),
        ex("prospects", "Demandes de clients", "prospects"), ex("signalements", "Problèmes signalés", "biens")]],
      ["Boutique", [ex("articles", "Articles et stock", "stock"), ex("ventes", "Ventes", "ventes"), ex("clients_commerce", "Clients", "ventes")]],
      ["Mobile Money", [ex("operations_mm", "Opérations du guichet", "mobile_money")]],
      ["Pour tous", [ex("depenses", "Dépenses", "depenses")]],
    ]));
  }
}

// Export Excel (CSV) d'une liste ; le serveur vérifie les droits
async function exporter(quoi, parametres = "") {
  try {
    const f = await apiFichier(`/api/export/${quoi}${parametres ? "?" + parametres : ""}`);
    telechargerBlob(f.blob, f.nom);
    toast(`Export « ${f.nom} » téléchargé : il s'ouvre avec Excel.`);
  } catch (e) { toast(e.message); }
}

function actualiser() {
  const actif = document.querySelector(".screen.active");
  if (actif && CHARGEURS[actif.id]) CHARGEURS[actif.id]();
  if (typeof chargerAssistant === "function") chargerAssistant();
  toast("Données actualisées");
}

// Bouton « Rafraîchir » de la barre de droite (en bas sur téléphone) : comme Ctrl + F5, la page et ses fichiers
// (styles, scripts) sont redemandés au serveur sans passer par la mémoire du navigateur, puis la page est rechargée.
// Serveur injoignable : on ne recharge pas (on perdrait l'écran en cours pour une page d'erreur).
let rafraichissementEnCours = false;
async function rafraichirCommeCtrlF5() {
  if (rafraichissementEnCours) return;
  rafraichissementEnCours = true;
  const bouton = el("btnRafraichir");
  if (bouton) bouton.classList.add("tourne");
  try {
    const rep = await fetch(location.pathname + location.search, { cache: "reload" });
    if (!rep.ok) throw new Error();
  } catch {
    rafraichissementEnCours = false;
    if (bouton) bouton.classList.remove("tourne");
    toast("Le serveur ne répond pas : la page n'a pas été rechargée.");
    return;
  }
  const fichiers = [...document.querySelectorAll("script[src], link[rel=stylesheet][href], link[rel=manifest][href]")]
    .map(x => x.src || x.href).filter(u => new URL(u, location.href).origin === location.origin);
  await Promise.all(fichiers.map(u => fetch(u, { cache: "reload" }).catch(() => {})));
  location.reload();
}

async function lancerSauvegarde() {
  if (!confirm("Créer une sauvegarde complète (base de données + documents) maintenant ?")) return;
  toast("Sauvegarde en cours… (quelques secondes)", 10000);
  try {
    const rep = await api("/api/sauvegarde", { method: "POST" });
    toast(`Sauvegarde créée (${rep.taille_mo} Mo). Téléchargement…`, 5000);
    const f = await apiFichier(`/api/sauvegarde/${encodeURIComponent(rep.fichier)}`);
    telechargerBlob(f.blob, f.nom);
    alert(`Sauvegarde réussie et vérifiée : ${rep.fichier}\n\nUne copie est dans le dossier « sauvegardes » du logiciel, et elle vient d'être téléchargée.\n` +
          messageCopie(rep.copie));
    if (typeof chargerAssistant === "function") chargerAssistant();
  } catch (e) { toast(e.message, 8000); }
}

function ouvrirAlertes() {
  if (peut("paiements")) {
    afficher("paiements").then(() => setTimeout(() => {
      const titre = [...document.querySelectorAll("#listePaiements h3")].find(h => h.textContent.startsWith("Impayés"));
      if (titre) titre.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 400));
  } else ouvrirAssistant();
}

// ---------- Mise à jour du logiciel ----------
// Le serveur télécharge et installe la nouvelle version, puis redémarre ; tous les PC et téléphones
// connectés se rechargent alors tout seuls (surveillerVersion, plus bas).
let versionChargee = null;

async function verifierMiseAJourDiscrete() {
  try {
    const v = await api("/api/version");
    versionChargee = versionChargee || v.version;
    if (!v.depot_configure || !estAdmin()) return;
    const r = await api("/api/version/verifier", { method: "POST" });
    // le bouton « Mise à jour » est dans Paramètres → À propos (demande de Boss du 05/10/2026)
    if (r.disponible) toast("Une mise à jour est disponible : Paramètres → À propos → Mise à jour.", 8000);
  } catch { /* silencieux */ }
}

// Toutes les minutes : si le serveur a changé de version, on recharge (après avoir prévenu)
async function surveillerVersion() {
  try {
    const v = await api("/api/version");
    if (!versionChargee) { versionChargee = v.version; return; }
    if (v.version !== versionChargee) annoncerNouvelleVersion(v.version);
  } catch { /* serveur en train de redémarrer : on réessaiera */ }
}
setInterval(surveillerVersion, 60 * 1000);

function annoncerNouvelleVersion(version) {
  if (document.getElementById("bandeauMaj")) return;
  const b = document.createElement("div");
  b.id = "bandeauMaj";
  b.className = "bandeau-maj";
  b.innerHTML = `<span>✨ Gérimo a été mis à jour (version ${esc(version)}).</span><button class="btn primary">Recharger</button>`;
  b.querySelector("button").onclick = () => location.reload();
  document.body.appendChild(b);
  // rechargement automatique si personne n'est en train de remplir un formulaire
  setTimeout(() => { if (!document.querySelector(".modal-overlay.show, section.screen.active[id^='form']")) location.reload(); }, 15000);
}

// Après l'installation : attendre que le serveur réponde avec la nouvelle version, puis recharger
async function attendreRedemarrage(zoneEtat, ancienne) {
  await new Promise(r => setTimeout(r, 6000));  // l'ancien serveur s'arrête 2 secondes après l'installation
  const debut = Date.now();
  while (Date.now() - debut < 180000) {
    await new Promise(r => setTimeout(r, 3000));
    try {
      const v = await api("/api/version");
      if (v.version !== ancienne) {
        zoneEtat.textContent = `✅ Version ${v.version} en service. Rechargement…`;
        setTimeout(() => location.reload(), 1200);
        return;
      }
    } catch { zoneEtat.textContent = "Redémarrage du serveur en cours…"; }
  }
  zoneEtat.textContent = "Le serveur met du temps à redémarrer : rechargez la page dans un instant (touche F5).";
}

// Nouveautés : quelques titres courts par version, avec ce qu'ils apportent
function listeNouveautes(elements) {
  return elements.map(e => `<div class="nouveaute"><b>${esc(e.titre)}</b>${e.apport ? `<span>${esc(e.apport)}</span>` : ""}</div>`).join("");
}
function journalNouveautes(v) {
  if (!v.versions?.length)  // serveur d'avant le journal des nouveautés
    return v.nouveautes.map(n => `<div class="nouveaute"><b>${esc(n.texte)}</b></div>`).join("") || '<p class="petit">—</p>';
  return v.versions.map(x => `<div class="nouveautes-version">${x.version === "prochaine" ? "En préparation (prochaine publication)"
    : `Version ${esc(x.version)}${x.date ? ` — ${esc(x.date)}` : ""}`}</div>${listeNouveautes(x.elements)}`).join("");
}

// Mise à jour par clé USB (client sans Internet) : le fichier « Gérimo mise à jour 1.xxx.zip » fabriqué par
// l'éditeur. Le serveur le vérifie d'abord (signature de l'éditeur), puis l'installe comme une mise à jour en ligne.
function brancherMiseAJourUsb(f, etat, versionActuelle) {
  const choisir = f.querySelector("#majUsbFichier"), installer = f.querySelector("#majInstaller");
  f.querySelector("#majUsb").onclick = () => choisir.click();
  choisir.onchange = async () => {
    const fichier = choisir.files[0];
    choisir.value = "";
    if (!fichier) return;
    installer.style.display = "none";
    etat.textContent = `Vérification de « ${fichier.name} »…`;
    let contenu;
    try {
      if (fichier.size > 80 * 1024 * 1024) throw new Error("Ce fichier est trop lourd pour être une mise à jour de Gérimo.");
      contenu = await lireDataURL(fichier);
      const r = await api("/api/version/fichier", { method: "POST", body: { contenu, installer: false } });
      etat.innerHTML = `<p style="margin:0 0 .4rem">${esc(r.message)}</p>` + (r.elements?.length ? listeNouveautes(r.elements) : "");
      if (!r.disponible) return;
    } catch (e) { etat.textContent = e.message; return; }
    installer.textContent = "Installer la version de la clé USB";
    installer.style.display = "";
    installer.disabled = false;
    installer.onclick = async () => {
      installer.disabled = true;
      etat.textContent = "Sauvegarde et installation en cours… (ne fermez pas cette fenêtre et ne retirez pas la clé USB)";
      try {
        const rep = await api("/api/version/fichier", { method: "POST", body: { contenu, installer: true } });
        etat.textContent = rep.message;
        if (rep.redemarrage) attendreRedemarrage(etat, versionActuelle);
      } catch (e) { etat.textContent = e.message; installer.disabled = false; }
    };
  };
}

async function ouvrirMiseAJour() {
  let v;
  try { v = await api("/api/version"); } catch (e) { toast(e.message); return; }
  const f = ouvrirFenetre(`<div class="modal-tete"><h3>Mise à jour du logiciel</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <div class="recap">Gérimo Pro — <b>version ${esc(v.version)}</b>${v.date ? ` du ${esc(v.date)}` : ""}</div>
    <div id="majEtat" class="petit" style="margin:.8rem 0">Recherche d'une nouvelle version…</div>
    <div class="form-section"><h3>Dernières nouveautés</h3>
      <div class="journal-nouveautes">${journalNouveautes(v)}</div>
    </div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button>${estAdmin() && !v.developpement
      ? `<button class="btn" id="majUsb" data-tip="Pas d'Internet ? Installez le fichier de mise à jour apporté sur une clé USB">Depuis une clé USB</button>
         <input type="file" id="majUsbFichier" accept=".zip" hidden>` : ""}<button class="btn primary" id="majInstaller" style="display:none">Installer la mise à jour</button></div>`);
  const etat = f.querySelector("#majEtat");
  if (f.querySelector("#majUsb")) brancherMiseAJourUsb(f, etat, v.version);
  try {
    const r = await api("/api/version/verifier", { method: "POST" });
    etat.innerHTML = `<p style="margin:0 0 .4rem">${esc(r.message)}</p>` + (r.elements?.length ? listeNouveautes(r.elements)
      : r.nouveautes?.length ? listeNouveautes(r.nouveautes.map(x => ({ titre: x }))) : "");
    if (r.disponible && r.installable !== false && estAdmin()) {
      const b = f.querySelector("#majInstaller");
      b.style.display = "";
      b.onclick = async () => {
        b.disabled = true;
        etat.textContent = "Sauvegarde, téléchargement et installation en cours… (ne fermez pas cette fenêtre)";
        try {
          const rep = await api("/api/version/installer", { method: "POST" });
          etat.textContent = rep.message;
          if (rep.redemarrage) attendreRedemarrage(etat, v.version);
        } catch (e) { etat.textContent = e.message; b.disabled = false; }
      };
    } else if (r.disponible && !estAdmin()) {
      etat.innerHTML += "<br>L'Admin peut l'installer depuis ce bouton.";
    }
  } catch (e) { etat.textContent = e.message; }
}
