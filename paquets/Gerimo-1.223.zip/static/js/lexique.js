// Paramètres → Assistant (Admin) : apprendre à Gérimo.
// Questions qu'il n'a pas comprises (gardées sans nom ni numéro), réponses apprises, dictionnaire de la dictée.

let statutQuestionsAssistant = "nouvelle";
let questionsAssistant = [];

async function chargerAssistantAdmin(statut) {
  if (statut) statutQuestionsAssistant = statut;
  const zone = el("parAssistant");
  let rep, dictee;
  try {
    [rep, dictee] = await Promise.all([api(`/api/assistant/questions?statut=${statutQuestionsAssistant}`), api("/api/assistant/dictee")]);
  } catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  questionsAssistant = rep.questions;
  el("nbQuestionsAssistant").textContent = rep.compte.nouvelle || "";
  const onglet = (s, libelle) => `<button class="btn${s === statutQuestionsAssistant ? " primary actif" : ""}" onclick="chargerAssistantAdmin('${s}')">${libelle} (${rep.compte[s]})</button>`;
  const vide = { nouvelle: "Aucune question en attente : Gérimo a compris tout ce qu'on lui a demandé.",
                 repondue: "Aucune réponse apprise pour l'instant.", ignoree: "Aucune question ignorée." }[statutQuestionsAssistant];
  zone.innerHTML = `<p class="petit">Quand Gérimo ne comprend pas une question, il ne devine pas : il la garde ici, sans les noms, téléphones ni numéros (remplacés par [nom], [téléphone]…). Donnez-lui la réponse, ou dites-lui vers qui orienter. Il la connaîtra aussitôt, sur tous les postes.</p>
    <div class="toolbar" data-onglets>${onglet("nouvelle", "À traiter")}${onglet("repondue", "Apprises")}${onglet("ignoree", "Ignorées")}</div>
    ${questionsAssistant.length ? `<div class="card">${questionsAssistant.map(ligneQuestionAssistant).join("")}</div>` : `<div class="card vide">${vide}</div>`}
    <div class="card"><h3>Dictionnaire de la dictée</h3>
      <p class="petit">Les mots que la dictée au micro entend mal, et ce que Gérimo doit comprendre à la place (exemple : « jérimo » → « Gérimo »).</p>
      <form class="toolbar" id="formulaireDictee" novalidate>
        <input id="dicteeEntendu" class="search" maxlength="80" placeholder="Ce que la dictée écrit" aria-label="Ce que la dictée écrit">
        <input id="dicteeCorrige" class="search" maxlength="120" placeholder="Ce qu'il faut comprendre" aria-label="Ce qu'il faut comprendre">
        <button type="submit" class="btn primary">Ajouter</button>
      </form>
      ${dictee.length ? dictee.map(d => `<div class="row"><span class="who">« ${esc(d.entendu)} » → <b>${esc(d.corrige)}</b></span>
        <span class="boutons"><button class="btn-sm" onclick="supprimerCorrectionDictee(${d.id})">Retirer</button></span></div>`).join("")
        : '<p class="petit">Aucun mot pour l\'instant.</p>'}
    </div>
    <div class="card"><h3>Raccourcis clavier</h3>
      <p class="petit" style="margin-top:-.4rem">Sur ordinateur, ces touches font gagner du temps. Elles marchent partout dans Gérimo.</p>
      <div class="liste-raccourcis">${LISTE_RACCOURCIS.map(([touche, quoi]) => `<div class="row"><span class="who">${esc(quoi)}</span>
        <span class="boutons"><kbd>${esc(touche)}</kbd></span></div>`).join("")}</div>
    </div>`;
  el("formulaireDictee").addEventListener("submit", ajouterCorrectionDictee);
}

function ligneQuestionAssistant(q) {
  const infos = `Posée ${q.nb} fois — ${esc(q.profils)} — dernière fois le ${esc(q.derniere)}`;
  let suite = "", boutons = "";
  if (q.statut === "nouvelle") {
    boutons = `<button class="btn-sm" onclick="repondreQuestionAssistant(${q.id})">Répondre</button>
      <button class="btn-sm" onclick="traiterQuestionAssistant(${q.id}, 'orienter_comptable')">Orienter : Comptable</button>
      <button class="btn-sm" onclick="traiterQuestionAssistant(${q.id}, 'orienter_caisse')">Orienter : Caisse</button>
      <button class="btn-sm" onclick="traiterQuestionAssistant(${q.id}, 'ignorer')">Ignorer</button>`;
  } else {
    if (q.statut === "repondue") suite = `<br><span class="petit">${q.etiquette ? `Gérimo oriente : ${esc(q.etiquette.split(": ")[1])}` : `Réponse : ${esc(q.reponse || "")}`}</span>`;
    boutons = `<button class="btn-sm" onclick="traiterQuestionAssistant(${q.id}, 'rouvrir')">Remettre à traiter</button>
      <button class="btn-sm" onclick="supprimerQuestionAssistant(${q.id})">Supprimer</button>`;
  }
  return `<div class="row"><span class="who"><b>« ${esc(q.texte)} »</b><br><span class="petit">${infos}</span>${suite}
    <div id="repQA${q.id}"></div></span><span class="boutons">${boutons}</span></div>`;
}

function repondreQuestionAssistant(id) {
  const q = questionsAssistant.find(x => x.id === id);
  el(`repQA${id}`).innerHTML = `<form class="form-section" style="margin-top:.6rem" onsubmit="event.preventDefault(); envoyerReponseAssistant(${id})">
    <div class="field"><label for="qaTexte${id}">Question (vous pouvez la reformuler)</label><input id="qaTexte${id}" maxlength="300" value="${esc(q.texte)}"></div>
    <div class="field"><label for="qaRep${id}">Réponse que Gérimo donnera</label><textarea id="qaRep${id}" rows="3" maxlength="2000" placeholder="Une réponse sûre, sans chiffre ni nom inventé."></textarea></div>
    <div class="actions"><button type="button" class="btn" onclick="el('repQA${id}').innerHTML = ''">Annuler</button><button type="submit" class="btn primary">Apprendre à Gérimo</button></div>
  </form>`;
  el(`qaRep${id}`).focus();
}

async function envoyerReponseAssistant(id) {
  const q = questionsAssistant.find(x => x.id === id);
  const texte = el(`qaTexte${id}`).value.trim();
  await traiterQuestionAssistant(id, "repondre", { reponse: el(`qaRep${id}`).value, texte: texte !== q.texte ? texte : "" });
}

async function traiterQuestionAssistant(id, action, extra = {}) {
  try {
    await api(`/api/assistant/questions/${id}`, { method: "POST", body: { action, ...extra } });
    toast({ repondre: "Gérimo connaît maintenant la réponse.", orienter_comptable: "Gérimo orientera vers le comptable.",
            orienter_caisse: "Gérimo orientera vers la Caisse.", ignorer: "Question ignorée.", rouvrir: "Question remise à traiter." }[action]);
    chargerAssistantAdmin();
  } catch (e) { toast(e.message, 8000); }
}

async function supprimerQuestionAssistant(id) {
  const mdp = await demanderMotDePasseAdmin("Supprimer cette question : Gérimo oubliera la réponse apprise. Confirmez avec votre mot de passe.");
  if (!mdp) { toast("Suppression annulée"); return; }
  await traiterQuestionAssistant(id, "supprimer", { mot_de_passe_admin: mdp });
}

async function ajouterCorrectionDictee(e) {
  e.preventDefault();
  const entendu = el("dicteeEntendu").value.trim(), corrige = el("dicteeCorrige").value.trim();
  if (entendu.length < 2 || !corrige) { toast("Remplissez les deux cases."); return; }
  try {
    await api("/api/assistant/dictee", { method: "POST", body: { entendu, corrige } });
    toast("Mot ajouté au dictionnaire de la dictée.");
    chargerAssistantAdmin();
  } catch (err) { toast(err.message, 8000); }
}

async function supprimerCorrectionDictee(id) {
  try { await api(`/api/assistant/dictee/${id}`, { method: "DELETE" }); chargerAssistantAdmin(); }
  catch (e) { toast(e.message, 8000); }
}
