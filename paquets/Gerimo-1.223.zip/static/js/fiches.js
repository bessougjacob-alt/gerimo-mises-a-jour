// Fiches de l'immobilier (13/11/2026, demande de Boss) : l'essentiel en évidence et un clic pour tout voir.
// - En haut de chaque liste : des chiffres clés (cliquables quand ils filtrent la liste).
// - Chaque ligne porte la couleur de son état (à jour, en retard, à risque, départ, terminé) et s'ouvre d'un clic
//   dans une fenêtre claire. Les boutons des lignes gardent leur rôle habituel.
// Le serveur (fiches.py) applique les mêmes droits que les listes.

const ETATS_IMMO = {
  a_jour: { texte: "À jour", pill: "ok" }, retard: { texte: "En retard", pill: "warn" },
  a_risque: { texte: "À risque", pill: "danger" }, depart: { texte: "Départ prévu", pill: "info" },
  termine: { texte: "Terminé", pill: "" }, libre: { texte: "Libre", pill: "warn" },
};

// État d'une ligne de liste (contrat ou locataire), avec les seules données de la liste
function etatListeContrat(c) {
  if (!STATUTS_EN_COURS.includes(c.statut_contrat)) return "termine";
  if (c.a_risque) return "a_risque";
  if (c.en_retard) return "retard";
  if (c.date_depart) return "depart";
  return "a_jour";
}
function etatListeLocataire(l) {
  const ordre = ["a_risque", "retard", "depart", "a_jour"];
  const etats = l.contrats.filter(c => STATUTS_EN_COURS.includes(c.statut_contrat)).map(etatListeContrat);
  return ordre.find(e => etats.includes(e)) || "termine";
}

// ---------- Chiffres clés en haut d'une liste ----------

function resumeAvant(idListe, tuiles) {
  const liste = el(idListe);
  let zone = el(idListe + "Resume");
  if (!zone) {
    zone = document.createElement("div");
    zone.id = idListe + "Resume";
    zone.className = "resume-stock";
    liste.parentElement.insertBefore(zone, liste.previousElementSibling && liste.previousElementSibling.classList.contains("toolbar")
      ? liste.previousElementSibling : liste);
  }
  const filtre = liste.dataset.filtre || "";
  zone.innerHTML = tuiles.map(t => t.filtre !== undefined
    ? `<button class="chiffre-cle ${t.classe || "neutre"}${filtre === t.filtre && t.filtre ? " choisi" : ""}" onclick="filtrerListeImmo('${idListe}', '${t.filtre}')">
        <span class="cc-chiffre">${t.chiffre}</span><span class="cc-libelle">${t.libelle}</span><span class="cc-aide">${t.aide || ""}</span></button>`
    : `<div class="chiffre-cle ${t.classe || "neutre"} statique"><span class="cc-chiffre">${t.chiffre}</span>
        <span class="cc-libelle">${t.libelle}</span><span class="cc-aide">${t.aide || ""}</span></div>`).join("");
}
// Filtre par état : ajoute une classe sur la liste (la recherche continue de marcher par-dessus)
function filtrerListeImmo(idListe, filtre) {
  const liste = el(idListe);
  liste.dataset.filtre = liste.dataset.filtre === filtre ? "" : filtre;
  liste.className = liste.dataset.filtre ? `filtre-${liste.dataset.filtre}` : "";
  const zone = el(idListe + "Resume");
  if (zone) zone.querySelectorAll("button.chiffre-cle").forEach(b => {
    b.classList.toggle("choisi", !!liste.dataset.filtre && b.getAttribute("onclick").includes(`'${liste.dataset.filtre}'`));
  });
}

function resumeLocataires() {
  const etats = locatairesCache.map(etatListeLocataire);
  const n = e => etats.filter(x => x === e).length;
  const enCours = etats.filter(e => e !== "termine").length;
  resumeAvant("listeLocataires", [
    { filtre: "", chiffre: locatairesCache.length, libelle: "Locataires", aide: `${enCours} avec un contrat en cours` },
    { filtre: "retard", classe: n("retard") + n("a_risque") ? "alerte-orange" : "calme", chiffre: n("retard") + n("a_risque"),
      libelle: "En retard de loyer", aide: n("retard") + n("a_risque") ? "voir qui relancer" : "tout le monde est à jour" },
    { filtre: "a_risque", classe: n("a_risque") ? "alerte" : "calme", chiffre: n("a_risque"), libelle: "À risque", aide: "2 mois impayés ou plus" },
    { filtre: "depart", classe: "neutre", chiffre: n("depart"), libelle: "Départs prévus", aide: "préavis reçus" },
  ]);
}

function resumeContrats() {
  const etats = contratsCache.map(etatListeContrat);
  const n = e => etats.filter(x => x === e).length;
  const enCours = etats.filter(e => e !== "termine").length;
  const loyers = contratsCache.filter(c => STATUTS_EN_COURS.includes(c.statut_contrat)).reduce((s, c) => s + c.montant_loyer, 0);
  resumeAvant("listeContrats", [
    { filtre: "", chiffre: enCours, libelle: "Contrats en cours", aide: `${formatMontant(loyers)} de loyers par mois` },
    { filtre: "retard", classe: n("retard") + n("a_risque") ? "alerte-orange" : "calme", chiffre: n("retard") + n("a_risque"),
      libelle: "En retard de loyer", aide: "au moins un mois impayé" },
    { filtre: "a_risque", classe: n("a_risque") ? "alerte" : "calme", chiffre: n("a_risque"), libelle: "À risque", aide: "2 mois impayés ou plus" },
    { filtre: "depart", classe: "neutre", chiffre: n("depart"), libelle: "Départs prévus", aide: "préavis reçus" },
  ]);
}

function resumeBiens() {
  const logements = citesCache.flatMap(c => c.logements);
  const occupes = logements.filter(l => l.statut_logement === "Occupé").length;
  const libres = logements.filter(l => l.statut_logement === "Libre").length;
  const taux = logements.length ? Math.round(occupes * 100 / logements.length) : 0;
  resumeAvant("listeBiens", [
    { chiffre: citesCache.length, libelle: citesCache.length > 1 ? "Biens" : "Bien", aide: `${logements.length} logement${logements.length > 1 ? "s" : ""}` },
    { chiffre: `${taux} %`, classe: taux >= 80 ? "calme" : "neutre", libelle: "Occupation", aide: `${occupes} occupé${occupes > 1 ? "s" : ""}` },
    { filtre: "libre", classe: libres ? "alerte-orange" : "calme", chiffre: libres, libelle: "Logements libres", aide: libres ? "à louer" : "tout est loué" },
  ]);
}

function resumeProprios() {
  const biens = propriosCache.reduce((s, p) => s + p.cites.length, 0);
  const logements = propriosCache.reduce((s, p) => s + p.cites.reduce((t, c) => t + c.nb_logements, 0), 0);
  resumeAvant("listeProprios", [
    { chiffre: propriosCache.length, libelle: "Propriétaires", aide: "cliquez sur un nom pour sa fiche" },
    { chiffre: biens, libelle: "Biens confiés", aide: `${logements} logement${logements > 1 ? "s" : ""}` },
  ]);
}

// Après chaque chargement de liste (les fonctions d'origine restent inchangées)
function apresChargement(nom, suite) {
  const origine = window[nom];
  window[nom] = async function (...args) {
    const r = await origine.apply(this, args);
    try { suite(); } catch (e) { console.error(e); }
    return r;
  };
}
apresChargement("chargerLocataires", () => { if (locatairesCache.length) resumeLocataires(); });
apresChargement("chargerContrats", () => { if (contratsCache.length) resumeContrats(); });
apresChargement("chargerBiens", () => { if (citesCache.length) resumeBiens(); });
apresChargement("chargerProprios", () => { if (propriosCache.length) resumeProprios(); });
CHARGEURS.locataires = window.chargerLocataires;
CHARGEURS.contrats = window.chargerContrats;
CHARGEURS.biens = window.chargerBiens;
CHARGEURS.proprietaires = window.chargerProprios;

// ---------- Clic sur une ligne → sa fiche ----------

document.addEventListener("click", e => {
  const ligne = e.target.closest(".row[data-fiche], tr[data-fiche], .ligne-fiche[data-fiche]");
  if (!ligne || e.target.closest("button, a, input, select, .boutons, .pill")) return;
  const [genre, id] = ligne.dataset.fiche.split(":");
  ouvrirFiche(genre, Number(id));
});
document.addEventListener("keydown", e => {
  if (e.key !== "Enter") return;
  const ligne = e.target.closest && e.target.closest(".row[data-fiche]");
  if (ligne && e.target === ligne) { const [g, id] = ligne.dataset.fiche.split(":"); ouvrirFiche(g, Number(id)); }
});

// genre → fonction qui ouvre la fiche ; les autres écrans y ajoutent les leurs (FICHES.paiement = …)
const FICHES = { locataire: id => ficheLocataire(id), contrat: id => ficheContrat(id), bien: id => ficheBien(id),
                 proprietaire: id => ficheProprietaire(id) };
function ouvrirFiche(genre, id) {
  const f = FICHES[genre];
  if (f) f(id);
}

// Petits morceaux communs des fenêtres
const statFiche = (libelle, valeur, aide = "", classe = "") =>
  `<div class="fiche-stat ${classe}"><small>${libelle}</small><b>${valeur}</b>${aide ? `<span>${aide}</span>` : ""}</div>`;
const pillEtat = (code, texte) => `<span class="pill ${ETATS_IMMO[code]?.pill ?? ""}">${esc(texte || ETATS_IMMO[code]?.texte || code)}</span>`;
function teteFiche(titre, sousTitre) {
  return `<div class="fa-tete"><div><h2>${esc(titre)}</h2><p>${sousTitre || "&nbsp;"}</p></div>
    <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>`;
}
function bandeauFiche(code, etat, grand, aide = "") {
  return `<div class="fa-stock etat-${code}"><span class="fa-etat">${esc(etat)}</span><span class="fa-quantite">${grand}</span>
    ${aide ? `<span class="fa-aide">${aide}</span>` : ""}</div>`;
}
function listePaiements(paiements) {
  if (!paiements.length) return "";
  return `<h4>Derniers paiements</h4><div class="fa-liste">${paiements.map(p => `
    <div class="fa-ligne"><span>${formatDate(p.date)} — ${esc(p.periode || p.motif)} <small>(${esc(p.mode)}${p.numero_recu ? ", reçu " + esc(p.numero_recu) : ""})</small></span>
      <span><b class="${p.statut === "Payé" ? "plus" : "moins"}">${formatMontant(p.montant)}</b>${p.statut !== "Payé" ? ` ${pillEtat("termine", p.statut)}` : ""}</span></div>`).join("")}</div>`;
}
function boutonsFiche(boutons) {
  return `<div class="actions fiche-actions">${boutons.filter(Boolean).join("")}<button class="btn" data-fermer>Fermer</button></div>`;
}
// Brancher les boutons [data-action] d'une fenêtre : la fenêtre se ferme puis l'action s'exécute
function brancherActions(fen, actions) {
  fen.querySelectorAll("[data-action]").forEach(b => b.addEventListener("click", () => {
    const action = actions[b.dataset.action];
    if (!action) return;
    if (!b.hasAttribute("data-garder")) fen.fermer();
    action(b.dataset);
  }));
}
const lienTel = tel => tel ? `<a href="tel:${esc(tel.replace(/\s/g, ""))}">${esc(tel)}</a>` : "";

// ---------- Locataire ----------

async function ficheLocataire(id) {
  let l;
  try { l = await api(`/api/fiches/locataire/${id}`); } catch (e) { toast(e.message); return; }
  const enCours = l.contrats.filter(c => c.etat !== "termine");
  const prochaine = enCours.map(c => c.prochaine_echeance).filter(Boolean)[0];
  const grand = l.etat === "termine" ? "Aucun contrat en cours" : l.total_du ? `${formatMontant(l.total_du)} à payer` : "Rien à payer";
  const aide = l.etat === "a_risque" ? "2 mois impayés ou plus : à relancer d'urgence."
    : l.etat === "retard" ? "Au moins un mois impayé : pensez à le relancer." : l.etat === "depart" ? "Il a annoncé son départ." : "";
  const fen = ouvrirFenetre(`<div class="fiche-article">
    ${teteFiche(l.nom_complet, [l.profession, lienTel(l.telephone), l.cni ? "CNI " + esc(l.cni) : "", l.email].filter(Boolean).map(x => x.startsWith("<a") ? x : esc(x)).join(" · "))}
    ${bandeauFiche(l.etat, ETATS_IMMO[l.etat].texte, grand, aide)}
    <div class="fiche-stats">
      ${statFiche("Loyer par mois", formatMontant(l.loyer_mensuel), enCours.length > 1 ? `${enCours.length} logements` : "")}
      ${statFiche("Reste à payer", formatMontant(l.total_du), l.total_du ? "mois échus" : "à jour", l.total_du ? "negatif" : "positif")}
      ${prochaine ? statFiche("Prochain loyer", formatMontant(prochaine.montant), `${esc(prochaine.mois)}, avant le ${formatDate(prochaine.date_limite)}`) : ""}
      ${l.client_depuis ? statFiche("Locataire depuis", formatDate(l.client_depuis)) : ""}
    </div>
    ${l.contrats.length ? `<h4>Contrats</h4><div class="fa-liste">${l.contrats.map(c => `
      <button class="fa-ligne cliquable" data-action="contrat" data-id="${c.id}"><span><b>${esc(c.logement)}</b> <small>· N° ${esc(c.numero_contrat)} · ${formatMontant(c.montant_loyer)}/mois</small>
        ${c.impayes ? `<br><small>Impayés : ${esc(c.impayes.mois.join(", "))}</small>` : ""}</span>${pillEtat(c.etat, c.etat_texte)}</button>`).join("")}</div>` : ""}
    ${listePaiements(l.paiements)}
    ${l.nb_pieces ? `<p class="petit">📎 ${l.nb_pieces} pièce${l.nb_pieces > 1 ? "s" : ""} jointe${l.nb_pieces > 1 ? "s" : ""} (CNI…) : bouton « Modifier ».</p>` : ""}
    ${boutonsFiche([
      l.telephone ? `<button class="btn" data-action="whatsapp">WhatsApp</button>` : "",
      `<button class="btn" data-action="modifier">Modifier</button>`,
      l.voit_paiements && enCours.length ? `<button class="btn primary" data-action="encaisser">Encaisser un loyer</button>` : "",
    ])}</div>`, { taille: "large" });
  brancherActions(fen, {
    contrat: d => ficheContrat(Number(d.id)),
    whatsapp: () => whatsAppLocataire(l.id),
    modifier: () => modifierLocataire(l.id),
    encaisser: () => encaisserPour(enCours[0].id),
  });
}

// ---------- Contrat ----------

async function ficheContrat(id) {
  let c;
  try { c = await api(`/api/fiches/contrat/${id}`); } catch (e) { toast(e.message); return; }
  const enCours = c.etat !== "termine";
  const grand = !enCours ? esc(c.statut_contrat) : c.impayes ? `${formatMontant(c.impayes.montant)} à payer` : "Loyers à jour";
  const aide = c.impayes ? `Mois impayés : ${esc(c.impayes.mois.join(", "))}${c.impayes.deja_verse ? ` (déjà versé ${formatMontant(c.impayes.deja_verse)})` : ""}`
    : c.date_depart ? `Départ prévu le ${formatDate(c.date_depart)}${c.motif_depart ? " — " + esc(c.motif_depart) : ""}`
    : c.statut_contrat === "Résilié" ? `Résilié le ${formatDate(c.date_resiliation)}${c.motif_resiliation ? " — " + esc(c.motif_resiliation) : ""}` : "";
  const fen = ouvrirFenetre(`<div class="fiche-article">
    ${teteFiche(`${c.locataire.nom_complet}`, `Contrat N° ${esc(c.numero_contrat)} · ${esc(c.type_contrat)} · Logement ${esc(c.logement.numero_logement)}, ${esc(c.logement.cite_nom)}`)}
    ${bandeauFiche(c.etat, c.etat_texte, grand, aide)}
    <div class="fiche-stats">
      ${statFiche("Loyer", formatMontant(c.montant_loyer), `payé en ${esc(c.terme_loyer.toLowerCase())}`)}
      ${c.prochaine_echeance ? statFiche("Prochain loyer", esc(c.prochaine_echeance.mois), `avant le ${formatDate(c.prochaine_echeance.date_limite)}`) : ""}
      ${statFiche("Caution", formatMontant(c.montant_caution), `${c.mois_caution} mois`)}
      ${statFiche("Avance", formatMontant(c.montant_avance), `${c.mois_avance} mois`)}
      ${statFiche("Début", formatDate(c.date_debut), c.date_fin ? `fin le ${formatDate(c.date_fin)}` : "sans date de fin")}
      ${statFiche("Mois réglés", c.nb_mois_payes, "depuis le début du suivi")}
    </div>
    <h4>Locataire</h4>
    <div class="fa-liste"><button class="fa-ligne cliquable" data-action="locataire"><span><b>${esc(c.locataire.nom_complet)}</b>
      ${c.locataire.telephone ? ` <small>· ${esc(c.locataire.telephone)}</small>` : ""}</span><span class="petit">voir sa fiche ›</span></button></div>
    ${listePaiements(c.paiements)}
    ${boutonsFiche([
      `<button class="btn" data-action="pdf">Contrat en PDF</button>`,
      enCours && c.locataire.telephone ? `<button class="btn" data-action="whatsapp">${c.impayes ? "Relancer (WhatsApp)" : "Bienvenue (WhatsApp)"}</button>` : "",
      c.statut_contrat !== "Résilié" ? `<button class="btn" data-action="modifier">Modifier</button>` : "",
      enCours && c.voit_paiements ? `<button class="btn primary" data-action="encaisser">Encaisser</button>` : "",
    ])}</div>`, { taille: "large" });
  brancherActions(fen, {
    locataire: () => ficheLocataire(c.locataire.id),
    pdf: () => ouvrirContratPdf(c.id),
    whatsapp: () => envoyerWhatsApp(c.impayes ? "retard" : "bienvenue", { contrat_id: c.id }),
    modifier: () => modifierContrat(c.id),
    encaisser: () => encaisserPour(c.id),
  });
}

// ---------- Bien ----------

async function ficheBien(id) {
  let b;
  try { b = await api(`/api/fiches/bien/${id}`); } catch (e) { toast(e.message); return; }
  const code = b.impayes ? "retard" : b.libres ? "libre" : "a_jour";
  const sous = [esc(b.adresse), b.proprietaire ? `Propriétaire : ${esc(b.proprietaire.nom_complet)}` : "",
                b.pourcentage_commission != null ? `Commission ${formatNombre(b.pourcentage_commission)} %` : "",
                b.gestionnaires && b.gestionnaires.length ? `Gestionnaire : ${esc(b.gestionnaires.join(", "))}` : ""].filter(Boolean).join(" · ");
  const fen = ouvrirFenetre(`<div class="fiche-article">
    ${teteFiche(b.nom, sous)}
    ${bandeauFiche(code, "Occupation", `${b.occupes} / ${b.nb_logements} logements occupés`,
      `${b.taux_occupation} % · ${b.libres} libre${b.libres > 1 ? "s" : ""}${b.impayes ? ` · ${formatMontant(b.impayes)} de loyers impayés` : ""}`)}
    <div class="fiche-stats">
      ${statFiche("Loyers attendus", formatMontant(b.loyers_attendus), "par mois")}
      ${statFiche("Impayés", formatMontant(b.impayes), b.impayes ? "mois échus" : "rien à relancer", b.impayes ? "negatif" : "positif")}
      ${statFiche("Logements libres", b.libres, b.libres ? "à louer" : "tout est loué")}
      ${b.parcelles.length ? statFiche("Parcelles", b.parcelles.length) : ""}
    </div>
    ${b.logements.length ? `<h4>Logements</h4><div class="fa-tableau"><table><thead><tr><th>Logement</th><th>Locataire</th><th>Loyer</th><th>État</th></tr></thead><tbody>
      ${b.logements.map(l => `<tr class="${l.locataire ? "ligne-cliquable" : ""}" ${l.locataire ? `data-action="locataire" data-id="${l.locataire.id}" data-garder` : ""}>
        <td><b>${esc(l.numero)}</b> <small>${esc(l.type)}</small></td>
        <td>${l.locataire ? esc(l.locataire.nom_complet) : '<span class="petit">—</span>'}</td>
        <td>${formatMontant(l.loyer)}</td>
        <td>${l.locataire ? pillEtat(l.etat, l.etat_texte) : `<span class="pill ${CLASSE_STATUT[l.statut] || ""}">${esc(l.statut)}</span>`}</td></tr>`).join("")}
    </tbody></table></div>` : ""}
    ${b.description ? `<h4>Description</h4><p>${esc(b.description)}</p>` : ""}
    ${boutonsFiche([
      `<button class="btn" data-action="probleme">Déclarer un problème</button>`,
      estAdmin() ? `<button class="btn primary" data-action="modifier">Modifier le bien</button>` : "",
    ])}</div>`, { taille: "large" });
  brancherActions(fen, {
    locataire: d => { fen.fermer(); ficheLocataire(Number(d.id)); },
    probleme: () => declarerProbleme(b.id),
    modifier: () => modifierCite(b.id),
  });
}

// ---------- Propriétaire ----------

async function ficheProprietaire(id) {
  let p;
  try { p = await api(`/api/fiches/proprietaire/${id}`); } catch (e) { toast(e.message); return; }
  const code = p.impayes ? "retard" : "a_jour";
  const fen = ouvrirFenetre(`<div class="fiche-article">
    ${teteFiche(p.nom_complet, [lienTel(p.telephone), p.ville ? esc(p.ville) : "", p.cni ? "CNI " + esc(p.cni) : "", p.email ? esc(p.email) : ""].filter(Boolean).join(" · "))}
    ${bandeauFiche(code, "Ses biens", `${p.biens.length} bien${p.biens.length > 1 ? "s" : ""} · ${p.occupes} / ${p.nb_logements} logements occupés`,
      p.impayes ? `${formatMontant(p.impayes)} de loyers impayés chez ses locataires` : "Aucun loyer impayé chez ses locataires")}
    <div class="fiche-stats">
      ${statFiche("Loyers attendus", formatMontant(p.loyers_attendus), "par mois")}
      ${statFiche("Impayés", formatMontant(p.impayes), "", p.impayes ? "negatif" : "positif")}
      ${statFiche("Logements", p.nb_logements, `${p.occupes} occupé${p.occupes > 1 ? "s" : ""}`)}
    </div>
    ${p.biens.length ? `<h4>Ses biens</h4><div class="fa-liste">${p.biens.map(b => `
      <button class="fa-ligne cliquable" data-action="bien" data-id="${b.id}"><span><b>${esc(b.nom)}</b>
        <small>· ${b.occupes}/${b.nb_logements} occupés${b.nb_parcelles ? ` · ${b.nb_parcelles} parcelle${b.nb_parcelles > 1 ? "s" : ""}` : ""}${
          b.pourcentage_commission != null ? ` · commission ${formatNombre(b.pourcentage_commission)} %` : ""}</small>
        <br><small>${formatMontant(b.loyers_attendus)}/mois${b.impayes ? ` · <b class="moins">${formatMontant(b.impayes)} impayés</b>` : ""}</small></span>
        <span class="petit">voir ›</span></button>`).join("")}</div>` : '<p class="petit">Aucun bien enregistré pour ce propriétaire.</p>'}
    ${p.nb_pieces ? `<p class="petit">📎 ${p.nb_pieces} pièce${p.nb_pieces > 1 ? "s" : ""} jointe${p.nb_pieces > 1 ? "s" : ""} : bouton « Modifier ».</p>` : ""}
    ${boutonsFiche([
      p.telephone ? `<button class="btn" data-action="whatsapp">WhatsApp</button>` : "",
      `<button class="btn primary" data-action="modifier">Modifier</button>`,
    ])}</div>`, { taille: "large" });
  brancherActions(fen, {
    bien: d => ficheBien(Number(d.id)),
    whatsapp: () => ouvrirWhatsAppTexte(p.telephone),
    modifier: () => modifierProprietaire(p.id),
  });
}

// ---------- Fiche d'un paiement (clic sur un encaissement, ici ou dans l'historique) ----------
FICHES.paiement = id => {
  const p = paiementsCache.find(x => x.id === id) || (historiqueCache ? historiqueCache.paiements.find(x => x.id === id) : null);
  if (!p) return;
  const annule = p.statut_paiement === "Annulé";
  const code = annule ? "termine" : p.versement_partiel ? "retard" : "a_jour";
  const etat = annule ? "Annulé" : p.versement_partiel ? "Versement partiel" : "Payé";
  const aide = annule ? `Annulé${p.motif_annulation ? " : " + esc(p.motif_annulation) : ""}`
    : p.versement_partiel ? "Arrangement : le mois n'est réglé qu'une fois soldé." : esc(p.periode || p.motif_paiement);
  const admin = p.commission_entreprise !== undefined;
  const fen = ouvrirFenetre(`<div class="fiche-article">
    ${teteFiche(p.locataire, `${p.repris ? "Repris de l'ancien logiciel" : "Reçu N° " + esc(p.numero_recu)} · ${esc(p.logement)} · contrat N° ${esc(p.numero_contrat)}`)}
    ${bandeauFiche(code, etat, formatMontant(p.montant), aide)}
    <div class="fiche-stats">
      ${statFiche("Date du paiement", formatDate(p.date_paiement), p.date_encaissement ? `saisi le ${esc(p.date_encaissement)}` : "")}
      ${statFiche("Mode", esc(p.mode_paiement))}
      ${statFiche("Motif", esc(p.motif_paiement), p.nb_mois ? `${p.nb_mois} mois` : "")}
      ${p.periode ? statFiche("Période", esc(p.periode)) : ""}
      ${p.encaisse_par ? statFiche("Encaissé par", esc(p.encaisse_par)) : ""}
    </div>
    ${admin ? `<h4>Répartition</h4><div class="fiche-stats">
      ${statFiche("Commission", formatMontant(p.commission_entreprise), `${formatNombre(p.pourcentage_commission ?? 0)} %`)}
      ${statFiche("Reversé au propriétaire", formatMontant(p.montant_reverse))}
      ${p.montant_caution ? statFiche("Caution gardée", formatMontant(p.montant_caution), "jamais de commission") : ""}
      ${p.montant_penalite ? statFiche("Pénalité de retard", formatMontant(p.montant_penalite)) : ""}
    </div>` : ""}
    ${boutonsFiche([
      `<button class="btn" data-action="contrat">Fiche du contrat</button>`,
      !annule && !p.repris ? `<button class="btn" data-action="recu">Reçu (PDF)</button>` : "",
      !annule && p.quittance_possible ? `<button class="btn" data-action="quittance">Quittance (PDF)</button>` : "",
      !annule && !p.repris && p.telephone ? `<button class="btn" data-action="whatsapp">Confirmation WhatsApp</button>` : "",
      estAdmin() && !annule ? `<button class="btn ghost" data-action="annuler">Annuler l'encaissement</button>` : "",
    ])}</div>`, { taille: "large" });
  brancherActions(fen, {
    contrat: () => ficheContrat(p.contrat_id),
    recu: () => ouvrirRecu(p.id),
    quittance: () => ouvrirQuittance(p.id),
    whatsapp: () => envoyerWhatsApp("confirmation", { paiement_id: p.id }),
    annuler: () => annulerEncaissement(p.id),
  });
};

// ---------- Modèle commun : une fiche décrite en quelques lignes ----------
// ficheSimple({ titre, sous, code, etat, grand, aide, stats: [[libellé, valeur, aide, classe]], sections: [{ titre, html }],
//               actions: [{ libelle, fn, principal, discret }] })
function ficheSimple(f) {
  const actions = (f.actions || []).filter(Boolean);
  const fen = ouvrirFenetre(`<div class="fiche-article">
    ${teteFiche(f.titre, f.sous || "")}
    ${f.grand !== undefined ? bandeauFiche(f.code || "a_jour", f.etat || "", f.grand, f.aide || "") : ""}
    ${(f.stats || []).filter(Boolean).length ? `<div class="fiche-stats">${f.stats.filter(Boolean).map(s => statFiche(...s)).join("")}</div>` : ""}
    ${(f.sections || []).filter(s => s && s.html).map(s => `<h4>${esc(s.titre)}</h4>${s.html}`).join("")}
    ${boutonsFiche(actions.map((a, i) => `<button class="btn${a.principal ? " primary" : a.discret ? " ghost" : ""}" data-action="a${i}">${esc(a.libelle)}</button>`))}
  </div>`, { taille: "large" });
  brancherActions(fen, Object.fromEntries(actions.map((a, i) => [`a${i}`, a.fn])));
  return fen;
}
const texteLibre = t => t ? `<p style="white-space:pre-line">${esc(t)}</p>` : "";

// ---------- Dépense ----------
FICHES.depense = id => {
  const d = depensesCache.find(x => x.id === id);
  if (!d) return;
  const charge = d.a_la_charge_de === "Entreprise" ? nomEntreprise() : d.a_la_charge_de;
  ficheSimple({
    titre: d.motif, sous: `${esc(d.bien)}${d.logement ? " · " + esc(d.logement) : ""}${d.adresse ? " · " + esc(d.adresse) : ""}`,
    code: d.a_la_charge_de === "Propriétaire" ? "depart" : "retard", etat: `À la charge : ${charge}`,
    grand: formatMontant(d.montant), aide: d.a_la_charge_de === "Propriétaire" ? "Déduite du reversement au propriétaire." : "Dépense de l'entreprise.",
    stats: [["Date", formatDate(d.date_depense)], ["Catégorie", esc(d.categorie)], ["Mode", esc(d.mode_paiement)],
            d.montant_tva ? ["Dont TVA", formatMontant(d.montant_tva)] : null,
            d.justificatif ? ["Justificatif", esc(d.justificatif)] : null, d.saisi_par ? ["Saisie par", esc(d.saisi_par)] : null],
    actions: [estAdmin() || moi.role === "Caisse" ? { libelle: "Supprimer", discret: true, fn: () => supprimerDepense(d.id) } : null,
              { libelle: "Modifier", principal: true, fn: () => modifierDepense(d.id) }],
  });
};

// ---------- Achat / vente de bien ----------
FICHES.operation = id => {
  const o = operationsCache.find(x => x.id === id);
  if (!o) return;
  const indirecte = o.type_operation === "Vente indirecte";
  ficheSimple({
    titre: o.partie_nom, sous: `N° ${esc(o.numero)}${o.bien ? " · " + esc(o.bien) : ""}${o.parcelle ? " · parcelle " + esc(o.parcelle) : ""}`,
    code: o.type_operation === "Achat" ? "retard" : indirecte ? "depart" : "a_jour", etat: o.type_operation,
    grand: formatMontant(o.montant), aide: esc(o.designation || ""),
    stats: [["Date", formatDate(o.date_operation)], ["Mode", esc(o.mode_paiement)],
            o.partie_telephone ? ["Téléphone", esc(o.partie_telephone)] : null, o.partie_cni ? ["CNI", esc(o.partie_cni)] : null,
            indirecte ? ["Pour le compte de", esc(o.proprietaire_nom)] : null,
            indirecte && o.commission_montant ? ["Commission", formatMontant(o.commission_montant), `payée par ${esc((o.commission_payee_par || "").toLowerCase())}`] : null,
            indirecte ? ["Net propriétaire", formatMontant(o.net_proprietaire)] : null,
            o.saisi_par ? ["Saisie par", esc(o.saisi_par)] : null],
    sections: [{ titre: "Observation", html: texteLibre(o.observation) }],
    actions: [...o.documents.map(doc => ({ libelle: `${doc.type} (PDF)`, fn: () => ouvrirDocumentAV(o.id, doc.code) })),
              estAdmin() ? { libelle: "Supprimer", discret: true, fn: () => supprimerOperation(o.id) } : null],
  });
};

// ---------- Fournisseur (Commerce) ----------
FICHES.fournisseur = async id => {
  const f = fournisseursCache.find(x => x.id === id);
  if (!f) return;
  let arrivages = [];
  try { arrivages = (await api("/api/arrivages")).filter(a => a.fournisseur_id === id && !a.annule); } catch { /* fiche sans arrivages */ }
  const argent = optionsCommerce && optionsCommerce.voit_achats;
  const reste = arrivages.reduce((s, a) => s + (a.reste || 0), 0);
  ficheSimple({
    titre: f.nom, sous: [f.telephone ? lienTel(f.telephone) : "", f.contact ? esc(f.contact) : "", f.adresse ? esc(f.adresse) : ""].filter(Boolean).join(" · "),
    code: !f.actif ? "termine" : reste ? "a_risque" : "a_jour", etat: f.actif ? "Fournisseur actif" : "Inactif",
    grand: argent ? (reste ? `${formatMontant(reste)} à lui payer` : "Rien à lui payer") : `${arrivages.length} arrivage${arrivages.length > 1 ? "s" : ""}`,
    aide: `${f.nb_articles} article${f.nb_articles > 1 ? "s" : ""} achetés chez lui d'habitude`,
    stats: [["Arrivages", arrivages.length], argent ? ["Total acheté", formatMontant(arrivages.reduce((s, a) => s + (a.montant_total || 0), 0))] : null],
    sections: [{ titre: "Derniers arrivages", html: arrivages.length ? `<div class="fa-liste">${arrivages.slice(0, 8).map(a => `
        <div class="fa-ligne"><span>${formatDate(a.date_arrivage)} — ${esc(a.numero)} <small>· ${esc(a.lignes.map(l => `${nombre(l.quantite)} ${l.unite} ${l.article}`).join(", "))}</small></span>
          ${argent ? `<b class="${a.reste ? "moins" : "plus"}">${a.prix_complets ? (a.reste ? "reste " + formatMontant(a.reste) : "payé") : "prix à compléter"}</b>` : ""}</div>`).join("")}</div>` : "" },
               { titre: "Note", html: texteLibre(f.note) }],
    actions: [f.telephone ? { libelle: "WhatsApp", fn: () => ouvrirWhatsAppTexte(f.telephone) } : null,
              optionsCommerce && optionsCommerce.supprime ? { libelle: "Supprimer", discret: true, fn: () => supprimerFournisseur(f.id) } : null,
              { libelle: "Modifier", principal: true, fn: () => modifierFournisseur(f.id) }],
  });
};

// ---------- Trésorerie ----------
FICHES.compte = id => {
  const c = (tresorerieCache ? tresorerieCache.comptes : []).find(x => x.id === id);
  if (!c) return;
  ficheSimple({
    titre: c.nom, sous: `${esc(c.type_compte)}${c.numero ? " · " + esc(c.numero) : ""}`,
    code: !c.actif ? "termine" : c.solde < 0 ? "a_risque" : "a_jour", etat: c.actif ? "Solde actuel" : "Compte fermé",
    grand: formatMontant(c.solde), aide: c.solde < 0 ? "Solde négatif : vérifiez les opérations ou faites un arrêté." : "",
    stats: [["Suivi depuis", formatDate(c.date_ouverture)],
            c.solde_initial !== undefined ? ["Solde de départ", formatMontant(c.solde_initial)] : null,
            ["Reçoit d'office", c.modes_paiement.length ? c.modes_paiement.map(esc).join(", ") : "rien (choix à la main)"],
            c.dernier_arrete ? ["Dernier arrêté", formatDate(c.dernier_arrete.date), `écart ${formatMontant(c.dernier_arrete.ecart)}`,
                                c.dernier_arrete.ecart ? "negatif" : "positif"] : ["Dernier arrêté", "aucun"]],
    actions: [{ libelle: "Voir ses mouvements", fn: () => voirJournalCompte(c.id) },
              c.actif ? { libelle: "Faire un arrêté de caisse", fn: () => nouvelArrete() } : null,
              estAdmin() ? { libelle: "Modifier", principal: true, fn: () => { montrerOngletTresorerie("trComptes"); modifierCompteTresorerie(c.id); } } : null],
  });
};

FICHES.mouvement = i => {
  const l = journalTresorerieCache && journalTresorerieCache.lignes[i];
  if (!l) return;
  const entree = l.sens === "entree";
  ficheSimple({
    titre: l.libelle, sous: `${formatDate(l.date)}${l.compte ? " · " + esc(l.compte) : ""}${l.reference ? " · " + esc(l.reference) : ""}`,
    code: entree ? "a_jour" : "a_risque", etat: entree ? "Entrée d'argent" : "Sortie d'argent",
    grand: `${entree ? "+" : "−"} ${formatMontant(l.montant)}`, aide: l.origine ? `Origine : ${esc(l.origine)}` : "",
    stats: [["Date", formatDate(l.date)], l.compte ? ["Compte", esc(l.compte)] : null,
            l.solde !== undefined && l.solde !== null ? ["Solde après", formatMontant(l.solde)] : null,
            l.reference ? ["Référence", esc(l.reference)] : null],
  });
};

FICHES.transfert = id => {
  const t = transfertsCache.find(x => x.id === id);
  if (!t) return;
  ficheSimple({
    titre: `${t.source} → ${t.cible}`, sous: `${esc(t.numero)}${t.saisi_par ? " · saisi par " + esc(t.saisi_par) : ""}`,
    code: "depart", etat: "Transfert entre comptes", grand: formatMontant(t.montant),
    aide: t.libelle ? esc(t.libelle) : "L'argent change de compte : ce n'est ni une entrée ni une dépense.",
    stats: [["Date", formatDate(t.date)], ["Depuis", esc(t.source)], ["Vers", esc(t.cible)],
            t.frais ? ["Frais", formatMontant(t.frais), "payés par le compte de départ", "negatif"] : null,
            t.reference ? ["Référence", esc(t.reference)] : null],
    actions: [estAdmin() ? { libelle: "Supprimer", discret: true, fn: () => supprimerTransfert(t.id, t.numero) } : null],
  });
};

FICHES.arrete = id => {
  const a = arretesCache.find(x => x.id === id);
  if (!a) return;
  ficheSimple({
    titre: `Arrêté de caisse — ${a.compte}`, sous: `Journée du ${formatDate(a.date)} · par ${esc(a.saisi_par)}`,
    code: a.ecart === 0 ? "a_jour" : "a_risque", etat: a.ecart === 0 ? "Caisse juste" : a.ecart > 0 ? "Surplus" : "Manquant",
    grand: a.ecart === 0 ? "Aucun écart" : `${a.ecart > 0 ? "+" : ""}${formatMontant(a.ecart)}`,
    aide: a.modifie_depuis ? `Une opération a changé depuis : solde recalculé ${formatMontant(a.solde_recalcule)}.` : esc(a.observation || ""),
    stats: [["Solde calculé", formatMontant(a.solde_calcule), "par Gérimo"], ["Argent compté", formatMontant(a.solde_compte)],
            ["Écart", `${a.ecart > 0 ? "+" : ""}${formatMontant(a.ecart)}`, "", a.ecart ? "negatif" : "positif"]],
    sections: [{ titre: "Observation", html: a.modifie_depuis ? texteLibre(a.observation) : "" }],
    actions: [estAdmin() ? { libelle: "Supprimer", discret: true, fn: () => supprimerArrete(a.id) } : null],
  });
};

FICHES.aproprio = id => {
  const p = reversementsCache && reversementsCache.proprietaires.find(x => x.id === id);
  if (!p) return;
  ficheSimple({
    titre: p.nom, sous: p.biens.map(b => esc(b.bien)).join(", "),
    code: p.reste > 0 ? "retard" : "a_jour", etat: "À lui reverser", grand: formatMontant(p.reste),
    aide: "Loyers nets encaissés pour lui, moins ses dépenses et ce qui lui a déjà été versé.",
    stats: [["Loyers nets", formatMontant(p.loyers_nets), "après commission"],
            p.depenses ? ["Dépenses à sa charge", formatMontant(p.depenses), "", "negatif"] : null,
            ["Déjà versé", formatMontant(p.verse)], ["Reste", formatMontant(p.reste), "", p.reste > 0 ? "negatif" : "positif"]],
    actions: [estAdmin() ? { libelle: "Fiche du propriétaire", fn: () => ficheProprietaire(p.id) } : null,
              p.reste > 0 ? { libelle: "Verser", principal: true, fn: () => verserProprietaire(p.id) } : null],
  });
};

FICHES.avendeur = id => {
  const v = reversementsCache && reversementsCache.vendeurs_a_payer.find(x => x.id === id);
  if (!v) return;
  ficheSimple({
    titre: v.vendeur, sous: `Vente ${esc(v.numero)} du ${formatDate(v.date)} à ${esc(v.acheteur)}`,
    code: "retard", etat: "À lui verser", grand: formatMontant(v.reste), aide: esc(v.designation || ""),
    stats: [["Net vendeur", formatMontant(v.net), "prix moins commission"], ["Déjà versé", formatMontant(v.verse || 0)]],
    actions: [{ libelle: "Verser", principal: true, fn: () => verserVendeur(v.id) }],
  });
};

FICHES.caution = contratId => {
  const c = reversementsCache && reversementsCache.cautions_detail.find(x => x.contrat_id === contratId);
  if (!c) return;
  ficheSimple({
    titre: c.locataire, sous: `Contrat ${esc(c.numero_contrat)} (${esc(c.statut)}) · ${esc(c.logement)}`,
    code: c.a_rendre ? "retard" : "depart", etat: c.a_rendre ? "Contrat terminé : caution à rendre" : "Caution détenue",
    grand: formatMontant(c.reste), aide: c.retenue_edl ? `Retenue prévue à l'état des lieux de sortie : ${formatMontant(c.retenue_edl)}.` : "Dépôt de garantie : jamais de commission.",
    stats: [c.telephone ? ["Téléphone", esc(c.telephone)] : null],
    actions: [peut("contrats") ? { libelle: "Fiche du contrat", fn: () => ficheContrat(c.contrat_id) } : null,
              { libelle: "Rendre la caution", principal: c.a_rendre, fn: () => rendreCaution(c.contrat_id) }],
  });
};

FICHES.reversement = id => {
  const r = reversementsFaits.find(x => x.id === id);
  if (!r) return;
  const quoi = r.type === "Loyers" ? "Reversement des loyers" : r.type === "Caution" ? "Restitution de caution" : "Versement au vendeur";
  ficheSimple({
    titre: r.beneficiaire, sous: `${esc(r.numero)} · ${formatDate(r.date)}${r.saisi_par ? " · saisi par " + esc(r.saisi_par) : ""}`,
    code: "a_jour", etat: quoi, grand: formatMontant(r.montant),
    aide: r.type === "Caution" ? `Caution du contrat ${esc(r.contrat || "")}${r.retenue ? ` — retenue ${formatMontant(r.retenue)}` : ""}`
      : r.type === "Vente" ? `Vente ${esc(r.vente || "")}` : "",
    stats: [["Mode", esc(r.mode_paiement)], ["Depuis le compte", esc(r.compte)], r.reference ? ["Référence", esc(r.reference)] : null,
            ["Reste dû après", formatMontant(r.reste_apres)]],
    actions: [{ libelle: "Bordereau (PDF)", fn: () => window.open(`/api/reversements/${r.id}/bordereau`, "_blank") },
              r.mode_paiement === "Virement" && r.rib ? { libelle: "Ordre de virement (PDF)", fn: () => ouvrirOrdreVirement(r.id) } : null,
              estAdmin() ? { libelle: "Supprimer", discret: true, fn: () => supprimerReversement(r.id, r.numero) } : null],
  });
};

FICHES.beneficiaire = id => {
  const b = beneficiairesCache.find(x => x.id === id);
  if (!b) return;
  ficheSimple({
    titre: b.nom, sous: `${esc(b.categorie)}${b.proprietaire && b.proprietaire !== b.nom ? " · " + esc(b.proprietaire) : ""}`,
    code: b.actif ? "a_jour" : "termine", etat: b.actif ? "Coordonnées de paiement" : "Inactif",
    grand: b.mobile_money && !b.rib && !b.iban_lisible ? esc(b.mobile_money) : esc(b.banque_nom || "Mobile Money"),
    stats: [b.rib ? ["RIB", esc(b.rib)] : null, b.iban_lisible ? ["IBAN", esc(b.iban_lisible)] : null, b.bic ? ["BIC", esc(b.bic)] : null,
            b.mobile_money ? ["Mobile Money", esc(b.mobile_money)] : null],
    actions: [{ libelle: "Modifier", principal: true, fn: () => modifierBeneficiaire(b.id) }],
  });
};

// ---------- Courte durée (séjours) ----------
FICHES.sejour = id => {
  const s = sejoursCache.find(x => x.id === id);
  if (!s) return;
  const actif = s.statut === "Confirmée" || s.statut === "Arrivé";
  const reste = s.reste > 0 && s.statut !== "Annulée";
  const etat = s.statut === "Arrivé" ? "Client présent" : s.statut;
  ficheSimple({
    titre: s.client_nom, sous: `N° ${esc(s.numero)} · ${esc(s.logement)}${s.client_telephone ? " · " + lienTel(s.client_telephone) : ""}`,
    code: s.statut === "Annulée" ? "termine" : reste ? "retard" : s.statut === "Arrivé" ? "a_jour" : "depart", etat,
    grand: reste ? `${formatMontant(s.reste)} à encaisser` : formatMontant(s.montant_total),
    aide: `Du ${formatDate(s.date_arrivee)} au ${formatDate(s.date_depart)} · ${s.nb_nuits} nuit${s.nb_nuits > 1 ? "s" : ""} · ${s.nb_personnes} pers.`,
    stats: [["Total du séjour", formatMontant(s.montant_total)], ["Déjà versé", formatMontant(s.verse)],
            ["Reste", formatMontant(s.reste), "", reste ? "negatif" : "positif"], s.client_piece ? ["Pièce d'identité", esc(s.client_piece)] : null],
    sections: [{ titre: "Versements", html: s.paiements.length ? `<div class="fa-liste">${s.paiements.map(p => `
        <button class="fa-ligne cliquable" onclick="ouvrirRecuSejour(${p.id})"><span>${esc(p.numero_recu)} <small>· ${esc(p.date_paiement ? formatDate(p.date_paiement) : "")} ${esc(p.mode_paiement || "")}</small></span>
          <b class="${p.statut === "Payé" ? "plus" : "moins"}">${formatMontant(p.montant)}${p.statut !== "Payé" ? " (" + esc(p.statut) + ")" : ""}</b></button>`).join("")}</div>` : "" },
               { titre: "Notes", html: texteLibre(s.notes) },
               { titre: "Annulation", html: texteLibre(s.motif_annulation) }],
    actions: [actif ? { libelle: "WhatsApp", fn: () => whatsappSejour(s.id) } : null,
              s.statut === "Confirmée" && s.date_arrivee <= aujourdhui() ? { libelle: "Client arrivé", fn: () => statutSejour(s.id, "Arrivé") } : null,
              s.statut === "Arrivé" ? { libelle: "Client parti", fn: () => statutSejour(s.id, "Parti") } : null,
              actif ? { libelle: "Annuler la réservation", discret: true, fn: () => annulerSejour(s.id) } : null,
              actif ? { libelle: "Modifier", fn: () => modifierSejour(s.id) } : null,
              reste ? { libelle: "Encaisser", principal: true, fn: () => encaisserSejour(s.id) } : null],
  });
};

// ---------- Agenda et demandes de clients ----------
FICHES.prospect = id => ouvrirProspect(id);   // la fiche du client existe déjà (suivi, logements qui correspondent)

FICHES.evenement = id => {
  const e = agendaCache.evenements.find(x => x.id === id) || agendaComplet.find(x => x.id === id);
  if (!e) return;
  const passe = !e.fait && e.date_evenement < aujourdhui();
  ficheSimple({
    titre: e.titre, sous: `${esc(e.type_evenement)}${e.pour_tous ? " · pour toute l'équipe" : ""}`,
    code: e.fait ? "a_jour" : passe ? "a_risque" : "depart", etat: e.fait ? "Fait" : passe ? "En retard" : "À faire",
    grand: `${esc(jourLong(e.date_evenement))}${e.heure ? " à " + esc(e.heure) : ""}`, aide: e.lieu ? esc(e.lieu) : "",
    stats: [e.telephone ? ["Téléphone", lienTel(e.telephone)] : null, e.prospect ? ["Client", esc(e.prospect)] : null,
            e.rappel_minutes ? ["Rappel", e.rappel_minutes >= 1440 ? "la veille" : `${e.rappel_minutes} min avant`] : null],
    sections: [{ titre: "Notes", html: texteLibre(e.notes) }],
    actions: [e.telephone ? { libelle: "WhatsApp", fn: () => ouvrirWhatsAppTexte(e.telephone) } : null,
              { libelle: e.fait ? "Remettre à faire" : "Marquer comme fait", fn: () => basculerEvenement(e.id) },
              { libelle: "Modifier", principal: true, fn: () => modifierEvenement(e.id) }],
  });
};

// ---------- Courriers ----------
FICHES.courrier = id => {
  const k = courriersCache.find(x => x.id === id);
  if (!k) return;
  const dernier = k.envois.at(-1);
  ficheSimple({
    titre: k.type_courrier, sous: `N° ${esc(k.numero)} · ${esc(k.locataire)} · ${esc(k.logement)}`,
    code: dernier ? "a_jour" : "retard", etat: dernier ? `Envoyé (${dernier.canal}) le ${dernier.date}` : "À envoyer au locataire",
    grand: esc(k.objet || k.type_courrier), aide: `Du ${formatDate(k.date_courrier)}${k.date_effet ? ` · effet le ${formatDate(k.date_effet)}` : ""}`,
    stats: [["Contrat", esc(k.numero_contrat)], k.telephone ? ["Téléphone", esc(k.telephone)] : null, ["Envois", k.envois.length]],
    actions: [{ libelle: "Voir / imprimer (PDF)", fn: () => window.open(`/api/courriers/${k.id}/pdf`, "_blank") },
              estAdmin() && k.type_courrier !== "Révision de loyer" ? { libelle: "Supprimer", discret: true, fn: () => supprimerCourrier(k.id) } : null,
              { libelle: "Envoyer au locataire", principal: !dernier, fn: () => envoyerCourrier(k.id) }],
  });
};

// ---------- États des lieux ----------
FICHES.edl = id => {
  const e = edlCache.etats.find(x => x.id === id);
  if (!e) return;
  const signe = e.statut === "Signé";
  ficheSimple({
    titre: `État des lieux de ${e.type_edl.toLowerCase()}`, sous: `N° ${esc(e.numero)} · ${esc(e.locataire)} · ${esc(e.logement)}`,
    code: signe ? "a_jour" : "retard", etat: e.statut, grand: formatDate(e.date_edl),
    aide: signe ? (e.envoye_le ? `Signé le ${esc(e.signe_le)} · envoyé au locataire le ${esc(e.envoye_le)}` : `Signé le ${esc(e.signe_le)} · pas encore envoyé au locataire`)
      : "Pas encore signé : continuez-le puis faites signer.",
    stats: [["Photos", e.nb_photos], ["Type", esc(e.type_edl)]],
    actions: [{ libelle: signe ? "PDF signé" : "Aperçu PDF", fn: () => window.open(`/api/etats-des-lieux/${e.id}/pdf`, "_blank") },
              signe ? { libelle: "Envoyer au locataire", fn: () => envoyerEdl(e.id) } : null,
              estAdmin() ? { libelle: "Supprimer", discret: true, fn: () => supprimerEdl(e.id) } : null,
              { libelle: signe ? "Ouvrir" : "Continuer / faire signer", principal: true, fn: () => ouvrirEdl(e.id) }],
  });
};

// ---------- Problèmes signalés ----------
FICHES.probleme = id => {
  const s = signalementsCache.find(x => x.id === id);
  if (!s) return;
  const resolu = s.statut === "Résolu";
  ficheSimple({
    titre: s.categorie, sous: `${esc(s.cite)}${s.logement ? ", logement " + esc(s.logement) : ""}`,
    code: resolu ? "a_jour" : s.urgence === "Urgente" ? "a_risque" : "retard", etat: `${s.statut} · urgence ${s.urgence.toLowerCase()}`,
    grand: resolu ? "Résolu" : s.statut === "En cours" ? "Intervention en cours" : "À traiter", aide: esc(s.description),
    stats: [["Signalé le", esc(s.date)], s.signale_par ? ["Par", esc(s.signale_par)] : null, ["Saisi par", esc(s.auteur)],
            s.resolu_le ? ["Résolu le", esc(s.resolu_le)] : null],
    sections: [{ titre: "Photo", html: s.photo ? `<img src="${esc(s.photo)}" alt="Photo du problème" style="max-width:100%;border-radius:12px;cursor:zoom-in" onclick="visionneuse('${esc(s.photo)}', 'Photo du problème')">` : "" },
               { titre: "Résolution", html: texteLibre(s.resolution) }],
    actions: [!resolu && peut("depenses") ? { libelle: "Dépense de réparation", fn: () => depenseProbleme(s.id) } : null,
              s.statut === "Ouvert" ? { libelle: "Intervention lancée", fn: () => statutProbleme(s.id, "En cours") } : null,
              !resolu ? { libelle: "Marquer comme résolu", principal: true, fn: () => statutProbleme(s.id, "Résolu") } : null],
  });
};

// ---------- Paramètres : comptes, journal, corbeille, sauvegardes ----------
FICHES.utilisateur = id => {
  const u = comptes && comptes.utilisateurs.find(x => x.id === id);
  if (!u) return;
  ficheSimple({
    titre: u.nom_complet, sous: `Identifiant ${esc(u.identifiant)}${u.id === comptes.moi ? " · c'est vous" : ""}`,
    code: !u.actif ? "termine" : u.mdp_provisoire_expire_deja ? "a_risque" : u.mdp_provisoire ? "retard" : "a_jour",
    etat: !u.actif ? "Compte désactivé" : u.mdp_provisoire_expire_deja ? "Mot de passe provisoire expiré" : u.mdp_provisoire ? "Mot de passe provisoire" : "Compte actif",
    grand: esc(u.role), aide: AIDE_ROLES[u.role] || "",
    stats: [["Fonction", esc(u.fonction_affichee || "—")], ["Créé le", esc(u.cree_le)],
            ["Dernière connexion", u.derniere_connexion ? esc(u.derniere_connexion) : "jamais"],
            u.cites.length ? ["Biens confiés", esc(u.cites.map(c => c.nom).join(", "))] : null],
    actions: [{ libelle: "Nouveau mot de passe", fn: () => redonnerMotDePasse(u.id) },
              { libelle: "Modifier", principal: true, fn: () => modifierUtilisateur(u.id) }],
  });
};

FICHES.journal = i => {
  const e = journalCache[i];
  if (!e) return;
  ficheSimple({
    titre: e.quoi, sous: `${esc(e.quand)} · par ${esc(e.qui)}`,
    code: e.code === "DELETE" || e.code === "ECHEC" ? "a_risque" : e.code === "UPDATE" ? "retard" : "a_jour",
    etat: e.operation, grand: esc(e.operation),
    sections: [{ titre: "Ce qui a changé", html: e.changements.length ? `<div class="fa-tableau"><table><thead><tr><th>Champ</th><th>Avant</th><th>Après</th></tr></thead><tbody>
      ${e.changements.map(c => `<tr><td><b>${esc(c.champ)}</b></td><td>${c.avant ? `<s>${esc(c.avant)}</s>` : "—"}</td><td>${esc(c.apres || "—")}</td></tr>`).join("")}</tbody></table></div>` : "" }],
  });
};

FICHES.corbeille = i => {
  const x = corbeilleCache[i];
  if (!x) return;
  ficheSimple({
    titre: x.quoi, sous: `Supprimé le ${esc(x.quand)} par ${esc(x.qui)}`, code: "termine", etat: "Dans la corbeille",
    grand: "Récupérable", aide: "La restauration remet l'élément exactement comme avant, avec ses fichiers.",
    sections: [{ titre: "Revient avec lui", html: x.nb_avec ? `<p>${esc(x.avec.join(", "))}${x.nb_avec > x.avec.length ? "…" : ""}</p>` : "" }],
    actions: [{ libelle: "Restaurer", principal: true, fn: () => restaurerCorbeille(x.transaction, x.quoi) }],
  });
};

FICHES.sauvegarde = i => {
  const x = sauvegardesCache && sauvegardesCache.sauvegardes[i];
  if (!x) return;
  ficheSimple({
    titre: `Sauvegarde du ${x.date}`, sous: esc(x.type), code: x.hors_du_pc ? "a_jour" : "retard",
    etat: x.hors_du_pc ? "Copiée hors du PC" : "Seulement sur ce PC", grand: `${x.taille_mo} Mo`,
    aide: x.hors_du_pc ? "Une copie existe ailleurs (clé, PC de secours) : vos données sont à l'abri." : "Pensez à la copier sur une clé USB ou un PC de secours.",
    stats: [["Fichier", esc(x.fichier)]],
    actions: [{ libelle: "Télécharger", fn: () => telechargerSauvegarde(x.fichier) },
              { libelle: "Restaurer", discret: true, fn: () => restaurerSauvegarde(x.fichier, x.date) }],
  });
};
