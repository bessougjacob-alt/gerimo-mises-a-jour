// Location courte durée / meublée : réservations à la nuit, calendrier, acomptes et soldes.
// Le serveur (sejours.py) revérifie tout : chevauchements, droits, montants.

let sejoursCache = [];
let optionsSejours = null;
let sejourEnCours = null;
let moisSejours = (() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1); })();

const MOIS_LONGS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
const isoJour = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const PASTILLE_SEJOUR = { "Confirmée": "warn", "Arrivé": "ok", "Parti": "info", "Annulée": "danger" };

async function chargerSejours() {
  el("btnLogementsNuit").style.display = moi.role === "Caisse" ? "none" : "";
  await Promise.all([chargerCalendrierSejours(), chargerListeSejours()]);
}
CHARGEURS.sejours = chargerSejours;

// ---------- Calendrier ----------

function changerMoisSejours(pas) {
  moisSejours = new Date(moisSejours.getFullYear(), moisSejours.getMonth() + pas, 1);
  chargerCalendrierSejours();
}

async function chargerCalendrierSejours() {
  el("calSejoursTitre").textContent = `${MOIS_LONGS[moisSejours.getMonth()]} ${moisSejours.getFullYear()}`;
  const zone = el("calSejours");
  let c;
  try { c = await api(`/api/sejours/calendrier?mois=${isoJour(moisSejours).slice(0, 7)}`); }
  catch (e) { zone.innerHTML = `<div class="vide">${esc(e.message)}</div>`; return; }
  if (!c.logements.length) {
    zone.innerHTML = `<div class="vide">Aucun logement proposé à la nuit.${moi.role !== "Caisse"
      ? " Cliquez sur « Logements à la nuit » pour en choisir et fixer leur prix." : ""}</div>`;
    return;
  }
  const jours = Array.from({ length: c.nb_jours }, (_, i) => new Date(moisSejours.getFullYear(), moisSejours.getMonth(), i + 1));
  const auj = aujourdhui();
  const tete = `<tr><th class="cal-nom">Logement</th>${jours.map(j =>
    `<th class="cal-jour${isoJour(j) === auj ? " cal-aujourdhui" : ""}">${j.getDate()}</th>`).join("")}</tr>`;
  const lignes = c.logements.map(l => {
    const sejours = c.sejours.filter(s => s.logement_id === l.id);
    const cases = jours.map(j => {
      const iso = isoJour(j);
      // une nuit est occupée du jour d'arrivée (inclus) au jour de départ (exclu)
      const s = sejours.find(x => x.arrivee <= iso && iso < x.depart);
      if (!s) return "<td></td>";
      const classe = { "Confirmée": "cal-confirmee", "Arrivé": "cal-arrive", "Parti": "cal-parti" }[s.statut] || "";
      return `<td class="cal-pris ${classe}" data-tip="${esc(s.client)} — du ${formatDate(s.arrivee)} au ${formatDate(s.depart)}" onclick="voirSejour(${s.id})"></td>`;
    }).join("");
    return `<tr><th class="cal-nom" data-tip="${formatMontant(l.prix_nuit)} la nuit">${esc(l.libelle)}</th>${cases}</tr>`;
  }).join("");
  zone.innerHTML = `<table>${tete}${lignes}</table>`;
}

// ---------- Liste des séjours ----------

async function chargerListeSejours() {
  const zone = el("listeSejours");
  try { sejoursCache = await api("/api/sejours"); }
  catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  if (!sejoursCache.length) {
    zone.innerHTML = '<div class="card vide">Aucun séjour récent ou à venir. Cliquez sur « + Nouvelle réservation ».</div>';
    return;
  }
  const ligne = s => {
    const actif = s.statut === "Confirmée" || s.statut === "Arrivé";
    const reste = s.reste > 0 && s.statut !== "Annulée";
    return `<div class="row row-fiche etat-${s.statut === "Annulée" || s.statut === "Parti" ? (reste ? "retard" : "termine") : reste ? "retard" : s.statut === "Arrivé" ? "a_jour" : "depart"}" data-fiche="sejour:${s.id}" tabindex="0" id="sejour-${s.id}"${motsCles({ tel: [s.client_telephone], textes: [s.numero, s.client_piece] })}>
      <span class="who"><b>${esc(s.client_nom)}</b> — ${esc(s.logement)} — du ${formatDate(s.date_arrivee)} au ${formatDate(s.date_depart)}
        (${s.nb_nuits} nuit${s.nb_nuits > 1 ? "s" : ""}) — ${formatMontant(s.montant_total)}
        <br><span class="petit">N° ${esc(s.numero)} — ${s.nb_personnes} pers. — versé ${formatMontant(s.verse)}${reste ? ` — <b>reste ${formatMontant(s.reste)}</b>` : ""}
        ${s.paiements.filter(p => p.statut === "Payé").map(p => ` — <a href="#" onclick="ouvrirRecuSejour(${p.id});return false">${esc(p.numero_recu)}</a>`).join("")}
        ${s.notes ? " — " + esc(s.notes) : ""}${s.motif_annulation ? " — Annulé : " + esc(s.motif_annulation) : ""}</span></span>
      <span class="boutons">
        <span class="pill ${PASTILLE_SEJOUR[s.statut]}">${s.statut === "Arrivé" ? "Client présent" : esc(s.statut)}</span>
        ${reste ? `<button class="btn-sm" onclick="encaisserSejour(${s.id})" data-tip="Acompte ou solde">Encaisser</button>` : ""}
        ${s.statut === "Confirmée" && s.date_arrivee <= aujourdhui() ? `<button class="btn-sm" onclick="statutSejour(${s.id}, 'Arrivé')">Arrivé</button>` : ""}
        ${s.statut === "Arrivé" ? `<button class="btn-sm" onclick="statutSejour(${s.id}, 'Parti')">Parti</button>` : ""}
        ${actif ? ibtn("whatsapp", "Confirmation du séjour par WhatsApp", `whatsappSejour(${s.id})`) : ""}
        ${actif ? ibtn("modifier", "Modifier la réservation", `modifierSejour(${s.id})`) : ""}
        ${actif ? `<button class="btn-sm del" onclick="annulerSejour(${s.id})">Annuler</button>` : ""}
        ${estAdmin() && s.paiements.some(p => p.statut === "Payé") ? `<button class="btn-sm" onclick="annulerVersementSejour(${s.id})" data-tip="Annuler un versement (Admin)">Versements</button>` : ""}
      </span></div>`;
  };
  const auj = aujourdhui();
  const enCours = sejoursCache.filter(s => s.statut === "Arrivé");
  const aVenir = sejoursCache.filter(s => s.statut === "Confirmée");
  const passes = sejoursCache.filter(s => s.statut === "Parti" || s.statut === "Annulée").reverse();
  const carte = (titre, liste, vide) => `<div class="card"><h3>${titre}</h3>${liste.map(ligne).join("") || `<div class="vide">${vide}</div>`}</div>`;
  const totalReste = sejoursCache.filter(s => s.statut !== "Annulée").reduce((t, s) => t + s.reste, 0);
  zone.innerHTML = `<div class="kpis">
      <div class="kpi ok"><div class="label">Clients présents</div><div class="value">${enCours.length}</div></div>
      <div class="kpi info"><div class="label">Arrivées à venir</div><div class="value">${aVenir.length}</div>
        <div class="sous-valeur">dont aujourd'hui : ${aVenir.filter(s => s.date_arrivee === auj).length}</div></div>
      <div class="kpi warn"><div class="label">Reste à encaisser</div><div class="value">${formatMontant(totalReste)}</div></div>
    </div>
    ${carte("Clients présents", enCours, "Aucun client en ce moment.")}
    ${carte("Réservations à venir", aVenir, "Aucune réservation à venir.")}
    ${passes.length ? carte("Séjours terminés ou annulés (30 derniers jours)", passes, "") : ""}`;
  el("rechercheSejours").dispatchEvent(new Event("input"));
}

function voirSejour(id) {
  const ligne = el(`sejour-${id}`);
  if (!ligne) { toast("Séjour hors de la liste (plus de 30 jours)"); return; }
  ligne.scrollIntoView({ behavior: "smooth", block: "center" });
  ligne.style.background = "var(--orange-soft)";
  setTimeout(() => { ligne.style.background = ""; }, 2000);
}

// ---------- Formulaire de réservation ----------

function logementSejourChoisi() {
  return optionsSejours?.logements.find(l => String(l.id) === el("sejLogement").value) || null;
}

function majRecapSejour() {
  const zone = el("sejRecap");
  let arrivee, depart;
  try { arrivee = valeurDate("sejArrivee", "Arrivée"); depart = valeurDate("sejDepart", "Départ"); } catch { arrivee = depart = null; }
  const prix = lireMontant(el("sejPrix").value) || 0;
  const remise = lireMontant(el("sejRemise").value) || 0;
  if (!arrivee || !depart) { zone.innerHTML = "Indiquez les dates d'arrivée et de départ."; return; }
  const nuits = Math.round((new Date(depart) - new Date(arrivee)) / 86400000);
  if (nuits < 1) { zone.innerHTML = "Le départ doit être au moins le lendemain de l'arrivée."; return; }
  zone.innerHTML = `<b>${nuits} nuit${nuits > 1 ? "s" : ""}</b> × ${formatMontant(prix)}${remise ? ` − remise ${formatMontant(remise)}` : ""}
    = <b>${formatMontant(nuits * prix - remise)}</b>`;
}
["input", "change"].forEach(t => el("formulaireSejour").addEventListener(t, majRecapSejour));
el("sejLogement").addEventListener("change", () => {
  const l = logementSejourChoisi();
  if (l && l.prix_nuit) el("sejPrix").value = formatNombre(l.prix_nuit);
  majRecapSejour();
});
["sejPrix", "sejRemise"].forEach(id => el(id).addEventListener("blur", () => {
  const n = lireMontant(el(id).value);
  if (n !== null) el(id).value = formatNombre(n);
}));

async function preparerFormSejour(s) {
  optionsSejours = await api("/api/sejours/options");
  const proposes = optionsSejours.logements.filter(l => l.prix_nuit !== null);
  remplirSelect(el("sejLogement"), proposes, {
    valeur: l => l.id, texte: l => `${l.libelle} — ${formatMontant(l.prix_nuit)} la nuit`,
    vide: proposes.length ? "— Choisir —" : "Aucun logement à la nuit (bouton « Logements à la nuit »)",
  });
  sejourEnCours = s ? s.id : null;
  el("titreSejour").textContent = s ? `Modifier la réservation N° ${s.numero}` : "Nouvelle réservation";
  el("sejLogement").value = s ? s.logement_id : (proposes.length === 1 ? proposes[0].id : "");
  el("sejClient").value = s ? s.client_nom : "";
  el("sejTelephone").value = s ? s.client_telephone : "";
  el("sejPiece").value = s ? s.client_piece : "";
  el("sejPersonnes").value = s ? s.nb_personnes : 1;
  const demain = new Date(); demain.setDate(demain.getDate() + 1);
  fixerDate("sejArrivee", s ? s.date_arrivee : aujourdhui());
  fixerDate("sejDepart", s ? s.date_depart : isoJour(demain));
  const l = logementSejourChoisi();
  el("sejPrix").value = s ? formatNombre(s.prix_nuit) : (l ? formatNombre(l.prix_nuit) : "");
  el("sejRemise").value = s && s.remise ? formatNombre(s.remise) : "";
  el("sejNotes").value = s ? s.notes : "";
  reinitialiserSaisie(el("formulaireSejour"));
  erreurFormulaire(el("formulaireSejour"), "");
  majRecapSejour();
}

async function nouveauSejour() {
  await preparerFormSejour(null);
  afficher("formSejour");
}

async function modifierSejour(id) {
  const s = sejoursCache.find(x => x.id === id);
  if (!s) return;
  await preparerFormSejour(s);
  afficher("formSejour");
}

el("formulaireSejour").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (!el("sejLogement").value) throw new Error("Choisissez le logement.");
    if (!el("sejClient").value.trim()) throw new Error("Indiquez le nom du client.");
    const arrivee = valeurDate("sejArrivee", "Arrivée"), depart = valeurDate("sejDepart", "Départ");
    if (!arrivee || !depart) throw new Error("Indiquez les dates d'arrivée et de départ (jj/mm/aaaa).");
    if (depart <= arrivee) throw new Error("Le départ doit être au moins le lendemain de l'arrivée.");
    const prix = lireMontant(el("sejPrix").value);
    if (!prix || prix <= 0) throw new Error("Indiquez le prix par nuit.");
    const personnes = Number(el("sejPersonnes").value);
    if (!Number.isInteger(personnes) || personnes < 1) throw new Error("Nombre de personnes : au moins 1.");
    const corps = {
      logement_id: Number(el("sejLogement").value), client_nom: el("sejClient").value,
      client_telephone: el("sejTelephone").value || null, client_piece: el("sejPiece").value || null,
      nb_personnes: personnes, date_arrivee: arrivee, date_depart: depart, prix_nuit: prix,
      remise: lireMontant(el("sejRemise").value) || 0, notes: el("sejNotes").value || null,
    };
    if (sejourEnCours) {
      await api(`/api/sejours/${sejourEnCours}`, { method: "PUT", body: corps });
      toast("Réservation modifiée");
    } else {
      const rep = await api("/api/sejours", { method: "POST", body: corps });
      toast(`Réservation N° ${rep.numero} enregistrée (${formatMontant(rep.montant_total)}) : « Encaisser » pour l'acompte`, 5000);
    }
    goBack();
  });
});

// ---------- Arrivée, départ, annulation ----------

async function statutSejour(id, statut) {
  try {
    const rep = await api(`/api/sejours/${id}/statut`, { method: "POST", body: { statut } });
    toast(statut === "Arrivé" ? "Arrivée notée : bon séjour au client !"
      : rep.reste > 0 ? `Départ noté. Attention : il reste ${formatMontant(rep.reste)} à encaisser.` : "Départ noté : séjour terminé.", 5000);
    chargerSejours();
  } catch (e) { toast(e.message); }
}

async function annulerSejour(id) {
  const s = sejoursCache.find(x => x.id === id);
  if (!s) return;
  const motif = prompt(`Annuler la réservation N° ${s.numero} de ${s.client_nom} ?\nMotif (facultatif) :`, "");
  if (motif === null) return;
  let mdp = null;
  if (s.verse > 0) {
    if (!estAdmin()) { toast("Le client a déjà versé de l'argent : seul l'Admin peut annuler ce séjour."); return; }
    mdp = await demanderMotDePasseAdmin(`Le client a versé ${formatMontant(s.verse)}. Ce versement reste acquis `
      + "(annulez-le à part si vous le remboursez). Mot de passe Admin pour confirmer :",
      { titre: "Annuler la réservation", bouton: "Annuler la réservation" });
    if (!mdp) return;
  }
  try {
    await api(`/api/sejours/${id}/annuler`, { method: "POST", body: { motif, mot_de_passe_admin: mdp } });
    toast("Réservation annulée");
    chargerSejours();
  } catch (e) { toast(e.message); }
}

// ---------- Versements ----------

function encaisserSejour(id) {
  const s = sejoursCache.find(x => x.id === id);
  if (!s) return;
  const f = ouvrirFenetre(`<form id="formVersementSejour" novalidate>
    <div class="modal-tete"><h3>Encaisser — ${esc(s.client_nom)}</h3><button type="button" class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <p class="petit">Séjour N° ${esc(s.numero)} — ${esc(s.logement)} — prix ${formatMontant(s.montant_total)}, déjà versé ${formatMontant(s.verse)},
      <b>reste ${formatMontant(s.reste)}</b>. Vous pouvez encaisser un acompte puis le solde.</p>
    <div class="fgrid">
      <div class="field"><label for="versMontant">Montant (F CFA)</label><input id="versMontant" inputmode="numeric" value="${formatNombre(s.reste)}"></div>
      <div class="field"><label for="versMode">Mode de paiement</label><select id="versMode"></select></div>
      <div class="field champ-compte"><label for="versCompte">Argent rangé dans</label><select id="versCompte"></select></div>
      <div class="field"><label for="versDate">Date</label><input id="versDate" type="date"></div>
    </div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button type="button" class="btn" data-fermer>Fermer</button><button type="submit" class="btn primary">Encaisser</button></div>
  </form>`);
  initialiserChampsDate(f);
  fixerDate("versDate", aujourdhui());
  const modes = optionsSejours?.modes_paiement || ["Espèce", "Mobile Money", "Virement", "Chèque", "Autre"];
  remplirSelect(el("versMode"), modes);
  preparerChoixCompte("versMode", "versCompte");
  const form = f.querySelector("form");
  form.addEventListener("submit", ev => {
    ev.preventDefault();
    soumettre(form, async () => {
      const m = lireMontant(el("versMontant").value);
      if (!m || m <= 0) throw new Error("Indiquez le montant versé.");
      if (m > s.reste) throw new Error(`Il ne reste que ${formatMontant(s.reste)} à payer.`);
      const jour = valeurDate("versDate", "Date");
      const rep = await api(`/api/sejours/${id}/paiements`, { method: "POST", body: {
        montant: m, mode_paiement: el("versMode").value, date_paiement: jour, compte_id: compteChoisi("versCompte") } });
      f.fermer();
      toast(`Encaissé — Reçu N° ${rep.numero_recu}${rep.reste > 0 ? ` (reste ${formatMontant(rep.reste)})` : " : séjour réglé"}`, 5000);
      ouvrirRecuSejour(rep.id);
      chargerSejours();
    });
  });
}

async function ouvrirRecuSejour(paiementId) {
  try {
    const fichier = await apiFichier(`/api/sejours/paiements/${paiementId}/recu`);
    ouvrirBlob(fichier.blob, fichier.nom);
  } catch (e) { toast(e.message); }
}

async function annulerVersementSejour(id) {
  const s = sejoursCache.find(x => x.id === id);
  const payes = s ? s.paiements.filter(p => p.statut === "Payé") : [];
  if (!payes.length) return;
  const choix = payes.length === 1 ? payes[0] : payes.find(p => p.numero_recu === prompt(
    `Versements : ${payes.map(p => `${p.numero_recu} (${formatMontant(p.montant)})`).join(", ")}\nN° du reçu à annuler :`, payes.at(-1).numero_recu));
  if (!choix) return;
  const mdp = await demanderMotDePasseAdmin(`Annuler le versement ${choix.numero_recu} de ${formatMontant(choix.montant)} (remboursement) ? Mot de passe Admin :`,
                                         { titre: "Annuler un versement", bouton: "Annuler le versement" });
  if (!mdp) return;
  try {
    await api(`/api/sejours/paiements/${choix.id}/annuler`, { method: "POST", body: { mot_de_passe_admin: mdp } });
    toast("Versement annulé");
    chargerSejours();
  } catch (e) { toast(e.message); }
}

async function whatsappSejour(id) {
  const fenetre = window.open("", "_blank");
  try {
    const rep = await api(`/api/sejours/${id}/whatsapp`, { method: "POST" });
    if (fenetre) fenetre.location.href = rep.lien; else window.location.href = rep.lien;
    toast(rep.a_numero ? "WhatsApp ouvert : vérifiez le message puis Envoyer" : "Pas de numéro : choisissez le contact dans WhatsApp", 5000);
  } catch (e) { if (fenetre) fenetre.close(); toast(e.message); }
}

// ---------- Logements proposés à la nuit (Admin, Gestionnaire) ----------

async function logementsALaNuit() {
  try { optionsSejours = await api("/api/sejours/options"); } catch (e) { toast(e.message); return; }
  const lignes = optionsSejours.logements.map(l => `<div class="row">
      <span class="who"><b>${esc(l.libelle)}</b><br><span class="petit">${esc(l.type_logement)} — ${esc(l.statut_logement)}</span></span>
      <span class="boutons">
        <input class="search" style="width:9rem" id="prixNuit-${l.id}" inputmode="numeric" placeholder="Prix / nuit"
          value="${l.prix_nuit !== null ? formatNombre(l.prix_nuit) : ""}" ${l.statut_logement === "Occupé" && l.prix_nuit === null ? "disabled" : ""}>
        <button class="btn-sm" onclick="enregistrerPrixNuit(${l.id})" ${l.statut_logement === "Occupé" && l.prix_nuit === null ? 'disabled data-tip="Loué au mois"' : ""}>OK</button>
      </span></div>`).join("");
  ouvrirFenetre(`<div class="modal-tete"><h3>Logements proposés à la nuit</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <p class="petit">Donnez un prix par nuit aux logements meublés que vous louez en courte durée ; videz le prix pour retirer un logement.
      Un logement loué au mois ne peut pas l'être. La commission de gestion du bien s'applique aussi aux séjours.</p>
    ${lignes || '<div class="vide">Aucun logement.</div>'}`);
}

async function enregistrerPrixNuit(id) {
  const texte = el(`prixNuit-${id}`).value.trim();
  const prix = texte ? lireMontant(texte) : null;
  if (texte && (!prix || prix <= 0)) { toast("Prix par nuit invalide (ex : 25 000)."); return; }
  try {
    await api(`/api/sejours/logements/${id}`, { method: "PUT", body: { prix_nuit: prix } });
    toast(prix ? `Logement proposé à ${formatMontant(prix)} la nuit` : "Logement retiré de la courte durée");
    chargerCalendrierSejours();
  } catch (e) { toast(e.message); }
}

brancherRecherche(el("rechercheSejours"), el("listeSejours"));
