// Étape 7 : dépenses par bien.
// Le serveur filtre selon le profil (Gestionnaire : ses biens) et revérifie tout.

let depensesCache = [];
let optionsDepense = null;
let depenseEnCours = null;

async function chargerDepenses() {
  const zone = el("listeDepenses");
  try {
    depensesCache = await api("/api/depenses");
  } catch (e) {
    zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`;
    return;
  }
  // Totaux : général et par catégorie
  const total = depensesCache.reduce((s, d) => s + d.montant, 0);
  const parCategorie = {};
  for (const d of depensesCache) parCategorie[d.categorie] = (parCategorie[d.categorie] || 0) + d.montant;
  const proprio = depensesCache.filter(d => d.a_la_charge_de === "Propriétaire").reduce((s, d) => s + d.montant, 0);
  el("totauxDepenses").innerHTML = depensesCache.length ? `<div class="kpis">
      <div class="kpi warn"><div class="label">Total des dépenses</div><div class="value">${formatMontant(total)}</div></div>
      <div class="kpi info"><div class="label">À la charge des propriétaires</div><div class="value">${formatMontant(proprio)}</div></div>
      <div class="kpi"><div class="label">À la charge de l'entreprise</div><div class="value">${formatMontant(total - proprio)}</div></div>
    </div>
    <div class="card"><h3>Par catégorie</h3>${Object.entries(parCategorie).sort((a, b) => b[1] - a[1]).map(([c, m]) =>
      `<div class="row"><span class="who">${esc(c)}</span><span>${formatMontant(m)}</span></div>`).join("")}</div>` : "";

  if (!depensesCache.length) {
    zone.innerHTML = '<div class="card vide">Aucune dépense enregistrée. Cliquez sur « + Ajouter une dépense ».</div>';
    return;
  }
  zone.innerHTML = `<div class="card"><h3>Dépenses</h3>${depensesCache.map(d => `
    <div class="row row-fiche etat-${d.a_la_charge_de === "Propriétaire" ? "depart" : "retard"}" data-fiche="depense:${d.id}" tabindex="0"${motsCles({ textes: [d.adresse, d.saisi_par] })}>
      <span class="who"><b>${esc(d.bien)}</b>${d.logement ? " — " + esc(d.logement) : ""} — ${esc(d.motif)} — ${formatMontant(d.montant)}
        <br><span class="petit">${esc(d.categorie)} — À la charge : ${esc(d.a_la_charge_de === "Entreprise" ? nomEntreprise() : d.a_la_charge_de)} — ${esc(d.mode_paiement)}${d.montant_tva ? " — dont TVA " + formatMontant(d.montant_tva) : ""}${d.justificatif ? " — Pièce " + esc(d.justificatif) : ""}${d.saisi_par ? " — Saisie : " + esc(d.saisi_par) : ""}</span></span>
      <span class="boutons">
        <span class="pill warn">${formatDate(d.date_depense)}</span>
        ${ibtn("modifier", "Modifier cette dépense", `modifierDepense(${d.id})`)}
        ${estAdmin() || moi.role === "Caisse" ? ibtn("supprimer", "Supprimer cette dépense", `supprimerDepense(${d.id})`) : ""}
      </span>
    </div>`).join("")}</div>`;
  el("rechercheDepenses").dispatchEvent(new Event("input"));
}
CHARGEURS.depenses = chargerDepenses;

// ---------- Formulaire ----------

const FONCTIONNEMENT = "fonctionnement";
function majLogementsDepense(valeur = "") {
  const fonctionnement = el("depBien").value === FONCTIONNEMENT;
  // dépense du bureau : ni logement, ni propriétaire ; catégories de fonctionnement
  el("depLogement").closest(".field").style.display = fonctionnement ? "none" : "";
  el("depCharge").closest(".field").style.display = fonctionnement ? "none" : "";
  if (optionsDepense) {
    const choix = el("depCategorie").value;
    remplirSelect(el("depCategorie"), fonctionnement ? optionsDepense.categories_fonctionnement : optionsDepense.categories);
    if ([...el("depCategorie").options].some(o => o.value === choix)) el("depCategorie").value = choix;
  }
  const bien = optionsDepense?.biens.find(b => String(b.id) === el("depBien").value);
  remplirSelect(el("depLogement"), bien ? bien.logements : [], {
    valeur: l => l.id, texte: l => `Logement ${l.numero}`, vide: "— Tout le bien —",
  });
  el("depLogement").value = valeur ?? "";
}
el("depBien").addEventListener("change", () => majLogementsDepense(""));

async function preparerFormDepense(d) {
  optionsDepense = await api("/api/depenses/options");
  const o = optionsDepense;
  depenseEnCours = d ? d.id : null;
  remplirSelect(el("depBien"), o.biens, { valeur: b => b.id, texte: b => b.nom, vide: o.biens.length ? "— Choisir —" : "Aucun bien" });
  if (o.fonctionnement_autorise) {
    el("depBien").insertAdjacentHTML("beforeend", `<option value="${FONCTIONNEMENT}">➜ Fonctionnement de l'entreprise (bureau, salaires…)</option>`);
  }
  remplirSelect(el("depCategorie"), o.categories);
  remplirSelect(el("depCharge"), o.charges, { texte: c => c === "Entreprise" ? `L'entreprise (${nomEntreprise()})` : c });
  remplirSelect(el("depMode"), o.modes_paiement);
  el("titreDepense").textContent = d ? "Modifier la dépense" : "Nouvelle dépense";
  if (d) {
    el("depBien").value = d.fonctionnement ? FONCTIONNEMENT : d.cite_id;
    majLogementsDepense(d.logement_id ?? "");
    el("depCategorie").value = d.categorie;
    el("depMontant").value = formatNombre(d.montant);
    el("depMotif").value = d.motif;
    el("depCharge").value = d.a_la_charge_de;
    el("depMode").value = d.mode_paiement;
    fixerDate("depDate", d.date_depense);
    el("depTva").value = d.montant_tva ? formatNombre(d.montant_tva) : "";
    el("depJustificatif").value = d.justificatif || "";
  } else {
    if (o.biens.length === 1) el("depBien").value = o.biens[0].id;
    majLogementsDepense("");
    el("depCategorie").value = "Réparation";
    el("depMontant").value = "";
    el("depMotif").value = "";
    el("depCharge").value = "Propriétaire";
    el("depMode").value = "Espèce";
    fixerDate("depDate", aujourdhui());
    el("depTva").value = "";
    el("depJustificatif").value = "";
  }
  await preparerChoixCompte("depMode", "depCompte", d ? d.compte_id : null);
  erreurFormulaire(el("formulaireDepense"), "");
}

async function nouvelleDepense() {
  await preparerFormDepense(null);
  afficher("formDepense");
}

async function modifierDepense(id) {
  const d = depensesCache.find(x => x.id === id);
  if (!d) return;
  await preparerFormDepense(d);
  afficher("formDepense");
}

el("depTva").addEventListener("blur", () => {
  const n = lireMontant(el("depTva").value);
  if (n !== null) el("depTva").value = formatNombre(n);
});

el("depMontant").addEventListener("blur", () => {
  const n = lireMontant(el("depMontant").value);
  if (n !== null) el("depMontant").value = formatNombre(n);
});

el("formulaireDepense").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (!el("depBien").value) throw new Error("Choisissez le bien concerné.");
    const montantSaisi = lireMontant(el("depMontant").value);
    if (montantSaisi === null || montantSaisi <= 0) throw new Error("Indiquez un montant valide (ex : 45 000).");
    if (!el("depMotif").value.trim()) throw new Error("Indiquez le motif de la dépense.");
    const dateDepense = valeurDate("depDate", "Date");
    if (!dateDepense) throw new Error("Indiquez la date (jj/mm/aaaa).");
    if (dateDepense > aujourdhui()) throw new Error("La date de la dépense ne peut pas être dans le futur.");
    const fonctionnement = el("depBien").value === FONCTIONNEMENT;
    const tva = el("depTva").value.trim() ? lireMontant(el("depTva").value) : 0;
    if (tva === null || tva >= montantSaisi) throw new Error("Vérifiez la TVA : elle doit être inférieure au montant (TVA comprise).");
    const corps = {
      cite_id: fonctionnement ? null : Number(el("depBien").value),
      logement_id: !fonctionnement && el("depLogement").value ? Number(el("depLogement").value) : null,
      montant_tva: tva, justificatif: el("depJustificatif").value,
      categorie: el("depCategorie").value,
      montant: montantSaisi,
      motif: el("depMotif").value,
      a_la_charge_de: el("depCharge").value,
      mode_paiement: el("depMode").value,
      date_depense: dateDepense,
      compte_id: compteChoisi("depCompte"),
    };
    if (depenseEnCours) {
      await api(`/api/depenses/${depenseEnCours}`, { method: "PUT", body: corps });
    } else {
      await api("/api/depenses", { method: "POST", body: corps });
    }
    toast("Dépense enregistrée");
    goBack();
  });
});

function supprimerDepense(id) {
  const d = depensesCache.find(x => x.id === id);
  supprimerAvecConfirmation(
    `Supprimer la dépense « ${d ? d.motif : ""} » (${d ? formatMontant(d.montant) : ""}) ? Entrez votre mot de passe pour confirmer.`,
    `/api/depenses/${id}/supprimer`, chargerDepenses);
}

brancherRecherche(el("rechercheDepenses"), el("listeDepenses"));
