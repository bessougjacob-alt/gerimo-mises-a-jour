// Paramètres → Sauvegardes (Admin) : état, copie hors du PC (clé USB / disque externe), liste, restauration,
// code de secours (les sauvegardes sont chiffrées : sur un PC neuf, ce code permet de les relire).

let sauvegardesCache = null;

async function chargerSauvegardes() {
  const zone = el("parSauvegardes");
  let pcSecours, codeSecours;
  try {
    [sauvegardesCache, pcSecours, codeSecours] = await Promise.all([api("/api/sauvegardes"), api("/api/secours"),
                                                                  api("/api/sauvegardes/code-secours")]);
  }
  catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  const s = sauvegardesCache;
  const f = s.frequence;
  const heures = (choisie) => Array.from({ length: 25 }, (_, h) => `<option value="${h}"${h === choisie ? " selected" : ""}>${h} h</option>`).join("");
  let etatSecours;
  if (!pcSecours.jumele) etatSecours = `<span class="pill warn">Aucun PC de secours</span> Si ce PC tombe en panne, le bureau s'arrête jusqu'à la restauration d'une sauvegarde sur un autre PC.`;
  else if (pcSecours.en_retard) etatSecours = `<span class="pill danger">En retard</span> <b>${esc(pcSecours.nom)}</b> ne vient plus chercher les sauvegardes${pcSecours.derniere_copie ? ` (dernière le ${formatDate(pcSecours.derniere_copie.slice(0, 10))} à ${pcSecours.derniere_copie.slice(11, 16)})` : ""} : est-il allumé, et Gérimo y tourne-t-il ?`;
  else etatSecours = `<span class="pill ok">PC de secours</span> <b>${esc(pcSecours.nom)}</b>${pcSecours.derniere_copie ? ` — dernière copie emportée le ${formatDate(pcSecours.derniere_copie.slice(0, 10))} à ${pcSecours.derniere_copie.slice(11, 16)}` : " — en attente de sa première copie"}.`;
  const derniere = s.sauvegardes[0];
  let etatCopie;
  if (!s.dossier_externe) etatCopie = `<span class="pill warn">Aucune copie hors du PC</span> Choisissez ci-dessous une clé USB ou un disque externe.`;
  else if (!s.dossier_externe_trouve) etatCopie = `<span class="pill warn">Clé non branchée</span> Branchez la clé USB (ou le disque) sur le PC serveur : la copie se fera toute seule dans l'heure.`;
  else etatCopie = `<span class="pill ok">Copie hors du PC</span> Dernière copie le ${esc(s.derniere_copie_externe || "—")}, dans ${esc(s.dossier_externe_trouve)}.`;
  zone.innerHTML = `
    <div class="card">
      <h3>Protection de vos données</h3>
      <div class="row"><span class="who">${derniere
        ? `<span class="pill ok">Vérifiée</span> Dernière sauvegarde le <b>${esc(derniere.date)}</b> (${derniere.taille_mo} Mo).`
        : `<span class="pill danger">Aucune sauvegarde</span> Faites-en une maintenant.`}
        <br><span class="petit">${f.frequence === "heure" ? `Une sauvegarde automatique chaque jour, et toutes les heures de ${f.debut} h à ${f.fin} h s'il y a eu des changements` : "Une sauvegarde automatique chaque jour"}, et avant chaque mise à jour. On garde les 24 dernières, une par jour sur 14 jours et une par mois sur un an.</span></span>
        <span class="boutons"><button class="btn primary" onclick="sauvegarderMaintenant()">Sauvegarder maintenant</button></span></div>
      <div class="row"><span class="who">${etatCopie}</span></div>
      <div class="row"><span class="who">${etatSecours}</span></div>
    </div>
    <div class="card">
      <h3>Code de secours</h3>
      <p class="petit" style="margin-top:-.4rem">Vos sauvegardes sont <b>chiffrées</b> : une clé USB perdue ou volée ne révèle rien, et personne ne peut glisser une fausse sauvegarde.
        Si ce PC est remplacé (panne, vol), Gérimo vous demandera ce <b>code de secours</b> pour relire vos sauvegardes.
        Écrivez-le sur papier et rangez-le en lieu sûr, <b>hors du bureau</b> et pas avec la clé USB. Sans lui, les sauvegardes sont illisibles sur un autre PC.</p>
      <div class="row"><span class="who">${codeSecours.note
        ? '<span class="pill ok">Noté</span> Vous avez confirmé avoir noté le code de secours.'
        : '<span class="pill danger">À noter</span> Le code de secours n\'a pas encore été noté.'}</span>
        <span class="boutons"><button class="btn${codeSecours.note ? "" : " primary"}" onclick="afficherCodeSecours()">Afficher le code</button></span></div>
      <div id="zoneCodeSecours"></div>
    </div>
    <div class="card">
      <h3>Fréquence des sauvegardes</h3>
      <div class="pj-boutons">
        <select id="sauvFrequence" class="search" style="flex:0 1 330px">
          <option value="heure"${f.frequence === "heure" ? " selected" : ""}>Toutes les heures, au bureau (conseillé)</option>
          <option value="jour"${f.frequence === "jour" ? " selected" : ""}>Une fois par jour</option></select>
        <span class="petit">de</span><select id="sauvDebut" class="search" style="flex:0 1 90px">${heures(f.debut)}</select>
        <span class="petit">à</span><select id="sauvFin" class="search" style="flex:0 1 90px">${heures(f.fin)}</select>
        <button class="btn" onclick="enregistrerFrequence()">Enregistrer</button></div>
      <p class="petit">En cas de panne, on perd au plus ce qui a été saisi depuis la dernière sauvegarde : avec « toutes les heures », une heure au maximum.</p>
    </div>
    <div class="card">
      <h3>PC de secours</h3>
      <p class="petit" style="margin-top:-.4rem">Un deuxième PC du bureau, où Gérimo Serveur est installé en mode « PC de secours ».
        Il vient chercher chaque nouvelle sauvegarde par le réseau et peut <b>prendre le relais</b> en quelques minutes si ce PC tombe en panne.</p>
      ${pcSecours.jumele
        ? `<div class="row"><span class="who">${etatSecours}<br><span class="petit">Jumelé le ${formatDate(pcSecours.jumele_le.slice(0, 10))}.</span></span>
            <span class="boutons"><button class="btn-sm del" onclick="oublierSecours()">Ne plus envoyer à ce PC</button></span></div>`
        : `<button class="btn primary" onclick="codeSecours()">Jumeler un PC de secours</button>`}
      <div id="codeSecours"></div>
    </div>
    <div class="card">
      <h3>Copie automatique hors du PC</h3>
      <p class="petit" style="margin-top:-.4rem">Si le PC serveur tombe en panne, est volé ou brûle, seules les copies faites <b>ailleurs</b> sauvent vos données.
        Branchez une clé USB ou un disque externe <b>sur le PC serveur</b>, puis indiquez un dossier dessus (par exemple <b>E:\\Sauvegardes Gérimo</b>).
        Gérimo y copie chaque nouvelle sauvegarde, la vérifie, et retrouve le dossier même si la lettre de la clé change. Rangez ensuite la clé dans un autre lieu de temps en temps.</p>
      <div class="pj-boutons"><input id="sauvDossier" class="search" placeholder="E:\\Sauvegardes Gérimo" value="${esc(s.dossier_externe)}">
        <button class="btn" onclick="choisirDossierExterne()">Enregistrer et tester</button></div>
    </div>
    <div class="card">
      <h3>Sauvegardes disponibles (${s.sauvegardes.length})</h3>
      ${s.sauvegardes.length ? `<div style="overflow-x:auto"><table class="tableau">
        <tr><th>Date</th><th>Type</th><th class="nombre">Taille</th><th>Hors du PC</th><th></th></tr>
        ${s.sauvegardes.map((x, i) => `<tr class="ligne-cliquable" data-fiche="sauvegarde:${i}"><td>${esc(x.date)}</td><td>${esc(x.type)}</td><td class="nombre">${x.taille_mo} Mo</td>
          <td>${x.hors_du_pc ? '<span class="pill ok">Oui</span>' : '<span class="pill">Non</span>'}</td>
          <td style="white-space:nowrap"><button class="btn-sm" onclick="telechargerSauvegarde('${esc(x.fichier)}')">Télécharger</button>
            <button class="btn-sm" onclick="restaurerSauvegarde('${esc(x.fichier)}', '${esc(x.date)}')">Restaurer</button></td></tr>`).join("")}
      </table></div>` : '<div class="vide">Aucune sauvegarde pour l\'instant.</div>'}
      <p class="petit">Dossier sur le PC serveur : ${esc(s.dossier_local)}</p>
    </div>
    <div class="card">
      <h3>Restaurer depuis un fichier</h3>
      <p class="petit" style="margin-top:-.4rem">Pour reprendre une sauvegarde copiée sur une clé (fichier <b>Gerimo_sauvegarde_….gerimo</b>, ou <b>.zip</b> pour les anciennes). Le fichier est d'abord vérifié, puis ajouté à la liste ci-dessus : cliquez ensuite sur « Restaurer ». Une sauvegarde venue d'un autre PC demande son code de secours.</p>
      <input type="file" id="sauvFichier" accept=".gerimo,.zip" style="display:none" onchange="envoyerSauvegarde(this)">
      <button class="btn" onclick="el('sauvFichier').click()">Choisir le fichier…</button>
    </div>`;
}

function messageCopie(copie) {
  if (!copie || copie.etat === "non_configure") return "Aucune copie hors du PC : choisissez une clé USB dans Paramètres → Sauvegardes.";
  if (copie.etat === "ok") return `Copie hors du PC faite et vérifiée (${copie.dossier}).`;
  if (copie.etat === "absent") return "La clé USB de sauvegarde n'est pas branchée : la copie se fera dès qu'elle le sera.";
  return `Copie hors du PC impossible : ${copie.message || "erreur"}.`;
}

async function sauvegarderMaintenant() {
  toast("Sauvegarde en cours… (quelques secondes)", 15000);
  try {
    const rep = await api("/api/sauvegarde", { method: "POST" });
    toast(`Sauvegarde vérifiée (${rep.taille_mo} Mo). ${messageCopie(rep.copie)}`, 8000);
  } catch (e) { toast(e.message, 8000); }
  chargerSauvegardes();
}

async function choisirDossierExterne() {
  const dossier = el("sauvDossier").value.trim();
  toast(dossier ? "Test du dossier et copie de la dernière sauvegarde…" : "Enregistrement…", 15000);
  try {
    const rep = await api("/api/sauvegardes/dossier-externe", { method: "PUT", body: { dossier } });
    toast(dossier ? messageCopie(rep.copie) : "Copie hors du PC désactivée.", 8000);
  } catch (e) { toast(e.message, 8000); }
  chargerSauvegardes();
}

async function telechargerSauvegarde(nom) {
  toast("Téléchargement…");
  try {
    const f = await apiFichier(`/api/sauvegarde/${encodeURIComponent(nom)}`);
    telechargerBlob(f.blob, f.nom);
  } catch (e) { toast(e.message); }
}

// Sauvegarde chiffrée par une autre installation de Gérimo (PC remplacé) : on demande son code de secours
const CODE_SECOURS = "CODE_SECOURS : ";

function demanderCodeSecours(message) {
  const code = prompt(message.replace(CODE_SECOURS, "") +
                      "\n\nCode de secours (8 groupes de 4 caractères, noté sur papier) :");
  return code && code.trim() ? code.trim() : null;
}

async function envoyerSauvegarde(champ, fichierDeja, code) {
  const fichier = fichierDeja || champ.files[0];
  if (champ) champ.value = "";
  if (!fichier) return;
  toast(`Envoi et vérification de « ${fichier.name} »…`, 60000);
  let rep;
  const entetes = { "Content-Type": "application/octet-stream" };
  if (code) entetes["X-Gerimo-Code-Secours"] = code;
  try { rep = await fetch("/api/sauvegardes/envoyer", { method: "POST", body: fichier, headers: entetes }); }
  catch { toast("Le serveur ne répond pas. Vérifiez qu'il est bien démarré."); return; }
  const d = await rep.json().catch(() => ({}));
  if (rep.status === 409 && String(d.detail || "").startsWith(CODE_SECOURS)) {
    const saisi = demanderCodeSecours(d.detail);
    if (saisi) return envoyerSauvegarde(null, fichier, saisi);
    toast("Envoi annulé : sans le code de secours, ce fichier ne peut pas être relu.", 8000);
    return;
  }
  if (!rep.ok) { toast(typeof d.detail === "string" ? d.detail : "Erreur du serveur.", 8000); return; }
  toast("Fichier vérifié et ajouté à la liste (type « Fichier envoyé »). Cliquez sur « Restaurer » pour l'utiliser.", 8000);
  chargerSauvegardes();
}

async function restaurerSauvegarde(nom, date) {
  if (!confirm(`Remettre TOUTES les données dans l'état du ${date} ?\n\n` +
               "Tout ce qui a été saisi depuis cette date (paiements, contrats, documents…) sera remplacé.\n" +
               "Par précaution, une sauvegarde de l'état actuel sera faite juste avant : vous pourrez revenir en arrière.\n\n" +
               "Pendant la restauration (1 à 2 minutes), les autres postes doivent arrêter de travailler.")) return;
  const mdp = await demanderMotDePasseAdmin(`Restauration de la sauvegarde du ${date} : confirmez avec votre mot de passe.`,
                                         { titre: "Restaurer une sauvegarde", bouton: "Restaurer" });
  if (!mdp) { toast("Restauration annulée"); return; }
  toast("Restauration en cours… ne fermez pas cette page.", 600000);
  let code = "";
  try {
    let rep;
    for (;;) {
      try {
        rep = await api(`/api/sauvegardes/${encodeURIComponent(nom)}/restaurer`,
                        { method: "POST", body: { mot_de_passe_admin: mdp, code_secours: code } });
        break;
      } catch (e) {
        if (!e.message.startsWith(CODE_SECOURS)) throw e;
        code = demanderCodeSecours(e.message);
        if (!code) { toast("Restauration annulée : rien n'a été modifié."); return; }
        toast("Restauration en cours… ne fermez pas cette page.", 600000);
      }
    }
    alert(`Restauration terminée : les données sont celles du ${date}.\n\n` +
          `L'état d'avant a été sauvegardé dans « ${rep.securite} » (visible dans la liste).\n` +
          "Vous allez être redirigé vers la page de connexion.");
    window.location.replace("/connexion");
  } catch (e) { toast(e.message, 10000); chargerSauvegardes(); }
}

async function afficherCodeSecours() {
  const mdp = await demanderMotDePasseAdmin("Pour afficher le code de secours des sauvegardes, confirmez avec votre mot de passe.",
                                         { titre: "Afficher le code de secours", bouton: "Afficher", danger: false });
  if (!mdp) return;
  let rep;
  try { rep = await api("/api/sauvegardes/code-secours", { method: "POST", body: { mot_de_passe_admin: mdp } }); }
  catch (e) { toast(e.message); return; }
  el("zoneCodeSecours").innerHTML = `
    <div class="code-secours" style="font-family:Consolas,monospace;font-size:1.35rem;letter-spacing:.06em;padding:.8rem 1rem;
      margin:.6rem 0;background:var(--fond-doux,#f3f5f1);border-radius:10px;text-align:center;word-break:break-all">${esc(rep.code)}</div>
    <p class="petit">Recopiez-le à la main, lisiblement (le chiffre 0 et la lettre O, le 1 et le I sont acceptés l'un pour l'autre).
      Ne l'envoyez pas par WhatsApp ni par e-mail, ne le prenez pas en photo.</p>
    <div class="pj-boutons"><button class="btn primary" onclick="confirmerCodeNote()">J'ai noté le code</button>
      <button class="btn" onclick="el('zoneCodeSecours').innerHTML=''">Masquer</button></div>`;
}

async function confirmerCodeNote() {
  try { await api("/api/sauvegardes/code-secours/note", { method: "POST" }); }
  catch (e) { toast(e.message); return; }
  toast("Merci ! Gardez ce papier en lieu sûr, hors du bureau.", 6000);
  chargerSauvegardes();
}

async function enregistrerFrequence() {
  try {
    await api("/api/sauvegardes/frequence", { method: "PUT", body: {
      frequence: el("sauvFrequence").value, debut: Number(el("sauvDebut").value), fin: Number(el("sauvFin").value) } });
    toast("Fréquence des sauvegardes enregistrée");
    chargerSauvegardes();
  } catch (e) { toast(e.message); }
}

async function codeSecours() {
  try {
    const rep = await api("/api/secours/code", { method: "POST" });
    el("codeSecours").innerHTML = `<div class="recap" style="margin-top:.8rem">Sur le PC de secours, dans la fenêtre de Gérimo Serveur, tapez :
      <br>adresse de ce PC : <b>${esc((rep.adresses.length ? rep.adresses : [location.hostname]).join(" ou "))}</b> — code : <b style="font-size:1.3rem;letter-spacing:.08em">${esc(rep.code)}</b>
      <br><span class="petit">Code valable ${rep.valable_minutes} minutes, une seule fois.</span></div>`;
  } catch (e) { toast(e.message); }
}

async function oublierSecours() {
  if (!confirm("Ne plus envoyer les sauvegardes au PC de secours ? Il faudra refaire le jumelage pour le réutiliser.")) return;
  try {
    await api("/api/secours/oublier", { method: "POST" });
    toast("PC de secours oublié");
    chargerSauvegardes();
  } catch (e) { toast(e.message); }
}
