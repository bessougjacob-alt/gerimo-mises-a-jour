// Commerce, étape 5 (14/11/2026) : bilan de la boutique. Admin, Caisse, Comptable (le serveur revérifie).
// L'essentiel en grand (chiffres clés), puis les ventes jour par jour (une seule série : une couleur, pas de légende),
// les meilleurs articles, ceux qui ne se vendent pas, les vendeurs et les modes de paiement.

let bilanCommerceCache = null;

function periodeBilan(code) {
  const auj = new Date(aujourdhui() + "T00:00:00");
  const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  if (code === "jour") return [iso(auj), iso(auj)];
  if (code === "mois_dernier") {
    const debut = new Date(auj.getFullYear(), auj.getMonth() - 1, 1), fin = new Date(auj.getFullYear(), auj.getMonth(), 0);
    return [iso(debut), iso(fin)];
  }
  if (code === "annee") return [`${auj.getFullYear()}-01-01`, iso(auj)];
  return [iso(new Date(auj.getFullYear(), auj.getMonth(), 1)), iso(auj)];
}
document.querySelectorAll("#formulaireBilanCommerce [data-periode]").forEach(b => b.addEventListener("click", () => {
  document.querySelectorAll("#formulaireBilanCommerce [data-periode]").forEach(x => x.classList.toggle("choisi", x === b));
  const [debut, fin] = periodeBilan(b.dataset.periode);
  fixerDate("bcDebut", debut);
  fixerDate("bcFin", fin);
  chargerBilanCommerce();
}));
el("formulaireBilanCommerce").addEventListener("submit", e => {
  e.preventDefault();
  document.querySelectorAll("#formulaireBilanCommerce [data-periode]").forEach(x => x.classList.remove("choisi"));
  chargerBilanCommerce();
});

function parametresBilan() {
  const debut = valeurDate("bcDebut", "Du"), fin = valeurDate("bcFin", "Au");
  const p = new URLSearchParams();
  if (debut) p.set("debut", debut);
  if (fin) p.set("fin", fin);
  return p;
}

async function chargerBilanCommerce() {
  const form = el("formulaireBilanCommerce"), zone = el("contenuBilanCommerce");
  if (!el("bcDebut").value) { const [d, f] = periodeBilan("mois"); fixerDate("bcDebut", d); fixerDate("bcFin", f); }
  let b;
  try { b = await api("/api/bilan-commerce?" + parametresBilan()); erreurFormulaire(form, ""); }
  catch (e) { erreurFormulaire(form, e.message); return; }
  bilanCommerceCache = b;
  const k = b.kpis;
  const tuile = (classe, chiffre, libelle, aide) => `<div class="chiffre-cle ${classe} statique"><span class="cc-chiffre">${chiffre}</span>
    <span class="cc-libelle">${libelle}</span><span class="cc-aide">${aide}</span></div>`;
  const max = Math.max(1, ...b.par_jour.map(j => j.total));
  const plusieursJours = b.par_jour.length > 1;
  zone.innerHTML = `
    <div class="resume-stock">
      ${tuile("calme", formatMontant(k.chiffre_affaires), "Chiffre d'affaires", `${k.nombre_ventes} vente${k.nombre_ventes > 1 ? "s" : ""} · panier moyen ${formatMontant(k.panier_moyen)}`)}
      ${tuile(k.benefice >= 0 ? "calme" : "alerte", formatMontant(k.benefice), "Bénéfice", k.chiffre_affaires ? `${String(k.taux_benefice).replace(".", ",")} % des ventes` : "aucune vente")}
      ${tuile(k.pertes ? "alerte-orange" : "calme", formatMontant(k.pertes), "Pertes", "casse, périmés, vols…")}
      ${tuile(k.benefice_net >= 0 ? "neutre" : "alerte", formatMontant(k.benefice_net), "Bénéfice après pertes", k.remises ? `remises accordées : ${formatMontant(k.remises)}` : "")}
    </div>
    <div class="resume-stock">
      ${tuile(k.credits_clients ? "alerte" : "calme", formatMontant(k.credits_clients), "Les clients me doivent", "à ce jour")}
      ${tuile(k.dettes_fournisseurs ? "alerte-orange" : "calme", formatMontant(k.dettes_fournisseurs), "Je dois aux fournisseurs", "à ce jour")}
      ${tuile("neutre", formatMontant(k.valeur_stock), "Valeur du stock", "au prix d'achat")}
      ${tuile("neutre", formatMontant(k.encaisse), "Argent encaissé", `payé aux fournisseurs : ${formatMontant(k.paye_fournisseurs)}`)}
    </div>
    ${plusieursJours ? `<div class="card"><h3>Ventes jour par jour</h3>
      <div class="histo" role="img" aria-label="Ventes jour par jour">${b.par_jour.map(j => `
        <div class="histo-col" data-tip="${formatDate(j.date)} : ${formatMontant(j.total)}"><span class="histo-barre" style="height:${Math.round(j.total / max * 100)}%"></span></div>`).join("")}</div>
      <div class="histo-axe"><span>${formatDate(b.par_jour[0].date)}</span><span>${formatDate(b.par_jour.at(-1).date)}</span></div></div>` : ""}
    <div class="bilan-colonnes">
      <div class="card"><h3>Meilleurs articles</h3>${b.meilleurs_articles.length ? `<div class="fa-tableau"><table><thead><tr><th>Article</th><th>Vendu</th><th>Ventes</th><th>Bénéfice</th></tr></thead><tbody>
        ${b.meilleurs_articles.map(a => `<tr><td><b>${esc(a.article)}</b></td><td>${nombre(a.quantite)} ${esc(a.unite)}</td><td>${formatMontant(a.chiffre_affaires)}</td>
          <td class="${a.benefice >= 0 ? "plus" : "moins"}">${formatMontant(a.benefice)}</td></tr>`).join("")}</tbody></table></div>` : '<p class="petit">Aucune vente sur la période.</p>'}</div>
      <div class="card"><h3>En stock mais pas vendus</h3>${b.sans_vente.length ? `<p class="petit" style="margin-top:-.4rem">De l'argent qui dort : pensez à une promotion.</p>
        <div class="fa-tableau"><table><thead><tr><th>Article</th><th>En stock</th><th>Valeur</th></tr></thead><tbody>
        ${b.sans_vente.map(a => `<tr><td><b>${esc(a.article)}</b></td><td>${nombre(a.stock)} ${esc(a.unite)}</td><td>${formatMontant(a.valeur)}</td></tr>`).join("")}</tbody></table></div>`
        : '<p class="petit">Tout ce qui est en stock s\'est vendu au moins une fois. 👍</p>'}</div>
      <div class="card"><h3>Par vendeur</h3>${b.par_vendeur.length ? b.par_vendeur.map(v => `<div class="row"><span class="who"><b>${esc(v.vendeur)}</b> <span class="petit">· ${v.nombre} vente${v.nombre > 1 ? "s" : ""}</span></span><b>${formatMontant(v.chiffre_affaires)}</b></div>`).join("") : '<p class="petit">—</p>'}</div>
      <div class="card"><h3>Argent reçu par mode</h3>${b.par_mode.length ? b.par_mode.map(m => `<div class="row"><span class="who">${esc(m.mode)}</span><b>${formatMontant(m.montant)}</b></div>`).join("") : '<p class="petit">—</p>'}</div>
    </div>`;
}
CHARGEURS.bilan_commerce = chargerBilanCommerce;

function imprimerBilanCommerce() {
  try { window.open("/api/bilan-commerce/pdf?" + parametresBilan(), "_blank"); }
  catch (e) { toast(e.message); }
}
