// Métier « Agence Mobile Money » (14/11/2026). Le moins de gestes possible au guichet :
// opérateur → Dépôt ou Retrait → montant → Valider. Les soldes (espèces et puces) restent affichés en grand.
// Le serveur (mobile_money.py) revérifie tout : kiosques de l'agent, soldes suffisants, droits.

let tableauMM = null;
let kiosqueMM = null;          // id du kiosque choisi
let saisieMM = { puce: null, type: "Dépôt" };
let operationsMM = [];
let ongletMM = "mmGuichet";
const AUTRES_OPERATIONS = ["Rechargement de la puce", "Retour de e-monnaie", "Apport d'espèces", "Sortie d'espèces", "Commission reçue"];
const AVEC_COMPTE_MM = ["Rechargement de la puce", "Retour de e-monnaie", "Apport d'espèces", "Sortie d'espèces", "Commission reçue"];
const AIDE_COMPTE_MM = { "Apport d'espèces": "D'où vient l'argent ?", "Sortie d'espèces": "Où va l'argent ?",
  "Rechargement de la puce": "Payé depuis", "Retour de e-monnaie": "Argent reçu sur", "Commission reçue": "Versée sur" };

const ONGLETS_MM = { mmGuichet: () => chargerGuichetMM(), mmOperations: () => chargerOperationsMM(),
                     mmCloture: () => chargerClotureMM(), mmCommissions: () => chargerCommissionsMM(), mmReglages: () => chargerReglagesMM() };
function montrerOngletMM(id) {
  if (id === "mmReglages" && !estAdmin()) id = "mmGuichet";
  ongletMM = id;
  document.querySelectorAll("#ongletsMM .onglet").forEach(b => b.classList.toggle("actif", b.dataset.onglet === id));
  Object.keys(ONGLETS_MM).forEach(z => { el(z).style.display = z === id ? "" : "none"; });
  ONGLETS_MM[id]();
}
el("ongletsMM").addEventListener("click", e => { const b = e.target.closest(".onglet"); if (b) montrerOngletMM(b.dataset.onglet); });
CHARGEURS.mobile_money = () => montrerOngletMM(ongletMM);

async function chargerTableauMM() {
  tableauMM = await api("/api/mm/tableau");
  document.querySelectorAll("#ongletsMM .onglet-saisie").forEach(b => { b.style.display = tableauMM.peut_saisir ? "" : "none"; });
  if (!tableauMM.points.some(p => p.id === kiosqueMM)) kiosqueMM = tableauMM.points.length ? tableauMM.points[0].id : null;
  return tableauMM;
}
const kiosque = () => tableauMM && tableauMM.points.find(p => p.id === kiosqueMM);

// ---------- Guichet ----------

async function chargerGuichetMM() {
  try { await chargerTableauMM(); } catch (e) { el("mmSoldes").innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  if (!tableauMM.points.length) {
    el("mmChoixKiosque").innerHTML = "";
    el("mmSoldes").innerHTML = `<div class="card vide">${estAdmin() ? "Aucun kiosque pour l'instant : créez-en un dans « Réglages » (avec ses puces et ses agents)."
      : "Vous n'êtes rattaché à aucun kiosque : demandez à l'Admin (Mobile Money → Réglages)."}</div>`;
    el("mmSaisie").style.display = "none";
    return;
  }
  el("mmChoixKiosque").innerHTML = tableauMM.points.length > 1 ? tableauMM.points.map(p =>
    `<button type="button" class="puce-filtre${p.id === kiosqueMM ? " choisi" : ""}" onclick="choisirKiosqueMM(${p.id})">${esc(p.nom)}</button>`).join("") : "";
  afficherSoldesMM();
  afficherSaisieMM();
}
function choisirKiosqueMM(id) { kiosqueMM = id; saisieMM.puce = null; chargerGuichetMM(); }

function afficherSoldesMM() {
  const k = kiosque();
  el("mmSoldes").innerHTML = `
    <div class="mm-solde especes${k.especes_basses ? " bas" : ""}"><small>Espèces en caisse</small><b>${formatMontant(k.especes)}</b>
      <span>${k.especes_basses ? "⚠ presque plus d'espèces" : `aujourd'hui : ${k.jour.nombre} opération${k.jour.nombre > 1 ? "s" : ""}`}</span></div>
    ${k.puces.map(p => `<div class="mm-solde${p.bas ? " bas" : ""}" style="--op:${esc(p.couleur)}"><small>${esc(p.operateur)}</small><b>${formatMontant(p.solde)}</b>
      <span>${p.bas ? "⚠ puce presque vide" : p.numero ? esc(p.numero) : "e-monnaie"}</span></div>`).join("")}
    <div class="mm-solde commissions"><small>Commissions du jour</small><b>${formatMontant(k.jour.commissions)}</b><span>attendues</span></div>`;
}

function afficherSaisieMM() {
  const k = kiosque();
  const zone = el("mmSaisie");
  zone.style.display = tableauMM.peut_saisir ? "" : "none";
  if (!tableauMM.peut_saisir) return;
  if (!k.puces.length) { zone.innerHTML = '<p class="petit">Ce kiosque n\'a aucune puce : l\'Admin doit en ajouter (Réglages).</p>'; return; }
  if (!saisieMM.puce || !k.puces.some(p => p.id === saisieMM.puce)) saisieMM.puce = k.puces[0].id;
  const autre = AUTRES_OPERATIONS.includes(saisieMM.type);
  const avecPuce = !["Apport d'espèces", "Sortie d'espèces"].includes(saisieMM.type);
  zone.innerHTML = `
    ${avecPuce ? `<div class="mm-operateurs">${k.puces.map(p => `<button type="button" class="mm-op${p.id === saisieMM.puce ? " choisi" : ""}"
      style="--op:${esc(p.couleur)}" onclick="saisieMM.puce = ${p.id}; afficherSaisieMM()">${esc(p.operateur)}</button>`).join("")}</div>` : ""}
    <div class="mm-types">
      <button type="button" class="mm-type depot${saisieMM.type === "Dépôt" ? " choisi" : ""}" onclick="saisieMM.type = 'Dépôt'; afficherSaisieMM()">⬇ Dépôt<small>le client donne des espèces</small></button>
      <button type="button" class="mm-type retrait${saisieMM.type === "Retrait" ? " choisi" : ""}" onclick="saisieMM.type = 'Retrait'; afficherSaisieMM()">⬆ Retrait<small>je donne des espèces</small></button>
    </div>
    <div class="mm-ligne-montant">
      <input id="mmMontant" class="mm-montant" inputmode="numeric" placeholder="Montant" aria-label="Montant" autocomplete="off">
      <input id="mmClient" inputmode="tel" placeholder="N° du client (facultatif)" aria-label="Numéro du client" autocomplete="off">
    </div>
    <div class="billets mm-rapides">${[1000, 2000, 5000, 10000, 20000, 50000].map(m => `<button type="button" onclick="el('mmMontant').value = '${formatNombre(m)}'; el('mmMontant').focus()">${formatMontant(m)}</button>`).join("")}</div>
    <div class="form-erreur" id="mmErreur" role="alert"></div>
    <button type="button" class="btn-encaisser" id="mmValider" onclick="validerOperationMM()">Valider ${autre ? "l'opération" : `le ${saisieMM.type.toLowerCase()}`}</button>
    <details class="mm-autres"${autre ? " open" : ""}><summary>Autres opérations : rechargement de puce, apport ou sortie d'espèces, commission reçue</summary>
      <div class="mm-autres-boutons">${AUTRES_OPERATIONS.map(t => `<button type="button" class="puce-filtre${saisieMM.type === t ? " choisi" : ""}"
        onclick="saisieMM.type = '${t.replace(/'/g, "\\'")}'; afficherSaisieMM()">${esc(t)}</button>`).join("")}</div>
      ${["Rechargement de la puce", "Retour de e-monnaie"].includes(saisieMM.type) ? `<label class="case"><input type="checkbox" id="mmPayeEspeces" checked> Payé avec les espèces du kiosque</label>` : ""}
      ${AVEC_COMPTE_MM.includes(saisieMM.type) && tableauMM.comptes && tableauMM.comptes.length ? `<div class="field" style="margin:.5rem 0 0">
        <label for="mmCompte">${esc(AIDE_COMPTE_MM[saisieMM.type])} (compte de l'entreprise, facultatif)</label>
        <select id="mmCompte"><option value="">${saisieMM.type === "Commission reçue" ? "La puce de l'opérateur" : "— Aucun (hors Trésorerie) —"}</option>
          ${tableauMM.comptes.map(c => `<option value="${c.id}">${esc(c.nom)} (${esc(c.type)})</option>`).join("")}</select></div>` : ""}
      <input id="mmReference" placeholder="Référence (facultatif)" maxlength="60" style="margin-top:.5rem">
    </details>`;
  el("mmMontant").addEventListener("keydown", e => { if (e.key === "Enter") validerOperationMM(); });
  el("mmMontant").addEventListener("blur", () => { const n = lireMontant(el("mmMontant").value); if (n) el("mmMontant").value = formatNombre(n); });
  el("mmMontant").focus();
}

async function validerOperationMM() {
  const erreur = el("mmErreur");
  erreur.style.display = "none";
  const montant = lireMontant(el("mmMontant").value);
  if (!montant) { erreur.textContent = "Tapez le montant."; erreur.style.display = "block"; el("mmMontant").focus(); return; }
  const avecPuce = !["Apport d'espèces", "Sortie d'espèces"].includes(saisieMM.type);
  el("mmValider").disabled = true;
  try {
    const r = await api("/api/mm/operations", { method: "POST", body: {
      point_id: kiosqueMM, type_operation: saisieMM.type, puce_id: avecPuce ? saisieMM.puce : null, montant,
      numero_client: el("mmClient").value.trim() || null, reference: el("mmReference") ? el("mmReference").value.trim() || null : null,
      paye_en_especes: el("mmPayeEspeces") ? el("mmPayeEspeces").checked : true,
      compte_id: el("mmCompte") && el("mmCompte").value ? Number(el("mmCompte").value) : null } });
    const res = el("mmResultat");
    res.hidden = false;
    res.className = "derniere-vente ok";
    res.innerHTML = `<b>✓ ${esc(r.type)} de ${formatMontant(r.montant)}${r.operateur ? " — " + esc(r.operateur) : ""} enregistré</b>
      <span>${r.solde_puce !== null ? `Puce : <b>${formatMontant(r.solde_puce)}</b> · ` : ""}Espèces : <b>${formatMontant(r.especes)}</b>${r.commission ? ` · commission ${formatMontant(r.commission)}` : ""}</span>`;
    if (AUTRES_OPERATIONS.includes(saisieMM.type)) saisieMM.type = "Dépôt";
    await chargerTableauMM();
    afficherSoldesMM();
    afficherSaisieMM();
  } catch (e) {
    erreur.textContent = e.message;
    erreur.style.display = "block";
    el("mmValider").disabled = false;
  }
}

// ---------- Opérations (aujourd'hui et les 6 jours d'avant) ----------

async function chargerOperationsMM() {
  const zone = el("listeMM");
  try { if (!tableauMM) await chargerTableauMM(); operationsMM = await api("/api/mm/operations" + (kiosqueMM ? `?point_id=${kiosqueMM}` : "")); }
  catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  zone.innerHTML = operationsMM.length ? `<div class="card">${operationsMM.map(o => `
    <div class="row row-fiche etat-${o.annulee ? "termine" : o.type === "Dépôt" ? "a_jour" : o.type === "Retrait" ? "depart" : "retard"}" data-fiche="mmop:${o.id}" tabindex="0"${motsCles({ tel: [o.numero_client], textes: [o.reference, o.numero] })}>
      <span class="who"><b>${esc(o.type)}</b>${o.operateur ? ` <span class="pastille-op" style="--op:${esc(o.couleur)}">${esc(o.operateur)}</span>` : ""} — ${formatMontant(o.montant)}${o.annulee ? " <span class=\"pill\">Annulée</span>" : ""}
        <br><span class="petit">${formatDate(o.date)} à ${esc(o.heure)}${o.numero_client ? " · client " + esc(o.numero_client) : ""}${o.commission ? " · commission " + formatMontant(o.commission) : ""} · ${esc(o.saisi_par)}</span></span>
    </div>`).join("")}</div>` : '<div class="card vide">Aucune opération ces 7 derniers jours.</div>';
  el("rechercheMM").dispatchEvent(new Event("input"));
}
brancherRecherche(el("rechercheMM"), el("listeMM"));

window.addEventListener("load", () => {
  if (typeof FICHES === "undefined") return;
  FICHES.mmop = id => {
    const o = operationsMM.find(x => x.id === id);
    if (!o) return;
    ficheSimple({
      titre: `${o.type}${o.operateur ? " — " + o.operateur : ""}`, sous: `${esc(o.numero)} · ${esc(o.point)} · ${formatDate(o.date)} à ${esc(o.heure)}`,
      code: o.annulee ? "termine" : "a_jour", etat: o.annulee ? `Annulée : ${o.motif_annulation}` : "Enregistrée", grand: formatMontant(o.montant),
      aide: o.numero_client ? `Client : ${esc(o.numero_client)}` : "",
      stats: [o.commission ? ["Commission attendue", formatMontant(o.commission)] : null, o.reference ? ["Référence", esc(o.reference)] : null,
              ["Saisie par", esc(o.saisi_par)], o.note ? ["Note", esc(o.note)] : null],
      actions: [tableauMM && tableauMM.peut_annuler && !o.annulee ? { libelle: "Annuler l'opération", discret: true, fn: () => annulerOperationMM(o) } : null],
    });
  };
});

async function annulerOperationMM(o) {
  const mdp = await demanderMotDePasseAdmin(`Annuler « ${o.type} de ${formatMontant(o.montant)} » ? Les soldes seront corrigés. Entrez votre mot de passe.`,
                                            { titre: "Annuler l'opération", bouton: "Annuler l'opération" });
  if (!mdp) return;
  try {
    await api(`/api/mm/operations/${o.id}/annuler`, { method: "POST", body: { mot_de_passe_admin: mdp, motif: "Erreur de saisie" } });
    toast("Opération annulée : les soldes sont corrigés");
    chargerOperationsMM();
  } catch (e) { toast(e.message, 7000); }
}

// ---------- Clôture du soir ----------

async function chargerClotureMM() {
  const zone = el("zoneClotureMM");
  try { await chargerTableauMM(); } catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  const k = kiosque();
  if (!k) { zone.innerHTML = '<div class="card vide">Aucun kiosque.</div>'; return; }
  let passees = [];
  try { passees = await api(`/api/mm/clotures?point_id=${k.id}`); } catch { /* sans historique */ }
  zone.innerHTML = `${tableauMM.points.length > 1 ? `<div class="mm-kiosque">${tableauMM.points.map(p =>
      `<button type="button" class="puce-filtre${p.id === kiosqueMM ? " choisi" : ""}" onclick="kiosqueMM = ${p.id}; chargerClotureMM()">${esc(p.nom)}</button>`).join("")}</div>` : ""}
    ${k.cloture_du_jour ? `<div class="card vide">✓ La journée d'aujourd'hui est déjà clôturée pour ${esc(k.nom)}.</div>` : `
    <div class="card"><h3>Clôture de ${esc(k.nom)} — aujourd'hui</h3>
      <p class="petit" style="margin-top:-.4rem">Comptez les espèces et lisez le solde de chaque puce sur le téléphone. Gérimo montre l'écart tout de suite.</p>
      <div class="fa-tableau"><table><thead><tr><th></th><th>Gérimo prévoit</th><th>Vous comptez / lisez</th><th>Écart</th></tr></thead><tbody>
        <tr><td><b>Espèces</b></td><td>${formatMontant(k.especes)}</td><td><input class="cl-reel" data-prevu="${k.especes}" data-cle="especes" inputmode="numeric" placeholder="${formatNombre(k.especes)}"></td><td class="cl-ecart">—</td></tr>
        ${k.puces.map(p => `<tr><td><b>${esc(p.operateur)}</b></td><td>${formatMontant(p.solde)}</td><td><input class="cl-reel" data-prevu="${p.solde}" data-puce="${p.id}" inputmode="numeric" placeholder="${formatNombre(p.solde)}"></td><td class="cl-ecart">—</td></tr>`).join("")}
      </tbody></table></div>
      <div class="field"><label for="clNote">Note (facultatif)</label><input id="clNote" maxlength="300"></div>
      <div class="form-erreur" role="alert" id="clErreur"></div>
      <button type="button" class="btn-encaisser" onclick="validerClotureMM()">Clôturer la journée</button>
    </div>`}
    ${passees.length ? `<h3 class="titre-groupe">Clôtures passées</h3><div class="card">${passees.map(c => `
      <div class="row row-fiche etat-${c.ecart_especes === 0 && c.puces.every(p => !p.ecart) ? "a_jour" : "a_risque"}"><span class="who"><b>${formatDate(c.date)}</b> — espèces : ${c.ecart_especes === 0 ? "justes" : `écart ${c.ecart_especes > 0 ? "+" : ""}${formatMontant(c.ecart_especes)}`}
        ${c.puces.filter(p => p.ecart).map(p => ` · ${esc(p.operateur)} ${p.ecart > 0 ? "+" : ""}${formatMontant(p.ecart)}`).join("")}
        <br><span class="petit">compté ${formatMontant(c.especes_comptees)} pour ${formatMontant(c.especes_calculees)} prévus · ${esc(c.saisi_par)}${c.note ? " · " + esc(c.note) : ""}</span></span></div>`).join("")}</div>` : ""}`;
  zone.querySelectorAll(".cl-reel").forEach(c => c.addEventListener("input", () => {
    const v = lireMontant(c.value), td = c.closest("tr").querySelector(".cl-ecart");
    if (!c.value.trim() || v === null) { td.textContent = "—"; return; }
    const ecart = v - Number(c.dataset.prevu);
    td.innerHTML = ecart === 0 ? '<b class="plus">✓ juste</b>' : `<b class="${ecart > 0 ? "plus" : "moins"}">${ecart > 0 ? "+" : "−"} ${formatMontant(Math.abs(ecart))}</b>`;
  }));
}

async function validerClotureMM() {
  const erreur = el("clErreur");
  const champs = [...el("zoneClotureMM").querySelectorAll(".cl-reel")];
  const valeur = c => c.value.trim() ? lireMontant(c.value) : Number(c.dataset.prevu);
  if (champs.some(c => valeur(c) === null)) { erreur.textContent = "Un montant est invalide."; erreur.style.display = "block"; return; }
  try {
    const r = await api("/api/mm/clotures", { method: "POST", body: {
      point_id: kiosqueMM, especes_comptees: valeur(champs.find(c => c.dataset.cle === "especes")),
      puces: champs.filter(c => c.dataset.puce).map(c => ({ puce_id: Number(c.dataset.puce), reel: valeur(c) })),
      note: el("clNote").value.trim() || null } });
    toast(r.ecart_especes === 0 ? "Journée clôturée : la caisse est juste 👍" : `Journée clôturée : écart d'espèces ${formatMontant(r.ecart_especes)}`, 6000);
    chargerClotureMM();
  } catch (e) { erreur.textContent = e.message; erreur.style.display = "block"; }
}

// ---------- Commissions ----------

async function chargerCommissionsMM() {
  const zone = el("zoneCommissionsMM");
  if (!el("mmDebut").value) { fixerDate("mmDebut", aujourdhui().slice(0, 8) + "01"); fixerDate("mmFin", aujourdhui()); }
  let r;
  try {
    const p = new URLSearchParams();
    const d = valeurDate("mmDebut", "Du"), f = valeurDate("mmFin", "Au");
    if (d) p.set("debut", d);
    if (f) p.set("fin", f);
    r = await api("/api/mm/rapport?" + p);
  } catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  const max = Math.max(1, ...r.par_jour.map(j => j.commissions));
  zone.innerHTML = `
    <div class="resume-stock">
      <div class="chiffre-cle calme statique"><span class="cc-chiffre">${formatMontant(r.total.commissions)}</span><span class="cc-libelle">Commissions attendues</span><span class="cc-aide">${r.total.nombre} dépôt${r.total.nombre > 1 ? "s" : ""} et retraits</span></div>
      <div class="chiffre-cle ${r.total.commissions_recues >= r.total.commissions ? "calme" : "alerte-orange"} statique"><span class="cc-chiffre">${formatMontant(r.total.commissions_recues)}</span><span class="cc-libelle">Commissions reçues</span><span class="cc-aide">${r.total.commissions_recues >= r.total.commissions ? "tout est versé" : `il manque ${formatMontant(r.total.commissions - r.total.commissions_recues)}`}</span></div>
      <div class="chiffre-cle neutre statique"><span class="cc-chiffre">${formatMontant(r.total.depots)}</span><span class="cc-libelle">Dépôts</span><span class="cc-aide">sur la période</span></div>
      <div class="chiffre-cle neutre statique"><span class="cc-chiffre">${formatMontant(r.total.retraits)}</span><span class="cc-libelle">Retraits</span><span class="cc-aide">sur la période</span></div>
    </div>
    <p class="petit">Commissions calculées avec le barème de chaque opérateur (Réglages). Comparez-les au relevé que l'opérateur vous envoie.</p>
    ${r.par_jour.length > 1 ? `<div class="card"><h3>Commissions jour par jour</h3><div class="histo">${r.par_jour.map(j => `
      <div class="histo-col" data-tip="${formatDate(j.date)} : ${formatMontant(j.commissions)}"><span class="histo-barre" style="height:${Math.round(j.commissions / max * 100)}%"></span></div>`).join("")}</div>
      <div class="histo-axe"><span>${formatDate(r.par_jour[0].date)}</span><span>${formatDate(r.par_jour.at(-1).date)}</span></div></div>` : ""}
    <div class="bilan-colonnes">
      <div class="card"><h3>Par opérateur</h3>${r.par_operateur.length ? `<div class="fa-tableau"><table><thead><tr><th>Opérateur</th><th>Opérations</th><th>Dépôts</th><th>Retraits</th><th>Commissions</th></tr></thead><tbody>
        ${r.par_operateur.map(o => `<tr><td><span class="pastille-op" style="--op:${esc(o.couleur)}">${esc(o.operateur)}</span></td><td>${o.nombre}</td><td>${formatMontant(o.depots)}</td><td>${formatMontant(o.retraits)}</td><td><b>${formatMontant(o.commissions)}</b></td></tr>`).join("")}</tbody></table></div>` : '<p class="petit">Aucune opération.</p>'}</div>
      <div class="card"><h3>Par agent</h3>${r.par_agent.length ? r.par_agent.map(a => `<div class="row"><span class="who"><b>${esc(a.agent)}</b> <span class="petit">· ${a.nombre} opération${a.nombre > 1 ? "s" : ""} · ${formatMontant(a.volume)}</span></span><b>${formatMontant(a.commissions)}</b></div>`).join("") : '<p class="petit">—</p>'}</div>
    </div>`;
}

// ---------- Réglages (Admin) ----------

let reglagesMM = null;
async function chargerReglagesMM() {
  const zone = el("zoneReglagesMM");
  try { reglagesMM = await api("/api/mm/reglages"); } catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  const nomOp = id => (reglagesMM.operateurs.find(o => o.id === id) || {}).nom || "?";
  zone.innerHTML = `
    <div class="card"><div class="df-tete" style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">Kiosques</h3>
      <button class="btn primary" onclick="formulaireKiosqueMM(null)">+ Nouveau kiosque</button></div>
      ${reglagesMM.points.length ? reglagesMM.points.map(p => `<div class="row row-fiche etat-${p.actif ? "a_jour" : "termine"}" onclick="formulaireKiosqueMM(${p.id})" tabindex="0">
        <span class="who"><b>${esc(p.nom)}</b>${p.adresse ? " — " + esc(p.adresse) : ""}<br><span class="petit">Puces : ${p.puces.filter(x => x.actif).map(x => esc(nomOp(x.operateur_id))).join(", ") || "aucune"}
          · agents : ${p.agents.map(a => esc((reglagesMM.utilisateurs.find(u => u.id === a) || {}).nom || "?")).join(", ") || "aucun"}</span></span></div>`).join("")
        : '<p class="petit">Aucun kiosque. Créez le premier : ses espèces de départ, une puce par opérateur, et les agents qui y travaillent.</p>'}</div>
    <div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">Opérateurs et barèmes de commission</h3>
      <button class="btn" onclick="formulaireOperateurMM(null)">+ Opérateur</button></div>
      ${reglagesMM.operateurs.map(o => `<div class="row row-fiche etat-${o.actif ? "a_jour" : "termine"}" onclick="formulaireOperateurMM(${o.id})" tabindex="0">
        <span class="who"><span class="pastille-op" style="--op:${esc(o.couleur)}">${esc(o.nom)}</span><br><span class="petit">${o.baremes.length ? `${o.baremes.length} tranche${o.baremes.length > 1 ? "s" : ""} de commission` : "aucun barème : commissions à 0"}</span></span></div>`).join("")}</div>`;
}

function formulaireKiosqueMM(id) {
  const p = id ? reglagesMM.points.find(x => x.id === id) : null;
  const puce = opId => p ? p.puces.find(x => x.operateur_id === opId && x.actif) : null;
  const fen = ouvrirFenetre(`<div class="modal-tete"><h3>${p ? "Modifier le kiosque" : "Nouveau kiosque"}</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field"><label for="kqNom">Nom</label><input id="kqNom" maxlength="100" value="${esc(p ? p.nom : "")}" placeholder="ex : Kiosque du marché"></div>
      <div class="field"><label for="kqAdresse">Adresse (facultatif)</label><input id="kqAdresse" maxlength="200" value="${esc(p ? p.adresse : "")}"></div>
      <div class="field"><label for="kqEspeces">Espèces au départ (F)</label><input id="kqEspeces" inputmode="numeric" value="${p ? formatNombre(p.especes_depart) : ""}"></div>
      <div class="field"><label for="kqSeuil">Prévenir sous (F d'espèces)</label><input id="kqSeuil" inputmode="numeric" value="${p && p.seuil_especes ? formatNombre(p.seuil_especes) : ""}"></div>
    </div>
    <h4>Puces (cochez les opérateurs de ce kiosque)</h4>
    <div class="fa-tableau"><table><thead><tr><th>Opérateur</th><th>N° de la puce</th><th>Solde au départ</th><th>Prévenir sous</th></tr></thead><tbody>
      ${reglagesMM.operateurs.filter(o => o.actif).map(o => { const x = puce(o.id); return `<tr data-op="${o.id}">
        <td><label class="case"><input type="checkbox" class="kqPuce"${x ? " checked" : ""}> ${esc(o.nom)}</label></td>
        <td><input class="kqNum" value="${esc(x ? x.numero : "")}" maxlength="30"></td>
        <td><input class="kqSolde" inputmode="numeric" value="${x ? formatNombre(x.solde_depart) : ""}"></td>
        <td><input class="kqSeuilPuce" inputmode="numeric" value="${x && x.seuil_alerte ? formatNombre(x.seuil_alerte) : ""}"></td></tr>`; }).join("")}
    </tbody></table></div>
    <h4>Agents qui y travaillent</h4>
    <div class="cases">${reglagesMM.utilisateurs.map(u => `<label><input type="checkbox" class="kqAgent" value="${u.id}"${p && p.agents.includes(u.id) ? " checked" : ""}> ${esc(u.nom)} <span class="petit">(${esc(u.role)})</span></label>`).join("") || '<span class="petit">Aucun compte Caisse ou Gestionnaire : créez-en dans Paramètres → Utilisateurs.</span>'}</div>
    ${p ? `<label class="case" style="margin-top:.6rem"><input type="checkbox" id="kqActif"${p.actif ? " checked" : ""}> Kiosque en service</label>` : ""}
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div>`, { taille: "large" });
  fen.querySelector('[data-action="ok"]').addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const m = (sel, defaut = 0) => { const v = fen.querySelector(sel).value.trim(); if (!v) return defaut; const n = lireMontant(v); if (n === null) throw new Error("Un montant est invalide."); return n; };
      const puces = [...fen.querySelectorAll("tr[data-op]")].filter(tr => tr.querySelector(".kqPuce").checked).map(tr => {
        const n = c => { const v = tr.querySelector(c).value.trim(); if (!v) return 0; const x = lireMontant(v); if (x === null) throw new Error("Un montant de puce est invalide."); return x; };
        return { operateur_id: Number(tr.dataset.op), numero: tr.querySelector(".kqNum").value.trim() || null, solde_depart: n(".kqSolde"), seuil_alerte: n(".kqSeuilPuce") };
      });
      const corps = { nom: fen.querySelector("#kqNom").value.trim(), adresse: fen.querySelector("#kqAdresse").value.trim() || null,
                      especes_depart: m("#kqEspeces"), seuil_especes: m("#kqSeuil"), actif: p ? fen.querySelector("#kqActif").checked : true,
                      agents: [...fen.querySelectorAll(".kqAgent:checked")].map(c => Number(c.value)), puces };
      if (corps.nom.length < 2) throw new Error("Indiquez le nom du kiosque.");
      await api(p ? `/api/mm/points/${p.id}` : "/api/mm/points", { method: p ? "PUT" : "POST", body: corps });
      fen.fermer();
      toast("Kiosque enregistré");
      chargerReglagesMM();
    } catch (e) { erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}

function formulaireOperateurMM(id) {
  const o = id ? reglagesMM.operateurs.find(x => x.id === id) : null;
  const ligne = (b = {}) => `<tr class="tranche"><td><select class="trType"><option${b.type === "Retrait" ? "" : " selected"}>Dépôt</option><option${b.type === "Retrait" ? " selected" : ""}>Retrait</option></select></td>
    <td><input class="trMin" inputmode="numeric" value="${b.min != null ? formatNombre(b.min) : ""}" placeholder="0"></td>
    <td><input class="trMax" inputmode="numeric" value="${b.max != null ? formatNombre(b.max) : ""}" placeholder="sans limite"></td>
    <td><input class="trFixe" inputmode="numeric" value="${b.fixe ? formatNombre(b.fixe) : ""}" placeholder="0"></td>
    <td><input class="trPct" inputmode="decimal" value="${b.pct ? String(b.pct).replace(".", ",") : ""}" placeholder="0"></td>
    <td><button type="button" class="ibtn del" onclick="this.closest('tr').remove()" aria-label="Retirer">✕</button></td></tr>`;
  const fen = ouvrirFenetre(`<div class="modal-tete"><h3>${o ? esc(o.nom) : "Nouvel opérateur"}</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field"><label for="opNom">Nom</label><input id="opNom" maxlength="60" value="${esc(o ? o.nom : "")}"></div>
      <div class="field"><label for="opCouleur">Couleur</label><input id="opCouleur" type="color" value="${esc(o ? o.couleur : "#1d3b53")}"></div>
    </div>
    <h4>Barème de commission</h4>
    <p class="petit">Pour chaque tranche de montant : une commission fixe (en francs) et/ou un pourcentage. Exemple : dépôt de 0 à 5 000 F → 50 F.</p>
    <div class="fa-tableau"><table><thead><tr><th>Type</th><th>De (F)</th><th>À (F)</th><th>Fixe (F)</th><th>%</th><th></th></tr></thead>
      <tbody id="opTranches">${(o ? o.baremes : []).map(ligne).join("")}</tbody></table></div>
    <button type="button" class="btn ghost" id="opAjout">+ Ajouter une tranche</button>
    ${o ? `<label class="case" style="margin-top:.6rem"><input type="checkbox" id="opActif"${o.actif ? " checked" : ""}> Opérateur utilisé</label>` : ""}
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div>`, { taille: "large" });
  fen.querySelector("#opAjout").addEventListener("click", () => fen.querySelector("#opTranches").insertAdjacentHTML("beforeend", ligne()));
  if (!o) fen.querySelector("#opTranches").insertAdjacentHTML("beforeend", ligne());
  fen.querySelector('[data-action="ok"]').addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const n = (tr, c, vide = 0) => { const v = tr.querySelector(c).value.trim(); if (!v) return vide; const x = c === ".trPct" ? lireQuantite(v) : lireMontant(v); if (x === null) throw new Error("Un nombre du barème est invalide."); return x; };
      const baremes = [...fen.querySelectorAll("tr.tranche")].map(tr => ({ type: tr.querySelector(".trType").value, min: n(tr, ".trMin"),
        max: n(tr, ".trMax", null), fixe: n(tr, ".trFixe"), pct: n(tr, ".trPct") }));
      const corps = { nom: fen.querySelector("#opNom").value.trim(), couleur: fen.querySelector("#opCouleur").value,
                      actif: o ? fen.querySelector("#opActif").checked : true, baremes };
      await api(o ? `/api/mm/operateurs/${o.id}` : "/api/mm/operateurs", { method: o ? "PUT" : "POST", body: corps });
      fen.fermer();
      toast("Opérateur enregistré");
      chargerReglagesMM();
    } catch (e) { erreur.textContent = e.message; erreur.style.display = "block"; }
  });
}
