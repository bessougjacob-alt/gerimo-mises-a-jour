// Scanner un code-barres avec l'appareil photo du téléphone (14/11/2026, demande de Boss : « pense à la version
// Android »). Sert à la caisse et au stock, quand il n'y a pas de douchette.
// - Lecteur intégré au navigateur (BarcodeDetector) quand il existe ;
// - sinon, petit décodeur EAN-13 / EAN-8 (codes des produits du commerce), sans aucune bibliothèque extérieure.
// Application Android : l'appareil photo est donné à la page à partir de la version de l'appli qui le permet.

const SCANNER_DISPONIBLE = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);

// ---------- Décodeur EAN-13 / EAN-8 (une ligne de pixels) ----------
const EAN_L = ["0001101", "0011001", "0010011", "0111101", "0100011", "0110001", "0101111", "0111011", "0110111", "0001011"];
const EAN_G = EAN_L.map(m => [...m].reverse().map(b => (b === "1" ? "0" : "1")).join(""));
const EAN_R = EAN_L.map(m => [...m].map(b => (b === "1" ? "0" : "1")).join(""));
const EAN_PREMIER = ["LLLLLL", "LLGLGG", "LLGGLG", "LLGGGL", "LGLLGG", "LGGLLG", "LGGGLL", "LGLGLG", "LGLGGL", "LGGLGL"];

function cleEanValide(code) {
  const chiffres = [...code].map(Number);
  const controle = chiffres.pop();
  const somme = chiffres.reverse().reduce((s, c, i) => s + c * (i % 2 === 0 ? 3 : 1), 0);
  return (10 - (somme % 10)) % 10 === controle;
}

// gris : tableau de luminosités d'une ligne → code EAN lu, ou null.
// Chaque chiffre occupe 7 modules en 4 barres : on mesure chaque chiffre à part (photo floue, un peu de travers).
function lireLigneEan(gris) {
  if (gris.length < 60) return null;
  const min = Math.min(...gris), max = Math.max(...gris);
  if (max - min < 40) return null;   // image trop uniforme
  for (const seuil of [(min + max) / 2, min + (max - min) * 0.4, min + (max - min) * 0.6]) {
    const bandes = [];
    let couleur = gris[0] < seuil ? 1 : 0, longueur = 0;
    for (const v of gris) {
      const b = v < seuil ? 1 : 0;
      if (b === couleur) longueur++;
      else { bandes.push({ couleur, longueur }); couleur = b; longueur = 1; }
    }
    bandes.push({ couleur, longueur });
    const code = decoderBandes(bandes);
    if (code) return code;
  }
  return null;
}

function motifChiffre(largeurs, commenceParNoir) {
  const total = largeurs.reduce((s, l) => s + l, 0);
  const modules = largeurs.map(l => Math.max(1, Math.min(4, Math.round(l * 7 / total))));
  let somme = modules.reduce((s, m) => s + m, 0);
  while (somme !== 7) {   // arrondi : on corrige la barre la plus mal arrondie
    const ecarts = largeurs.map((l, j) => l * 7 / total - modules[j]);
    const j = somme > 7 ? ecarts.indexOf(Math.min(...ecarts)) : ecarts.indexOf(Math.max(...ecarts));
    modules[j] += somme > 7 ? -1 : 1;
    if (modules[j] < 1 || modules[j] > 4) return null;
    somme = modules.reduce((s, m) => s + m, 0);
  }
  return modules.map((m, j) => String(((j % 2 === 0) === commenceParNoir) ? 1 : 0).repeat(m)).join("");
}

function decoderBandes(bandes) {
  for (const moitie of [6, 4]) {   // EAN-13 puis EAN-8
    const total = 3 + moitie * 4 + 5 + moitie * 4 + 3;
    for (let i = 0; i + total <= bandes.length; i++) {
      if (bandes[i].couleur !== 1) continue;
      const garde = bandes.slice(i, i + 3).map(b => b.longueur);
      const module = (garde[0] + garde[1] + garde[2]) / 3;
      if (garde.some(l => l > module * 2.2 || l < module * 0.35)) continue;
      // la zone blanche avant le code doit être large (pas une barre au milieu d'un autre dessin)
      if (i > 0 && bandes[i - 1].longueur < module * 3) continue;
      const largeurs = bandes.slice(i, i + total).map(b => b.longueur);
      let pos = 3, gauche = "", parites = "", ok = true;
      for (let k = 0; k < moitie && ok; k++) {
        const m = motifChiffre(largeurs.slice(pos, pos + 4), false); pos += 4;
        if (!m) { ok = false; break; }
        let c = EAN_L.indexOf(m);
        if (c >= 0) { gauche += c; parites += "L"; continue; }
        c = EAN_G.indexOf(m);
        if (c >= 0 && moitie === 6) { gauche += c; parites += "G"; continue; }
        ok = false;
      }
      if (!ok) continue;
      const centre = largeurs.slice(pos, pos + 5);
      if (centre.some(l => l > module * 2.5)) continue;
      pos += 5;
      let droite = "";
      for (let k = 0; k < moitie && ok; k++) {
        const m = motifChiffre(largeurs.slice(pos, pos + 4), true); pos += 4;
        const c = m ? EAN_R.indexOf(m) : -1;
        if (c < 0) ok = false; else droite += c;
      }
      if (!ok) continue;
      let code;
      if (moitie === 6) {
        const premier = EAN_PREMIER.indexOf(parites);
        if (premier < 0) continue;
        code = premier + gauche + droite;
      } else code = gauche + droite;
      if (cleEanValide(code)) return code;
    }
  }
  return null;
}

function lireImageEan(contexte, largeur, hauteur) {
  for (const part of [0.5, 0.4, 0.6, 0.3, 0.7]) {
    const ligne = contexte.getImageData(0, Math.floor(hauteur * part), largeur, 1).data;
    const gris = [];
    for (let x = 0; x < largeur; x++) gris.push(ligne[x * 4] * 0.3 + ligne[x * 4 + 1] * 0.59 + ligne[x * 4 + 2] * 0.11);
    const code = lireLigneEan(gris) || lireLigneEan(gris.slice().reverse());
    if (code) return code;
  }
  return null;
}

// ---------- Photo du code-barres (marche partout, même en http et avec les anciennes versions de l'appli) ----------
function lireCodeSurImage(image) {
  const toile = document.createElement("canvas");
  const largeur = Math.min(image.naturalWidth || image.width, 1400);
  toile.width = largeur;
  toile.height = Math.round(largeur * (image.naturalHeight || image.height) / (image.naturalWidth || image.width));
  const contexte = toile.getContext("2d", { willReadFrequently: true });
  contexte.drawImage(image, 0, 0, toile.width, toile.height);
  for (let part = 0.2; part <= 0.8; part += 0.04) {
    const ligne = contexte.getImageData(0, Math.floor(toile.height * part), toile.width, 1).data;
    const gris = [];
    for (let x = 0; x < toile.width; x++) gris.push(ligne[x * 4] * 0.3 + ligne[x * 4 + 1] * 0.59 + ligne[x * 4 + 2] * 0.11);
    const code = lireLigneEan(gris) || lireLigneEan(gris.slice().reverse());
    if (code) return code;
  }
  return null;
}

function scannerParPhoto(quandLu) {
  const champ = document.createElement("input");
  champ.type = "file";
  champ.accept = "image/*";
  champ.capture = "environment";
  champ.addEventListener("change", () => {
    const fichier = champ.files && champ.files[0];
    if (!fichier) return;
    const url = URL.createObjectURL(fichier);
    const image = new Image();
    image.onload = async () => {
      let code = null;
      if ("BarcodeDetector" in window) {
        try { const t = await new window.BarcodeDetector({ formats: ["ean_13", "ean_8", "upc_a", "upc_e", "code_128", "code_39"] }).detect(image); if (t.length) code = t[0].rawValue; } catch { /* décodeur intégré */ }
      }
      code = code || lireCodeSurImage(image);
      URL.revokeObjectURL(url);
      if (code) quandLu(code);
      else toast("Code-barres non lu : reprenez la photo de plus près, bien à plat et éclairé (ou tapez le code).", 7000);
    };
    image.src = url;
  });
  champ.click();
}

// ---------- Fenêtre de l'appareil photo (vidéo) ----------
async function scannerCodeBarres(quandLu) {
  if (!SCANNER_DISPONIBLE) { scannerParPhoto(quandLu); return; }   // connexion http : la vidéo n'est pas permise
  const fen = ouvrirFenetre(`<div class="modal-tete"><h3>Scanner un code-barres</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <div class="scanner-cadre"><video playsinline muted></video><div class="scanner-viseur"></div></div>
    <p class="petit" id="scannerAide">Placez le code-barres dans le cadre, bien à plat et éclairé.</p>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn" data-action="photo">Prendre une photo à la place</button></div>`, { taille: "" });
  fen.querySelector('[data-action="photo"]').addEventListener("click", () => { fen.fermer(); scannerParPhoto(quandLu); });
  const video = fen.querySelector("video");
  let flux = null, fini = false;
  const arreter = () => { fini = true; if (flux) flux.getTracks().forEach(t => t.stop()); };
  fen.addEventListener("fermee", arreter);
  try {
    flux = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 } }, audio: false });
  } catch {
    fen.fermer();   // pas de vidéo (appareil refusé, ancienne appli…) : on passe par une photo
    scannerParPhoto(quandLu);
    return;
  }
  video.srcObject = flux;
  await video.play().catch(() => {});
  let natif = null;
  if ("BarcodeDetector" in window) {
    try { natif = new window.BarcodeDetector({ formats: ["ean_13", "ean_8", "upc_a", "upc_e", "code_128", "code_39"] }); } catch { natif = null; }
  }
  const toile = document.createElement("canvas");
  const contexte = toile.getContext("2d", { willReadFrequently: true });
  const chercher = async () => {
    if (fini || !video.videoWidth) { if (!fini) requestAnimationFrame(chercher); return; }
    let code = null;
    try {
      if (natif) {
        const trouves = await natif.detect(video);
        if (trouves.length) code = trouves[0].rawValue;
      } else {
        toile.width = Math.min(video.videoWidth, 960);
        toile.height = Math.round(toile.width * video.videoHeight / video.videoWidth);
        contexte.drawImage(video, 0, 0, toile.width, toile.height);
        code = lireImageEan(contexte, toile.width, toile.height);
      }
    } catch { /* image suivante */ }
    if (code) {
      if (navigator.vibrate) navigator.vibrate(80);
      fen.fermer();
      quandLu(code);
      return;
    }
    setTimeout(chercher, natif ? 120 : 60);
  };
  chercher();
}
