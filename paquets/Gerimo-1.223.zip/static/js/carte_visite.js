// Carte de visite (Actions rapides → Imprimer → « Ma carte de visite »).
// Nom, prénoms et téléphones se saisissent ; la fonction est celle fixée par l'Admin (verrouillée).
// Le reste (logo, fond, QR code, adresse) vient de la maquette ; l'Admin peut en envoyer une autre (« Uploader vCard »).

let carteInfos = null;
let minuterieApercu;

async function ouvrirCarteVisite() {
  try { carteInfos = await api("/api/carte-visite"); } catch (e) { toast(e.message); return; }
  if (!carteInfos.maquette && !estAdmin()) {
    toast("La maquette de carte de visite de l'entreprise n'a pas encore été envoyée : demandez-la à l'Admin.", 7000);
    return;
  }
  const memo = lireStockage(`isup_carte_${moi.identifiant}`, null);
  el("cvNom").value = memo?.nom ?? carteInfos.nom;
  el("cvPrenoms").value = memo?.prenoms ?? carteInfos.prenoms;
  el("cvTel1").value = memo?.telephone1 ?? carteInfos.telephone1;
  el("cvTel2").value = memo?.telephone2 ?? carteInfos.telephone2;
  el("cvFonction").value = carteInfos.fonction;
  reinitialiserSaisie(el("formCarte"));
  erreurFormulaire(el("formCarte"), "");
  el("cvMaquette").style.display = estAdmin() ? "" : "none";
  apercuProposee = carteInfos.maquette_proposee;   // maquette envoyée mais pas encore adoptée
  el("cvRemplacer").disabled = !apercuProposee;
  ouvrirModal("modalCarte");
  rafraichirApercuCarte();
}

// Maquette (Admin) : « Uploader vCard » montre la carte avec le nouveau modèle,
// « Remplacer l'ancienne maquette » l'adopte pour tout le monde.
let apercuProposee = false;

el("cvMaquetteFichier").addEventListener("change", async () => {
  const fichier = el("cvMaquetteFichier").files[0];
  el("cvMaquetteFichier").value = "";
  if (!fichier) return;
  const form = el("formCarte");
  erreurFormulaire(form, "");
  toast("Lecture de la maquette…", 4000);
  try {
    const rep = await fetch("/api/carte-visite/maquette", { method: "POST", body: fichier });
    const r = await rep.json().catch(() => ({}));
    if (!rep.ok) throw new Error(r.detail || "Maquette refusée.");
    apercuProposee = true;
    el("cvRemplacer").disabled = false;
    await rafraichirApercuCarte();
    toast("Voici votre carte avec la nouvelle maquette" + (r.recto_verso ? "" : " (recto seul)")
          + (r.fonction ? "" : " — aucune ligne « fonction » trouvée sous le nom")
          + ". Si elle vous convient : « Remplacer l'ancienne maquette ».", 9000);
    if (r.avertissement) erreurFormulaire(form, `⚠ ${r.avertissement}`);   // format inhabituel : acceptée, mais à savoir
  } catch (e) { erreurFormulaire(form, e.message); }
});

async function carteRemplacerMaquette() {
  if (!confirm("Remplacer l'ancienne maquette par la nouvelle ? Toutes les cartes de visite seront faites avec ce modèle "
               + "(l'ancienne est gardée de côté).")) return;
  try {
    await api("/api/carte-visite/maquette/remplacer", { method: "POST" });
    apercuProposee = false;
    el("cvRemplacer").disabled = true;
    rafraichirApercuCarte();
    toast("Nouvelle maquette adoptée ✅", 5000);
  } catch (e) { erreurFormulaire(el("formCarte"), e.message); }
}

function donneesCarte(format = "imprimeur") {
  const d = { nom: el("cvNom").value.trim(), prenoms: el("cvPrenoms").value.trim(), telephone1: el("cvTel1").value.trim(),
              telephone2: el("cvTel2").value.trim() || null, format };
  if (!d.nom) throw new Error("Indiquez le nom.");
  if (!d.telephone1) throw new Error("Indiquez au moins un numéro de téléphone.");
  ecrireStockage(`isup_carte_${moi.identifiant}`, d);
  return d;
}

async function rafraichirApercuCarte() {
  let d;
  try { d = donneesCarte(); } catch { return; }
  try {
    const { blob } = await apiFichier(`/api/carte-visite/apercu${apercuProposee ? "?proposee=true" : ""}`, { body: d });
    const ancien = el("cvApercu").src;
    el("cvApercu").src = URL.createObjectURL(blob);
    if (ancien.startsWith("blob:")) URL.revokeObjectURL(ancien);
    erreurFormulaire(el("formCarte"), "");
  } catch (e) { erreurFormulaire(el("formCarte"), e.message); }
}
["cvNom", "cvPrenoms", "cvTel1", "cvTel2"].forEach(id => el(id).addEventListener("input", () => {
  clearTimeout(minuterieApercu);
  minuterieApercu = setTimeout(rafraichirApercuCarte, 700);
}));

// Impression au bureau : planche A4 de 10 cartes, recto puis verso
async function carteImprimer() {
  try {
    verifierChamps(el("formCarte"));
    const { blob } = await apiFichier("/api/carte-visite/pdf", { body: donneesCarte("planche") });
    ouvrirBlob(blob);
    toast("Imprimez en recto-verso, taille réelle (100 %), sur papier cartonné, puis découpez le long des traits.", 9000);
  } catch (e) { erreurFormulaire(el("formCarte"), e.message); }
}

// Fichier pour l'imprimeur : recto + verso avec 3 mm de fond perdu
async function carteImprimeur(mode) {
  const form = el("formCarte");
  erreurFormulaire(form, "");
  let d;
  try { verifierChamps(form); d = donneesCarte("imprimeur"); } catch (e) { erreurFormulaire(form, e.message); return; }
  try {
    if (mode === "pdf") {
      const f = await apiFichier("/api/carte-visite/pdf", { body: d });
      telechargerBlob(f.blob, f.nom);
    } else if (mode === "whatsapp") {
      const fenetre = window.open("", "_blank");
      const [rep, f] = await Promise.all([api("/api/carte-visite/whatsapp", { method: "POST", body: d }),
                                          apiFichier("/api/carte-visite/pdf", { body: d })]);
      telechargerBlob(f.blob, f.nom);
      if (fenetre) fenetre.location.href = rep.lien; else window.location.href = rep.lien;
      toast(rep.a_numero ? "WhatsApp ouvert vers l'imprimeur : joignez le PDF téléchargé, puis Envoyer."
                         : "Numéro de l'imprimeur non renseigné (Paramètres) : choisissez le contact dans WhatsApp.", 8000);
    } else {
      const adresse = prompt("Adresse e-mail de l'imprimeur :", carteInfos.email_imprimeur || "");
      if (!adresse) return;
      toast("Envoi en cours…", 8000);
      await api("/api/carte-visite/envoyer-email", { method: "POST", body: { ...d, destinataire: adresse.trim() } });
      toast(`Carte de visite envoyée à ${adresse} ✅`, 5000);
    }
  } catch (e) { erreurFormulaire(form, e.message); }
}
