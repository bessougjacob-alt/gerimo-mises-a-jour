// Commerce, étape 4 (14/11/2026) : ventes au comptoir, historique des ventes, clients et crédits.
// Le serveur (ventes.py) revérifie tout : prix, stock, remise plafonnée, plafond de crédit, droits.

let optionsVentes = null;
let articlesVente = [];
let clientsCommerce = [];
let ventesCache = [];
let ongletVentes = "veCaisse";
let panier = [];            // [{ article_id, unite_id, quantite }]
let prixPanier = "Détail";

// ---------- Onglets ----------

const ONGLETS_VENTES = { veCaisse: () => chargerCaisse(), veHistorique: () => chargerVentes(), veClients: () => chargerClientsCommerce() };
function montrerOngletVentes(id) {
  ongletVentes = id;
  document.querySelectorAll("#ongletsVentes .onglet").forEach(b => b.classList.toggle("actif", b.dataset.onglet === id));
  Object.keys(ONGLETS_VENTES).forEach(z => { el(z).style.display = z === id ? "" : "none"; });
  ONGLETS_VENTES[id]();
}
el("ongletsVentes").addEventListener("click", e => {
  const b = e.target.closest(".onglet");
  if (b) montrerOngletVentes(b.dataset.onglet);
});
CHARGEURS.ventes = () => montrerOngletVentes(ongletVentes);

async function chargerBasesVente() {
  [optionsVentes, articlesVente, clientsCommerce] = await Promise.all([
    api("/api/ventes/options"), api("/api/articles"), api("/api/clients-commerce")]);
  const doivent = clientsCommerce.filter(c => c.doit > 0).length;
  el("nbClientsDoivent").textContent = doivent || "";
}

// ---------- Caisse : articles à toucher ----------

async function chargerCaisse() {
  try { await chargerBasesVente(); } catch (e) { el("caisseTuiles").innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  afficherTuilesCaisse();
  afficherPanier();
  el("caisseRecherche").focus();
}

function prixDe(article, uniteId) {
  const source = uniteId ? article.unites.find(u => u.id === uniteId) : article;
  return prixPanier === "Gros" && source.prix_gros ? source.prix_gros : source.prix_detail;
}

function afficherTuilesCaisse() {
  const mots = normaliser(el("caisseRecherche").value).split(/\s+/).filter(Boolean);
  const liste = articlesVente.filter(a => a.actif && (!mots.length || mots.every(m =>
    normaliser([a.nom, a.categorie, a.code_barres, ...a.unites.map(u => u.code_barres)].join(" ")).includes(m))));
  el("caisseTuiles").innerHTML = liste.map(a => {
    const etat = a.stock <= 0 ? "vide" : a.stock_bas ? "bas" : "ok";
    return `<button type="button" class="tuile-caisse etat-${etat}" onclick="ajouterAuPanier(${a.id})">
      <b>${esc(a.nom)}</b><span class="tc-prix">${formatMontant(prixDe(a, null))}<small> / ${esc(a.unite_base)}</small></span>
      <span class="tc-stock">${a.stock <= 0 ? "plus en stock" : esc(a.stock_texte)}</span></button>`;
  }).join("") || '<div class="card vide">Aucun article ne correspond.</div>';
}
el("caisseRecherche").addEventListener("input", afficherTuilesCaisse);
// Douchette : code + Entrée → l'article (ou son carton) va dans le panier
el("caisseRecherche").addEventListener("keydown", async e => {
  if (e.key !== "Enter") return;
  e.preventDefault();
  const texte = el("caisseRecherche").value.trim();
  if (!texte) return;
  if (/^\d{6,}$/.test(texte)) {
    try {
      const r = await api(`/api/articles/code/${encodeURIComponent(texte)}`);
      ajouterAuPanier(r.article.id, r.unite_id);
    } catch (err) { toast(err.message, 5000); }
  } else {
    const premier = el("caisseTuiles").querySelector(".tuile-caisse");
    if (premier) premier.click();
  }
  el("caisseRecherche").value = "";
  afficherTuilesCaisse();
});

// Appareil photo du téléphone : le code lu met l'article (ou son carton) dans le panier
function scannerCaisse() {
  scannerCodeBarres(async code => {
    try {
      const r = await api(`/api/articles/code/${encodeURIComponent(code)}`);
      ajouterAuPanier(r.article.id, r.unite_id);
      toast(`${r.article.nom} ajouté au panier`);
    } catch (e) { toast(e.message, 6000); }
  });
}

// ---------- Panier : un ticket de caisse ----------
// Une vente ordinaire = 2 touches : « Encaisser », puis « Compte juste » (ou le billet donné).

let remisePanier = 0;

function ajouterAuPanier(articleId, uniteId = null) {
  const ligne = panier.find(l => l.article_id === articleId && l.unite_id === uniteId);
  if (ligne) ligne.quantite += 1;
  else panier.push({ article_id: articleId, unite_id: uniteId, quantite: 1 });
  el("derniereVente").hidden = true;
  afficherPanier();
}

function totauxPanier() {
  const sousTotal = panier.reduce((s, l) => {
    const a = articlesVente.find(x => x.id === l.article_id);
    return s + Math.round(prixDe(a, l.unite_id) * l.quantite);
  }, 0);
  const remise = Math.min(remisePanier, sousTotal);
  return { sousTotal, remise, total: sousTotal - remise };
}

function afficherPanier() {
  el("panierLignes").innerHTML = panier.length ? panier.map((l, i) => {
    const a = articlesVente.find(x => x.id === l.article_id);
    const prix = prixDe(a, l.unite_id);
    const lots = [{ id: "", nom: a.unite_base }, ...a.unites.map(u => ({ id: u.id, nom: u.nom }))];
    const lot = lots.find(u => String(u.id) === String(l.unite_id ?? "")).nom;
    return `<div class="ticket-ligne">
      <div class="tl-qte"><button type="button" onclick="changerQuantitePanier(${i}, -1)" aria-label="Moins">−</button>
        <b>${nombre(l.quantite)}</b><button type="button" onclick="changerQuantitePanier(${i}, 1)" aria-label="Plus">+</button></div>
      <div class="tl-nom">${esc(a.nom)}${lots.length > 1
        ? ` <button type="button" class="tl-lot" onclick="changerLotPanier(${i})" data-tip="Changer : ${lots.map(u => esc(u.nom)).join(" / ")}">${esc(lot)} ▾</button>`
        : ""}<small>${formatMontant(prix)} × ${nombre(l.quantite)}</small></div>
      <b class="tl-total">${formatMontant(Math.round(prix * l.quantite))}</b></div>`;
  }).join("") : '<p class="ticket-vide">Touchez un article à gauche<br>(ou scannez-le) pour commencer.</p>';
  const t = totauxPanier();
  el("panierRemiseLigne").hidden = !t.remise;
  el("panierRemiseLigne").innerHTML = t.remise ? `<span>Remise</span><b>− ${formatMontant(t.remise)}</b>` : "";
  el("panierTotal").textContent = formatMontant(t.total);
  el("btnEncaisserVente").disabled = !panier.length;
  const nb = panier.reduce((s, l) => s + l.quantite, 0);
  el("btnVoirTicket").textContent = document.querySelector(".caisse-panier").classList.contains("ouvert")
    ? "Cacher le ticket" : `Voir le ticket${nb ? ` (${nombre(nb)} article${nb > 1 ? "s" : ""})` : ""}`;
  el("btnEncaisserVente").textContent = panier.length ? `Encaisser ${formatMontant(t.total)}` : "Encaisser";
}

// Téléphone : la barre du bas montre le total et « Encaisser » ; le ticket se déplie d'un toucher
function basculerTicket() {
  document.querySelector(".caisse-panier").classList.toggle("ouvert");
  afficherPanier();
}

function changerQuantitePanier(i, delta) {
  panier[i].quantite = Math.max(0, panier[i].quantite + delta);
  if (!panier[i].quantite) panier.splice(i, 1);
  afficherPanier();
}
// Le lot (bouteille → carton → …) change à chaque toucher
function changerLotPanier(i) {
  const a = articlesVente.find(x => x.id === panier[i].article_id);
  const lots = [null, ...a.unites.map(u => u.id)];
  panier[i].unite_id = lots[(lots.indexOf(panier[i].unite_id) + 1) % lots.length];
  afficherPanier();
}
function viderPanier() {
  panier = [];
  remisePanier = 0;
  afficherPanier();
}
document.querySelectorAll(".bascule-prix button").forEach(b => b.addEventListener("click", () => {
  prixPanier = b.dataset.prix;
  document.querySelectorAll(".bascule-prix button").forEach(x => x.classList.toggle("choisi", x === b));
  afficherTuilesCaisse();
  afficherPanier();
}));

function saisirRemise() {
  if (!panier.length) { toast("Ajoutez d'abord des articles."); return; }
  const t = totauxPanier();
  const fen = ouvrirFenetre(`<div class="modal-tete"><h3>Remise</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <p>Montant de la vente : <b>${formatMontant(t.sousTotal)}</b>${optionsVentes && !optionsVentes.est_admin ? ` — vous pouvez faire jusqu'à ${optionsVentes.remise_max} % seul` : ""}.</p>
    <div class="field"><label for="remMontant">Remise en francs</label><input id="remMontant" inputmode="numeric" value="${remisePanier ? formatNombre(remisePanier) : ""}" placeholder="ex : 500"></div>
    <div class="actions"><button class="btn" data-action="aucune">Pas de remise</button><button class="btn primary" data-action="ok">Appliquer</button></div>`, { taille: "" });
  const champ = fen.querySelector("#remMontant");
  champ.focus();
  const appliquer = valeur => { remisePanier = valeur; fen.fermer(); afficherPanier(); };
  fen.querySelector('[data-action="aucune"]').addEventListener("click", () => appliquer(0));
  fen.querySelector('[data-action="ok"]').addEventListener("click", () => {
    const m = lireMontant(champ.value || "0");
    if (m === null || m > t.sousTotal) { toast("Remise invalide (pas plus que le montant de la vente)."); return; }
    appliquer(m);
  });
  champ.addEventListener("keydown", e => { if (e.key === "Enter") fen.querySelector('[data-action="ok"]').click(); });
}

// ---------- Paiement : écran simple, gros boutons ----------

function billetsProposes(total) {
  const billets = [500, 1000, 2000, 5000, 10000, 20000, 50000].filter(b => b > total);
  return billets.slice(0, 4);
}

function ouvrirPaiementVente() {
  if (!panier.length) return;
  const t = totauxPanier();
  let mode = "Espèce", donne = t.total, credit = false;
  const fen = ouvrirFenetre(`<div class="paiement-caisse">
    <div class="modal-tete"><h3>Paiement</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <div class="afficheur grand"><span>À PAYER</span><b>${formatMontant(t.total)}</b></div>
    <div class="choix-mode">
      <button type="button" class="choisi" data-mode="Espèce">💵 Espèces</button>
      <button type="button" data-mode="Mobile Money">📱 Mobile Money</button>
      <button type="button" data-mode="Autre">Autre</button>
    </div>
    <div class="zone-especes">
      <p class="petit">Le client donne :</p>
      <div class="billets">
        <button type="button" class="choisi" data-donne="${t.total}">Compte juste</button>
        ${billetsProposes(t.total).map(b => `<button type="button" data-donne="${b}">${formatMontant(b)}</button>`).join("")}
        <input id="pcDonne" inputmode="numeric" placeholder="Autre montant" aria-label="Autre montant donné">
      </div>
      <div class="monnaie" id="pcMonnaie"></div>
    </div>
    <div class="zone-autre" hidden><label for="pcAutre">Mode</label><select id="pcAutre"><option>Virement</option><option>Chèque</option><option>Autre</option></select></div>
    <button type="button" class="lien-credit" data-action="credit">Le client ne paie pas tout (crédit) ›</button>
    <div class="zone-credit" hidden>
      <div class="fgrid">
        <div class="field large"><label for="pcClient">Client</label><div class="ligne-client"><select id="pcClient"></select>
          <button type="button" class="btn-sm" data-action="nouveauClient">+ Nouveau</button></div></div>
        <div class="field"><label for="pcPaye">Il paie maintenant (F)</label><input id="pcPaye" inputmode="numeric" placeholder="0"></div>
      </div>
      <div class="monnaie" id="pcReste"></div>
    </div>
    <div class="form-erreur" role="alert"></div>
    <button type="button" class="btn-encaisser" data-action="valider">Valider la vente</button>
  </div>`, { taille: "" });
  const $ = s => fen.querySelector(s);

  const remplirClients = choisi => {
    remplirSelect($("#pcClient"), clientsCommerce.filter(c => c.actif),
      { valeur: c => c.id, texte: c => c.nom + (c.doit > 0 ? ` (doit ${formatMontant(c.doit)})` : ""), vide: "— Choisir le client —" });
    if (choisi) $("#pcClient").value = choisi;
  };
  const maj = () => {
    $(".zone-especes").hidden = mode !== "Espèce" || credit;
    $(".zone-autre").hidden = mode !== "Autre";
    $("#pcMonnaie").innerHTML = donne >= t.total
      ? (donne > t.total ? `Monnaie à rendre<b>${formatMontant(donne - t.total)}</b>` : "Compte juste : rien à rendre")
      : `<span class="moins">Il manque ${formatMontant(t.total - donne)}</span>`;
    if (credit) {
      const paye = lireMontant($("#pcPaye").value || "0") || 0;
      $("#pcReste").innerHTML = paye <= t.total ? `Reste à crédit<b class="moins">${formatMontant(t.total - paye)}</b>` : '<span class="moins">Plus que le total</span>';
    }
  };
  fen.querySelectorAll("[data-mode]").forEach(b => b.addEventListener("click", () => {
    mode = b.dataset.mode;
    fen.querySelectorAll("[data-mode]").forEach(x => x.classList.toggle("choisi", x === b));
    maj();
  }));
  fen.querySelectorAll("[data-donne]").forEach(b => b.addEventListener("click", () => {
    donne = Number(b.dataset.donne);
    $("#pcDonne").value = "";
    fen.querySelectorAll("[data-donne]").forEach(x => x.classList.toggle("choisi", x === b));
    maj();
  }));
  $("#pcDonne").addEventListener("input", () => {
    const m = lireMontant($("#pcDonne").value);
    if (m !== null) { donne = m; fen.querySelectorAll("[data-donne]").forEach(x => x.classList.remove("choisi")); }
    maj();
  });
  $('[data-action="credit"]').addEventListener("click", () => {
    credit = !credit;
    $(".zone-credit").hidden = !credit;
    $('[data-action="credit"]').textContent = credit ? "‹ Le client paie tout" : "Le client ne paie pas tout (crédit) ›";
    if (credit) { remplirClients(); $("#pcClient").focus(); }
    maj();
  });
  $("#pcPaye").addEventListener("input", maj);
  $('[data-action="nouveauClient"]').addEventListener("click", () => nouveauClientCommerce(false, null, id => { remplirClients(String(id)); }));

  const valider = async (extra = {}) => {
    const erreur = $(".form-erreur");
    erreur.style.display = "none";
    let paye = t.total;
    if (credit) {
      paye = lireMontant($("#pcPaye").value || "0");
      if (paye === null || paye > t.total) { erreur.textContent = "Montant payé invalide."; erreur.style.display = "block"; return; }
      if (!$("#pcClient").value) { erreur.textContent = "Vente à crédit : choisissez le client (ou « + Nouveau »)."; erreur.style.display = "block"; return; }
    } else if (mode === "Espèce" && donne < t.total) {
      erreur.textContent = "Le montant donné ne suffit pas. Pour un crédit : « Le client ne paie pas tout »."; erreur.style.display = "block"; return;
    }
    const modePaiement = mode === "Autre" ? $("#pcAutre").value : mode;
    const corps = {
      prix_applique: prixPanier, lignes: panier.map(l => ({ article_id: l.article_id, unite_id: l.unite_id, quantite: l.quantite })),
      remise: t.remise, paye, mode_paiement: modePaiement,
      client_id: credit && $("#pcClient").value ? Number($("#pcClient").value) : null, ...extra,
    };
    $('[data-action="valider"]').disabled = true;
    try {
      const r = await api("/api/ventes", { method: "POST", body: corps });
      fen.fermer();
      const rendu = !credit && mode === "Espèce" ? donne - t.total : 0;
      viderPanier();
      await chargerBasesVente();
      afficherTuilesCaisse();
      venteTerminee(r, rendu);
    } catch (e) {
      $('[data-action="valider"]').disabled = false;
      if (/^Remise de plus de/.test(e.message)) {
        const confirmation = await demanderConfirmationAdmin(e.message);
        if (confirmation) return valider({ ...extra, confirmation_admin: confirmation });
      } else if (/quand même \(Admin\)/.test(e.message)) {
        if (await confirmerAction("Vendre sans stock", `${e.message} Le stock passera en négatif : pensez à saisir l'arrivage oublié.`, "Vendre quand même")) {
          return valider({ ...extra, forcer_stock: true });
        }
      } else { erreur.textContent = e.message; erreur.style.display = "block"; }
    }
  };
  $('[data-action="valider"]').addEventListener("click", () => valider());
  fen.addEventListener("keydown", e => { if (e.key === "Enter" && e.target.tagName !== "SELECT") { e.preventDefault(); valider(); } });
  maj();
  $('[data-action="valider"]').focus();
}

// Après la vente : un bandeau discret sous le ticket (pas de fenêtre à fermer), on enchaîne la vente suivante
function venteTerminee(r, rendu) {
  const zone = el("derniereVente");
  zone.hidden = false;
  zone.className = `derniere-vente ${r.reste > 0 ? "credit" : "ok"}`;
  zone.innerHTML = `<b>✓ Vente ${esc(r.numero)} enregistrée</b>
    ${rendu > 0 ? `<span class="rendu">Monnaie à rendre : <b>${formatMontant(rendu)}</b></span>` : ""}
    ${r.reste > 0 ? `<span>Reste à crédit : <b>${formatMontant(r.reste)}</b></span>` : ""}
    ${r.provisoire ? '<span class="petit">Bon provisoire, enregistré sur ce téléphone : la vente part au serveur à son retour (ticket et facture ensuite).</span>' : ""}
    <span class="dv-boutons"${r.provisoire ? " hidden" : ""}>
      <button type="button" class="btn-sm" onclick="ouvrirTicket(${r.id}, ${rendu > 0 ? r.total + rendu : 0})">🧾 Ticket</button>
      <button type="button" class="btn-sm" onclick="ouvrirFacture(${r.id})">Facture</button>
      <button type="button" class="btn-sm wa" onclick="ticketWhatsApp(${r.id})">WhatsApp</button>
      <button type="button" class="btn-sm" onclick="montrerOngletVentes('veHistorique'); setTimeout(() => FICHES.vente(${r.id}), 400)">Voir la vente</button>
    </span>`;
  el("caisseRecherche").focus();
}

function confirmerAction(titre, texte, bouton) {
  return new Promise(resolve => {
    const fen = ouvrirFenetre(`<div class="modal-tete"><h3>${esc(titre)}</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
      <p>${esc(texte)}</p><div class="actions"><button class="btn" data-fermer>Annuler</button><button class="btn primary" data-action="ok">${esc(bouton)}</button></div>`, { taille: "" });
    let oui = false;
    fen.querySelector('[data-action="ok"]').addEventListener("click", () => { oui = true; fen.fermer(); });
    fen.addEventListener("fermee", () => resolve(oui));
  });
}

function demanderConfirmationAdmin(message) {
  return new Promise(resolve => {
    const fen = ouvrirFenetre(`<div class="modal-tete"><h3>Confirmation de l'Admin</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
      <p>${esc(message)}</p>
      <div class="field"><label for="caIdent">Identifiant de l'Admin</label><input id="caIdent" autocomplete="off"></div>
      <div class="field"><label for="caMdp">Son mot de passe</label><input id="caMdp" type="password" autocomplete="off"></div>
      <div class="actions"><button class="btn" data-fermer>Annuler</button><button class="btn primary" data-action="ok">Confirmer la remise</button></div>`, { taille: "" });
    let valeur = null;
    fen.querySelector('[data-action="ok"]').addEventListener("click", () => {
      valeur = { identifiant: fen.querySelector("#caIdent").value.trim(), mot_de_passe: fen.querySelector("#caMdp").value };
      if (!valeur.identifiant || !valeur.mot_de_passe) { toast("Identifiant et mot de passe de l'Admin."); valeur = null; return; }
      fen.fermer();
    });
    fen.addEventListener("fermee", () => resolve(valeur));
    fen.querySelector("#caIdent").focus();
  });
}


// ---------- Documents : ticket (80 mm), facture A4, reçu ; ticket par WhatsApp ----------

function ouvrirTicket(id, donne = 0) { window.open(`/api/ventes/${id}/ticket${donne ? `?donne=${donne}` : ""}`, "_blank"); }
function ouvrirFacture(id) { window.open(`/api/ventes/${id}/facture`, "_blank"); }
function ouvrirRecuReglement(id) { window.open(`/api/reglements-ventes/${id}/recu`, "_blank"); }

// WhatsApp n'accepte pas de pièce jointe par lien : on envoie le ticket en texte, bien présenté
async function ticketWhatsApp(id) {
  let v = ventesCache.find(x => x.id === id);
  if (!v) {
    try { v = (await api(`/api/ventes?debut=${aujourdhui().slice(0, 8)}01`)).find(x => x.id === id); } catch { v = null; }
  }
  if (!v) { toast("Vente introuvable."); return; }
  const lignes = v.lignes.map(l => `• ${nombre(l.quantite)} ${l.unite} ${l.article} : ${formatMontant(l.total)}`).join("\n");
  const texte = `${nomEntreprise()}\nTicket ${v.numero} du ${formatDate(v.date)}\n\n${lignes}\n`
    + (v.remise ? `Remise : − ${formatMontant(v.remise)}\n` : "") + `*TOTAL : ${formatMontant(v.total)}*\n`
    + (v.reste > 0 ? `Payé : ${formatMontant(v.recu)} — reste à payer : ${formatMontant(v.reste)}\n` : "Payé. ")
    + "Merci de votre visite !";
  ouvrirWhatsAppTexte(v.client_telephone || "", texte);
}

// ---------- Historique des ventes ----------

async function chargerVentes() {
  const zone = el("listeVentes");
  if (!el("veDebut").value) fixerDate("veDebut", aujourdhui().slice(0, 8) + "01");
  if (!el("veFin").value) fixerDate("veFin", aujourdhui());
  try {
    const p = new URLSearchParams();
    const debut = valeurDate("veDebut", "Du"), fin = valeurDate("veFin", "Au");
    if (debut) p.set("debut", debut);
    if (fin) p.set("fin", fin);
    [ventesCache] = await Promise.all([api("/api/ventes?" + p), optionsVentes ? null : chargerBasesVente()]);
  } catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  const valides = ventesCache.filter(v => v.statut === "Validée");
  const jour = valides.filter(v => v.date === aujourdhui());
  const somme = (liste, champ) => liste.reduce((s, v) => s + (v[champ] || 0), 0);
  el("resumeVentes").innerHTML = [
    `<div class="chiffre-cle calme statique"><span class="cc-chiffre">${formatMontant(somme(jour, "total"))}</span><span class="cc-libelle">Ventes d'aujourd'hui</span><span class="cc-aide">${jour.length} vente${jour.length > 1 ? "s" : ""}</span></div>`,
    `<div class="chiffre-cle neutre statique"><span class="cc-chiffre">${formatMontant(somme(valides, "total"))}</span><span class="cc-libelle">Sur la période</span><span class="cc-aide">${valides.length} vente${valides.length > 1 ? "s" : ""}</span></div>`,
    `<div class="chiffre-cle ${somme(valides, "reste") ? "alerte" : "calme"} statique"><span class="cc-chiffre">${formatMontant(somme(valides, "reste"))}</span><span class="cc-libelle">Reste à encaisser</span><span class="cc-aide">ventes à crédit</span></div>`,
    optionsVentes && optionsVentes.voit_achats ? `<div class="chiffre-cle calme statique"><span class="cc-chiffre">${formatMontant(somme(valides, "benefice"))}</span><span class="cc-libelle">Bénéfice</span><span class="cc-aide">sur la période</span></div>` : "",
  ].join("");
  zone.innerHTML = ventesCache.length ? `<div class="card">${ventesCache.map(v => {
    const code = v.statut === "Annulée" ? "termine" : v.reste > 0 ? "retard" : "a_jour";
    return `<div class="row row-fiche etat-${code}" data-fiche="vente:${v.id}" tabindex="0"${motsCles({ tel: [v.client_telephone], textes: [v.numero, ...v.lignes.map(l => l.article)] })}>
      <span class="who"><b>${esc(v.client)}</b> — ${formatMontant(v.total)}${v.reste > 0 ? ` — <b class="moins">reste ${formatMontant(v.reste)}</b>` : ""}
        <br><span class="petit">${esc(v.numero)} · ${formatDate(v.date)} · ${esc(v.lignes.map(l => `${nombre(l.quantite)} ${l.unite} ${l.article}`).join(", "))}${v.vendu_par ? " · " + esc(v.vendu_par) : ""}</span></span>
      <span class="boutons"><span class="pill ${ETATS_IMMO[code].pill}">${v.statut === "Annulée" ? "Annulée" : v.reste > 0 ? "Crédit" : "Payée"}</span></span></div>`;
  }).join("")}</div>` : '<div class="card vide">Aucune vente sur cette période.</div>';
  el("rechercheVentes").dispatchEvent(new Event("input"));
}
brancherRecherche(el("rechercheVentes"), el("listeVentes"));

// Encaisser une somme sur une vente ou pour un client (remboursement d'un crédit)
async function encaisserReglement(url, reste, titre, apres) {
  const fen = ouvrirFenetre(`<div class="modal-tete"><h3>${esc(titre)}</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <p>Il doit : <b>${formatMontant(reste)}</b></p>
    <div class="fgrid">
      <div class="field"><label for="rgMontant">Montant reçu (F)</label><input id="rgMontant" inputmode="numeric" value="${formatNombre(reste)}"></div>
      <div class="field"><label for="rgMode">Mode</label><select id="rgMode"></select></div>
      <div class="field"><label for="rgCompte">Encaissé sur</label><select id="rgCompte"></select></div>
    </div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div>`);
  remplirSelect(fen.querySelector("#rgMode"), optionsVentes ? optionsVentes.modes_paiement : ["Espèce", "Mobile Money", "Virement", "Chèque", "Autre"]);
  await preparerChoixCompte("rgMode", "rgCompte");
  fen.querySelector('[data-action="ok"]').addEventListener("click", async () => {
    const zone = fen.querySelector(".form-erreur");
    try {
      const m = lireMontant(fen.querySelector("#rgMontant").value);
      if (!m) throw new Error("Montant invalide.");
      const r = await api(url, { method: "POST", body: { montant: m, mode_paiement: fen.querySelector("#rgMode").value, compte_id: compteChoisi("rgCompte") } });
      toast(r.reste > 0 ? `Enregistré : il doit encore ${formatMontant(r.reste)}` : "Enregistré : il ne doit plus rien 👍", 5000);
      fen.fermer();
      apres();
    } catch (err) { zone.textContent = err.message; zone.style.display = "block"; }
  });
}

async function annulerVente(v) {
  const motif = await new Promise(resolve => {
    const f = ouvrirFenetre(`<div class="modal-tete"><h3>Annuler la vente ${esc(v.numero)}</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
      <p>La marchandise revient en stock${v.recu ? ` et <b>${formatMontant(v.recu)}</b> sont rendus au client (sortie de caisse aujourd'hui)` : ""}.</p>
      <div class="field"><label for="avMotifV">Pourquoi ?</label><input id="avMotifV" maxlength="300" placeholder="ex : client a rendu la marchandise"></div>
      <div class="actions"><button class="btn" data-fermer>Retour</button><button class="btn primary" data-action="ok">Continuer</button></div>`, { taille: "" });
    let choisi = null;
    f.querySelector('[data-action="ok"]').addEventListener("click", () => {
      const t = f.querySelector("#avMotifV").value.trim();
      if (t.length < 3) { toast("Indiquez le motif."); return; }
      choisi = t; f.fermer();
    });
    f.addEventListener("fermee", () => resolve(choisi));
  });
  if (!motif) return;
  const mdp = await demanderMotDePasseAdmin(`Annuler la vente ${v.numero} ? Entrez votre mot de passe.`, { titre: "Annuler la vente", bouton: "Annuler la vente" });
  if (!mdp) return;
  try {
    await api(`/api/ventes/${v.id}/annuler`, { method: "POST", body: { mot_de_passe_admin: mdp, motif } });
    toast("Vente annulée : la marchandise est revenue en stock", 5000);
    chargerVentes();
  } catch (e) { toast(e.message, 7000); }
}

// ---------- Clients ----------

async function chargerClientsCommerce() {
  const zone = el("listeClientsCommerce");
  try { await chargerBasesVente(); } catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  const doivent = clientsCommerce.filter(c => c.doit > 0);
  el("resumeClients").innerHTML = [
    `<div class="chiffre-cle neutre statique"><span class="cc-chiffre">${clientsCommerce.length}</span><span class="cc-libelle">Clients</span><span class="cc-aide">enregistrés</span></div>`,
    `<div class="chiffre-cle ${doivent.length ? "alerte" : "calme"} statique"><span class="cc-chiffre">${formatMontant(doivent.reduce((s, c) => s + c.doit, 0))}</span>
      <span class="cc-libelle">Ce que les clients doivent</span><span class="cc-aide">${doivent.length} client${doivent.length > 1 ? "s" : ""} à crédit</span></div>`,
  ].join("");
  const tries = [...clientsCommerce].sort((a, b) => b.doit - a.doit || a.nom.localeCompare(b.nom));
  zone.innerHTML = tries.length ? `<div class="card">${tries.map(c => `
    <div class="row row-fiche etat-${!c.actif ? "termine" : c.doit > 0 ? (c.plafond_credit !== null && c.doit >= c.plafond_credit ? "a_risque" : "retard") : "a_jour"}" data-fiche="clientc:${c.id}" tabindex="0"${motsCles({ tel: [c.telephone], textes: [c.adresse] })}>
      <span class="who"><b>${esc(c.nom)}</b>${c.telephone ? " — " + esc(c.telephone) : ""}
        <br><span class="petit">${c.doit > 0 ? `<b class="moins">doit ${formatMontant(c.doit)}</b>` : "ne doit rien"}${c.plafond_credit !== null ? ` · plafond ${formatMontant(c.plafond_credit)}` : ""}${c.adresse ? " · " + esc(c.adresse) : ""}</span></span>
      <span class="boutons">${c.doit > 0 ? `<button class="btn-sm" onclick="encaisserReglement('/api/clients-commerce/${c.id}/reglements', ${c.doit}, 'Paiement de ${esc(c.nom).replace(/'/g, "&#39;")}', chargerClientsCommerce)">Il paie</button>` : ""}</span>
    </div>`).join("")}</div>` : '<div class="card vide">Aucun client enregistré. Un client est nécessaire pour vendre à crédit.</div>';
  el("rechercheClientsCommerce").dispatchEvent(new Event("input"));
}
brancherRecherche(el("rechercheClientsCommerce"), el("listeClientsCommerce"));

function nouveauClientCommerce(depuisCaisse, client = null, apres = null) {
  const admin = optionsVentes && optionsVentes.est_admin;
  const fen = ouvrirFenetre(`<div class="modal-tete"><h3>${client ? "Modifier le client" : "Nouveau client"}</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <div class="fgrid">
      <div class="field large"><label for="ccNom">Nom</label><input id="ccNom" maxlength="150" value="${esc(client ? client.nom : "")}"></div>
      <div class="field"><label for="ccTel">Téléphone</label><input id="ccTel" inputmode="tel" maxlength="30" value="${esc(client ? client.telephone : "")}"></div>
      <div class="field"><label for="ccAdresse">Adresse (facultatif)</label><input id="ccAdresse" maxlength="200" value="${esc(client ? client.adresse : "")}"></div>
      ${admin ? `<div class="field"><label for="ccPlafond">Plafond de crédit (F, vide = sans plafond)</label><input id="ccPlafond" inputmode="numeric" value="${client && client.plafond_credit !== null ? formatNombre(client.plafond_credit) : ""}"></div>` : ""}
      <div class="field large"><label for="ccNote">Note (facultatif)</label><input id="ccNote" maxlength="500" value="${esc(client ? client.note : "")}"></div>
    </div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="ok">Enregistrer</button></div>`);
  fen.querySelector("#ccNom").focus();
  fen.querySelector('[data-action="ok"]').addEventListener("click", async () => {
    const zone = fen.querySelector(".form-erreur");
    try {
      const nom = fen.querySelector("#ccNom").value.trim();
      if (nom.length < 2) throw new Error("Indiquez le nom du client.");
      const champPlafond = fen.querySelector("#ccPlafond");
      const plafond = champPlafond && champPlafond.value.trim() ? lireMontant(champPlafond.value) : null;
      if (champPlafond && champPlafond.value.trim() && plafond === null) throw new Error("Plafond invalide.");
      const corps = { nom, telephone: fen.querySelector("#ccTel").value.trim() || null, adresse: fen.querySelector("#ccAdresse").value.trim() || null,
                      note: fen.querySelector("#ccNote").value.trim() || null, plafond_credit: plafond, actif: client ? client.actif : true };
      const r = client ? await api(`/api/clients-commerce/${client.id}`, { method: "PUT", body: corps })
                       : await api("/api/clients-commerce", { method: "POST", body: corps });
      fen.fermer();
      toast("Client enregistré");
      await chargerBasesVente();
      if (apres) apres(r.id); else chargerClientsCommerce();
    } catch (err) { zone.textContent = err.message; zone.style.display = "block"; }
  });
}

// ---------- Fiches (registre de fiches.js, chargé après ce script) ----------

window.addEventListener("load", () => {
  if (typeof FICHES === "undefined") return;
  FICHES.vente = id => {
    const v = ventesCache.find(x => x.id === id);
    if (!v) return;
    const code = v.statut === "Annulée" ? "termine" : v.reste > 0 ? "retard" : "a_jour";
    ficheSimple({
      titre: v.client, sous: `Vente ${esc(v.numero)} · ${formatDate(v.date)}${v.vendu_par ? " · vendue par " + esc(v.vendu_par) : ""} · prix ${esc(v.prix_applique.toLowerCase())}`,
      code, etat: v.statut === "Annulée" ? "Annulée" : v.reste > 0 ? "Vente à crédit" : "Payée", grand: formatMontant(v.total),
      aide: v.statut === "Annulée" ? `Annulée : ${esc(v.motif_annulation)}${v.rembourse ? ` · ${formatMontant(v.rembourse)} rendus` : ""}`
        : v.reste > 0 ? `Reste à payer : ${formatMontant(v.reste)}` : "",
      stats: [["Sous-total", formatMontant(v.sous_total)], v.remise ? ["Remise", formatMontant(v.remise), "", "negatif"] : null,
              ["Déjà reçu", formatMontant(v.recu)], v.benefice !== undefined ? ["Bénéfice", formatMontant(v.benefice), "", v.benefice >= 0 ? "positif" : "negatif"] : null],
      sections: [{ titre: "Articles", html: `<div class="fa-tableau"><table><thead><tr><th>Article</th><th>Quantité</th><th>Prix</th><th>Total</th></tr></thead><tbody>
          ${v.lignes.map(l => `<tr><td><b>${esc(l.article)}</b></td><td>${nombre(l.quantite)} ${esc(l.unite)}</td><td>${formatMontant(l.prix_unitaire)}</td><td>${formatMontant(l.total)}</td></tr>`).join("")}</tbody></table></div>` },
                 { titre: "Paiements reçus", html: v.reglements.length ? `<div class="fa-liste">${v.reglements.map(x => `
          <button class="fa-ligne cliquable" onclick="ouvrirRecuReglement(${x.id})" data-tip="Reçu de ce paiement (PDF)"><span>${formatDate(x.date)} — ${esc(x.numero)} <small>· ${esc(x.mode_paiement)}${x.a_la_vente ? " · à la vente" : " · reçu ›"}</small></span><b class="plus">${formatMontant(x.montant)}</b></button>`).join("")}</div>` : "" }],
      actions: [{ libelle: "🧾 Ticket", fn: () => ouvrirTicket(v.id) }, { libelle: "Facture", fn: () => ouvrirFacture(v.id) },
                v.statut === "Validée" ? { libelle: "WhatsApp", fn: () => ticketWhatsApp(v.id) } : null,
                optionsVentes && optionsVentes.peut_annuler && v.statut === "Validée" ? { libelle: "Annuler la vente", discret: true, fn: () => annulerVente(v) } : null,
                v.reste > 0 ? { libelle: "Encaisser le reste", principal: true, fn: () => encaisserReglement(`/api/ventes/${v.id}/reglements`, v.reste, `Paiement — vente ${v.numero}`, chargerVentes) } : null],
    });
  };
  FICHES.clientc = async id => {
    const c = clientsCommerce.find(x => x.id === id);
    if (!c) return;
    let ventes = [];
    try { ventes = await api(`/api/ventes?client_id=${id}`); } catch { /* fiche sans historique */ }
    const credit = ventes.filter(v => v.statut === "Validée" && v.reste > 0);
    ficheSimple({
      titre: c.nom, sous: [c.telephone ? lienTel(c.telephone) : "", c.adresse ? esc(c.adresse) : ""].filter(Boolean).join(" · "),
      code: c.doit > 0 ? (c.plafond_credit !== null && c.doit >= c.plafond_credit ? "a_risque" : "retard") : "a_jour",
      etat: c.doit > 0 ? "Il doit" : "À jour", grand: c.doit > 0 ? formatMontant(c.doit) : "Ne doit rien",
      aide: c.plafond_credit !== null ? `Plafond de crédit : ${formatMontant(c.plafond_credit)}` : "Pas de plafond de crédit",
      stats: [["Achats", ventes.filter(v => v.statut === "Validée").length], ["Total acheté", formatMontant(ventes.filter(v => v.statut === "Validée").reduce((s, v) => s + v.total, 0))],
              credit.length ? ["Ventes à crédit", credit.length, "pas encore soldées", "negatif"] : null],
      sections: [{ titre: "Ventes non soldées", html: credit.length ? `<div class="fa-liste">${credit.map(v => `
          <div class="fa-ligne"><span>${formatDate(v.date)} — ${esc(v.numero)} <small>· total ${formatMontant(v.total)}</small></span><b class="moins">reste ${formatMontant(v.reste)}</b></div>`).join("")}</div>` : "" },
                 { titre: "Note", html: texteLibre(c.note) }],
      actions: [c.telephone && c.doit > 0 ? { libelle: "Relancer (WhatsApp)", fn: () => ouvrirWhatsAppTexte(c.telephone,
                  `Bonjour ${c.nom}, sauf erreur de notre part, il reste ${formatMontant(c.doit).replace(" F", " FCFA")} à régler à ${nomEntreprise()}. Merci de passer nous voir. Bonne journée !`) } : null,
                { libelle: "Modifier", fn: () => nouveauClientCommerce(false, c) },
                c.doit > 0 ? { libelle: "Il paie", principal: true, fn: () => encaisserReglement(`/api/clients-commerce/${c.id}/reglements`, c.doit, `Paiement de ${c.nom}`, chargerClientsCommerce) } : null],
    });
  };
});
