// Espaces (14/11/2026, décision de Boss) : les écrans sont regroupés par métier en « espaces » à tuiles, comme
// Paramètres. Le menu et l'accueil n'affichent que les espaces de la licence ; chaque espace ne montre que les tuiles
// permises au profil. Les écrans eux-mêmes ne changent pas, et le serveur vérifie toujours les droits module par module.
// Une tuile = un écran (et éventuellement une de ses rubriques, comme Boutique → Arrivages).

const ICONES_ESPACES = {
  patrimoine: '<path d="M3 21V9l9-6 9 6v12"/><path d="M9 21v-6h6v6"/><path d="M3 21h18"/>',
  locations: '<path d="M15 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0z"/><path d="M3 21v-1a6 6 0 0 1 9-5.2"/><path d="M14 17h7M17.5 13.5V21"/>',
  loyers: '<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
  boutique: '<path d="M4 9h16l-1.5-5h-13z"/><path d="M5 9v11h14V9"/><path d="M9 20v-6h6v6"/>',
  mobile_money: '<rect x="6" y="2" width="12" height="20" rx="2.5"/><path d="M10 18h4"/><path d="M9.5 8.5 12 6l2.5 2.5"/><path d="M12 6v7"/>',
  argent: '<rect x="2" y="6" width="20" height="13" rx="2"/><path d="M2 10h20"/><path d="M6 15h3"/><path d="M16 3 12 6 8 3"/>',
  rapports: '<path d="M4 20V11"/><path d="M10 20V5"/><path d="M16 20v-7"/><path d="M22 20H2"/>',
  agenda: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
};
const pasProfil = role => moi && moi.role !== role;
const ESPACES = [
  { id: "patrimoine", menu: "Patrimoine", desc: "Biens, propriétaires, achats et ventes de biens", groupe: "Immobilier", couleur: "#4c8a4a", teinte: "#e5f1e3", items: [
    { libelle: "Biens et logements", ecran: "biens", module: "biens" },
    { libelle: "Propriétaires", ecran: "proprietaires", module: "proprietaires" },
    { libelle: "Achats / ventes de biens", ecran: "achats_ventes", module: "achats_ventes" },
    { libelle: "Problèmes signalés", ecran: "problemes", module: "biens" } ] },
  { id: "locations", menu: "Locations", desc: "Contrats, locataires, courte durée, états des lieux, courriers", groupe: "Immobilier", couleur: "#2f6690", teinte: "#e4eef6", items: [
    { libelle: "Contrats", ecran: "contrats", module: "contrats" },
    { libelle: "Locataires", ecran: "locataires", module: "locataires" },
    { libelle: "Courte durée", ecran: "sejours", module: "sejours" },
    { libelle: "États des lieux", ecran: "etats_des_lieux", module: "etats_des_lieux" },
    { libelle: "Courriers", ecran: "courriers", module: "courriers" } ] },
  { id: "loyers", menu: "Loyers", desc: "Encaissements, impayés, relances et historique", groupe: "Immobilier", couleur: "#1f7a6d", teinte: "#dff1ee", items: [
    { libelle: "Encaissements et impayés", ecran: "paiements", module: "paiements" },
    { libelle: "Historique des paiements", ecran: "historique", module: "paiements" },
    { libelle: "Messages groupés", ecran: "messagesGroupes", module: "paiements" } ] },
  { id: "boutique", menu: "Boutique", desc: "Caisse, ventes, clients, articles et stock", groupe: "Commerce", couleur: "#7a5c2e", teinte: "#f3ebdd", items: [
    { libelle: "Caisse", ecran: "ventes", onglet: "veCaisse", module: "ventes" },
    { libelle: "Ventes", ecran: "ventes", onglet: "veHistorique", module: "ventes" },
    { libelle: "Clients", ecran: "ventes", onglet: "veClients", module: "ventes" },
    { libelle: "Articles et stock", ecran: "stock", onglet: "stArticles", module: "stock" },
    { libelle: "Arrivages", ecran: "stock", onglet: "stArrivages", module: "stock" },
    { libelle: "Sorties et inventaire", ecran: "stock", onglet: "stSorties", module: "stock", si: () => pasProfil("Caisse") },
    { libelle: "Fournisseurs", ecran: "stock", onglet: "stFournisseurs", module: "stock" },
    { libelle: "Ce que je dois", ecran: "stock", onglet: "stDettes", module: "stock", si: () => pasProfil("Gestionnaire") } ] },
  { id: "mobile_money", menu: "Mobile Money", desc: "Guichet, soldes des puces, clôture, commissions", groupe: "Mobile Money", couleur: "#ff7900", teinte: "#fff0e2", items: [
    { libelle: "Guichet", ecran: "mobile_money", onglet: "mmGuichet", module: "mobile_money" },
    { libelle: "Opérations", ecran: "mobile_money", onglet: "mmOperations", module: "mobile_money" },
    { libelle: "Clôture du soir", ecran: "mobile_money", onglet: "mmCloture", module: "mobile_money", si: () => pasProfil("Comptable") },
    { libelle: "Commissions", ecran: "mobile_money", onglet: "mmCommissions", module: "mobile_money" },
    { libelle: "Réglages", ecran: "mobile_money", onglet: "mmReglages", module: "mobile_money", si: () => estAdmin() } ] },
  { id: "argent", menu: "Argent", desc: "Trésorerie, dépenses, reversements, comptabilité", groupe: "Argent et chiffres", couleur: "#2f6690", teinte: "#e4eef6", items: [
    { libelle: "Soldes des comptes", ecran: "tresorerie", onglet: "trSoldes", module: "tresorerie" },
    { libelle: "Dépenses", ecran: "depenses", module: "depenses" },
    { libelle: "Journal", ecran: "tresorerie", onglet: "trJournal", module: "tresorerie" },
    { libelle: "Transferts", ecran: "tresorerie", onglet: "trTransferts", module: "tresorerie" },
    { libelle: "Arrêtés de caisse", ecran: "tresorerie", onglet: "trArretes", module: "tresorerie" },
    { libelle: "Reversements", ecran: "tresorerie", onglet: "trReversements", module: "tresorerie", si: () => peut("paiements") || peut("achats_ventes") },
    { libelle: "Carnet de RIB", ecran: "tresorerie", onglet: "trCarnet", module: "tresorerie" },
    { libelle: "Rapprochement bancaire", ecran: "tresorerie", onglet: "trRapprochement", module: "tresorerie" },
    { libelle: "Résultat et TVA", ecran: "rapports", onglet: "rapResultat", module: "rapports", si: () => peut("comptabilite") },
    { libelle: "Comptes", ecran: "tresorerie", onglet: "trComptes", module: "tresorerie", si: () => estAdmin() } ] },
  { id: "rapports", menu: "Rapports", desc: "Statistiques, rapports et bilans de chaque métier", groupe: "Argent et chiffres", couleur: "#1d3b53", teinte: "#e3e9ef", items: [
    { libelle: "Statistiques des loyers", ecran: "rapports", onglet: "rapGraphiques", module: "rapports" },
    { libelle: "Rapport détaillé", ecran: "rapports", onglet: "rapDetail", module: "rapports" },
    { libelle: "Rapport par bien", ecran: "rapports", onglet: "rapBien", module: "rapports" },
    { libelle: "Bilan de la boutique", ecran: "bilan_commerce", module: "bilan_commerce" },
    { libelle: "Commissions Mobile Money", ecran: "mobile_money", onglet: "mmCommissions", module: "mobile_money", sans: true } ] },
  { id: "agenda", menu: "Agenda", desc: "Rendez-vous, demandes de clients, annonces", groupe: "Outils", couleur: "#4c8a4a", teinte: "#e5f1e3", items: [
    { libelle: "Agenda", ecran: "agenda", onglet: "ongletAgenda", module: "agenda" },
    { libelle: "Demandes de clients", ecran: "agenda", onglet: "ongletClients", module: "prospects" },
    { libelle: "Réseaux sociaux", ecran: "reseaux_sociaux", module: "reseaux_sociaux" } ] },
];

// Rubrique d'un écran à onglets : l'écran la retient dans sa variable, et l'ouvre à son chargement
const CHOISIR_ONGLET = {
  tresorerie: id => { ongletTresorerie = id; }, stock: id => { ongletStock = id; }, ventes: id => { ongletVentes = id; },
  mobile_money: id => { ongletMM = id; }, rapports: id => { ongletRapports = id; },
};

const itemVisible = it => peut(it.module) && (!it.si || it.si());
const itemsVisibles = e => e.items.filter(itemVisible);
const espaceVisible = e => itemsVisibles(e).length > 0;
// « sans » : tuile d'un autre espace (les commissions apparaissent aussi dans Rapports) ; elle ne décide pas de l'espace
function espaceDe(ecran, onglet) {
  return ESPACES.find(e => e.items.some(i => !i.sans && i.ecran === ecran && (!i.onglet || !onglet || i.onglet === onglet)))
    || ESPACES.find(e => e.items.some(i => !i.sans && i.ecran === ecran));
}
let espaceCourant = null;

function ongletActif(section) {
  const b = section && section.querySelector(":scope .onglets-internes .onglet.actif");
  return b ? b.dataset.onglet : null;
}

async function ouvrirItem(it, espaceId) {
  espaceCourant = espaceId;
  if (it.onglet && CHOISIR_ONGLET[it.ecran]) CHOISIR_ONGLET[it.ecran](it.onglet);
  const section = el(it.ecran);
  const dejaLa = section && section.classList.contains("active");
  if (!dejaLa) {
    const ok = await afficher(it.ecran);
    if (ok === false) return;
  }
  if (it.onglet) {   // rubrique de l'écran (bouton caché, son code habituel fait le reste)
    const b = section.querySelector(`.onglets-internes [data-onglet="${it.onglet}"]`);
    if (b && (dejaLa || !CHOISIR_ONGLET[it.ecran])) b.click();
  }
  majEspace(it.ecran);
  closeMenu && closeMenu();
}

function ouvrirEspace(id) {
  const e = ESPACES.find(x => x.id === id);
  const it = e && itemsVisibles(e)[0];
  if (it) ouvrirItem(it, id);
  else toast("Cet espace ne fait pas partie de votre licence ou de votre profil.");
}

// Prépare un écran d'espace : colonne de tuiles de l'espace à gauche, le reste à droite sous un grand titre
function preparerSection(section) {
  if (section.dataset.espacePret) return;
  section.dataset.espacePret = "1";
  if (!section.classList.contains("ecran-windows")) {
    section.classList.add("ecran-windows");
    const contenu = document.createElement("div");
    contenu.className = "par-contenu";
    const titre = document.createElement("h2");
    titre.className = "par-titre";
    contenu.appendChild(titre);
    [...section.children].forEach(x => contenu.appendChild(x));
    section.appendChild(contenu);
  }
  const propres = section.querySelector(":scope > .onglets, :scope > .par-contenu > .onglets");
  if (propres) propres.classList.add("onglets-internes");
  const nav = document.createElement("nav");
  nav.className = "onglets onglets-windows espace-nav";
  nav.setAttribute("aria-label", "Rubriques");
  section.insertBefore(nav, section.firstChild);
  // un changement de rubrique fait par l'écran lui-même (lien interne…) : la tuile suit
  if (propres) new MutationObserver(() => { if (section.classList.contains("active")) majEspace(section.id, true); })
    .observe(propres, { subtree: true, attributes: true, attributeFilter: ["class"] });
}

function majEspace(ecran, silencieux = false) {
  const section = el(ecran);
  const onglet = ongletActif(section);
  let e = ESPACES.find(x => x.id === espaceCourant);
  if (!e || !e.items.some(i => i.ecran === ecran)) e = espaceDe(ecran, onglet);
  // la rubrique ouverte appartient à un autre espace (ex. Résultat et TVA, rangé dans Argent) : c'est lui qu'on montre
  else if (onglet && !e.items.some(i => i.ecran === ecran && (!i.onglet || i.onglet === onglet))) e = espaceDe(ecran, onglet) || e;
  if (!section || !e) return;
  espaceCourant = e.id;
  preparerSection(section);
  const visibles = itemsVisibles(e);
  const actif = visibles.find(i => i.ecran === ecran && (!i.onglet || i.onglet === onglet)) || visibles.find(i => i.ecran === ecran);
  const nav = section.querySelector(":scope > .espace-nav");
  nav.innerHTML = visibles.map((it, i) => `<button type="button" class="onglet${it === actif ? " actif" : ""}" data-item="${i}">
    <svg class="par-ico" viewBox="0 0 24 24" aria-hidden="true">${ICONES_ONGLETS[it.onglet] || ICONES_ESPACES[e.id]}</svg><span class="ow-texte">${esc(it.libelle)}</span></button>`).join("");
  nav.querySelectorAll("[data-item]").forEach(b => b.addEventListener("click", () => ouvrirItem(visibles[+b.dataset.item], e.id)));
  const titre = section.querySelector(":scope > .par-contenu > .par-titre");
  if (titre && actif) titre.textContent = actif.libelle;
  // en-tête de l'écran : celui de l'espace
  const entete = el("enteteEcran");
  entete.hidden = false;
  entete.style.setProperty("--couleur", e.couleur);
  entete.style.setProperty("--teinte", e.teinte);
  el("eeIco").innerHTML = `<svg viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">${ICONES_ESPACES[e.id]}</svg>`;
  el("eeTitre").textContent = e.menu;
  el("eeDesc").textContent = e.desc;
  document.querySelectorAll(".mi[data-espace]").forEach(b => b.classList.toggle("active", b.dataset.espace === e.id));
  if (!silencieux) window.scrollTo(0, 0);
}

// Chaque affichage d'un écran d'espace met sa colonne de tuiles à jour
const afficherSansEspace = window.afficher;
window.afficher = async function (id, isRoot) {
  const r = await afficherSansEspace(id, isRoot);
  if (r !== false && espaceDe(id)) majEspace(id, true);
  else if (r !== false) document.querySelectorAll(".mi[data-espace]").forEach(b => b.classList.remove("active"));
  return r;
};
// L'icône « Rapports » du bord droit ouvre l'espace Rapports (ses tuiles selon la licence)
window.ouvrirStatistiques = () => ouvrirEspace("rapports");

// ---------- Menu et accueil selon la licence ----------
function construireEspaces() {
  const icone = svg => `<svg viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">${svg}</svg>`;
  const visibles = ESPACES.filter(espaceVisible);
  let groupe;
  const entrees = visibles.map(e => {
    const titre = e.groupe !== groupe ? `<div class="sm-groupe">${esc(e.groupe)}</div>` : "";
    groupe = e.groupe;
    return `${titre}<button class="mi" data-espace="${e.id}" onclick="ouvrirEspace('${e.id}')"><span class="mi-ico">${icone(ICONES_ESPACES[e.id])}</span><span>${esc(e.menu)}</span></button>`;
  }).join("");
  const accueil = el("menuItems").querySelector('[data-screen="accueil"]');
  const parametres = el("menuItems").querySelector('[data-screen="parametres"]');
  const raccourci = [...el("menuItems").querySelectorAll(".mi")].find(b => !b.dataset.screen);
  el("menuItems").innerHTML = (accueil ? accueil.outerHTML : "") + entrees
    + (parametres ? `<div class="sm-groupe">Administration</div>${parametres.outerHTML}` : "") + (raccourci ? raccourci.outerHTML : "");
  // Accueil : une carte par espace (les rapports s'ouvrent par l'icône du bord droit)
  el("modgrid").innerHTML = visibles.filter(e => e.id !== "rapports").map(e =>
    `<button class="modcard" onclick="ouvrirEspace('${e.id}')" style="--couleur:${e.couleur};--teinte:${e.teinte}"><div class="icon">${icone(ICONES_ESPACES[e.id])}</div>
      <div><b>${esc(e.menu)}</b><span>${esc(e.desc)}</span></div></button>`).join("");
}

// ---------- Actions rapides (décision de Boss du 14/11/2026) ----------
// D'abord les gestes du jour, à un seul toucher ; puis Ajouter / Imprimer / Exporter rangés par métier ; Sauvegarde (Admin).
// Modifier et Supprimer ont disparu (chaque ligne s'ouvre dans sa fiche), Rechercher et Actualiser aussi (barre de
// recherche et bouton Rafraîchir juste à côté).
function construireActionsRapides() {
  const svg = d => `<svg viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  const b = (libelle, aide, couleur, teinte, icone, action, classe = "") =>
    `<button class="qbtn ${classe}" onclick="${action}" data-tip="${esc(aide)}" style="--couleur:${couleur};--teinte:${teinte}"><span class="qico">${svg(icone)}</span><span>${esc(libelle)}</span></button>`;
  const gestes = [
    peut("paiements") && b("Encaisser un loyer", "Encaisser un loyer", "#1f7a6d", "#dff1ee", ICONES_ESPACES.loyers, "afficher('paiements').then(() => nouvelEncaissement())"),
    peut("ventes") && b("Caisse", "Vendre au comptoir", "#7a5c2e", "#f3ebdd", ICONES_ESPACES.boutique, "ongletVentes = 'veCaisse'; ouvrirEspace('boutique')"),
    peut("mobile_money") && moi.role !== "Comptable" && b("Guichet", "Guichet Mobile Money", "#ff7900", "#fff0e2", ICONES_ESPACES.mobile_money, "ongletMM = 'mmGuichet'; ouvrirEspace('mobile_money')"),
    peut("depenses") && b("Dépense", "Noter une dépense", "#b7791f", "#f8eedb", '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/>', "afficher('depenses').then(() => nouvelleDepense())"),
  ].filter(Boolean);
  const menus = [
    b("Ajouter", "Ajouter un élément", "#c1552d", "#fbeae2", '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>', "menuRapide(this, 'ajouter')"),
    b("Imprimer", "Imprimer : reçus, tickets, rapports…", "#4c8a4a", "#e5f1e3", '<path d="M6 9V3h12v6"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8" rx="1"/>', "menuRapide(this, 'imprimer')"),
    b("Exporter", "Exporter une liste vers Excel", "#1f7a6d", "#dff1ee", '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h2M8 17h2M14 13h2M14 17h2"/>', "menuRapide(this, 'exporter')"),
    estAdmin() && b("Sauvegarde", "Sauvegarder la base et les documents (Admin)", "#b7791f", "#f8eedb", '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.66 3.58 3 8 3s8-1.34 8-3V5"/><path d="M4 11v6c0 1.66 3.58 3 8 3"/><path d="m15 18 2 2 4-4"/>', "lancerSauvegarde()"),
  ].filter(Boolean);
  el("actionsRapides").innerHTML = gestes.join("") + menus.join("");
}
