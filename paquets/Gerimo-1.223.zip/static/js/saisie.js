// Contrôle des saisies et saisie intelligente (pour tout le projet).
// 1. Filtre : un caractère interdit (ex. un chiffre dans un nom) ne s'écrit pas.
// 2. Vérification à la sortie du champ et à l'enregistrement (mêmes règles que le serveur).
// 3. Suggestions pendant la frappe (dictionnaire intégré + mots déjà saisis).
// 4. Fautes de frappe soulignées en rouge, avec la correction proposée.

// ---------- Règles par type de champ (identiques à commun.py côté serveur) ----------

const chiffres = v => v.replace(/\D/g, "").length;
const TYPES_SAISIE = {
  nom: {
    permis: /[\p{L}' ’.\-]/u, message: "Un nom ne contient que des lettres (pas de chiffres ni de symboles).",
    valider: v => !v || /\p{L}/u.test(v) ? null : "un nom doit contenir des lettres.",
  },
  mots: { permis: /[\p{L}' ’.\-/(),]/u, message: "Lettres uniquement : pas de chiffres dans ce champ." },
  nomBien: {
    permis: /[\p{L}0-9' ’.\-,()/&°]/u, message: "Lettres et chiffres uniquement (pas de symboles).",
    valider: v => !v || /\p{L}/u.test(v) ? null : "le nom du bien doit contenir des lettres.",
  },
  code: { permis: /[\p{L}0-9 ./\-]/u, message: "Lettres, chiffres, tiret (-), barre (/) ou point uniquement." },
  montant: {
    permis: /[0-9   ]/, message: "Chiffres uniquement : le montant est en F CFA.",
    valider: v => !v || lireMontant(v) !== null ? null : "montant invalide (ex : 75 000).",
  },
  decimal: {
    permis: /[0-9 ,.]/, message: "Chiffres uniquement (virgule pour les décimales).",
    valider: v => !v || lireMontant(v) !== null ? null : "nombre invalide (ex : 500 ou 512,5).",
  },
  pourcentage: {
    permis: /[0-9,.%]/, message: "Chiffres uniquement (ex : 10 ou 12,5).",
    valider: v => {
      if (!v) return null;
      const n = Number(v.replace("%", "").replace(",", ".").trim());
      return Number.isFinite(n) && n >= 0 && n <= 100 ? null : "un pourcentage est compris entre 0 et 100.";
    },
  },
  telephone: {
    permis: /[0-9 +.\-()]/, message: "Chiffres uniquement (ex : 07 01 02 03 04).",
    valider: v => !v || (chiffres(v) >= 8 && chiffres(v) <= 15) ? null : "numéro incomplet (10 chiffres en Côte d'Ivoire).",
  },
  cni: {
    permis: /[A-Za-z0-9 \-]/, majuscules: true, message: "Lettres et chiffres uniquement.",
    valider: v => !v || (v.replace(/[^A-Za-z0-9]/g, "").length >= 4) ? null : "numéro de CNI trop court.",
  },
  email: {
    permis: /[A-Za-z0-9@._%+\-]/, message: "Adresse e-mail : lettres, chiffres et @ . - _ uniquement.",
    valider: v => !v || /^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(v) ? null : "adresse e-mail invalide (ex : nom@gmail.com).",
  },
  texte: { interdit: /[<>{}`\\]/, message: "Les caractères < > { } ` \\ ne sont pas acceptés.", orthographe: true },
};

// Champ → type, liste de suggestions, plusieurs éléments séparés par des virgules, correction
const CHAMPS_SAISIE = {
  proprioNom: { type: "nom" }, locNom: { type: "nom" }, ctLocNom: { type: "nom" }, sejClient: { type: "nom" },
  proprioVille: { type: "mots", vocab: "villes", corriger: true },
  locProfession: { type: "mots", vocab: "professions", corriger: true },
  ctLocProfession: { type: "mots", vocab: "professions", corriger: true },
  proprioCni: { type: "cni" }, locCni: { type: "cni" }, ctLocCni: { type: "cni" },
  proprioTel: { type: "telephone" }, locTel: { type: "telephone" }, ctLocTel: { type: "telephone" }, sejTelephone: { type: "telephone" },
  bienNomCite: { type: "nomBien" }, citeNom: { type: "nomBien" },
  bienCommission: { type: "pourcentage" }, citeCommission: { type: "pourcentage" },
  bienNumero: { type: "code" }, parcNumero: { type: "code" },
  bienLoyer: { type: "montant" }, ctLoyer: { type: "montant" },
  parcPrixEntree: { type: "montant" }, parcDernierPrix: { type: "montant" },
  parcSuperficie: { type: "decimal" },
  bienAdresse: { type: "texte", vocab: "adresses", corriger: true },
  citeAdresse: { type: "texte", vocab: "adresses", corriger: true },
  parcSituation: { type: "texte", vocab: "adresses", corriger: true },
  parcDocuments: { type: "texte", vocab: "documents", multiple: true, corriger: true },
  citeDescription: { type: "texte", corriger: true },
  payObservation: { type: "texte", vocab: "observations", corriger: true },
  resiliationMotif: { type: "texte", vocab: "motifs_resiliation", corriger: true },
  depMontant: { type: "montant" },
  avPartie: { type: "nom" }, avTel: { type: "telephone" }, avCni: { type: "cni" }, avMontant: { type: "montant" },
  avDesignation: { type: "texte", corriger: true },
  avProprioNom: { type: "nom" }, avProprioTel: { type: "telephone" }, avProprioCni: { type: "cni" },
  avCommissionPct: { type: "pourcentage" }, avCommission: { type: "montant" },
  avObservation: { type: "texte", corriger: true },
  depMotif: { type: "texte", vocab: "motifs_depense", corriger: true },
  annulationMotif: { type: "texte", vocab: "motifs_annulation", corriger: true },
  proprioEmail: { type: "email" }, locEmail: { type: "email" }, ctLocEmail: { type: "email" },
  prNom: { type: "nom" }, prTel: { type: "telephone" }, prEmail: { type: "email" }, prBudget: { type: "montant" },
  prQuartier: { type: "mots", vocab: "adresses" }, prDetails: { type: "texte", corriger: true },
  evtTitre: { type: "texte", corriger: true }, evtTel: { type: "telephone" }, evtLieu: { type: "texte", vocab: "adresses" },
  evtNotes: { type: "texte", corriger: true },
  revLoyer: { type: "montant" }, revMotif: { type: "texte", corriger: true },
  aveClauses: { type: "texte", corriger: true },
  edlObservations: { type: "texte", corriger: true }, edlRetenues: { type: "montant" },
  cvNom: { type: "nom" }, cvPrenoms: { type: "nom" }, cvTel1: { type: "telephone" }, cvTel2: { type: "telephone" },
  sigDescription: { type: "texte", corriger: true }, sigPar: { type: "nom" },
  // Commerce (13/11/2026)
  artNom: { type: "texte" }, artCategorie: { type: "texte" }, artUnite: { type: "texte" },
  artDetail: { type: "montant" }, artGros: { type: "montant" }, artAchat: { type: "montant" }, artSeuil: { type: "decimal" },
  fouNom: { type: "texte" }, fouTel: { type: "telephone" }, fouContact: { type: "texte" },
  fouAdresse: { type: "texte", vocab: "adresses" }, fouNote: { type: "texte", corriger: true },
};

// ---------- Outils ----------

// « Séguéla » → « seguela » (comparaison sans accents ni majuscules)
const normaliser = s => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();

function distance(a, b) {  // nombre de lettres à changer pour passer de a à b
  const ligne = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    let diag = ligne[0];
    ligne[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = ligne[j];
      ligne[j] = Math.min(ligne[j] + 1, ligne[j - 1] + 1, diag + (a[i - 1] === b[j - 1] ? 0 : 1));
      diag = tmp;
    }
  }
  return ligne[b.length];
}

function libelleChamp(champ) {
  const label = document.querySelector(`label[for="${champ.id}"]`);
  return label ? label.textContent.trim() : "Champ";
}

function zoneAide(champ) {
  const apres = champ.closest(".surligneur") || champ;
  let aide = apres.parentElement.querySelector(":scope > .aide-saisie");
  if (!aide) {
    aide = document.createElement("div");
    aide.className = "aide-saisie";
    apres.after(aide);
  }
  return aide;
}

function afficherAide(champ, message, duree = 0) {
  const aide = zoneAide(champ);
  aide.textContent = message || "";
  aide.style.display = message ? "block" : "none";
  clearTimeout(champ._minuterieAide);
  if (message && duree) champ._minuterieAide = setTimeout(() => afficherAide(champ, ""), duree);
}

// ---------- 1. Filtre pendant la frappe ----------

function filtrer(champ, regle) {
  const avant = champ.value;
  const curseur = champ.selectionStart ?? avant.length;
  let retires = 0, retiresAvantCurseur = 0;
  const propre = [...avant].filter((c, i) => {
    const ok = regle.permis ? regle.permis.test(c) : !regle.interdit.test(c);
    if (!ok) { retires++; if (i < curseur) retiresAvantCurseur++; }
    return ok;
  }).join("");
  const final = regle.majuscules ? propre.toUpperCase() : propre;
  if (final !== avant) {
    champ.value = final;
    const pos = Math.max(0, curseur - retiresAvantCurseur);
    try { champ.setSelectionRange(pos, pos); } catch { /* champ sans curseur */ }
  }
  if (retires) afficherAide(champ, regle.message, 3000);
}

// ---------- 2. Vérification ----------

function erreurChamp(champ) {
  const config = CHAMPS_SAISIE[champ.id];
  const regle = config && TYPES_SAISIE[config.type];
  return regle && regle.valider ? regle.valider(champ.value.trim()) : null;
}

function verifierChamp(champ) {
  const erreur = erreurChamp(champ);
  champ.classList.toggle("champ-invalide", !!erreur);
  if (erreur) afficherAide(champ, `« ${libelleChamp(champ)} » : ${erreur}`);
  return erreur;
}

// Appelée avant chaque enregistrement (voir soumettre dans app.js)
function verifierChamps(form) {
  for (const id of Object.keys(CHAMPS_SAISIE)) {
    const champ = form.querySelector(`#${id}`);
    if (!champ || champ.disabled || !champ.offsetParent) continue;  // champ caché ou bloqué
    const erreur = verifierChamp(champ);
    if (erreur) { champ.focus(); throw new Error(`« ${libelleChamp(champ)} » : ${erreur}`); }
  }
}

// ---------- 3. Suggestions pendant la frappe ----------

function listeVocab(nom) { return VOCABULAIRE[nom] || []; }

// partie en cours de saisie (après la dernière virgule si le champ en accepte plusieurs)
function segmentCourant(champ, config) {
  if (!config.multiple) return { debut: 0, texte: champ.value };
  const v = champ.value.slice(0, champ.selectionStart ?? champ.value.length);
  const debut = Math.max(v.lastIndexOf(","), v.lastIndexOf("\n")) + 1;
  return { debut, texte: v.slice(debut) };
}

function proposer(champ, config) {
  const boite = champ._suggestions;
  const q = normaliser(segmentCourant(champ, config).texte);
  boite._choix = -1;
  if (!q || document.activeElement !== champ) { boite.style.display = "none"; return; }
  const mots = listeVocab(config.vocab);
  const debut = mots.filter(m => normaliser(m).startsWith(q));
  const milieu = q.length >= 3 ? mots.filter(m => !normaliser(m).startsWith(q) && normaliser(m).includes(q)) : [];
  const resultats = [...debut, ...milieu].filter(m => normaliser(m) !== q).slice(0, 7);
  boite.innerHTML = resultats.map(m => `<li>${esc(m)}</li>`).join("");
  boite.style.display = resultats.length ? "block" : "none";
}

function choisirSuggestion(champ, config, mot) {
  const { debut } = segmentCourant(champ, config);
  const fin = champ.selectionStart ?? champ.value.length;
  const avant = champ.value.slice(0, debut);
  const apres = champ.value.slice(fin);
  const insertion = (config.multiple && debut > 0 ? " " : "") + mot + (config.multiple ? ", " : "");
  champ.value = avant + insertion + apres.replace(/^[^,\n]*/, "");
  const pos = (avant + insertion).length;
  champ.setSelectionRange(pos, pos);
  champ._suggestions.style.display = "none";
  champ.dispatchEvent(new Event("input"));
  champ.dispatchEvent(new Event("change"));
}

function brancherSuggestions(champ, config) {
  const boite = document.createElement("ul");
  boite.className = "suggestions";
  boite.setAttribute("role", "listbox");
  champ.closest(".surligneur").append(boite);
  champ._suggestions = boite;
  champ.setAttribute("autocomplete", "off");

  champ.addEventListener("input", () => proposer(champ, config));
  champ.addEventListener("focus", () => proposer(champ, config));
  champ.addEventListener("blur", () => setTimeout(() => { boite.style.display = "none"; }, 150));
  boite.addEventListener("mousedown", e => {
    const li = e.target.closest("li");
    if (li) { e.preventDefault(); choisirSuggestion(champ, config, li.textContent); }
  });
  champ.addEventListener("keydown", e => {
    if (boite.style.display !== "block") return;
    const items = [...boite.children];
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      boite._choix = (boite._choix + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length;
      items.forEach((li, i) => li.classList.toggle("actif", i === boite._choix));
    } else if ((e.key === "Enter" || e.key === "Tab") && boite._choix >= 0) {
      e.preventDefault();  // Entrée choisit la suggestion au lieu d'enregistrer le formulaire
      choisirSuggestion(champ, config, items[boite._choix].textContent);
    } else if (e.key === "Escape") {
      e.preventDefault();  // Échap ferme les suggestions, pas le formulaire
      boite.style.display = "none";
    }
  });
}

// ---------- 4. Fautes de frappe : soulignées en rouge ----------

const IGNORES = new Set();  // mots que l'utilisateur a choisi de garder

function nomsPropres() {
  const mots = new Set();
  for (const liste of ["villes", "adresses"]) {
    for (const element of listeVocab(liste)) {
      for (const m of element.match(/[\p{L}'’-]{5,}/gu) || []) mots.add(m);
    }
  }
  return [...mots];
}

function plusProche(mot, candidats, tolerance) {
  const n = normaliser(mot);
  let meilleur = null, dMin = Infinity;
  for (const c of candidats) {
    const d = distance(n, normaliser(c));
    if (d < dMin) { dMin = d; meilleur = c; }
  }
  return meilleur && dMin <= tolerance && meilleur !== mot ? meilleur : null;
}

// Renvoie les fautes trouvées : [{ debut, fin, terme, proposition }]
function analyser(champ, config) {
  const v = champ.value;
  const fautes = [];
  if (!v.trim()) return fautes;

  // Ville, profession : la valeur entière doit être un mot connu
  if (config.type === "mots" && config.vocab) {
    const mot = v.trim();
    const liste = listeVocab(config.vocab);
    if (!IGNORES.has(mot) && !liste.includes(mot)) {
      const exact = liste.find(m => normaliser(m) === normaliser(mot));  // seulement accents/majuscules
      const proposition = exact || plusProche(mot, liste, mot.length >= 7 ? 2 : 1);
      if (proposition) fautes.push({ debut: v.indexOf(mot), fin: v.indexOf(mot) + mot.length, terme: mot, proposition });
    }
    return fautes;
  }

  // Textes : fautes fréquentes connues et noms de lieux mal orthographiés
  const lieux = nomsPropres();
  for (const m of v.matchAll(/[\p{L}'’-]+/gu)) {
    const mot = m[0];
    if (IGNORES.has(mot)) continue;
    let proposition = CORRECTIONS[mot.toLowerCase()];
    if (proposition && /^\p{Lu}/u.test(mot)) proposition = proposition[0].toUpperCase() + proposition.slice(1);
    if (!proposition && /^\p{Lu}/u.test(mot) && mot.length >= 5 && !lieux.includes(mot)) {
      proposition = lieux.find(l => normaliser(l) === normaliser(mot)) || plusProche(mot, lieux, mot.length >= 8 ? 2 : 1);
    }
    if (proposition && proposition !== mot) fautes.push({ debut: m.index, fin: m.index + mot.length, terme: mot, proposition });
  }
  return fautes;
}

// Calque placé sous le champ : reproduit le texte et souligne les fautes
function copierStyle(source, cible) {
  const s = getComputedStyle(source);
  for (const p of ["fontFamily", "fontSize", "fontWeight", "letterSpacing", "lineHeight", "wordSpacing",
                   "paddingTop", "paddingRight", "paddingBottom", "paddingLeft", "borderTopWidth",
                   "borderRightWidth", "borderBottomWidth", "borderLeftWidth", "boxSizing", "textIndent"]) {
    cible.style[p] = s[p];
  }
  cible.parentElement.style.borderRadius = s.borderRadius;
}

function dessinerFautes(champ, fautes) {
  const calque = champ._calque;
  let html = "", pos = 0;
  for (const f of fautes) {
    html += esc(champ.value.slice(pos, f.debut)) + `<span class="faute">${esc(champ.value.slice(f.debut, f.fin))}</span>`;
    pos = f.fin;
  }
  html += esc(champ.value.slice(pos)) + (champ.tagName === "TEXTAREA" ? "\n " : "");
  calque.innerHTML = html;
  calque.scrollTop = champ.scrollTop;
  calque.scrollLeft = champ.scrollLeft;

  // Propositions sous le champ
  let zone = champ.closest(".surligneur").parentElement.querySelector(":scope > .correction");
  if (!fautes.length) { if (zone) zone.remove(); return; }
  if (!zone) {
    zone = document.createElement("div");
    zone.className = "correction";
    champ.closest(".surligneur").after(zone);
  }
  zone.innerHTML = fautes.slice(0, 3).map((f, i) => `<span>« ${esc(f.terme)} » : vouliez-vous dire
    <b>« ${esc(f.proposition)} »</b> ? <button type="button" class="btn-sm" data-i="${i}" data-action="corriger">Corriger</button>
    <button type="button" class="btn-sm" data-i="${i}" data-action="ignorer">Ignorer</button></span>`).join("");
  zone.onclick = e => {
    const b = e.target.closest("button");
    if (!b) return;
    const f = fautes[Number(b.dataset.i)];
    if (b.dataset.action === "corriger") {
      champ.value = champ.value.slice(0, f.debut) + f.proposition + champ.value.slice(f.fin);
      champ.dispatchEvent(new Event("change"));
    } else {
      IGNORES.add(f.terme);
    }
    corrigerChamp(champ, CHAMPS_SAISIE[champ.id]);
  };
}

function corrigerChamp(champ, config) {
  dessinerFautes(champ, analyser(champ, config));
}

function brancherCorrection(champ, config) {
  const calque = document.createElement("div");
  calque.className = "calque-fautes";
  calque.setAttribute("aria-hidden", "true");
  if (champ.tagName === "TEXTAREA") calque.classList.add("multiligne");
  champ.before(calque);
  champ._calque = calque;
  copierStyle(champ, calque);
  let minuterie;
  champ.addEventListener("input", () => {
    dessinerFautes(champ, []);  // on efface pendant la frappe…
    clearTimeout(minuterie);
    minuterie = setTimeout(() => corrigerChamp(champ, config), 600);  // …et on revérifie à la pause
  });
  champ.addEventListener("blur", () => corrigerChamp(champ, config));
  champ.addEventListener("scroll", () => { calque.scrollTop = champ.scrollTop; calque.scrollLeft = champ.scrollLeft; });
  // valeur remplie par le programme (ouverture d'une fiche) : on revérifie
  champ.addEventListener("focus", () => copierStyle(champ, calque));
}

// ---------- Mise en place ----------

function initialiserSaisie() {
  for (const [id, config] of Object.entries(CHAMPS_SAISIE)) {
    const champ = document.getElementById(id);
    if (!champ) continue;
    const regle = TYPES_SAISIE[config.type];

    // correcteur du navigateur (souligné rouge, clic droit) seulement pour les textes libres
    champ.spellcheck = !!regle.orthographe;
    champ.lang = "fr";

    if (config.vocab || config.corriger) {
      const enveloppe = document.createElement("div");
      enveloppe.className = "surligneur";
      champ.replaceWith(enveloppe);
      enveloppe.append(champ);
      if (config.corriger) brancherCorrection(champ, config);
      if (config.vocab) brancherSuggestions(champ, config);
    }

    champ.addEventListener("input", () => {
      filtrer(champ, regle);
      if (champ.classList.contains("champ-invalide") && !erreurChamp(champ)) {
        champ.classList.remove("champ-invalide");
        afficherAide(champ, "");
      }
    });
    champ.addEventListener("blur", () => { if (champ.value.trim()) verifierChamp(champ); });
  }
}

// Efface les marques (rouge, propositions) d'un formulaire qu'on rouvre
function reinitialiserSaisie(form) {
  form.querySelectorAll(".champ-invalide").forEach(c => c.classList.remove("champ-invalide"));
  form.querySelectorAll(".aide-saisie").forEach(a => { a.style.display = "none"; });
  form.querySelectorAll(".correction").forEach(z => z.remove());
  form.querySelectorAll(".calque-fautes").forEach(c => { c.innerHTML = ""; });
}

// Mots déjà saisis dans le logiciel, ajoutés au dictionnaire (sans doublons)
async function chargerVocabulaire() {
  try {
    const rep = await fetch("/api/vocabulaire");
    if (!rep.ok) return;
    const appris = await rep.json();
    for (const [liste, mots] of Object.entries(appris)) {
      const existants = new Set((VOCABULAIRE[liste] ||= []).map(normaliser));
      for (const m of mots) if (!existants.has(normaliser(m))) VOCABULAIRE[liste].push(m);
    }
  } catch { /* les suggestions intégrées suffisent */ }
}
