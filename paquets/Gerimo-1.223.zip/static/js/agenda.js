// Agenda (widget de l'accueil + écran complet) et demandes de nouveaux clients.

const JOURS_COURTS = ["L", "M", "M", "J", "V", "S", "D"];
const MOIS_NOMS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
let moisAgenda = new Date(); moisAgenda.setDate(1);
let jourChoisi = aujourdhui();
let agendaCache = { evenements: [], echeances: {} };
let evenementEnCours = null;
let prospectsCache = [];
let optionsProspects = null;
let prospectEnCours = null;

const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
function jourLong(isoJour) {
  const d = new Date(isoJour + "T00:00");
  const noms = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
  if (isoJour === aujourdhui()) return "Aujourd'hui";
  const demain = new Date(); demain.setDate(demain.getDate() + 1);
  if (isoJour === iso(demain)) return "Demain";
  return `${noms[d.getDay()]} ${d.getDate()} ${MOIS_NOMS[d.getMonth()]}`;
}

// ---------- Widget de l'accueil ----------
async function chargerAgendaWidget() {
  if (!peut("agenda")) return;
  const debut = new Date(moisAgenda); debut.setDate(debut.getDate() - 7);
  const fin = new Date(moisAgenda.getFullYear(), moisAgenda.getMonth() + 1, 14);
  try { agendaCache = await api(`/api/agenda?debut=${iso(debut)}&fin=${iso(fin)}`); } catch { return; }
  dessinerCalendrier();
  dessinerListeAgenda();
}
const _accueilAvantAgenda = CHARGEURS.accueil;
CHARGEURS.accueil = () => { if (_accueilAvantAgenda) _accueilAvantAgenda(); chargerAgendaWidget(); };

function decalerMoisAgenda(n) { moisAgenda.setMonth(moisAgenda.getMonth() + n); chargerAgendaWidget(); }

const agendaCompact = () => el("widgetAgenda").classList.contains("compact");

// Clic sur le widget (hors boutons) : agrandir ; nouveau clic sur l'en-tête : réduire
function basculerAgenda(ouvrir) {
  const w = el("widgetAgenda");
  const compact = ouvrir === undefined ? !w.classList.contains("compact") : !ouvrir;
  w.classList.toggle("compact", compact);
  w.title = compact ? "Cliquez pour agrandir l'agenda" : "";
  dessinerCalendrier();
  dessinerListeAgenda();
}
el("widgetAgenda").addEventListener("click", e => {
  if (agendaCompact() && !e.target.closest("button, .evt .ibtn")) { basculerAgenda(true); return; }
  if (!agendaCompact() && e.target.closest(".widget-tete") && !e.target.closest("button")) basculerAgenda(false);
});

function dessinerCalendrier() {
  if (agendaCompact()) { dessinerSemaine(); return; }
  const annee = moisAgenda.getFullYear(), mois = moisAgenda.getMonth();
  const premier = new Date(annee, mois, 1);
  const decalage = (premier.getDay() + 6) % 7;   // semaine commençant le lundi
  const avecEvt = new Set(agendaCache.evenements.filter(e => !e.fait).map(e => e.date_evenement));
  let html = `<div class="mc-titre">${MOIS_NOMS[mois]} ${annee}</div>` + JOURS_COURTS.map(j => `<div class="mc-jsem">${j}</div>`).join("");
  for (let i = 0; i < 42; i++) {
    const d = new Date(annee, mois, 1 - decalage + i);
    if (i >= 35 && d.getMonth() !== mois) break;
    const j = iso(d);
    const classes = ["mc-jour", d.getMonth() !== mois && "autre", j === aujourdhui() && "auj", j === jourChoisi && "choisi",
                     avecEvt.has(j) && "a-evt", agendaCache.echeances[j] && "echeance"].filter(Boolean).join(" ");
    const tip = [avecEvt.has(j) && "Rendez-vous / tâches", agendaCache.echeances[j] && `${agendaCache.echeances[j]} loyer(s) à échéance`].filter(Boolean).join(" — ");
    html += `<div class="${classes}" data-jour="${j}"${tip ? ` data-tip="${esc(tip)}"` : ""}>${d.getDate()}</div>`;
  }
  el("miniCalendrier").innerHTML = html;
}
// Mode compact : seulement la semaine en cours
function dessinerSemaine() {
  const base = new Date((jourChoisi || aujourdhui()) + "T00:00");
  base.setDate(base.getDate() - (base.getDay() + 6) % 7);
  const avecEvt = new Set(agendaCache.evenements.filter(e => !e.fait).map(e => e.date_evenement));
  let html = JOURS_COURTS.map(j => `<div class="mc-jsem">${j}</div>`).join("");
  for (let i = 0; i < 7; i++) {
    const d = new Date(base); d.setDate(base.getDate() + i);
    const j = iso(d);
    const classes = ["mc-jour", j === aujourdhui() && "auj", j === jourChoisi && "choisi", avecEvt.has(j) && "a-evt",
                     agendaCache.echeances[j] && "echeance"].filter(Boolean).join(" ");
    html += `<div class="${classes}" data-jour="${j}">${d.getDate()}</div>`;
  }
  el("miniCalendrier").innerHTML = html;
}

el("miniCalendrier").addEventListener("click", e => {
  const j = e.target.closest("[data-jour]");
  if (!j) return;
  jourChoisi = j.dataset.jour;
  dessinerCalendrier();
  dessinerListeAgenda();
});
el("miniCalendrier").addEventListener("dblclick", e => {
  const j = e.target.closest("[data-jour]");
  if (j) nouvelEvenement(j.dataset.jour);
});

function ligneEvenement(e, avecDate = false) {
  return `<div class="evt ligne-fiche${e.fait ? " fait" : ""}" data-fiche="evenement:${e.id}" tabindex="0">
    <span class="evt-pastille ${esc(e.type_evenement)}"></span>
    <span class="evt-heure">${e.heure || "—"}</span>
    <span class="evt-corps"><span class="evt-titre">${esc(e.titre)}</span>
      <span class="evt-type">${avecDate ? esc(jourLong(e.date_evenement)) + " — " : ""}${esc(e.type_evenement)}${e.lieu ? " — " + esc(e.lieu) : ""}${e.prospect ? " — client : " + esc(e.prospect) : ""}${e.pour_tous ? " — équipe" : ""}</span></span>
    ${e.telephone ? ibtn("whatsapp", `WhatsApp ${e.telephone}`, `ouvrirWhatsAppTexte('${esc(e.telephone)}')`) : ""}
    ${ibtn("coche", e.fait ? "Remettre à faire" : "Marquer comme fait", `basculerEvenement(${e.id})`, { classe: "modif" })}
    ${ibtn("modifier", "Modifier", `modifierEvenement(${e.id})`)}
  </div>`;
}

function dessinerListeAgenda() {
  const zone = el("agendaListe");
  const duJour = agendaCache.evenements.filter(e => e.date_evenement === jourChoisi);
  let html = `<div class="agenda-jour">${esc(jourLong(jourChoisi))}</div>`;
  html += duJour.map(e => ligneEvenement(e)).join("") || '<div class="petit">Rien de prévu. Double-cliquez sur un jour pour ajouter.</div>';
  if (agendaCache.echeances[jourChoisi]) html += `<div class="evt"><span class="evt-pastille Échéance"></span><span class="evt-corps"><span class="evt-titre">${agendaCache.echeances[jourChoisi]} loyer(s) à échéance</span><span class="evt-type">Date limite de paiement</span></span></div>`;
  // ensuite : les prochains jours
  const prochains = agendaCache.evenements.filter(e => e.date_evenement > jourChoisi && !e.fait).slice(0, agendaCompact() ? 2 : 6);
  const aVenir = agendaCache.evenements.filter(e => e.date_evenement >= aujourdhui() && !e.fait).length;
  el("agendaResume").textContent = aVenir ? `· ${aVenir} à venir` : "";
  if (prochains.length) html += '<div class="agenda-jour">À venir</div>' + prochains.map(e => ligneEvenement(e, true)).join("");
  zone.innerHTML = html;
}

async function basculerEvenement(id) {
  try { await api(`/api/agenda/${id}/fait`, { method: "POST" }); } catch (e) { toast(e.message); return; }
  rafraichirAgendas();
}
function rafraichirAgendas() {
  chargerAgendaWidget();
  if (document.querySelector("#agenda.active")) chargerAgendaComplet();
  if (typeof chargerAssistant === "function") chargerAssistant();
}

// ---------- Fenêtre « rendez-vous » ----------
function nouvelEvenement(jour = null, valeurs = {}) {
  if (!peut("agenda")) { toast("Votre profil n'a pas d'agenda."); return; }
  evenementEnCours = null;
  remplirSelect(el("evtType"), ["Rendez-vous", "Appel", "Visite", "Courrier", "Tâche", "Relance"]);
  el("evtType").value = valeurs.type || "Rendez-vous";
  fixerDate("evtDate", jour || jourChoisi || aujourdhui());
  el("evtHeure").value = valeurs.heure || "";
  el("evtTitre").value = valeurs.titre || "";
  el("evtTel").value = valeurs.telephone || "";
  el("evtLieu").value = "";
  el("evtNotes").value = valeurs.notes || "";
  el("evtRappel").value = "30";
  el("evtTous").checked = false;
  el("evtTitreFenetre").textContent = "Nouveau rendez-vous, appel ou tâche";
  el("evtSupprimer").style.display = "none";
  el("formEvenement").dataset.prospect = valeurs.prospect_id || "";
  reinitialiserSaisie(el("formEvenement"));
  erreurFormulaire(el("formEvenement"), "");
  ouvrirModal("modalEvenement");
  el("evtTitre").focus();
}

function modifierEvenement(id) {
  const e = agendaCache.evenements.find(x => x.id === id) || agendaComplet.find(x => x.id === id);
  if (!e) return;
  nouvelEvenement(e.date_evenement, { type: e.type_evenement, heure: e.heure, titre: e.titre, telephone: e.telephone, notes: e.notes, prospect_id: e.prospect_id });
  evenementEnCours = e;
  el("evtLieu").value = e.lieu;
  el("evtRappel").value = String([0, 15, 30, 60, 1440].includes(e.rappel_minutes) ? e.rappel_minutes : 30);
  el("evtTous").checked = e.pour_tous;
  el("evtTitreFenetre").textContent = "Modifier";
  el("evtSupprimer").style.display = estAdmin() ? "" : "none";
}

el("evtSupprimer").addEventListener("click", () => {
  if (!evenementEnCours) return;
  fermerModal("modalEvenement");
  supprimerAvecConfirmation(`Supprimer « ${evenementEnCours.titre} » de l'agenda ? Mot de passe Admin.`,
    `/api/agenda/${evenementEnCours.id}/supprimer`, rafraichirAgendas);
});

el("formEvenement").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (!el("evtTitre").value.trim()) throw new Error("Indiquez l'objet (ex : Visite du studio B4).");
    const date = valeurDate("evtDate", "Date");
    if (!date) throw new Error("Indiquez la date (jj/mm/aaaa).");
    const corps = {
      titre: el("evtTitre").value, type_evenement: el("evtType").value, date_evenement: date,
      heure: el("evtHeure").value || null, lieu: el("evtLieu").value, telephone: el("evtTel").value,
      notes: el("evtNotes").value, rappel_minutes: Number(el("evtRappel").value), pour_tous: el("evtTous").checked,
      prospect_id: e.target.dataset.prospect ? Number(e.target.dataset.prospect) : null,
    };
    if (evenementEnCours) await api(`/api/agenda/${evenementEnCours.id}`, { method: "PUT", body: corps });
    else await api("/api/agenda", { method: "POST", body: corps });
    fermerModal("modalEvenement");
    toast(corps.heure ? "Enregistré : l'assistant vous préviendra à l'avance." : "Enregistré dans l'agenda.");
    jourChoisi = date;
    rafraichirAgendas();
  });
});

// ---------- Écran Agenda & clients ----------
let agendaComplet = [];
function ongletAgenda(bouton) {
  document.querySelectorAll("#agenda .onglet").forEach(b => b.classList.toggle("actif", b === bouton));
  el("ongletAgenda").style.display = bouton.dataset.onglet === "ongletAgenda" ? "" : "none";
  el("ongletClients").style.display = bouton.dataset.onglet === "ongletClients" ? "" : "none";
  if (bouton.dataset.onglet === "ongletClients") chargerProspects();
}

async function chargerAgendaComplet() {
  const choix = el("agendaPeriode").value;
  const d = new Date();
  const debut = new Date(d), fin = new Date(d);
  if (choix === "passe") debut.setDate(d.getDate() - 30); else fin.setDate(d.getDate() + (choix === "mois" ? 30 : 7));
  if (choix !== "passe") debut.setDate(d.getDate() - 7);   // + les retards de la semaine passée
  try { agendaComplet = (await api(`/api/agenda?debut=${iso(debut)}&fin=${iso(fin)}`)).evenements; }
  catch (e) { el("agendaComplet").innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  if (choix !== "passe") agendaComplet = agendaComplet.filter(e => e.date_evenement >= aujourdhui() || !e.fait);
  const parJour = {};
  agendaComplet.forEach(e => (parJour[e.date_evenement] = parJour[e.date_evenement] || []).push(e));
  el("agendaComplet").innerHTML = Object.keys(parJour).sort().map(j =>
    `<div class="card"><h3>${esc(jourLong(j))}${j < aujourdhui() ? ' <span class="pill danger">en retard</span>' : ""}</h3>
     <div style="display:flex;flex-direction:column;gap:.45rem">${parJour[j].map(e => ligneEvenement(e)).join("")}</div></div>`).join("")
    || '<div class="card vide">Rien de prévu sur cette période.</div>';
  chargerNombreProspects();
}
CHARGEURS.agenda = chargerAgendaComplet;
el("agendaPeriode").addEventListener("change", chargerAgendaComplet);

// ---------- Demandes de clients ----------
const CLASSE_STATUT_PROSPECT = { "Nouveau": "danger", "En cours": "warn", "Visite prévue": "info", "Converti": "ok", "Perdu": "info" };

async function chargerNombreProspects() {
  if (!peut("prospects")) { document.querySelector('[data-onglet="ongletClients"]').style.display = "none"; return; }
  try {
    prospectsCache = await api("/api/prospects");
    const actifs = prospectsCache.filter(p => !["Converti", "Perdu"].includes(p.statut)).length;
    el("nbProspects").textContent = actifs || "";
  } catch { /* rien */ }
}

async function chargerProspects() {
  const zone = el("listeProspects");
  try { prospectsCache = await api("/api/prospects"); }
  catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  if (!prospectsCache.length) {
    zone.innerHTML = '<div class="card vide">Aucune demande. Notez chaque client qui cherche un logement : l\'assistant vous préviendra dès qu\'un logement correspond.</div>';
    return;
  }
  zone.innerHTML = `<div class="card">${prospectsCache.map(p => {
    const recherche = [p.besoin, p.type_logement, p.quartier && "à " + p.quartier, p.budget_max && "budget " + formatMontant(p.budget_max)].filter(Boolean).join(", ");
    const retard = p.prochaine_action && p.prochaine_action <= aujourdhui() && !["Converti", "Perdu"].includes(p.statut);
    return `<div class="row row-fiche etat-${["Converti"].includes(p.statut) ? "a_jour" : p.statut === "Perdu" ? "termine" : retard ? "retard" : "depart"}" data-fiche="prospect:${p.id}" tabindex="0"${motsCles({ tel: [p.telephone], textes: [p.details, p.quartier] })}>
      <span class="who"><b>${esc(p.nom_complet)}</b>${p.telephone ? " — " + esc(p.telephone) : ""}
        <br><span class="petit">${esc(recherche)} — reçu le ${formatDate(p.cree_le)}${p.source ? " (" + esc(p.source) + ")" : ""}
        ${p.prochaine_action ? ` — <span style="${retard ? "color:var(--danger);font-weight:600" : ""}">à recontacter le ${formatDate(p.prochaine_action)}</span>` : ""}</span></span>
      <span class="boutons">
        <span class="pill ${CLASSE_STATUT_PROSPECT[p.statut]}">${esc(p.statut)}</span>
        ${p.telephone ? ibtn("whatsapp", "Écrire sur WhatsApp", `waProspect(${p.id})`) : ""}
        ${ibtn("calendrier", "Planifier un appel ou une visite", `planifierProspect(${p.id})`, { classe: "doc" })}
        ${ibtn("modifier", "Ouvrir la fiche (suivi, logements qui correspondent)", `ouvrirProspect(${p.id})`)}
      </span></div>`;
  }).join("")}</div>`;
  el("rechercheProspects").dispatchEvent(new Event("input"));
}
brancherRecherche(el("rechercheProspects"), el("listeProspects"));

function waProspect(id) {
  const p = prospectsCache.find(x => x.id === id);
  if (p) ouvrirWhatsAppTexte(p.telephone, `Bonjour ${p.nom_complet}, ici ${nomEntreprise()}. `);
}

async function preparerFormProspect() {
  optionsProspects = optionsProspects || await api("/api/prospects/options");
  remplirSelect(el("prBesoin"), optionsProspects.besoins);
  remplirSelect(el("prType"), optionsProspects.types_logement, { vide: "Indifférent" });
  remplirSelect(el("prSource"), optionsProspects.sources, { vide: "—" });
  remplirSelect(el("prStatut"), optionsProspects.statuts);
}

async function nouveauProspect(infos = {}) {
  if (!peut("prospects")) { toast("Votre profil ne gère pas les demandes de clients."); return; }
  try { await preparerFormProspect(); } catch (e) { toast(e.message); return; }
  prospectEnCours = null;
  el("prNom").value = infos.nom_complet || "";
  el("prTel").value = infos.telephone || "";
  el("prEmail").value = "";
  el("prBesoin").value = infos.besoin || "Location";
  el("prType").value = infos.type_logement || "";
  el("prQuartier").value = infos.quartier || "";
  el("prBudget").value = infos.budget_max ? formatNombre(infos.budget_max) : "";
  el("prSource").value = "";
  el("prStatut").value = "Nouveau";
  const demain = new Date(); demain.setDate(demain.getDate() + 1);
  fixerDate("prAction", iso(demain));
  el("prDetails").value = "";
  el("prCorrespondances").innerHTML = "";
  el("prSuivi").innerHTML = "";
  el("prTitreFenetre").textContent = "Nouvelle demande de client";
  el("prSupprimer").style.display = "none";
  reinitialiserSaisie(el("formProspect"));
  erreurFormulaire(el("formProspect"), "");
  ouvrirModal("modalProspect");
  el("prNom").focus();
}

async function ouvrirProspect(id) {
  let p;
  try { await preparerFormProspect(); p = await api(`/api/prospects/${id}`); } catch (e) { toast(e.message); return; }
  prospectEnCours = p;
  el("prNom").value = p.nom_complet;
  el("prTel").value = p.telephone;
  el("prEmail").value = p.email;
  el("prBesoin").value = p.besoin;
  el("prType").value = p.type_logement || "";
  el("prQuartier").value = p.quartier;
  el("prBudget").value = p.budget_max ? formatNombre(p.budget_max) : "";
  el("prSource").value = p.source || "";
  el("prStatut").value = p.statut;
  fixerDate("prAction", p.prochaine_action);
  el("prDetails").value = p.details;
  el("prTitreFenetre").textContent = `Demande de ${p.nom_complet}`;
  el("prSupprimer").style.display = estAdmin() ? "" : "none";
  afficherSuiviProspect(p);
  reinitialiserSaisie(el("formProspect"));
  erreurFormulaire(el("formProspect"), "");
  ouvrirModal("modalProspect");
}

function afficherSuiviProspect(p) {
  el("prCorrespondances").innerHTML = p.correspondances?.length ? `<div class="recap" style="margin-bottom:.8rem"><b>Logements libres qui correspondent :</b><br>${p.correspondances.map(c =>
    `• ${esc(c.logement)} — ${esc(c.type_logement)} — ${formatMontant(c.loyer)}${c.bon_quartier ? " ✓ quartier" : ""}
     ${p.telephone ? `<button type="button" class="btn-sm wa" onclick="proposerLogement(${p.id}, ${c.id})">Proposer par WhatsApp</button>` : ""}`).join("<br>")}</div>`
    : (p.besoin === "Location" ? '<p class="petit">Aucun logement libre ne correspond pour l\'instant : l\'assistant vous préviendra dès qu\'il y en aura un.</p>' : "");
  el("prSuivi").innerHTML = `<div class="form-section"><h3>Suivi</h3>
    <div class="pj-boutons"><input id="prNote" class="search" placeholder="ex : Appelé, visite prévue samedi ; ne répond pas…" maxlength="2000">
      <button type="button" class="btn" onclick="ajouterNoteProspect()">Ajouter au suivi</button>
      <button type="button" class="btn ghost" onclick="planifierProspect(${p.id})">Planifier un rappel</button></div>
    ${(p.suivi || []).map(s => `<div class="row"><span class="who">${esc(s.note)}</span><span class="petit">${esc(s.date)} — ${esc(s.auteur)}</span></div>`).join("")}</div>`;
}

function proposerLogement(prospectId, logementId) {
  const p = prospectEnCours;
  const c = p?.correspondances.find(x => x.id === logementId);
  if (!p || !c) return;
  ouvrirWhatsAppTexte(p.telephone, `Bonjour ${p.nom_complet}, ici ${nomEntreprise()}. Suite à votre demande, nous avons un logement disponible : ` +
    `${c.logement} (${c.type_logement}), loyer ${formatMontant(c.loyer).replace(" F", " F CFA")} par mois. Quand souhaitez-vous le visiter ?`);
  api(`/api/prospects/${prospectId}/suivi`, { method: "POST", body: { note: `Logement proposé par WhatsApp : ${c.logement}`, statut: "En cours" } })
    .then(afficherSuiviProspect).catch(() => {});
}

async function ajouterNoteProspect() {
  const note = el("prNote").value.trim();
  if (!note || !prospectEnCours) return;
  try {
    const p = await api(`/api/prospects/${prospectEnCours.id}/suivi`, { method: "POST", body: { note, prochaine_action: valeurDate("prAction", "À recontacter le") } });
    prospectEnCours = p;
    el("prStatut").value = p.statut;
    afficherSuiviProspect(p);
    toast("Suivi enregistré");
  } catch (e) { toast(e.message); }
}

function planifierProspect(id) {
  const p = prospectsCache.find(x => x.id === id) || prospectEnCours;
  if (!p) return;
  fermerModal("modalProspect");
  const demain = new Date(); demain.setDate(demain.getDate() + 1);
  nouvelEvenement(iso(demain), { type: "Appel", heure: "10:00", titre: `Rappeler ${p.nom_complet} (${p.type_logement || p.besoin})`, telephone: p.telephone, prospect_id: p.id });
}

el("prSupprimer").addEventListener("click", () => {
  if (!prospectEnCours) return;
  fermerModal("modalProspect");
  supprimerAvecConfirmation(`Supprimer la demande de ${prospectEnCours.nom_complet} ? Mot de passe Admin.`,
    `/api/prospects/${prospectEnCours.id}/supprimer`, chargerProspects);
});

el("formProspect").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    if (!el("prNom").value.trim()) throw new Error("Indiquez le nom du client.");
    const budget = el("prBudget").value.trim() ? lireMontant(el("prBudget").value) : null;
    if (el("prBudget").value.trim() && budget === null) throw new Error("Budget invalide (ex : 60 000).");
    const corps = {
      nom_complet: el("prNom").value, telephone: el("prTel").value, email: el("prEmail").value,
      besoin: el("prBesoin").value, type_logement: el("prType").value || null, quartier: el("prQuartier").value,
      budget_max: budget, details: el("prDetails").value, source: el("prSource").value || null,
      statut: el("prStatut").value, prochaine_action: valeurDate("prAction", "À recontacter le"),
    };
    const p = prospectEnCours
      ? await api(`/api/prospects/${prospectEnCours.id}`, { method: "PUT", body: corps })
      : await api("/api/prospects", { method: "POST", body: corps });
    prospectEnCours = p;
    afficherSuiviProspect(p);
    el("prTitreFenetre").textContent = `Demande de ${p.nom_complet}`;
    toast(p.correspondances.length ? `Enregistré — ${p.correspondances.length} logement(s) libre(s) correspondent !` : "Demande enregistrée : l'assistant vous rappellera de le recontacter.", 5000);
    if (document.querySelector("#agenda.active")) chargerProspects();
    if (typeof chargerAssistant === "function") chargerAssistant();
  });
});
