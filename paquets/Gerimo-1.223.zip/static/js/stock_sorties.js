// Commerce, partie 3 (14/11/2026) : sorties de stock avec motif, et inventaire.
// Admin et magasinier (Gestionnaire) ; seul l'Admin valide un inventaire. Le serveur revérifie tout.

TITRES_ECRANS.formInventaire = ["Inventaire", "Comptez le stock réel : Gérimo montre l'écart"];
ECRANS.formInventaire = "stock";
let inventairesCache = [];
let sortiesCache = [];
let articlesInventaire = [];

const AIDE_RAISON = { "Casse": "cassé, abîmé", "Périmé": "date limite passée", "Vol ou perte": "disparu",
                      "Usage interne": "utilisé par la boutique", "Cadeau ou échantillon": "donné", "Autre": "" };

async function chargerSorties() {
  const zone = el("listeSorties");
  let s;
  try {
    [s, inventairesCache] = await Promise.all([api("/api/stock/sorties"), api("/api/stock/inventaires"),
                                               optionsCommerce ? null : chargerOptionsCommerce()]);
  } catch (e) { zone.innerHTML = `<div class="card vide">${esc(e.message)}</div>`; return; }
  sortiesCache = s.sorties;
  const aValider = inventairesCache.filter(i => i.statut === "À valider");
  const moisCourant = aujourdhui().slice(0, 7);
  const duMois = s.sorties.filter(x => x.date.startsWith(moisCourant)).length;
  el("resumeSorties").innerHTML = [
    `<div class="chiffre-cle neutre statique"><span class="cc-chiffre">${duMois}</span><span class="cc-libelle">Sorties ce mois-ci</span>
      <span class="cc-aide">casse, périmés, pertes…</span></div>`,
    s.pertes_du_mois !== undefined ? `<div class="chiffre-cle ${s.pertes_du_mois ? "alerte" : "calme"} statique"><span class="cc-chiffre">${formatMontant(s.pertes_du_mois)}</span>
      <span class="cc-libelle">Pertes ce mois-ci</span><span class="cc-aide">${Object.entries(s.pertes_par_raison).map(([r, v]) => `${esc(r)} ${formatMontant(v)}`).join(" · ") || "au prix d'achat"}</span></div>` : "",
    `<div class="chiffre-cle ${aValider.length ? "alerte-orange" : "calme"} statique"><span class="cc-chiffre">${aValider.length}</span>
      <span class="cc-libelle">Inventaire${aValider.length > 1 ? "s" : ""} à valider</span><span class="cc-aide">${aValider.length ? (estAdmin() ? "cliquez dessus ci-dessous" : "l'Admin doit valider") : "rien en attente"}</span></div>`,
  ].join("");
  const tuileInventaire = i => `<button class="tuile-arrivage etat-${i.statut === "À valider" ? "a-completer" : i.statut === "Abandonné" ? "annule" : "paye"}" onclick="ouvrirInventaire(${i.id})">
      <span class="tarr-haut"><b>Inventaire du ${formatDate(i.date)}</b><span class="tarr-etat">${esc(i.statut)}</span></span>
      <span class="tarr-contenu">${i.nb_articles} article${i.nb_articles > 1 ? "s" : ""} compté${i.nb_articles > 1 ? "s" : ""} · ${i.nb_ecarts ? `<b>${i.nb_ecarts} écart${i.nb_ecarts > 1 ? "s" : ""}</b>` : "aucun écart"}${
        i.valeur_ecart !== undefined && i.valeur_ecart ? ` · ${i.valeur_ecart > 0 ? "+" : ""}${formatMontant(i.valeur_ecart)}` : ""}</span>
      <span class="tarr-bas">${esc(i.numero)} · compté par ${esc(i.saisi_par)}${i.valide_par ? ` · validé par ${esc(i.valide_par)}` : ""}</span></button>`;
  zone.innerHTML = (aValider.length ? `<h3 class="titre-groupe">À valider</h3><div class="tuiles-arrivages">${aValider.map(tuileInventaire).join("")}</div>` : "")
    + `<h3 class="titre-groupe">Dernières sorties</h3>`
    + (s.sorties.length ? `<div class="card"><div class="fa-liste">${s.sorties.slice(0, 60).map(x => `
        <div class="fa-ligne ligne-fiche" data-fiche="sortie:${x.id}" tabindex="0"><span>${formatDate(x.date)} — <b>${esc(x.article)}</b> <small>· ${esc(x.motif)}${x.saisi_par ? ` · ${esc(x.saisi_par)}` : ""}</small></span>
          <span><b class="moins">− ${esc(x.quantite_texte)}</b>${x.valeur !== undefined ? ` <small>(${formatMontant(x.valeur)})</small>` : ""}</span></div>`).join("")}</div></div>`
      : '<div class="card vide">Aucune sortie pour l\'instant. Un produit cassé, périmé ou disparu ? « − Sortie de stock ».</div>')
    + (inventairesCache.filter(i => i.statut !== "À valider").length
      ? `<h3 class="titre-groupe">Inventaires passés</h3><div class="tuiles-arrivages">${inventairesCache.filter(i => i.statut !== "À valider").slice(0, 12).map(tuileInventaire).join("")}</div>` : "");
}

// ---------- Sortie de stock (fenêtre) ----------

async function nouvelleSortie(articleId = null) {
  try {
    await chargerOptionsCommerce();
    if (!articlesCache.length || articleId) articlesCache = await api("/api/articles");
  } catch (e) { toast(e.message); return; }
  const disponibles = articlesCache.filter(a => a.actif && a.stock > 0);
  if (!disponibles.length) { toast("Aucun article en stock pour l'instant."); return; }
  const raisons = Object.keys(AIDE_RAISON);
  const fen = ouvrirFenetre(`
    <div class="modal-tete"><h3>Sortie de stock</h3><button class="ibtn" data-fermer data-tip="Fermer">✕</button></div>
    <p>Marchandise cassée, périmée, disparue ou utilisée par la boutique : elle sort du stock, sans vente.</p>
    <div class="fgrid">
      <div class="field large"><label for="soArticle">Article</label><select id="soArticle"></select></div>
      <div class="field"><label for="soUnite">Sortie par</label><select id="soUnite"></select></div>
      <div class="field"><label for="soQuantite">Quantité</label><input id="soQuantite" inputmode="decimal" placeholder="ex : 3"></div>
    </div>
    <div class="field"><label>Pourquoi ?</label><div class="choix-raison">${raisons.map((r, i) => `
      <label class="raison${i === 0 ? " choisie" : ""}"><input type="radio" name="soRaison" value="${esc(r)}"${i === 0 ? " checked" : ""}><b>${esc(r)}</b>${AIDE_RAISON[r] ? `<small>${esc(AIDE_RAISON[r])}</small>` : ""}</label>`).join("")}</div></div>
    <div class="field"><label for="soNote">Précision (facultatif)</label><input id="soNote" maxlength="150" placeholder="ex : carton tombé à la livraison"></div>
    <div class="total-arrivage" id="soApres"></div>
    <div class="form-erreur" role="alert"></div>
    <div class="actions"><button class="btn" data-fermer>Fermer</button><button class="btn primary" data-action="sortir">Enregistrer la sortie</button></div>`);
  const choix = fen.querySelector("#soArticle");
  remplirSelect(choix, disponibles, { valeur: a => a.id, texte: a => `${a.nom} (en stock : ${a.stock_texte})` });
  if (articleId && disponibles.some(a => a.id === articleId)) choix.value = articleId;
  const article = () => disponibles.find(a => String(a.id) === choix.value);
  const contenance = () => {
    const a = article(), u = fen.querySelector("#soUnite").value;
    return u ? a.unites.find(x => String(x.id) === u).contenance : 1;
  };
  const majApres = () => {
    const a = article(), q = lireQuantite(fen.querySelector("#soQuantite").value);
    fen.querySelector("#soApres").innerHTML = q ? (q * contenance() > a.stock
      ? `<b class="moins">Il n'en reste que ${esc(a.stock_texte)} : impossible d'en sortir autant.</b>`
      : `Il restera <b>${nombre(a.stock - q * contenance())} ${esc(a.unite_base)}</b> en stock.`) : "";
  };
  const majUnites = () => {
    const a = article();
    remplirSelect(fen.querySelector("#soUnite"), [{ id: "", nom: a.unite_base }, ...a.unites.map(u => ({ id: u.id, nom: `${u.nom} (${nombre(u.contenance)})` }))],
      { valeur: u => u.id, texte: u => u.nom });
    majApres();
  };
  choix.addEventListener("change", majUnites);
  fen.querySelector("#soUnite").addEventListener("change", majApres);
  fen.querySelector("#soQuantite").addEventListener("input", majApres);
  fen.querySelectorAll('input[name="soRaison"]').forEach(r => r.addEventListener("change", () => {
    fen.querySelectorAll(".raison").forEach(l => l.classList.toggle("choisie", l.querySelector("input").checked));
  }));
  majUnites();
  fen.querySelector("#soQuantite").focus();
  fen.querySelector('[data-action="sortir"]').addEventListener("click", async () => {
    const erreur = fen.querySelector(".form-erreur");
    try {
      const quantite = lireQuantite(fen.querySelector("#soQuantite").value);
      if (!quantite) throw new Error("Indiquez la quantité qui sort.");
      const r = await api("/api/stock/sorties", { method: "POST", body: {
        article_id: article().id, unite_id: fen.querySelector("#soUnite").value ? Number(fen.querySelector("#soUnite").value) : null,
        quantite, raison: fen.querySelector('input[name="soRaison"]:checked').value,
        note: fen.querySelector("#soNote").value.trim() || null } });
      toast(`Sortie enregistrée : il reste ${r.stock_texte}`, 5000);
      fen.fermer();
      rafraichirCommerce();
    } catch (err) { erreur.textContent = err.message; erreur.style.display = "block"; }
  });
}

// ---------- Inventaire : page de comptage ----------

async function nouvelInventaire() {
  try { articlesInventaire = await api("/api/stock/inventaire/preparer"); } catch (e) { toast(e.message); return; }
  if (!articlesInventaire.length) { toast("Aucun article en vente à compter."); return; }
  fixerDate("invDate", aujourdhui());
  el("invNote").value = "";
  el("invRecherche").value = "";
  el("invValider").checked = false;
  const groupes = {};
  for (const a of articlesInventaire) (groupes[a.categorie] ||= []).push(a);
  el("invArticles").innerHTML = Object.entries(groupes).map(([cat, liste]) => `
    <div class="card"><h3>${esc(cat)}</h3><div class="fa-tableau"><table class="table-inventaire"><thead><tr>
      <th>Article</th><th>Gérimo prévoit</th><th>Vous comptez</th><th>Écart</th></tr></thead><tbody>
      ${liste.map(a => `<tr class="ligne-inv" data-id="${a.id}" data-nom="${esc(normaliser(a.nom))}">
        <td><b>${esc(a.nom)}</b></td><td>${esc(a.stock_texte)}</td>
        <td><div class="saisie-comptage">${a.unites.filter(u => u.contenance > 1).map(u => `
          <label><input class="inv-q" data-contenance="${u.contenance}" inputmode="decimal" placeholder="0"> ${esc(u.nom)}</label>`).join("")}
          <label><input class="inv-q" data-contenance="1" inputmode="decimal" placeholder="0"> ${esc(a.unite_base)}</label></div></td>
        <td class="inv-ecart"><span class="petit">—</span></td></tr>`).join("")}
    </tbody></table></div></div>`).join("");
  el("invArticles").querySelectorAll(".inv-q").forEach(c => c.addEventListener("input", majInventaire));
  majInventaire();
  erreurFormulaire(el("formulaireInventaire"), "");
  afficher("formInventaire");
}

// Total compté d'une ligne (null si rien n'est tapé)
function compteLigne(tr) {
  let total = 0, tape = false;
  for (const c of tr.querySelectorAll(".inv-q")) {
    if (!c.value.trim()) continue;
    const q = lireQuantite(c.value);
    if (q === null) return NaN;
    tape = true;
    total += q * Number(c.dataset.contenance);
  }
  return tape ? total : null;
}

function majInventaire() {
  let comptes = 0, ecarts = 0;
  el("invArticles").querySelectorAll(".ligne-inv").forEach(tr => {
    const a = articlesInventaire.find(x => String(x.id) === tr.dataset.id);
    const compte = compteLigne(tr);
    const zone = tr.querySelector(".inv-ecart");
    tr.classList.remove("ecart-plus", "ecart-moins", "ecart-ok");
    if (compte === null) { zone.innerHTML = '<span class="petit">—</span>'; return; }
    if (Number.isNaN(compte)) { zone.innerHTML = '<b class="moins">nombre invalide</b>'; return; }
    comptes++;
    const ecart = Math.round((compte - a.stock_prevu) * 1000) / 1000;
    if (ecart) ecarts++;
    tr.classList.add(ecart > 0 ? "ecart-plus" : ecart < 0 ? "ecart-moins" : "ecart-ok");
    zone.innerHTML = ecart ? `<b class="${ecart > 0 ? "plus" : "moins"}">${ecart > 0 ? "+" : "−"} ${nombre(Math.abs(ecart))} ${esc(a.unite_base)}</b>`
                           : '<b class="plus">✓ juste</b>';
  });
  el("invResume").innerHTML = comptes ? `<b>${comptes}</b> article${comptes > 1 ? "s" : ""} compté${comptes > 1 ? "s" : ""} · `
    + (ecarts ? `<b class="moins">${ecarts} écart${ecarts > 1 ? "s" : ""}</b>` : '<b class="plus">aucun écart</b>') : "";
}

el("invRecherche").addEventListener("input", () => {
  const mots = normaliser(el("invRecherche").value).split(/\s+/).filter(Boolean);
  el("invArticles").querySelectorAll(".ligne-inv").forEach(tr => {
    tr.style.display = mots.every(m => tr.dataset.nom.includes(m)) ? "" : "none";
  });
});

el("formulaireInventaire").addEventListener("submit", e => {
  e.preventDefault();
  soumettre(e.target, async () => {
    const date = valeurDate("invDate", "Date du comptage");
    if (!date) throw new Error("Indiquez la date du comptage (jj/mm/aaaa).");
    const lignes = [];
    for (const tr of el("invArticles").querySelectorAll(".ligne-inv")) {
      const compte = compteLigne(tr);
      if (compte === null) continue;
      if (Number.isNaN(compte)) throw new Error("Un nombre compté est invalide (ex : 12 ou 1,5).");
      lignes.push({ article_id: Number(tr.dataset.id), stock_compte: compte });
    }
    if (!lignes.length) throw new Error("Tapez au moins un article compté.");
    const r = await api("/api/stock/inventaires", { method: "POST", body: {
      date_inventaire: date, note: el("invNote").value.trim() || null, lignes, valider: estAdmin() && el("invValider").checked } });
    toast(r.statut === "Validé" ? "Inventaire validé : le stock est corrigé" : "Inventaire enregistré : l'Admin doit le valider", 6000);
    ongletStock = "stSorties";
    goBack();
  });
});

// ---------- Fenêtre d'un inventaire : écarts, validation (Admin) ----------

function ouvrirInventaire(id) {
  const i = inventairesCache.find(x => x.id === id);
  if (!i) return;
  const code = i.statut === "À valider" ? "a-completer" : i.statut === "Abandonné" ? "annule" : "paye";
  const argent = i.valeur_ecart !== undefined;
  const fen = ouvrirFenetre(`<div class="fiche-article">
    <div class="fa-tete"><div><h2>Inventaire du ${formatDate(i.date)}</h2><p>${esc(i.numero)} · compté par ${esc(i.saisi_par)}${i.valide_par ? ` · validé par ${esc(i.valide_par)}` : ""}</p></div>
      <button class="ibtn" data-fermer data-tip="Fermer" aria-label="Fermer">✕</button></div>
    <div class="fa-stock etat-${code}"><span class="fa-etat">${esc(i.statut)}</span>
      <span class="fa-quantite">${i.nb_ecarts ? `${i.nb_ecarts} écart${i.nb_ecarts > 1 ? "s" : ""}` : "Aucun écart"}</span>
      <span class="fa-aide">${i.nb_articles} article${i.nb_articles > 1 ? "s" : ""} compté${i.nb_articles > 1 ? "s" : ""}${
        argent && i.valeur_ecart ? ` · valeur de l'écart ${i.valeur_ecart > 0 ? "+" : ""}${formatMontant(i.valeur_ecart)}` : ""}${
        i.statut === "À valider" ? " · à la validation, le stock prend les quantités comptées" : ""}</span></div>
    <div class="fa-tableau"><table><thead><tr><th>Article</th><th>Prévu</th><th>Compté</th><th>Écart</th>${argent ? "<th>Valeur</th>" : ""}</tr></thead><tbody>
      ${i.lignes.map(l => `<tr><td><b>${esc(l.article)}</b></td><td>${nombre(l.stock_prevu)}</td><td>${nombre(l.stock_compte)}</td>
        <td><b class="${l.ecart > 0 ? "plus" : l.ecart < 0 ? "moins" : ""}">${l.ecart ? esc(l.ecart_texte) : "✓"}</b></td>
        ${argent ? `<td>${l.valeur_ecart ? formatMontant(l.valeur_ecart) : "—"}</td>` : ""}</tr>`).join("")}</tbody></table></div>
    ${i.note ? `<h4>Note</h4><p>${esc(i.note)}</p>` : ""}
    <div class="actions">
      ${estAdmin() && i.statut === "À valider" ? '<button class="btn ghost" data-action="abandonner">Abandonner</button>' : ""}
      <button class="btn" data-fermer>Fermer</button>
      ${estAdmin() && i.statut === "À valider" ? '<button class="btn primary" data-action="valider">Valider et corriger le stock</button>' : ""}
    </div></div>`, { taille: "large" });
  const agir = (action, message) => fen.querySelector(`[data-action="${action}"]`)?.addEventListener("click", async () => {
    try {
      await api(`/api/stock/inventaires/${i.id}/${action}`, { method: "POST" });
      toast(message, 5000);
      fen.fermer();
      rafraichirCommerce();
    } catch (err) { toast(err.message, 7000); }
  });
  agir("valider", "Inventaire validé : le stock est corrigé");
  agir("abandonner", "Inventaire abandonné : le stock n'a pas changé");
}

// Fiche d'une sortie (enregistrée dans le registre des fiches, chargé après ce script)
window.addEventListener("load", () => {
  if (typeof FICHES === "undefined") return;
  FICHES.sortie = id => {
    const x = sortiesCache.find(y => y.id === id);
    if (!x) return;
    ficheSimple({
      titre: x.article, sous: `${formatDate(x.date)}${x.saisi_par ? " · par " + esc(x.saisi_par) : ""}`,
      code: "a_risque", etat: `Sortie : ${x.raison}`, grand: `− ${esc(x.quantite_texte)}`, aide: esc(x.motif),
      stats: [["Motif", esc(x.raison)], x.valeur !== undefined ? ["Ce que ça avait coûté", formatMontant(x.valeur), "au prix d'achat", "negatif"] : null],
    });
  };
});
