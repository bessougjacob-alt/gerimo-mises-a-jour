// Raccourcis clavier :
//   Échap          : ferme ce qui est ouvert (menu, fenêtre, formulaire) ; sinon ouvre / ferme le menu
//   Ctrl + Z       : annule la dernière saisie du champ (puis l'efface)
//   Ctrl + Maj + Z : vide tous les champs du formulaire
//   Ctrl + S       : enregistre le formulaire
//   ← / →          : onglet précédent / suivant (Paramètres, Trésorerie, Rapports, Agenda, panneau Gérimo…)


// ---------- Formulaire « en cours » : fenêtre ouverte, sinon écran affiché ----------
function fenetreOuverte() {
  return [...document.querySelectorAll(".modal-overlay.show")].pop() || null;
}
function formulaireCourant() {
  const fenetre = fenetreOuverte();
  if (fenetre) return fenetre.querySelector("form");
  return document.querySelector(".screen.active form.card") || null;
}

// ---------- Ctrl + Z : historique de saisie de chaque champ ----------
const estChampTexte = c => c && ((c.tagName === "INPUT" && !["checkbox", "radio", "file", "button", "submit", "hidden"].includes(c.type))
                                 || c.tagName === "TEXTAREA");
document.addEventListener("focusin", e => {
  const c = e.target;
  if (estChampTexte(c) || c.tagName === "SELECT") { c._historique = [c.value]; c._derniereFrappe = 0; }
});
document.addEventListener("input", e => {
  const c = e.target;
  if (!estChampTexte(c) || c._restauration || !c._historique) return;
  const maintenant = Date.now();
  // les frappes rapprochées forment une seule étape (on annule mot par mot, pas lettre par lettre)
  if (maintenant - c._derniereFrappe < 700 && c._historique.length > 1) c._historique[c._historique.length - 1] = c.value;
  else c._historique.push(c.value);
  c._derniereFrappe = maintenant;
}, true);

function annulerSaisie(c) {
  if (c.tagName === "SELECT") {
    c.value = c._historique?.[0] ?? c.value;
  } else {
    const h = c._historique || [c.value];
    if (h.length > 1) { h.pop(); c.value = h[h.length - 1]; }
    else { c.value = ""; c._historique = [""]; }   // plus rien à annuler : le champ est effacé
    c._derniereFrappe = 0;
  }
  c._restauration = true;
  c.dispatchEvent(new Event("input", { bubbles: true }));
  c.dispatchEvent(new Event("change", { bubbles: true }));
  c._restauration = false;
}

function viderFormulaire(form) {
  form.querySelectorAll("input, textarea").forEach(c => {
    if (c.disabled || c.readOnly || !estChampTexte(c) || c.classList.contains("date-cache")) return;
    c.value = "";
    c._historique = [""];
  });
  if (typeof reinitialiserSaisie === "function") reinitialiserSaisie(form);
  if (form.querySelector(".form-erreur")) erreurFormulaire(form, "");
  toast("Tous les champs ont été vidés");
}

// ---------- Échap ----------
function fermerFenetreStatique(fenetre) {
  const bouton = [...fenetre.querySelectorAll("button")].find(b => /^(Annuler|Fermer|✕)$/.test(b.textContent.trim()));
  if (bouton) bouton.click(); else fenetre.classList.remove("show");
}

function gererEchap() {
  if (document.querySelector(".menu-flottant")) { fermerMenusFlottants(); return; }
  const fenetre = fenetreOuverte();
  if (fenetre) {
    if (!fenetre.id) return;            // fenêtre créée à la demande : elle se ferme d'elle-même
    fermerFenetreStatique(fenetre);
    return;
  }
  if (el("panneauAssistant")?.classList.contains("show")) { fermerAssistant(); return; }
  if (el("sideMenu").classList.contains("show")) { closeMenu(); return; }
  const ecran = document.querySelector(".screen.active");
  if (ecran && ecran.querySelector("form.card") && screenHistory.length > 1) { goBack(); return; }  // formulaire ouvert
  toggleMenu();
}

// ---------- Flèches gauche / droite : onglet précédent / suivant ----------
// Groupes d'onglets : .onglets (écrans), .ap-onglets (panneau Gérimo), [data-onglets] (filtres en forme d'onglets).
// Jamais pendant une saisie (la flèche déplace alors le curseur) ni avec Alt (retour du navigateur).
const GROUPES_ONGLETS = ".onglets, .ap-onglets, [data-onglets]";
const estVisible = x => x && x.offsetParent !== null && getComputedStyle(x).visibility !== "hidden";

function groupeOngletsCourant() {
  const fenetre = fenetreOuverte();
  const panneau = document.getElementById("panneauAssistant");
  let zone;
  if (fenetre) zone = fenetre;                                       // une fenêtre ouverte : seulement ses onglets
  else if (panneau && panneau.classList.contains("show")
           && (panneau.contains(document.activeElement) || panneau.matches(":hover"))) zone = panneau;
  else zone = document.querySelector(".screen.active");
  if (!zone) return null;
  const groupes = [...zone.querySelectorAll(GROUPES_ONGLETS)].filter(estVisible);
  // plusieurs groupes visibles : celui qui contient l'élément actif, sinon le premier (le plus haut)
  return groupes.find(g => g.contains(document.activeElement)) || groupes[0] || null;
}

function changerOnglet(sens) {
  const groupe = groupeOngletsCourant();
  if (!groupe) return false;
  const onglets = [...groupe.querySelectorAll(":scope > button")].filter(b => estVisible(b) && !b.disabled);
  if (onglets.length < 2) return false;
  const actuel = onglets.findIndex(b => b.classList.contains("actif"));
  const suivant = onglets[(Math.max(actuel, 0) + sens + onglets.length) % onglets.length];
  suivant.click();
  // le nouvel onglet reçoit le focus seulement si on naviguait déjà dans la barre
  if (groupe.contains(document.activeElement)) suivant.focus();
  suivant.scrollIntoView({ block: "nearest", inline: "nearest" });
  return true;
}

document.addEventListener("keydown", e => {
  if (e.defaultPrevented || (e.key !== "ArrowLeft" && e.key !== "ArrowRight")) return;
  if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
  const c = document.activeElement;
  if (estChampTexte(c) || c?.tagName === "SELECT" || c?.isContentEditable
      || (c?.tagName === "INPUT" && ["range", "radio"].includes(c.type))) return;
  if (document.body.classList.contains("en-veille") || document.getElementById("sideMenu")?.classList.contains("show")) return;
  if (changerOnglet(e.key === "ArrowRight" ? 1 : -1)) e.preventDefault();
});

document.addEventListener("keydown", e => {
  if (e.defaultPrevented) return;
  const touche = e.key.toLowerCase();   // fonctionne en AZERTY comme en QWERTY
  const ctrl = e.ctrlKey || e.metaKey;

  if (e.key === "Escape") {
    gererEchap();
    return;
  }
  if (ctrl && touche === "s") {
    e.preventDefault();                  // pas de « Enregistrer la page » du navigateur
    const form = formulaireCourant();
    if (form && form.querySelector('button[type="submit"]')) form.requestSubmit();
    else toast("Aucun formulaire à enregistrer sur cet écran.");
    return;
  }
  if (ctrl && touche === "z") {
    const form = formulaireCourant();
    if (e.shiftKey) {
      e.preventDefault();
      if (!form) { toast("Aucun formulaire ouvert."); return; }
      if (confirm("Vider tous les champs de ce formulaire ?")) viderFormulaire(form);
      return;
    }
    const c = document.activeElement;
    if (estChampTexte(c) || c?.tagName === "SELECT") {
      e.preventDefault();
      annulerSaisie(c);
    }
  }
});

// La liste des raccourcis est rangée dans Paramètres → Assistant → « Raccourcis clavier » (demande de Boss du
// 14/11/2026 : le rappel sous chaque formulaire surchargeait les fenêtres).
const LISTE_RACCOURCIS = [
  ["Ctrl + S", "Enregistrer le formulaire ouvert"],
  ["Échap", "Fermer ce qui est ouvert (fenêtre, formulaire, menu) ; sinon ouvrir ou fermer le menu"],
  ["Ctrl + Z", "Annuler la dernière saisie du champ (puis l'effacer)"],
  ["Ctrl + Maj + Z", "Vider tous les champs du formulaire"],
  ["← / →", "Rubrique précédente / suivante (Paramètres, Trésorerie, Stock, Ventes, Rapports, Agenda…)"],
  ["Retour arrière", "Revenir à l'écran précédent (quand on n'écrit pas dans un champ)"],
  ["Ctrl + L", "Mettre Gérimo en veille tout de suite (écran verrouillé)"],
  ["Ctrl + F5", "Rafraîchir complètement la page"],
  ["Entrée (caisse)", "Dans la recherche de la caisse : ajoute le premier article trouvé, ou l'article scanné à la douchette"],
];
