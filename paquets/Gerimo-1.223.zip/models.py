from sqlalchemy import Column, Integer, String, Boolean, Date, DateTime, Enum, ForeignKey, CHAR, Numeric, Text, Table, Time
from sqlalchemy.dialects.postgresql import ARRAY, JSONB
from sqlalchemy.orm import declarative_base, relationship
from datetime import datetime
from decimal import Decimal
import enum

Base = declarative_base()

class RoleUtilisateur(str, enum.Enum):
    Admin = "Admin"
    Gestionnaire = "Gestionnaire"
    Caisse = "Caisse"
    Comptable = "Comptable"

class Utilisateur(Base):
    __tablename__ = "utilisateurs"

    id = Column(Integer, primary_key=True)
    nom_complet = Column(String(150), nullable=False)
    identifiant = Column(String(80), unique=True, nullable=False)
    mot_de_passe = Column(String(255), nullable=False)
    role = Column(Enum(RoleUtilisateur, name="role_utilisateur", create_type=False), nullable=False)
    actif = Column(Boolean, default=True)
    fonction = Column(String(120))   # carte de visite : fixée par l'Admin
    appellation = Column(String(80))  # comment l'assistant l'appelle (« Monsieur BESSOU ») ; vide = prénom (migration 034)
    cree_le = Column(DateTime, default=datetime.now)
    # mot de passe donné par l'Admin : à remplacer à la première connexion (migration 030)
    mdp_provisoire = Column(Boolean, default=False, nullable=False)
    mdp_provisoire_expire_le = Column(DateTime)
    mdp_redonne_le = Column(DateTime)
    mdp_redonne_par = Column(Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"))

class Session(Base):
    __tablename__ = "sessions"

    id = Column(Integer, primary_key=True)
    jeton_hache = Column(CHAR(64), unique=True, nullable=False)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id"), nullable=False)
    cree_le = Column(DateTime, default=datetime.now)
    expire_le = Column(DateTime, nullable=False)
    # mode veille (migration 030) : session verrouillée, à rouvrir avec le mot de passe
    veille = Column(Boolean, default=False, nullable=False)
    derniere_activite = Column(DateTime)
    veille_minutes = Column(Integer, default=20, nullable=False)  # 0 : pas de veille automatique
    essais_reveil = Column(Integer, default=0, nullable=False)
    appareil = Column(String(40))

    utilisateur = relationship(Utilisateur)


class AppareilHorsReseau(Base):
    """Téléphone autorisé à rafraîchir en arrière-plan sa copie hors réseau (migration 027)."""
    __tablename__ = "appareils_hors_reseau"

    id = Column(Integer, primary_key=True)
    code_appareil = Column(String(64), unique=True, nullable=False)
    nom = Column(String(120), nullable=False)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id"), nullable=False)
    jeton_hache = Column(CHAR(64), unique=True, nullable=False)
    cree_le = Column(DateTime, default=datetime.now)
    derniere_copie_le = Column(DateTime)
    retire_le = Column(DateTime)
    retire_par = Column(Integer, ForeignKey("utilisateurs.id"))

    utilisateur = relationship(Utilisateur, foreign_keys=[utilisateur_id])


class OperationHorsReseau(Base):
    """Enregistrement fait hors réseau, envoyé au retour du serveur (migration 028)."""
    __tablename__ = "operations_hors_reseau"

    id = Column(Integer, primary_key=True)
    uid = Column(String(64), unique=True, nullable=False)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id"), nullable=False)
    appareil_nom = Column(String(120))
    methode = Column(String(6), nullable=False)
    chemin = Column(String(300), nullable=False)
    corps = Column(JSONB, nullable=False, default=dict)
    resume = Column(String(300), nullable=False, default="")
    id_local = Column(Numeric(20, 0))
    id_reel = Column(Integer)
    saisi_le = Column(DateTime, nullable=False)
    recu_le = Column(DateTime, default=datetime.now)
    statut = Column(String(12), nullable=False)
    detail = Column(Text)
    traite_par = Column(Integer, ForeignKey("utilisateurs.id"))
    traite_le = Column(DateTime)
    argent_recu_le = Column(DateTime)       # encaissement hors réseau : argent remis à la caisse (migration 029)
    argent_recu_par = Column(Integer, ForeignKey("utilisateurs.id"))

    utilisateur = relationship(Utilisateur, foreign_keys=[utilisateur_id])

# ---------- Biens (étape 2) ----------

# Libellés officiels : mêmes valeurs que les ENUM de schema.sql
# « Type de bien » dans l'interface (colonne type_batiment en base)
TYPES_BATIMENT = ("Appartement/Immeuble", "Cité", "Maison basse", "Villa", "Duplex",
                  "Cour commune", "Résidence", "Parcelle")
# Une parcelle a ses propres champs (table parcelles) : pas de logement de type Parcelle
TYPES_BATIMENT_LOGEMENT = tuple(t for t in TYPES_BATIMENT if t != "Parcelle")
APPROBATIONS_PARCELLE = ("Approuvé", "Non-approuvé", "En attente")
TYPES_LOGEMENT = ("Studio", "2 pièces", "3 pièces", "4 pièces", "5 pièces", "6 pièces",
                  "7 pièces", "8 pièces", "Villa de plus de 8 pièces", "Magasin")
# Logement repris d'un ancien fichier sans son type : à corriger plus tard sur sa fiche (migration 039)
TYPE_A_PRECISER = "À préciser"
TYPES_LOGEMENT_FICHE = TYPES_LOGEMENT + (TYPE_A_PRECISER,)
STATUTS_LOGEMENT = ("Libre", "Occupé", "Réservé", "Maintenance")

gestionnaires_cites = Table(
    "gestionnaires_cites", Base.metadata,
    Column("utilisateur_id", Integer, ForeignKey("utilisateurs.id"), primary_key=True),
    Column("cite_id", Integer, ForeignKey("cites.id"), primary_key=True),
)

class Proprietaire(Base):
    __tablename__ = "proprietaires"

    id = Column(Integer, primary_key=True)
    nom_complet = Column(String(150), nullable=False)
    cni = Column(String(50))
    telephone = Column(String(30))
    ville = Column(String(80))
    email = Column(String(150))
    cree_le = Column(DateTime, default=datetime.now)

    cites = relationship("Cite", back_populates="proprietaire")

class Cite(Base):
    __tablename__ = "cites"

    id = Column(Integer, primary_key=True)
    nom = Column(String(150), nullable=False)
    adresse = Column(String(200))
    proprietaire_id = Column(Integer, ForeignKey("proprietaires.id"))
    description = Column(Text)
    cree_le = Column(DateTime, default=datetime.now)

    proprietaire = relationship(Proprietaire, back_populates="cites")
    logements = relationship("Logement", back_populates="cite", order_by="Logement.numero_logement")
    parcelles = relationship("Parcelle", back_populates="cite", order_by="Parcelle.numero_parcelle")
    # Utilisateur.cites_gerees : les cités confiées à un compte Gestionnaire
    gestionnaires = relationship(Utilisateur, secondary=gestionnaires_cites, backref="cites_gerees")
    # Mandats de gestion, du plus récent au plus ancien (historique des %)
    mandats = relationship("ContratGestion", back_populates="cite",
                           order_by=lambda: [ContratGestion.date_debut.desc(), ContratGestion.id.desc()])

    @property
    def mandat_actuel(self):
        return self.mandats[0] if self.mandats else None


class GestionnaireMandataire(Base):
    """Société qui gère les biens pour le compte des propriétaires (l'entreprise cliente, « Mon entreprise »)."""
    __tablename__ = "gestionnaires"

    id = Column(Integer, primary_key=True)
    nom = Column(String(150), nullable=False)
    rccm = Column(String(80))
    ncc = Column(String(80))
    adresse = Column(String(200))
    ville = Column(String(80))
    cree_le = Column(DateTime, default=datetime.now)


class ContratGestion(Base):
    """Mandat ISUP ↔ propriétaire ↔ bien, avec le % de commission."""
    __tablename__ = "contrats_gestion"

    id = Column(Integer, primary_key=True)
    gestionnaire_id = Column(Integer, ForeignKey("gestionnaires.id"), nullable=False)
    proprietaire_id = Column(Integer, ForeignKey("proprietaires.id"), nullable=False)
    cite_id = Column(Integer, ForeignKey("cites.id"), nullable=False)
    pourcentage_commission = Column(Numeric(5, 2), nullable=False)
    date_debut = Column(Date, nullable=False)
    cree_le = Column(DateTime, default=datetime.now)

    cite = relationship(Cite, back_populates="mandats")

class Logement(Base):
    __tablename__ = "logements"

    id = Column(Integer, primary_key=True)
    cite_id = Column(Integer, ForeignKey("cites.id"), nullable=False)
    type_batiment = Column(Enum(*TYPES_BATIMENT, name="type_batiment", create_type=False), nullable=False)
    numero_logement = Column(String(30), nullable=False)
    type_logement = Column(Enum(*TYPES_LOGEMENT_FICHE, name="type_logement", create_type=False), nullable=False)
    loyer = Column(Numeric(12, 2), nullable=False)
    statut_logement = Column(Enum(*STATUTS_LOGEMENT, name="statut_logement", create_type=False),
                             nullable=False, default="Libre")
    prix_nuit = Column(Numeric(12, 2))  # rempli = logement proposé en courte durée (séjours)
    cree_le = Column(DateTime, default=datetime.now)

    cite = relationship(Cite, back_populates="logements")
    contrats = relationship("Contrat", back_populates="logement")

class Parcelle(Base):
    __tablename__ = "parcelles"

    id = Column(Integer, primary_key=True)
    cite_id = Column(Integer, ForeignKey("cites.id"), nullable=False)
    numero_parcelle = Column(String(30), nullable=False)
    superficie = Column(Numeric(12, 2), nullable=False)  # m²
    situation_geographique = Column(String(200))
    documents = Column(Text)
    prix_entree = Column(Numeric(14, 2))
    dernier_prix = Column(Numeric(14, 2))
    approbation = Column(Enum(*APPROBATIONS_PARCELLE, name="approbation_parcelle", create_type=False),
                         nullable=False, default="En attente")
    disponible = Column(Boolean, nullable=False, default=True)
    cree_le = Column(DateTime, default=datetime.now)

    cite = relationship(Cite, back_populates="parcelles")

# ---------- Locataires et contrats de bail (étape 3) ----------

TYPES_CONTRAT = ("Bail habitation", "Bail commercial", "Location meublée", "Courte durée",
                 "Colocation", "Gestion immobilière")
USAGES_BIEN = ("Habitation", "Commercial", "Professionnel", "Industriel", "Stockage",
               "Mixte (habitation + activités)", "Courte durée")
STATUTS_CONTRAT = ("Actif", "Expiré", "Résilié", "Suspendu", "En attente", "Renouvelé")
TERMES_LOYER = ("Début de mois", "Fin de mois")
# Un contrat « en cours » occupe son logement (un seul à la fois par logement)
STATUTS_EN_COURS = ("Actif", "Renouvelé", "Suspendu", "En attente")

class Locataire(Base):
    __tablename__ = "locataires"

    id = Column(Integer, primary_key=True)
    nom_complet = Column(String(150), nullable=False)
    cni = Column(String(50))
    telephone = Column(String(30))
    profession = Column(String(100))
    email = Column(String(150))
    cree_le = Column(DateTime, default=datetime.now)

    contrats = relationship("Contrat", back_populates="locataire", order_by="Contrat.date_debut.desc()")

class Contrat(Base):
    __tablename__ = "contrats"

    id = Column(Integer, primary_key=True)
    numero_contrat = Column(String(40), unique=True, nullable=False)
    logement_id = Column(Integer, ForeignKey("logements.id"), nullable=False)
    locataire_id = Column(Integer, ForeignKey("locataires.id"), nullable=False)
    type_contrat = Column(Enum(*TYPES_CONTRAT, name="type_contrat", create_type=False), nullable=False)
    usage_bien = Column(Enum(*USAGES_BIEN, name="usage_bien", create_type=False), nullable=False)
    statut_contrat = Column(Enum(*STATUTS_CONTRAT, name="statut_contrat", create_type=False),
                            nullable=False, default="Actif")
    terme_loyer = Column(Enum(*TERMES_LOYER, name="terme_loyer", create_type=False),
                         nullable=False, default="Début de mois")
    montant_loyer = Column(Numeric(12, 2), nullable=False)
    mois_caution = Column(Integer, default=0)
    montant_caution = Column(Numeric(12, 2), default=0)
    mois_avance = Column(Integer, default=0)
    montant_avance = Column(Numeric(12, 2), default=0)
    date_debut = Column(Date, nullable=False)
    suivi_depuis = Column(Date)  # reprise : Gérimo compte les loyers à partir de ce mois (migration 038)
    date_fin = Column(Date)
    date_resiliation = Column(Date)
    motif_resiliation = Column(Text)
    # départ annoncé par le locataire (préavis) : les loyers s'arrêtent au mois du départ
    date_preavis = Column(Date)
    date_depart = Column(Date)
    motif_depart = Column(Text)
    mois_impayes_consecutifs = Column(Integer, nullable=False, default=0)
    cree_le = Column(DateTime, default=datetime.now)

    logement = relationship(Logement, back_populates="contrats")
    locataire = relationship(Locataire, back_populates="contrats")
    echeances = relationship("Echeance", back_populates="contrat", order_by="Echeance.mois_echeance")

# ---------- Paiements, encaissements, échéances, impayés (étape 4) ----------

MODES_PAIEMENT = ("Espèce", "Mobile Money", "Virement", "Chèque", "Autre")
MOTIFS_PAIEMENT = ("Loyer mensuel", "Caution/avance", "Règlement total")
STATUTS_PAIEMENT = ("Payé", "En attente", "Annulé", "Impayé", "Remboursé")
STATUTS_IMPAYES = ("En retard", "À risque", "Régularisé")

class Echeance(Base):
    """Un mois de loyer dû pour un contrat (réglé quand paiement_id est renseigné)."""
    __tablename__ = "echeances"

    id = Column(Integer, primary_key=True)
    contrat_id = Column(Integer, ForeignKey("contrats.id"), nullable=False)
    mois_echeance = Column(Date, nullable=False)  # 1er du mois
    montant_loyer = Column(Numeric(12, 2), nullable=False)
    montant_charges = Column(Numeric(12, 2), default=0)
    date_limite = Column(Date, nullable=False)    # le 05 du mois (ou du mois suivant)
    paiement_id = Column(Integer, ForeignKey("paiements.id"))  # le paiement qui a SOLDÉ le mois
    montant_verse = Column(Numeric(12, 2), nullable=False, default=0)  # versements partiels compris (migration 037)
    cree_le = Column(DateTime, default=datetime.now)

    contrat = relationship(Contrat, back_populates="echeances")
    paiement = relationship("Paiement", back_populates="echeances")
    versements = relationship("VersementEcheance", back_populates="echeance", order_by="VersementEcheance.id",
                              cascade="all, delete-orphan", passive_deletes=True)

    @property
    def reste(self) -> Decimal:
        """Ce qu'il reste à payer sur ce mois (0 quand il est soldé)."""
        if self.paiement is not None:
            return Decimal(0)
        return self.montant_loyer - (self.montant_verse or Decimal(0))

# ---------- Trésorerie (précomptabilité, migration 021) ----------

TYPES_COMPTE = ("Caisse", "Banque", "Mobile Money")

class CompteTresorerie(Base):
    """Endroit où se trouve l'argent : caisse, compte bancaire, compte Mobile Money."""
    __tablename__ = "comptes_tresorerie"

    id = Column(Integer, primary_key=True)
    nom = Column(String(80), unique=True, nullable=False)
    type_compte = Column(String(20), nullable=False)
    numero = Column(String(60))
    modes_paiement = Column(ARRAY(Text), nullable=False, default=list)
    solde_initial = Column(Numeric(14, 2), nullable=False, default=0)
    date_ouverture = Column(Date, nullable=False)
    actif = Column(Boolean, nullable=False, default=True)
    compte_comptable = Column(String(12))   # export SYSCOHADA (vide = 5711 caisse, 5211 banque, 5521 Mobile Money)
    cree_le = Column(DateTime, default=datetime.now)

class TransfertTresorerie(Base):
    __tablename__ = "transferts_tresorerie"

    id = Column(Integer, primary_key=True)
    numero = Column(String(30), unique=True, nullable=False)
    date_transfert = Column(Date, nullable=False)
    compte_source = Column(Integer, ForeignKey("comptes_tresorerie.id"), nullable=False)
    compte_cible = Column(Integer, ForeignKey("comptes_tresorerie.id"), nullable=False)
    montant = Column(Numeric(14, 2), nullable=False)
    frais = Column(Numeric(14, 2), nullable=False, default=0)
    libelle = Column(String(200))
    reference = Column(String(80))
    saisi_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    source = relationship(CompteTresorerie, foreign_keys=[compte_source])
    cible = relationship(CompteTresorerie, foreign_keys=[compte_cible])
    auteur = relationship(Utilisateur)

class ArreteCaisse(Base):
    __tablename__ = "arretes_caisse"

    id = Column(Integer, primary_key=True)
    compte_id = Column(Integer, ForeignKey("comptes_tresorerie.id"), nullable=False)
    date_arrete = Column(Date, nullable=False)
    solde_calcule = Column(Numeric(14, 2), nullable=False)
    solde_compte = Column(Numeric(14, 2), nullable=False)
    ecart = Column(Numeric(14, 2), nullable=False)
    billetage = Column(JSONB, nullable=False, default=dict)
    observation = Column(Text)
    saisi_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    compte = relationship(CompteTresorerie)
    auteur = relationship(Utilisateur)

class Paiement(Base):
    __tablename__ = "paiements"

    id = Column(Integer, primary_key=True)
    contrat_id = Column(Integer, ForeignKey("contrats.id"), nullable=False)
    montant = Column(Numeric(12, 2), nullable=False)
    date_paiement = Column(Date, nullable=False)
    statut_paiement = Column(Enum(*STATUTS_PAIEMENT, name="statut_paiement", create_type=False),
                             nullable=False, default="Payé")
    mode_paiement = Column(Enum(*MODES_PAIEMENT, name="mode_paiement", create_type=False), nullable=False)
    motif_paiement = Column(Enum(*MOTIFS_PAIEMENT, name="motif_paiement", create_type=False), nullable=False)
    numero_recu = Column(String(30), unique=True)
    periode_debut = Column(Date)
    periode_fin = Column(Date)
    nb_mois = Column(Integer)
    encaisse_par = Column(Integer, ForeignKey("utilisateurs.id"))
    date_annulation = Column(DateTime)
    motif_annulation = Column(Text)
    compte_id = Column(Integer, ForeignKey("comptes_tresorerie.id"))  # vide = rangé selon le mode
    versement_partiel = Column(Boolean, nullable=False, default=False)  # arrangement : montant libre (migration 037)
    cree_le = Column(DateTime, default=datetime.now)

    contrat = relationship(Contrat, backref="paiements")
    echeances = relationship(Echeance, back_populates="paiement", order_by=Echeance.mois_echeance)  # mois soldés
    versements = relationship("VersementEcheance", back_populates="paiement", order_by="VersementEcheance.id",
                              cascade="all, delete-orphan", passive_deletes=True)
    encaissement = relationship("Encaissement", back_populates="paiement", uselist=False)
    caissier = relationship(Utilisateur)

class VersementEcheance(Base):
    """La part d'un paiement sur un mois de loyer, et ce qu'il restait à payer sur ce mois juste après."""
    __tablename__ = "versements_echeances"

    id = Column(Integer, primary_key=True)
    echeance_id = Column(Integer, ForeignKey("echeances.id", ondelete="CASCADE"), nullable=False)
    paiement_id = Column(Integer, ForeignKey("paiements.id", ondelete="CASCADE"), nullable=False)
    montant = Column(Numeric(12, 2), nullable=False)
    reste_apres = Column(Numeric(12, 2), nullable=False, default=0)
    cree_le = Column(DateTime, default=datetime.now)

    echeance = relationship(Echeance, back_populates="versements")
    paiement = relationship(Paiement, back_populates="versements")

class Encaissement(Base):
    """Répartition d'un paiement : commission ISUP et montant reversé au propriétaire."""
    __tablename__ = "encaissements"

    id = Column(Integer, primary_key=True)
    paiement_id = Column(Integer, ForeignKey("paiements.id"), nullable=False)
    date_encaissement = Column(Date, nullable=False)
    montant_encaisse = Column(Numeric(12, 2), nullable=False)
    montant_caution = Column(Numeric(12, 2), nullable=False, default=0)  # sans commission
    pourcentage_commission = Column(Numeric(5, 2))
    commission_entreprise = Column(Numeric(12, 2), default=0)
    montant_reverse = Column(Numeric(12, 2), default=0)
    montant_penalite = Column(Numeric(12, 2), nullable=False, default=0)  # pénalité de retard comprise
    observation = Column(Text)
    cree_le = Column(DateTime, default=datetime.now)

    paiement = relationship(Paiement, back_populates="encaissement")

TYPES_DOCUMENT = ("Contrat de bail", "Reçu de paiement", "Facture", "Quittance", "Décharge")

class Document(Base):
    """PDF généré une fois et conservé (on réimprime toujours le même fichier)."""
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True)
    contrat_id = Column(Integer, ForeignKey("contrats.id"))
    paiement_id = Column(Integer, ForeignKey("paiements.id"))
    achat_vente_id = Column(Integer, ForeignKey("achats_ventes.id"))
    type_document = Column(Enum(*TYPES_DOCUMENT, name="type_document", create_type=False), nullable=False)
    chemin_fichier = Column(String(300))   # relatif au dossier documents/
    nom_fichier = Column(String(200))
    genere_par = Column(Integer, ForeignKey("utilisateurs.id"))
    date_generation = Column(DateTime, default=datetime.now)

# ---------- Dépenses (étape 7) ----------

# Dépenses liées à un bien, puis dépenses de fonctionnement de l'entreprise (précomptabilité, 06/10/2026)
CATEGORIES_BIEN = ("Réparation", "Plomberie", "Électricité", "Peinture", "Entretien",
                   "Eau / électricité (factures)", "Gardiennage", "Taxes et impôts")
CATEGORIES_FONCTIONNEMENT = ("Salaires et primes", "Loyer du bureau", "Fournitures de bureau", "Internet et téléphone",
                             "Carburant et transport", "Publicité", "Frais bancaires", "Honoraires (comptable, avocat…)")
CATEGORIES_DEPENSE = CATEGORIES_BIEN + CATEGORIES_FONCTIONNEMENT + ("Autre",)
CHARGES_DEPENSE = ("Propriétaire", "Entreprise")

class Depense(Base):
    __tablename__ = "depenses"

    id = Column(Integer, primary_key=True)
    cite_id = Column(Integer, ForeignKey("cites.id"))   # vide = dépense de fonctionnement de l'entreprise
    logement_id = Column(Integer, ForeignKey("logements.id"))
    montant = Column(Numeric(12, 2), nullable=False)
    motif = Column(String(200), nullable=False)
    categorie = Column(String(40), nullable=False, default="Autre")
    a_la_charge_de = Column(String(20), nullable=False, default="Propriétaire")
    mode_paiement = Column(Enum(*MODES_PAIEMENT, name="mode_paiement", create_type=False), nullable=False,
                           default="Espèce")
    date_depense = Column(Date, nullable=False)
    compte_id = Column(Integer, ForeignKey("comptes_tresorerie.id"))
    montant_tva = Column(Numeric(12, 2), nullable=False, default=0)   # TVA comprise dans le montant
    justificatif = Column(String(80))                                 # n° de facture ou de reçu
    saisi_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    cite = relationship(Cite)
    logement = relationship(Logement)
    auteur = relationship(Utilisateur)

# ---------- Achats / Ventes de biens (étape 7) ----------

# Vente directe : ISUP représente légalement le propriétaire.
# Vente indirecte : ISUP est intermédiaire (propriétaire vendeur identifié, commission).
TYPES_OPERATION = ("Achat", "Vente directe", "Vente indirecte")
TYPES_OPERATION_BASE = ("Achat", "Vente", "Vente directe", "Vente indirecte")  # « Vente » : ancien libellé
PAYEURS_COMMISSION = ("Acheteur", "Vendeur")

class AchatVente(Base):
    __tablename__ = "achats_ventes"

    id = Column(Integer, primary_key=True)
    numero = Column(String(30), unique=True)
    type_operation = Column(Enum(*TYPES_OPERATION_BASE, name="type_operation_av", create_type=False), nullable=False)
    cite_id = Column(Integer, ForeignKey("cites.id"))
    parcelle_id = Column(Integer, ForeignKey("parcelles.id"))
    designation = Column(Text)
    partie_nom = Column(String(150), nullable=False)
    partie_telephone = Column(String(30))
    partie_cni = Column(String(50))
    # vente indirecte : propriétaire vendeur, commission d'intermédiation et qui la paie
    proprietaire_nom = Column(String(150))
    proprietaire_telephone = Column(String(30))
    proprietaire_cni = Column(String(50))
    commission_montant = Column(Numeric(14, 2), nullable=False, default=0)
    commission_payee_par = Column(String(10))
    montant = Column(Numeric(14, 2), nullable=False)
    mode_paiement = Column(Enum(*MODES_PAIEMENT, name="mode_paiement", create_type=False), nullable=False)
    date_operation = Column(Date, nullable=False)
    type_document = Column(Enum(*TYPES_DOCUMENT, name="type_document", create_type=False))  # ancien champ
    observation = Column(Text)
    compte_id = Column(Integer, ForeignKey("comptes_tresorerie.id"))
    saisi_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    cite = relationship(Cite)
    parcelle = relationship(Parcelle)
    auteur = relationship(Utilisateur)

# ---------- Reversements et carnet de RIB (précomptabilité, migration 022) ----------

CATEGORIES_BENEFICIAIRE = ("Propriétaire", "Employé", "Fournisseur", "Autre")
TYPES_REVERSEMENT = ("Loyers", "Vente", "Caution")

class Beneficiaire(Base):
    """Carnet de RIB : personne que l'entreprise paie (propriétaire, employé, fournisseur…)."""
    __tablename__ = "beneficiaires"

    id = Column(Integer, primary_key=True)
    nom = Column(String(150), nullable=False)
    categorie = Column(String(20), nullable=False, default="Propriétaire")
    proprietaire_id = Column(Integer, ForeignKey("proprietaires.id", ondelete="SET NULL"))
    banque_nom = Column(String(120))
    titulaire = Column(String(150))
    banque_code = Column(String(5))
    banque_guichet = Column(String(5))
    banque_compte = Column(String(12))
    banque_cle_rib = Column(String(2))
    iban = Column(String(34))
    bic = Column(String(11))
    mobile_money = Column(String(30))
    observation = Column(Text)
    actif = Column(Boolean, nullable=False, default=True)
    cree_le = Column(DateTime, default=datetime.now)

    proprietaire = relationship(Proprietaire)

class Reversement(Base):
    """Argent versé à un propriétaire (loyers nets) ou au vendeur d'une vente faite en intermédiaire."""
    __tablename__ = "reversements"

    id = Column(Integer, primary_key=True)
    numero = Column(String(30), unique=True, nullable=False)
    type_reversement = Column(String(10), nullable=False)
    proprietaire_id = Column(Integer, ForeignKey("proprietaires.id"))
    achat_vente_id = Column(Integer, ForeignKey("achats_ventes.id"))
    beneficiaire_nom = Column(String(150), nullable=False)
    beneficiaire_id = Column(Integer, ForeignKey("beneficiaires.id", ondelete="SET NULL"))
    date_reversement = Column(Date, nullable=False)
    montant = Column(Numeric(14, 2), nullable=False)
    reste_apres = Column(Numeric(14, 2), nullable=False, default=0)
    compte_id = Column(Integer, ForeignKey("comptes_tresorerie.id"), nullable=False)
    mode_paiement = Column(Enum(*MODES_PAIEMENT, name="mode_paiement", create_type=False), nullable=False)
    reference = Column(String(80))
    observation = Column(Text)
    # restitution de caution : contrat, et retenue gardée pour réparations (revient au propriétaire)
    contrat_id = Column(Integer, ForeignKey("contrats.id"))
    retenue = Column(Numeric(14, 2), nullable=False, default=0)
    motif_retenue = Column(Text)
    saisi_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    proprietaire = relationship(Proprietaire)
    operation = relationship(AchatVente)
    contrat = relationship(Contrat)
    beneficiaire = relationship(Beneficiaire)
    compte = relationship(CompteTresorerie)
    auteur = relationship(Utilisateur)

TYPES_MESSAGE = ("bienvenue", "rappel", "confirmation", "retard", "expulsion")

class MessageWhatsApp(Base):
    """Message WhatsApp préparé (historique des relances)."""
    __tablename__ = "messages_whatsapp"

    id = Column(Integer, primary_key=True)
    type_message = Column(String(20), nullable=False)
    contrat_id = Column(Integer, ForeignKey("contrats.id"), nullable=False)
    paiement_id = Column(Integer, ForeignKey("paiements.id"))
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id"))
    telephone = Column(String(30), nullable=False)
    message = Column(Text, nullable=False)
    cree_le = Column(DateTime, default=datetime.now)

class Impaye(Base):
    __tablename__ = "impayes"

    id = Column(Integer, primary_key=True)
    contrat_id = Column(Integer, ForeignKey("contrats.id"))
    echeance_id = Column(Integer, ForeignKey("echeances.id"), unique=True)
    locataire_id = Column(Integer, ForeignKey("locataires.id"), nullable=False)
    logement_id = Column(Integer, ForeignKey("logements.id"), nullable=False)
    cite_id = Column(Integer, ForeignKey("cites.id"), nullable=False)
    mois = Column(Date, nullable=False)
    montant_du = Column(Numeric(12, 2), nullable=False)
    statut_impayes = Column(Enum(*STATUTS_IMPAYES, name="statut_impayes", create_type=False),
                            nullable=False, default="En retard")
    cree_le = Column(DateTime, default=datetime.now)

class DemandeReinitialisation(Base):
    __tablename__ = "demandes_reinitialisation"

    id = Column(Integer, primary_key=True)
    identifiant = Column(String(80), nullable=False)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id"))
    traitee = Column(Boolean, default=False)
    cree_le = Column(DateTime, default=datetime.now)

# ---------- Pièces jointes, états des lieux, agenda, courriers… (demandes du 03/10/2026) ----------

TYPES_PIECE = ("CNI", "Passeport", "Attestation d'identité", "Permis de conduire", "Carte consulaire",
               "Titre de propriété / ACD", "Bulletin de salaire", "Autre")

class PieceJointe(Base):
    __tablename__ = "pieces_jointes"

    id = Column(Integer, primary_key=True)
    proprietaire_id = Column(Integer, ForeignKey("proprietaires.id", ondelete="CASCADE"))
    locataire_id = Column(Integer, ForeignKey("locataires.id", ondelete="CASCADE"))
    type_piece = Column(String(40), nullable=False, default="CNI")
    chemin_fichier = Column(String(300), nullable=False)
    nom_fichier = Column(String(200), nullable=False)
    type_mime = Column(String(60), nullable=False)
    taille = Column(Integer)
    ajoute_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

TYPES_EDL = ("Entrée", "Sortie")

class EtatDesLieux(Base):
    __tablename__ = "etats_des_lieux"

    id = Column(Integer, primary_key=True)
    numero = Column(String(30), unique=True, nullable=False)
    contrat_id = Column(Integer, ForeignKey("contrats.id"), nullable=False)
    type_edl = Column(String(10), nullable=False)
    date_edl = Column(Date, nullable=False)
    pieces = Column(JSONB, nullable=False, default=list)
    compteurs = Column(JSONB, nullable=False, default=dict)
    nb_cles = Column(Integer, nullable=False, default=0)
    observations = Column(Text)
    retenues = Column(Numeric(12, 2), nullable=False, default=0)
    statut = Column(String(10), nullable=False, default="Brouillon")
    signature_locataire = Column(Text)
    signature_agent = Column(Text)
    signe_le = Column(DateTime)
    chemin_pdf = Column(String(300))
    envoye_le = Column(DateTime)
    cree_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)
    modifie_le = Column(DateTime)

    contrat = relationship(Contrat)
    auteur = relationship(Utilisateur)
    photos = relationship("PhotoEdl", back_populates="etat_des_lieux", order_by="PhotoEdl.id",
                          cascade="all, delete-orphan")

class PhotoEdl(Base):
    __tablename__ = "edl_photos"

    id = Column(Integer, primary_key=True)
    etat_des_lieux_id = Column(Integer, ForeignKey("etats_des_lieux.id", ondelete="CASCADE"), nullable=False)
    piece = Column(String(80))
    legende = Column(String(200))
    chemin_fichier = Column(String(300), nullable=False)
    cree_le = Column(DateTime, default=datetime.now)

    etat_des_lieux = relationship(EtatDesLieux, back_populates="photos")

BESOINS_PROSPECT = ("Location", "Achat", "Vente", "Confier un bien en gestion", "Autre")
SOURCES_PROSPECT = ("Passage au bureau", "Appel", "WhatsApp", "Facebook", "Bouche à oreille", "Panneau / affiche", "Autre")
STATUTS_PROSPECT = ("Nouveau", "En cours", "Visite prévue", "Converti", "Perdu")

class Prospect(Base):
    __tablename__ = "prospects"

    id = Column(Integer, primary_key=True)
    nom_complet = Column(String(150), nullable=False)
    telephone = Column(String(30))
    email = Column(String(150))
    besoin = Column(String(30), nullable=False, default="Location")
    type_logement = Column(String(40))
    quartier = Column(String(150))
    budget_max = Column(Numeric(14, 2))
    details = Column(Text)
    source = Column(String(40))
    statut = Column(String(20), nullable=False, default="Nouveau")
    prochaine_action = Column(Date)
    cree_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)
    modifie_le = Column(DateTime)

    suivi = relationship("SuiviProspect", order_by="SuiviProspect.cree_le.desc()", cascade="all, delete-orphan")
    auteur = relationship(Utilisateur)

class SuiviProspect(Base):
    __tablename__ = "prospects_suivi"

    id = Column(Integer, primary_key=True)
    prospect_id = Column(Integer, ForeignKey("prospects.id", ondelete="CASCADE"), nullable=False)
    note = Column(Text, nullable=False)
    cree_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    auteur = relationship(Utilisateur)

TYPES_EVENEMENT = ("Rendez-vous", "Appel", "Visite", "Courrier", "Tâche", "Relance")

class Evenement(Base):
    __tablename__ = "agenda"

    id = Column(Integer, primary_key=True)
    titre = Column(String(200), nullable=False)
    type_evenement = Column(String(20), nullable=False, default="Rendez-vous")
    date_evenement = Column(Date, nullable=False)
    heure = Column(Time)
    lieu = Column(String(200))
    telephone = Column(String(30))
    notes = Column(Text)
    rappel_minutes = Column(Integer, nullable=False, default=30)
    fait = Column(Boolean, nullable=False, default=False)
    fait_le = Column(DateTime)
    prospect_id = Column(Integer, ForeignKey("prospects.id", ondelete="SET NULL"))
    contrat_id = Column(Integer, ForeignKey("contrats.id", ondelete="SET NULL"))
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    prospect = relationship(Prospect)
    contrat = relationship(Contrat)
    destinataire = relationship(Utilisateur, foreign_keys=[utilisateur_id])

TYPES_COURRIER = ("Révision de loyer", "Avenant au bail")

class Courrier(Base):
    __tablename__ = "courriers"

    id = Column(Integer, primary_key=True)
    numero = Column(String(30), unique=True, nullable=False)
    type_courrier = Column(String(30), nullable=False)
    contrat_id = Column(Integer, ForeignKey("contrats.id"), nullable=False)
    date_courrier = Column(Date, nullable=False)
    date_effet = Column(Date)
    ancien_loyer = Column(Numeric(12, 2))
    nouveau_loyer = Column(Numeric(12, 2))
    ancienne_date_fin = Column(Date)
    nouvelle_date_fin = Column(Date)
    objet = Column(String(200))
    contenu = Column(Text)
    chemin_pdf = Column(String(300))
    envois = Column(JSONB, nullable=False, default=list)
    cree_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    contrat = relationship(Contrat, backref="courriers")
    auteur = relationship(Utilisateur)

CATEGORIES_PROBLEME = ("Plomberie / fuite d'eau", "Électricité", "Toiture / étanchéité", "Serrurerie / porte",
                       "Peinture / murs", "Sanitaires", "Fosse septique", "Sécurité / gardiennage",
                       "Voisinage / nuisances", "Autre")
URGENCES = ("Faible", "Normale", "Urgente")
STATUTS_SIGNALEMENT = ("Ouvert", "En cours", "Résolu")

class Signalement(Base):
    __tablename__ = "signalements"

    id = Column(Integer, primary_key=True)
    cite_id = Column(Integer, ForeignKey("cites.id", ondelete="CASCADE"), nullable=False)
    logement_id = Column(Integer, ForeignKey("logements.id", ondelete="SET NULL"))
    categorie = Column(String(40), nullable=False)
    urgence = Column(String(10), nullable=False, default="Normale")
    description = Column(Text, nullable=False)
    signale_par = Column(String(150))
    statut = Column(String(10), nullable=False, default="Ouvert")
    resolution = Column(Text)
    resolu_le = Column(DateTime)
    photo_chemin = Column(String(300))
    cree_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    cite = relationship(Cite)
    logement = relationship(Logement)
    auteur = relationship(Utilisateur)

class Parametre(Base):
    __tablename__ = "parametres"

    cle = Column(String(60), primary_key=True)
    valeur = Column(Text)
    modifie_le = Column(DateTime, default=datetime.now)

class Publication(Base):
    __tablename__ = "publications"

    id = Column(Integer, primary_key=True)
    titre = Column(String(200), nullable=False)
    texte = Column(Text, nullable=False)
    canal = Column(String(30), nullable=False)
    cree_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    auteur = relationship(Utilisateur)


# ---------- Location courte durée / meublée (séjours, migration 026) ----------

STATUTS_RESERVATION = ("Confirmée", "Arrivé", "Parti", "Annulée")


class Reservation(Base):
    """Séjour à la nuit dans un logement meublé : client, dates, prix (acompte et solde à part)."""
    __tablename__ = "reservations"

    id = Column(Integer, primary_key=True)
    numero = Column(String(30), unique=True, nullable=False)
    logement_id = Column(Integer, ForeignKey("logements.id"), nullable=False)
    client_nom = Column(String(150), nullable=False)
    client_telephone = Column(String(30))
    client_piece = Column(String(80))
    nb_personnes = Column(Integer, nullable=False, default=1)
    date_arrivee = Column(Date, nullable=False)
    date_depart = Column(Date, nullable=False)
    prix_nuit = Column(Numeric(12, 2), nullable=False)
    remise = Column(Numeric(12, 2), nullable=False, default=0)
    montant_total = Column(Numeric(12, 2), nullable=False)
    statut = Column(String(12), nullable=False, default="Confirmée")
    notes = Column(Text)
    motif_annulation = Column(Text)
    cree_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    logement = relationship(Logement)
    auteur = relationship(Utilisateur)
    paiements = relationship("PaiementSejour", back_populates="reservation", order_by="PaiementSejour.id")

    @property
    def nb_nuits(self) -> int:
        return (self.date_depart - self.date_arrivee).days


class PaiementSejour(Base):
    """Versement d'un client de courte durée (acompte ou solde), avec la commission de gestion du bien."""
    __tablename__ = "sejours_paiements"

    id = Column(Integer, primary_key=True)
    reservation_id = Column(Integer, ForeignKey("reservations.id"), nullable=False)
    numero_recu = Column(String(30), unique=True, nullable=False)
    date_paiement = Column(Date, nullable=False)
    montant = Column(Numeric(12, 2), nullable=False)
    mode_paiement = Column(Enum(*MODES_PAIEMENT, name="mode_paiement", create_type=False), nullable=False)
    compte_id = Column(Integer, ForeignKey("comptes_tresorerie.id"))
    pourcentage_commission = Column(Numeric(5, 2), nullable=False, default=0)
    commission = Column(Numeric(12, 2), nullable=False, default=0)
    montant_reverse = Column(Numeric(12, 2), nullable=False, default=0)
    statut = Column(String(10), nullable=False, default="Payé")
    motif_annulation = Column(Text)
    date_annulation = Column(DateTime)
    encaisse_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    reservation = relationship(Reservation, back_populates="paiements")
    caissier = relationship(Utilisateur)


# ---------- Métier Commerce / boutique (migration 041, 13/11/2026) ----------

class Fournisseur(Base):
    __tablename__ = "fournisseurs"

    id = Column(Integer, primary_key=True)
    nom = Column(String(150), nullable=False)
    telephone = Column(String(30))
    contact = Column(String(150))
    adresse = Column(String(200))
    note = Column(Text)
    actif = Column(Boolean, nullable=False, default=True)
    cree_le = Column(DateTime, default=datetime.now)


class Article(Base):
    __tablename__ = "articles"

    id = Column(Integer, primary_key=True)
    nom = Column(String(150), nullable=False)
    categorie = Column(String(80))
    code_barres = Column(String(40))
    unite_base = Column(String(30), nullable=False, default="Pièce")   # unité du stock
    prix_detail = Column(Numeric(12, 2), nullable=False, default=0)
    prix_gros = Column(Numeric(12, 2), nullable=False, default=0)
    prix_achat = Column(Numeric(12, 2), nullable=False, default=0)    # par unité de base ; caché au Gestionnaire
    seuil_alerte = Column(Numeric(12, 3), nullable=False, default=0)
    suit_peremption = Column(Boolean, nullable=False, default=False)
    fournisseur_id = Column(Integer, ForeignKey("fournisseurs.id", ondelete="SET NULL"))
    actif = Column(Boolean, nullable=False, default=True)
    cree_le = Column(DateTime, default=datetime.now)

    fournisseur = relationship(Fournisseur)
    unites = relationship("UniteArticle", back_populates="article", cascade="all, delete-orphan",
                          order_by="UniteArticle.contenance")


class UniteArticle(Base):
    """Autre unité de vente d'un article (Carton = 24 Bouteilles), avec ses propres prix."""
    __tablename__ = "unites_articles"

    id = Column(Integer, primary_key=True)
    article_id = Column(Integer, ForeignKey("articles.id", ondelete="CASCADE"), nullable=False)
    nom = Column(String(30), nullable=False)
    contenance = Column(Numeric(12, 3), nullable=False)
    prix_detail = Column(Numeric(12, 2), nullable=False, default=0)
    prix_gros = Column(Numeric(12, 2), nullable=False, default=0)
    code_barres = Column(String(40))

    article = relationship(Article, back_populates="unites")


# ---------- Commerce : arrivages, stock, paiements aux fournisseurs (migration 042) ----------

class Arrivage(Base):
    __tablename__ = "arrivages"

    id = Column(Integer, primary_key=True)
    numero = Column(String(20), unique=True, nullable=False)
    fournisseur_id = Column(Integer, ForeignKey("fournisseurs.id"))
    date_arrivage = Column(Date, nullable=False)
    reference_facture = Column(String(60))
    note = Column(Text)
    prix_complets = Column(Boolean, nullable=False, default=False)
    montant_total = Column(Numeric(14, 2), nullable=False, default=0)
    annule = Column(Boolean, nullable=False, default=False)
    motif_annulation = Column(Text)
    saisi_par = Column(Integer, ForeignKey("utilisateurs.id"))
    prix_par = Column(Integer, ForeignKey("utilisateurs.id"))
    prix_le = Column(DateTime)
    cree_le = Column(DateTime, default=datetime.now)

    fournisseur = relationship(Fournisseur)
    auteur = relationship(Utilisateur, foreign_keys=[saisi_par])
    lignes = relationship("LigneArrivage", back_populates="arrivage", cascade="all, delete-orphan",
                          order_by="LigneArrivage.id")
    versements = relationship("VersementFournisseur", back_populates="arrivage", order_by="VersementFournisseur.id")


class LigneArrivage(Base):
    __tablename__ = "lignes_arrivage"

    id = Column(Integer, primary_key=True)
    arrivage_id = Column(Integer, ForeignKey("arrivages.id", ondelete="CASCADE"), nullable=False)
    article_id = Column(Integer, ForeignKey("articles.id"), nullable=False)
    unite_id = Column(Integer, ForeignKey("unites_articles.id", ondelete="SET NULL"))
    unite_nom = Column(String(30), nullable=False)
    quantite = Column(Numeric(12, 3), nullable=False)
    contenance = Column(Numeric(12, 3), nullable=False, default=1)
    quantite_base = Column(Numeric(14, 3), nullable=False)
    prix_unitaire = Column(Numeric(12, 2))     # prix d'un lot ; vide = à compléter par la Caisse
    date_limite = Column(Date)
    reste_base = Column(Numeric(14, 3), nullable=False, default=0)

    arrivage = relationship(Arrivage, back_populates="lignes")
    article = relationship(Article)


class MouvementStock(Base):
    __tablename__ = "mouvements_stock"

    id = Column(Integer, primary_key=True)
    article_id = Column(Integer, ForeignKey("articles.id"), nullable=False)
    date_mouvement = Column(Date, nullable=False)
    quantite_base = Column(Numeric(14, 3), nullable=False)
    genre = Column(String(20), nullable=False)
    ligne_arrivage_id = Column(Integer, ForeignKey("lignes_arrivage.id", ondelete="CASCADE"))
    motif = Column(String(200))
    raison = Column(String(30))          # sortie : Casse, Périmé, Vol ou perte… (migration 043)
    valeur = Column(Numeric(14, 2))      # sortie : ce que la marchandise avait coûté
    saisi_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    article = relationship(Article)
    auteur = relationship(Utilisateur)


class VersementFournisseur(Base):
    __tablename__ = "versements_fournisseurs"

    id = Column(Integer, primary_key=True)
    arrivage_id = Column(Integer, ForeignKey("arrivages.id"), nullable=False)
    date_versement = Column(Date, nullable=False)
    montant = Column(Numeric(14, 2), nullable=False)
    mode_paiement = Column(Enum(*MODES_PAIEMENT, name="mode_paiement", create_type=False), nullable=False,
                           default="Espèce")
    compte_id = Column(Integer, ForeignKey("comptes_tresorerie.id"))
    note = Column(String(200))
    saisi_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    arrivage = relationship(Arrivage, back_populates="versements")
    auteur = relationship(Utilisateur)


# ---------- Commerce : inventaires (migration 043) ----------

class Inventaire(Base):
    __tablename__ = "inventaires"

    id = Column(Integer, primary_key=True)
    numero = Column(String(20), unique=True, nullable=False)
    date_inventaire = Column(Date, nullable=False)
    statut = Column(String(12), nullable=False, default="À valider")
    note = Column(Text)
    saisi_par = Column(Integer, ForeignKey("utilisateurs.id"))
    valide_par = Column(Integer, ForeignKey("utilisateurs.id"))
    valide_le = Column(DateTime)
    cree_le = Column(DateTime, default=datetime.now)

    auteur = relationship(Utilisateur, foreign_keys=[saisi_par])
    valideur = relationship(Utilisateur, foreign_keys=[valide_par])
    lignes = relationship("LigneInventaire", back_populates="inventaire", cascade="all, delete-orphan",
                          order_by="LigneInventaire.id")


class LigneInventaire(Base):
    __tablename__ = "lignes_inventaire"

    id = Column(Integer, primary_key=True)
    inventaire_id = Column(Integer, ForeignKey("inventaires.id", ondelete="CASCADE"), nullable=False)
    article_id = Column(Integer, ForeignKey("articles.id"), nullable=False)
    stock_prevu = Column(Numeric(14, 3), nullable=False)
    stock_compte = Column(Numeric(14, 3), nullable=False)

    inventaire = relationship(Inventaire, back_populates="lignes")
    article = relationship(Article)


# ---------- Commerce : ventes au comptoir et clients (migration 044) ----------

class ClientCommerce(Base):
    __tablename__ = "clients_commerce"

    id = Column(Integer, primary_key=True)
    nom = Column(String(150), nullable=False)
    telephone = Column(String(30))
    adresse = Column(String(200))
    note = Column(Text)
    plafond_credit = Column(Numeric(14, 2))
    actif = Column(Boolean, nullable=False, default=True)
    cree_le = Column(DateTime, default=datetime.now)


class Vente(Base):
    __tablename__ = "ventes"

    id = Column(Integer, primary_key=True)
    numero = Column(String(20), unique=True, nullable=False)
    date_vente = Column(Date, nullable=False)
    client_id = Column(Integer, ForeignKey("clients_commerce.id"))
    prix_applique = Column(String(6), nullable=False, default="Détail")
    sous_total = Column(Numeric(14, 2), nullable=False)
    remise = Column(Numeric(14, 2), nullable=False, default=0)
    total = Column(Numeric(14, 2), nullable=False)
    remise_confirmee_par = Column(Integer, ForeignKey("utilisateurs.id"))
    stock_force_par = Column(Integer, ForeignKey("utilisateurs.id"))
    statut = Column(String(10), nullable=False, default="Validée")
    motif_annulation = Column(Text)
    annule_par = Column(Integer, ForeignKey("utilisateurs.id"))
    annule_le = Column(Date)
    rembourse = Column(Numeric(14, 2), nullable=False, default=0)
    rembourse_compte_id = Column(Integer, ForeignKey("comptes_tresorerie.id"))
    rembourse_mode = Column(Enum(*MODES_PAIEMENT, name="mode_paiement", create_type=False))
    note = Column(String(200))
    vendu_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    client = relationship(ClientCommerce)
    vendeur = relationship(Utilisateur, foreign_keys=[vendu_par])
    lignes = relationship("LigneVente", back_populates="vente", cascade="all, delete-orphan", order_by="LigneVente.id")
    reglements = relationship("ReglementVente", back_populates="vente", order_by="ReglementVente.id")


class LigneVente(Base):
    __tablename__ = "lignes_vente"

    id = Column(Integer, primary_key=True)
    vente_id = Column(Integer, ForeignKey("ventes.id", ondelete="CASCADE"), nullable=False)
    article_id = Column(Integer, ForeignKey("articles.id"), nullable=False)
    unite_id = Column(Integer, ForeignKey("unites_articles.id", ondelete="SET NULL"))
    unite_nom = Column(String(30), nullable=False)
    article_nom = Column(String(150), nullable=False)
    quantite = Column(Numeric(12, 3), nullable=False)
    contenance = Column(Numeric(12, 3), nullable=False, default=1)
    quantite_base = Column(Numeric(14, 3), nullable=False)
    prix_unitaire = Column(Numeric(12, 2), nullable=False)
    total = Column(Numeric(14, 2), nullable=False)
    cout = Column(Numeric(14, 2), nullable=False, default=0)

    vente = relationship(Vente, back_populates="lignes")
    article = relationship(Article)


class ReglementVente(Base):
    __tablename__ = "reglements_ventes"

    id = Column(Integer, primary_key=True)
    numero = Column(String(20), unique=True, nullable=False)
    vente_id = Column(Integer, ForeignKey("ventes.id"), nullable=False)
    date_reglement = Column(Date, nullable=False)
    montant = Column(Numeric(14, 2), nullable=False)
    mode_paiement = Column(Enum(*MODES_PAIEMENT, name="mode_paiement", create_type=False), nullable=False, default="Espèce")
    compte_id = Column(Integer, ForeignKey("comptes_tresorerie.id"))
    a_la_vente = Column(Boolean, nullable=False, default=False)
    saisi_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    vente = relationship(Vente, back_populates="reglements")
    auteur = relationship(Utilisateur)


# ---------- Métier Agence Mobile Money (migration 045) ----------

mm_agents_points = Table(
    "mm_agents_points", Base.metadata,
    Column("utilisateur_id", Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), primary_key=True),
    Column("point_id", Integer, ForeignKey("mm_points.id", ondelete="CASCADE"), primary_key=True),
)


class MMOperateur(Base):
    __tablename__ = "mm_operateurs"

    id = Column(Integer, primary_key=True)
    nom = Column(String(60), unique=True, nullable=False)
    couleur = Column(String(9), nullable=False, default="#1d3b53")
    actif = Column(Boolean, nullable=False, default=True)
    ordre = Column(Integer, nullable=False, default=0)


class MMPoint(Base):
    __tablename__ = "mm_points"

    id = Column(Integer, primary_key=True)
    nom = Column(String(100), unique=True, nullable=False)
    adresse = Column(String(200))
    especes_depart = Column(Numeric(14, 2), nullable=False, default=0)
    date_depart = Column(Date, nullable=False)
    seuil_especes = Column(Numeric(14, 2), nullable=False, default=0)
    actif = Column(Boolean, nullable=False, default=True)
    cree_le = Column(DateTime, default=datetime.now)

    agents = relationship(Utilisateur, secondary=mm_agents_points, backref="points_mm")
    puces = relationship("MMPuce", back_populates="point", order_by="MMPuce.operateur_id")


class MMPuce(Base):
    __tablename__ = "mm_puces"

    id = Column(Integer, primary_key=True)
    point_id = Column(Integer, ForeignKey("mm_points.id", ondelete="CASCADE"), nullable=False)
    operateur_id = Column(Integer, ForeignKey("mm_operateurs.id"), nullable=False)
    numero = Column(String(30))
    solde_depart = Column(Numeric(14, 2), nullable=False, default=0)
    seuil_alerte = Column(Numeric(14, 2), nullable=False, default=0)
    actif = Column(Boolean, nullable=False, default=True)

    point = relationship(MMPoint, back_populates="puces")
    operateur = relationship(MMOperateur)


class MMBareme(Base):
    __tablename__ = "mm_baremes"

    id = Column(Integer, primary_key=True)
    operateur_id = Column(Integer, ForeignKey("mm_operateurs.id", ondelete="CASCADE"), nullable=False)
    type_operation = Column(String(10), nullable=False)
    montant_min = Column(Numeric(14, 2), nullable=False, default=0)
    montant_max = Column(Numeric(14, 2))
    commission_fixe = Column(Numeric(12, 2), nullable=False, default=0)
    commission_pct = Column(Numeric(6, 3), nullable=False, default=0)


class MMOperation(Base):
    __tablename__ = "mm_operations"

    id = Column(Integer, primary_key=True)
    numero = Column(String(20), unique=True, nullable=False)
    point_id = Column(Integer, ForeignKey("mm_points.id"), nullable=False)
    puce_id = Column(Integer, ForeignKey("mm_puces.id"))
    type_operation = Column(String(30), nullable=False)
    montant = Column(Numeric(14, 2), nullable=False)
    paye_en_especes = Column(Boolean, nullable=False, default=True)
    compte_id = Column(Integer, ForeignKey("comptes_tresorerie.id"))   # compte de l'entreprise concerné (migration 046)
    numero_client = Column(String(30))
    reference = Column(String(60))
    commission = Column(Numeric(12, 2), nullable=False, default=0)
    date_operation = Column(Date, nullable=False)
    note = Column(String(200))
    annulee = Column(Boolean, nullable=False, default=False)
    motif_annulation = Column(String(300))
    annule_par = Column(Integer, ForeignKey("utilisateurs.id"))
    saisi_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    point = relationship(MMPoint)
    puce = relationship(MMPuce)
    auteur = relationship(Utilisateur, foreign_keys=[saisi_par])


class MMCloture(Base):
    __tablename__ = "mm_clotures"

    id = Column(Integer, primary_key=True)
    point_id = Column(Integer, ForeignKey("mm_points.id"), nullable=False)
    date_cloture = Column(Date, nullable=False)
    especes_calculees = Column(Numeric(14, 2), nullable=False)
    especes_comptees = Column(Numeric(14, 2), nullable=False)
    puces = Column(JSONB, nullable=False, default=list)
    note = Column(String(300))
    saisi_par = Column(Integer, ForeignKey("utilisateurs.id"))
    cree_le = Column(DateTime, default=datetime.now)

    point = relationship(MMPoint)
    auteur = relationship(Utilisateur)
