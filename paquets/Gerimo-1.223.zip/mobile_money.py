"""Métier « Agence Mobile Money » (14/11/2026) : opérations, soldes des puces et des espèces, clôture du soir,
commissions, réglages.

Décisions de Boss (13/11/2026) : voir migrations/045_mobile_money.sql. Règles appliquées ici :
- Chaque opération a un effet sur la puce de l'opérateur et/ou sur les espèces du kiosque :
    Dépôt (le client donne des espèces, l'agent envoie la e-monnaie) : espèces +, puce − ;
    Retrait (l'agent donne des espèces) : espèces −, puce + ;
    Rechargement de la puce (achat de e-monnaie) : puce + ; espèces − s'il est payé avec les espèces du kiosque ;
    Retour de e-monnaie (revente au distributeur) : puce − ; espèces + s'il est payé en espèces ;
    Apport d'espèces / Sortie d'espèces (le patron apporte ou retire de l'argent liquide) : espèces + / −.
- On ne peut pas envoyer plus de e-monnaie que la puce n'en a, ni donner plus d'espèces que le kiosque n'en a.
- Commission attendue : barème par tranches de l'opérateur (Admin), sur les dépôts et retraits.
- Agents (Caisse ou Gestionnaire) : seulement les kiosques auxquels l'Admin les a rattachés. Comptable : consultation.
  Annulation : Admin ou Caisse, avec son mot de passe et un motif (l'opération reste visible, barrée).
- Clôture du soir : l'agent compte les espèces et lit le solde de chaque puce ; Gérimo note les écarts.
"""
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import Field
from sqlalchemy import func
from sqlalchemy.orm import Session as SessionDB, selectinload

from commun import Formulaire, Suppression, Telephone, Texte, charger, enregistrer, montant, numero_suivant
from models import MMBareme, MMCloture, MMOperateur, MMOperation, MMPoint, MMPuce, Utilisateur
from securite import exiger_admin, exiger_module, get_db, verifier_mot_de_passe

router = APIRouter(prefix="/api/mm")
acces = exiger_module("mobile_money")
ZERO = Decimal(0)
TYPES = ("Dépôt", "Retrait", "Rechargement de la puce", "Retour de e-monnaie", "Apport d'espèces", "Sortie d'espèces",
         "Commission reçue")
AVEC_PUCE = ("Dépôt", "Retrait", "Rechargement de la puce", "Retour de e-monnaie", "Commission reçue")
# Lien avec la Trésorerie de l'entreprise (migration 046) : le compte d'où vient ou vers lequel part l'argent
AVEC_COMPTE = ("Apport d'espèces", "Sortie d'espèces", "Rechargement de la puce", "Retour de e-monnaie", "Commission reçue")


def _f(v) -> str:
    return f"{Decimal(v):,.0f}".replace(",", " ") + " F"


# ---------- Droits : quels kiosques ----------

def points_visibles(db: SessionDB, u: Utilisateur) -> list[MMPoint]:
    q = db.query(MMPoint).options(selectinload(MMPoint.puces).selectinload(MMPuce.operateur), selectinload(MMPoint.agents))
    if u.role.value not in ("Admin", "Comptable"):
        q = q.filter(MMPoint.agents.any(Utilisateur.id == u.id))
    return q.order_by(MMPoint.nom).all()


def _point_autorise(db: SessionDB, u: Utilisateur, point_id: int) -> MMPoint:
    p = next((x for x in points_visibles(db, u) if x.id == point_id), None)
    if p is None:
        raise HTTPException(status_code=404, detail="Kiosque introuvable (ou vous n'y êtes pas rattaché).")
    return p


def _peut_saisir(u: Utilisateur) -> None:
    if u.role.value == "Comptable":
        raise HTTPException(status_code=403, detail="Le Comptable consulte seulement.")


# ---------- Soldes ----------

def effets(o: MMOperation) -> tuple[Decimal, Decimal]:
    """(effet sur la puce, effet sur les espèces) d'une opération."""
    m, t = o.montant, o.type_operation
    if t == "Dépôt":
        return -m, m
    if t == "Retrait":
        return m, -m
    if t == "Rechargement de la puce":
        return m, (-m if o.paye_en_especes else ZERO)
    if t == "Retour de e-monnaie":
        return -m, (m if o.paye_en_especes else ZERO)
    if t == "Apport d'espèces":
        return ZERO, m
    if t == "Commission reçue":   # versée sur la puce ; sur un compte de l'entreprise, elle ne touche pas le kiosque
        return (ZERO if o.compte_id else m), ZERO
    return ZERO, -m


def soldes(db: SessionDB, point: MMPoint, au: date | None = None) -> tuple[dict[int, Decimal], Decimal]:
    """({puce_id: solde}, espèces) du kiosque à la fin de la journée « au » (aujourd'hui par défaut)."""
    puces = {p.id: p.solde_depart for p in point.puces}
    especes = point.especes_depart
    q = db.query(MMOperation).filter(MMOperation.point_id == point.id, MMOperation.annulee.is_(False))
    if au is not None:
        q = q.filter(MMOperation.date_operation <= au)
    for o in q:
        dp, de = effets(o)
        if o.puce_id in puces:
            puces[o.puce_id] += dp
        especes += de
    return puces, especes


def commission(db: SessionDB, operateur_id: int, type_operation: str, montant_: Decimal) -> Decimal:
    if type_operation not in ("Dépôt", "Retrait"):
        return ZERO
    for b in db.query(MMBareme).filter(MMBareme.operateur_id == operateur_id, MMBareme.type_operation == type_operation) \
            .order_by(MMBareme.montant_min):
        if b.montant_min <= montant_ and (b.montant_max is None or montant_ <= b.montant_max):
            return (b.commission_fixe + montant_ * b.commission_pct / 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return ZERO


def point_json(db: SessionDB, p: MMPoint) -> dict:
    s_puces, especes = soldes(db, p)
    aujourdhui = date.today()
    ops = db.query(MMOperation).filter(MMOperation.point_id == p.id, MMOperation.date_operation == aujourdhui,
                                       MMOperation.annulee.is_(False)).all()
    cloture = db.query(MMCloture).filter(MMCloture.point_id == p.id, MMCloture.date_cloture == aujourdhui).first()
    puces = []
    for x in sorted(p.puces, key=lambda y: y.operateur.ordre):
        if not x.actif:
            continue
        solde = s_puces.get(x.id, ZERO)
        puces.append({"id": x.id, "operateur_id": x.operateur_id, "operateur": x.operateur.nom, "couleur": x.operateur.couleur,
                      "numero": x.numero or "", "solde": montant(solde), "seuil": montant(x.seuil_alerte),
                      "bas": bool(x.seuil_alerte and solde <= x.seuil_alerte)})
    return {"id": p.id, "nom": p.nom, "adresse": p.adresse or "", "actif": p.actif,
            "especes": montant(especes), "seuil_especes": montant(p.seuil_especes),
            "especes_basses": bool(p.seuil_especes and especes <= p.seuil_especes), "puces": puces,
            "agents": [a.nom_complet for a in p.agents],
            "jour": {"nombre": len(ops),
                     "depots": montant(sum((o.montant for o in ops if o.type_operation == "Dépôt"), ZERO)),
                     "retraits": montant(sum((o.montant for o in ops if o.type_operation == "Retrait"), ZERO)),
                     "commissions": montant(sum((o.commission for o in ops), ZERO))},
            "cloture_du_jour": bool(cloture)}


@router.get("/tableau")
def tableau(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    points = points_visibles(db, u)
    comptes = []
    if u.role.value == "Admin":   # pour relier un apport, une sortie, un rechargement… à un compte de l'entreprise
        from models import CompteTresorerie
        comptes = [{"id": c.id, "nom": c.nom, "type": c.type_compte}
                   for c in db.query(CompteTresorerie).filter(CompteTresorerie.actif).order_by(CompteTresorerie.nom)]
    return {"points": [point_json(db, p) for p in points if p.actif], "peut_saisir": u.role.value != "Comptable",
            "comptes": comptes,
            "peut_annuler": u.role.value in ("Admin", "Caisse"), "est_admin": u.role.value == "Admin", "types": TYPES}


# ---------- Opérations ----------

class OperationIn(Formulaire):
    point_id: int
    type_operation: Literal[TYPES]
    puce_id: int | None = None
    montant: Decimal = Field(gt=0, max_digits=14, decimal_places=2)
    paye_en_especes: bool = True
    compte_id: int | None = None   # compte de l'entreprise (Trésorerie) d'où vient ou vers lequel part l'argent
    numero_client: Telephone | None = Field(None, max_length=30)
    reference: Texte | None = Field(None, max_length=60)
    note: Texte | None = Field(None, max_length=200)
    date_operation: date | None = None   # seulement pour une opération faite hors réseau (rejouée par le serveur)


def operation_json(o: MMOperation) -> dict:
    return {"id": o.id, "numero": o.numero, "date": o.date_operation.isoformat(),
            "heure": o.cree_le.strftime("%H:%M") if o.cree_le else "", "point": o.point.nom, "point_id": o.point_id,
            "type": o.type_operation, "operateur": o.puce.operateur.nom if o.puce else "",
            "couleur": o.puce.operateur.couleur if o.puce else "", "montant": montant(o.montant),
            "commission": montant(o.commission), "numero_client": o.numero_client or "", "reference": o.reference or "",
            "note": o.note or "", "paye_en_especes": o.paye_en_especes, "compte_id": o.compte_id, "annulee": o.annulee,
            "motif_annulation": o.motif_annulation or "", "saisi_par": o.auteur.nom_complet if o.auteur else ""}


@router.post("/operations")
def creer_operation(d: OperationIn, request: Request, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    import hors_reseau
    rejeu = hors_reseau.est_rejeu(request)   # opération faite hors réseau : elle a déjà eu lieu
    _peut_saisir(u)
    point = _point_autorise(db, u, d.point_id)
    puce = None
    if d.type_operation in AVEC_PUCE:
        puce = db.get(MMPuce, d.puce_id) if d.puce_id else None
        if puce is None or puce.point_id != point.id or not puce.actif:
            raise HTTPException(status_code=400, detail="Choisissez l'opérateur (la puce du kiosque).")
    compte_id = None
    if d.compte_id is not None and d.type_operation in AVEC_COMPTE:
        if u.role.value != "Admin":
            raise HTTPException(status_code=403, detail="Seul l'Admin relie une opération à un compte de l'entreprise.")
        from models import CompteTresorerie
        compte = charger(db, CompteTresorerie, d.compte_id, "Compte de trésorerie introuvable.")
        if not compte.actif:
            raise HTTPException(status_code=400, detail="Ce compte de trésorerie est fermé.")
        compte_id = compte.id
    if d.type_operation in ("Rechargement de la puce", "Retour de e-monnaie") and compte_id:
        d.paye_en_especes = False   # payé par la banque (ou un autre compte), pas avec les espèces du kiosque
    o = MMOperation(numero=numero_suivant(db, MMOperation.numero, f"MM-{date.today().year}", 6), point_id=point.id,
                    puce_id=puce.id if puce else None, type_operation=d.type_operation, montant=d.montant,
                    paye_en_especes=d.paye_en_especes, compte_id=compte_id, numero_client=d.numero_client or None,
                    reference=d.reference or None, saisi_par=u.id,
                    note=((d.note or "") + (" — saisie hors réseau" if rejeu else "")).strip(" —")[:200] or None,
                    date_operation=d.date_operation if rejeu and d.date_operation and d.date_operation <= date.today() else date.today())
    # contrôle : assez de e-monnaie sur la puce, assez d'espèces dans le kiosque
    s_puces, especes = soldes(db, point)
    dp, de = effets(o)
    if puce and s_puces.get(puce.id, ZERO) + dp < 0 and not rejeu:
        raise HTTPException(status_code=409, detail=f"Pas assez de e-monnaie sur la puce {puce.operateur.nom} "
                                                    f"({_f(s_puces.get(puce.id, ZERO))}) : rechargez-la d'abord.")
    if especes + de < 0 and not rejeu:
        raise HTTPException(status_code=409, detail=f"Pas assez d'espèces dans le kiosque ({_f(especes)}) : "
                                                    "faites d'abord un apport d'espèces.")
    o.commission = commission(db, puce.operateur_id, d.type_operation, d.montant) if puce else ZERO
    db.add(o)
    enregistrer(db, "Enregistrement impossible.")
    db.refresh(o)
    s_puces, especes = soldes(db, point)
    return {**operation_json(o), "solde_puce": montant(s_puces.get(o.puce_id, ZERO)) if o.puce_id else None,
            "especes": montant(especes)}


@router.get("/operations")
def liste_operations(point_id: int | None = None, debut: date | None = None, fin: date | None = None,
                     u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    ids = [p.id for p in points_visibles(db, u)]
    if point_id is not None:
        if point_id not in ids:
            raise HTTPException(status_code=404, detail="Kiosque introuvable.")
        ids = [point_id]
    q = (db.query(MMOperation).options(selectinload(MMOperation.point), selectinload(MMOperation.auteur),
                                       selectinload(MMOperation.puce).selectinload(MMPuce.operateur))
         .filter(MMOperation.point_id.in_(ids or [0])))
    q = q.filter(MMOperation.date_operation >= (debut or date.today() - timedelta(days=6)))
    if fin:
        q = q.filter(MMOperation.date_operation <= fin)
    return [operation_json(o) for o in q.order_by(MMOperation.id.desc()).limit(1000)]


class AnnulationIn(Suppression):
    motif: Texte = Field(min_length=3, max_length=300)


@router.post("/operations/{operation_id}/annuler")
def annuler(operation_id: int, d: AnnulationIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    if u.role.value not in ("Admin", "Caisse"):
        raise HTTPException(status_code=403, detail="Annulation réservée à l'Admin et à la Caisse.")
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", u.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été annulé.")
    o = charger(db, MMOperation, operation_id, "Opération introuvable.")
    _point_autorise(db, u, o.point_id)
    if o.annulee:
        raise HTTPException(status_code=409, detail="Cette opération est déjà annulée.")
    if db.query(MMCloture).filter(MMCloture.point_id == o.point_id, MMCloture.date_cloture >= o.date_operation).first():
        raise HTTPException(status_code=409, detail="La journée de cette opération est déjà clôturée : elle ne peut plus être annulée.")
    o.annulee, o.motif_annulation, o.annule_par = True, d.motif, u.id
    enregistrer(db, "Annulation impossible.")
    return {"ok": True}


# ---------- Clôture du soir ----------

class PuceCompteeIn(Formulaire):
    puce_id: int
    reel: Decimal = Field(ge=0, max_digits=14, decimal_places=2)


class ClotureIn(Formulaire):
    point_id: int
    especes_comptees: Decimal = Field(ge=0, max_digits=14, decimal_places=2)
    puces: list[PuceCompteeIn] = Field(default_factory=list)
    note: Texte | None = Field(None, max_length=300)
    date_cloture: date | None = None   # oubli de la veille : on clôture le lendemain matin


@router.post("/clotures")
def cloturer(d: ClotureIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _peut_saisir(u)
    point = _point_autorise(db, u, d.point_id)
    aujourdhui = d.date_cloture or date.today()
    if aujourdhui > date.today() or aujourdhui < point.date_depart - timedelta(days=1):
        raise HTTPException(status_code=400, detail="Date de clôture incorrecte.")
    if db.query(MMCloture).filter(MMCloture.point_id == point.id, MMCloture.date_cloture == aujourdhui).first():
        raise HTTPException(status_code=409, detail="Cette journée est déjà clôturée pour ce kiosque.")
    s_puces, especes = soldes(db, point, aujourdhui)
    lues = {x.puce_id: x.reel for x in d.puces}
    detail = []
    for p in point.puces:
        if p.actif:
            calcule = s_puces.get(p.id, ZERO)
            reel = lues.get(p.id, calcule)
            detail.append({"puce_id": p.id, "operateur": p.operateur.nom, "calcule": montant(calcule), "reel": montant(reel),
                           "ecart": montant(reel - calcule)})
    c = MMCloture(point_id=point.id, date_cloture=aujourdhui, especes_calculees=especes, especes_comptees=d.especes_comptees,
                  puces=detail, note=d.note or None, saisi_par=u.id)
    db.add(c)
    enregistrer(db, "Clôture impossible.")
    return {"id": c.id, "ecart_especes": montant(d.especes_comptees - especes), "puces": detail}


@router.get("/clotures")
def liste_clotures(point_id: int | None = None, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    ids = [p.id for p in points_visibles(db, u)]
    q = db.query(MMCloture).options(selectinload(MMCloture.point), selectinload(MMCloture.auteur)) \
        .filter(MMCloture.point_id.in_([point_id] if point_id in ids else ids or [0]))
    return [{"id": c.id, "point": c.point.nom, "date": c.date_cloture.isoformat(),
             "especes_calculees": montant(c.especes_calculees), "especes_comptees": montant(c.especes_comptees),
             "ecart_especes": montant(c.especes_comptees - c.especes_calculees), "puces": c.puces, "note": c.note or "",
             "saisi_par": c.auteur.nom_complet if c.auteur else ""}
            for c in q.order_by(MMCloture.date_cloture.desc(), MMCloture.id.desc()).limit(120)]


@router.post("/clotures/{cloture_id}/supprimer")
def supprimer_cloture(cloture_id: int, d: Suppression, admin: Utilisateur = Depends(exiger_admin),
                      db: SessionDB = Depends(get_db)):
    acces(admin)
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe Admin incorrect.")
    c = charger(db, MMCloture, cloture_id, "Clôture introuvable.")
    db.delete(c)
    enregistrer(db, "Suppression impossible.")
    return {"ok": True}


# ---------- Rapport : volumes et commissions ----------

@router.get("/rapport")
def rapport(debut: date | None = Query(None), fin: date | None = Query(None), point_id: int | None = None,
            u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    debut = debut or date.today().replace(day=1)
    fin = fin or date.today()
    ids = [p.id for p in points_visibles(db, u)]
    if point_id is not None:
        ids = [point_id] if point_id in ids else []
    ops = (db.query(MMOperation).options(selectinload(MMOperation.puce).selectinload(MMPuce.operateur),
                                         selectinload(MMOperation.auteur), selectinload(MMOperation.point))
           .filter(MMOperation.point_id.in_(ids or [0]), MMOperation.annulee.is_(False),
                   MMOperation.date_operation >= debut, MMOperation.date_operation <= fin).all())
    par_op = defaultdict(lambda: {"depots": ZERO, "retraits": ZERO, "nombre": 0, "commissions": ZERO, "couleur": "#1d3b53"})
    par_agent = defaultdict(lambda: {"nombre": 0, "volume": ZERO, "commissions": ZERO})
    par_jour = defaultdict(lambda: ZERO)
    for o in ops:
        if o.type_operation not in ("Dépôt", "Retrait"):
            continue
        x = par_op[o.puce.operateur.nom]
        x["couleur"] = o.puce.operateur.couleur
        x["depots" if o.type_operation == "Dépôt" else "retraits"] += o.montant
        x["nombre"] += 1
        x["commissions"] += o.commission
        a = par_agent[o.auteur.nom_complet if o.auteur else "—"]
        a["nombre"] += 1
        a["volume"] += o.montant
        a["commissions"] += o.commission
        par_jour[o.date_operation] += o.commission
    total_com = sum((x["commissions"] for x in par_op.values()), ZERO)
    recues = sum((o.montant for o in ops if o.type_operation == "Commission reçue"), ZERO)
    jours, j = [], debut
    while j <= fin and len(jours) < 400:
        jours.append({"date": j.isoformat(), "commissions": montant(par_jour.get(j, ZERO))})
        j += timedelta(days=1)
    return {"debut": debut.isoformat(), "fin": fin.isoformat(),
            "total": {"nombre": sum(x["nombre"] for x in par_op.values()), "commissions": montant(total_com),
                      "commissions_recues": montant(recues),
                      "depots": montant(sum((x["depots"] for x in par_op.values()), ZERO)),
                      "retraits": montant(sum((x["retraits"] for x in par_op.values()), ZERO))},
            "par_operateur": [{"operateur": n, "couleur": x["couleur"], "nombre": x["nombre"], "depots": montant(x["depots"]),
                               "retraits": montant(x["retraits"]), "commissions": montant(x["commissions"])}
                              for n, x in sorted(par_op.items(), key=lambda y: -y[1]["commissions"])],
            "par_agent": [{"agent": n, "nombre": x["nombre"], "volume": montant(x["volume"]), "commissions": montant(x["commissions"])}
                          for n, x in sorted(par_agent.items(), key=lambda y: -y[1]["volume"])],
            "par_jour": jours}


# ---------- Réglages (Admin) : opérateurs, kiosques, puces, barèmes, agents ----------

@router.get("/reglages")
def reglages(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    ops = db.query(MMOperateur).order_by(MMOperateur.ordre, MMOperateur.nom).all()
    baremes = defaultdict(list)
    for b in db.query(MMBareme).order_by(MMBareme.montant_min):
        baremes[b.operateur_id].append({"type": b.type_operation, "min": montant(b.montant_min),
                                        "max": montant(b.montant_max) if b.montant_max is not None else None,
                                        "fixe": montant(b.commission_fixe), "pct": float(b.commission_pct)})
    points = db.query(MMPoint).options(selectinload(MMPoint.puces), selectinload(MMPoint.agents)).order_by(MMPoint.nom).all()
    return {"operateurs": [{"id": o.id, "nom": o.nom, "couleur": o.couleur, "actif": o.actif, "baremes": baremes[o.id]} for o in ops],
            "points": [{"id": p.id, "nom": p.nom, "adresse": p.adresse or "", "especes_depart": montant(p.especes_depart),
                        "seuil_especes": montant(p.seuil_especes), "actif": p.actif, "agents": [a.id for a in p.agents],
                        "puces": [{"id": x.id, "operateur_id": x.operateur_id, "numero": x.numero or "",
                                   "solde_depart": montant(x.solde_depart), "seuil_alerte": montant(x.seuil_alerte),
                                   "actif": x.actif} for x in p.puces]} for p in points],
            "utilisateurs": [{"id": x.id, "nom": x.nom_complet, "role": x.role.value}
                             for x in db.query(Utilisateur).filter(Utilisateur.actif.is_(True)).order_by(Utilisateur.nom_complet)
                             if x.role.value in ("Caisse", "Gestionnaire")]}


class PuceIn(Formulaire):
    operateur_id: int
    numero: Texte | None = Field(None, max_length=30)
    solde_depart: Decimal = Field(Decimal(0), max_digits=14, decimal_places=2)
    seuil_alerte: Decimal = Field(Decimal(0), ge=0, max_digits=14, decimal_places=2)
    actif: bool = True


class PointIn(Formulaire):
    nom: Texte = Field(min_length=2, max_length=100)
    adresse: Texte | None = Field(None, max_length=200)
    especes_depart: Decimal = Field(Decimal(0), max_digits=14, decimal_places=2)
    seuil_especes: Decimal = Field(Decimal(0), ge=0, max_digits=14, decimal_places=2)
    actif: bool = True
    agents: list[int] = Field(default_factory=list)
    puces: list[PuceIn] = Field(default_factory=list, max_length=20)


def _appliquer_point(db: SessionDB, p: MMPoint, d: PointIn) -> None:
    p.nom, p.adresse, p.especes_depart, p.seuil_especes, p.actif = d.nom, d.adresse or None, d.especes_depart, d.seuil_especes, d.actif
    p.agents = db.query(Utilisateur).filter(Utilisateur.id.in_(d.agents or [0])).all()
    if len({x.operateur_id for x in d.puces}) != len(d.puces):
        raise HTTPException(status_code=400, detail="Une seule puce par opérateur et par kiosque.")
    existantes = {x.operateur_id: x for x in p.puces}
    for x in d.puces:
        charger(db, MMOperateur, x.operateur_id, "Opérateur introuvable.")
        puce = existantes.get(x.operateur_id) or MMPuce(operateur_id=x.operateur_id)
        puce.numero, puce.solde_depart, puce.seuil_alerte, puce.actif = x.numero or None, x.solde_depart, x.seuil_alerte, x.actif
        if puce.id is None:
            p.puces.append(puce)
    for operateur_id, puce in existantes.items():   # une puce retirée du formulaire est désactivée (ses opérations restent)
        if operateur_id not in {x.operateur_id for x in d.puces}:
            puce.actif = False


@router.post("/points")
def creer_point(d: PointIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    p = MMPoint(date_depart=date.today())
    db.add(p)
    _appliquer_point(db, p, d)
    enregistrer(db, f"Un kiosque « {d.nom} » existe déjà.")
    return {"id": p.id}


@router.put("/points/{point_id}")
def modifier_point(point_id: int, d: PointIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    p = charger(db, MMPoint, point_id, "Kiosque introuvable.")
    _appliquer_point(db, p, d)
    enregistrer(db, f"Un kiosque « {d.nom} » existe déjà.")
    return {"id": p.id}


class TrancheIn(Formulaire):
    type: Literal["Dépôt", "Retrait"]
    min: Decimal = Field(Decimal(0), ge=0, max_digits=14, decimal_places=2)
    max: Decimal | None = Field(None, ge=0, max_digits=14, decimal_places=2)
    fixe: Decimal = Field(Decimal(0), ge=0, max_digits=12, decimal_places=2)
    pct: Decimal = Field(Decimal(0), ge=0, le=100, max_digits=6, decimal_places=3)


class OperateurIn(Formulaire):
    nom: Texte = Field(min_length=2, max_length=60)
    couleur: str = Field("#1d3b53", pattern=r"^#[0-9a-fA-F]{6}$")
    actif: bool = True
    baremes: list[TrancheIn] = Field(default_factory=list, max_length=60)


def _appliquer_operateur(db: SessionDB, o: MMOperateur, d: OperateurIn) -> None:
    for x in d.baremes:
        if x.max is not None and x.max < x.min:
            raise HTTPException(status_code=400, detail="Une tranche a un maximum plus petit que son minimum.")
    o.nom, o.couleur, o.actif = d.nom, d.couleur, d.actif
    db.flush()
    db.query(MMBareme).filter(MMBareme.operateur_id == o.id).delete()
    for x in d.baremes:
        db.add(MMBareme(operateur_id=o.id, type_operation=x.type, montant_min=x.min, montant_max=x.max,
                        commission_fixe=x.fixe, commission_pct=x.pct))


@router.post("/operateurs")
def creer_operateur(d: OperateurIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    o = MMOperateur(ordre=(db.query(func.max(MMOperateur.ordre)).scalar() or 0) + 1)
    db.add(o)
    _appliquer_operateur(db, o, d)
    enregistrer(db, f"L'opérateur « {d.nom} » existe déjà.")
    return {"id": o.id}


@router.put("/operateurs/{operateur_id}")
def modifier_operateur(operateur_id: int, d: OperateurIn, admin: Utilisateur = Depends(exiger_admin),
                       db: SessionDB = Depends(get_db)):
    acces(admin)
    o = charger(db, MMOperateur, operateur_id, "Opérateur introuvable.")
    _appliquer_operateur(db, o, d)
    enregistrer(db, f"L'opérateur « {d.nom} » existe déjà.")
    return {"id": o.id}


# ---------- Pour la trésorerie et la comptabilité de l'entreprise ----------

def operations_avec_compte(db: SessionDB, debut: date | None = None, fin: date | None = None):
    """Opérations reliées à un compte de l'entreprise (apports, sorties, rechargements par la banque, commissions)."""
    q = (db.query(MMOperation).options(selectinload(MMOperation.point), selectinload(MMOperation.puce).selectinload(MMPuce.operateur))
         .filter(MMOperation.compte_id.isnot(None), MMOperation.annulee.is_(False)))
    if debut is not None:
        q = q.filter(MMOperation.date_operation >= debut)
    if fin is not None:
        q = q.filter(MMOperation.date_operation <= fin)
    return q.order_by(MMOperation.date_operation, MMOperation.id).all()


def sens_tresorerie(o: MMOperation) -> str:
    """Pour le compte de l'entreprise : « entree » ou « sortie »."""
    return "sortie" if o.type_operation in ("Apport d'espèces", "Rechargement de la puce") else "entree"


def libelle_tresorerie(o: MMOperation) -> str:
    op = f" {o.puce.operateur.nom}" if o.puce else ""
    return {"Apport d'espèces": f"Apport d'espèces au kiosque {o.point.nom}",
            "Sortie d'espèces": f"Espèces reprises au kiosque {o.point.nom}",
            "Rechargement de la puce": f"Rechargement de la puce{op} ({o.point.nom})",
            "Retour de e-monnaie": f"Retour de e-monnaie{op} ({o.point.nom})",
            "Commission reçue": f"Commission Mobile Money{op}"}.get(o.type_operation, o.type_operation)


def situation_agences(db: SessionDB) -> list[dict]:
    """Pour la Trésorerie : espèces et e-monnaie de chaque kiosque (l'argent de l'agence)."""
    resultat = []
    for p in db.query(MMPoint).options(selectinload(MMPoint.puces).selectinload(MMPuce.operateur)).filter(MMPoint.actif).order_by(MMPoint.nom):
        s_puces, especes = soldes(db, p)
        puces = [{"operateur": x.operateur.nom, "solde": montant(s_puces.get(x.id, ZERO))} for x in p.puces if x.actif]
        resultat.append({"kiosque": p.nom, "especes": montant(especes), "puces": puces,
                         "total": montant(especes + sum((s_puces.get(x.id, ZERO) for x in p.puces if x.actif), ZERO))})
    return resultat


# ---------- Alertes (assistant) ----------

def alertes(db: SessionDB, u: Utilisateur) -> list[tuple[str, str, str, str]]:
    resultat = []
    hier = date.today() - timedelta(days=1)
    for p in points_visibles(db, u):
        if not p.actif:
            continue
        s_puces, especes = soldes(db, p)
        basses = [x.operateur.nom for x in p.puces if x.actif and x.seuil_alerte and s_puces.get(x.id, ZERO) <= x.seuil_alerte]
        if basses:
            resultat.append((f"mm-puce-{p.id}", "attention", f"{p.nom} : puce presque vide ({', '.join(basses)})",
                             "Rechargez la e-monnaie pour pouvoir servir les dépôts."))
        if p.seuil_especes and especes <= p.seuil_especes:
            resultat.append((f"mm-especes-{p.id}", "attention", f"{p.nom} : peu d'espèces ({_f(especes)})",
                             "Faites un apport d'espèces pour pouvoir servir les retraits."))
        if hier >= p.date_depart and db.query(MMOperation).filter(MMOperation.point_id == p.id, MMOperation.date_operation == hier).count() \
                and not db.query(MMCloture).filter(MMCloture.point_id == p.id, MMCloture.date_cloture == hier).first():
            resultat.append((f"mm-cloture-{p.id}", "info", f"{p.nom} : la journée d'hier n'a pas été clôturée",
                             "Pensez à compter la caisse chaque soir (Mobile Money → Clôture)."))
    return resultat
