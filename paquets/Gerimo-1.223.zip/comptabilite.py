"""Précomptabilité, parties 3 et 4 : TVA, résultat, clôture des périodes, export SYSCOHADA, rapprochement bancaire.

Tout est calculé à partir des opérations déjà saisies (encaissements, dépenses, achats/ventes, transferts,
reversements) : rien n'est ressaisi. Les paiements repris d'un ancien fichier (REP-) appartiennent à la période
d'avant Gérimo et ne sont pas comptés.

- TVA (si l'entreprise y est assujettie, Paramètres) : les commissions encaissées sont considérées TVA comprise ;
  TVA collectée − TVA payée sur les dépenses de l'entreprise = TVA à reverser à l'État.
- Résultat : commissions (et loyers des biens de l'entreprise) − charges de l'entreprise. Les achats et ventes de
  biens sont présentés à part (investissements et cessions, hors activité courante).
- Clôture : l'Admin fige les mois remis au comptable (voir periode.py).
- Export : journal des écritures au format du plan comptable SYSCOHADA révisé, en Excel, pour le comptable.
- Rapprochement : le relevé de la banque (Excel ou CSV) est comparé aux mouvements enregistrés dans Gérimo.

Droits : Admin, Caisse et Comptable ; clôture réservée à l'Admin (mot de passe redemandé).
"""
import io
from collections import defaultdict
from datetime import date, datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy.orm import Session as SessionDB, selectinload

import parametres
import periode
import recus
import sejours
import tresorerie
from commun import montant
from models import (AchatVente, Cite, CompteTresorerie, Contrat, Depense, Logement, Paiement, Parametre, Reversement,
                    TransfertTresorerie, Utilisateur)
from reversements import est_entreprise, net_vendeur
from securite import confirmer_mot_de_passe_admin, exiger_admin, exiger_module, get_db

router = APIRouter(prefix="/api")
acces = exiger_module("comptabilite")
acces_tresorerie = exiger_module("tresorerie")
ZERO = Decimal(0)
UN = Decimal(1)

# ---------- Plan comptable SYSCOHADA révisé (comptes utilisés) ----------

PLAN = {
    "5711": "Caisse", "5211": "Banque", "5521": "Monnaie électronique (Mobile Money)",
    "4671": "Propriétaires mandants (loyers à reverser)", "4672": "Vendeurs (ventes pour le compte de tiers)",
    "1650": "Dépôts et cautionnements reçus (cautions des locataires)",
    "7061": "Commissions de gestion locative", "7062": "Commissions d'intermédiation",
    "7083": "Locations (biens de l'entreprise)", "8210": "Produits des cessions de biens",
    "2210": "Terrains", "2310": "Bâtiments", "4431": "État, TVA facturée", "4452": "État, TVA récupérable",
    "6241": "Entretien et réparations des biens immobiliers", "6051": "Eau et électricité",
    "6371": "Gardiennage (personnel extérieur)", "6411": "Impôts et taxes", "6611": "Salaires et primes",
    "6222": "Location du bureau", "6055": "Fournitures de bureau", "6281": "Frais de télécommunication",
    "6042": "Carburant et transport", "6271": "Publicité", "6311": "Frais bancaires",
    "6324": "Honoraires", "6588": "Autres charges",
    "6011": "Achats de marchandises", "4011": "Fournisseurs",   # Commerce (13/11/2026)
    "7011": "Ventes de marchandises", "4111": "Clients",
    "7068": "Commissions Mobile Money", "5712": "Caisse des kiosques Mobile Money", "5522": "E-monnaie des puces Mobile Money",
}
COMPTE_CHARGE = {
    "Réparation": "6241", "Plomberie": "6241", "Électricité": "6241", "Peinture": "6241", "Entretien": "6241",
    "Eau / électricité (factures)": "6051", "Gardiennage": "6371", "Taxes et impôts": "6411",
    "Salaires et primes": "6611", "Loyer du bureau": "6222", "Fournitures de bureau": "6055",
    "Internet et téléphone": "6281", "Carburant et transport": "6042", "Publicité": "6271",
    "Frais bancaires": "6311", "Honoraires (comptable, avocat…)": "6324", "Autre": "6588",
}
COMPTE_TRESORERIE_DEFAUT = {"Caisse": "5711", "Banque": "5211", "Mobile Money": "5521"}
JOURNAL_DEFAUT = {"Caisse": "CA", "Banque": "BQ", "Mobile Money": "MM"}


# ---------- TVA ----------

def tva_reglages(db: SessionDB) -> tuple[bool, Decimal]:
    assujetti = parametres.lire(db, "tva_assujetti") == "oui"
    try:
        taux = Decimal(parametres.lire(db, "tva_taux") or "18")
    except ArithmeticError:
        taux = Decimal(18)
    return assujetti, taux


def part_tva(ttc: Decimal, taux: Decimal) -> Decimal:
    """TVA comprise dans un montant TTC (arrondie au franc)."""
    if not taux:
        return ZERO
    return (ttc * taux / (100 + taux)).quantize(UN, rounding=ROUND_HALF_UP)


def _repris(p: Paiement) -> bool:
    return (p.numero_recu or "").startswith(tresorerie.PREFIXE_REPRISE)


# ---------- Résultat et TVA d'une période ----------

def calculer(db: SessionDB, debut: date, fin: date) -> dict:
    assujetti, taux = tva_reglages(db)
    produits = defaultdict(lambda: ZERO)
    tva_collectee = ZERO
    paiements = db.query(Paiement).options(
        selectinload(Paiement.encaissement),
        selectinload(Paiement.contrat).selectinload(Contrat.logement).selectinload(Logement.cite)
        .selectinload(Cite.proprietaire),
    ).filter(Paiement.statut_paiement == "Payé", Paiement.date_paiement >= debut, Paiement.date_paiement <= fin)
    for p in paiements:
        if _repris(p) or p.encaissement is None:
            continue
        e = p.encaissement
        proprio = p.contrat.logement.cite.proprietaire
        if proprio is not None and est_entreprise(proprio.nom_complet):
            produits["Loyers des biens de l'entreprise"] += p.montant - (e.montant_caution or ZERO)
        elif e.commission_entreprise:
            produits["Commissions de gestion locative"] += e.commission_entreprise
    for v in sejours.versements(db, debut, fin):  # séjours en courte durée
        proprio = v.reservation.logement.cite.proprietaire
        if proprio is not None and est_entreprise(proprio.nom_complet):
            produits["Séjours des biens de l'entreprise"] += v.montant
        elif v.commission:
            produits["Commissions de gestion locative"] += v.commission
    for o in db.query(AchatVente).filter(AchatVente.type_operation == "Vente indirecte",
                                         AchatVente.date_operation >= debut, AchatVente.date_operation <= fin):
        produits["Commissions d'intermédiation"] += o.commission_montant or ZERO
    # les commissions sont considérées TVA comprise
    commissions_ttc = produits["Commissions de gestion locative"] + produits["Commissions d'intermédiation"]
    if assujetti:
        for cle in ("Commissions de gestion locative", "Commissions d'intermédiation"):
            tva = part_tva(produits[cle], taux)
            tva_collectee += tva
            produits[cle] -= tva

    charges = defaultdict(lambda: ZERO)
    tva_deductible = ZERO
    for d in db.query(Depense).filter(Depense.a_la_charge_de != "Propriétaire", Depense.date_depense >= debut,
                                      Depense.date_depense <= fin):
        tva = (d.montant_tva or ZERO) if assujetti else ZERO
        charges[d.categorie] += d.montant - tva
        tva_deductible += tva
    for t in db.query(TransfertTresorerie).filter(TransfertTresorerie.frais > 0, TransfertTresorerie.date_transfert >= debut,
                                                  TransfertTresorerie.date_transfert <= fin):
        charges["Frais bancaires"] += t.frais

    biens = {"achats": ZERO, "ventes": ZERO}
    for o in db.query(AchatVente).filter(AchatVente.type_operation.in_(("Achat", "Vente", "Vente directe")),
                                         AchatVente.date_operation >= debut, AchatVente.date_operation <= fin):
        biens["achats" if o.type_operation == "Achat" else "ventes"] += o.montant

    total_produits = sum(produits.values(), ZERO)
    total_charges = sum(charges.values(), ZERO)
    return {
        "debut": debut, "fin": fin, "tva": {"assujetti": assujetti, "taux": taux, "collectee": tva_collectee,
                                            "deductible": tva_deductible, "a_payer": tva_collectee - tva_deductible},
        "produits": [{"poste": k, "montant": v} for k, v in sorted(produits.items()) if v],
        "charges": [{"poste": k, "montant": v} for k, v in sorted(charges.items(), key=lambda x: -x[1]) if v],
        "total_produits": total_produits, "total_charges": total_charges,
        "resultat": total_produits - total_charges, "commissions_ttc": commissions_ttc, "biens": biens,
    }


def _mois(debut: date, fin: date) -> list[tuple[date, date]]:
    mois, courant = [], debut.replace(day=1)
    while courant <= fin:
        suivant = (courant.replace(day=28) + timedelta(days=4)).replace(day=1)
        mois.append((max(courant, debut), min(suivant - timedelta(days=1), fin)))
        courant = suivant
    return mois


def _j(v):
    if isinstance(v, Decimal):
        return montant(v)
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, dict):
        return {k: _j(x) for k, x in v.items()}
    if isinstance(v, list):
        return [_j(x) for x in v]
    return v


def _periode(debut: date | None, fin: date | None) -> tuple[date, date]:
    fin = fin or date.today()
    debut = debut or fin.replace(day=1)
    if debut > fin:
        raise HTTPException(status_code=400, detail="La date de début est après la date de fin.")
    if (fin - debut).days > 3700:
        raise HTTPException(status_code=400, detail="Période trop longue (10 ans au plus).")
    return debut, fin


@router.get("/comptabilite/resultat")
def resultat(debut: date | None = Query(None), fin: date | None = Query(None),
             utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    debut, fin = _periode(debut, fin)
    r = calculer(db, debut, fin)
    r["par_mois"] = [{"debut": a, "fin": b, **{k: calculer(db, a, b)[k] for k in ("total_produits", "total_charges",
                                                                                   "resultat")}}
                     for a, b in _mois(debut, fin)] if (fin - debut).days > 31 else []
    soldes_debut = tresorerie.soldes(db, debut - timedelta(days=1))
    soldes_fin = tresorerie.soldes(db, fin)
    r["tresorerie"] = [{"compte": c.nom, "debut": soldes_debut[c.id], "fin": soldes_fin[c.id]}
                       for c in db.query(CompteTresorerie).order_by(CompteTresorerie.nom) if c.actif]
    r["cloture_jusqu_au"] = periode.cloture_jusqu_au(db)
    r["peut_cloturer"] = utilisateur.role.value == "Admin"
    return _j(r)


@router.get("/comptabilite/resultat/pdf")
def resultat_pdf(debut: date | None = Query(None), fin: date | None = Query(None),
                 utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    r = resultat(debut, fin, utilisateur, db)
    contenu = recus.resultat_pdf(r)
    return Response(contenu, media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="Resultat {r["debut"]} {r["fin"]}.pdf"'})


# ---------- Clôture des périodes (Admin) ----------

class ClotureIn(BaseModel):
    jusqu_au: date | None = None      # vide = tout rouvrir
    mot_de_passe_admin: str


@router.post("/comptabilite/cloture")
def cloturer(d: ClotureIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, d.mot_de_passe_admin)
    if d.jusqu_au and d.jusqu_au >= date.today():
        raise HTTPException(status_code=400, detail="On ne clôture que des jours déjà passés.")
    p = db.get(Parametre, periode.CLE)
    valeur = d.jusqu_au.isoformat() if d.jusqu_au else ""
    if p is None:
        db.add(Parametre(cle=periode.CLE, valeur=valeur, modifie_le=datetime.now()))
    else:
        p.valeur, p.modifie_le = valeur, datetime.now()
    db.commit()
    return {"cloture_jusqu_au": valeur or None}


# ---------- Export comptable SYSCOHADA (Excel) ----------

def ecritures(db: SessionDB, debut: date, fin: date) -> list[dict]:
    """Écritures équilibrées (débit = crédit), une par opération, au format SYSCOHADA."""
    assujetti, taux = tva_reglages(db)
    rangement = tresorerie.Rangement(db)
    comptes = rangement.comptes
    journaux_utilises = defaultdict(int)
    code_journal = {}
    for c in sorted(comptes.values(), key=lambda x: x.id):
        base = JOURNAL_DEFAUT[c.type_compte]
        journaux_utilises[base] += 1
        code_journal[c.id] = base if journaux_utilises[base] == 1 else f"{base}{journaux_utilises[base]}"

    def tres(compte_id: int | None) -> tuple[str, str]:
        """(n° de compte, code journal) d'un compte de trésorerie ; 4718 « à classer » s'il n'est rangé nulle part."""
        c = comptes.get(compte_id)
        if c is None:
            return "4718", "OD"
        return c.compte_comptable or COMPTE_TRESORERIE_DEFAUT[c.type_compte], code_journal[c.id]

    resultat = []

    def ecriture(jour, journal, piece, libelle, lignes):
        lignes = [l for l in lignes if l[2] or l[3]]
        assert sum(l[2] for l in lignes) == sum(l[3] for l in lignes), (piece, lignes)
        for compte, tiers, debit, credit in lignes:
            resultat.append({"date": jour, "journal": journal, "piece": piece or "", "compte": compte,
                             "intitule": PLAN.get(compte, ""), "tiers": tiers or "", "libelle": libelle,
                             "debit": debit, "credit": credit})

    paiements = db.query(Paiement).options(
        selectinload(Paiement.encaissement), selectinload(Paiement.contrat).selectinload(Contrat.locataire),
        selectinload(Paiement.contrat).selectinload(Contrat.logement).selectinload(Logement.cite)
        .selectinload(Cite.proprietaire),
    ).filter(Paiement.statut_paiement == "Payé", Paiement.date_paiement >= debut, Paiement.date_paiement <= fin) \
        .order_by(Paiement.date_paiement, Paiement.id)
    for p in paiements:
        if _repris(p) or p.encaissement is None:
            continue
        e, cite = p.encaissement, p.contrat.logement.cite
        proprio = cite.proprietaire.nom_complet if cite.proprietaire else "Propriétaire non renseigné"
        caution = e.montant_caution or ZERO
        loyers = p.montant - caution
        compte, journal = tres(rangement.compte(p.compte_id, p.mode_paiement))
        libelle = f"Encaissement {p.contrat.locataire.nom_complet} — {cite.nom}"
        if est_entreprise(proprio):  # loyers des biens de l'entreprise : produit (sans TVA)
            ecriture(p.date_paiement, journal, p.numero_recu, libelle, [
                (compte, "", p.montant, ZERO), ("1650", p.contrat.locataire.nom_complet, ZERO, caution),
                ("7083", "", ZERO, loyers)])
            continue
        ecriture(p.date_paiement, journal, p.numero_recu, libelle, [
            (compte, "", p.montant, ZERO), ("1650", p.contrat.locataire.nom_complet, ZERO, caution),
            ("4671", proprio, ZERO, loyers)])
        commission = e.commission_entreprise or ZERO
        if commission:
            tva = part_tva(commission, taux) if assujetti else ZERO
            ecriture(p.date_paiement, "OD", p.numero_recu, f"Commission de gestion — {cite.nom}", [
                ("4671", proprio, commission, ZERO), ("7061", "", ZERO, commission - tva), ("4431", "", ZERO, tva)])

    for v in sejours.versements(db, debut, fin):  # séjours en courte durée (sans caution)
        cite = v.reservation.logement.cite
        proprio = cite.proprietaire.nom_complet if cite.proprietaire else "Propriétaire non renseigné"
        compte, journal = tres(rangement.compte(v.compte_id, v.mode_paiement))
        libelle = f"Séjour {v.reservation.client_nom} — {cite.nom}"
        if est_entreprise(proprio):
            ecriture(v.date_paiement, journal, v.numero_recu, libelle, [(compte, "", v.montant, ZERO),
                                                                         ("7083", "", ZERO, v.montant)])
            continue
        ecriture(v.date_paiement, journal, v.numero_recu, libelle, [(compte, "", v.montant, ZERO),
                                                                     ("4671", proprio, ZERO, v.montant)])
        if v.commission:
            tva = part_tva(v.commission, taux) if assujetti else ZERO
            ecriture(v.date_paiement, "OD", v.numero_recu, f"Commission de gestion (séjour) — {cite.nom}", [
                ("4671", proprio, v.commission, ZERO), ("7061", "", ZERO, v.commission - tva), ("4431", "", ZERO, tva)])

    for d in db.query(Depense).options(selectinload(Depense.cite).selectinload(Cite.proprietaire)).filter(
            Depense.date_depense >= debut, Depense.date_depense <= fin).order_by(Depense.date_depense, Depense.id):
        compte, journal = tres(rangement.compte(d.compte_id, d.mode_paiement))
        lieu = d.cite.nom if d.cite else "fonctionnement"
        libelle = f"Dépense — {d.motif} ({lieu})"
        piece = d.justificatif or f"DEP-{d.id}"
        if d.a_la_charge_de == "Propriétaire" and d.cite is not None:
            proprio = d.cite.proprietaire.nom_complet if d.cite.proprietaire else "Propriétaire non renseigné"
            ecriture(d.date_depense, journal, piece, libelle, [("4671", proprio, d.montant, ZERO), (compte, "", ZERO, d.montant)])
        else:
            tva = (d.montant_tva or ZERO) if assujetti else ZERO
            ecriture(d.date_depense, journal, piece, libelle, [
                (COMPTE_CHARGE.get(d.categorie, "6588"), "", d.montant - tva, ZERO), ("4452", "", tva, ZERO),
                (compte, "", ZERO, d.montant)])

    for o in db.query(AchatVente).filter(AchatVente.date_operation >= debut, AchatVente.date_operation <= fin) \
            .order_by(AchatVente.date_operation, AchatVente.id):
        compte, journal = tres(rangement.compte(o.compte_id, o.mode_paiement))
        if o.type_operation == "Achat":
            immo = "2210" if o.parcelle_id else "2310"
            ecriture(o.date_operation, journal, o.numero, f"Achat — {o.designation or ''}",
                     [(immo, o.partie_nom, o.montant, ZERO), (compte, "", ZERO, o.montant)])
        elif o.type_operation == "Vente indirecte":
            commission = o.commission_montant or ZERO
            recu = o.montant + (commission if o.commission_payee_par == "Acheteur" else ZERO)
            tva = part_tva(commission, taux) if assujetti else ZERO
            vendeur = o.proprietaire_nom or "Vendeur"
            # l'argent reçu appartient au vendeur, sauf la commission qui est un produit de l'entreprise
            ecriture(o.date_operation, journal, o.numero, f"Vente pour le compte de {vendeur} — {o.partie_nom}", [
                (compte, "", recu, ZERO), ("4672", vendeur, ZERO, net_vendeur(o)),
                ("7062", "", ZERO, commission - tva), ("4431", "", ZERO, tva)])
        else:
            ecriture(o.date_operation, journal, o.numero, f"Vente — {o.designation or ''}",
                     [(compte, "", o.montant, ZERO), ("8210", o.partie_nom, ZERO, o.montant)])

    for t in db.query(TransfertTresorerie).filter(TransfertTresorerie.date_transfert >= debut,
                                                  TransfertTresorerie.date_transfert <= fin) \
            .order_by(TransfertTresorerie.date_transfert, TransfertTresorerie.id):
        source, journal = tres(t.compte_source)
        cible, _ = tres(t.compte_cible)
        ecriture(t.date_transfert, journal, t.numero, t.libelle or "Transfert entre comptes",
                 [(cible, "", t.montant, ZERO), ("6311", "", t.frais, ZERO), (source, "", ZERO, t.montant + t.frais)])

    for r in db.query(Reversement).options(selectinload(Reversement.contrat).selectinload(Contrat.logement)
                                           .selectinload(Logement.cite)).filter(
            Reversement.date_reversement >= debut, Reversement.date_reversement <= fin) \
            .order_by(Reversement.date_reversement, Reversement.id):
        compte, journal = tres(r.compte_id)
        if r.type_reversement == "Loyers":
            ecriture(r.date_reversement, journal, r.numero, f"Reversement des loyers — {r.beneficiaire_nom}",
                     [("4671", r.beneficiaire_nom, r.montant, ZERO), (compte, "", ZERO, r.montant)])
        elif r.type_reversement == "Vente":
            ecriture(r.date_reversement, journal, r.numero, f"Versement au vendeur — {r.beneficiaire_nom}",
                     [("4672", r.beneficiaire_nom, r.montant, ZERO), (compte, "", ZERO, r.montant)])
        else:
            cite = r.contrat.logement.cite
            proprio = cite.proprietaire.nom_complet if cite.proprietaire else "Propriétaire non renseigné"
            ecriture(r.date_reversement, journal, r.numero, f"Restitution de caution — {r.beneficiaire_nom}", [
                ("1650", r.beneficiaire_nom, r.montant + r.retenue, ZERO), (compte, "", ZERO, r.montant),
                ("4671", proprio, ZERO, r.retenue)])
    # Commerce : ventes au comptoir, sommes reçues des clients, annulations
    import ventes
    for v in ventes.ventes_du(db, debut, fin):
        client = v.client.nom if v.client else "Clients divers"
        ecriture(v.date_vente, "VT", v.numero, f"Vente de marchandises — {client}",
                 [("4111", client, v.total, ZERO), ("7011", "", ZERO, v.total)])
    for x in ventes.reglements(db, debut, fin):
        client = x.vente.client.nom if x.vente.client else "Clients divers"
        compte, journal = tres(rangement.compte(x.compte_id, x.mode_paiement))
        ecriture(x.date_reglement, journal, x.numero, f"Encaissement vente {x.vente.numero} — {client}",
                 [(compte, "", x.montant, ZERO), ("4111", client, ZERO, x.montant)])
    for v in ventes.annulations_du(db, debut, fin):
        client = v.client.nom if v.client else "Clients divers"
        ecriture(v.annule_le, "VT", v.numero, f"Annulation de la vente {v.numero} — {client}",
                 [("7011", "", v.total, ZERO), ("4111", client, ZERO, v.total)])
        if v.rembourse:
            compte, journal = tres(rangement.compte(v.rembourse_compte_id, v.rembourse_mode))
            ecriture(v.annule_le, journal, v.numero, f"Remboursement vente {v.numero} — {client}",
                     [("4111", client, v.rembourse, ZERO), (compte, "", ZERO, v.rembourse)])

    # Agence Mobile Money : argent échangé entre un compte de l'entreprise et les kiosques ; commissions reçues
    import mobile_money
    for o in mobile_money.operations_avec_compte(db, debut, fin):
        compte, journal = tres(o.compte_id)
        libelle = mobile_money.libelle_tresorerie(o)
        t = o.type_operation
        lignes = {"Apport d'espèces": [("5712", "", o.montant, ZERO), (compte, "", ZERO, o.montant)],
                  "Sortie d'espèces": [(compte, "", o.montant, ZERO), ("5712", "", ZERO, o.montant)],
                  "Rechargement de la puce": [("5522", "", o.montant, ZERO), (compte, "", ZERO, o.montant)],
                  "Retour de e-monnaie": [(compte, "", o.montant, ZERO), ("5522", "", ZERO, o.montant)],
                  "Commission reçue": [(compte, "", o.montant, ZERO), ("7068", "", ZERO, o.montant)]}.get(t)
        if lignes:
            ecriture(o.date_operation, journal, o.numero, libelle, lignes)
    # commission versée sur la puce (sans compte de l'entreprise) : produit, en e-monnaie
    from models import MMOperation
    for o in db.query(MMOperation).filter(MMOperation.type_operation == "Commission reçue", MMOperation.compte_id.is_(None),
                                          MMOperation.annulee.is_(False), MMOperation.date_operation >= debut,
                                          MMOperation.date_operation <= fin):
        ecriture(o.date_operation, "OD", o.numero, "Commission Mobile Money versée sur la puce",
                 [("5522", "", o.montant, ZERO), ("7068", "", ZERO, o.montant)])

    # Commerce : arrivage aux prix complétés = achat de marchandises dû au fournisseur ; paiement = dette réglée
    import arrivages
    for a in arrivages.arrivages_completes(db, debut, fin):
        fournisseur = a.fournisseur.nom if a.fournisseur else "Fournisseur divers"
        ecriture(a.date_arrivage, "AC", a.reference_facture or a.numero, f"Achat de marchandises — {fournisseur} ({a.numero})",
                 [("6011", "", a.montant_total, ZERO), ("4011", fournisseur, ZERO, a.montant_total)])
    for v in arrivages.versements(db, debut, fin):
        fournisseur = v.arrivage.fournisseur.nom if v.arrivage.fournisseur else "Fournisseur divers"
        compte, journal = tres(rangement.compte(v.compte_id, v.mode_paiement))
        ecriture(v.date_versement, journal, v.arrivage.numero, f"Paiement fournisseur — {fournisseur}",
                 [("4011", fournisseur, v.montant, ZERO), (compte, "", ZERO, v.montant)])
    resultat.sort(key=lambda l: (l["date"], l["journal"], l["piece"]))
    return resultat


@router.get("/comptabilite/export-syscohada")
def export_syscohada(debut: date | None = Query(None), fin: date | None = Query(None),
                     utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    import openpyxl
    from openpyxl.styles import Alignment, Font, PatternFill
    debut, fin = _periode(debut, fin)
    lignes = ecritures(db, debut, fin)
    classeur = openpyxl.Workbook()
    entete = Font(bold=True, color="FFFFFF")
    fond = PatternFill("solid", fgColor="1D3B53")

    def feuille(ws, titres, largeurs):
        ws.append(titres)
        for i, largeur in enumerate(largeurs, start=1):
            ws.cell(row=1, column=i).font, ws.cell(row=1, column=i).fill = entete, fond
            ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = largeur
        ws.freeze_panes = "A2"

    ws = classeur.active
    ws.title = "Journal"
    feuille(ws, ["Date", "Journal", "N° pièce", "Compte", "Intitulé du compte", "Tiers", "Libellé", "Débit", "Crédit"],
            [12, 9, 18, 10, 38, 26, 50, 14, 14])
    for l in lignes:
        ws.append([l["date"], l["journal"], l["piece"], l["compte"], l["intitule"], l["tiers"], l["libelle"],
                   float(l["debit"]) or None, float(l["credit"]) or None])
        ws.cell(row=ws.max_row, column=1).number_format = "DD/MM/YYYY"
        for col in (8, 9):
            ws.cell(row=ws.max_row, column=col).number_format = "#,##0"
    total_debit = sum((l["debit"] for l in lignes), ZERO)
    total_credit = sum((l["credit"] for l in lignes), ZERO)
    ws.append(["", "", "", "", "", "", "TOTAL", float(total_debit), float(total_credit)])
    for col in range(7, 10):
        ws.cell(row=ws.max_row, column=col).font = Font(bold=True)
        ws.cell(row=ws.max_row, column=col).number_format = "#,##0"

    balance = defaultdict(lambda: [ZERO, ZERO])
    for l in lignes:
        balance[l["compte"]][0] += l["debit"]
        balance[l["compte"]][1] += l["credit"]
    wb = classeur.create_sheet("Balance")
    feuille(wb, ["Compte", "Intitulé", "Total débit", "Total crédit", "Solde débiteur", "Solde créditeur"],
            [10, 44, 15, 15, 15, 15])
    for compte in sorted(balance):
        d, c = balance[compte]
        wb.append([compte, PLAN.get(compte, ""), float(d), float(c), float(max(d - c, ZERO)), float(max(c - d, ZERO))])
        for col in range(3, 7):
            wb.cell(row=wb.max_row, column=col).number_format = "#,##0"
    wi = classeur.create_sheet("Informations")
    for ligne in (["Entreprise", recus.ENTETE["nom"]], ["Période", f"du {debut:%d/%m/%Y} au {fin:%d/%m/%Y}"],
                  ["Établi le", datetime.now().strftime("%d/%m/%Y %H:%M")], ["Par", utilisateur.nom_complet],
                  ["Référentiel", "Plan comptable SYSCOHADA révisé (comptes à vérifier par le comptable)"],
                  ["Note", "4718 = opérations dont le mode de paiement n'est rangé dans aucun compte de trésorerie"]):
        wi.append(ligne)
    wi.column_dimensions["A"].width, wi.column_dimensions["B"].width = 16, 80
    for cellule in wi["B"]:
        cellule.alignment = Alignment(wrap_text=True)
    sortie = io.BytesIO()
    classeur.save(sortie)
    nom = f"Ecritures SYSCOHADA {debut:%Y-%m-%d} au {fin:%Y-%m-%d}.xlsx"
    return Response(sortie.getvalue(), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{nom}"'})


# ---------- Rapprochement bancaire ----------

MOTS_DATE = ("date",)
MOTS_LIBELLE = ("libell", "désignation", "designation", "description", "opération", "operation", "détail", "motif")
MOTS_DEBIT = ("débit", "debit", "retrait", "sortie")
MOTS_CREDIT = ("crédit", "credit", "versement", "entrée", "entree", "dépôt", "depot")
MOTS_MONTANT = ("montant",)


def _colonne(colonnes: list[str], mots: tuple, exclure: int | None = None) -> int | None:
    for i, c in enumerate(colonnes):
        if i != exclure and any(m in c.lower() for m in mots):
            return i
    return None


def _nombre(valeur) -> Decimal | None:
    if valeur in (None, ""):
        return None
    if isinstance(valeur, (int, float)):
        return Decimal(str(valeur)).quantize(UN, rounding=ROUND_HALF_UP)
    texte = str(valeur).replace(" ", "").replace("\xa0", "").replace(" ", "").replace("F", "").replace("CFA", "")
    texte = texte.replace(",", ".")
    try:
        return Decimal(texte).quantize(UN, rounding=ROUND_HALF_UP)
    except ArithmeticError:
        return None


def _date(valeur) -> date | None:
    if isinstance(valeur, datetime):
        return valeur.date()
    if isinstance(valeur, date):
        return valeur
    texte = str(valeur or "").strip()[:10]
    for forme in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d/%m/%y"):
        try:
            return datetime.strptime(texte, forme).date()
        except ValueError:
            continue
    return None


def lire_releve(nom: str, contenu: bytes) -> list[dict]:
    """Lignes du relevé : date, libellé, sens (entree/sortie) et montant."""
    from import_donnees import lire_fichier
    feuille = lire_fichier(nom, contenu)[0]
    colonnes = feuille["colonnes"]
    i_date = _colonne(colonnes, MOTS_DATE)
    i_lib = _colonne(colonnes, MOTS_LIBELLE, exclure=i_date)
    i_debit, i_credit = _colonne(colonnes, MOTS_DEBIT), _colonne(colonnes, MOTS_CREDIT)
    i_montant = _colonne(colonnes, MOTS_MONTANT)
    if i_date is None or not ((i_debit is not None and i_credit is not None) or i_montant is not None):
        raise HTTPException(status_code=400, detail="Relevé non reconnu : il faut une colonne « Date » et soit des "
                                                    "colonnes « Débit » et « Crédit », soit une colonne « Montant » "
                                                    "(négatif pour les sorties).")
    lignes = []
    for l in feuille["lignes"]:
        v = l["valeurs"] + [None] * len(colonnes)
        jour = _date(v[i_date])
        if jour is None:
            continue
        if i_debit is not None and i_credit is not None:
            debit, credit = _nombre(v[i_debit]), _nombre(v[i_credit])
            sens, somme = ("sortie", debit) if debit else ("entree", credit)
        else:
            m = _nombre(v[i_montant])
            sens, somme = ("sortie", -m) if m is not None and m < 0 else ("entree", m)
        if not somme:
            continue
        lignes.append({"date": jour, "libelle": str(v[i_lib] or "") if i_lib is not None else "", "sens": sens,
                       "montant": abs(somme), "ligne": l["ligne"]})
    if not lignes:
        raise HTTPException(status_code=400, detail="Aucune opération lisible dans ce relevé.")
    return lignes


def rapprocher(releve: list[dict], gerimo: list[dict], tolerance_jours: int = 5) -> dict:
    """Associe chaque ligne du relevé à un mouvement Gérimo de même sens et même montant, à quelques jours près."""
    libres = list(range(len(gerimo)))
    associes, releve_seul = [], []
    for r in sorted(releve, key=lambda x: x["date"]):
        candidats = [i for i in libres if gerimo[i]["sens"] == r["sens"] and gerimo[i]["montant"] == r["montant"]
                     and abs((gerimo[i]["date"] - r["date"]).days) <= tolerance_jours]
        if candidats:
            i = min(candidats, key=lambda k: abs((gerimo[k]["date"] - r["date"]).days))
            libres.remove(i)
            associes.append({"releve": r, "gerimo": gerimo[i]})
        else:
            releve_seul.append(r)
    return {"associes": associes, "releve_seul": releve_seul, "gerimo_seul": [gerimo[i] for i in libres]}


@router.post("/comptabilite/rapprochement")
async def rapprochement(request: Request, compte_id: int, nom: str = "releve.xlsx",
                        utilisateur: Utilisateur = Depends(acces_tresorerie), db: SessionDB = Depends(get_db)):
    contenu = b""
    async for morceau in request.stream():
        contenu += morceau
        if len(contenu) > 10_000_000:
            raise HTTPException(status_code=413, detail="Relevé trop gros (10 Mo maximum).")
    compte = db.get(CompteTresorerie, compte_id)
    if compte is None:
        raise HTTPException(status_code=404, detail="Compte introuvable.")
    releve = lire_releve(Path(nom).name, contenu)
    debut, fin = min(l["date"] for l in releve), max(l["date"] for l in releve)
    gerimo = [l for l in tresorerie.mouvements(db, fin=fin + timedelta(days=5), debut=debut - timedelta(days=5))
              if l["compte_id"] == compte.id]
    r = rapprocher(releve, gerimo)
    # mouvements Gérimo hors des dates du relevé : pas comptés comme « absents du relevé »
    r["gerimo_seul"] = [g for g in r["gerimo_seul"] if debut <= g["date"] <= fin]
    propre = lambda g: {k: g[k] for k in ("date", "libelle", "sens", "montant", "reference")}  # noqa: E731
    return _j({"compte": compte.nom, "debut": debut, "fin": fin, "nb_releve": len(releve),
               "associes": [{"releve": a["releve"], "gerimo": propre(a["gerimo"])} for a in r["associes"]],
               "releve_seul": r["releve_seul"], "gerimo_seul": [propre(g) for g in r["gerimo_seul"]]})
