"""Fiches de détail de l'immobilier (13/11/2026, demande de Boss) : un clic sur un locataire, un contrat, un bien ou
un propriétaire ouvre une fenêtre claire, avec l'essentiel en évidence (état en couleur, chiffres clés).

Les droits sont ceux des listes : Gestionnaire limité à ses biens et sans commission, propriétaires pour l'Admin,
derniers paiements seulement pour les profils qui ont les Finances.
"""
from datetime import date
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session as SessionDB, selectinload

import paiements
from commun import charger, montant, voit_finances
from contrats import acces_contrats, acces_locataires, charger_contrat, contrat_json, locataire_visible
from biens import acces_biens, acces_proprietaires
from models import (STATUTS_EN_COURS, Cite, Contrat, Echeance, Locataire, Logement, Paiement, PieceJointe,
                    Proprietaire, Utilisateur)
from securite import cites_autorisees, get_db, peut_acceder, verifier_cite_autorisee

router = APIRouter(prefix="/api/fiches")
ZERO = Decimal(0)


def etat_contrat(c: Contrat, aujourdhui: date) -> dict:
    """L'état le plus important d'un contrat, avec sa couleur : termine, a_risque, retard, depart, a_jour."""
    if c.statut_contrat not in STATUTS_EN_COURS:
        return {"code": "termine", "texte": c.statut_contrat, "impayes": None}
    impayes = paiements.resume_impayes(c, aujourdhui)
    if impayes and impayes["a_risque"]:
        return {"code": "a_risque", "texte": f"À risque — {impayes['nb_mois']} mois impayés", "impayes": impayes}
    if impayes:
        return {"code": "retard", "texte": f"En retard — {impayes['nb_mois']} mois", "impayes": impayes}
    if c.date_depart:
        return {"code": "depart", "texte": f"Départ prévu le {c.date_depart:%d/%m/%Y}", "impayes": None}
    return {"code": "a_jour", "texte": "À jour", "impayes": None}


def _impayes_json(i: dict | None) -> dict | None:
    if not i:
        return None
    return {k: v for k, v in i.items() if k != "derniere_limite"}


def prochaine_echeance(c: Contrat, aujourdhui: date) -> dict | None:
    """Le prochain loyer pas encore en retard (les mois futurs ne sont pas encore créés en base)."""
    if c.statut_contrat not in STATUTS_EN_COURS:
        return None
    for mois, reste in paiements.prochains_mois(c, 24):
        limite = paiements.date_limite(mois, c.terme_loyer)
        if limite >= aujourdhui:
            return {"mois": paiements.libelle_mois(mois), "date_limite": limite.isoformat(), "montant": montant(reste)}
    return None


def derniers_paiements(db: SessionDB, contrat_ids: list[int], nombre: int = 6) -> list[dict]:
    if not contrat_ids:
        return []
    lignes = (db.query(Paiement).options(selectinload(Paiement.contrat).selectinload(Contrat.logement))
              .filter(Paiement.contrat_id.in_(contrat_ids))
              .order_by(Paiement.date_paiement.desc(), Paiement.id.desc()).limit(nombre))
    return [{"id": p.id, "numero_recu": p.numero_recu, "date": p.date_paiement.isoformat(), "montant": montant(p.montant),
             "mode": p.mode_paiement, "statut": p.statut_paiement, "motif": p.motif_paiement,
             "periode": paiements.libelle_periode(p.periode_debut, p.periode_fin),
             "logement": f"Logement {p.contrat.logement.numero_logement}"} for p in lignes]


def _charger_contrats(db: SessionDB, ids: list[int]) -> list[Contrat]:
    contrats = (db.query(Contrat).options(selectinload(Contrat.echeances).selectinload(Echeance.paiement),
                                          selectinload(Contrat.locataire),
                                          selectinload(Contrat.logement).selectinload(Logement.cite))
                .filter(Contrat.id.in_(ids)).all()) if ids else []
    paiements.recalculer_tout(db, contrats)   # retards et « à risque » à jour
    return contrats


def _resume_contrat(c: Contrat, aujourdhui: date) -> dict:
    e = etat_contrat(c, aujourdhui)
    return {"id": c.id, "numero_contrat": c.numero_contrat, "statut_contrat": c.statut_contrat,
            "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}", "cite_id": c.logement.cite_id,
            "montant_loyer": montant(c.montant_loyer), "date_debut": c.date_debut.isoformat(),
            "etat": e["code"], "etat_texte": e["texte"], "impayes": _impayes_json(e["impayes"]),
            "prochaine_echeance": prochaine_echeance(c, aujourdhui)}


# ---------- Contrat ----------

@router.get("/contrat/{contrat_id}")
def fiche_contrat(contrat_id: int, u: Utilisateur = Depends(acces_contrats), db: SessionDB = Depends(get_db)):
    charger_contrat(db, u, contrat_id)   # 404 hors de ses biens
    c = _charger_contrats(db, [contrat_id])[0]
    aujourdhui = date.today()
    r = {**contrat_json(c), **_resume_contrat(c, aujourdhui)}
    r["logement"] = contrat_json(c)["logement"]
    r["voit_paiements"] = peut_acceder(u.role.value, "paiements")
    r["paiements"] = derniers_paiements(db, [c.id]) if r["voit_paiements"] else []
    r["nb_mois_payes"] = sum(1 for e in c.echeances if e.paiement is not None)
    return r


# ---------- Locataire ----------

@router.get("/locataire/{locataire_id}")
def fiche_locataire(locataire_id: int, u: Utilisateur = Depends(acces_locataires), db: SessionDB = Depends(get_db)):
    l = charger(db, Locataire, locataire_id, "Locataire introuvable.")
    if not locataire_visible(u, l):
        raise HTTPException(status_code=404, detail="Locataire introuvable.")
    autorisees = cites_autorisees(u)
    ids = [c.id for c in l.contrats if autorisees is None or c.logement.cite_id in autorisees]
    aujourdhui = date.today()
    contrats = sorted(_charger_contrats(db, ids), key=lambda c: (c.statut_contrat not in STATUTS_EN_COURS, c.date_debut),
                      reverse=False)
    resumes = [_resume_contrat(c, aujourdhui) for c in contrats]
    du = sum((Decimal(str(x["impayes"]["montant"])) for x in resumes if x["impayes"]), ZERO)
    gravite = ["a_risque", "retard", "depart", "a_jour", "termine"]
    en_cours = [x for x in resumes if x["etat"] != "termine"]
    etat = min((x["etat"] for x in en_cours), key=gravite.index) if en_cours else "termine"
    voit_paiements = peut_acceder(u.role.value, "paiements")
    nb_pieces = db.query(func.count(PieceJointe.id)).filter(PieceJointe.locataire_id == l.id).scalar()
    return {"id": l.id, "nom_complet": l.nom_complet, "telephone": l.telephone or "", "cni": l.cni or "",
            "email": l.email or "", "profession": l.profession or "", "nb_pieces": nb_pieces,
            "client_depuis": min(c.date_debut for c in contrats).isoformat() if contrats else None,
            "etat": etat, "total_du": montant(du), "contrats": resumes,
            "loyer_mensuel": montant(sum((c.montant_loyer for c in contrats if c.statut_contrat in STATUTS_EN_COURS), ZERO)),
            "voit_paiements": voit_paiements, "paiements": derniers_paiements(db, ids) if voit_paiements else []}


# ---------- Bien (cité, immeuble…) ----------

@router.get("/bien/{cite_id}")
def fiche_bien(cite_id: int, u: Utilisateur = Depends(acces_biens), db: SessionDB = Depends(get_db)):
    try:
        verifier_cite_autorisee(u, cite_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Bien introuvable.")
    cite = db.query(Cite).options(selectinload(Cite.logements).selectinload(Logement.contrats),
                                  selectinload(Cite.parcelles), selectinload(Cite.proprietaire),
                                  selectinload(Cite.mandats), selectinload(Cite.gestionnaires)).get(cite_id)
    if cite is None:
        raise HTTPException(status_code=404, detail="Bien introuvable.")
    aujourdhui = date.today()
    ids = [c.id for l in cite.logements for c in l.contrats if c.statut_contrat in STATUTS_EN_COURS]
    actifs = {c.logement_id: c for c in _charger_contrats(db, ids)}
    logements, attendu, du = [], ZERO, ZERO
    for l in cite.logements:
        c = actifs.get(l.id)
        ligne = {"id": l.id, "numero": l.numero_logement, "type": l.type_logement, "loyer": montant(l.loyer),
                 "statut": l.statut_logement, "locataire": None}
        if c:
            r = _resume_contrat(c, aujourdhui)
            attendu += c.montant_loyer
            if r["impayes"]:
                du += Decimal(str(r["impayes"]["montant"]))
            ligne.update(locataire={"id": c.locataire.id, "nom_complet": c.locataire.nom_complet,
                                    "telephone": c.locataire.telephone or ""},
                         contrat_id=c.id, etat=r["etat"], etat_texte=r["etat_texte"], loyer=montant(c.montant_loyer))
        logements.append(ligne)
    occupes = sum(1 for l in cite.logements if l.statut_logement == "Occupé")
    r = {"id": cite.id, "nom": cite.nom, "adresse": cite.adresse or "", "description": cite.description or "",
         "nb_logements": len(cite.logements), "occupes": occupes,
         "libres": sum(1 for l in cite.logements if l.statut_logement == "Libre"),
         "taux_occupation": round(occupes * 100 / len(cite.logements)) if cite.logements else 0,
         "loyers_attendus": montant(attendu), "impayes": montant(du), "logements": logements,
         "parcelles": [{"id": p.id, "numero": p.numero_parcelle, "superficie": montant(p.superficie),
                        "disponible": p.disponible, "approbation": p.approbation} for p in cite.parcelles]}
    if u.role.value == "Admin":
        mandat = cite.mandat_actuel
        r.update(proprietaire={"id": cite.proprietaire.id, "nom_complet": cite.proprietaire.nom_complet,
                               "telephone": cite.proprietaire.telephone or ""} if cite.proprietaire else None,
                 pourcentage_commission=montant(mandat.pourcentage_commission) if mandat else None,
                 gestionnaires=[g.nom_complet for g in cite.gestionnaires])
    return r


# ---------- Propriétaire (Admin) ----------

@router.get("/proprietaire/{proprietaire_id}")
def fiche_proprietaire(proprietaire_id: int, u: Utilisateur = Depends(acces_proprietaires),
                       db: SessionDB = Depends(get_db)):
    p = db.query(Proprietaire).options(selectinload(Proprietaire.cites).selectinload(Cite.logements)
                                       .selectinload(Logement.contrats),
                                       selectinload(Proprietaire.cites).selectinload(Cite.parcelles),
                                       selectinload(Proprietaire.cites).selectinload(Cite.mandats)).get(proprietaire_id)
    if p is None:
        raise HTTPException(status_code=404, detail="Propriétaire introuvable.")
    aujourdhui = date.today()
    ids = [c.id for cite in p.cites for l in cite.logements for c in l.contrats if c.statut_contrat in STATUTS_EN_COURS]
    contrats = {c.id: c for c in _charger_contrats(db, ids)}
    biens, total_attendu, total_du, total_logements, total_occupes = [], ZERO, ZERO, 0, 0
    for cite in p.cites:
        attendu = du = ZERO
        en_retard = 0
        for l in cite.logements:
            for c in l.contrats:
                if c.id in contrats:
                    attendu += c.montant_loyer
                    imp = paiements.resume_impayes(contrats[c.id], aujourdhui)
                    if imp:
                        du += Decimal(str(imp["montant"]))
                        en_retard += 1
        occupes = sum(1 for l in cite.logements if l.statut_logement == "Occupé")
        mandat = cite.mandat_actuel
        biens.append({"id": cite.id, "nom": cite.nom, "adresse": cite.adresse or "", "nb_logements": len(cite.logements),
                      "occupes": occupes, "nb_parcelles": len(cite.parcelles), "loyers_attendus": montant(attendu),
                      "impayes": montant(du), "locataires_en_retard": en_retard,
                      "pourcentage_commission": montant(mandat.pourcentage_commission) if mandat else None})
        total_attendu += attendu
        total_du += du
        total_logements += len(cite.logements)
        total_occupes += occupes
    nb_pieces = db.query(func.count(PieceJointe.id)).filter(PieceJointe.proprietaire_id == p.id).scalar()
    return {"id": p.id, "nom_complet": p.nom_complet, "telephone": p.telephone or "", "cni": p.cni or "",
            "email": p.email or "", "ville": p.ville or "", "nb_pieces": nb_pieces, "biens": biens,
            "nb_logements": total_logements, "occupes": total_occupes, "loyers_attendus": montant(total_attendu),
            "impayes": montant(total_du), "voit_finances": voit_finances(u)}
