"""Licence de Gérimo : une clé par client, liée au(x) PC serveur(s), signée par l'éditeur (13/10/2026, demande de Boss).

But : qu'on ne puisse pas copier Gérimo Serveur sur un autre PC et s'en servir sans payer.
- Chaque PC a un « code PC » (tiré de l'identifiant que Windows donne au PC à son installation) : le client l'envoie
  à l'éditeur (bouton WhatsApp dans Paramètres → À propos).
- L'éditeur fabrique la clé avec licence.bat (sa clé privée, cle_editeur/) : nom du client, code(s) PC, date de fin
  (ou sans fin). Une clé n'est valable que sur les PC qu'elle nomme, et ne peut être ni modifiée ni inventée
  (signature Ed25519, editeur.py).
- Sans clé : 30 jours d'essai complets. Ensuite (ou clé expirée, ou PC qui n'est pas dans la clé) : LECTURE SEULE.
  Les données restent consultables, imprimables et sauvegardables (jamais prises en otage) ; seules les nouvelles
  saisies sont refusées (402), jusqu'à l'activation d'une clé.
- PC de secours qui a pris le relais : toléré 30 jours avec la clé du PC principal (une panne n'arrête pas le bureau).
- Seul le programme installé (Gérimo Serveur.exe) est contrôlé : le dossier de développement ne l'est pas.
Limite (dite à Boss) : le logiciel est en Python, un informaticien qui modifie le code peut retirer ce contrôle ;
la licence arrête la copie ordinaire du programme sur un autre PC.
"""
import base64
import hashlib
import json
import os
import sys
from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session as SessionDB

import editeur
from models import Parametre, Utilisateur
from securite import exiger_admin, get_db, utilisateur_connecte

router = APIRouter(prefix="/api")

PREFIXE = "GERIMO1"
JOURS_ESSAI = 30
JOURS_RELAIS = 30
CLE_PARAM, ESSAI_PARAM = "licence_cle", "licence_essai_debut"
WHATSAPP_EDITEUR = "2250749622566"   # pour envoyer son code PC à l'éditeur
# Contrôle actif dans le programme installé ; les tests l'activent à la main
ACTIVE = getattr(sys, "frozen", False) or os.getenv("GERIMO_LICENCE") == "1"
# Toujours permis, même en lecture seule : se connecter, se reconnecter après la veille, changer son mot de passe,
# activer une licence, sauvegarder (les données ne sont jamais prises en otage)
PERMIS = ("/api/connexion", "/api/deconnexion", "/api/veille", "/api/activite", "/api/licence", "/api/sauvegarde",
          "/api/mot-de-passe-oublie", "/api/secours/", "/api/version/", "/api/suivi/")


def saisie_bloquee(methode: str, chemin: str) -> bool:
    """Requête refusée en lecture seule ? (les lectures, et ce qui est toujours permis, passent)"""
    return (methode in ("POST", "PUT", "PATCH", "DELETE") and chemin.startswith("/api/")
            and not chemin.startswith(PERMIS) and not chemin.endswith("/mot-de-passe"))


# Abonnement impayé (26/10/2026, contrat type de Boss) : le travail n'est jamais bloqué d'un coup.
#   - fin de la licence + 5 jours (le 05 du mois impayé) : rappel dans les notifications, tout fonctionne ;
#   - fin + 16 jours (après le 15) : fonctions réduites (liste ci-dessous) ; consulter, encaisser, reçus, quittances,
#     dépenses et sauvegardes restent possibles ;
#   - un mois après le premier jour impayé : lecture seule.
JOURS_AVANT_RAPPEL = 5
JOURS_AVANT_REDUCTION = 16
REDUITES_SAISIE = ("/api/cites", "/api/logements", "/api/parcelles", "/api/proprietaires", "/api/contrats",
                   "/api/locataires", "/api/courriers/revision", "/api/courriers/avenant")
REDUITES_TOUT = ("/api/whatsapp", "/api/statistiques", "/api/rapports", "/api/export/",
                 "/api/comptabilite/export-syscohada")
FONCTIONS_REDUITES = ("nouveaux biens, propriétaires, locataires et contrats, messages WhatsApp, "
                      "rapports, statistiques et exports Excel")


def fonction_reduite(methode: str, chemin: str) -> bool:
    """Requête refusée quand les fonctions sont réduites (abonnement impayé après le 15) ?"""
    if chemin.startswith(REDUITES_TOUT) or (chemin.startswith("/api/") and chemin.endswith("/whatsapp")):
        return True
    return methode in ("POST", "PUT", "PATCH", "DELETE") and chemin.startswith(REDUITES_SAISIE)


def ajouter_mois(jour: date, mois: int) -> date:
    """31/01 + 1 mois = 28 (ou 29)/02."""
    import calendar
    annee, m = divmod(jour.month - 1 + mois, 12)
    annee += jour.year
    return date(annee, m + 1, min(jour.day, calendar.monthrange(annee, m + 1)[1]))


def _retard(fin: date, aujourdhui: date, client: str) -> dict | None:
    """Abonnement échu depuis moins d'un mois : {"statut": "retard"|"reduite", ...} ; plus d'un mois : None."""
    premier_impaye = fin + timedelta(days=1)
    reduite_le = fin + timedelta(days=JOURS_AVANT_REDUCTION)
    lecture_le = ajouter_mois(premier_impaye, 1)
    if aujourdhui >= lecture_le:
        return None
    jj = lambda d: d.strftime("%d/%m/%Y")  # noqa: E731
    commun = {"jours_retard": (aujourdhui - fin).days, "reduite_le": jj(reduite_le), "lecture_seule_le": jj(lecture_le)}
    if aujourdhui >= reduite_le:
        return {**commun, "statut": "reduite", "jours_restants": (lecture_le - aujourdhui).days,
                "message": f"Abonnement de {client} impayé depuis le {jj(premier_impaye)} : certaines fonctions sont "
                           f"réduites ({FONCTIONS_REDUITES}). Consulter, encaisser et imprimer les reçus restent "
                           f"possibles. Sans règlement, Gérimo passera en lecture seule le {jj(lecture_le)}. "
                           "Tout revient dès l'activation de la nouvelle clé reçue après paiement."}
    return {**commun, "statut": "retard", "jours_restants": (reduite_le - aujourdhui).days,
            "message": f"Abonnement de {client} à régler (impayé depuis le {jj(premier_impaye)}). Tout fonctionne "
                       f"encore ; sans règlement, certaines fonctions seront réduites à partir du {jj(reduite_le)}."}


# ---------- Code PC ----------

def _identifiant_windows() -> str:
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                            winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
            return str(winreg.QueryValueEx(k, "MachineGuid")[0])
    except (OSError, ImportError):
        import socket
        import uuid
        return f"{socket.gethostname()}-{uuid.getnode()}"


def code_pc(identifiant: str | None = None) -> str:
    """« K7QF-2MZA-9XPL » : court, à dicter ou envoyer par WhatsApp ; le même tant que Windows n'est pas réinstallé."""
    brut = hashlib.sha256(("gerimo/pc/" + (identifiant or _identifiant_windows())).encode()).digest()
    texte = base64.b32encode(brut).decode()[:12]
    return "-".join(texte[i:i + 4] for i in range(0, 12, 4))


# ---------- Clé ----------

def lire_cle(cle: str) -> dict:
    """Contenu d'une clé dont la signature de l'éditeur est valable ; ValueError sinon."""
    morceaux = "".join(cle.split()).split(".")
    if len(morceaux) != 3 or morceaux[0] != PREFIXE:
        raise ValueError("Ce texte n'est pas une clé de licence Gérimo (elle commence par GERIMO1.).")
    try:
        contenu = json.loads(base64.urlsafe_b64decode(morceaux[1] + "=" * (-len(morceaux[1]) % 4)))
        signature = base64.b64encode(base64.urlsafe_b64decode(morceaux[2] + "=" * (-len(morceaux[2]) % 4))).decode()
    except ValueError:
        raise ValueError("Clé de licence abîmée : recopiez-la en entier.") from None
    try:
        editeur.verifier(editeur.USAGE_LICENCE, contenu, signature)
    except editeur.SignatureInvalide:
        raise ValueError("Clé de licence refusée : elle n'a pas été faite par l'éditeur de Gérimo, ou a été modifiée.") from None
    return contenu


def fabriquer_cle(contenu: dict, signature_b64: str) -> str:
    """(Outil de l'éditeur) Assemble la clé à partir du contenu et de sa signature."""
    def b64(octets: bytes) -> str:
        return base64.urlsafe_b64encode(octets).decode().rstrip("=")
    texte = json.dumps(contenu, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"{PREFIXE}.{b64(texte)}.{b64(base64.b64decode(signature_b64))}"


# ---------- État ----------

def _lire(db: SessionDB, cle: str) -> str:
    p = db.get(Parametre, cle)
    return (p.valeur or "") if p else ""


def _ecrire(db: SessionDB, cle: str, valeur: str) -> None:
    p = db.get(Parametre, cle)
    if p is None:
        db.add(Parametre(cle=cle, valeur=valeur, modifie_le=datetime.now()))
    else:
        p.valeur, p.modifie_le = valeur, datetime.now()


def _debut_essai_registre() -> date | None:
    """Début de l'essai aussi gardé dans Windows : effacer la base ne redonne pas 30 jours."""
    try:
        import winreg
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Gerimo") as k:
            try:
                return date.fromisoformat(winreg.QueryValueEx(k, "essai")[0])
            except (OSError, ValueError):
                return None
    except (OSError, ImportError):
        return None


def _noter_essai_registre(debut: date) -> None:
    try:
        import winreg
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Gerimo") as k:
            winreg.SetValueEx(k, "essai", 0, winreg.REG_SZ, debut.isoformat())
    except (OSError, ImportError):
        pass


def debut_essai(db: SessionDB, aujourdhui: date | None = None) -> date:
    aujourdhui = aujourdhui or date.today()
    candidats = [aujourdhui]
    try:
        candidats.append(date.fromisoformat(_lire(db, ESSAI_PARAM)))
    except ValueError:
        pass
    if ACTIVE:
        registre = _debut_essai_registre()
        if registre:
            candidats.append(registre)
    debut = min(candidats)
    if _lire(db, ESSAI_PARAM) != debut.isoformat():
        _ecrire(db, ESSAI_PARAM, debut.isoformat())
        db.commit()
    if ACTIVE:
        _noter_essai_registre(debut)
    return debut


def _relais_depuis() -> datetime | None:
    try:
        import secours
        if secours.role() in ("relais", "rendu"):
            return datetime.fromisoformat(secours.config().get("relais_depuis", ""))
    except (ImportError, ValueError):
        pass
    return None


def etat(db: SessionDB, aujourdhui: date | None = None, code: str | None = None) -> dict:
    """{"statut": "active"|"essai"|"relais"|"lecture_seule", "message", "client", "fin", "jours_restants", "code_pc"}"""
    aujourdhui = aujourdhui or date.today()
    code = code or code_pc()
    base = {"code_pc": code, "controle": ACTIVE, "whatsapp_editeur": WHATSAPP_EDITEUR}
    cle = _lire(db, CLE_PARAM)
    probleme = ""
    if cle:
        try:
            contenu = lire_cle(cle)
            fin = date.fromisoformat(contenu["expire"]) if contenu.get("expire") else None
            infos = {"client": contenu.get("client", ""), "numero": contenu.get("numero", ""),
                     "fin": fin.strftime("%d/%m/%Y") if fin else None}
            if code not in contenu.get("machines", []):
                probleme = f"la licence de « {infos['client']} » n'est pas valable sur ce PC (code {code})"
            elif fin and fin < aujourdhui and contenu.get("fin_contrat"):
                # contrat résilié : ni rappel ni fonctions réduites, lecture seule pour toujours (données jamais perdues)
                probleme = f"le contrat de « {infos['client']} » est terminé depuis le {infos['fin']}"
            elif fin and fin < aujourdhui:
                retard = _retard(fin, aujourdhui, infos["client"])
                if retard:
                    return {**base, **infos, **retard}
                probleme = (f"l'abonnement de « {infos['client']} » est impayé depuis plus d'un mois "
                            f"(licence terminée le {infos['fin']})")
            else:
                restants = (fin - aujourdhui).days if fin else None
                return {**base, **infos, "statut": "active", "jours_restants": restants,
                        "message": f"Licence accordée à {infos['client']}" + (
                            f" jusqu'au {infos['fin']}, date de fin du contrat : Gérimo passera ensuite en lecture seule."
                            if fin and contenu.get("fin_contrat")
                            else f", jusqu'au {infos['fin']}." if fin else ", sans limite de durée.")}
        except ValueError as e:
            probleme = str(e)
    relais = _relais_depuis()
    if probleme and relais and datetime.now() - relais < timedelta(days=JOURS_RELAIS):
        return {**base, "statut": "relais", "jours_restants": JOURS_RELAIS - (datetime.now() - relais).days,
                "message": "PC de secours en relais : la licence du PC principal est acceptée pendant 30 jours."}
    if not cle:
        debut = debut_essai(db, aujourdhui)
        restants = JOURS_ESSAI - (aujourdhui - debut).days
        if restants > 0:
            return {**base, "statut": "essai", "jours_restants": restants,
                    "message": f"Version d'essai : encore {restants} jour{'s' if restants > 1 else ''}."}
        probleme = f"la période d'essai de {JOURS_ESSAI} jours est terminée"
    return {**base, "statut": "lecture_seule", "jours_restants": 0,
            "message": f"Gérimo est en lecture seule : {probleme}. Les données restent consultables et sauvegardables ; "
                       "pour saisir de nouveau, l'Admin active une licence (Paramètres → À propos)."}


_cache = {"quand": datetime.min, "etat": None}


def _etat_en_cache() -> dict | None:
    """État de la licence du programme installé (None au développement), relu chaque minute."""
    if not ACTIVE:
        return None
    if datetime.now() - _cache["quand"] > timedelta(minutes=1):
        from database import SessionLocal
        try:
            with SessionLocal() as db:
                _cache["etat"] = etat(db)
        except Exception:  # noqa: BLE001 — base pas prête : on ne bloque pas
            _cache["etat"] = None
        _cache["quand"] = datetime.now()
    return _cache["etat"]


def lecture_seule() -> str | None:
    """Message si les saisies sont bloquées (contrôle du programme installé seulement), sinon None."""
    e = _etat_en_cache()
    return e["message"] if e and e["statut"] == "lecture_seule" else None


def fonctions_reduites() -> str | None:
    """Message si les fonctions sont réduites (abonnement impayé après le 15), sinon None."""
    e = _etat_en_cache()
    return e["message"] if e and e["statut"] == "reduite" else None


def oublier_cache() -> None:
    _cache["quand"] = datetime.min
    import metiers
    metiers.oublier_cache()


# ---------- Abonnement mensuel : clé débloquée en ligne après « Paiement reçu » ----------
# Le maintenancier prépare à l'avance les clés du client (signées sur son PC) ; quand un paiement est confirmé
# dans Gérimo Maintenance, la clé du mois est débloquée dans le registre en ligne. Gérimo la récupère tout seul
# (toutes les 30 minutes avec le suivi, ou par « Vérifier mon abonnement ») et signale qu'elle est installée.
RENOUVELEE_PARAM = "licence_renouvelee"


def _rpc(fonction: str, corps: dict, timeout: int = 20):
    import urllib.request
    import suivi
    adresse, cle = suivi.reglage()
    requete = urllib.request.Request(f"{adresse}/rest/v1/rpc/{fonction}", method="POST",
                                     data=json.dumps(corps).encode("utf-8"),
                                     headers={"apikey": cle, "Content-Type": "application/json",
                                              "User-Agent": "Gerimo-licence"})
    if cle.startswith("eyJ"):  # ancienne clé « anon » (JWT) : aussi en Authorization
        requete.add_header("Authorization", f"Bearer {cle}")
    with urllib.request.urlopen(requete, timeout=timeout) as reponse:
        return json.loads(reponse.read(200_000) or b"null")


def seuls_metiers_changent(avant: dict, apres: dict) -> bool:
    """Deux clés identiques (même numéro, client, PC, fin…) sauf la liste des métiers (et la date d'émission)."""
    import metiers
    reste = lambda c: {k: v for k, v in c.items() if k not in ("metiers", "emise")}  # noqa: E731
    return reste(avant) == reste(apres) and metiers.metiers_de_la_cle(avant) != metiers.metiers_de_la_cle(apres)


def installer_cle_en_ligne(db: SessionDB, code: str | None = None) -> dict:
    """Installe la clé débloquée la plus récente si elle prolonge la licence actuelle.
    {"installee": bool, "message": str, "fin": "jj/mm/aaaa" | None}"""
    code = code or code_pc()
    try:
        lignes = _rpc("cles_pour_pc", {"p_code": code}) or []
    except Exception:  # noqa: BLE001 — pas d'Internet, registre absent : on réessaiera
        return {"installee": False, "fin": None,
                "message": "Le registre en ligne ne répond pas (Internet coupé ?). Gérimo réessaiera tout seul."}
    fin_actuelle = None
    try:
        actuelle = lire_cle(_lire(db, CLE_PARAM)) if _lire(db, CLE_PARAM) else None
    except ValueError:
        actuelle = None
    if actuelle and code in actuelle.get("machines", []):
        if not actuelle.get("expire"):
            return {"installee": False, "fin": None, "message": "Licence sans limite de durée : rien à renouveler."}
        fin_actuelle = date.fromisoformat(actuelle["expire"])
    meilleure = None
    for ligne in lignes:
        try:
            contenu = lire_cle(ligne.get("cle", ""))
        except ValueError:
            continue
        if code not in contenu.get("machines", []) or not contenu.get("expire"):
            continue
        fin = date.fromisoformat(contenu["expire"])
        if meilleure is None or fin > meilleure[1]:
            meilleure = (ligne["cle"], fin, contenu)
    installee = False
    # même mois, clé re-signée par l'éditeur où SEULS les métiers ont changé (Gérimo Maintenance → Métiers du client)
    memes_mois_metiers_changes = bool(meilleure and actuelle and fin_actuelle and meilleure[1] == fin_actuelle
                                      and seuls_metiers_changent(actuelle, meilleure[2]))
    if meilleure and (fin_actuelle is None or meilleure[1] > fin_actuelle or memes_mois_metiers_changes):
        fin_actuelle = meilleure[1]
        _ecrire(db, CLE_PARAM, meilleure[0])
        if not memes_mois_metiers_changes:  # pas de « Paiement reçu, merci » pour un simple changement de métiers
            _ecrire(db, RENOUVELEE_PARAM, json.dumps({"fin": fin_actuelle.isoformat(), "le": datetime.now().isoformat()}))
        db.commit()
        oublier_cache()
        installee = True
    if lignes and fin_actuelle:
        try:  # le maintenancier voit « installée chez le client »
            _rpc("cle_installee", {"p_code": code, "p_fin": fin_actuelle.isoformat()})
        except Exception:  # noqa: BLE001
            pass
    fin_txt = fin_actuelle.strftime("%d/%m/%Y") if fin_actuelle else None
    if installee and memes_mois_metiers_changes:
        message = "Nouvelle clé installée : les métiers de votre licence ont été mis à jour."
    elif installee:
        message = f"Paiement reçu, merci ! Abonnement prolongé jusqu'au {fin_txt}."
    elif fin_actuelle:
        message = f"Aucun nouveau paiement confirmé pour l'instant. Abonnement réglé jusqu'au {fin_txt}."
    else:
        message = "Aucun paiement confirmé pour ce PC pour l'instant."
    return {"installee": installee, "fin": fin_txt, "message": message}


def renouvellement_recent(db: SessionDB, jours: int = 3) -> dict | None:
    """{"fin": "jj/mm/aaaa"} si une clé a été installée toute seule ces derniers jours (message de remerciement)."""
    try:
        d = json.loads(_lire(db, RENOUVELEE_PARAM) or "null")
        if d and datetime.now() - datetime.fromisoformat(d["le"]) < timedelta(days=jours):
            return {"fin": date.fromisoformat(d["fin"]).strftime("%d/%m/%Y")}
    except (ValueError, KeyError, TypeError):
        pass
    return None


# ---------- API ----------

@router.get("/licence")
def voir(utilisateur: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    e = etat(db)
    if utilisateur.role.value != "Admin":  # les autres voient seulement s'il faut s'inquiéter
        return {k: e.get(k) for k in ("statut", "message", "jours_restants")}
    import metiers
    return {**e, "metiers": metiers.resume()}


class ActivationIn(BaseModel):
    cle: str = Field(min_length=10, max_length=4000)


@router.post("/licence")
def activer(d: ActivationIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    try:
        contenu = lire_cle(d.cle)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    code = code_pc()
    if code not in contenu.get("machines", []) and _relais_depuis() is None:
        raise HTTPException(status_code=400, detail=f"Cette clé est faite pour un autre PC. Le code de ce PC est {code} : "
                                                    "envoyez-le à l'éditeur pour recevoir la bonne clé.")
    _ecrire(db, CLE_PARAM, "".join(d.cle.split()))
    db.commit()
    oublier_cache()
    return etat(db)


@router.post("/licence/verifier")
def verifier_abonnement(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    """« Vérifier mon abonnement » : va chercher tout de suite la clé débloquée après un paiement."""
    return {**etat(db), "resultat": installer_cle_en_ligne(db)}
