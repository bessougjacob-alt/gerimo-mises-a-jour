"""Commerce, partie 2 (13/11/2026) : arrivages de marchandises, stock, et ce que la boutique doit à ses fournisseurs.

Décisions de Boss (13/11/2026) :
- Le magasinier (Gestionnaire) reçoit les marchandises : il saisit le fournisseur, les articles, les quantités (à la
  pièce ou par lot : carton, sac…) et les dates limites. Le stock augmente tout de suite. Il ne voit et ne saisit
  aucun prix : l'arrivage est « prix à compléter ».
- La Caisse ou l'Admin complète les prix (montant de la facture) et note ce qui a été payé ; le reste est « ce que je
  dois au fournisseur », payable plus tard en un ou plusieurs versements (sorties d'argent de la trésorerie).
- Prix d'achat de l'article (pour le bénéfice) : coût moyen entre le stock déjà là et ce qui arrive.
- Annulation d'un arrivage : Admin seulement, mot de passe redemandé, et seulement si rien n'en a encore été vendu ou
  sorti, et aucun paiement au fournisseur. Suppression d'un paiement au fournisseur : Admin ou Caisse, avec son
  mot de passe (comme les dépenses).
- Période clôturée par l'Admin : rien ne s'ajoute ni ne se modifie avant la date de clôture (periode.py).
"""
from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from sqlalchemy import func
from sqlalchemy.orm import Session as SessionDB, selectinload

import periode
import tresorerie
from commerce import acces, voit_achats
from commun import Formulaire, Suppression, Texte, Paragraphe, charger, enregistrer, montant, numero_suivant
from models import (MODES_PAIEMENT, Arrivage, Article, Fournisseur, LigneArrivage, MouvementStock, UniteArticle,
                    Utilisateur, VersementFournisseur)
from securite import confirmer_mot_de_passe_admin, exiger_admin, get_db, verifier_mot_de_passe

router = APIRouter(prefix="/api")
ZERO = Decimal(0)
ROLES_ARRIVAGE = ("Admin", "Gestionnaire", "Caisse")
ROLES_ARGENT = ("Admin", "Caisse")   # prix des arrivages et paiements aux fournisseurs


# ---------- Stock ----------

def stocks(db: SessionDB) -> dict[int, Decimal]:
    """Stock de chaque article, en plus petite unité vendue."""
    return {a: q for a, q in db.query(MouvementStock.article_id, func.sum(MouvementStock.quantite_base))
            .group_by(MouvementStock.article_id)}


def stock_de(db: SessionDB, article_id: int) -> Decimal:
    return db.query(func.coalesce(func.sum(MouvementStock.quantite_base), 0)).filter(
        MouvementStock.article_id == article_id).scalar() or ZERO


def prendre_dans_les_arrivages(db: SessionDB, article_id: int, quantite_base: Decimal) -> None:
    """Une vente ou une sortie prend d'abord dans l'arrivage le plus ancien (date limite la plus proche d'abord) :
    ce qui reste de chaque arrivage sert aux alertes de date limite."""
    reste = quantite_base
    lignes = (db.query(LigneArrivage).join(Arrivage).filter(
        LigneArrivage.article_id == article_id, LigneArrivage.reste_base > 0, Arrivage.annule.is_(False))
        .order_by(LigneArrivage.date_limite.asc().nullslast(), Arrivage.date_arrivage, LigneArrivage.id)
        .with_for_update(of=LigneArrivage))
    for ligne in lignes:
        if reste <= 0:
            break
        pris = min(ligne.reste_base, reste)
        ligne.reste_base -= pris
        reste -= pris


def resume_stock(article: Article, quantite: Decimal) -> str:
    """« 3 Cartons + 5 Canettes » (du plus grand lot au plus petit)."""
    if quantite <= 0:
        return f"{montant(quantite)} {article.unite_base}"
    morceaux, reste = [], quantite
    for u in sorted(article.unites, key=lambda x: x.contenance, reverse=True):
        if u.contenance > 1 and reste >= u.contenance:
            n = int(reste // u.contenance)
            morceaux.append(f"{n} {u.nom}")
            reste -= n * u.contenance
    if reste or not morceaux:
        morceaux.append(f"{montant(reste)} {article.unite_base}")
    return " + ".join(morceaux)


# ---------- Arrivages ----------

class LigneIn(Formulaire):
    article_id: int
    unite_id: int | None = None          # vide = plus petite unité vendue
    quantite: Decimal = Field(gt=0, max_digits=12, decimal_places=3)
    date_limite: date | None = None
    prix_unitaire: Decimal | None = Field(None, ge=0, max_digits=12, decimal_places=2)   # prix d'un lot


class PaiementIn(Formulaire):
    montant: Decimal = Field(gt=0, max_digits=14, decimal_places=2)
    mode_paiement: Literal[MODES_PAIEMENT] = "Espèce"
    compte_id: int | None = None
    date_versement: date | None = None
    note: Texte | None = Field(None, max_length=200)


class ArrivageIn(Formulaire):
    fournisseur_id: int | None = None
    date_arrivage: date
    reference_facture: Texte | None = Field(None, max_length=60)
    note: Paragraphe | None = Field(None, max_length=2000)
    lignes: list[LigneIn] = Field(min_length=1, max_length=200)
    paiement: PaiementIn | None = None   # payé tout de suite (Admin, Caisse)


class PrixIn(Formulaire):
    prix: dict[int, Decimal]             # id de ligne → prix d'un lot
    reference_facture: Texte | None = Field(None, max_length=60)
    paiement: PaiementIn | None = None


def paye(a: Arrivage) -> Decimal:
    return sum((v.montant for v in a.versements), ZERO)


def arrivage_json(a: Arrivage, u: Utilisateur) -> dict:
    argent = voit_achats(u)
    lignes = []
    for l in a.lignes:
        ligne = {"id": l.id, "article_id": l.article_id, "article": l.article.nom, "unite": l.unite_nom,
                 "unite_base": l.article.unite_base, "quantite": montant(l.quantite), "contenance": montant(l.contenance),
                 "quantite_base": montant(l.quantite_base), "reste_base": montant(l.reste_base),
                 "date_limite": l.date_limite.isoformat() if l.date_limite else None}
        if argent:
            ligne["prix_unitaire"] = montant(l.prix_unitaire) if l.prix_unitaire is not None else None
        lignes.append(ligne)
    r = {"id": a.id, "numero": a.numero, "fournisseur_id": a.fournisseur_id,
         "fournisseur": a.fournisseur.nom if a.fournisseur else "Sans fournisseur",
         "date_arrivage": a.date_arrivage.isoformat(), "reference_facture": a.reference_facture or "",
         "note": a.note or "", "prix_complets": a.prix_complets, "annule": a.annule,
         "motif_annulation": a.motif_annulation or "", "saisi_par": a.auteur.nom_complet if a.auteur else "",
         "lignes": lignes}
    if argent:
        deja = paye(a)
        r.update(montant_total=montant(a.montant_total), paye=montant(deja),
                 reste=montant(a.montant_total - deja) if a.prix_complets and not a.annule else 0,
                 versements=[{"id": v.id, "date": v.date_versement.isoformat(), "montant": montant(v.montant),
                              "mode_paiement": v.mode_paiement, "note": v.note or "",
                              "saisi_par": v.auteur.nom_complet if v.auteur else ""} for v in a.versements])
    return r


def _requete(db: SessionDB):
    return db.query(Arrivage).options(
        selectinload(Arrivage.lignes).selectinload(LigneArrivage.article), selectinload(Arrivage.fournisseur),
        selectinload(Arrivage.auteur), selectinload(Arrivage.versements).selectinload(VersementFournisseur.auteur))


@router.get("/arrivages")
def liste(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    arrivages = _requete(db).order_by(Arrivage.date_arrivage.desc(), Arrivage.id.desc()).limit(300)
    return [arrivage_json(a, u) for a in arrivages]


def _verifier_role(u: Utilisateur, roles: tuple, message: str) -> None:
    if u.role.value not in roles:
        raise HTTPException(status_code=403, detail=message)


def _ajouter_versement(db: SessionDB, u: Utilisateur, a: Arrivage, p: PaiementIn) -> None:
    jour = p.date_versement or date.today()
    if jour > date.today():
        raise HTTPException(status_code=400, detail="La date du paiement ne peut pas être dans le futur.")
    if jour < a.date_arrivage:
        raise HTTPException(status_code=400, detail="Le paiement ne peut pas être avant l'arrivage.")
    periode.verifier_ouverte(db, jour)
    reste = a.montant_total - paye(a)
    if p.montant > reste:
        raise HTTPException(status_code=400, detail=f"Le paiement dépasse ce qui reste à payer pour cet arrivage "
                                                    f"({montant(reste):,} F).".replace(",", " "))
    v = VersementFournisseur(arrivage=a, date_versement=jour, montant=p.montant, mode_paiement=p.mode_paiement,
                             compte_id=tresorerie.verifier_compte_choisi(db, p.compte_id, p.mode_paiement),
                             note=p.note or None, saisi_par=u.id)
    db.add(v)


def _completer_prix(db: SessionDB, u: Utilisateur, a: Arrivage, prix: dict[int, Decimal]) -> None:
    """Prix de chaque ligne → total de l'arrivage, et prix d'achat moyen des articles."""
    for l in a.lignes:
        if l.id not in prix or prix[l.id] is None:
            raise HTTPException(status_code=400, detail=f"Indiquez le prix de « {l.article.nom} ».")
        if prix[l.id] < 0:
            raise HTTPException(status_code=400, detail="Un prix ne peut pas être négatif.")
    db.flush()
    stock = stocks(db)
    for l in a.lignes:
        nouveau = Decimal(prix[l.id])
        prix_base = nouveau / l.contenance
        article = l.article
        # coût moyen : le stock déjà là (à l'ancien prix) + ce qui reste de cet arrivage (au nouveau prix)
        autres = max(stock.get(article.id, ZERO) - l.reste_base, ZERO)
        if article.prix_achat and autres > 0 and (autres + l.reste_base) > 0:
            moyen = (autres * article.prix_achat + l.reste_base * prix_base) / (autres + l.reste_base)
        else:
            moyen = prix_base
        article.prix_achat = moyen.quantize(Decimal("0.01"))
        l.prix_unitaire = nouveau
    a.montant_total = sum((l.prix_unitaire * l.quantite for l in a.lignes), ZERO).quantize(Decimal("0.01"))
    a.prix_complets, a.prix_par, a.prix_le = True, u.id, datetime.now()


@router.post("/arrivages")
def creer(d: ArrivageIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _verifier_role(u, ROLES_ARRIVAGE, "Les arrivages sont saisis par l'Admin, le Gestionnaire ou la Caisse.")
    if d.date_arrivage > date.today():
        raise HTTPException(status_code=400, detail="La date de l'arrivage ne peut pas être dans le futur.")
    periode.verifier_ouverte(db, d.date_arrivage)
    if d.fournisseur_id is not None:
        charger(db, Fournisseur, d.fournisseur_id, "Fournisseur introuvable.")
    argent = voit_achats(u)
    a = Arrivage(numero=numero_suivant(db, Arrivage.numero, f"ARR-{d.date_arrivage.year}", 4),
                 fournisseur_id=d.fournisseur_id, date_arrivage=d.date_arrivage,
                 reference_facture=d.reference_facture or None, note=d.note or None, saisi_par=u.id)
    db.add(a)
    prix = {}
    for i, x in enumerate(d.lignes):
        article = charger(db, Article, x.article_id, "Article introuvable.")
        unite = None
        if x.unite_id is not None:
            unite = db.get(UniteArticle, x.unite_id)
            if unite is None or unite.article_id != article.id:
                raise HTTPException(status_code=400, detail=f"Lot inconnu pour « {article.nom} ».")
        if article.suit_peremption and x.date_limite is None:
            raise HTTPException(status_code=400, detail=f"« {article.nom} » se périme : indiquez sa date limite.")
        if x.date_limite and x.date_limite < d.date_arrivage:
            raise HTTPException(status_code=400, detail=f"« {article.nom} » : la date limite est déjà passée.")
        contenance = unite.contenance if unite else Decimal(1)
        base = (x.quantite * contenance).quantize(Decimal("0.001"))
        ligne = LigneArrivage(article=article, unite_id=unite.id if unite else None,
                              unite_nom=unite.nom if unite else article.unite_base, quantite=x.quantite,
                              contenance=contenance, quantite_base=base, date_limite=x.date_limite, reste_base=base)
        a.lignes.append(ligne)
        prix[i] = x.prix_unitaire
    db.flush()  # numéros des lignes, pour les relier à leur mouvement de stock
    for ligne in a.lignes:
        db.add(MouvementStock(article_id=ligne.article_id, date_mouvement=d.date_arrivage,
                              quantite_base=ligne.quantite_base, genre="Arrivage", ligne_arrivage_id=ligne.id,
                              motif=f"Arrivage {a.numero}", saisi_par=u.id))
    # Admin ou Caisse qui donnent tous les prix : arrivage complet tout de suite (et paiement éventuel)
    if argent and all(p is not None for p in prix.values()):
        _completer_prix(db, u, a, {ligne.id: prix[i] for i, ligne in enumerate(a.lignes)})
        if d.paiement:
            _ajouter_versement(db, u, a, d.paiement)
    elif d.paiement:
        raise HTTPException(status_code=400, detail="Indiquez d'abord tous les prix pour enregistrer un paiement.")
    enregistrer(db, "Enregistrement impossible.")
    return {"id": a.id, "numero": a.numero}


@router.post("/arrivages/{arrivage_id}/prix")
def completer(arrivage_id: int, d: PrixIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _verifier_role(u, ROLES_ARGENT, "Les prix d'achat sont complétés par la Caisse ou l'Admin.")
    a = charger(db, Arrivage, arrivage_id, "Arrivage introuvable.")
    if a.annule:
        raise HTTPException(status_code=409, detail="Cet arrivage est annulé.")
    periode.verifier_ouverte(db, a.date_arrivage)
    if d.reference_facture is not None:
        a.reference_facture = d.reference_facture or None
    _completer_prix(db, u, a, d.prix)
    if a.montant_total < paye(a):
        raise HTTPException(status_code=400, detail="Le nouveau total est plus petit que ce qui a déjà été payé.")
    if d.paiement:
        _ajouter_versement(db, u, a, d.paiement)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": a.id}


class AnnulationIn(Suppression):
    motif: Texte = Field(min_length=3, max_length=300)


@router.post("/arrivages/{arrivage_id}/annuler")
def annuler(arrivage_id: int, d: AnnulationIn, admin: Utilisateur = Depends(exiger_admin),
            db: SessionDB = Depends(get_db)):
    acces(admin)
    confirmer_mot_de_passe_admin(admin, d.mot_de_passe_admin)
    a = charger(db, Arrivage, arrivage_id, "Arrivage introuvable.")
    if a.annule:
        raise HTTPException(status_code=409, detail="Cet arrivage est déjà annulé.")
    periode.verifier_ouverte(db, a.date_arrivage)
    if a.versements:
        raise HTTPException(status_code=409, detail="Un paiement au fournisseur est enregistré pour cet arrivage : "
                                                    "supprimez-le d'abord.")
    if any(l.reste_base < l.quantite_base for l in a.lignes):
        raise HTTPException(status_code=409, detail="Une partie de cet arrivage a déjà été vendue ou sortie du stock : "
                                                    "il ne peut plus être annulé (faites plutôt une sortie de stock).")
    for l in a.lignes:
        db.add(MouvementStock(article_id=l.article_id, date_mouvement=date.today(), quantite_base=-l.quantite_base,
                              genre="Annulation", ligne_arrivage_id=l.id, motif=f"Annulation {a.numero} : {d.motif}"[:200],
                              saisi_par=admin.id))
        l.reste_base = ZERO
    a.annule, a.motif_annulation = True, d.motif
    enregistrer(db, "Annulation impossible.")
    return {"ok": True}


# ---------- Paiements aux fournisseurs ----------

@router.post("/arrivages/{arrivage_id}/versements")
def payer(arrivage_id: int, d: PaiementIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _verifier_role(u, ROLES_ARGENT, "Les paiements aux fournisseurs sont enregistrés par la Caisse ou l'Admin.")
    a = charger(db, Arrivage, arrivage_id, "Arrivage introuvable.")
    if a.annule:
        raise HTTPException(status_code=409, detail="Cet arrivage est annulé.")
    if not a.prix_complets:
        raise HTTPException(status_code=409, detail="Complétez d'abord les prix de cet arrivage.")
    _ajouter_versement(db, u, a, d)
    enregistrer(db, "Enregistrement impossible.")
    return {"ok": True}


@router.post("/versements-fournisseurs/{versement_id}/supprimer")
def supprimer_versement(versement_id: int, d: Suppression, u: Utilisateur = Depends(acces),
                        db: SessionDB = Depends(get_db)):
    _verifier_role(u, ROLES_ARGENT, "Suppression réservée à l'Admin et à la Caisse.")
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", u.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été supprimé.")
    v = charger(db, VersementFournisseur, versement_id, "Paiement introuvable.")
    periode.verifier_ouverte(db, v.date_versement)
    db.delete(v)
    enregistrer(db, "Suppression impossible.")
    return {"ok": True}


@router.get("/fournisseurs/a-payer")
def a_payer(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    """« Ce que je dois aux fournisseurs » : par fournisseur, les arrivages pas encore payés en entier."""
    _verifier_role(u, ROLES_ARGENT, "Réservé à l'Admin et à la Caisse.")
    par_fournisseur = defaultdict(lambda: {"total": ZERO, "arrivages": []})
    a_completer = 0
    for a in _requete(db).filter(Arrivage.annule.is_(False)).order_by(Arrivage.date_arrivage):
        if not a.prix_complets:
            a_completer += 1
            continue
        reste = a.montant_total - paye(a)
        if reste > 0:
            f = par_fournisseur[a.fournisseur.nom if a.fournisseur else "Sans fournisseur"]
            f["total"] += reste
            f["arrivages"].append({"id": a.id, "numero": a.numero, "date": a.date_arrivage.isoformat(),
                                   "total": montant(a.montant_total), "reste": montant(reste)})
    fournisseurs = [{"fournisseur": nom, "total": montant(v["total"]), "arrivages": v["arrivages"]}
                    for nom, v in sorted(par_fournisseur.items(), key=lambda x: -x[1]["total"])]
    return {"total": montant(sum((Decimal(str(f["total"])) for f in fournisseurs), ZERO)),
            "fournisseurs": fournisseurs, "prix_a_completer": a_completer}


def versements(db: SessionDB, debut: date | None = None, fin: date | None = None):
    """Paiements aux fournisseurs de la période (trésorerie, comptabilité)."""
    q = db.query(VersementFournisseur).options(selectinload(VersementFournisseur.arrivage)
                                               .selectinload(Arrivage.fournisseur))
    if debut is not None:
        q = q.filter(VersementFournisseur.date_versement >= debut)
    if fin is not None:
        q = q.filter(VersementFournisseur.date_versement <= fin)
    return q.order_by(VersementFournisseur.date_versement, VersementFournisseur.id).all()


def arrivages_completes(db: SessionDB, debut: date, fin: date):
    """Arrivages aux prix complétés de la période (comptabilité : achats de marchandises)."""
    return (db.query(Arrivage).options(selectinload(Arrivage.fournisseur))
            .filter(Arrivage.prix_complets.is_(True), Arrivage.annule.is_(False),
                    Arrivage.date_arrivage >= debut, Arrivage.date_arrivage <= fin)
            .order_by(Arrivage.date_arrivage, Arrivage.id).all())


# ---------- Fiche d'un article (fenêtre de détail) ----------

JOURS_DATE_LIMITE = 30   # « date limite proche » : dans les 30 jours


def dates_limites(db: SessionDB) -> dict[int, date]:
    """Pour chaque article : la date limite la plus proche parmi ce qui reste en stock."""
    return {a: d for a, d in db.query(LigneArrivage.article_id, func.min(LigneArrivage.date_limite)).join(Arrivage)
            .filter(LigneArrivage.reste_base > 0, LigneArrivage.date_limite.isnot(None), Arrivage.annule.is_(False))
            .group_by(LigneArrivage.article_id)}


@router.get("/articles/{article_id}/fiche")
def fiche_article(article_id: int, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    from commerce import article_json
    a = db.query(Article).options(selectinload(Article.unites), selectinload(Article.fournisseur)).get(article_id)
    if a is None:
        raise HTTPException(status_code=404, detail="Article introuvable.")
    stock = stock_de(db, a.id)
    lots = (db.query(LigneArrivage).join(Arrivage).options(selectinload(LigneArrivage.arrivage))
            .filter(LigneArrivage.article_id == a.id, LigneArrivage.reste_base > 0, Arrivage.annule.is_(False))
            .order_by(LigneArrivage.date_limite.asc().nullslast(), Arrivage.date_arrivage).all())
    mouvements = (db.query(MouvementStock).filter(MouvementStock.article_id == a.id)
                  .order_by(MouvementStock.date_mouvement.desc(), MouvementStock.id.desc()).limit(15).all())
    r = article_json(a, u, stock)
    r["lots"] = [{"numero": l.arrivage.numero, "date_arrivage": l.arrivage.date_arrivage.isoformat(),
                  "reste": montant(l.reste_base), "reste_texte": resume_stock(a, l.reste_base),
                  "date_limite": l.date_limite.isoformat() if l.date_limite else None,
                  "jours": (l.date_limite - date.today()).days if l.date_limite else None} for l in lots]
    r["mouvements"] = [{"date": m.date_mouvement.isoformat(), "genre": m.genre, "quantite": montant(m.quantite_base),
                        "motif": m.motif or ""} for m in mouvements]
    if voit_achats(u):
        r["valeur_stock"] = montant((max(stock, ZERO) * a.prix_achat).quantize(Decimal("1")))
    return r
