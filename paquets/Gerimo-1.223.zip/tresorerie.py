"""Précomptabilité, partie 1 : la trésorerie (où est l'argent, combien, et d'où il vient).

- Comptes d'argent en nombre libre : caisses, comptes bancaires, comptes Mobile Money (Wave, Orange…).
  Chaque mode de paiement peut être rangé d'office dans un compte (ex : Espèce → Caisse principale).
- Les entrées et sorties ne sont PAS ressaisies : elles viennent des encaissements, des dépenses et des
  achats/ventes déjà enregistrés, plus les transferts entre comptes saisis ici.
- Arrêté de caisse : l'argent réellement compté est comparé au solde calculé ; l'écart est conservé.

Droits (vérifiés ici) : Admin, Caisse et Comptable consultent, saisissent les transferts et les arrêtés ;
seul l'Admin crée ou modifie les comptes et supprime (mot de passe redemandé).
"""
from collections import defaultdict
from datetime import date
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import Field
from sqlalchemy.orm import Session as SessionDB, selectinload

import periode
from commun import Formulaire, Suppression, Texte, charger, enregistrer, montant, numero_suivant, supprimer
from models import (MODES_PAIEMENT, TYPES_COMPTE, AchatVente, ArreteCaisse, CompteTresorerie, Contrat, Depense,
                    Paiement, Reversement, TransfertTresorerie, Utilisateur)
from securite import (confirmer_mot_de_passe_admin, exiger_admin, exiger_module, get_db, utilisateur_connecte)

router = APIRouter(prefix="/api")
acces = exiger_module("tresorerie")
ZERO = Decimal(0)
PREFIXE_REPRISE = "REP-"  # paiements repris d'un ancien fichier : déjà comptés dans le solde de départ

# Billets et pièces en francs CFA (arrêté de caisse détaillé)
COUPURES = (10000, 5000, 2000, 1000, 500, 250, 200, 100, 50, 25, 10, 5)


# ---------- Rangement des opérations dans les comptes ----------

class Rangement:
    """Trouve le compte d'une opération : celui choisi à la saisie, sinon celui de son mode de paiement."""

    def __init__(self, db: SessionDB):
        self.comptes = {c.id: c for c in db.query(CompteTresorerie).order_by(CompteTresorerie.id)}
        self.par_mode = {}
        for c in self.comptes.values():
            if c.actif:
                for mode in c.modes_paiement or []:
                    self.par_mode.setdefault(mode, c.id)

    def compte(self, compte_id: int | None, mode: str | None) -> int | None:
        if compte_id in self.comptes:
            return compte_id
        return self.par_mode.get(mode)


def compte_par_defaut(db: SessionDB, mode: str) -> int | None:
    return Rangement(db).compte(None, mode)


def verifier_compte_choisi(db: SessionDB, compte_id: int | None, mode: str) -> int | None:
    """Saisie d'un encaissement, d'une dépense ou d'un achat/vente : compte choisi (actif), ou celui du mode."""
    if compte_id is None:
        return compte_par_defaut(db, mode)
    compte = db.get(CompteTresorerie, compte_id)
    if compte is None or not compte.actif:
        raise HTTPException(status_code=400, detail="Compte de trésorerie introuvable ou fermé.")
    return compte.id


def _ligne(jour, sens, valeur, libelle, origine, reference, compte_id, tri) -> dict:
    return {"date": jour, "sens": sens, "montant": Decimal(valeur), "libelle": libelle, "origine": origine,
            "reference": reference or "", "compte_id": compte_id, "tri": tri}


def mouvements(db: SessionDB, fin: date | None = None, debut: date | None = None) -> list[dict]:
    """Toutes les entrées et sorties d'argent (du plus ancien au plus récent).

    compte_id vaut None quand l'opération n'est rangée dans aucun compte (mode sans compte associé)."""
    r = Rangement(db)
    lignes = []

    def periode(requete, colonne):
        if debut is not None:
            requete = requete.filter(colonne >= debut)
        if fin is not None:
            requete = requete.filter(colonne <= fin)
        return requete

    paiements = periode(db.query(Paiement).options(selectinload(Paiement.contrat).selectinload(Contrat.locataire))
                        .filter(Paiement.statut_paiement == "Payé"), Paiement.date_paiement)
    for p in paiements:
        if (p.numero_recu or "").startswith(PREFIXE_REPRISE):
            continue
        locataire = p.contrat.locataire.nom_complet if p.contrat and p.contrat.locataire else ""
        lignes.append(_ligne(p.date_paiement, "entree", p.montant, f"Encaissement — {locataire} ({p.motif_paiement})",
                             "Encaissement", p.numero_recu, r.compte(p.compte_id, p.mode_paiement), (p.cree_le, "p", p.id)))

    import sejours  # séjours en courte durée (acomptes, soldes)
    for v in sejours.versements(db, debut, fin):
        lignes.append(_ligne(v.date_paiement, "entree", v.montant, f"Séjour — {v.reservation.client_nom} "
                             f"({v.reservation.numero})", "Séjour", v.numero_recu,
                             r.compte(v.compte_id, v.mode_paiement), (v.cree_le, "s", v.id)))

    for d in periode(db.query(Depense).options(selectinload(Depense.cite)), Depense.date_depense):
        lieu = d.cite.nom if d.cite else "fonctionnement"
        lignes.append(_ligne(d.date_depense, "sortie", d.montant, f"Dépense — {d.motif} ({lieu})",
                             "Dépense", d.categorie, r.compte(d.compte_id, d.mode_paiement), (d.cree_le, "d", d.id)))

    for o in periode(db.query(AchatVente), AchatVente.date_operation):
        compte = r.compte(o.compte_id, o.mode_paiement)
        tri = (o.cree_le, "a", o.id)
        if o.type_operation == "Achat":
            lignes.append(_ligne(o.date_operation, "sortie", o.montant, f"Achat — {o.designation or ''}",
                                 "Achat", o.numero, compte, tri))
        elif o.type_operation == "Vente indirecte":
            # le prix transite par l'entreprise ; la commission payée par l'acheteur s'y ajoute.
            # Le versement au propriétaire vendeur n'est PAS déduit ici : il est enregistré le jour où il est
            # réellement fait, depuis le compte utilisé (choix de Boss du 06/10/2026).
            commission = o.commission_montant or ZERO
            recu = o.montant + (commission if o.commission_payee_par == "Acheteur" else ZERO)
            lignes.append(_ligne(o.date_operation, "entree", recu, f"Vente (intermédiaire) — {o.partie_nom}",
                                 "Vente", o.numero, compte, tri))
        else:  # Vente directe (et ancien libellé « Vente »)
            lignes.append(_ligne(o.date_operation, "entree", o.montant, f"Vente — {o.partie_nom}",
                                 "Vente", o.numero, compte, tri))

    for t in periode(db.query(TransfertTresorerie).options(selectinload(TransfertTresorerie.source),
                                                            selectinload(TransfertTresorerie.cible)),
                     TransfertTresorerie.date_transfert):
        texte = t.libelle or f"{t.source.nom} → {t.cible.nom}"
        lignes.append(_ligne(t.date_transfert, "sortie", t.montant, f"Transfert vers {t.cible.nom} — {texte}",
                             "Transfert", t.numero, t.compte_source, (t.cree_le, "t", t.id)))
        lignes.append(_ligne(t.date_transfert, "entree", t.montant, f"Transfert depuis {t.source.nom} — {texte}",
                             "Transfert", t.numero, t.compte_cible, (t.cree_le, "t", t.id)))
        if t.frais:
            lignes.append(_ligne(t.date_transfert, "sortie", t.frais, f"Frais de transfert — {t.numero}",
                                 "Frais", t.numero, t.compte_source, (t.cree_le, "t2", t.id)))

    for v in periode(db.query(Reversement).filter(Reversement.montant > 0), Reversement.date_reversement):
        quoi = {"Loyers": "Reversement des loyers", "Vente": "Versement au vendeur",
                "Caution": "Restitution de caution"}[v.type_reversement]
        lignes.append(_ligne(v.date_reversement, "sortie", v.montant, f"{quoi} — {v.beneficiaire_nom}",
                             "Reversement", v.numero, v.compte_id, (v.cree_le, "r", v.id)))

    import ventes  # Commerce : sommes reçues des clients, remboursements à l'annulation
    for x in ventes.reglements(db, debut, fin):
        client = x.vente.client.nom if x.vente.client else "client de passage"
        lignes.append(_ligne(x.date_reglement, "entree", x.montant, f"Vente — {client} ({x.vente.numero})", "Vente",
                             x.numero, r.compte(x.compte_id, x.mode_paiement), (x.cree_le, "v", x.id)))
    for v in ventes.annulations_du(db, debut, fin):
        if v.rembourse:
            client = v.client.nom if v.client else "client de passage"
            lignes.append(_ligne(v.annule_le, "sortie", v.rembourse, f"Remboursement — vente {v.numero} annulée ({client})",
                                 "Vente", v.numero, r.compte(v.rembourse_compte_id, v.rembourse_mode), (v.cree_le, "va", v.id)))

    import mobile_money  # Agence Mobile Money : argent échangé avec un compte de l'entreprise
    for o in mobile_money.operations_avec_compte(db, debut, fin):
        lignes.append(_ligne(o.date_operation, mobile_money.sens_tresorerie(o), o.montant, mobile_money.libelle_tresorerie(o),
                             "Mobile Money", o.numero, o.compte_id, (o.cree_le, "mm", o.id)))

    import arrivages  # Commerce : paiements aux fournisseurs
    for v in arrivages.versements(db, debut, fin):
        fournisseur = v.arrivage.fournisseur.nom if v.arrivage.fournisseur else "fournisseur"
        lignes.append(_ligne(v.date_versement, "sortie", v.montant, f"Paiement fournisseur — {fournisseur} "
                             f"({v.arrivage.numero})", "Fournisseur", v.arrivage.numero,
                             r.compte(v.compte_id, v.mode_paiement), (v.cree_le, "f", v.id)))

    lignes.sort(key=lambda l: (l["date"], str(l["tri"][0] or ""), l["tri"][1], l["tri"][2]))
    # une opération antérieure à l'ouverture d'un compte n'y compte pas (déjà dans son solde de départ)
    return [l for l in lignes if l["compte_id"] is None or l["date"] >= r.comptes[l["compte_id"]].date_ouverture]


def soldes(db: SessionDB, au: date) -> dict[int, Decimal]:
    """Solde de chaque compte à la fin de la journée « au »."""
    resultat = {c.id: c.solde_initial for c in db.query(CompteTresorerie)}
    for l in mouvements(db, fin=au):
        if l["compte_id"] is not None:
            resultat[l["compte_id"]] += l["montant"] if l["sens"] == "entree" else -l["montant"]
    return resultat


def _signe(l: dict) -> Decimal:
    return l["montant"] if l["sens"] == "entree" else -l["montant"]


# ---------- Comptes ----------

class CompteIn(Formulaire):
    nom: Texte = Field(min_length=2, max_length=80)
    type_compte: Literal[TYPES_COMPTE]
    numero: Texte | None = Field(None, max_length=60)
    modes_paiement: list[Literal[MODES_PAIEMENT]] = []
    solde_initial: Decimal = Field(Decimal(0), max_digits=14, decimal_places=2)
    date_ouverture: date
    actif: bool = True
    compte_comptable: str | None = Field(None, max_length=12)   # export SYSCOHADA (ex : 5211)


def compte_json(c: CompteTresorerie) -> dict:
    return {"id": c.id, "nom": c.nom, "type_compte": c.type_compte, "numero": c.numero or "",
            "modes_paiement": list(c.modes_paiement or []), "solde_initial": montant(c.solde_initial),
            "date_ouverture": c.date_ouverture.isoformat(), "actif": c.actif,
            "compte_comptable": c.compte_comptable or ""}


@router.get("/tresorerie/comptes-actifs")
def comptes_actifs(utilisateur: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    """Pour les formulaires (encaissement, dépense, achat/vente) : comptes ouverts, sans leurs soldes."""
    return [{"id": c.id, "nom": c.nom, "type_compte": c.type_compte, "modes_paiement": list(c.modes_paiement or [])}
            for c in db.query(CompteTresorerie).filter_by(actif=True).order_by(CompteTresorerie.nom)]


def appliquer_compte(db: SessionDB, c: CompteTresorerie, d: CompteIn) -> None:
    if d.date_ouverture > date.today():
        raise HTTPException(status_code=400, detail="La date de début du suivi ne peut pas être dans le futur.")
    if d.solde_initial < 0 and d.type_compte == "Caisse":
        raise HTTPException(status_code=400, detail="Une caisse ne peut pas commencer avec un solde négatif.")
    modes = list(dict.fromkeys(d.modes_paiement))
    if d.actif:
        for autre in db.query(CompteTresorerie).filter(CompteTresorerie.actif.is_(True)):
            if autre.id != c.id:
                commun_ = set(modes) & set(autre.modes_paiement or [])
                if commun_:
                    raise HTTPException(status_code=409, detail=f"« {sorted(commun_)[0]} » est déjà rangé dans le compte "
                                                                f"« {autre.nom} ». Retirez-le d'abord de ce compte.")
    c.nom, c.type_compte, c.numero = d.nom, d.type_compte, d.numero or None
    c.modes_paiement, c.solde_initial, c.date_ouverture, c.actif = modes, d.solde_initial, d.date_ouverture, d.actif
    numero = (d.compte_comptable or "").strip()
    if numero and not (numero.isdigit() and 2 <= len(numero) <= 12 and numero[0] == "5"):
        raise HTTPException(status_code=400, detail="Compte comptable : des chiffres commençant par 5 (classe 5 du "
                                                    "SYSCOHADA, ex : 5711 caisse, 5211 banque, 5521 Mobile Money).")
    c.compte_comptable = numero or None


@router.post("/tresorerie/comptes")
def creer_compte(d: CompteIn, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    c = CompteTresorerie()
    appliquer_compte(db, c, d)
    db.add(c)
    enregistrer(db, "Un compte porte déjà ce nom.")
    return {"id": c.id}


@router.put("/tresorerie/comptes/{compte_id}")
def modifier_compte(compte_id: int, d: CompteIn, admin: Utilisateur = Depends(exiger_admin),
                    db: SessionDB = Depends(get_db)):
    c = charger(db, CompteTresorerie, compte_id, "Compte introuvable.")
    appliquer_compte(db, c, d)
    enregistrer(db, "Un compte porte déjà ce nom.")
    return {"id": c.id}


# ---------- Vue d'ensemble et journal ----------

@router.get("/tresorerie")
def vue_ensemble(utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    aujourdhui = date.today()
    comptes = db.query(CompteTresorerie).order_by(CompteTresorerie.actif.desc(), CompteTresorerie.nom).all()
    solde = {c.id: c.solde_initial for c in comptes}
    jour = defaultdict(lambda: {"entrees": ZERO, "sorties": ZERO})
    non_ranges = {"nombre": 0, "entrees": ZERO, "sorties": ZERO}
    for l in mouvements(db, fin=aujourdhui):
        if l["compte_id"] is None:
            non_ranges["nombre"] += 1
            non_ranges["entrees" if l["sens"] == "entree" else "sorties"] += l["montant"]
            continue
        solde[l["compte_id"]] += _signe(l)
        if l["date"] == aujourdhui:
            jour[l["compte_id"]]["entrees" if l["sens"] == "entree" else "sorties"] += l["montant"]
    derniers = {}
    for a in db.query(ArreteCaisse).order_by(ArreteCaisse.date_arrete):
        derniers[a.compte_id] = a
    # à qui appartient l'argent : propriétaires (reste à verser), cautions (dépôts de garantie), entreprise
    from reversements import situation
    s = situation(db)
    total = sum((solde[c.id] for c in comptes if c.actif), ZERO)
    du = s["du_proprietaires"] + s["du_vendeurs"]
    return {
        "repartition": {"proprietaires": montant(s["du_proprietaires"]), "vendeurs": montant(s["du_vendeurs"]),
                        "cautions": montant(s["cautions"]), "entreprise": montant(total - du - s["cautions"])},
        "date": aujourdhui.isoformat(),
        "comptes": [{**compte_json(c), "solde": montant(solde[c.id]),
                     "entrees_jour": montant(jour[c.id]["entrees"]), "sorties_jour": montant(jour[c.id]["sorties"]),
                     "dernier_arrete": ({"date": derniers[c.id].date_arrete.isoformat(),
                                         "ecart": montant(derniers[c.id].ecart)} if c.id in derniers else None)}
                    for c in comptes],
        "total": montant(sum((solde[c.id] for c in comptes if c.actif), ZERO)),
        "non_ranges": {k: (montant(v) if k != "nombre" else v) for k, v in non_ranges.items()},
        "modes_paiement": MODES_PAIEMENT, "types_compte": TYPES_COMPTE, "coupures": COUPURES,
        "peut_parametrer": utilisateur.role.value == "Admin",
        "agences_mobile_money": _agences_mobile_money(db, utilisateur),
    }


def _agences_mobile_money(db: SessionDB, utilisateur: Utilisateur) -> list[dict]:
    """Argent des kiosques Mobile Money (espèces et puces), si le métier est ouvert."""
    from securite import peut_acceder
    if not peut_acceder(utilisateur.role.value, "mobile_money"):
        return []
    import mobile_money
    return mobile_money.situation_agences(db)


@router.get("/tresorerie/journal")
def journal_tresorerie(debut: date | None = Query(None), fin: date | None = Query(None),
                       compte: str | None = Query(None), utilisateur: Utilisateur = Depends(acces),
                       db: SessionDB = Depends(get_db)):
    """Journal des mouvements d'une période. compte : un id, « tous » ou « non_ranges »."""
    aujourdhui = date.today()
    fin = fin or aujourdhui
    debut = debut or fin.replace(day=1)
    if debut > fin:
        raise HTTPException(status_code=400, detail="La date de début est après la date de fin.")
    comptes = {c.id: c for c in db.query(CompteTresorerie)}
    compte_id = None
    if compte not in (None, "", "tous", "non_ranges"):
        try:
            compte_id = int(compte)
        except ValueError:
            raise HTTPException(status_code=400, detail="Compte invalide.")
        if compte_id not in comptes:
            raise HTTPException(status_code=404, detail="Compte introuvable.")

    def retenue(l):
        if compte == "non_ranges":
            return l["compte_id"] is None
        return compte_id is None or l["compte_id"] == compte_id

    toutes = [l for l in mouvements(db, fin=fin) if retenue(l)]
    # solde de départ : solde initial + tout ce qui précède la période (un seul compte, ou tous les comptes)
    if compte == "non_ranges":
        depart = ZERO
    else:
        depart = sum((c.solde_initial for c in comptes.values() if compte_id in (None, c.id)), ZERO)
    depart += sum((_signe(l) for l in toutes if l["date"] < debut and l["compte_id"] is not None), ZERO)
    courant = depart
    lignes, entrees, sorties = [], ZERO, ZERO
    for l in toutes:
        if l["date"] < debut:
            continue
        # vue « tous les comptes » : un transfert interne entre et sort, il ne change pas le total
        if l["compte_id"] is not None:
            courant += _signe(l)
        if compte_id is None and l["origine"] == "Transfert":
            pass  # vue de tous les comptes : un transfert interne n'est ni une recette ni une dépense
        elif l["sens"] == "entree":
            entrees += l["montant"]
        else:
            sorties += l["montant"]
        lignes.append({"date": l["date"].isoformat(), "sens": l["sens"], "montant": montant(l["montant"]),
                       "libelle": l["libelle"], "origine": l["origine"], "reference": l["reference"],
                       "compte": comptes[l["compte_id"]].nom if l["compte_id"] else "Non rangé",
                       "solde": montant(courant) if compte != "non_ranges" else None})
    return {"debut": debut.isoformat(), "fin": fin.isoformat(), "solde_debut": montant(depart),
            "entrees": montant(entrees), "sorties": montant(sorties),
            "solde_fin": montant(courant) if compte != "non_ranges" else None, "lignes": lignes}


# ---------- Transferts entre comptes ----------

class TransfertIn(Formulaire):
    date_transfert: date
    compte_source: int
    compte_cible: int
    montant: Decimal = Field(gt=0, max_digits=14, decimal_places=2)
    frais: Decimal = Field(Decimal(0), ge=0, max_digits=14, decimal_places=2)
    libelle: Texte | None = Field(None, max_length=200)
    reference: Texte | None = Field(None, max_length=80)


def transfert_json(t: TransfertTresorerie) -> dict:
    return {"id": t.id, "numero": t.numero, "date": t.date_transfert.isoformat(), "source": t.source.nom,
            "cible": t.cible.nom, "montant": montant(t.montant), "frais": montant(t.frais),
            "libelle": t.libelle or "", "reference": t.reference or "",
            "saisi_par": t.auteur.nom_complet if t.auteur else ""}


@router.get("/tresorerie/transferts")
def liste_transferts(utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    transferts = db.query(TransfertTresorerie).options(
        selectinload(TransfertTresorerie.source), selectinload(TransfertTresorerie.cible),
        selectinload(TransfertTresorerie.auteur)
    ).order_by(TransfertTresorerie.date_transfert.desc(), TransfertTresorerie.id.desc()).limit(500)
    return [transfert_json(t) for t in transferts]


@router.post("/tresorerie/transferts")
def creer_transfert(d: TransfertIn, utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    if d.date_transfert > date.today():
        raise HTTPException(status_code=400, detail="La date du transfert ne peut pas être dans le futur.")
    periode.verifier_ouverte(db, d.date_transfert)
    if d.compte_source == d.compte_cible:
        raise HTTPException(status_code=400, detail="Choisissez deux comptes différents.")
    source = charger(db, CompteTresorerie, d.compte_source, "Compte de départ introuvable.")
    cible = charger(db, CompteTresorerie, d.compte_cible, "Compte d'arrivée introuvable.")
    if not (source.actif and cible.actif):
        raise HTTPException(status_code=400, detail="Un des deux comptes est fermé.")
    for c in (source, cible):
        if d.date_transfert < c.date_ouverture:
            raise HTTPException(status_code=400, detail=f"Le suivi du compte « {c.nom} » commence le "
                                                        f"{c.date_ouverture:%d/%m/%Y} : date du transfert trop ancienne.")
    # on ne sort pas d'une caisse plus d'argent qu'elle n'en contient
    if source.type_compte == "Caisse":
        disponible = soldes(db, d.date_transfert)[source.id]
        if d.montant + d.frais > disponible:
            raise HTTPException(status_code=409, detail=f"La caisse « {source.nom} » ne contient que "
                                                        f"{montant(disponible):,} F à cette date.".replace(",", " "))
    t = TransfertTresorerie(date_transfert=d.date_transfert, compte_source=source.id, compte_cible=cible.id,
                            montant=d.montant, frais=d.frais, libelle=d.libelle or None,
                            reference=d.reference or None, saisi_par=utilisateur.id,
                            numero=numero_suivant(db, TransfertTresorerie.numero, f"TRF-{date.today().year}", 4))
    db.add(t)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": t.id, "numero": t.numero}


@router.post("/tresorerie/transferts/{transfert_id}/supprimer")
def supprimer_transfert(transfert_id: int, donnees: Suppression, admin: Utilisateur = Depends(exiger_admin),
                        db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    t = charger(db, TransfertTresorerie, transfert_id, "Transfert introuvable.")
    periode.verifier_ouverte(db, t.date_transfert)
    return supprimer(db, t, "Suppression impossible.")


# ---------- Arrêtés de caisse ----------

class ArreteIn(Formulaire):
    compte_id: int
    date_arrete: date
    solde_compte: Decimal = Field(ge=0, max_digits=14, decimal_places=2)
    billetage: dict[str, int] = {}
    observation: Texte | None = Field(None, max_length=500)


@router.get("/tresorerie/arretes/preparer")
def preparer_arrete(compte_id: int, jour: date | None = Query(None, alias="date"),
                    utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    """Solde calculé d'un compte en fin de journée, et les mouvements de ce jour-là."""
    jour = jour or date.today()
    compte = charger(db, CompteTresorerie, compte_id, "Compte introuvable.")
    du_jour = [l for l in mouvements(db, fin=jour, debut=jour) if l["compte_id"] == compte.id]
    deja = db.query(ArreteCaisse).filter_by(compte_id=compte.id, date_arrete=jour).first()
    return {"compte": compte.nom, "type_compte": compte.type_compte, "date": jour.isoformat(),
            "solde_calcule": montant(soldes(db, jour)[compte.id]), "deja_fait": deja is not None,
            "entrees": montant(sum((l["montant"] for l in du_jour if l["sens"] == "entree"), ZERO)),
            "sorties": montant(sum((l["montant"] for l in du_jour if l["sens"] == "sortie"), ZERO)),
            "mouvements": [{"libelle": l["libelle"], "sens": l["sens"], "montant": montant(l["montant"]),
                            "reference": l["reference"]} for l in du_jour]}


@router.get("/tresorerie/arretes")
def liste_arretes(utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    arretes = db.query(ArreteCaisse).options(selectinload(ArreteCaisse.compte), selectinload(ArreteCaisse.auteur)) \
        .order_by(ArreteCaisse.date_arrete.desc(), ArreteCaisse.id.desc()).limit(300).all()
    # une opération ajoutée, modifiée ou supprimée après l'arrêté change le solde calculé de ce jour : on le signale
    cache = {}
    resultat = []
    for a in arretes:
        if a.date_arrete not in cache:
            cache[a.date_arrete] = soldes(db, a.date_arrete)
        recalcule = cache[a.date_arrete].get(a.compte_id, ZERO)
        resultat.append({"id": a.id, "compte": a.compte.nom, "date": a.date_arrete.isoformat(),
                         "solde_calcule": montant(a.solde_calcule), "solde_compte": montant(a.solde_compte),
                         "ecart": montant(a.ecart), "observation": a.observation or "",
                         "billetage": a.billetage or {}, "saisi_par": a.auteur.nom_complet if a.auteur else "",
                         "modifie_depuis": recalcule != a.solde_calcule, "solde_recalcule": montant(recalcule)})
    return resultat


@router.post("/tresorerie/arretes")
def creer_arrete(d: ArreteIn, utilisateur: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    if d.date_arrete > date.today():
        raise HTTPException(status_code=400, detail="On ne peut pas arrêter une journée qui n'est pas encore passée.")
    compte = charger(db, CompteTresorerie, d.compte_id, "Compte introuvable.")
    periode.verifier_ouverte(db, d.date_arrete)
    if d.date_arrete < compte.date_ouverture:
        raise HTTPException(status_code=400, detail=f"Le suivi de ce compte commence le {compte.date_ouverture:%d/%m/%Y}.")
    billetage = {}
    for coupure, nombre in d.billetage.items():
        if not coupure.isdigit() or int(coupure) not in COUPURES or not 0 <= nombre <= 1_000_000:
            raise HTTPException(status_code=400, detail="Détail des billets et pièces invalide.")
        if nombre:
            billetage[coupure] = nombre
    if billetage and sum(int(k) * v for k, v in billetage.items()) != d.solde_compte:
        raise HTTPException(status_code=400, detail="Le total des billets et pièces ne correspond pas au montant compté.")
    if db.query(ArreteCaisse).filter_by(compte_id=compte.id, date_arrete=d.date_arrete).first():
        raise HTTPException(status_code=409, detail="Cette journée est déjà arrêtée pour ce compte.")
    calcule = soldes(db, d.date_arrete)[compte.id]
    a = ArreteCaisse(compte_id=compte.id, date_arrete=d.date_arrete, solde_calcule=calcule,
                     solde_compte=d.solde_compte, ecart=d.solde_compte - calcule, billetage=billetage,
                     observation=d.observation or None, saisi_par=utilisateur.id)
    db.add(a)
    enregistrer(db, "Cette journée est déjà arrêtée pour ce compte.")
    return {"id": a.id, "solde_calcule": montant(calcule), "ecart": montant(a.ecart)}


@router.post("/tresorerie/arretes/{arrete_id}/supprimer")
def supprimer_arrete(arrete_id: int, donnees: Suppression, admin: Utilisateur = Depends(exiger_admin),
                     db: SessionDB = Depends(get_db)):
    confirmer_mot_de_passe_admin(admin, donnees.mot_de_passe_admin)
    a = charger(db, ArreteCaisse, arrete_id, "Arrêté introuvable.")
    periode.verifier_ouverte(db, a.date_arrete)
    return supprimer(db, a, "Suppression impossible.")
