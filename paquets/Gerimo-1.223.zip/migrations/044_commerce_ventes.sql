-- ============================================================
-- Migration 044 — Commerce, étape 4 (14/11/2026) : ventes au comptoir, clients, paiements des clients (ventes.py)
-- Décisions de Boss (14/11/2026) :
-- - prix détail OU gros pour toute la vente ; remise plafonnée (% fixé par l'Admin), au-delà mot de passe Admin ;
-- - vendeurs : Admin, Caisse et magasinier ; stock à zéro : vente bloquée sauf Admin ;
-- - crédit : client obligatoire, plafond par client, remboursements en plusieurs fois (chacun son reçu) ;
-- - annulation : Admin ou Caisse (mot de passe + motif) : la marchandise revient, l'argent ressort de la caisse.
-- Tables :
-- - clients_commerce : les clients de la boutique (les « clients » de l'agenda sont des prospects de l'immobilier) ;
-- - ventes (n° VTE-AAAA-NNNNN) et lignes_vente (prix et coût au moment de la vente, pour le bénéfice) ;
-- - reglements_ventes (n° RGL-AAAA-NNNNN) : chaque somme reçue d'un client, à la vente ou plus tard.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS clients_commerce (
    id              SERIAL PRIMARY KEY,
    nom             VARCHAR(150) NOT NULL,
    telephone       VARCHAR(30),
    adresse         VARCHAR(200),
    note            TEXT,
    plafond_credit  NUMERIC(14, 2) CHECK (plafond_credit >= 0),   -- vide = pas de plafond
    actif           BOOLEAN NOT NULL DEFAULT TRUE,
    cree_le         TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_clients_commerce_nom ON clients_commerce (lower(nom));

CREATE TABLE IF NOT EXISTS ventes (
    id                     SERIAL PRIMARY KEY,
    numero                 VARCHAR(20) NOT NULL UNIQUE,
    date_vente             DATE NOT NULL,
    client_id              INTEGER REFERENCES clients_commerce(id),
    prix_applique          VARCHAR(6) NOT NULL DEFAULT 'Détail' CHECK (prix_applique IN ('Détail', 'Gros')),
    sous_total             NUMERIC(14, 2) NOT NULL CHECK (sous_total >= 0),
    remise                 NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (remise >= 0),
    total                  NUMERIC(14, 2) NOT NULL CHECK (total >= 0),
    remise_confirmee_par   INTEGER REFERENCES utilisateurs(id),      -- remise au-delà du plafond
    stock_force_par        INTEGER REFERENCES utilisateurs(id),      -- vendu sans stock (Admin)
    statut                 VARCHAR(10) NOT NULL DEFAULT 'Validée' CHECK (statut IN ('Validée', 'Annulée')),
    motif_annulation       TEXT,
    annule_par             INTEGER REFERENCES utilisateurs(id),
    annule_le              DATE,
    rembourse              NUMERIC(14, 2) NOT NULL DEFAULT 0,        -- rendu au client à l'annulation
    rembourse_compte_id    INTEGER REFERENCES comptes_tresorerie(id),
    rembourse_mode         mode_paiement,
    note                   VARCHAR(200),
    vendu_par              INTEGER REFERENCES utilisateurs(id),
    cree_le                TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_ventes_date ON ventes (date_vente);
CREATE INDEX IF NOT EXISTS idx_ventes_client ON ventes (client_id);

CREATE TABLE IF NOT EXISTS lignes_vente (
    id              SERIAL PRIMARY KEY,
    vente_id        INTEGER NOT NULL REFERENCES ventes(id) ON DELETE CASCADE,
    article_id      INTEGER NOT NULL REFERENCES articles(id),
    unite_id        INTEGER REFERENCES unites_articles(id) ON DELETE SET NULL,
    unite_nom       VARCHAR(30) NOT NULL,
    article_nom     VARCHAR(150) NOT NULL,                              -- recopié pour le ticket
    quantite        NUMERIC(12, 3) NOT NULL CHECK (quantite > 0),
    contenance      NUMERIC(12, 3) NOT NULL DEFAULT 1 CHECK (contenance > 0),
    quantite_base   NUMERIC(14, 3) NOT NULL CHECK (quantite_base > 0),
    prix_unitaire   NUMERIC(12, 2) NOT NULL CHECK (prix_unitaire >= 0),
    total           NUMERIC(14, 2) NOT NULL CHECK (total >= 0),
    cout            NUMERIC(14, 2) NOT NULL DEFAULT 0                   -- prix d'achat moyen × quantité
);
CREATE INDEX IF NOT EXISTS idx_lignes_vente_article ON lignes_vente (article_id);

CREATE TABLE IF NOT EXISTS reglements_ventes (
    id              SERIAL PRIMARY KEY,
    numero          VARCHAR(20) NOT NULL UNIQUE,
    vente_id        INTEGER NOT NULL REFERENCES ventes(id),
    date_reglement  DATE NOT NULL,
    montant         NUMERIC(14, 2) NOT NULL CHECK (montant > 0),
    mode_paiement   mode_paiement NOT NULL DEFAULT 'Espèce',
    compte_id       INTEGER REFERENCES comptes_tresorerie(id),
    a_la_vente      BOOLEAN NOT NULL DEFAULT FALSE,
    saisi_par       INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_reglements_ventes_vente ON reglements_ventes (vente_id);

DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['clients_commerce', 'ventes', 'lignes_vente', 'reglements_ventes']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
