-- ============================================================
-- Migration 042 — Commerce, partie 2 (13/11/2026) : arrivages de marchandises, stock, paiements aux fournisseurs
-- (arrivages.py)
-- - arrivages : marchandises reçues d'un fournisseur (n° ARR-AAAA-NNNN). Le magasinier (Gestionnaire) compte et
--   saisit les quantités ; la Caisse ou l'Admin complète ensuite les prix (« prix à compléter ») — choix de Boss.
-- - lignes_arrivage : article, lot choisi (carton… ; vide = plus petite unité), quantité, prix d'un lot, date limite.
--   reste_base = ce qui reste de cet arrivage en stock (les ventes et sorties prennent d'abord le plus ancien) :
--   sert à prévenir avant la date limite.
-- - mouvements_stock : chaque entrée (+) et sortie (−), toujours en plus petite unité vendue ; stock = somme.
-- - versements_fournisseurs : ce qui a été payé au fournisseur pour un arrivage (comptant ou plus tard) ;
--   « ce que je dois » = total des arrivages − versements. Sorties d'argent de la trésorerie.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS arrivages (
    id                 SERIAL PRIMARY KEY,
    numero             VARCHAR(20) NOT NULL UNIQUE,
    fournisseur_id     INTEGER REFERENCES fournisseurs(id),
    date_arrivage      DATE NOT NULL,
    reference_facture  VARCHAR(60),
    note               TEXT,
    prix_complets      BOOLEAN NOT NULL DEFAULT FALSE,
    montant_total      NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (montant_total >= 0),
    annule             BOOLEAN NOT NULL DEFAULT FALSE,
    motif_annulation   TEXT,
    saisi_par          INTEGER REFERENCES utilisateurs(id),
    prix_par           INTEGER REFERENCES utilisateurs(id),
    prix_le            TIMESTAMP,
    cree_le            TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_arrivages_fournisseur ON arrivages (fournisseur_id);

CREATE TABLE IF NOT EXISTS lignes_arrivage (
    id              SERIAL PRIMARY KEY,
    arrivage_id     INTEGER NOT NULL REFERENCES arrivages(id) ON DELETE CASCADE,
    article_id      INTEGER NOT NULL REFERENCES articles(id),
    unite_id        INTEGER REFERENCES unites_articles(id) ON DELETE SET NULL,
    unite_nom       VARCHAR(30) NOT NULL,                                  -- recopié (le lot peut changer ensuite)
    quantite        NUMERIC(12, 3) NOT NULL CHECK (quantite > 0),          -- en lots choisis
    contenance      NUMERIC(12, 3) NOT NULL DEFAULT 1 CHECK (contenance > 0),
    quantite_base   NUMERIC(14, 3) NOT NULL CHECK (quantite_base > 0),     -- quantite × contenance
    prix_unitaire   NUMERIC(12, 2) CHECK (prix_unitaire >= 0),             -- prix d'un lot ; vide = à compléter
    date_limite     DATE,
    reste_base      NUMERIC(14, 3) NOT NULL DEFAULT 0 CHECK (reste_base >= 0)
);
CREATE INDEX IF NOT EXISTS idx_lignes_arrivage_article ON lignes_arrivage (article_id);

CREATE TABLE IF NOT EXISTS mouvements_stock (
    id                 SERIAL PRIMARY KEY,
    article_id         INTEGER NOT NULL REFERENCES articles(id),
    date_mouvement     DATE NOT NULL,
    quantite_base      NUMERIC(14, 3) NOT NULL CHECK (quantite_base <> 0),   -- + entrée, − sortie
    genre              VARCHAR(20) NOT NULL CHECK (genre IN ('Arrivage', 'Annulation', 'Vente', 'Sortie', 'Inventaire')),
    ligne_arrivage_id  INTEGER REFERENCES lignes_arrivage(id) ON DELETE CASCADE,
    motif              VARCHAR(200),
    saisi_par          INTEGER REFERENCES utilisateurs(id),
    cree_le            TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_mouvements_stock_article ON mouvements_stock (article_id);

CREATE TABLE IF NOT EXISTS versements_fournisseurs (
    id              SERIAL PRIMARY KEY,
    arrivage_id     INTEGER NOT NULL REFERENCES arrivages(id),
    date_versement  DATE NOT NULL,
    montant         NUMERIC(14, 2) NOT NULL CHECK (montant > 0),
    mode_paiement   mode_paiement NOT NULL DEFAULT 'Espèce',
    compte_id       INTEGER REFERENCES comptes_tresorerie(id),
    note            VARCHAR(200),
    saisi_par       INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_versements_fournisseurs_arrivage ON versements_fournisseurs (arrivage_id);

DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['arrivages', 'lignes_arrivage', 'mouvements_stock', 'versements_fournisseurs']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
