-- ============================================================
-- Migration 041 — Métier Commerce / boutique, partie 1 (13/11/2026) : articles et fournisseurs (commerce.py)
-- - fournisseurs : à qui la boutique achète ;
-- - articles : unité de base (celle du stock : Pièce, Bouteille, Kg…), prix détail et gros de cette unité,
--   prix d'achat (pour la marge : jamais montré au Gestionnaire), seuil d'alerte, code-barres, péremption suivie ou non ;
-- - unites_articles : autres unités de vente du même article, avec leur contenance en unité de base
--   (Carton = 24 Bouteilles) et leurs propres prix ; le stock se compte toujours en unité de base.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS fournisseurs (
    id          SERIAL PRIMARY KEY,
    nom         VARCHAR(150) NOT NULL,
    telephone   VARCHAR(30),
    contact     VARCHAR(150),            -- personne à joindre chez le fournisseur
    adresse     VARCHAR(200),
    note        TEXT,
    actif       BOOLEAN NOT NULL DEFAULT TRUE,
    cree_le     TIMESTAMP DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS fournisseurs_nom_unique ON fournisseurs (lower(nom));

CREATE TABLE IF NOT EXISTS articles (
    id                SERIAL PRIMARY KEY,
    nom               VARCHAR(150) NOT NULL,
    categorie         VARCHAR(80),
    code_barres       VARCHAR(40),
    unite_base        VARCHAR(30) NOT NULL DEFAULT 'Pièce',
    prix_detail       NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (prix_detail >= 0),
    prix_gros         NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (prix_gros >= 0),
    prix_achat        NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (prix_achat >= 0),  -- par unité de base
    seuil_alerte      NUMERIC(12, 3) NOT NULL DEFAULT 0 CHECK (seuil_alerte >= 0),
    suit_peremption   BOOLEAN NOT NULL DEFAULT FALSE,
    fournisseur_id    INTEGER REFERENCES fournisseurs(id) ON DELETE SET NULL,     -- fournisseur habituel
    actif             BOOLEAN NOT NULL DEFAULT TRUE,
    cree_le           TIMESTAMP DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS articles_nom_unique ON articles (lower(nom));
CREATE UNIQUE INDEX IF NOT EXISTS articles_code_barres_unique ON articles (code_barres) WHERE code_barres IS NOT NULL;

CREATE TABLE IF NOT EXISTS unites_articles (
    id           SERIAL PRIMARY KEY,
    article_id   INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
    nom          VARCHAR(30) NOT NULL,                                 -- Carton, Sac, Paquet…
    contenance   NUMERIC(12, 3) NOT NULL CHECK (contenance > 0),       -- en unité de base (Carton = 24)
    prix_detail  NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (prix_detail >= 0),
    prix_gros    NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (prix_gros >= 0),
    code_barres  VARCHAR(40)
);
CREATE UNIQUE INDEX IF NOT EXISTS unites_articles_nom_unique ON unites_articles (article_id, lower(nom));
CREATE UNIQUE INDEX IF NOT EXISTS unites_articles_code_barres_unique ON unites_articles (code_barres)
    WHERE code_barres IS NOT NULL;

-- « Qui a fait quoi » et corbeille (migration 019)
DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['fournisseurs', 'articles', 'unites_articles']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
