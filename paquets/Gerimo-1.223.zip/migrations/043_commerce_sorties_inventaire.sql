-- ============================================================
-- Migration 043 — Commerce, partie 3 (14/11/2026) : sorties de stock avec motif, inventaire (stock_sorties.py)
-- - mouvements_stock.raison : pourquoi la marchandise est sortie (Casse, Périmé, Vol ou perte, Usage interne,
--   Cadeau ou échantillon, Autre) ; valeur : ce qu'elle avait coûté (prix d'achat moyen × quantité), pour les pertes.
-- - inventaires : comptage du stock réel (n° INV-AAAA-NNNN). Saisi par l'Admin ou le magasinier, validé par l'Admin
--   (décision de Boss du 13/11/2026) : à la validation, l'écart devient un mouvement « Inventaire ».
-- - lignes_inventaire : pour chaque article compté, le stock prévu par Gérimo et le stock compté.
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE mouvements_stock ADD COLUMN IF NOT EXISTS raison VARCHAR(30);
ALTER TABLE mouvements_stock ADD COLUMN IF NOT EXISTS valeur NUMERIC(14, 2);

CREATE TABLE IF NOT EXISTS inventaires (
    id              SERIAL PRIMARY KEY,
    numero          VARCHAR(20) NOT NULL UNIQUE,
    date_inventaire DATE NOT NULL,
    statut          VARCHAR(12) NOT NULL DEFAULT 'À valider' CHECK (statut IN ('À valider', 'Validé', 'Abandonné')),
    note            TEXT,
    saisi_par       INTEGER REFERENCES utilisateurs(id),
    valide_par      INTEGER REFERENCES utilisateurs(id),
    valide_le       TIMESTAMP,
    cree_le         TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS lignes_inventaire (
    id               SERIAL PRIMARY KEY,
    inventaire_id    INTEGER NOT NULL REFERENCES inventaires(id) ON DELETE CASCADE,
    article_id       INTEGER NOT NULL REFERENCES articles(id),
    stock_prevu      NUMERIC(14, 3) NOT NULL,
    stock_compte     NUMERIC(14, 3) NOT NULL CHECK (stock_compte >= 0)
);
CREATE UNIQUE INDEX IF NOT EXISTS lignes_inventaire_unique ON lignes_inventaire (inventaire_id, article_id);

DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['inventaires', 'lignes_inventaire']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
