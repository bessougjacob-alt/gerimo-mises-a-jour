-- ============================================================
-- Migration 046 — Mobile Money relié à la Trésorerie (14/11/2026, demande de Boss)
-- - mm_operations.compte_id : compte de l'entreprise d'où vient (apport d'espèces, rechargement payé par la banque)
--   ou vers lequel part l'argent (sortie d'espèces, retour de e-monnaie payé par virement, commission reçue) ;
-- - nouveau type « Commission reçue » : ce que l'opérateur verse réellement (sur la puce ou sur un compte).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

ALTER TABLE mm_operations ADD COLUMN IF NOT EXISTS compte_id INTEGER REFERENCES comptes_tresorerie(id);
ALTER TABLE mm_operations DROP CONSTRAINT IF EXISTS mm_operations_type_operation_check;
ALTER TABLE mm_operations ADD CONSTRAINT mm_operations_type_operation_check CHECK (type_operation IN
    ('Dépôt', 'Retrait', 'Rechargement de la puce', 'Retour de e-monnaie', 'Apport d''espèces', 'Sortie d''espèces',
     'Commission reçue'));
