-- ============================================================
-- Migration 045 — Métier « Agence Mobile Money » (14/11/2026) : mobile_money.py
-- Décisions de Boss (13/11/2026) : métier à part ; opérateurs Orange Money, MTN MoMo, Moov Money, Wave (+ ajout par
-- l'Admin) ; saisie de CHAQUE opération → solde de chaque puce, espèces en caisse et commissions calculés ;
-- plusieurs kiosques / agents ; clôture de caisse quotidienne avec écart ; approvisionnements ; alertes de solde bas.
-- Choix fait en l'absence de Boss (à valider) : commission = barème par tranches saisi par l'Admin pour chaque
-- opérateur et type d'opération (montant fixe et/ou pourcentage) ; c'est une commission ATTENDUE, à comparer à ce que
-- l'opérateur verse réellement chaque mois.
-- Tables :
-- - mm_operateurs, mm_points (kiosques, avec leurs espèces de départ), mm_agents_points (qui travaille où),
-- - mm_puces (une puce d'agent par opérateur et par kiosque, solde de départ, seuil d'alerte),
-- - mm_baremes (tranches de commission), mm_operations (n° MM-AAAA-NNNNNN), mm_clotures (comptage du soir).
-- Peut être exécutée plusieurs fois sans risque
-- ============================================================
SET client_encoding = 'UTF8';

CREATE TABLE IF NOT EXISTS mm_operateurs (
    id      SERIAL PRIMARY KEY,
    nom     VARCHAR(60) NOT NULL UNIQUE,
    couleur VARCHAR(9) NOT NULL DEFAULT '#1d3b53',
    actif   BOOLEAN NOT NULL DEFAULT TRUE,
    ordre   INTEGER NOT NULL DEFAULT 0
);
INSERT INTO mm_operateurs (nom, couleur, ordre) VALUES
    ('Orange Money', '#ff7900', 1), ('MTN MoMo', '#ffcb05', 2), ('Moov Money', '#0066b3', 3), ('Wave', '#1dc3f0', 4)
ON CONFLICT (nom) DO NOTHING;

CREATE TABLE IF NOT EXISTS mm_points (
    id                      SERIAL PRIMARY KEY,
    nom                     VARCHAR(100) NOT NULL UNIQUE,
    adresse                 VARCHAR(200),
    especes_depart          NUMERIC(14, 2) NOT NULL DEFAULT 0,
    date_depart             DATE NOT NULL DEFAULT CURRENT_DATE,
    seuil_especes           NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (seuil_especes >= 0),
    actif                   BOOLEAN NOT NULL DEFAULT TRUE,
    cree_le                 TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mm_agents_points (
    utilisateur_id  INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
    point_id        INTEGER NOT NULL REFERENCES mm_points(id) ON DELETE CASCADE,
    PRIMARY KEY (utilisateur_id, point_id)
);

CREATE TABLE IF NOT EXISTS mm_puces (
    id              SERIAL PRIMARY KEY,
    point_id        INTEGER NOT NULL REFERENCES mm_points(id) ON DELETE CASCADE,
    operateur_id    INTEGER NOT NULL REFERENCES mm_operateurs(id),
    numero          VARCHAR(30),
    solde_depart    NUMERIC(14, 2) NOT NULL DEFAULT 0,
    seuil_alerte    NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (seuil_alerte >= 0),
    actif           BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (point_id, operateur_id)
);

CREATE TABLE IF NOT EXISTS mm_baremes (
    id                SERIAL PRIMARY KEY,
    operateur_id      INTEGER NOT NULL REFERENCES mm_operateurs(id) ON DELETE CASCADE,
    type_operation    VARCHAR(10) NOT NULL CHECK (type_operation IN ('Dépôt', 'Retrait')),
    montant_min       NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (montant_min >= 0),
    montant_max       NUMERIC(14, 2) CHECK (montant_max >= 0),          -- vide = sans limite
    commission_fixe   NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (commission_fixe >= 0),
    commission_pct    NUMERIC(6, 3) NOT NULL DEFAULT 0 CHECK (commission_pct >= 0 AND commission_pct <= 100)
);
CREATE INDEX IF NOT EXISTS idx_mm_baremes_operateur ON mm_baremes (operateur_id, type_operation);

CREATE TABLE IF NOT EXISTS mm_operations (
    id              SERIAL PRIMARY KEY,
    numero          VARCHAR(20) NOT NULL UNIQUE,
    point_id        INTEGER NOT NULL REFERENCES mm_points(id),
    puce_id         INTEGER REFERENCES mm_puces(id),            -- vide : mouvement d'espèces seulement
    type_operation  VARCHAR(30) NOT NULL CHECK (type_operation IN
                    ('Dépôt', 'Retrait', 'Rechargement de la puce', 'Retour de e-monnaie', 'Apport d''espèces', 'Sortie d''espèces')),
    montant         NUMERIC(14, 2) NOT NULL CHECK (montant > 0),
    paye_en_especes BOOLEAN NOT NULL DEFAULT TRUE,              -- rechargement payé en espèces du kiosque ?
    numero_client   VARCHAR(30),
    reference       VARCHAR(60),
    commission      NUMERIC(12, 2) NOT NULL DEFAULT 0,
    date_operation  DATE NOT NULL,
    note            VARCHAR(200),
    annulee         BOOLEAN NOT NULL DEFAULT FALSE,
    motif_annulation VARCHAR(300),
    annule_par      INTEGER REFERENCES utilisateurs(id),
    saisi_par       INTEGER REFERENCES utilisateurs(id),
    cree_le         TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_mm_operations_point_date ON mm_operations (point_id, date_operation);
CREATE INDEX IF NOT EXISTS idx_mm_operations_puce ON mm_operations (puce_id);

CREATE TABLE IF NOT EXISTS mm_clotures (
    id                  SERIAL PRIMARY KEY,
    point_id            INTEGER NOT NULL REFERENCES mm_points(id),
    date_cloture        DATE NOT NULL,
    especes_calculees   NUMERIC(14, 2) NOT NULL,
    especes_comptees    NUMERIC(14, 2) NOT NULL,
    puces               JSONB NOT NULL DEFAULT '[]',            -- [{puce_id, operateur, calcule, reel}]
    note                VARCHAR(300),
    saisi_par           INTEGER REFERENCES utilisateurs(id),
    cree_le             TIMESTAMP DEFAULT NOW(),
    UNIQUE (point_id, date_cloture)
);

DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY['mm_operateurs', 'mm_points', 'mm_agents_points', 'mm_puces', 'mm_baremes', 'mm_operations', 'mm_clotures']
    LOOP
        EXECUTE format('DROP TRIGGER IF EXISTS journal_actions ON %I', t);
        EXECUTE format('CREATE TRIGGER journal_actions AFTER INSERT OR UPDATE OR DELETE ON %I '
                       'FOR EACH ROW EXECUTE FUNCTION journal_ecrire()', t);
    END LOOP;
END $$;
