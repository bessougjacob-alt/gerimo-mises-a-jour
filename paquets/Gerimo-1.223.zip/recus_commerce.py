"""Documents du Commerce (14/11/2026) : ticket de caisse (80 mm), facture A4, reçu de paiement d'un client.

Décision de Boss (14/11/2026) : ticket par défaut (imprimante ticket 80 mm, ou A4), facture A4 si le client la demande.
L'identité de l'entreprise vient de « Mon entreprise » (recus.ENTETE), jamais écrite en dur. Une vente annulée porte la
mention « ANNULÉE ». Les documents sont fabriqués à la demande (toujours à jour), avec les mêmes polices que les autres.
"""
from decimal import Decimal

from fpdf import FPDF

import recus
from recus import ENCRE, ENTETE, GRIS, MARINE, ORANGE, POLICES, VERT, en_lettres, francs

# Formats de ticket (demande de Boss du 14/11/2026, le plus petit d'abord) : largeur de la page et de la zone imprimée
# (une imprimante « 58 mm » imprime environ 48 mm ; « 80 mm » environ 72 mm). A4 : le ticket centré sur la page.
FORMATS_TICKET = {
    "58": {"libelle": "58 mm (petit rouleau, aussi vendu « 57 mm »)", "page": 58, "zone": 50, "echelle": 0.82, "car": 24},
    "80": {"libelle": "80 mm (rouleau standard)", "page": 80, "zone": 72, "echelle": 1.0, "car": 34},
    "A4": {"libelle": "A4 (imprimante de bureau)", "page": 210, "zone": 90, "echelle": 1.1, "car": 40},
}


def _f(valeur) -> str:
    return f"{Decimal(valeur):,.0f}".replace(",", " ") + " F"


def _qte(valeur) -> str:
    v = Decimal(valeur)
    return f"{v:,.0f}".replace(",", " ") if v == v.to_integral_value() else f"{v:.3f}".rstrip("0").replace(".", ",")


# ---------- Ticket de caisse (58 mm, 80 mm ou A4) ----------

class _Ticket(FPDF):
    def __init__(self, fmt: dict, hauteur: float):
        super().__init__(format=(fmt["page"], 297 if fmt["page"] == 210 else hauteur))
        self.set_auto_page_break(False)
        self.k_ = fmt["echelle"]
        self.zone = fmt["zone"]
        self.x0 = (fmt["page"] - fmt["zone"]) / 2
        self.add_font("Montserrat", "", str(POLICES / "Montserrat-Medium.ttf"))
        self.add_font("Montserrat", "B", str(POLICES / "Montserrat-Bold.ttf"))

    def _police(self, taille, style, couleur):
        self.set_font("Montserrat", style, taille * self.k_)
        self.set_text_color(*couleur)
        return taille * self.k_ * 0.45

    def ligne(self, y, gauche, droite="", taille=7.5, style="", couleur=ENCRE):
        h = self._police(taille, style, couleur)
        self.set_xy(self.x0, y)
        self.cell(self.zone, h, gauche, align="L")
        if droite:
            self.set_xy(self.x0, y)
            self.cell(self.zone, h, droite, align="R")
        return y + h + 1.2

    def centre(self, y, texte, taille=7.5, style="", couleur=ENCRE):
        h = self._police(taille, style, couleur)
        self.set_xy(self.x0, y)
        self.multi_cell(self.zone, h + 0.6, texte, align="C")
        return self.get_y() + 0.6

    def pointilles(self, y):
        self.set_draw_color(*GRIS)
        self.set_line_width(0.15)
        self.set_dash_pattern(dash=0.8, gap=0.8)
        self.line(self.x0, y, self.x0 + self.zone, y)
        self.set_dash_pattern()
        return y + 2


def ticket_pdf(v: dict, format_ticket: str = "58") -> bytes:
    """v : numero, date, heure, client, vendeur, prix_applique, lignes [{article, unite, quantite, prix, total}],
    sous_total, remise, total, recu, reste, rendu, mode, annulee. format_ticket : « 58 », « 80 » ou « A4 »."""
    fmt = FORMATS_TICKET.get(format_ticket, FORMATS_TICKET["58"])
    k = fmt["echelle"]
    hauteur = (74 + 9 * len(v["lignes"]) + (6 if v["remise"] else 0) + (6 if v["reste"] else 0)
               + (8 if v["annulee"] else 0)) * max(k, 0.9)
    pdf = _Ticket(fmt, hauteur)
    pdf.set_title(f"Ticket {v['numero']}")
    pdf.add_page()
    y = pdf.centre(4, ENTETE["nom"] or "Ticket de caisse", taille=11, style="B", couleur=ORANGE)
    for texte in (ENTETE["adresse"], ENTETE["telephones"] or ENTETE["contact"]):
        if texte:
            y = pdf.centre(y, texte, taille=6.5, couleur=GRIS)
    y = pdf.pointilles(y + 1)
    y = pdf.ligne(y, f"Ticket {v['numero']}", style="B")
    y = pdf.ligne(y, f"{v['date']} à {v['heure']}", f"Prix {v['prix_applique'].lower()}", taille=6.5, couleur=GRIS)
    y = pdf.ligne(y, f"Client : {v['client']}"[:fmt["car"] + 10], taille=6.5, couleur=GRIS)
    if v["annulee"]:
        y = pdf.centre(y + 1, "VENTE ANNULÉE", taille=11, style="B", couleur=(176, 57, 44))
    y = pdf.pointilles(y + 1)
    for l in v["lignes"]:
        h = pdf._police(7.5, "B", ENCRE)
        pdf.set_xy(pdf.x0, y)
        nom = l["article"] if len(l["article"]) <= fmt["car"] else l["article"][:fmt["car"] - 1].rstrip() + "…"
        pdf.cell(pdf.zone - 22 * k, h, nom)
        pdf.set_xy(pdf.x0, y)
        pdf.cell(pdf.zone, h, _f(l["total"]), align="R")
        y = pdf.ligne(y + h + 0.6, f"  {_qte(l['quantite'])} {l['unite']} × {_f(l['prix'])}", taille=6.5, couleur=GRIS)
    y = pdf.pointilles(y + 0.5)
    if v["remise"]:
        y = pdf.ligne(y, "Sous-total", _f(v["sous_total"]))
        y = pdf.ligne(y, "Remise", "− " + _f(v["remise"]))
    y = pdf.ligne(y + 0.5, "TOTAL", _f(v["total"]), taille=12, style="B", couleur=MARINE)
    y = pdf.ligne(y + 1, f"Payé ({v['mode']})", _f(v["recu"]))
    if v["rendu"]:
        y = pdf.ligne(y, "Monnaie rendue", _f(v["rendu"]))
    if v["reste"]:
        y = pdf.ligne(y, "Reste à payer", _f(v["reste"]), style="B", couleur=(176, 57, 44))
    y = pdf.pointilles(y + 1)
    if v["vendeur"]:
        y = pdf.centre(y, f"Servi par {v['vendeur']}", taille=6.5, couleur=GRIS)
    pdf.centre(y + 1, "Merci de votre visite !", taille=8.5, style="B", couleur=VERT)
    return bytes(pdf.output())


# ---------- Facture A4 ----------

def facture_pdf(v: dict) -> bytes:
    """v : comme ticket_pdf, plus client_coordonnees et numero de facture (= numéro de la vente)."""
    pdf = recus.PDF()
    pdf.set_title(f"Facture {v['numero']}")
    pdf.add_page()
    y = recus._entete(pdf, 6, "FACTURE", v["numero"], v["date"], "Vente au comptoir")
    y = recus._ligne(pdf, y, "Client", v["client"])
    if v.get("client_coordonnees"):
        y = recus._ligne(pdf, y, "Coordonnées", v["client_coordonnees"])
    if v["annulee"]:
        pdf.texte(120, y - 6, "ANNULÉE", taille=16, couleur=(176, 57, 44), style="B", largeur=78, align="R")
    colonnes = [("Désignation", 90, "L"), ("Quantité", 32, "R"), ("Prix unitaire", 30, "R"), ("Total", 30, "R")]
    y += 2
    pdf.set_fill_color(*MARINE)
    pdf.rect(16, y, 182, 7, style="F")
    x = 16
    for titre, largeur, align in colonnes:
        pdf.texte(x + 2, y + 1.6, titre, taille=8.5, couleur=(255, 255, 255), style="B", largeur=largeur - 4, align=align)
        x += largeur
    y += 9
    for i, l in enumerate(v["lignes"]):
        if y > 245:   # page suivante (longue facture)
            pdf.add_page()
            y = 16
        if i % 2:
            pdf.set_fill_color(246, 248, 245)
            pdf.rect(16, y - 1.2, 182, 6.4, style="F")
        valeurs = [l["article"], f"{_qte(l['quantite'])} {l['unite']}", _f(l["prix"]), _f(l["total"])]
        x = 16
        for (titre, largeur, align), valeur in zip(colonnes, valeurs):
            pdf.texte(x + 2, y, valeur[:60], taille=8.5, couleur=ENCRE, largeur=largeur - 4, align=align)
            x += largeur
        y += 6.4
    pdf.set_draw_color(*VERT)
    pdf.set_line_width(0.3)
    pdf.line(16, y, 198, y)
    y += 2.5

    def total(libelle, valeur, gras=False, couleur=ENCRE):
        nonlocal y
        pdf.texte(110, y, libelle, taille=9.5 if gras else 8.5, couleur=MARINE if gras else GRIS, style="B" if gras else "",
                  largeur=55, align="R")
        pdf.texte(165, y, valeur, taille=10.5 if gras else 9, couleur=couleur, style="B" if gras else "", largeur=31, align="R")
        y += 6 if gras else 5

    if v["remise"]:
        total("Sous-total", _f(v["sous_total"]))
        total("Remise", "− " + _f(v["remise"]))
    total("TOTAL", francs(v["total"]), gras=True, couleur=MARINE)
    total(f"Payé ({v['mode']})", _f(v["recu"]))
    if v["reste"]:
        total("Reste à payer", _f(v["reste"]), couleur=(176, 57, 44))
    y += 3
    pdf.set_font("Montserrat", "", 9)
    pdf.set_text_color(*ENCRE)
    pdf.set_xy(16, y)
    lettres = en_lettres(v["total"])
    pdf.multi_cell(182, 4.8, f"Arrêtée la présente facture à la somme de {lettres[0].lower()}{lettres[1:]}.")
    y = pdf.get_y() + 8
    if y > 255:
        pdf.add_page()
        y = 20
    pdf.texte(16, y, f"Fait à {ENTETE['ville']}, le {v['date']}", taille=9, couleur=ENCRE)
    pdf.texte(16, y + 6, f"Pour {ENTETE['nom']}", taille=8, couleur=GRIS)
    pdf.set_draw_color(*GRIS)
    pdf.set_line_width(0.2)
    pdf.rect(128, y - 3, 70, 22)
    pdf.texte(128, y - 1.5, "Signature et cachet", taille=7.5, couleur=GRIS, largeur=70, align="C")
    return bytes(pdf.output())


# ---------- Reçu d'un paiement de client (crédit remboursé) ----------

def _recu_client(pdf, y0: float, d: dict, mention: str) -> None:
    y = recus._entete(pdf, y0, "REÇU DE PAIEMENT", d["numero"], d["date"], mention)
    y = recus._ligne(pdf, y, "Reçu de", d["client"])
    y = recus._montant(pdf, y, {"montant": d["montant"], "montant_lettres": en_lettres(d["montant"])})
    y = recus._ligne(pdf, y, "Motif", d["motif"])
    y = recus._ligne(pdf, y, "Mode de paiement", d["mode"])
    recus._ligne(pdf, y, "Reste dû après", d["reste"])
    recus._pied(pdf, y0, d["date"], f"Encaissé par : {d['caissier']}" if d.get("caissier") else "")


def recu_client_pdf(d: dict) -> bytes:
    return recus._page_double(lambda pdf, y0, mention: _recu_client(pdf, y0, d, mention), f"Reçu {d['numero']}",
                              ("ORIGINAL — Client", f"DUPLICATA — {ENTETE['nom']} (souche)"))
