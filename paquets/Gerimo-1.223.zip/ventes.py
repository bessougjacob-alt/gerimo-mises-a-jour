"""Commerce, étape 4 (14/11/2026) : ventes au comptoir, clients et paiements des clients.

Décisions de Boss (14/11/2026) :
- Prix détail OU gros pour toute la vente.
- Remise : le vendeur peut faire seul jusqu'au % fixé par l'Admin (Paramètres, 10 % par défaut) ; au-delà, un Admin
  confirme avec son identifiant et son mot de passe. Un Admin qui vend n'a pas de plafond.
- Vendeurs : Admin, Caisse et magasinier (Gestionnaire).
- Stock insuffisant : vente refusée, sauf pour l'Admin (« vendre quand même », noté sur la vente et au journal).
- Crédit (le client paie moins que le total) : client obligatoire ; plafond de crédit du client (refus sauf Admin) ;
  le client rembourse en une ou plusieurs fois, chaque somme a son numéro de reçu (RGL-…).
- Annulation : Admin ou Caisse, avec son mot de passe et un motif. La marchandise revient en stock ; ce que le client
  avait payé lui est rendu (sortie d'argent le jour de l'annulation : les journées passées ne changent pas).
- Bénéfice : coût de chaque ligne au prix d'achat moyen du moment ; jamais montré au Gestionnaire.
"""
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import Field
from sqlalchemy import func
from sqlalchemy.orm import Session as SessionDB, selectinload

import parametres
import periode
import tresorerie
from arrivages import prendre_dans_les_arrivages, resume_stock, stocks
from commerce import voit_achats
from commun import Formulaire, Paragraphe, Suppression, Telephone, Texte, charger, enregistrer, montant, numero_suivant
from models import (MODES_PAIEMENT, Article, ClientCommerce, LigneVente, MouvementStock, ReglementVente, UniteArticle,
                    Utilisateur, Vente)
from securite import exiger_module, get_db, verifier_mot_de_passe

router = APIRouter(prefix="/api")
acces = exiger_module("ventes")
ZERO = Decimal(0)
UN_FRANC = Decimal("1")


def _francs(v: Decimal) -> Decimal:
    return v.quantize(UN_FRANC, rounding=ROUND_HALF_UP)


def texte_francs(v) -> str:
    return f"{Decimal(v):,.0f}".replace(",", " ") + " F"


# ---------- Clients ----------

class ClientIn(Formulaire):
    nom: Texte = Field(min_length=2, max_length=150)
    telephone: Telephone | None = Field(None, max_length=30)
    adresse: Texte | None = Field(None, max_length=200)
    note: Paragraphe | None = Field(None, max_length=2000)
    plafond_credit: Decimal | None = Field(None, ge=0, max_digits=14, decimal_places=2)
    actif: bool = True


def doit(db: SessionDB, client_ids: list[int] | None = None) -> dict[int, Decimal]:
    """Ce que chaque client doit encore (ventes validées − sommes reçues)."""
    q_ventes = db.query(Vente.client_id, func.sum(Vente.total)).filter(Vente.statut == "Validée", Vente.client_id.isnot(None))
    q_recu = (db.query(Vente.client_id, func.sum(ReglementVente.montant)).join(ReglementVente.vente)
              .filter(Vente.statut == "Validée", Vente.client_id.isnot(None)))
    if client_ids is not None:
        q_ventes, q_recu = q_ventes.filter(Vente.client_id.in_(client_ids)), q_recu.filter(Vente.client_id.in_(client_ids))
    total = dict(q_ventes.group_by(Vente.client_id).all())
    recu = dict(q_recu.group_by(Vente.client_id).all())
    return {c: (total[c] or ZERO) - (recu.get(c) or ZERO) for c in total}


def client_json(c: ClientCommerce, du: Decimal = ZERO) -> dict:
    return {"id": c.id, "nom": c.nom, "telephone": c.telephone or "", "adresse": c.adresse or "", "note": c.note or "",
            "plafond_credit": montant(c.plafond_credit) if c.plafond_credit is not None else None, "actif": c.actif,
            "doit": montant(du)}


@router.get("/clients-commerce")
def liste_clients(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    dus = doit(db)
    return [client_json(c, dus.get(c.id, ZERO)) for c in
            db.query(ClientCommerce).order_by(ClientCommerce.actif.desc(), func.lower(ClientCommerce.nom))]


def _appliquer_client(c: ClientCommerce, d: ClientIn, u: Utilisateur) -> None:
    c.nom, c.telephone, c.adresse, c.note, c.actif = d.nom, d.telephone or None, d.adresse or None, d.note or None, d.actif
    if u.role.value == "Admin":   # le plafond de crédit est fixé par l'Admin
        c.plafond_credit = d.plafond_credit


@router.post("/clients-commerce")
def creer_client(d: ClientIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    c = ClientCommerce()
    _appliquer_client(c, d, u)
    db.add(c)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": c.id}


@router.put("/clients-commerce/{client_id}")
def modifier_client(client_id: int, d: ClientIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    c = charger(db, ClientCommerce, client_id, "Client introuvable.")
    _appliquer_client(c, d, u)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": c.id}


# ---------- Ventes ----------

class LigneVenteIn(Formulaire):
    article_id: int
    unite_id: int | None = None
    quantite: Decimal = Field(gt=0, max_digits=12, decimal_places=3)


class ConfirmationAdmin(Formulaire):
    identifiant: str = Field(min_length=1, max_length=80)
    mot_de_passe: str = Field(min_length=1, max_length=200)


class VenteIn(Formulaire):
    prix_applique: Literal["Détail", "Gros"] = "Détail"
    lignes: list[LigneVenteIn] = Field(min_length=1, max_length=200)
    remise: Decimal = Field(Decimal(0), ge=0, max_digits=14, decimal_places=2)
    client_id: int | None = None
    paye: Decimal = Field(ge=0, max_digits=14, decimal_places=2)      # reçu tout de suite (le reste = crédit)
    mode_paiement: Literal[MODES_PAIEMENT] = "Espèce"
    compte_id: int | None = None
    date_vente: date | None = None
    note: Texte | None = Field(None, max_length=200)
    forcer_stock: bool = False                                          # Admin : vendre même sans stock
    confirmation_admin: ConfirmationAdmin | None = None                 # remise au-delà du plafond


def _admin_confirme(db: SessionDB, c: ConfirmationAdmin | None) -> Utilisateur | None:
    if c is None:
        return None
    admin = db.query(Utilisateur).filter(func.lower(Utilisateur.identifiant) == c.identifiant.strip().lower(),
                                         Utilisateur.actif.is_(True)).first()
    if admin is None or admin.role.value != "Admin" or not verifier_mot_de_passe(c.mot_de_passe, admin.mot_de_passe):
        raise HTTPException(status_code=403, detail="Confirmation refusée : identifiant ou mot de passe d'Admin incorrect.")
    return admin


def vente_json(v: Vente, u: Utilisateur) -> dict:
    argent = voit_achats(u)
    recu = sum((r.montant for r in v.reglements), ZERO)
    r = {"id": v.id, "numero": v.numero, "date": v.date_vente.isoformat(), "statut": v.statut,
         "client_id": v.client_id, "client": v.client.nom if v.client else "Client de passage",
         "client_telephone": v.client.telephone if v.client else "",
         "prix_applique": v.prix_applique, "sous_total": montant(v.sous_total), "remise": montant(v.remise),
         "total": montant(v.total), "recu": montant(recu),
         "reste": montant(v.total - recu) if v.statut == "Validée" else 0,
         "vendu_par": v.vendeur.nom_complet if v.vendeur else "", "note": v.note or "",
         "motif_annulation": v.motif_annulation or "", "rembourse": montant(v.rembourse),
         "lignes": [{"article_id": l.article_id, "article": l.article_nom, "unite": l.unite_nom,
                     "quantite": montant(l.quantite), "prix_unitaire": montant(l.prix_unitaire), "total": montant(l.total)}
                    for l in v.lignes],
         "reglements": [{"id": x.id, "numero": x.numero, "date": x.date_reglement.isoformat(), "montant": montant(x.montant),
                         "mode_paiement": x.mode_paiement, "a_la_vente": x.a_la_vente,
                         "saisi_par": x.auteur.nom_complet if x.auteur else ""} for x in v.reglements]}
    if argent:
        cout = sum((l.cout for l in v.lignes), ZERO)
        r.update(cout=montant(cout), benefice=montant(v.total - cout))
    return r


def _requete(db: SessionDB):
    return db.query(Vente).options(selectinload(Vente.lignes), selectinload(Vente.client), selectinload(Vente.vendeur),
                                   selectinload(Vente.reglements).selectinload(ReglementVente.auteur))


@router.get("/ventes")
def liste_ventes(debut: date | None = None, fin: date | None = None, client_id: int | None = None,
                 u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    q = _requete(db)
    if debut:
        q = q.filter(Vente.date_vente >= debut)
    if fin:
        q = q.filter(Vente.date_vente <= fin)
    if client_id:
        q = q.filter(Vente.client_id == client_id)
    return [vente_json(v, u) for v in q.order_by(Vente.date_vente.desc(), Vente.id.desc()).limit(500)]


@router.get("/ventes/options")
def options(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    return {"remise_max": int(parametres.lire(db, "commerce_remise_max") or 10), "est_admin": u.role.value == "Admin",
            "voit_achats": voit_achats(u), "peut_annuler": u.role.value in ("Admin", "Caisse"),
            "modes_paiement": MODES_PAIEMENT}


def _ajouter_reglement(db: SessionDB, u: Utilisateur, v: Vente, montant_: Decimal, mode: str, compte_id: int | None,
                       jour: date, a_la_vente: bool) -> ReglementVente:
    r = ReglementVente(numero=numero_suivant(db, ReglementVente.numero, f"RGL-{jour.year}", 5), vente=v,
                       date_reglement=jour, montant=montant_, mode_paiement=mode,
                       compte_id=tresorerie.verifier_compte_choisi(db, compte_id, mode), a_la_vente=a_la_vente,
                       saisi_par=u.id)
    db.add(r)
    return r


@router.post("/ventes")
def vendre(d: VenteIn, request: Request, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    import hors_reseau
    rejeu = hors_reseau.est_rejeu(request)   # vente faite hors réseau : elle a déjà eu lieu
    jour = d.date_vente or date.today()
    if jour > date.today():
        raise HTTPException(status_code=400, detail="La date de la vente ne peut pas être dans le futur.")
    periode.verifier_ouverte(db, jour)
    admin = u.role.value == "Admin"
    client = charger(db, ClientCommerce, d.client_id, "Client introuvable.") if d.client_id else None
    stock = stocks(db)
    besoin: dict[int, Decimal] = {}
    lignes, sous_total = [], ZERO
    for x in d.lignes:
        article = charger(db, Article, x.article_id, "Article introuvable.")
        if not article.actif:
            raise HTTPException(status_code=400, detail=f"« {article.nom} » est retiré de la vente.")
        unite = None
        if x.unite_id is not None:
            unite = db.get(UniteArticle, x.unite_id)
            if unite is None or unite.article_id != article.id:
                raise HTTPException(status_code=400, detail=f"Lot inconnu pour « {article.nom} ».")
        source = unite or article
        prix = source.prix_gros if d.prix_applique == "Gros" and source.prix_gros else source.prix_detail
        if not prix:
            raise HTTPException(status_code=400, detail=f"« {article.nom} » n'a pas de prix de vente : complétez sa fiche.")
        contenance = unite.contenance if unite else Decimal(1)
        base = (x.quantite * contenance).quantize(Decimal("0.001"))
        besoin[article.id] = besoin.get(article.id, ZERO) + base
        total = _francs(prix * x.quantite)
        sous_total += total
        lignes.append(LigneVente(article=article, unite_id=unite.id if unite else None,
                                 unite_nom=unite.nom if unite else article.unite_base, article_nom=article.nom,
                                 quantite=x.quantite, contenance=contenance, quantite_base=base, prix_unitaire=prix,
                                 total=total, cout=_francs(article.prix_achat * base)))
    # stock : refus, sauf Admin qui choisit de vendre quand même
    manquants = [(a, q) for a, q in besoin.items() if q > stock.get(a, ZERO)]
    force_par = None
    if manquants:
        if not ((admin and d.forcer_stock) or rejeu):
            noms = ", ".join(f"{db.get(Article, a).nom} (reste {resume_stock(db.get(Article, a), stock.get(a, ZERO))})"
                             for a, _ in manquants)
            raise HTTPException(status_code=409, detail=f"Pas assez en stock : {noms}." + (
                " Vous pouvez vendre quand même (Admin)." if admin else " Seul l'Admin peut vendre sans stock."))
        force_par = u.id
    # remise : plafond en % pour le vendeur, au-delà un Admin confirme
    if d.remise > sous_total:
        raise HTTPException(status_code=400, detail="La remise ne peut pas dépasser le montant de la vente.")
    remise_max = Decimal(parametres.lire(db, "commerce_remise_max") or "10")
    confirme_par = None
    if d.remise and not admin and d.remise > _francs(sous_total * remise_max / 100):
        confirmant = _admin_confirme(db, d.confirmation_admin)
        if confirmant is None:
            raise HTTPException(status_code=403, detail=f"Remise de plus de {remise_max} % : un Admin doit la "
                                                        "confirmer avec son identifiant et son mot de passe.")
        confirme_par = confirmant.id
    total = sous_total - d.remise
    if d.paye > total:
        raise HTTPException(status_code=400, detail=f"Le montant reçu dépasse le total ({texte_francs(total)}) : "
                                                    "indiquez seulement ce qui est gardé (rendez la monnaie).")
    credit = total - d.paye
    if credit > 0:
        if client is None:
            raise HTTPException(status_code=400, detail="Vente à crédit : choisissez ou créez la fiche du client.")
        if client.plafond_credit is not None and not admin:
            deja = doit(db, [client.id]).get(client.id, ZERO)
            if deja + credit > client.plafond_credit:
                raise HTTPException(status_code=409, detail=f"Plafond de crédit dépassé : {client.nom} doit déjà "
                                    f"{texte_francs(deja)} (plafond {texte_francs(client.plafond_credit)}). Seul l'Admin peut aller au-delà.")
    v = Vente(numero=numero_suivant(db, Vente.numero, f"VTE-{jour.year}", 5), date_vente=jour, client=client,
              prix_applique=d.prix_applique, sous_total=sous_total, remise=d.remise, total=total,
              remise_confirmee_par=confirme_par, stock_force_par=force_par, vendu_par=u.id,
              note=((d.note or "") + (" — vendue hors réseau" if rejeu else "")).strip(" —")[:200] or None)
    v.lignes = lignes
    db.add(v)
    db.flush()
    for l in v.lignes:
        db.add(MouvementStock(article_id=l.article_id, date_mouvement=jour, quantite_base=-l.quantite_base, genre="Vente",
                              motif=f"Vente {v.numero}", valeur=l.cout, saisi_par=u.id))
        prendre_dans_les_arrivages(db, l.article_id, l.quantite_base)
    if d.paye > 0:
        _ajouter_reglement(db, u, v, d.paye, d.mode_paiement, d.compte_id, jour, True)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": v.id, "numero": v.numero, "total": montant(total), "reste": montant(credit)}


class ReglementIn(Formulaire):
    montant: Decimal = Field(gt=0, max_digits=14, decimal_places=2)
    mode_paiement: Literal[MODES_PAIEMENT] = "Espèce"
    compte_id: int | None = None
    date_reglement: date | None = None


@router.post("/ventes/{vente_id}/reglements")
def regler(vente_id: int, d: ReglementIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    """Le client rembourse une vente à crédit (en une ou plusieurs fois)."""
    v = charger(db, Vente, vente_id, "Vente introuvable.")
    if v.statut != "Validée":
        raise HTTPException(status_code=409, detail="Cette vente est annulée.")
    jour = d.date_reglement or date.today()
    if jour > date.today() or jour < v.date_vente:
        raise HTTPException(status_code=400, detail="Date du paiement incorrecte.")
    periode.verifier_ouverte(db, jour)
    reste = v.total - sum((r.montant for r in v.reglements), ZERO)
    if d.montant > reste:
        raise HTTPException(status_code=400, detail=f"Le client ne doit plus que {texte_francs(reste)} sur cette vente.")
    r = _ajouter_reglement(db, u, v, d.montant, d.mode_paiement, d.compte_id, jour, False)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": r.id, "numero": r.numero, "reste": montant(reste - d.montant)}


@router.post("/clients-commerce/{client_id}/reglements")
def regler_client(client_id: int, d: ReglementIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    """Le client verse une somme sur ce qu'il doit : elle règle ses ventes à crédit, la plus ancienne d'abord."""
    client = charger(db, ClientCommerce, client_id, "Client introuvable.")
    jour = d.date_reglement or date.today()
    if jour > date.today():
        raise HTTPException(status_code=400, detail="La date du paiement ne peut pas être dans le futur.")
    periode.verifier_ouverte(db, jour)
    ventes = _requete(db).filter(Vente.client_id == client.id, Vente.statut == "Validée").order_by(Vente.date_vente, Vente.id).all()
    dues = [(v, v.total - sum((r.montant for r in v.reglements), ZERO)) for v in ventes]
    dues = [(v, reste) for v, reste in dues if reste > 0]
    total_du = sum((reste for _, reste in dues), ZERO)
    if not dues:
        raise HTTPException(status_code=400, detail=f"{client.nom} ne doit rien.")
    if d.montant > total_du:
        raise HTTPException(status_code=400, detail=f"{client.nom} ne doit que {texte_francs(total_du)}.")
    reste_a_placer, numeros = d.montant, []
    for v, reste in dues:
        if reste_a_placer <= 0:
            break
        part = min(reste, reste_a_placer)
        numeros.append(_ajouter_reglement(db, u, v, part, d.mode_paiement, d.compte_id, max(jour, v.date_vente), False))
        reste_a_placer -= part
    enregistrer(db, "Enregistrement impossible.")
    return {"reglements": [r.numero for r in numeros], "reste": montant(total_du - d.montant)}


class AnnulationVenteIn(Suppression):
    motif: Texte = Field(min_length=3, max_length=300)
    mode_remboursement: Literal[MODES_PAIEMENT] = "Espèce"
    compte_id: int | None = None


@router.post("/ventes/{vente_id}/annuler")
def annuler(vente_id: int, d: AnnulationVenteIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    if u.role.value not in ("Admin", "Caisse"):
        raise HTTPException(status_code=403, detail="Annulation réservée à l'Admin et à la Caisse.")
    if not verifier_mot_de_passe(d.mot_de_passe_admin or "", u.mot_de_passe):
        raise HTTPException(status_code=403, detail="Mot de passe incorrect. Rien n'a été annulé.")
    v = charger(db, Vente, vente_id, "Vente introuvable.")
    if v.statut == "Annulée":
        raise HTTPException(status_code=409, detail="Cette vente est déjà annulée.")
    aujourdhui = date.today()
    periode.verifier_ouverte(db, aujourdhui)
    for l in v.lignes:   # la marchandise revient en stock
        db.add(MouvementStock(article_id=l.article_id, date_mouvement=aujourdhui, quantite_base=l.quantite_base,
                              genre="Annulation", motif=f"Annulation {v.numero} : {d.motif}"[:200], saisi_par=u.id))
    recu = sum((r.montant for r in v.reglements), ZERO)
    v.statut, v.motif_annulation, v.annule_par, v.annule_le = "Annulée", d.motif, u.id, aujourdhui
    if recu:   # l'argent reçu est rendu au client aujourd'hui
        v.rembourse, v.rembourse_mode = recu, d.mode_remboursement
        v.rembourse_compte_id = tresorerie.verifier_compte_choisi(db, d.compte_id, d.mode_remboursement)
    enregistrer(db, "Annulation impossible.")
    return {"ok": True, "rembourse": montant(recu)}


# ---------- Pour la trésorerie et la comptabilité ----------

def reglements(db: SessionDB, debut: date | None = None, fin: date | None = None):
    q = db.query(ReglementVente).options(selectinload(ReglementVente.vente).selectinload(Vente.client))
    if debut is not None:
        q = q.filter(ReglementVente.date_reglement >= debut)
    if fin is not None:
        q = q.filter(ReglementVente.date_reglement <= fin)
    return q.order_by(ReglementVente.date_reglement, ReglementVente.id).all()


def ventes_du(db: SessionDB, debut: date, fin: date):
    """Ventes de la période (toutes, même annulées ensuite : l'annulation est une écriture à sa propre date)."""
    return (db.query(Vente).options(selectinload(Vente.client))
            .filter(Vente.date_vente >= debut, Vente.date_vente <= fin).order_by(Vente.date_vente, Vente.id).all())


def annulations_du(db: SessionDB, debut: date | None = None, fin: date | None = None):
    q = db.query(Vente).options(selectinload(Vente.client)).filter(Vente.statut == "Annulée")
    if debut is not None:
        q = q.filter(Vente.annule_le >= debut)
    if fin is not None:
        q = q.filter(Vente.annule_le <= fin)
    return q.order_by(Vente.annule_le, Vente.id).all()


# ---------- Documents : ticket de caisse, facture, reçu de paiement d'un client ----------

def _donnees_document(v: Vente, donne: Decimal | None = None) -> dict:
    recu = sum((r.montant for r in v.reglements), ZERO)
    a_la_vente = next((r for r in v.reglements if r.a_la_vente), None)
    c = v.client
    return {
        "numero": v.numero, "date": v.date_vente.strftime("%d/%m/%Y"),
        "heure": v.cree_le.strftime("%H:%M") if v.cree_le else "",
        "client": c.nom if c else "Client de passage",
        "client_coordonnees": " — ".join(x for x in (c.telephone, c.adresse) if x) if c else "",
        "vendeur": v.vendeur.nom_complet if v.vendeur else "", "prix_applique": v.prix_applique,
        "lignes": [{"article": l.article_nom, "unite": l.unite_nom, "quantite": l.quantite, "prix": l.prix_unitaire,
                    "total": l.total} for l in v.lignes],
        "sous_total": v.sous_total, "remise": v.remise, "total": v.total, "recu": recu,
        "reste": (v.total - recu) if v.statut == "Validée" else ZERO,
        "rendu": max(donne - (a_la_vente.montant if a_la_vente else ZERO), ZERO) if donne else ZERO,
        "mode": a_la_vente.mode_paiement if a_la_vente else "crédit", "annulee": v.statut == "Annulée",
    }


def _pdf(contenu: bytes, nom: str):
    import unicodedata
    from urllib.parse import quote
    from fastapi.responses import Response
    simple = unicodedata.normalize("NFKD", nom).encode("ascii", "ignore").decode()   # « Recu … » pour les vieux navigateurs
    return Response(contenu, media_type="application/pdf", headers={
        "Content-Disposition": f"inline; filename=\"{simple}\"; filename*=UTF-8''{quote(nom)}", "Cache-Control": "no-store"})


@router.get("/ventes/{vente_id}/ticket")
def ticket(vente_id: int, donne: Decimal | None = None, format: str | None = None, u: Utilisateur = Depends(acces),
           db: SessionDB = Depends(get_db)):
    """Ticket au format réglé dans Paramètres (58 mm par défaut), ou à celui demandé (« 58 », « 80 », « A4 »)."""
    import recus_commerce
    v = charger(db, Vente, vente_id, "Vente introuvable.")
    choisi = format if format in recus_commerce.FORMATS_TICKET else parametres.lire(db, "commerce_format_ticket")
    return _pdf(recus_commerce.ticket_pdf(_donnees_document(v, donne), choisi), f"Ticket {v.numero}.pdf")


@router.get("/ventes/{vente_id}/facture")
def facture(vente_id: int, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    import recus_commerce
    v = charger(db, Vente, vente_id, "Vente introuvable.")
    return _pdf(recus_commerce.facture_pdf(_donnees_document(v)), f"Facture {v.numero}.pdf")


@router.get("/reglements-ventes/{reglement_id}/recu")
def recu_reglement(reglement_id: int, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    import recus_commerce
    r = charger(db, ReglementVente, reglement_id, "Paiement introuvable.")
    v = r.vente
    deja = sum((x.montant for x in v.reglements if x.id <= r.id), ZERO)
    contenu = recus_commerce.recu_client_pdf({
        "numero": r.numero, "date": r.date_reglement.strftime("%d/%m/%Y"),
        "client": v.client.nom if v.client else "Client de passage", "montant": r.montant,
        "motif": f"Paiement de la vente {v.numero} du {v.date_vente:%d/%m/%Y} (total {texte_francs(v.total)})",
        "mode": r.mode_paiement, "reste": texte_francs(max(v.total - deja, ZERO)),
        "caissier": r.auteur.nom_complet if r.auteur else ""})
    return _pdf(contenu, f"Reçu {r.numero}.pdf")
