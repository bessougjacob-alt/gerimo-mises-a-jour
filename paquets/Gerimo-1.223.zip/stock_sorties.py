"""Commerce, partie 3 (14/11/2026) : sorties de stock avec motif, et inventaire.

Décisions de Boss (13/11/2026) :
- Sorties avec un motif : casse, périmé, vol ou perte, usage interne, cadeau ou échantillon, autre. Saisies par l'Admin
  ou le magasinier (Gestionnaire). On ne sort pas plus que ce qu'il y a en stock. Ce que la marchandise avait coûté
  est noté (pertes), visible seulement par ceux qui voient les prix d'achat.
- Inventaire : on compte le stock réel ; Gérimo montre l'écart avec ce qu'il prévoyait. Le magasinier peut saisir le
  comptage ; seul l'Admin le valide. À la validation, l'écart devient un mouvement « Inventaire » (+ ou −).
"""
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from sqlalchemy.orm import Session as SessionDB, selectinload

from arrivages import prendre_dans_les_arrivages, resume_stock, stock_de, stocks
from commerce import acces, voit_achats
from commun import Formulaire, Texte, Paragraphe, charger, enregistrer, montant, numero_suivant
from models import Article, Inventaire, LigneInventaire, MouvementStock, UniteArticle, Utilisateur
from securite import exiger_admin, get_db

router = APIRouter(prefix="/api/stock")
ZERO = Decimal(0)
RAISONS = ("Casse", "Périmé", "Vol ou perte", "Usage interne", "Cadeau ou échantillon", "Autre")
ROLES_STOCK = ("Admin", "Gestionnaire")


def _verifier_role(u: Utilisateur) -> None:
    if u.role.value not in ROLES_STOCK:
        raise HTTPException(status_code=403, detail="Les sorties et l'inventaire sont faits par l'Admin ou le magasinier.")


# ---------- Sorties ----------

class SortieIn(Formulaire):
    article_id: int
    unite_id: int | None = None
    quantite: Decimal = Field(gt=0, max_digits=12, decimal_places=3)
    raison: Literal[RAISONS]
    note: Texte | None = Field(None, max_length=150)
    date_sortie: date | None = None


@router.post("/sorties")
def creer_sortie(d: SortieIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _verifier_role(u)
    jour = d.date_sortie or date.today()
    if jour > date.today():
        raise HTTPException(status_code=400, detail="La date ne peut pas être dans le futur.")
    article = charger(db, Article, d.article_id, "Article introuvable.")
    contenance = Decimal(1)
    if d.unite_id is not None:
        unite = db.get(UniteArticle, d.unite_id)
        if unite is None or unite.article_id != article.id:
            raise HTTPException(status_code=400, detail="Lot inconnu pour cet article.")
        contenance = unite.contenance
    base = (d.quantite * contenance).quantize(Decimal("0.001"))
    en_stock = stock_de(db, article.id)
    if base > en_stock:
        raise HTTPException(status_code=400, detail=f"Il ne reste que {resume_stock(article, en_stock)} de « {article.nom} » "
                                                    "en stock : impossible d'en sortir plus.")
    db.add(MouvementStock(article_id=article.id, date_mouvement=jour, quantite_base=-base, genre="Sortie",
                          raison=d.raison, valeur=(base * article.prix_achat).quantize(Decimal("0.01")),
                          motif=(f"{d.raison} — {d.note}" if d.note else d.raison)[:200], saisi_par=u.id))
    prendre_dans_les_arrivages(db, article.id, base)
    enregistrer(db, "Enregistrement impossible.")
    return {"ok": True, "stock": montant(en_stock - base), "stock_texte": resume_stock(article, en_stock - base)}


@router.get("/sorties")
def liste_sorties(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    argent = voit_achats(u)
    sorties = (db.query(MouvementStock).options(selectinload(MouvementStock.article).selectinload(Article.unites),
                                                selectinload(MouvementStock.auteur))
               .filter(MouvementStock.genre == "Sortie")
               .order_by(MouvementStock.date_mouvement.desc(), MouvementStock.id.desc()).limit(300).all())
    debut_mois = date.today().replace(day=1)
    par_raison: dict[str, Decimal] = {}
    lignes = []
    for m in sorties:
        q = -m.quantite_base
        ligne = {"id": m.id, "date": m.date_mouvement.isoformat(), "article": m.article.nom,
                 "quantite": montant(q), "quantite_texte": resume_stock(m.article, q), "raison": m.raison or "Autre",
                 "motif": m.motif or "", "saisi_par": m.auteur.nom_complet if m.auteur else ""}
        if argent:
            ligne["valeur"] = montant(m.valeur or ZERO)
            if m.date_mouvement >= debut_mois:
                par_raison[ligne["raison"]] = par_raison.get(ligne["raison"], ZERO) + (m.valeur or ZERO)
        lignes.append(ligne)
    r = {"raisons": RAISONS, "sorties": lignes}
    if argent:
        r["pertes_du_mois"] = montant(sum(par_raison.values(), ZERO))
        r["pertes_par_raison"] = {k: montant(v) for k, v in sorted(par_raison.items(), key=lambda x: -x[1])}
    return r


# ---------- Inventaire ----------

class LigneInventaireIn(Formulaire):
    article_id: int
    stock_compte: Decimal = Field(ge=0, max_digits=14, decimal_places=3)   # en plus petite unité vendue


class InventaireIn(Formulaire):
    date_inventaire: date
    note: Paragraphe | None = Field(None, max_length=2000)
    lignes: list[LigneInventaireIn] = Field(min_length=1, max_length=2000)
    valider: bool = False   # l'Admin peut valider tout de suite


@router.get("/inventaire/preparer")
def preparer(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    """Les articles en vente, avec le stock que Gérimo prévoit (à comparer au comptage)."""
    _verifier_role(u)
    stock = stocks(db)
    articles = (db.query(Article).options(selectinload(Article.unites)).filter(Article.actif)
                .order_by(Article.categorie.nullslast(), Article.nom))
    return [{"id": a.id, "nom": a.nom, "categorie": a.categorie or "Sans catégorie", "unite_base": a.unite_base,
             "stock_prevu": montant(stock.get(a.id, ZERO)), "stock_texte": resume_stock(a, stock.get(a.id, ZERO)),
             "unites": [{"nom": x.nom, "contenance": montant(x.contenance)} for x in sorted(a.unites, key=lambda x: -x.contenance)]}
            for a in articles]


def inventaire_json(i: Inventaire, u: Utilisateur) -> dict:
    argent = voit_achats(u)
    lignes, valeur = [], ZERO
    for l in i.lignes:
        ecart = l.stock_compte - l.stock_prevu
        ligne = {"article_id": l.article_id, "article": l.article.nom, "unite_base": l.article.unite_base,
                 "stock_prevu": montant(l.stock_prevu), "stock_compte": montant(l.stock_compte), "ecart": montant(ecart),
                 "ecart_texte": ("+ " if ecart > 0 else "− " if ecart < 0 else "") + resume_stock(l.article, abs(ecart))}
        if argent:
            ligne["valeur_ecart"] = montant((ecart * l.article.prix_achat).quantize(Decimal("1")))
            valeur += ecart * l.article.prix_achat
        lignes.append(ligne)
    r = {"id": i.id, "numero": i.numero, "date": i.date_inventaire.isoformat(), "statut": i.statut, "note": i.note or "",
         "saisi_par": i.auteur.nom_complet if i.auteur else "", "valide_par": i.valideur.nom_complet if i.valideur else "",
         "nb_articles": len(lignes), "nb_ecarts": sum(1 for x in lignes if x["ecart"]),
         "lignes": sorted(lignes, key=lambda x: (x["ecart"] == 0, x["ecart"]))}
    if argent:
        r["valeur_ecart"] = montant(valeur.quantize(Decimal("1")))
    return r


def _requete_inventaires(db: SessionDB):
    return db.query(Inventaire).options(selectinload(Inventaire.lignes).selectinload(LigneInventaire.article)
                                        .selectinload(Article.unites),
                                        selectinload(Inventaire.auteur), selectinload(Inventaire.valideur))


@router.get("/inventaires")
def liste_inventaires(u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _verifier_role(u)
    return [inventaire_json(i, u) for i in _requete_inventaires(db).order_by(Inventaire.date_inventaire.desc(),
                                                                              Inventaire.id.desc()).limit(100)]


def _valider(db: SessionDB, admin: Utilisateur, i: Inventaire) -> None:
    for l in i.lignes:
        ecart = l.stock_compte - l.stock_prevu
        if not ecart:
            continue
        db.add(MouvementStock(article_id=l.article_id, date_mouvement=i.date_inventaire, quantite_base=ecart,
                              genre="Inventaire", raison="Inventaire",
                              valeur=(ecart * l.article.prix_achat).quantize(Decimal("0.01")),
                              motif=f"Inventaire {i.numero} : compté {montant(l.stock_compte)}, prévu {montant(l.stock_prevu)}",
                              saisi_par=admin.id))
        if ecart < 0:
            prendre_dans_les_arrivages(db, l.article_id, -ecart)
    i.statut, i.valide_par, i.valide_le = "Validé", admin.id, datetime.now()


@router.post("/inventaires")
def creer_inventaire(d: InventaireIn, u: Utilisateur = Depends(acces), db: SessionDB = Depends(get_db)):
    _verifier_role(u)
    if d.date_inventaire > date.today():
        raise HTTPException(status_code=400, detail="La date de l'inventaire ne peut pas être dans le futur.")
    if d.valider and u.role.value != "Admin":
        raise HTTPException(status_code=403, detail="Seul l'Admin valide un inventaire.")
    ids = [x.article_id for x in d.lignes]
    if len(ids) != len(set(ids)):
        raise HTTPException(status_code=400, detail="Un article est compté deux fois.")
    stock = stocks(db)
    i = Inventaire(numero=numero_suivant(db, Inventaire.numero, f"INV-{d.date_inventaire.year}", 4),
                   date_inventaire=d.date_inventaire, note=d.note or None, saisi_par=u.id)
    for x in d.lignes:
        article = charger(db, Article, x.article_id, "Article introuvable.")
        i.lignes.append(LigneInventaire(article=article, stock_prevu=stock.get(article.id, ZERO), stock_compte=x.stock_compte))
    db.add(i)
    db.flush()
    if d.valider:
        _valider(db, u, i)
    enregistrer(db, "Enregistrement impossible.")
    return {"id": i.id, "numero": i.numero, "statut": i.statut}


@router.post("/inventaires/{inventaire_id}/valider")
def valider(inventaire_id: int, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    i = charger(db, Inventaire, inventaire_id, "Inventaire introuvable.")
    if i.statut != "À valider":
        raise HTTPException(status_code=409, detail=f"Cet inventaire est déjà « {i.statut} ».")
    _valider(db, admin, i)
    enregistrer(db, "Validation impossible.")
    return {"ok": True}


@router.post("/inventaires/{inventaire_id}/abandonner")
def abandonner(inventaire_id: int, admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    acces(admin)
    i = charger(db, Inventaire, inventaire_id, "Inventaire introuvable.")
    if i.statut != "À valider":
        raise HTTPException(status_code=409, detail=f"Cet inventaire est déjà « {i.statut} ».")
    i.statut = "Abandonné"
    enregistrer(db, "Enregistrement impossible.")
    return {"ok": True}


# ---------- Alertes (assistant : bandeau « Bonjour » et notifications) ----------

def alertes(db: SessionDB, u: Utilisateur) -> list[dict]:
    """[(cle, niveau, titre, detail)] : stock bas, dates limites, prix à compléter, inventaires à valider."""
    from arrivages import dates_limites, JOURS_DATE_LIMITE
    from models import Arrivage
    resultat = []
    stock = stocks(db)
    articles = db.query(Article).options(selectinload(Article.unites)).filter(Article.actif).all()
    vides = [a for a in articles if stock.get(a.id, ZERO) <= 0]
    bas = [a for a in articles if 0 < stock.get(a.id, ZERO) <= a.seuil_alerte]
    if vides:
        resultat.append(("stock-vide", "urgent", f"{len(vides)} article{'s' if len(vides) > 1 else ''} en rupture de stock",
                         ", ".join(a.nom for a in vides[:5]) + ("…" if len(vides) > 5 else "")))
    if bas:
        resultat.append(("stock-bas", "attention", f"{len(bas)} article{'s' if len(bas) > 1 else ''} presque épuisé{'s' if len(bas) > 1 else ''}",
                         ", ".join(f"{a.nom} ({resume_stock(a, stock[a.id])})" for a in bas[:5]) + ("…" if len(bas) > 5 else "")))
    aujourdhui = date.today()
    limites = dates_limites(db)
    noms = {a.id: a.nom for a in articles}
    perimes = [(i, d) for i, d in limites.items() if d < aujourdhui and i in noms]
    proches = [(i, d) for i, d in limites.items()
               if aujourdhui <= d <= aujourdhui + timedelta(days=JOURS_DATE_LIMITE) and i in noms]
    if perimes:
        resultat.append(("stock-perime", "urgent", f"Produits périmés en stock : {len(perimes)}",
                         ", ".join(noms[i] for i, _ in sorted(perimes, key=lambda x: x[1])[:5])
                         + " — retirez-les (sortie « Périmé »)."))
    if proches:
        resultat.append(("stock-date", "attention", f"Date limite proche : {len(proches)} produit{'s' if len(proches) > 1 else ''}",
                         ", ".join(f"{noms[i]} ({d:%d/%m})" for i, d in sorted(proches, key=lambda x: x[1])[:5])))
    if voit_achats(u):
        n = db.query(Arrivage).filter(Arrivage.prix_complets.is_(False), Arrivage.annule.is_(False)).count()
        if n:
            resultat.append(("arrivages-prix", "attention", f"{n} arrivage{'s' if n > 1 else ''} sans prix",
                             "Mettez les prix de la facture (Stock → Arrivages)."))
    if u.role.value == "Admin":
        n = db.query(Inventaire).filter(Inventaire.statut == "À valider").count()
        if n:
            resultat.append(("inventaire-valider", "attention", f"{n} inventaire{'s' if n > 1 else ''} à valider",
                             "Vérifiez les écarts puis validez (Stock → Sorties et inventaire)."))
    return resultat
