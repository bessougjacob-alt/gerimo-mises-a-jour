// Statistiques en graphiques (icône du bord droit) : KPI du mois, évolution sur 12 mois, impayés,
// occupation, modes de paiement et reversements. Graphiques dessinés en HTML/CSS, sans bibliothèque
// ni Internet. Le serveur (/api/statistiques) respecte les droits : pas de commission pour le Gestionnaire.

// Couleurs des séries, vérifiées pour les daltoniens (validateur de palette, 04/10/2026)
const COULEURS_STATS = { loyers: "#7fb24a", commission: "#1f5f99", depenses: "#c1552d", impayes: "#b0392c" };

// 1 250 000 → « 1,25 M » ; 85 000 → « 85 k » (axes) ; le montant exact reste dans l'infobulle
function montantCourt(n) {
  const a = Math.abs(n);
  if (a >= 1e6) return (n / 1e6).toLocaleString("fr-FR", { maximumFractionDigits: 2 }) + " M";
  if (a >= 1e3) return (n / 1e3).toLocaleString("fr-FR", { maximumFractionDigits: 0 }) + " k";
  return String(n);
}

// Graduation « ronde » de l'axe (1, 2 ou 5 × 10^n)
function maxRond(max) {
  if (max <= 0) return 1;
  const p = 10 ** Math.floor(Math.log10(max));
  return [1, 2, 2.5, 5, 10].map(f => f * p).find(v => v >= max);
}

const NOMS_MOIS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
const libelleMois = mm_aaaa => { const [m, a] = mm_aaaa.split("/"); return `${NOMS_MOIS[m - 1]} ${a}`; };
// Axe : le mois seul, l'année sur le premier mois et sur janvier
const libelleAxe = (mm_aaaa, i) => { const [m, a] = mm_aaaa.split("/"); return NOMS_MOIS[m - 1] + (i === 0 || m === "01" ? ` ${a.slice(2)}` : ""); };

function legende(series) {
  return `<div class="st-legende">${series.map(s => `<span><i style="background:${s.couleur}"></i>${esc(s.nom)}</span>`).join("")}</div>`;
}

// Colonnes groupées par mois (une seule échelle) ; survol = infobulle avec les montants exacts
function colonnes(mois, series, vide = "Aucun montant sur les 12 derniers mois.") {
  const plusGrand = Math.max(0, ...series.flatMap(s => s.valeurs));
  if (plusGrand <= 0) return `${series.length > 1 ? legende(series) : ""}<div class="vide st-vide">${vide}</div>`;
  const max = maxRond(plusGrand);
  const graduations = [1, 0.75, 0.5, 0.25, 0].map(f => `<div class="st-grad" style="bottom:${f * 100}%"><span>${montantCourt(max * f)}</span></div>`).join("");
  const groupes = mois.map((m, i) => {
    const bulle = `<b>${esc(libelleMois(m))}</b>` + series.map(s => `<br><i style="background:${s.couleur}"></i>${esc(s.nom)} : ${formatMontant(s.valeurs[i])}`).join("");
    return `<div class="st-groupe" data-bulle="${esc(bulle)}">
      <div class="st-barres">${series.map(s => `<div class="st-barre" style="height:${s.valeurs[i] / max * 100}%;background:${s.couleur}"></div>`).join("")}</div>
      <div class="st-mois">${esc(libelleAxe(m, i))}</div></div>`;
  }).join("");
  return `${series.length > 1 ? legende(series) : ""}<div class="st-defile"><div class="st-colonnes">${graduations}<div class="st-zone">${groupes}</div></div></div>`;
}

// Barres horizontales : [{ libelle, valeur, texte, couleur? }]
function barresH(items, couleur, vide) {
  if (!items.length) return `<div class="vide">${vide}</div>`;
  const max = Math.max(...items.map(x => x.valeur), 1);
  return `<div class="st-lignes">${items.map(x => `
    <div class="st-ligne" data-bulle="${esc(`<b>${esc(x.libelle)}</b><br>${esc(x.texte)}`)}">
      <span class="st-lib">${esc(x.libelle)}</span>
      <span class="st-piste"><span style="width:${Math.max(x.valeur / max * 100, x.valeur ? 1.5 : 0)}%;background:${x.couleur || couleur}"></span></span>
      <span class="st-val">${esc(x.texte)}</span></div>`).join("")}</div>`;
}

// Barre empilée par ligne (ex. propriétaire : net + commission + dépenses)
function barresEmpilees(items, series, vide) {
  if (!items.length) return `<div class="vide">${vide}</div>`;
  const max = Math.max(...items.map(x => series.reduce((t, s) => t + x[s.cle], 0)), 1);
  return legende(series) + `<div class="st-lignes">${items.map(x => {
    const total = series.reduce((t, s) => t + x[s.cle], 0);
    const bulle = `<b>${esc(x.libelle)}</b>` + series.map(s => `<br><i style="background:${s.couleur}"></i>${esc(s.nom)} : ${formatMontant(x[s.cle])}`).join("");
    return `<div class="st-ligne" data-bulle="${esc(bulle)}"><span class="st-lib">${esc(x.libelle)}</span>
      <span class="st-piste empilee">${series.map(s => x[s.cle] > 0 ? `<span style="width:${x[s.cle] / max * 100}%;background:${s.couleur}"></span>` : "").join("")}</span>
      <span class="st-val">${formatMontant(total)}</span></div>`;
  }).join("")}</div>`;
}

// Anneau d'occupation (occupés / réservés / maintenance / libres)
function anneauOccupation(o) {
  const parts = [["Occupés", o.occupes, "#4c8a4a"], ["Réservés", o.reserves, "#1f5f99"],
                 ["Maintenance", o.maintenance, "#b7791f"], ["Libres", o.libres, "#d5dad3"]];
  let angle = 0;
  const arcs = parts.filter(p => p[1] > 0).map(([, n, c]) => {
    const debut = angle; angle += n / Math.max(o.total, 1) * 360;
    return `${c} ${debut}deg ${angle}deg`;
  });
  const fond = o.total ? `conic-gradient(${arcs.join(",")})` : "#e2e6df";
  return `<div class="st-anneau-bloc">
    <div class="st-anneau" style="background:${fond}"><div><b>${o.taux_occupation} %</b><span>occupés</span></div></div>
    <div class="st-anneau-legende">${parts.map(([nom, n, c]) => `<span><i style="background:${c}"></i>${nom}<b>${n}</b></span>`).join("")}
      <span class="petit">${o.total} logement(s) au total</span></div></div>`;
}

function tableauChiffres(ev, avecCommission) {
  return `<details class="st-tableau"><summary>Voir les chiffres en tableau</summary><div class="table-defile"><table>
    <thead><tr><th>Mois</th><th>Loyers encaissés</th>${avecCommission ? "<th>Commission</th>" : ""}<th>Dépenses</th><th>Impayés échus</th></tr></thead>
    <tbody>${ev.map(m => `<tr><td>${esc(libelleMois(m.mois))}</td><td>${formatMontant(m.loyers)}</td>${avecCommission ? `<td>${formatMontant(m.commission)}</td>` : ""}<td>${formatMontant(m.depenses)}</td><td>${formatMontant(m.impayes)}</td></tr>`).join("")}</tbody>
  </table></div></details>`;
}

async function chargerStatistiques() {
  const zone = el("contenuStatistiques");
  zone.innerHTML = '<div class="vide">Calcul des statistiques…</div>';
  let s;
  try { s = await api("/api/statistiques"); } catch (e) { zone.innerHTML = `<div class="vide">${esc(e.message)}</div>`; return; }
  const ev = s.evolution, r = s.rapport, t = s.mois_en_cours;
  const admin = ev.length && ev[0].commission !== undefined;
  const somme = cle => ev.reduce((x, m) => x + (m[cle] || 0), 0);

  const kpis = `<div class="kpis">
    ${carteKpi("ok", `Loyers encaissés (${t.mois})`, formatMontant(t.loyers_encaisses))}
    ${admin ? carteKpi("info", "Commission de gestion du mois", formatMontant(t.commission_entreprise)) : carteKpi("warn", "Dépenses du mois", formatMontant(t.depenses))}
    ${carteKpi("warn", "Impayés en cours", `${t.impayes_en_cours} contrat${t.impayes_en_cours > 1 ? "s" : ""}`, `taux sur 12 mois : ${String(r.kpis.taux_impayes).replace(".", ",")} %`)}
    ${carteKpi("risk", "Contrats à risque", t.contrats_a_risque, "2 mois impayés ou plus")}
  </div>`;

  const series = [{ nom: "Loyers encaissés", couleur: COULEURS_STATS.loyers, valeurs: ev.map(m => m.loyers) }];
  if (admin) series.push({ nom: "Commission de gestion", couleur: COULEURS_STATS.commission, valeurs: ev.map(m => m.commission) });
  series.push({ nom: "Dépenses", couleur: COULEURS_STATS.depenses, valeurs: ev.map(m => m.depenses) });

  let html = kpis + `<div class="st-grille">
    <div class="card st-large"><h3>Encaissements et dépenses — 12 derniers mois</h3>
      <p class="st-total">Loyers encaissés sur 12 mois : <b>${formatMontant(somme("loyers"))}</b>${admin ? ` — commission de gestion : <b>${formatMontant(somme("commission"))}</b>` : ""} — dépenses : <b>${formatMontant(somme("depenses"))}</b></p>${colonnes(ev.map(m => m.mois), series)}${tableauChiffres(ev, admin)}</div>
    <div class="card"><h3>Loyers échus impayés par mois</h3>${colonnes(ev.map(m => m.mois), [{ nom: "Impayés", couleur: COULEURS_STATS.impayes, valeurs: ev.map(m => m.impayes) }], "Aucun loyer impayé sur les 12 derniers mois.")}
      <p class="petit">Loyers dont la date limite (le 05) est passée sans paiement, à ce jour.</p></div>
    <div class="card"><h3>Occupation des logements</h3>${anneauOccupation(r.occupation)}</div>
    <div class="card"><h3>Taux d'occupation par bien</h3>${barresH(r.par_bien.filter(b => b.logements).map(b => ({
      libelle: b.bien, valeur: b.taux_occupation, texte: `${b.taux_occupation} % (${b.occupes}/${b.logements})`,
      couleur: b.taux_occupation >= 80 ? "#4c8a4a" : b.taux_occupation >= 50 ? "#b7791f" : "#b0392c" })), "#4c8a4a", "Aucun logement.")}</div>
    <div class="card"><h3>Encaissements par mode de paiement (12 mois)</h3>${barresH(r.par_mode.map(m => ({
      libelle: m.mode, valeur: m.montant, texte: formatMontant(m.montant) })), COULEURS_STATS.loyers, "Aucun encaissement sur 12 mois.")}</div>
    <div class="card"><h3>Loyers encaissés par bien (12 mois)</h3>${barresH(r.par_bien.filter(b => b.loyers).sort((a, b) => b.loyers - a.loyers).map(b => ({
      libelle: b.bien, valeur: b.loyers, texte: formatMontant(b.loyers) })), COULEURS_STATS.loyers, "Aucun loyer encaissé sur 12 mois.")}</div>`;
  if (admin && r.reversements) {
    html += `<div class="card st-large"><h3>Reversements propriétaires vs commission de gestion (12 mois)</h3>${barresEmpilees(
      r.reversements.map(p => ({ libelle: p.proprietaire, net: p.net, commission: p.commission, depenses: p.depenses })),
      [{ cle: "net", nom: "Net à reverser", couleur: COULEURS_STATS.loyers }, { cle: "commission", nom: "Commission de gestion", couleur: COULEURS_STATS.commission },
       { cle: "depenses", nom: "Dépenses à sa charge", couleur: COULEURS_STATS.depenses }], "Aucun encaissement sur 12 mois.")}
      <p class="petit">Net à reverser = loyers − commission de gestion − dépenses à la charge du propriétaire. Les cautions ne sont pas reversées.</p></div>`;
  }
  html += `</div><div class="actions" style="justify-content:flex-start"><button class="btn primary" onclick="montrerOngletRapports('rapDetail')">Rapport détaillé et PDF</button></div>`;
  zone.innerHTML = html;
}

// Infobulle commune à tous les graphiques (souris ou doigt)
(function () {
  const bulle = document.createElement("div");
  bulle.className = "st-bulle";
  document.body.appendChild(bulle);
  const montrer = e => {
    const cible = e.target.closest && e.target.closest("[data-bulle]");
    if (!cible || !cible.closest("#rapGraphiques")) { bulle.classList.remove("show"); return; }
    bulle.innerHTML = cible.dataset.bulle;
    bulle.classList.add("show");
    const x = Math.min(e.clientX + 14, window.innerWidth - bulle.offsetWidth - 8);
    const y = e.clientY - bulle.offsetHeight - 12 < 8 ? e.clientY + 16 : e.clientY - bulle.offsetHeight - 12;
    bulle.style.transform = `translate(${Math.max(8, x)}px, ${y}px)`;
  };
  document.addEventListener("pointermove", montrer);
  document.addEventListener("pointerdown", montrer);
  document.addEventListener("scroll", () => bulle.classList.remove("show"), true);
})();
