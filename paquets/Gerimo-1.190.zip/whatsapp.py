"""Étape 6 : messages WhatsApp pré-remplis (liens wa.me, sans API payante).

Cinq messages (textes modifiables dans modeles/messages_whatsapp.txt) :
- bienvenue     : à la signature du contrat            (Admin, Gestionnaire)
- rappel        : avant l'échéance (7 jours avant)      (Admin, Gestionnaire, Caisse)
- confirmation  : après un encaissement                 (Admin, Gestionnaire, Caisse)
- retard        : loyer impayé après le 05              (Admin, Gestionnaire, Caisse)
- expulsion     : contrat « À risque » (2 mois d'impayés consécutifs) — Admin uniquement
Chaque message préparé est noté dans messages_whatsapp (historique des relances).
"""
import re
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path
from typing import Literal
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import func
from sqlalchemy.orm import Session as SessionDB

import recus
from commun import charger, est_admin
from models import Contrat, MessageWhatsApp, Paiement, Utilisateur, STATUTS_EN_COURS, TYPES_MESSAGE
from paiements import (contrats_du_perimetre, date_limite, libelle_mois, libelle_periode, prochains_mois,
                       recalculer_tout, resume_impayes)
from securite import exiger_module, get_db, peut_acceder, verifier_cite_autorisee

router = APIRouter(prefix="/api")
acces_paiements = exiger_module("paiements")

MODELES = Path(__file__).parent / "modeles" / "messages_whatsapp.txt"
JOURS_RAPPEL = 7  # le rappel est proposé dans les 7 jours avant la date limite


# ---------- Textes ----------

def lire_modeles() -> dict[str, str]:
    """Découpe le fichier en messages : [nom] puis le texte (lignes « # » ignorées)."""
    messages, courant = {}, None
    for ligne in MODELES.read_text(encoding="utf-8").splitlines():
        if ligne.startswith("#"):
            continue
        titre = re.fullmatch(r"\[(\w+)\]\s*", ligne)
        if titre:
            courant = titre.group(1)
            messages[courant] = []
        elif courant:
            messages[courant].append(ligne.rstrip())
    return {nom: "\n".join(lignes).strip() for nom, lignes in messages.items()}


def numero_whatsapp(telephone: str | None) -> str | None:
    """« 07 49 62 25 66 » → « 2250749622566 » (indicatif de la Côte d'Ivoire ajouté)."""
    chiffres = re.sub(r"\D", "", telephone or "")
    if len(chiffres) == 10:
        chiffres = "225" + chiffres
    return chiffres if 8 <= len(chiffres) <= 15 else None


def valeurs_contrat(c: Contrat) -> dict:
    terme = ("au début de chaque mois (au plus tard le 05)" if c.terme_loyer == "Début de mois"
             else "à la fin de chaque mois (au plus tard le 05 du mois suivant)")
    return {
        "locataire": c.locataire.nom_complet, "logement": c.logement.numero_logement,
        "bien": c.logement.cite.nom, "numero_contrat": c.numero_contrat,
        "loyer": recus.francs(c.montant_loyer), "terme": terme,
        "date_debut": c.date_debut.strftime("%d/%m/%Y"),
    }


def prochaine_echeance(c: Contrat, aujourdhui: date):
    """Prochain mois à payer (hors avance) s'il arrive à échéance dans les 7 jours."""
    prochain = prochains_mois(c, 1)
    if not prochain or c.statut_contrat not in STATUTS_EN_COURS or c.statut_contrat == "En attente":
        return None
    mois, montant = prochain[0]
    limite = date_limite(mois, c.terme_loyer)
    if not aujourdhui <= limite <= aujourdhui + timedelta(days=JOURS_RAPPEL):
        return None
    return mois, montant, limite


def derniers_envois(db: SessionDB, contrat_ids: list[int]) -> dict:
    """{(contrat_id, type) : date du dernier message préparé}."""
    if not contrat_ids:
        return {}
    lignes = db.query(MessageWhatsApp.contrat_id, MessageWhatsApp.type_message, func.max(MessageWhatsApp.cree_le)) \
        .filter(MessageWhatsApp.contrat_id.in_(contrat_ids)) \
        .group_by(MessageWhatsApp.contrat_id, MessageWhatsApp.type_message).all()
    return {(cid, t): quand.strftime("%d/%m/%Y") for cid, t, quand in lignes}


# ---------- Préparer un message ----------

class DemandeMessage(BaseModel):
    type_message: Literal[TYPES_MESSAGE]
    contrat_id: int | None = None
    paiement_id: int | None = None   # pour la confirmation de paiement


@router.post("/whatsapp")
def preparer_message(demande: DemandeMessage, utilisateur: Utilisateur = Depends(acces_paiements),
                     db: SessionDB = Depends(get_db)):
    aujourdhui = date.today()
    paiement = None
    if demande.type_message == "confirmation":
        if demande.paiement_id is None:
            raise HTTPException(status_code=400, detail="Paiement manquant.")
        paiement = charger(db, Paiement, demande.paiement_id, "Paiement introuvable.")
        if paiement.statut_paiement != "Payé":
            raise HTTPException(status_code=409, detail="Ce paiement est annulé.")
        contrat = paiement.contrat
    else:
        if demande.contrat_id is None:
            raise HTTPException(status_code=400, detail="Contrat manquant.")
        contrat = charger(db, Contrat, demande.contrat_id, "Contrat introuvable.")
    try:
        verifier_cite_autorisee(utilisateur, contrat.logement.cite_id)
    except HTTPException:
        raise HTTPException(status_code=404, detail="Contrat introuvable.")

    # Droits propres à chaque message (vérifiés ici, pas seulement à l'écran)
    if demande.type_message == "bienvenue" and not peut_acceder(utilisateur.role.value, "contrats"):
        raise HTTPException(status_code=403, detail="Message de bienvenue réservé à l'Admin et au Gestionnaire.")
    if demande.type_message == "expulsion" and not est_admin(utilisateur):
        raise HTTPException(status_code=403, detail="L'avis d'expulsion est réservé à l'Admin.")

    valeurs = valeurs_contrat(contrat)
    recalculer_tout(db, [contrat])
    if demande.type_message == "rappel":
        echeance = prochaine_echeance(contrat, aujourdhui)
        if echeance is None:
            raise HTTPException(status_code=409, detail="Aucune échéance dans les 7 prochains jours pour ce contrat.")
        mois, montant, limite = echeance
        valeurs.update(mois=libelle_mois(mois), montant=recus.francs(montant), date_limite=limite.strftime("%d/%m/%Y"))
    elif demande.type_message in ("retard", "expulsion"):
        impayes = resume_impayes(contrat, aujourdhui)
        if impayes is None:
            raise HTTPException(status_code=409, detail="Ce contrat n'a pas d'impayé.")
        if demande.type_message == "expulsion" and not impayes["a_risque"]:
            raise HTTPException(status_code=409, detail="L'avis d'expulsion n'est possible qu'après "
                                                        "2 mois d'impayés consécutifs (contrat « À risque »).")
        valeurs.update(nb_mois=impayes["nb_mois"], mois_dus=", ".join(impayes["mois"]),
                       montant_du=recus.francs(Decimal(str(impayes["montant"]))))
    elif demande.type_message == "confirmation":
        valeurs.update(montant=recus.francs(paiement.montant), motif=paiement.motif_paiement,
                       periode=libelle_periode(paiement.periode_debut, paiement.periode_fin) or "—",
                       date_paiement=paiement.date_paiement.strftime("%d/%m/%Y"), mode=paiement.mode_paiement,
                       numero_recu=paiement.numero_recu)

    numero = numero_whatsapp(contrat.locataire.telephone)
    if numero is None:
        raise HTTPException(status_code=409, detail="Pas de numéro de téléphone valide pour ce locataire "
                                                    "(à compléter dans sa fiche).")
    modele = lire_modeles().get(demande.type_message)
    if not modele:
        raise HTTPException(status_code=500, detail=f"Message « {demande.type_message} » absent du modèle.")
    message = modele.format_map(recus._ValeursModele(valeurs))

    db.add(MessageWhatsApp(type_message=demande.type_message, contrat_id=contrat.id,
                           paiement_id=paiement.id if paiement else None, utilisateur_id=utilisateur.id,
                           telephone=contrat.locataire.telephone, message=message))
    db.commit()
    return {"lien": f"https://wa.me/{numero}?text={quote(message)}", "message": message,
            "locataire": contrat.locataire.nom_complet}


# ---------- Échéances à venir (pour les rappels) ----------

@router.get("/echeances/a-venir")
def echeances_a_venir(utilisateur: Utilisateur = Depends(acces_paiements), db: SessionDB = Depends(get_db)):
    contrats = contrats_du_perimetre(db, utilisateur)
    recalculer_tout(db, contrats)
    aujourdhui = date.today()
    envois = derniers_envois(db, [c.id for c in contrats])
    lignes = []
    for c in contrats:
        echeance = prochaine_echeance(c, aujourdhui)
        if echeance is None:
            continue
        mois, montant, limite = echeance
        lignes.append({
            "id": c.id, "numero_contrat": c.numero_contrat,
            "locataire": {"nom_complet": c.locataire.nom_complet, "telephone": c.locataire.telephone},
            "logement": f"Logement {c.logement.numero_logement}, {c.logement.cite.nom}",
            "adresse": c.logement.cite.adresse,
            "mois": libelle_mois(mois), "montant": float(montant), "date_limite": limite.isoformat(),
            "jours_restants": (limite - aujourdhui).days, "dernier_rappel": envois.get((c.id, "rappel")),
        })
    return sorted(lignes, key=lambda l: (l["date_limite"], l["locataire"]["nom_complet"]))


@router.get("/whatsapp/derniers-envois")
def derniers(utilisateur: Utilisateur = Depends(acces_paiements), db: SessionDB = Depends(get_db)):
    """Dernier message de chaque type par contrat (affiché à côté des boutons)."""
    contrats = contrats_du_perimetre(db, utilisateur)
    envois = derniers_envois(db, [c.id for c in contrats])
    resultat: dict[str, dict] = {}
    for (cid, t), quand in envois.items():
        resultat.setdefault(str(cid), {})[t] = quand
    return resultat
