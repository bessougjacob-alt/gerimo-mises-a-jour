"""Version du logiciel et mises à jour (bouton en bas à droite).

Deux façons de mettre à jour, choisies automatiquement :
- Serveur installé (ISUP ERP Serveur.exe, sans Git) : MISE À JOUR EN LIGNE. Le bouton lit sur GitHub la
  dernière version publiée (publication.json, envoyée par publier.bat depuis le PC de développement),
  télécharge le paquet, sauvegarde la base et les fichiers, installe les fichiers du logiciel
  (maj_fichiers.py), puis redémarre le serveur ; au démarrage, les migrations mettent la base à jour.
  Si la nouvelle version ne démarre pas, l'ancienne est remise automatiquement.
- Projet Git (PC de développement, ou serveur installé avec Git) : git pull puis migrations.
Les PC et téléphones affichent le logiciel du serveur : ils se rechargent d'eux-mêmes après la mise à jour.
"""
import base64
import binascii
import importlib.util
import json
import os
import platform
import re
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session as SessionDB

import maj_fichiers
import parametres
import recus
from database import engine

from models import Utilisateur
from securite import exiger_admin, get_db, utilisateur_connecte

router = APIRouter(prefix="/api")
DOSSIER = Path(__file__).parent
API_GITHUB = "https://api.github.com"
BRANCHE = "main"


def git(*arguments: str, timeout: int = 30) -> str:
    resultat = subprocess.run(["git", *arguments], cwd=DOSSIER, capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=timeout)
    if resultat.returncode != 0:
        raise RuntimeError((resultat.stderr or resultat.stdout).strip())
    return resultat.stdout.strip()


def mode_git() -> bool:
    return (DOSSIER / ".git").exists()


def numero_de(infos: dict) -> int:
    """Numéro de version comparable (« 1.42 » → 42)."""
    if isinstance(infos.get("numero"), int):
        return infos["numero"]
    m = re.search(r"\.(\d+)$", str(infos.get("version", "")))
    return int(m.group(1)) if m else 0


def _sans_notes_internes(sujet: str) -> bool:
    return "CLAUDE.md" not in sujet and not sujet.startswith("Publication de la version")


def journal_nouveautes() -> list[dict]:
    """Journal des nouveautés (nouveautes.json) : par version, quelques titres courts et ce qu'ils apportent.
    La version « prochaine » regroupe ce qui sera publié au prochain publier.bat."""
    try:
        versions = json.loads((DOSSIER / "nouveautes.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    return [v for v in versions if isinstance(v, dict) and v.get("elements")]


def a_plat(versions: list[dict]) -> list[dict]:
    """Ancienne présentation (date + texte), encore lue par les serveurs installés avant ce journal."""
    return [{"date": v.get("date", ""), "texte": e["titre"] + (f" — {e['apport']}" if e.get("apport") else "")}
            for v in versions for e in v["elements"]]


def avec_journal(infos: dict) -> dict:
    versions = journal_nouveautes() or infos.get("versions") or []
    if not versions:
        return infos
    if not mode_git():  # serveur installé : ce qui était « prochaine » est la version en service
        versions = [{**v, "version": infos["version"], "numero": numero_de(infos), "date": infos.get("date", "")}
                    if v.get("version") == "prochaine" else v for v in versions]
    return {**infos, "versions": versions[:12], "nouveautes": a_plat(versions)[:15]}


_EN_SERVICE: dict | None = None  # version chargée au démarrage du serveur (installé sans Git)


def infos_version() -> dict:
    """Version qui TOURNE. Serveur installé : lue une fois au démarrage, pour qu'après l'installation d'une mise
    à jour (fichiers déjà copiés, redémarrage dans 2 secondes) on n'annonce pas trop tôt la nouvelle version."""
    global _EN_SERVICE
    if mode_git():
        return avec_journal(version_sur_disque())
    if _EN_SERVICE is None:
        _EN_SERVICE = avec_journal(version_sur_disque())
    return _EN_SERVICE


def version_sur_disque() -> dict:
    if mode_git():
        try:
            nombre = git("rev-list", "--count", "HEAD")
            date = git("log", "-1", "--format=%cd", "--date=format:%d/%m/%Y")
            journal = git("log", "-25", "--format=%cd|%s", "--date=format:%d/%m/%Y")
            nouveautes = [{"date": l.split("|", 1)[0], "texte": l.split("|", 1)[1]} for l in journal.splitlines()
                          if "|" in l and _sans_notes_internes(l.split("|", 1)[1])][:15]
            return {"version": f"1.{nombre}", "numero": int(nombre), "date": date, "nouveautes": nouveautes}
        except (RuntimeError, OSError, subprocess.TimeoutExpired, ValueError):
            pass
    # Version installée sans Git : la plus récente entre la construction (VERSION.json)
    # et la dernière mise à jour en ligne (publication.json)
    meilleure = {"version": "1.0", "numero": 0, "date": "", "nouveautes": []}
    for nom in ("VERSION.json", "publication.json"):
        fichier = DOSSIER / nom
        if fichier.exists():
            try:
                infos = json.loads(fichier.read_text(encoding="utf-8"))
            except ValueError:
                continue
            if numero_de(infos) >= numero_de(meilleure):
                meilleure = {**infos, "numero": numero_de(infos)}
    return meilleure


def distant() -> str | None:
    try:
        return git("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}") or None
    except (RuntimeError, OSError, subprocess.TimeoutExpired):
        return None


# ---------- Mise à jour en ligne (GitHub) ----------

def reglages(db: SessionDB) -> tuple[str, str]:
    return parametres.lire(db, "maj_depot").strip(), parametres.lire(db, "maj_jeton").strip()


def telecharger(url: str, jeton: str, accept: str, timeout: int = 60) -> bytes:
    requete = urllib.request.Request(url, headers={"Accept": accept, "User-Agent": "Gerimo-mises-a-jour",
                                                   "X-GitHub-Api-Version": "2022-11-28"})
    if jeton:
        requete.add_header("Authorization", f"Bearer {jeton}")
    try:
        with urllib.request.urlopen(requete, timeout=timeout) as reponse:
            return reponse.read(maj_fichiers.TAILLE_MAX + 1)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise RuntimeError("accès refusé par GitHub : vérifiez le jeton dans Paramètres → Réglages")
        if e.code == 404:
            raise RuntimeError("dépôt ou version publiée introuvable : vérifiez le nom du dépôt (Paramètres), "
                               "et qu'une version a bien été publiée avec publier.bat")
        raise RuntimeError(f"GitHub a répondu {e.code}")
    except (urllib.error.URLError, TimeoutError, OSError):
        raise RuntimeError("pas de connexion Internet")


def publication_distante(depot: str, jeton: str) -> dict:
    brut = telecharger(f"{API_GITHUB}/repos/{depot}/contents/publication.json?ref={BRANCHE}", jeton,
                       "application/vnd.github.raw+json", timeout=30)
    try:
        infos = json.loads(brut.decode("utf-8"))
    except ValueError:
        raise RuntimeError("publication.json illisible sur GitHub")
    return {**infos, "numero": numero_de(infos)}


def paquet_distant(depot: str, jeton: str) -> bytes:
    return telecharger(f"{API_GITHUB}/repos/{depot}/zipball/{BRANCHE}", jeton, "application/vnd.github+json",
                       timeout=180)


def modules_manquants(publication: dict) -> list[str]:
    """Composants dont la nouvelle version a besoin mais qui ne sont pas dans ce serveur installé.
    Chaque module est cherché en entier (« cryptography.hazmat.primitives.ciphers.aead », pas seulement
    « cryptography ») : le 13/10/2026, la 1.114 s'est installée alors qu'un morceau manquait, et le serveur
    ne démarrait plus."""
    manquants = []
    for module in publication.get("modules", []):
        if module in sys.modules:  # déjà chargé : présent (dans le programme installé, find_spec lèverait une
            continue               # erreur pour un module chargé sans __spec__, ex. cryptography…serialization)
        try:
            if importlib.util.find_spec(module) is None:
                manquants.append(module)
        except (ImportError, ValueError, AttributeError):
            manquants.append(module)
    return manquants


def redemarrer_bientot() -> bool:
    """Serveur installé (exe) : relance le programme dans 2 secondes. En développement (uvicorn --reload),
    le serveur se recharge tout seul quand les fichiers changent."""
    if not getattr(sys, "frozen", False):
        return False

    def relancer():
        time.sleep(2)
        try:  # arrêt voulu : sinon le gardien croit à un plantage et lance un 2e serveur (ports déjà pris)
            import continuite
            continuite.noter_arret_volontaire(DOSSIER)
        except Exception:  # noqa: BLE001
            pass
        drapeaux = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        subprocess.Popen([sys.executable], cwd=DOSSIER, close_fds=True, creationflags=drapeaux,
                         env=dict(os.environ, ISUP_SANS_NAVIGATEUR="1", ISUP_APRES_MAJ="1", ISUP_MESSAGE_MAJ=""))
        os._exit(0)
    threading.Thread(target=relancer, daemon=True).start()
    return True


@router.get("/version")
def version(u: Utilisateur = Depends(utilisateur_connecte), db: SessionDB = Depends(get_db)):
    configure = distant() is not None if mode_git() else bool(reglages(db)[0])
    return {**infos_version(), "depot_configure": configure, "developpement": mode_git()}


@router.post("/version/verifier")
def verifier(u: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):  # Admin uniquement
    if mode_git():
        return _verifier_git()
    depot, jeton = reglages(db)
    if not depot:
        return {"disponible": False, "message": "Les mises à jour en ligne ne sont pas encore réglées : indiquez le dépôt "
                                                "GitHub dans Paramètres → Réglages → Mises à jour en ligne."}
    try:
        publication = publication_distante(depot, jeton)
    except RuntimeError as e:
        conseil = " Sans Internet, vous pouvez installer une mise à jour apportée sur clé USB (bouton « Depuis une clé USB »)."
        return {"disponible": False, "message": f"Vérification impossible : {e}." + (conseil if "Internet" in str(e) else "")}
    actuelle = infos_version()
    if publication["numero"] <= numero_de(actuelle):
        return {"disponible": False, "message": f"Vous avez la dernière version ({actuelle['version']}). 👍"}
    manquants = modules_manquants(publication)
    if publication.get("versions"):  # journal des nouveautés : seulement ce qui est plus récent que la version installée
        elements = [e for v in publication["versions"] if numero_de(v) > numero_de(actuelle) for e in v["elements"]]
    else:
        elements = [{"titre": n["texte"] if isinstance(n, dict) else str(n), "apport": ""}
                    for n in publication.get("nouveautes", [])]
    retour = {"disponible": True, "installable": not manquants, "version": publication.get("version"),
              "message": f"Nouvelle version {publication.get('version')} disponible (vous avez la {actuelle['version']}).",
              "elements": elements[:15], "nouveautes": [e["titre"] for e in elements][:15]}
    if manquants:
        retour["message"] += (" Elle a besoin d'un nouveau composant (" + ", ".join(manquants) + ") : il faut "
                              "réinstaller une fois le programme serveur complet (nouvelle distribution), puis les "
                              "mises à jour par ce bouton reprendront.")
    return retour


def _verifier_git() -> dict:
    branche = distant()
    if branche is None:
        return {"disponible": False, "message": "Ce PC est le poste de développement : publiez vos modifications avec "
                                                "publier.bat, puis mettez à jour le serveur depuis son propre bouton."}
    try:
        git("fetch", "--quiet", timeout=60)
        retard = int(git("rev-list", "--count", f"HEAD..{branche}") or 0)
        nouveautes = git("log", f"HEAD..{branche}", "--format=%s").splitlines() if retard else []
    except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
        return {"disponible": False, "message": f"Vérification impossible (Internet ?) : {str(e)[:150]}"}
    if not retard:
        return {"disponible": False, "message": "Vous avez la dernière version. 👍"}
    return {"disponible": True, "installable": True, "message": f"{retard} amélioration(s) disponible(s).",
            "nouveautes": [n for n in nouveautes if _sans_notes_internes(n)][:15]}


@router.post("/version/installer")
def installer(admin: Utilisateur = Depends(exiger_admin), db: SessionDB = Depends(get_db)):
    if mode_git():
        return _installer_git()
    depot, jeton = reglages(db)
    if not depot:
        raise HTTPException(status_code=409, detail="Mises à jour en ligne non réglées (Paramètres → Réglages).")
    avant = infos_version()
    try:
        publication = publication_distante(depot, jeton)
        if publication["numero"] <= numero_de(avant):
            return {"ok": True, "redemarrage": False, "message": "Vous avez déjà la dernière version."}
        if modules_manquants(publication):
            raise HTTPException(status_code=409, detail="Cette version a besoin d'un nouveau composant : réinstallez "
                                                        "le programme serveur complet (nouvelle distribution).")
        fichiers = maj_fichiers.lire_paquet(paquet_distant(depot, jeton))
        maj_fichiers.verifier_code(fichiers)
    except (RuntimeError, ValueError) as e:
        raise HTTPException(status_code=502, detail=f"Mise à jour impossible : {e}")
    _verifier_signature(fichiers, publication.get("version"))
    return _installer_fichiers(fichiers, publication, avant)


def _verifier_signature(fichiers: dict[str, bytes], version_annoncee: str | None) -> None:
    import editeur
    try:
        signe = editeur.verifier_paquet(fichiers)  # signée par l'éditeur, fichier par fichier
    except editeur.SignatureInvalide as e:
        raise HTTPException(status_code=502, detail=f"Mise à jour REFUSÉE ({e}) : elle ne vient pas de l'éditeur de "
                                                    "Gérimo, ou a été modifiée en route. Rien n'a été installé.")
    if signe["version"] != version_annoncee:
        raise HTTPException(status_code=502, detail="Mise à jour REFUSÉE : version différente de celle annoncée.")


def _installer_fichiers(fichiers: dict[str, bytes], publication: dict, avant: dict) -> dict:
    """Fichiers déjà vérifiés (code + signature) : sauvegarde, installation, redémarrage."""
    import sauvegarde
    sauvegarde.creer_sauvegarde("avant-mise-a-jour")  # base + documents, avant de toucher à quoi que ce soit
    try:
        maj_fichiers.appliquer(fichiers, DOSSIER, avant["version"])
    except OSError as e:
        raise HTTPException(status_code=500, detail=f"Installation interrompue, ancienne version gardée : {e}")
    if not redemarrer_bientot():
        maj_fichiers.confirmer(DOSSIER)  # hors programme serveur : pas de contrôle au redémarrage
    return {"ok": True, "redemarrage": True, "version": publication.get("version"),
            "message": f"Version {publication.get('version')} installée (base sauvegardée avant). Le serveur redémarre : "
                       "le logiciel se rechargera tout seul dans quelques secondes."}


# ---------- Mise à jour depuis un fichier (clé USB), pour les clients sans Internet ----------
# Le fichier « Gérimo mise à jour 1.xxx.zip » est fabriqué par publier.bat (ou mise_a_jour_usb.bat) sur le PC de
# l'éditeur. Il contient exactement les fichiers de la version publiée, avec leur signature : le serveur fait les
# mêmes contrôles que pour la mise à jour en ligne (signature de l'éditeur, code correct, composants présents,
# sauvegarde avant, retour arrière automatique si la nouvelle version ne démarre pas).

class FichierMajIn(BaseModel):
    contenu: str = Field(min_length=10, max_length=maj_fichiers.TAILLE_MAX * 4 // 3 + 16)  # zip en base64
    installer: bool = False


def lire_fichier_maj(contenu_b64: str) -> tuple[dict[str, bytes], dict]:
    """Fichier choisi → (fichiers vérifiés, publication). Lève HTTPException avec un message clair sinon."""
    try:
        brut = base64.b64decode(contenu_b64.split(",", 1)[-1], validate=True)
        fichiers = maj_fichiers.lire_paquet(brut)
        maj_fichiers.verifier_code(fichiers)
        publication = json.loads(fichiers["publication.json"].decode("utf-8"))
    except (ValueError, UnicodeDecodeError, binascii.Error) as e:
        raise HTTPException(status_code=422, detail=f"Ce fichier n'est pas une mise à jour de Gérimo valable : {e}"
                                                    if str(e) else "Ce fichier n'est pas une mise à jour de Gérimo.")
    _verifier_signature(fichiers, publication.get("version"))
    return fichiers, {**publication, "numero": numero_de(publication)}


@router.post("/version/fichier")
def installer_fichier(d: FichierMajIn, admin: Utilisateur = Depends(exiger_admin)):
    """Mise à jour par clé USB : d'abord vérifier le fichier (installer=False), puis l'installer (installer=True)."""
    if mode_git():
        raise HTTPException(status_code=409, detail="Ce PC est le poste de développement : il se met à jour avec Git, "
                                                    "pas par clé USB.")
    fichiers, publication = lire_fichier_maj(d.contenu)
    avant = infos_version()
    if publication["numero"] <= numero_de(avant):
        return {"disponible": False, "message": f"Ce fichier contient la version {publication.get('version')} : vous "
                                                f"avez déjà la {avant['version']}, rien à installer."}
    manquants = modules_manquants(publication)
    if manquants:
        raise HTTPException(status_code=409, detail=f"La version {publication.get('version')} a besoin d'un nouveau "
                            "composant (" + ", ".join(manquants) + ") : il faut réinstaller une fois le programme "
                            "serveur complet (nouvelle distribution).")
    if not d.installer:
        if publication.get("versions"):
            elements = [e for v in publication["versions"] if numero_de(v) > numero_de(avant) for e in v["elements"]]
        else:
            elements = [{"titre": n["texte"] if isinstance(n, dict) else str(n), "apport": ""}
                        for n in publication.get("nouveautes", [])]
        return {"disponible": True, "version": publication.get("version"), "elements": elements[:15],
                "message": f"✅ Fichier valable, signé par l'éditeur : version {publication.get('version')} "
                           f"(vous avez la {avant['version']})."}
    return _installer_fichiers(fichiers, publication, avant)


def _installer_git() -> dict:
    if distant() is None:
        raise HTTPException(status_code=409, detail="Aucun serveur de mises à jour configuré.")
    try:
        if git("status", "--porcelain", "--untracked-files=no"):
            raise HTTPException(status_code=409, detail="Des fichiers du logiciel ont été modifiés sur ce poste : "
                                                        "mise à jour automatique impossible sans risque.")
        git("pull", "--ff-only", "--quiet", timeout=120)
        subprocess.run([str(DOSSIER / "venv" / "Scripts" / "python.exe"), "migrer.py"], cwd=DOSSIER,
                       capture_output=True, timeout=300, check=True)
    except (RuntimeError, OSError, subprocess.SubprocessError) as e:
        raise HTTPException(status_code=500, detail=f"Mise à jour interrompue : {str(e)[:200]}")
    return {"ok": True, "redemarrage": True,
            "message": "Mise à jour installée. Le logiciel redémarre : il se rechargera tout seul dans quelques secondes."}


# ---------- À propos du logiciel (Paramètres, Admin) ----------

COMPOSANTS = [
    ("FastAPI", "serveur web", "MIT"), ("Uvicorn", "serveur HTTP", "BSD-3"), ("SQLAlchemy", "accès à la base", "MIT"),
    ("PostgreSQL", "base de données", "Licence PostgreSQL"), ("psycopg2", "pilote PostgreSQL", "LGPL-3.0"),
    ("bcrypt", "protection des mots de passe", "Apache-2.0"), ("fpdf2", "documents PDF", "LGPL-3.0"),
    ("PyMuPDF", "carte de visite (maquette PDF)", "AGPL-3.0"), ("Pillow", "photos", "MIT-CMU"),
    ("num2words", "montants en lettres", "LGPL-2.1"),
    ("Montserrat", "police des titres", "SIL Open Font License 1.1"),
    ("Plus Jakarta Sans", "police du texte", "SIL Open Font License 1.1"),
]
POLITIQUE = DOSSIER / "modeles" / "politique_confidentialite.txt"


@router.get("/a-propos")
def a_propos(admin: Utilisateur = Depends(exiger_admin)):
    with engine.connect() as c:
        postgres = c.execute(text("SHOW server_version")).scalar()
    v = infos_version()
    return {
        **v, "nom": "Gérimo Pro", "sous_titre": "Logiciel de gestion immobilière",
        "licencie": recus.ENTETE,  # société cliente qui utilise Gérimo (pas d'éditeur affiché pour l'instant)
        "python": platform.python_version(), "postgresql": postgres,
        "systeme": f"{platform.system()} {platform.release()}",
        "migrations": len(list((DOSSIER / "migrations").glob("*.sql"))),
        "composants": [{"nom": n, "role": r, "licence": l} for n, r, l in COMPOSANTS],
        "politique": recus.remplir_modele(POLITIQUE.read_text(encoding="utf-8"), {}),
        "politique_date": datetime.fromtimestamp(POLITIQUE.stat().st_mtime).strftime("%d/%m/%Y"),
        "annee": datetime.now().year,
    }
